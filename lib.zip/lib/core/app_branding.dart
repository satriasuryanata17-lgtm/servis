class AppBranding {
  static const String appName = 'Juragan Servis';
  static const String compactName = 'JuraganServis';
  static const String productLine = 'Servis Elektronik POS';
  static const String supportGreeting =
      'Halo Admin! Saya ingin bertanya seputar fitur aplikasi Juragan Servis.';
}

