import 'package:flutter/foundation.dart';

class AppRuntimeConfig {
  static const _devSupabaseUrl = 'https://hdnuemoqnrysuvkvwbdd.supabase.co';
  static const _devSupabaseAnonKey =
      'sb_publishable_KRZiiOHub-9hnurIA-jzhA_egjXOVkz';
  static const _devSupportWhatsappNumber = '6285187586061';
  static const _defaultWindowsUpdateManifestUrl =
      'https://updates.juragankasir.biz.id/juragan-servis/windows/latest.json';
  static const _defaultAndroidUpdateManifestUrl =
      'https://updates.juragankasir.biz.id/juragan-servis/android/latest.json';
  static const _defaultAndroidUpdateSource = 'r2';

  static String get supabaseUrl {
    const env = String.fromEnvironment('JURAGAN_SUPABASE_URL');
    if (env.isNotEmpty) return env;
    if (!kReleaseMode) return _devSupabaseUrl;
    throw StateError('Missing JURAGAN_SUPABASE_URL');
  }

  static String get supabaseAnonKey {
    const env = String.fromEnvironment('JURAGAN_SUPABASE_ANON_KEY');
    if (env.isNotEmpty) return env;
    if (!kReleaseMode) return _devSupabaseAnonKey;
    throw StateError('Missing JURAGAN_SUPABASE_ANON_KEY');
  }

  static String get supportWhatsappNumber {
    const env = String.fromEnvironment('JURAGAN_SUPPORT_WHATSAPP');
    if (env.isNotEmpty) return _normalizePhone(env);
    if (!kReleaseMode) return _normalizePhone(_devSupportWhatsappNumber);
    throw StateError('Missing JURAGAN_SUPPORT_WHATSAPP');
  }

  static String get supportWhatsappUrl =>
      'https://wa.me/$supportWhatsappNumber';

  static String get appVersion {
    const env = String.fromEnvironment('JURAGAN_APP_VERSION');
    if (env.isNotEmpty) return env;
    return '1.0.0';
  }

  static int get appBuildNumber {
    const env = String.fromEnvironment('JURAGAN_APP_BUILD_NUMBER');
    if (env.isNotEmpty) return int.tryParse(env) ?? 0;
    return 1;
  }

  static String get windowsUpdateManifestUrl {
    const env = String.fromEnvironment('JURAGAN_WINDOWS_UPDATE_MANIFEST_URL');
    if (env.isNotEmpty) return env;
    return _defaultWindowsUpdateManifestUrl;
  }

  static String get androidUpdateManifestUrl {
    const env = String.fromEnvironment('JURAGAN_ANDROID_UPDATE_MANIFEST_URL');
    if (env.isNotEmpty) return env;
    return _defaultAndroidUpdateManifestUrl;
  }

  static String get androidUpdateSource {
    const androidEnv = String.fromEnvironment('JURAGAN_ANDROID_UPDATE_SOURCE');
    const generalEnv = String.fromEnvironment('JURAGAN_UPDATE_SOURCE');
    final value =
        (androidEnv.isNotEmpty ? androidEnv : generalEnv).trim().toLowerCase();
    if (value == 'playstore' || value == 'play_store') return 'playstore';
    if (value == 'r2' || value == 'manual') return 'r2';
    return _defaultAndroidUpdateSource;
  }

  static bool get useAndroidR2Updates => androidUpdateSource == 'r2';

  static List<String> validateReleaseConfiguration() {
    final issues = <String>[];
    if (!kReleaseMode) return issues;

    const supabaseUrlEnv = String.fromEnvironment('JURAGAN_SUPABASE_URL');
    const supabaseAnonKeyEnv =
        String.fromEnvironment('JURAGAN_SUPABASE_ANON_KEY');
    const supportWhatsappEnv =
        String.fromEnvironment('JURAGAN_SUPPORT_WHATSAPP');
    const windowsManifestEnv =
        String.fromEnvironment('JURAGAN_WINDOWS_UPDATE_MANIFEST_URL');
    const androidManifestEnv =
        String.fromEnvironment('JURAGAN_ANDROID_UPDATE_MANIFEST_URL');
    final androidSource = androidUpdateSource;

    if (supabaseUrlEnv.isEmpty) {
      issues.add('JURAGAN_SUPABASE_URL belum diatur.');
    } else if (!supabaseUrlEnv.startsWith('https://')) {
      issues.add('JURAGAN_SUPABASE_URL harus memakai https://.');
    } else if (_looksLikePlaceholder(supabaseUrlEnv)) {
      issues.add('JURAGAN_SUPABASE_URL masih placeholder.');
    }
    if (supabaseAnonKeyEnv.isEmpty) {
      issues.add('JURAGAN_SUPABASE_ANON_KEY belum diatur.');
    } else if (_looksLikePlaceholder(supabaseAnonKeyEnv)) {
      issues.add('JURAGAN_SUPABASE_ANON_KEY masih placeholder.');
    }
    if (supportWhatsappEnv.isEmpty) {
      issues.add('JURAGAN_SUPPORT_WHATSAPP belum diatur.');
    } else if (_normalizePhone(supportWhatsappEnv).length < 10) {
      issues.add('JURAGAN_SUPPORT_WHATSAPP tidak valid.');
    } else if (_looksLikePlaceholder(supportWhatsappEnv)) {
      issues.add('JURAGAN_SUPPORT_WHATSAPP masih placeholder.');
    }
    if (windowsManifestEnv.isNotEmpty &&
        !windowsManifestEnv.startsWith('https://')) {
      issues.add('JURAGAN_WINDOWS_UPDATE_MANIFEST_URL harus memakai https://.');
    } else if (_looksLikePlaceholder(windowsUpdateManifestUrl)) {
      issues.add('JURAGAN_WINDOWS_UPDATE_MANIFEST_URL masih placeholder.');
    }
    if (androidSource != 'r2' && androidSource != 'playstore') {
      issues.add('JURAGAN_UPDATE_SOURCE harus r2 atau playstore.');
    }
    if (androidSource == 'r2') {
      if (androidManifestEnv.isNotEmpty &&
          !androidManifestEnv.startsWith('https://')) {
        issues
            .add('JURAGAN_ANDROID_UPDATE_MANIFEST_URL harus memakai https://.');
      } else if (_looksLikePlaceholder(androidUpdateManifestUrl)) {
        issues.add('JURAGAN_ANDROID_UPDATE_MANIFEST_URL masih placeholder.');
      }
    }
    return issues;
  }

  static bool _looksLikePlaceholder(String value) {
    final normalized = value.trim().toLowerCase();
    if (normalized.isEmpty) return true;
    return normalized.contains('change-me') ||
        normalized.contains('replace-me') ||
        normalized.contains('placeholder') ||
        normalized.contains('example.com') ||
        normalized.contains('your_') ||
        normalized.contains('your-') ||
        normalized.contains('<') ||
        normalized.contains('>');
  }

  static String _normalizePhone(String phone) {
    var value = phone.replaceAll(RegExp(r'[^0-9]'), '');
    if (value.startsWith('0')) {
      value = '62${value.substring(1)}';
    }
    if (value.isNotEmpty && !value.startsWith('62')) {
      value = '62$value';
    }
    return value;
  }
}

