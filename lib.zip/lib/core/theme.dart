import 'package:flutter/material.dart';

class AppIcons {
  AppIcons._();

  // Standard recycle-bin icon for all destructive/remove actions.
  static const IconData recycleBin = Icons.restore_from_trash_rounded;
}

class AppColors {
  static const primary = Color(0xFF1E3A5F); // Deep Navy
  static const primaryBrand = Color(0xFF1E3A5F);
  static const primaryDark = Color(0xFF0C2340);
  static const primaryLight = Color(0xFFEFF6FF);
  static const brandLight = Color(0xFFBFDBFE);

  static const background = Color(0xFFF7F8FA); // Background semua halaman
  static const surface = Color(0xFFFFFFFF); // Surface kartu & panel
  static const surfaceDim = Color(0xFFF0F1F5); // Input field fill

  static const textTitle = Color(0xFF0A0F1E); // Heading utama  hampir hitam
  static const textBody = Color(0xFF3D4350); // Teks paragraph
  static const textCaption = Color(0xFF8B95A5); // Label & timestamp

  static const success = Color(0xFF00A86B);
  static const warning = Color(0xFFFF8A00);
  static const danger = Color(0xFFE73A53);
  static const info = Color(0xFF1A54D6);

  static const warningBg = Color(0xFFFFF8EC);
  static const dangerBg = Color(0xFFFFF2F2);
  static const infoBg = Color(0xFFEEF5FF);

  static const border = Color(0xFFE2E4E8);
  static const borderFocus = Color(0xFF1A54D6);
  static const divider = Color(0xFFF0F2F5);
  static const shadow = Color(0x0C000000); // Shadow super tipis

  // Setiap warna punya pasangan: bg (sangat muda) + fg (icon/label)
  static const iconGreenBg = Color(0xFFE8FBF3);
  static const iconGreen = Color(0xFF00A86B);
  static const iconBlueBg = Color(0xFFE8F0FF);
  static const iconBlue = Color(0xFF2563EB);
  static const iconOrangeBg = Color(0xFFEFF6FF);
  static const iconOrange = Color(0xFF2563EB);
  static const iconPurpleBg = Color(0xFFF3EEFF);
  static const iconPurple = Color(0xFF7C3AED);
  static const iconTealBg = Color(0xFFE6FAFA);
  static const iconTeal = Color(0xFF0891B2);
  static const iconPinkBg = Color(0xFFFFEEF2);
  static const iconPink = Color(0xFFDB2777);
  static const iconAmberBg = Color(0xFFFFF7ED);
  static const iconAmber = Color(0xFFEA580C);
  static const iconGrayBg = Color(0xFFF0F0F4);
  static const iconGray = Color(0xFF64748B);

  // (agar semua file lama tidak perlu diubah)
  static const textPrimary = textTitle;
  static const textSecondary = textBody;
  static const textMuted = textCaption;
  static const textLink = primary;
  static const iconOutline = textTitle;
  static const accent = warning;

  static const dangerLight = dangerBg;
  static const blueLight = infoBg;
  static const blue = iconBlue;

  static const qaTransaksi = iconGreenBg;
  static const qaProduk = iconOrangeBg;
  static const qaLaporan = iconPurpleBg;
  static const qaStok = iconAmberBg;
  static const qaPelanggan = iconPinkBg;
  static const qaSetting = iconGrayBg;
  static const primarySurface = Color(0xFFFFF8F0);
  static const accentLight = Color(0xFFFFF1EC);

  // Gradient color lists (backward compat)
  static const gradGreen = [Color(0xFF00C17B), Color(0xFF009960)];
  static const gradBlue = [Color(0xFF2D6CEA), Color(0xFF1A54D6)];
  static const gradOrange = [Color(0xFFFF6B35), Color(0xFFE85520)];
  static const gradPurple = [Color(0xFF8B5CF6), Color(0xFF7C3AED)];
  static const gradTeal = [
    Color(0xFF2563EB),
    Color(0xFF1E3A5F)
  ]; // Service primary accent
  static const gradPink = [Color(0xFFF43F5E), Color(0xFFE11D48)];
  static const gradAmber = [Color(0xFFFFB800), Color(0xFFE6A800)];
  static const gradservis = [
    Color(0xFF2563EB),
    Color(0xFF1E3A5F)
  ]; // Backward-compatible service gradient
}

class AppText {
  static TextStyle get displayMoney => const TextStyle(
        fontFamily: 'PlusJakartaSans',
        fontSize: 34,
        fontWeight: FontWeight.w800,
        color: AppColors.textTitle,
        letterSpacing: -1.2,
        height: 1.0,
      );

  static TextStyle get money => const TextStyle(
        fontFamily: 'PlusJakartaSans',
        fontSize: 24,
        fontWeight: FontWeight.w700,
        color: AppColors.textTitle,
        letterSpacing: -0.5,
      );

  static TextStyle get h1 => const TextStyle(
        fontFamily: 'PlusJakartaSans',
        fontSize: 28,
        fontWeight: FontWeight.w700,
        color: AppColors.textTitle,
        letterSpacing: -0.6,
        height: 1.2,
      );

  static TextStyle get h2 => const TextStyle(
        fontFamily: 'PlusJakartaSans',
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: AppColors.textTitle,
        letterSpacing: -0.3,
      );

  static TextStyle get h3 => const TextStyle(
        fontFamily: 'PlusJakartaSans',
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: AppColors.textTitle,
      );

  static TextStyle get body => const TextStyle(
        fontFamily: 'PlusJakartaSans',
        fontSize: 16,
        fontWeight: FontWeight.w500,
        color: AppColors.textBody,
        height: 1.5,
      );

  static TextStyle get bodySmall => const TextStyle(
        fontFamily: 'PlusJakartaSans',
        fontSize: 15,
        fontWeight: FontWeight.w400,
        color: AppColors.textBody,
        height: 1.5,
      );

  static TextStyle get caption => const TextStyle(
        fontFamily: 'PlusJakartaSans',
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: AppColors.textCaption,
        height: 1.4,
      );

  static TextStyle get label => const TextStyle(
        fontFamily: 'PlusJakartaSans',
        fontSize: 13,
        fontWeight: FontWeight.w600,
        color: AppColors.textCaption,
        letterSpacing: 0.3,
      );

  static TextStyle get overline => const TextStyle(
        fontFamily: 'PlusJakartaSans',
        fontSize: 12,
        fontWeight: FontWeight.w700,
        color: AppColors.textCaption,
        letterSpacing: 1.2,
      );
}

class Rad {
  // Border radius
  static const double xs = 0;
  static const double sm = 0;
  static const double md = 0;
  static const double lg = 0;
  static const double xl = 0;
  static const double full = 0;
}

class Sp {
  // Spacing
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
}

class Sh {
  // Shadow system
  static List<BoxShadow> get xs => [
        const BoxShadow(
            color: Color(0x08000000), blurRadius: 6, offset: Offset(0, 2)),
      ];

  static List<BoxShadow> get sm => [
        const BoxShadow(
            color: Color(0x0A000000), blurRadius: 12, offset: Offset(0, 3)),
        const BoxShadow(
            color: Color(0x06000000), blurRadius: 4, offset: Offset(0, 1)),
      ];

  static List<BoxShadow> get md => [
        const BoxShadow(
            color: Color(0x0D000000), blurRadius: 20, offset: Offset(0, 6)),
        const BoxShadow(
            color: Color(0x07000000), blurRadius: 6, offset: Offset(0, 2)),
      ];

  static List<BoxShadow> get primaryGlow => [
        BoxShadow(
            color: AppColors.primary.withValues(alpha: 0.3),
            blurRadius: 14,
            offset: const Offset(0, 5)),
      ];
}

// BACKWARD-COMPATIBLE ALIASES (agar file lain tidak perlu diubah)

/// Alias untuk kelas Rad (border radius)
class AppRadius {
  static const double xs = Rad.xs;
  static const double sm = Rad.sm;
  static const double md = Rad.md;
  static const double lg = Rad.lg;
  static const double xl = Rad.xl;
  static const double xxl = Rad.xl;
  static const double full = Rad.full;
}

/// Alias untuk kelas Sp (spacing)
class AppSpacing {
  static const double xs = Sp.xs;
  static const double sm = Sp.sm;
  static const double md = Sp.md;
  static const double lg = Sp.lg;
  static const double xl = Sp.xl;
}

/// Alias untuk kelas Sh (shadow)
class AppShadow {
  static List<BoxShadow> get soft => Sh.xs;
  static List<BoxShadow> get card => Sh.sm;
  static List<BoxShadow> get medium => Sh.md;
  static List<BoxShadow> primaryGlow(Color color) => [
        BoxShadow(
            color: color.withValues(alpha: 0.3),
            blurRadius: 14,
            offset: const Offset(0, 5)),
      ];
}

/// Extension warna untuk alias yang hilang sudah dipindah ke class AppColors

