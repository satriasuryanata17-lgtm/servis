import 'package:flutter/material.dart';

import '../models/db_models.dart';
import 'theme.dart';

const List<String> financeCategoryIconKeys = [
  'receipt',
  'wallet',
  'sales',
  'inventory',
  'salary',
  'materials',
  'stationery',
  'bonus',
  'rent',
  'utilities',
  'transport',
  'promo',
  'operations',
  'maintenance',
  'admin_bank',
  'tax',
  'service',
  'capital',
  'commission',
  'cashback',
  'other',
];

const List<String> financeCategoryColorHexes = [
  '#3A7D7C',
  '#00A86B',
  '#2563EB',
  '#0891B2',
  '#D97706',
  '#7C3AED',
  '#DB2777',
  '#37474F',
  '#C62828',
  '#64748B',
];

IconData financeCategoryIcon(String key, {String? name}) {
  switch (key.trim().toLowerCase()) {
    case 'sales':
      return Icons.point_of_sale_outlined;
    case 'wallet':
      return Icons.account_balance_wallet_outlined;
    case 'inventory':
      return Icons.inventory_2_outlined;
    case 'salary':
      return Icons.badge_outlined;
    case 'materials':
      return Icons.category_outlined;
    case 'stationery':
      return Icons.edit_note_outlined;
    case 'bonus':
      return Icons.card_giftcard_outlined;
    case 'rent':
      return Icons.storefront_outlined;
    case 'utilities':
      return Icons.bolt_outlined;
    case 'transport':
      return Icons.local_shipping_outlined;
    case 'promo':
      return Icons.campaign_outlined;
    case 'operations':
      return Icons.tune_outlined;
    case 'maintenance':
      return Icons.build_outlined;
    case 'admin_bank':
      return Icons.account_balance_outlined;
    case 'tax':
      return Icons.request_quote_outlined;
    case 'service':
      return Icons.handyman_outlined;
    case 'capital':
      return Icons.savings_outlined;
    case 'commission':
      return Icons.workspace_premium_outlined;
    case 'cashback':
      return Icons.replay_circle_filled_outlined;
    case 'installment':
      return Icons.payments_outlined;
    case 'restore':
      return Icons.restore_outlined;
    case 'refund':
      return Icons.assignment_return_outlined;
    case 'cancel':
      return Icons.cancel_outlined;
    case 'adjustment':
      return Icons.tune_outlined;
    case 'other':
      return Icons.more_horiz_outlined;
    case 'receipt':
    default:
      return _fallbackIconForName(name);
  }
}

IconData _fallbackIconForName(String? name) {
  final normalized = (name ?? '').trim().toLowerCase();
  if (normalized.contains('atk')) return Icons.edit_note_outlined;
  if (normalized.contains('perlengkapan')) return Icons.edit_note_outlined;
  if (normalized.contains('bonus')) return Icons.card_giftcard_outlined;
  if (normalized.contains('gaji') || normalized.contains('honor')) {
    return Icons.badge_outlined;
  }
  if (normalized.contains('bahan') || normalized.contains('persediaan')) {
    return Icons.category_outlined;
  }
  if (normalized.contains('jasa')) return Icons.handyman_outlined;
  if (normalized.contains('modal')) return Icons.savings_outlined;
  if (normalized.contains('promosi') || normalized.contains('pemasaran')) {
    return Icons.campaign_outlined;
  }
  if (normalized.contains('pajak')) return Icons.request_quote_outlined;
  if (normalized.contains('bank') || normalized.contains('admin')) {
    return Icons.account_balance_outlined;
  }
  if (normalized.contains('perawatan') || normalized.contains('perbaikan')) {
    return Icons.build_outlined;
  }
  return Icons.receipt_long_outlined;
}

Color financeCategoryColor(String hex) {
  final cleaned = hex.trim().replaceFirst('#', '');
  if (cleaned.length == 6) {
    final value = int.tryParse('FF$cleaned', radix: 16);
    if (value != null) return Color(value);
  }
  if (cleaned.length == 8) {
    final value = int.tryParse(cleaned, radix: 16);
    if (value != null) return Color(value);
  }
  return AppColors.primaryBrand;
}

String defaultFinanceIconKey(String type) {
  return type == 'masuk' ? 'wallet' : 'receipt';
}

String defaultFinanceColorHex(String type) {
  return type == 'masuk' ? '#00A86B' : '#3A7D7C';
}

FinanceCategory? financeCategoryByName(
  List<FinanceCategory> categories,
  String type,
  String name,
) {
  final normalizedType = type == 'masuk' ? 'masuk' : 'keluar';
  final normalizedName = name.trim().toLowerCase();
  for (final category in categories) {
    if (category.type == normalizedType &&
        category.name.trim().toLowerCase() == normalizedName) {
      return category;
    }
  }
  return null;
}

const Set<String> _internalFinanceCategoryNames = {
  'servis',
  'penjualan',
  'pembelian stok',
  'pembatalan',
  'pembatalan pembelian',
  'koreksi',
  'cicilan',
  'pemulihan',
  'refund retur',
};

bool isManualFinanceCategory(FinanceCategory category) {
  return !_internalFinanceCategoryNames.contains(
    category.name.trim().toLowerCase(),
  );
}

