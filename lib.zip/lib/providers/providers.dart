import 'package:flutter/foundation.dart' hide Category;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:async';
import '../models/db_models.dart';
import '../database/db_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../services/auth_service.dart';
import '../services/ai_simple_service.dart';
import '../services/backup_service.dart';
import '../services/support_contact_service.dart';
import '../services/local_notification_service.dart';
import '../services/pos_network_service.dart';

final shellIndexProvider =
    NotifierProvider<ShellIndexNotifier, int>(() => ShellIndexNotifier());

// SELECTED CUSTOMER PROVIDER (global)
class SelectedCustomerNotifier extends Notifier<Customer?> {
  @override
  Customer? build() => null;
  void updateState(Customer? value) => state = value;
}

final selectedCustomerProvider =
    NotifierProvider<SelectedCustomerNotifier, Customer?>(
        SelectedCustomerNotifier.new);

class ShellIndexNotifier extends Notifier<int> {
  @override
  int build() => 1; // Default to Kasir

  void set(int index) => state = index;
}

final currentLicenseProvider = FutureProvider<License?>((ref) async {
  // Listen to auth changes so the license refreshes on login/logout
  ref.watch(authProvider);
  return await DBHelper.instance.getLicense();
});

const String _localDeviceIdFallbackKey = 'local_device_id_fallback_v1';

Future<String> _currentDeviceIdForShift() async {
  try {
    final id = (await AuthService.getDeviceId()).trim();
    if (id.isNotEmpty && id != 'unknown_device') return id;
  } catch (e) {
    debugPrint('shift device id error: $e');
  }

  final prefs = await SharedPreferences.getInstance();
  final existing = prefs.getString(_localDeviceIdFallbackKey)?.trim();
  if (existing != null && existing.isNotEmpty) return existing;

  final fallback = 'local-${DateTime.now().microsecondsSinceEpoch}';
  await prefs.setString(_localDeviceIdFallbackKey, fallback);
  return fallback;
}

// ==============================
// ==============================
// BACKUP PROVIDER
// ==============================
final backupCheckProvider = FutureProvider<bool>((ref) async {
  return await BackupService.shouldRemindBackup();
});

final supportWhatsappProvider = FutureProvider<String>((ref) async {
  return SupportContactService.getSupportWhatsappNumber();
});

final playStoreUrlProvider = FutureProvider<String>((ref) async {
  return SupportContactService.getPlayStoreUrl();
});

// ==============================
// AUTH PROVIDER
// ==============================
enum AuthStatus { initializing, unauthorized, licensee, admin }

final authProvider =
    NotifierProvider<AuthNotifier, AuthStatus>(() => AuthNotifier());

class PendingTransferInfo {
  final String requestId;
  final String licenseId;
  final String requesterDeviceId;
  final String requesterPlatform;
  final int remainingSeconds;

  const PendingTransferInfo({
    required this.requestId,
    required this.licenseId,
    required this.requesterDeviceId,
    required this.requesterPlatform,
    required this.remainingSeconds,
  });
}

final pendingTransferProvider =
    NotifierProvider<PendingTransferNotifier, PendingTransferInfo?>(
        () => PendingTransferNotifier());

class PendingTransferNotifier extends Notifier<PendingTransferInfo?> {
  @override
  PendingTransferInfo? build() => null;

  void set(PendingTransferInfo? info) => state = info;
  void clear() => state = null;
}

class AuthNotifier extends Notifier<AuthStatus> {
  static const Duration _licenseRevalidationInterval = Duration(hours: 6);

  bool _bootstrapped = false;
  Timer? _validationTimer;

  @override
  AuthStatus build() {
    if (!_bootstrapped) {
      _bootstrapped = true;
      ref.onDispose(() {
        _validationTimer?.cancel();
      });
      debugPrint('[Auth] Starting session restoration...');
      // Start restore session but don't block the build
      Future.microtask(() => _restoreSession());
    }
    return AuthStatus.initializing;
  }

  Future<void> _restoreSession() async {
    try {
      debugPrint('[Auth] Getting local license...');
      // 1. Quick Local Check first for professional instant access
      final localLicense = await DBHelper.instance.getLicense();
      debugPrint('[Auth] Local license: ${localLicense != null}');
      if (localLicense != null) {
        // Check local consistency only (no network)
        final deviceId = await AuthService.getDeviceId();
        if (AuthService.isLicenseLocallyValid(localLicense, deviceId)) {
          debugPrint('[Auth] License valid locally.');
          state = AuthStatus.licensee;
          _startValidationTimer();
          Future.microtask(_performPeriodicValidation);
          return;
        }
      }

      debugPrint('[Auth] Deep license check...');
      // 2. If no local session or invalid local data, do the deep check
      final ok = await AuthService.checkLicenseValid();
      debugPrint('[Auth] Deep check result: $ok');
      if (ref.mounted) {
        state = ok ? AuthStatus.licensee : AuthStatus.unauthorized;
        if (ok) _startValidationTimer();
      }
    } catch (e) {
      debugPrint('[Auth] Restore session error: $e');
      if (ref.mounted) state = AuthStatus.unauthorized;
    }
  }

  void _startValidationTimer() {
    _validationTimer?.cancel();

    // Revalidasi lisensi berkala. Saat aplikasi dibuka tetap ada satu validasi
    // server, jadi interval ini tidak perlu agresif dan tidak membebani Supabase.
    _validationTimer =
        Timer.periodic(_licenseRevalidationInterval, (timer) async {
      await _performPeriodicValidation();
    });

    // Self-service ganti perangkat sekarang action-based. Perangkat lama
    // keluar saat validasi berkala/buka aplikasi, jadi tidak perlu polling
    // transfer otomatis yang menghabiskan request database.
  }

  Future<void> _performPeriodicValidation() async {
    final currentLicense = await DBHelper.instance.getLicense();
    if (currentLicense == null) {
      _validationTimer?.cancel();
      return;
    }

    // Panggil revalidasi
    final ok = await AuthService.checkLicenseValid(forceRemote: true);

    // Jika ok == false, berarti server eksplisit bilang lisensi HAPUS/INVALID
    if (!ok) {
      _validationTimer?.cancel();

      final isTrial = currentLicense.isTrial == 1;
      await LocalNotificationService.showAuthNotification(
        title: isTrial ? 'Masa Trial Berakhir' : 'Lisensi Tidak Valid',
        body: isTrial
            ? 'Masa trial Anda telah habis atau akun telah dihapus. Silakan hubungi admin.'
            : 'Akun Anda telah dinonaktifkan atau dihapus dari sistem.',
      );

      await logout();
    }
  }

  /// Unified login pada satu form tanpa memisahkan UI admin dan lisensi.
  Future<AuthStatus> login(String input, String password) async {
    final cleanInput = input.trim();
    final cleanPassword = password.trim();
    final primaryModeIsLicense = _looksLikeLicenseIdentifier(cleanInput);
    AuthBackendRequiredException? primaryBackendError;
    AuthBackendRequiredException? secondaryBackendError;

    Future<AuthStatus> tryLicense() async {
      final isLicense = await AuthService.activateLicense(
        cleanInput.toUpperCase(),
        cleanPassword,
      );
      if (isLicense) {
        if (ref.mounted) {
          state = AuthStatus.licensee;
          _startValidationTimer();
        }
        return AuthStatus.licensee;
      }
      return AuthStatus.unauthorized;
    }

    Future<AuthStatus> tryAdmin() async {
      final isAdmin = await AuthService.adminLogin(
        _normalizeAdminIdentifier(cleanInput),
        cleanPassword,
      );
      if (isAdmin) {
        if (ref.mounted) state = AuthStatus.admin;
        return AuthStatus.admin;
      }
      return AuthStatus.unauthorized;
    }

    Future<AuthStatus> runAttempt(
      bool asLicense,
      bool isPrimary,
    ) async {
      try {
        return asLicense ? await tryLicense() : await tryAdmin();
      } on DeviceLockedException {
        rethrow;
      } on AuthBackendRequiredException catch (e) {
        if (isPrimary) {
          primaryBackendError = e;
        } else {
          secondaryBackendError ??= e;
        }
        return AuthStatus.unauthorized;
      }
    }

    final primaryStatus = await runAttempt(primaryModeIsLicense, true);
    if (primaryStatus != AuthStatus.unauthorized) {
      return primaryStatus;
    }

    final secondaryStatus = await runAttempt(!primaryModeIsLicense, false);
    if (secondaryStatus != AuthStatus.unauthorized) {
      return secondaryStatus;
    }

    if (primaryBackendError != null) {
      throw primaryBackendError!;
    }
    if (secondaryBackendError != null) {
      throw secondaryBackendError!;
    }

    return AuthStatus.unauthorized;
  }

  Future<AuthStatus> startDemoTrial() async {
    final ok = await AuthService.startDemoTrial();
    if (ok) {
      if (ref.mounted) {
        state = AuthStatus.licensee;
        _startValidationTimer();
      }
      return AuthStatus.licensee;
    }
    return AuthStatus.unauthorized;
  }

  Future<AuthStatus> activateStoredLicenseSession() async {
    final license = await DBHelper.instance.getLicense();
    if (license == null) return AuthStatus.unauthorized;

    if (ref.mounted) {
      state = AuthStatus.licensee;
      _startValidationTimer();
    }
    return AuthStatus.licensee;
  }

  Future<AuthStatus> loginAdmin(String username, String password) async {
    final cleanUser = _normalizeAdminIdentifier(username);
    final cleanPassword = password.trim();
    final isAdmin = await AuthService.adminLogin(cleanUser, cleanPassword);
    if (isAdmin) {
      if (ref.mounted) state = AuthStatus.admin;
      return AuthStatus.admin;
    }

    return AuthStatus.unauthorized;
  }

  bool _looksLikeLicenseIdentifier(String value) {
    final normalized = value.trim().toUpperCase();
    return normalized.startsWith('JKSR') || normalized.contains('-');
  }

  String _normalizeAdminIdentifier(String value) {
    return value.trim().replaceAll('-', '');
  }

  /// HP1: Setujui atau tolak transfer, lalu logout jika approve.
  Future<bool> respondToTransfer({
    required String requestId,
    required String licenseId,
    required bool approve,
  }) async {
    final ok = await AuthService.respondDeviceTransfer(
      requestId: requestId,
      licenseId: licenseId,
      approve: approve,
    );
    if (ok && approve) {
      await LocalNotificationService.showAuthNotification(
        title: 'Perangkat Dipindahkan',
        body:
            'Anda telah menyetujui perpindahan perangkat. Akun ini akan keluar.',
      );
      await logout();
    }
    if (ref.mounted) {
      ref.read(pendingTransferProvider.notifier).clear();
    }
    return ok;
  }

  Future<void> logout() async {
    _validationTimer?.cancel();
    final wasLicensee = state == AuthStatus.licensee;
    state = AuthStatus.unauthorized;
    AuthService.clearAdminSession();
    if (wasLicensee) {
      final license = await DBHelper.instance.getLicense();
      if (license != null && license.licenseId != null) {
        await AuthService.unregisterDevice(license.licenseId!);
      }
      await AuthService.clearLocalLicense();
    }
  }

  Future<void> logoutAndReset() async {
    _validationTimer?.cancel();
    state = AuthStatus.initializing;
    AuthService.clearAdminSession();

    // Let AuthGate finish removing the authenticated widget tree first.
    await Future.delayed(const Duration(milliseconds: 700));
    await AuthService.clearLocalLicense();

    if (ref.mounted) {
      state = AuthStatus.unauthorized;
    }
  }
}

final categoriesProvider = NotifierProvider<CategoriesNotifier, List<Category>>(
    () => CategoriesNotifier());

class SelectedCategoryNotifier extends Notifier<int?> {
  @override
  int? build() => null;
  void set(int? id) => state = id;
}

final selectedCategoryIdProvider =
    NotifierProvider<SelectedCategoryNotifier, int?>(
        () => SelectedCategoryNotifier());

final categoryProductCountsProvider =
    FutureProvider<Map<int, int>>((ref) async {
  ref.watch(categoriesProvider);
  ref.watch(productsProvider);
  return await DBHelper.instance.getAllCategoryProductCounts();
});

class CategoriesNotifier extends Notifier<List<Category>> {
  @override
  List<Category> build() {
    loadCategories();
    return [];
  }

  Future<void> loadCategories() async {
    try {
      state = await DBHelper.instance.getCategories();
    } catch (e) {
      debugPrint('loadCategories error: $e');
    }
  }

  void updateFromSync(List<Category> categories) {
    state = categories;
  }

  Future<int> addCategory(String name, {int durationHours = 0}) async {
    try {
      final id = await DBHelper.instance
          .insertCategory(name, durationHours: durationHours);
      await loadCategories();
      return id;
    } catch (e) {
      debugPrint('addCategory error: $e');
      rethrow;
    }
  }

  Future<void> updateCategory(int id, String name, {int? durationHours}) async {
    try {
      await DBHelper.instance
          .updateCategory(id, name, durationHours: durationHours);
      await loadCategories();
    } catch (e) {
      debugPrint('updateCategory error: $e');
      rethrow;
    }
  }

  Future<int> checkProductCount(int catId) async {
    try {
      return await DBHelper.instance.countProductsByCategory(catId);
    } catch (e) {
      debugPrint('checkProductCount error: $e');
      return 0;
    }
  }

  Future<void> deleteCategory(int id) async {
    try {
      await DBHelper.instance.deleteCategory(id);
      await loadCategories();
      // DBHelper reassigns products to the protected default category.
      ref.invalidate(productsProvider);
    } catch (e) {
      debugPrint('deleteCategory error: $e');
      rethrow;
    }
  }
}

// ==============================
// PRODUCTS PROVIDER
// ==============================
final productsProvider =
    NotifierProvider<ProductsNotifier, List<Product>>(() => ProductsNotifier());

class ProductsNotifier extends Notifier<List<Product>> {
  @override
  List<Product> build() {
    loadProducts();
    return [];
  }

  Future<void> loadProducts() async {
    try {
      final net = POSNetworkService.instance;
      if (net.mode == POSNetworkMode.terminal && net.masterIp != null) {
        final data = await net.fetchMenu();
        if (data != null && data['products'] != null) {
          final List list = data['products'];
          state = list.map((e) => Product.fromMap(e)).toList();

          // Also update categories if available
          if (data['categories'] != null) {
            final List catList = data['categories'];
            final categories = catList.map((e) => Category.fromMap(e)).toList();
            ref.read(categoriesProvider.notifier).updateFromSync(categories);
          }
        }
        return;
      }
      state = await DBHelper.instance.getAllProducts();
    } catch (e) {
      debugPrint('loadProducts error: $e');
    }
  }

  Future<int> addProduct(Product p) async {
    try {
      final normalizedProduct =
          p.tracksInventory ? p : p.copyWith(stock: 0, minStock: 0);
      final openingStock =
          normalizedProduct.tracksInventory ? normalizedProduct.stock : 0;
      final productForInsert = openingStock > 0
          ? normalizedProduct.copyWith(stock: 0)
          : normalizedProduct;
      final id = await DBHelper.instance.insertProduct(productForInsert);
      if (openingStock > 0) {
        final now = DateTime.now();
        final dateOnly =
            '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
        final staff = ref.read(activeStaffProvider);
        await DBHelper.instance.insertStockLog(StockLog(
          productId: id,
          type: 'in',
          qty: openingStock,
          date: now.toIso8601String(),
          stockName: 'Stok Awal',
          entryDate: dateOnly,
          expiryDate: normalizedProduct.expiryDate,
          employeeName: staff?.name ?? 'Kasir',
        ));
      }
      await loadProducts();
      return id;
    } catch (e) {
      debugPrint('addProduct error: $e');
      rethrow;
    }
  }

  Future<void> addProducts(List<Product> list) async {
    try {
      for (final p in list) {
        final normalizedProduct =
            p.tracksInventory ? p : p.copyWith(stock: 0, minStock: 0);
        final openingStock =
            normalizedProduct.tracksInventory ? normalizedProduct.stock : 0;
        final productForInsert = openingStock > 0
            ? normalizedProduct.copyWith(stock: 0)
            : normalizedProduct;
        final id = await DBHelper.instance.insertProduct(productForInsert);
        if (openingStock > 0) {
          final now = DateTime.now();
          final dateOnly =
              '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
          final staff = ref.read(activeStaffProvider);
          await DBHelper.instance.insertStockLog(StockLog(
            productId: id,
            type: 'in',
            qty: openingStock,
            date: now.toIso8601String(),
            stockName: 'Stok Awal',
            entryDate: dateOnly,
            expiryDate: normalizedProduct.expiryDate,
            employeeName: staff?.name ?? 'Kasir',
          ));
        }
      }
      await loadProducts();
    } catch (e) {
      debugPrint('addProducts error: $e');
      rethrow;
    }
  }

  Future<void> updateProduct(Product p) async {
    try {
      await DBHelper.instance.updateProduct(p);
      await loadProducts();
    } catch (e) {
      debugPrint('updateProduct error: $e');
      rethrow;
    }
  }

  Future<void> deleteProduct(int id) async {
    try {
      await DBHelper.instance.deleteProduct(id);
      await loadProducts();
    } catch (e) {
      debugPrint('deleteProduct error: $e');
    }
  }

  Future<void> deleteProducts(List<int> ids) async {
    try {
      await DBHelper.instance.deleteProducts(ids);
      await loadProducts();
    } catch (e) {
      debugPrint('deleteProducts error: $e');
    }
  }

  Future<void> recordStockLog(StockLog log) async {
    try {
      await DBHelper.instance.insertStockLog(log);
      await loadProducts();
    } catch (e) {
      debugPrint('recordStockLog error: $e');
      rethrow;
    }
  }

  Future<List<ProductRecipe>> getProductRecipes(int serviceProductId) async {
    return DBHelper.instance.getProductRecipes(serviceProductId);
  }

  Future<void> replaceProductRecipes(
    int serviceProductId,
    List<ProductRecipe> recipes,
  ) async {
    await DBHelper.instance.replaceProductRecipes(serviceProductId, recipes);
  }
}

// ==============================
// CART PROVIDER
// ==============================
class HardwarePricingSettings {
  final bool roundUpToKg;

  const HardwarePricingSettings({this.roundUpToKg = false});

  HardwarePricingSettings copyWith({bool? roundUpToKg}) {
    return HardwarePricingSettings(
      roundUpToKg: roundUpToKg ?? this.roundUpToKg,
    );
  }

  bool appliesTo(Product product) =>
      product.isHardware == 1 || product.unit.trim().toLowerCase() == 'kg';

  double billableQtyFor(Product product, double qty) {
    if (!roundUpToKg || !appliesTo(product) || qty <= 0) return qty;
    return qty.ceilToDouble();
  }
}

final hardwarePricingSettingsProvider =
    NotifierProvider<HardwarePricingSettingsNotifier, HardwarePricingSettings>(
        HardwarePricingSettingsNotifier.new);

class HardwarePricingSettingsNotifier extends Notifier<HardwarePricingSettings> {
  static const _keyRoundUp = 'hardware_pricing_round_up_to_kg';

  @override
  HardwarePricingSettings build() {
    _load();
    return const HardwarePricingSettings();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    state = HardwarePricingSettings(
      roundUpToKg: prefs.getBool(_keyRoundUp) ?? false,
    );
  }

  Future<void> update(HardwarePricingSettings settings) async {
    state = settings;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyRoundUp, settings.roundUpToKg);
  }
}

final cartProvider =
    NotifierProvider<CartNotifier, Map<Product, double>>(() => CartNotifier());

class ProductPricingSnapshot {
  final int originalUnitPrice;
  final int finalUnitPrice;
  final Discount? appliedDiscount;
  final bool hasPriceOverride;

  const ProductPricingSnapshot({
    required this.originalUnitPrice,
    required this.finalUnitPrice,
    this.appliedDiscount,
    this.hasPriceOverride = false,
  });

  bool get hasPromo =>
      appliedDiscount != null && originalUnitPrice > finalUnitPrice;

  int get unitSavings => hasPromo ? originalUnitPrice - finalUnitPrice : 0;

  String get appliedDiscountName => appliedDiscount?.name.trim() ?? '';

  int get appliedDiscountIsPercentage => appliedDiscount?.isPercentage ?? 0;

  int get appliedDiscountValue => appliedDiscount?.nominal ?? 0;
}

class CartItemPriceOverride {
  final int unitPrice;

  const CartItemPriceOverride({
    required this.unitPrice,
  });
}

class CartNotifier extends Notifier<Map<Product, double>> {
  @override
  Map<Product, double> build() => {};

  bool addItem(Product p, {double qty = 1}) {
    if (p.isMaterial == 1) return false;
    final current = state[p] ?? 0;
    // For services/servis, stock might be infinite or handled differently.
    // If stock management is on, we still check.
    if (p.hasStockManagement == 1 && current + qty > p.stock) return false;

    final newQty = current + qty;
    state = {...state, p: newQty};
    return true;
  }

  bool setQty(Product p, double qty) {
    if (qty <= 0) {
      removeItem(p);
      return true;
    } else {
      if (p.isMaterial == 1) return false;
      if (p.hasStockManagement == 1 && qty > p.stock) return false;
      state = {...state, p: qty};
      return true;
    }
  }

  void removeItem(Product p) {
    final productId = p.id;
    if (productId != null) {
      ref.read(cartPriceOverridesProvider.notifier).removeOverride(productId);
    }
    final newState = Map<Product, double>.from(state)..remove(p);
    state = newState;
  }

  void clearCart() {
    ref.read(cartPriceOverridesProvider.notifier).clearOverrides();
    state = {};
  }

  int get totalBelanja {
    final allDiscounts = ref.read(discountsProvider);
    final hardwareSettings = ref.read(hardwarePricingSettingsProvider);
    final priceOverrides = ref.read(cartPriceOverridesProvider);
    int t = 0;
    for (var e in state.entries) {
      t += calculateLineSubtotal(
        e.key,
        e.value,
        allDiscounts,
        hardwareSettings,
        unitPriceOverride: _overrideUnitPriceFor(e.key, priceOverrides),
      );
    }
    return t;
  }

  static int calculateDiscountedPrice(
    Product p,
    double qty,
    List<Discount> allDiscounts, {
    HardwarePricingSettings hardwareSettings = const HardwarePricingSettings(),
    int? unitPriceOverride,
  }) {
    return resolveUnitPricing(
      p,
      qty,
      allDiscounts,
      hardwareSettings: hardwareSettings,
      unitPriceOverride: unitPriceOverride,
    ).finalUnitPrice;
  }

  static double billableQty(
    Product p,
    double qty,
    HardwarePricingSettings hardwareSettings,
  ) {
    return hardwareSettings.billableQtyFor(p, qty);
  }

  static int calculateLineSubtotal(
    Product p,
    double qty,
    List<Discount> allDiscounts,
    HardwarePricingSettings hardwareSettings, {
    int? unitPriceOverride,
  }) {
    final billable = billableQty(p, qty, hardwareSettings);
    final unitPrice = calculateDiscountedPrice(
      p,
      billable,
      allDiscounts,
      hardwareSettings: hardwareSettings,
      unitPriceOverride: unitPriceOverride,
    );
    return (unitPrice * billable).round();
  }

  static ProductPricingSnapshot resolveUnitPricing(
    Product p,
    double qty,
    List<Discount> allDiscounts, {
    DateTime? at,
    HardwarePricingSettings hardwareSettings = const HardwarePricingSettings(),
    int? unitPriceOverride,
  }) {
    final pricingQty = billableQty(p, qty, hardwareSettings);
    final price = p.getPrice(pricingQty);
    final now = at ?? DateTime.now();

    final activeDiscounts = allDiscounts.where((d) {
      final start = DateTime.tryParse(d.startDate);
      final end = DateTime.tryParse(d.endDate);
      if (start == null || end == null) return false;
      if (now.isBefore(start) || now.isAfter(end)) return false;

      final ids = d.productIds.split(',').map((id) => id.trim());
      return ids.contains(p.id.toString());
    }).toList();

    if (activeDiscounts.isEmpty) {
      final pricing = ProductPricingSnapshot(
        originalUnitPrice: price,
        finalUnitPrice: price,
      );
      if (unitPriceOverride == null) return pricing;
      return ProductPricingSnapshot(
        originalUnitPrice: pricing.finalUnitPrice,
        finalUnitPrice: unitPriceOverride,
        hasPriceOverride: true,
      );
    }

    int bestPrice = price;
    Discount? bestDiscount;
    for (var d in activeDiscounts) {
      int discounted;
      if (d.isPercentage == 1) {
        discounted = (price * (100 - d.nominal) / 100).round();
      } else {
        discounted = price - d.nominal;
      }
      if (discounted < bestPrice) {
        bestPrice = discounted;
        bestDiscount = d;
      }
    }

    final pricing = ProductPricingSnapshot(
      originalUnitPrice: price,
      finalUnitPrice: bestPrice,
      appliedDiscount: bestDiscount,
    );
    if (unitPriceOverride == null) return pricing;
    return ProductPricingSnapshot(
      originalUnitPrice: pricing.finalUnitPrice,
      finalUnitPrice: unitPriceOverride,
      hasPriceOverride: true,
    );
  }

  int get totalSavings {
    final allDiscounts = ref.read(discountsProvider);
    int s = 0;
    for (var e in state.entries) {
      final hardwareSettings = ref.read(hardwarePricingSettingsProvider);
      final pricing = resolveUnitPricing(
        e.key,
        e.value,
        allDiscounts,
        hardwareSettings: hardwareSettings,
      );
      s += (pricing.unitSavings * billableQty(e.key, e.value, hardwareSettings))
          .round();
    }
    return s;
  }

  int get totalItems {
    int c = 0;
    for (var qty in state.values) {
      c += qty.round();
    }
    return c;
  }
}

int? _overrideUnitPriceFor(
  Product product,
  Map<int, CartItemPriceOverride> priceOverrides,
) {
  final productId = product.id;
  if (productId == null) return null;
  return priceOverrides[productId]?.unitPrice;
}

// ==============================
// CART ITEM PRICE OVERRIDES
// ==============================
final cartPriceOverridesProvider = NotifierProvider<CartPriceOverridesNotifier,
    Map<int, CartItemPriceOverride>>(() => CartPriceOverridesNotifier());

class CartPriceOverridesNotifier
    extends Notifier<Map<int, CartItemPriceOverride>> {
  @override
  Map<int, CartItemPriceOverride> build() => {};

  void setOverride(int productId, int unitPrice) {
    if (unitPrice <= 0) {
      removeOverride(productId);
      return;
    }
    state = {
      ...state,
      productId: CartItemPriceOverride(unitPrice: unitPrice),
    };
  }

  void removeOverride(int productId) {
    if (!state.containsKey(productId)) return;
    final next = Map<int, CartItemPriceOverride>.from(state)..remove(productId);
    state = next;
  }

  void clearOverrides() {
    if (state.isEmpty) return;
    state = {};
  }
}

// ==============================
// CART ITEM NOTES PROVIDER
// ==============================
final cartItemNotesProvider =
    NotifierProvider<CartItemNotesNotifier, Map<int, String>>(
        () => CartItemNotesNotifier());

class CartItemNotesNotifier extends Notifier<Map<int, String>> {
  @override
  Map<int, String> build() => {};

  void setNote(int productId, String note) {
    if (note.trim().isEmpty) {
      final newState = Map<int, String>.from(state);
      newState.remove(productId);
      state = newState;
    } else {
      state = {...state, productId: note.trim()};
    }
  }

  void clearNotes() => state = {};
}

// ==============================
// DASHBOARD SUMMARY PROVIDER
// ==============================
class DashboardSummary {
  final int todaySales;
  final int todayProfit;
  final int todayCount;
  final int todaySoldItems;
  final double todayTotalWeight;
  final int todayUnpaid;
  final int todayCompleted;
  final int totalProducts;
  final int totalStockValue;
  final List<Product> lowStockProducts;
  final List<Map<String, dynamic>> topProducts;

  DashboardSummary({
    required this.todaySales,
    required this.todayProfit,
    required this.todayCount,
    required this.todaySoldItems,
    required this.todayTotalWeight,
    required this.todayUnpaid,
    required this.todayCompleted,
    required this.totalProducts,
    required this.totalStockValue,
    required this.lowStockProducts,
    required this.topProducts,
  });
}

final dashboardProvider = FutureProvider<DashboardSummary>((ref) async {
  ref.watch(productsProvider); // Re-compute setiap produk update
  ref.watch(transactionsProvider); // Re-compute every time transaction happens
  final db = DBHelper.instance;
  final todayStr = DateTime.now().toIso8601String().substring(0, 10);

  final daily = await db.getDailySummaryV3(todayStr);
  final soldItems = await db.getDailySoldQtyV3(todayStr);
  final totalWeight = await db.getDailyTotalWeight(todayStr);
  final products = await db.getAllProducts();
  final lowStock = await db.getLowStockProducts();
  final topProducts = await db.getTopSellingProducts(limit: 3);

  final totalStockValue =
      products.fold<int>(0, (s, p) => s + (p.stock * p.buyPrice));

  return DashboardSummary(
    todaySales: daily['sales'] ?? 0,
    todayProfit: daily['profit'] ?? 0,
    todayCount: daily['count'] ?? 0,
    todaySoldItems: soldItems,
    todayTotalWeight: totalWeight,
    todayUnpaid: daily['unpaid'] ?? 0,
    todayCompleted: daily['completed'] ?? 0,
    totalProducts: products.length,
    totalStockValue: totalStockValue,
    lowStockProducts: lowStock,
    topProducts: topProducts,
  );
});

// Period Grafik Dashboard (today, last_7_days, month, year)
final salesTrendPeriodProvider =
    NotifierProvider<SalesTrendPeriodNotifier, String>(
        () => SalesTrendPeriodNotifier());

class SalesTrendPeriodNotifier extends Notifier<String> {
  @override
  String build() => 'last_7_days';
  void set(String val) => state = val;
}

// Provider untuk data grafik penjualan dinamis
final salesTrendProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async {
  ref.watch(transactionsProvider);
  final period = ref.watch(salesTrendPeriodProvider);
  return await DBHelper.instance.getSalesTrendData(period);
});

// Backward compatibility untuk WeeklySalesChart (opsional jika masih ada yang pakai)
final weeklySalesProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async {
  return ref.watch(salesTrendProvider.future);
});

// Provider untuk data performa kategori
final categorySalesProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async {
  ref.watch(transactionsProvider);
  return await DBHelper.instance.getCategorySalesStatistics();
});

// ==============================
// SALES REPORT PROVIDER
// ==============================
class SalesReport {
  final int totalSalesRp;
  final int totalProfitRp;
  final int transactionCount;
  final List<Map<String, dynamic>> perProductBreakdown;

  SalesReport({
    required this.totalSalesRp,
    required this.totalProfitRp,
    required this.transactionCount,
    this.perProductBreakdown = const [],
  });
}

// Period provider pakai Notifier bukan StateProvider (kompatibel semua versi Riverpod 2)
final reportPeriodProvider =
    NotifierProvider<ReportPeriodNotifier, int>(() => ReportPeriodNotifier());

class ReportPeriodNotifier extends Notifier<int> {
  @override
  int build() => 7; // Default 7 hari

  void setPeriod(int days) => state = days;
}

final salesReportProvider = FutureProvider<SalesReport>((ref) async {
  ref.watch(productsProvider);
  final days = ref.watch(reportPeriodProvider);

  final result = await DBHelper.instance.getSalesByPeriod(days: days);
  if (result.isEmpty) {
    return SalesReport(totalSalesRp: 0, totalProfitRp: 0, transactionCount: 0);
  }

  final summary = result.first;
  final breakdown = result.length > 1 ? result.sublist(1) : [];
  return SalesReport(
    totalSalesRp: summary['total_sales'] as int,
    totalProfitRp: summary['total_profit'] as int,
    transactionCount: summary['count'] as int,
    perProductBreakdown: breakdown.cast<Map<String, dynamic>>(),
  );
});

// ==============================
// AI SERVICE PROVIDER
// ==============================
final aiServiceProvider = Provider<AISimpleService>((ref) => AISimpleService());

final insightsProvider =
    FutureProvider<Map<String, List<Product>>>((ref) async {
  ref.watch(productsProvider);
  ref.watch(transactionsProvider);
  return ref.read(aiServiceProvider).getInsights();
});

final aiBusinessSnapshotProvider =
    FutureProvider<AiBusinessSnapshot>((ref) async {
  ref.watch(productsProvider);
  ref.watch(transactionsProvider);
  return ref.read(aiServiceProvider).getBusinessSnapshot();
});

// ==============================
// CUSTOMERS PROVIDER
// ==============================
final customersProvider = NotifierProvider<CustomersNotifier, List<Customer>>(
    () => CustomersNotifier());

class CustomersNotifier extends Notifier<List<Customer>> {
  @override
  List<Customer> build() {
    loadCustomers();
    return [];
  }

  Future<void> loadCustomers() async {
    try {
      state = await DBHelper.instance.getAllCustomers();
    } catch (e) {
      debugPrint('loadCustomers error: $e');
    }
  }

  Future<void> addCustomer(Customer c) async {
    try {
      await DBHelper.instance.insertCustomer(c);
      await loadCustomers();
    } catch (e) {
      debugPrint('addCustomer error: $e');
      rethrow;
    }
  }

  Future<void> updateCustomer(Customer c) async {
    try {
      await DBHelper.instance.updateCustomer(c);
      await loadCustomers();
      await ref.read(transactionsProvider.notifier).loadTransactions();
    } catch (e) {
      debugPrint('updateCustomer error: $e');
      rethrow;
    }
  }

  Future<void> deleteCustomer(int id, {bool pinVerified = false}) async {
    if (!pinVerified) {
      throw StateError('PIN admin wajib diverifikasi sebelum hapus pelanggan.');
    }

    try {
      final customer = await DBHelper.instance.getCustomerById(id);
      final transactionCount =
          await DBHelper.instance.getCustomerTransactionCount(id);
      await DBHelper.instance.deleteCustomer(id);
      final staff = ref.read(activeStaffProvider);
      final customerName = customer?.name ?? 'ID $id';
      await DBHelper.instance.insertAuditLog(
        AuditLog(
          action: 'customer_deleted',
          entityType: 'customer',
          entityId: id,
          staffId: staff?.id,
          staffName: staff?.name ?? 'Admin/Owner',
          staffRole: staff?.role ?? 'Admin',
          note:
              'Pelanggan "$customerName" dihapus dari master pelanggan. $transactionCount transaksi lama tetap tersimpan.',
          metadataJson: jsonEncode({
            'customer_id': id,
            'customer_name': customer?.name,
            'customer_phone': customer?.phone,
            'transaction_count': transactionCount,
            'authorized_by': 'admin_pin',
          }),
          createdAt: DateTime.now().toIso8601String(),
        ),
      );
      ref.invalidate(auditLogsProvider);
      await loadCustomers();
      await ref.read(transactionsProvider.notifier).loadTransactions();
    } catch (e) {
      debugPrint('deleteCustomer error: $e');
      rethrow;
    }
  }
}

// ==============================
// EMPLOYEES PROVIDER
// ==============================
final employeesProvider = NotifierProvider<EmployeesNotifier, List<Employee>>(
    () => EmployeesNotifier());

class EmployeesNotifier extends Notifier<List<Employee>> {
  @override
  List<Employee> build() {
    loadEmployees();
    return [];
  }

  Future<void> loadEmployees() async {
    try {
      state = await DBHelper.instance.getAllEmployees();
    } catch (e) {
      debugPrint('loadEmployees error: $e');
    }
  }

  Future<void> addEmployee(Employee e) async {
    try {
      await DBHelper.instance.insertEmployee(e);
      await loadEmployees();
    } catch (err) {
      debugPrint('addEmployee error: $err');
      rethrow;
    }
  }

  Future<void> updateEmployee(Employee e) async {
    try {
      await DBHelper.instance.updateEmployee(e);
      await loadEmployees();
    } catch (err) {
      debugPrint('updateEmployee error: $err');
      rethrow;
    }
  }

  Future<void> deleteEmployee(int id) async {
    try {
      await DBHelper.instance.deleteEmployee(id);
      await loadEmployees();
    } catch (e) {
      debugPrint('deleteEmployee error: $e');
      rethrow;
    }
  }
}

// ==============================
// STAFF SESSION PROVIDERS
// ==============================

/// Tracks whether the staff session has been restored from SharedPreferences.
/// This prevents the StaffTerminalScreen from flashing briefly on app restart.
final staffSessionRestoredProvider =
    NotifierProvider<StaffSessionRestoredNotifier, bool>(
        () => StaffSessionRestoredNotifier());

class StaffSessionRestoredNotifier extends Notifier<bool> {
  @override
  bool build() => false;
  void markRestored() => state = true;
}

class ActiveStaffNotifier extends Notifier<Employee?> {
  static const _staffSessionKey = 'active_staff_session';

  @override
  Employee? build() {
    // Restore session from SharedPreferences when app starts
    // This runs in the background and updates state when complete
    Future.microtask(() => _restoreSession());
    return null;
  }

  /// Restore staff session from SharedPreferences
  Future<void> _restoreSession() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final sessionData = prefs.getString(_staffSessionKey);

      if (sessionData != null && sessionData.isNotEmpty) {
        final Map<String, dynamic> data = jsonDecode(sessionData);
        final staff = Employee(
          id: data['id'] as int?,
          name: data['name'] as String? ?? '',
          role: data['role'] as String? ?? '',
          phone: data['phone'] as String? ?? '',
          pin: data['pin'] as String?,
          permissionsJson: data['permissionsJson'] as String?,
          createdAt:
              data['createdAt'] as String? ?? DateTime.now().toIso8601String(),
        );
        state = staff;
      }
    } catch (e) {
      debugPrint('ActiveStaffNotifier _restoreSession error: $e');
    }
    // Mark session restoration as complete regardless of outcome
    ref.read(staffSessionRestoredProvider.notifier).markRestored();
  }

  /// Set active staff and save to SharedPreferences
  Future<void> set(Employee? staff) async {
    try {
      state = staff;
      final prefs = await SharedPreferences.getInstance();

      if (staff != null) {
        // Save staff data as JSON
        final data = {
          'id': staff.id,
          'name': staff.name,
          'role': staff.role,
          'phone': staff.phone,
          'pin': staff.pin,
          'permissionsJson': staff.permissionsJson,
          'createdAt': staff.createdAt,
        };
        await prefs.setString(_staffSessionKey, jsonEncode(data));
      } else {
        // Clear session on logout
        await prefs.remove(_staffSessionKey);
      }
    } catch (e) {
      debugPrint('ActiveStaffNotifier set error: $e');
    }
  }

  /// Logout - clear the active staff session
  Future<void> logout() async {
    try {
      state = null;
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_staffSessionKey);
    } catch (e) {
      debugPrint('ActiveStaffNotifier logout error: $e');
    }
  }
}

final activeStaffProvider = NotifierProvider<ActiveStaffNotifier, Employee?>(
    () => ActiveStaffNotifier());

class SelectedStaffForPinNotifier extends Notifier<Employee?> {
  @override
  Employee? build() => null;
  void set(Employee? staff) => state = staff;
}

final selectedStaffForPinProvider =
    NotifierProvider<SelectedStaffForPinNotifier, Employee?>(
        () => SelectedStaffForPinNotifier());

// ==============================
// servis WORKSHOP PROVIDERS
// ==============================
final selectedservisOrderStationProvider =
    NotifierProvider<SelectedservisOrderStationNotifier, servisStation?>(
        () => SelectedservisOrderStationNotifier());

class SelectedservisOrderStationNotifier extends Notifier<servisStation?> {
  @override
  servisStation? build() => null;

  void set(servisStation? table) => state = table;
}

final servisStationsProvider =
    NotifierProvider<servisStationsNotifier, List<servisStation>>(
        () => servisStationsNotifier());

class servisStationsNotifier extends Notifier<List<servisStation>> {
  @override
  List<servisStation> build() {
    loadTables();
    return [];
  }

  Future<void> loadTables() async {
    try {
      state = await DBHelper.instance.getservisStations();
    } catch (e) {
      debugPrint('loadservisStations error: $e');
    }
  }

  Future<void> addTable({
    required String name,
    required String area,
    required int seats,
  }) async {
    final nowIso = DateTime.now().toIso8601String();
    final normalized = '${area.trim()}-${name.trim()}'
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9]+'), '-')
        .replaceAll(RegExp(r'^-+|-+$'), '');
    await DBHelper.instance.insertservisStation(
      servisStation(
        name: name.trim(),
        area: area.trim().isEmpty ? 'Ruang Utama' : area.trim(),
        seats: seats.clamp(1, 99).toInt(),
        qrSlug: normalized.isEmpty
            ? 'meja-${DateTime.now().millisecondsSinceEpoch}'
            : normalized,
        sortOrder: state.length + 1,
        updatedAt: nowIso,
      ),
    );
    await loadTables();
  }

  Future<void> updateStatus(servisStation table, String status) async {
    if (table.id == null) return;
    await DBHelper.instance.updateservisStationStatus(table.id!, status);
    await loadTables();
  }

  Future<void> mergeTables(servisStation source, servisStation target) async {
    if (source.id == null || target.id == null || source.id == target.id) {
      return;
    }
    await DBHelper.instance.mergeservisStations(
      sourceTableId: source.id!,
      targetTableId: target.id!,
    );
    await loadTables();
  }
}

final servisWorkshopTicketsProvider = NotifierProvider<
    servisWorkshopTicketsNotifier,
    List<servisWorkshopTicket>>(() => servisWorkshopTicketsNotifier());

class servisWorkshopTicketsNotifier
    extends Notifier<List<servisWorkshopTicket>> {
  StreamSubscription? _signalSub;

  @override
  List<servisWorkshopTicket> build() {
    loadTickets();

    // Listen for real-time update signals (Lightweight & Battery Efficient)
    final net = POSNetworkService.instance;
    _signalSub = net.updateSignalStream.listen((_) {
      loadTickets();
    });

    ref.onDispose(() => _signalSub?.cancel());

    return [];
  }

  Future<void> loadTickets({bool includeDone = false}) async {
    try {
      final net = POSNetworkService.instance;
      if (net.mode == POSNetworkMode.terminal && net.masterIp != null) {
        final newTickets = await net.fetchWorkshopTickets();

        // Check for new tickets to show notification
        if (state.isNotEmpty && newTickets.length > state.length) {
          // Compare IDs to find truly new ones
          final existingIds = state.map((t) => t.id).toSet();
          final freshTickets =
              newTickets.where((t) => !existingIds.contains(t.id)).toList();

          if (freshTickets.isNotEmpty) {
            for (final t in freshTickets) {
              LocalNotificationService.show(
                id: t.id ?? DateTime.now().millisecondsSinceEpoch % 100000,
                title: 'Pesanan Baru: ${t.tableName}',
                body: 'Tipe: ${t.orderType} - Segera proses di Workshop!',
              );
            }
          }
        }

        state = newTickets;
        return;
      }
      state = await DBHelper.instance
          .getservisWorkshopTickets(includeDone: includeDone);
    } catch (e) {
      debugPrint('loadservisWorkshopTickets error: $e');
    }
  }

  Future<void> updateStatus(servisWorkshopTicket ticket, String status) async {
    if (ticket.id == null) return;

    final net = POSNetworkService.instance;
    if (net.mode == POSNetworkMode.terminal && net.masterIp != null) {
      await net.updateWorkshopStatus(ticket.id!, status);
    }

    await DBHelper.instance
        .updateservisWorkshopTicketStatus(ticket.id!, status);
    await loadTickets();
  }
}

// ==============================
// WALLET PROVIDER
// ==============================
final financeRealtimeProvider = NotifierProvider<FinanceRealtimeNotifier, int>(
    () => FinanceRealtimeNotifier());

class FinanceRealtimeNotifier extends Notifier<int> {
  @override
  int build() => 0;

  void markChanged() => state++;
}

final walletBalanceProvider = FutureProvider<int>((ref) async {
  ref.watch(financeRealtimeProvider);
  return DBHelper.instance.getWalletBalance();
});

final walletTransactionsProvider =
    FutureProvider<List<WalletTransaction>>((ref) async {
  ref.watch(financeRealtimeProvider);
  ref.watch(walletBalanceProvider);
  return DBHelper.instance.getAllWalletTransactions();
});

final financeCategoriesProvider =
    NotifierProvider<FinanceCategoriesNotifier, List<FinanceCategory>>(
        () => FinanceCategoriesNotifier());

class FinanceCategoriesNotifier extends Notifier<List<FinanceCategory>> {
  @override
  List<FinanceCategory> build() {
    loadCategories();
    return [];
  }

  Future<void> loadCategories({bool includeInactive = true}) async {
    try {
      state = await DBHelper.instance.getFinanceCategories(
        includeInactive: includeInactive,
      );
    } catch (e) {
      debugPrint('loadFinanceCategories error: $e');
    }
  }

  List<FinanceCategory> byType(String type, {bool includeInactive = false}) {
    final normalizedType = type == 'masuk' ? 'masuk' : 'keluar';
    return state
        .where((category) =>
            category.type == normalizedType &&
            (includeInactive || category.active))
        .toList()
      ..sort((a, b) {
        final activeCompare = b.isActive.compareTo(a.isActive);
        if (activeCompare != 0) return activeCompare;
        final sortCompare = a.sortOrder.compareTo(b.sortOrder);
        if (sortCompare != 0) return sortCompare;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });
  }

  Future<int> addCategory({
    required String name,
    required String type,
    required String iconKey,
    required String colorHex,
  }) async {
    final now = DateTime.now().toIso8601String();
    final id = await DBHelper.instance.insertFinanceCategory(FinanceCategory(
      name: name.trim(),
      type: type == 'masuk' ? 'masuk' : 'keluar',
      iconKey: iconKey,
      colorHex: colorHex,
      sortOrder: 700,
      createdAt: now,
      updatedAt: now,
    ));
    await loadCategories();
    ref.read(financeRealtimeProvider.notifier).markChanged();
    ref.invalidate(walletTransactionsProvider);
    return id;
  }

  Future<void> updateCategory(FinanceCategory category) async {
    await DBHelper.instance.updateFinanceCategory(category);
    await loadCategories();
    ref.read(financeRealtimeProvider.notifier).markChanged();
    ref.invalidate(walletTransactionsProvider);
  }

  Future<void> setActive(FinanceCategory category, bool active) async {
    final id = category.id;
    if (id == null) return;
    await DBHelper.instance.setFinanceCategoryActive(id, active);
    await loadCategories();
    ref.read(financeRealtimeProvider.notifier).markChanged();
    ref.invalidate(walletTransactionsProvider);
  }
}

class ShellBadgeCounts {
  final int activeservisCount;
  final int pendingUnpaidCount;

  const ShellBadgeCounts({
    this.activeservisCount = 0,
    this.pendingUnpaidCount = 0,
  });
}

final shellBadgeCountsProvider =
    NotifierProvider<ShellBadgeCountsNotifier, ShellBadgeCounts>(
        ShellBadgeCountsNotifier.new);

class ShellBadgeCountsNotifier extends Notifier<ShellBadgeCounts> {
  @override
  ShellBadgeCounts build() {
    Future.microtask(refresh);
    return const ShellBadgeCounts();
  }

  Future<void> refresh() async {
    try {
      final activeservis =
          await DBHelper.instance.countActiveservisTransactions();
      final pendingUnpaid =
          await DBHelper.instance.countPendingUnpaidTransactions();
      if (!ref.mounted) return;
      state = ShellBadgeCounts(
        activeservisCount: activeservis,
        pendingUnpaidCount: pendingUnpaid,
      );
    } catch (e) {
      debugPrint('refresh shell badges error: $e');
    }
  }

  void updateFromTransactions(List<Transaction> transactions) {
    final activeservis = transactions.where((t) {
      final status = t.servisStatus.trim();
      return t.isDeleted == 0 && status.isNotEmpty && status != 'Selesai';
    }).length;
    final pendingUnpaid = transactions
        .where((t) => t.isDeleted == 0 && t.amountPaid < t.grandTotal)
        .length;
    state = ShellBadgeCounts(
      activeservisCount: activeservis,
      pendingUnpaidCount: pendingUnpaid,
    );
  }
}

final transactionsProvider =
    NotifierProvider<TransactionsNotifier, List<Transaction>>(
        () => TransactionsNotifier());

class _servisServiceProfile {
  final String fulfillmentType;
  final String serviceLevel;
  final int slaHours;

  const _servisServiceProfile({
    required this.fulfillmentType,
    required this.serviceLevel,
    required this.slaHours,
  });
}

_servisServiceProfile _resolveservisServiceProfile({
  required Map<Product, double> cartItems,
  required DateTime createdAt,
  String? orderType,
  String? pickupSchedule,
}) {
  final fulfillmentType = _normalizeFulfillmentType(orderType);
  final productProfiles = cartItems.keys.map(_profileFromProduct).toList();
  productProfiles.sort((a, b) {
    final aPriority = a.serviceLevel == 'Regular' ? 1 : 0;
    final bPriority = b.serviceLevel == 'Regular' ? 1 : 0;
    if (aPriority != bPriority) return aPriority.compareTo(bPriority);
    final aHours = a.slaHours <= 0 ? 99999 : a.slaHours;
    final bHours = b.slaHours <= 0 ? 99999 : b.slaHours;
    return aHours.compareTo(bHours);
  });

  final best = productProfiles.isEmpty
      ? const _servisServiceProfile(
          fulfillmentType: 'Ambil Sendiri',
          serviceLevel: 'Regular',
          slaHours: 0,
        )
      : productProfiles.first;

  final pickupAt =
      pickupSchedule == null ? null : DateTime.tryParse(pickupSchedule);
  final pickupSlaHours = pickupAt == null
      ? 0
      : pickupAt.difference(createdAt).inMinutes <= 0
          ? 0
          : (pickupAt.difference(createdAt).inMinutes / 60).ceil();

  final serviceLevel = best.serviceLevel != 'Regular'
      ? best.serviceLevel
      : pickupSlaHours > 0 && pickupSlaHours <= 8
          ? 'Express'
          : 'Regular';
  final slaHours = best.slaHours > 0
      ? best.slaHours
      : pickupSlaHours > 0
          ? pickupSlaHours
          : 0;

  return _servisServiceProfile(
    fulfillmentType: fulfillmentType,
    serviceLevel: serviceLevel,
    slaHours: slaHours,
  );
}

_servisServiceProfile _profileFromProduct(Product product) {
  final lower = product.name.toLowerCase();
  final hourMatch = RegExp(r'(\d+)\s*jam').firstMatch(lower);
  final parsedHours =
      hourMatch == null ? 0 : int.tryParse(hourMatch.group(1) ?? '') ?? 0;
  final slaHours =
      product.durationHours > 0 ? product.durationHours : parsedHours;

  String serviceLevel = 'Regular';
  if (lower.contains('prioritas')) {
    serviceLevel = 'Prioritas';
  } else if (lower.contains('express')) {
    serviceLevel = 'Express';
  } else if (lower.contains('kilat')) {
    serviceLevel = 'Kilat';
  } else if (lower.contains('cepat')) {
    serviceLevel = 'Cepat';
  } else if (slaHours > 0 && slaHours <= 8) {
    serviceLevel = 'Express';
  }

  return _servisServiceProfile(
    fulfillmentType: 'Ambil Sendiri',
    serviceLevel: serviceLevel,
    slaHours: slaHours,
  );
}

String _normalizeFulfillmentType(String? orderType) {
  final value = orderType?.trim();
  if (value == null || value.isEmpty) return 'Ambil Sendiri';
  final lower = value.toLowerCase();
  if (lower.contains('antar') ||
      lower.contains('delivery') ||
      lower.contains('pickup') ||
      lower.contains('jemput')) {
    return 'Antar/Jemput';
  }
  if (lower.contains('ambil')) return 'Ambil Sendiri';
  return value;
}

class TransactionsNotifier extends Notifier<List<Transaction>> {
  @override
  List<Transaction> build() {
    loadTransactions();
    return [];
  }

  Future<void> loadTransactions() async {
    try {
      final net = POSNetworkService.instance;
      if (net.mode == POSNetworkMode.terminal && net.masterIp != null) {
        state = await net.fetchTransactions();
        ref
            .read(shellBadgeCountsProvider.notifier)
            .updateFromTransactions(state);
        return;
      }
      state = await DBHelper.instance.getAllTransactions();
      ref.read(shellBadgeCountsProvider.notifier).updateFromTransactions(state);
    } catch (e) {
      debugPrint('loadTransactions error: $e');
    }
  }

  Future<int> createTransaction({
    required Map<Product, double> cartItems,
    Customer? customer,
    String? customerName, // nama ketik manual (fallback jika customer null)
    int discountAmount = 0,
    int additionalCharges = 0,
    List<Map<String, dynamic>>? additionalChargesList,
    required String paymentMethod,
    required int amountPaid,
    String? note,
    Map<int, String>? itemNotes,
    String? orderType,
    String? pickupSchedule,
    String? paymentStatus,
    String? servisStatus,
    String? kelengkapan,
    String? address,
    DateTime? dueDate,
    int? servisStationId,
    String? servisStationName,
    bool sendToWorkshop = false,
    DateTime? transactionDate,
  }) async {
    try {
      final allDiscounts = ref.read(discountsProvider);
      final hardwareSettings = ref.read(hardwarePricingSettingsProvider);
      final priceOverrides = ref.read(cartPriceOverridesProvider);
      final totalAmount = cartItems.entries.fold<int>(0, (s, e) {
        return s +
            CartNotifier.calculateLineSubtotal(
              e.key,
              e.value,
              allDiscounts,
              hardwareSettings,
              unitPriceOverride: _overrideUnitPriceFor(e.key, priceOverrides),
            );
      });
      final grandTotal = (totalAmount - discountAmount + additionalCharges)
          .clamp(0, totalAmount + additionalCharges);
      final changeAmount = amountPaid - grandTotal;

      // Serialize charges list to JSON
      String? chargesJson;
      if (additionalChargesList != null && additionalChargesList.isNotEmpty) {
        chargesJson = jsonEncode(additionalChargesList);
      }

      // Auto-mark as Lunas if full payment
      String finalStatus =
          paymentStatus ?? (amountPaid >= grandTotal ? "Lunas" : "Belum Lunas");
      if (amountPaid >= grandTotal) {
        finalStatus = "Lunas";
      }

      // Resolusi nama: prioritas Customer objek, fallback ke nama manual
      final resolvedCustomerName = customer?.name ??
          (customerName != null && customerName.trim().isNotEmpty
              ? customerName.trim()
              : null);
      final transactionCreatedAt = transactionDate ?? DateTime.now();
      final serviceProfile = _resolveservisServiceProfile(
        cartItems: cartItems,
        createdAt: transactionCreatedAt,
        orderType: orderType,
        pickupSchedule: pickupSchedule,
      );

      final tx = Transaction(
        customerId: customer?.id,
        customerName: resolvedCustomerName,
        totalAmount: totalAmount,
        discountAmount: discountAmount,
        additionalCharges: additionalCharges,
        additionalChargesJson: chargesJson,
        grandTotal: grandTotal,
        paymentMethod: paymentMethod,
        amountPaid: amountPaid,
        changeAmount: changeAmount > 0 ? changeAmount : 0,
        note: note,
        createdAt: transactionCreatedAt.toIso8601String(),
        orderType: orderType,
        pickupSchedule: pickupSchedule,
        fulfillmentType: serviceProfile.fulfillmentType,
        serviceLevel: serviceProfile.serviceLevel,
        slaHours: serviceProfile.slaHours,
        paymentStatus: finalStatus,
        servisStatus: servisStatus ?? 'Diterima',
        kelengkapan: kelengkapan,
        address: address,
        dueDate: dueDate?.toIso8601String(),
      );

      final Map<int, String> itemNotesMap =
          itemNotes ?? ref.read(cartItemNotesProvider);
      final items = cartItems.entries.map((e) {
        final billableQty =
            CartNotifier.billableQty(e.key, e.value, hardwareSettings);
        final overrideUnitPrice = _overrideUnitPriceFor(e.key, priceOverrides);
        final normalPricing = CartNotifier.resolveUnitPricing(
          e.key,
          e.value,
          allDiscounts,
          hardwareSettings: hardwareSettings,
        );
        final pricing = CartNotifier.resolveUnitPricing(
          e.key,
          e.value,
          allDiscounts,
          hardwareSettings: hardwareSettings,
          unitPriceOverride: overrideUnitPrice,
        );
        final hasPriceOverride = overrideUnitPrice != null &&
            overrideUnitPrice != normalPricing.finalUnitPrice;
        final unitPrice = pricing.finalUnitPrice;
        final subtotal = (unitPrice * billableQty).round();
        final originalUnitPrice = hasPriceOverride
            ? normalPricing.finalUnitPrice
            : pricing.originalUnitPrice;
        final originalSubtotal = (originalUnitPrice * billableQty).round();
        final priceOverrideAmount =
            hasPriceOverride ? originalSubtotal - subtotal : 0;
        return TransactionItem(
          transactionId: 0, // will be set by DB
          productId: e.key.id!,
          productName: e.key.name,
          qty: e.value,
          unitPrice: unitPrice,
          originalUnitPrice: originalUnitPrice,
          originalSubtotal: originalSubtotal,
          priceOverrideAmount: priceOverrideAmount,
          subtotal: subtotal,
          note: itemNotesMap[e.key.id!],
          appliedDiscountName:
              hasPriceOverride || pricing.appliedDiscountName.isEmpty
                  ? null
                  : pricing.appliedDiscountName,
          appliedDiscountIsPercentage:
              hasPriceOverride ? 0 : pricing.appliedDiscountIsPercentage,
          appliedDiscountValue:
              hasPriceOverride ? 0 : pricing.appliedDiscountValue,
          isPriceOverride: hasPriceOverride ? 1 : 0,
          unit: e.key.unit,
          isHardware: e.key.isHardware,
        );
      }).toList();

      final net = POSNetworkService.instance;
      if (net.mode == POSNetworkMode.terminal) {
        final syncedId = await net.sendOrder(
          transaction: tx,
          items: items,
          servisStationId: servisStationId,
          servisStationName: servisStationName,
        );
        ref.read(cartItemNotesProvider.notifier).clearNotes();
        ref.read(cartPriceOverridesProvider.notifier).clearOverrides();
        ref.read(selectedservisOrderStationProvider.notifier).set(null);
        await loadTransactions();
        return syncedId ?? 0;
      }

      // Save transaction + stock changes in a single DB transaction.
      final txPrefix = ref.read(transactionSettingsProvider).prefix;
      final txId = await DBHelper.instance
          .insertTransaction(tx, items, transactionPrefix: txPrefix);

      final staff = ref.read(activeStaffProvider);
      final staffName = staff?.name ?? 'Kasir';
      await DBHelper.instance.insertAuditLog(AuditLog(
        action: 'transaction_created',
        entityType: 'transaction',
        entityId: txId,
        staffId: staff?.id,
        staffName: staffName,
        staffRole: staff?.role ?? '',
        amount: grandTotal,
        note:
            'Order servis dibuat${resolvedCustomerName == null ? '' : ' untuk $resolvedCustomerName'}',
        metadataJson: jsonEncode({
          'payment_method': paymentMethod,
          'payment_status': finalStatus,
          'servis_status': servisStatus ?? 'Diterima',
          'order_type': orderType,
          'fulfillment_type': serviceProfile.fulfillmentType,
          'service_level': serviceProfile.serviceLevel,
          'sla_hours': serviceProfile.slaHours,
          'pickup_schedule': pickupSchedule,
          'item_count': cartItems.length,
        }),
        createdAt: DateTime.now().toIso8601String(),
      ));
      if (discountAmount > 0) {
        await DBHelper.instance.insertAuditLog(AuditLog(
          action: 'discount_applied',
          entityType: 'transaction',
          entityId: txId,
          staffId: staff?.id,
          staffName: staffName,
          staffRole: staff?.role ?? '',
          amount: discountAmount,
          note: 'Diskon order servis diberikan',
          createdAt: DateTime.now().toIso8601String(),
        ));
      }
      final priceOverrideCount =
          items.where((item) => item.hasPriceOverride).length;
      final totalPriceOverrideAmount = items.fold<int>(
        0,
        (sum, item) => sum + item.effectivePriceOverrideAmount,
      );
      if (priceOverrideCount > 0) {
        await DBHelper.instance.insertAuditLog(AuditLog(
          action: 'price_override_applied',
          entityType: 'transaction',
          entityId: txId,
          staffId: staff?.id,
          staffName: staffName,
          staffRole: staff?.role ?? '',
          amount: totalPriceOverrideAmount,
          note:
              '$priceOverrideCount item memakai harga nego pada order servis.',
          metadataJson: jsonEncode({
            'item_count': priceOverrideCount,
            'price_override_amount': totalPriceOverrideAmount,
          }),
          createdAt: DateTime.now().toIso8601String(),
        ));
      }

      final tableName = servisStationName?.trim();
      final shouldCreateWorkshopTicket = sendToWorkshop ||
          servisStationId != null ||
          (tableName?.isNotEmpty == true);
      if (shouldCreateWorkshopTicket) {
        final nowIso = DateTime.now().toIso8601String();
        await DBHelper.instance.insertservisWorkshopTicket(
          servisWorkshopTicket(
            transactionId: txId,
            tableName: tableName?.isNotEmpty == true
                ? tableName!
                : (resolvedCustomerName ?? 'Pelanggan Umum'),
            customerName: resolvedCustomerName,
            orderType: orderType ?? 'Ambil Sendiri',
            status: 'queued',
            station: 'Workshop',
            note: note,
            createdAt: nowIso,
            updatedAt: nowIso,
          ),
        );
        if (servisStationId != null) {
          await DBHelper.instance.assignservisStationToTransaction(
            stationId: servisStationId,
            transactionId: txId,
          );
        }
        if (finalStatus == "Lunas") {
          await DBHelper.instance.releaseservisStationByTransactionId(txId);
        }
      }

      // Clear notes after successful transaction
      ref.read(cartItemNotesProvider.notifier).clearNotes();
      ref.read(cartPriceOverridesProvider.notifier).clearOverrides();
      if (shouldCreateWorkshopTicket) {
        ref.read(selectedservisOrderStationProvider.notifier).set(null);
        await ref.read(servisStationsProvider.notifier).loadTables();
        await ref.read(servisWorkshopTicketsProvider.notifier).loadTickets();
      }

      await ref.read(productsProvider.notifier).loadProducts();
      await loadTransactions();
      _invalidateHistory();

      // Schedule servis reminder if pickupSchedule is set
      if (pickupSchedule != null) {
        try {
          final scheduledDate = DateTime.tryParse(pickupSchedule);
          if (scheduledDate != null) {
            final createdTx = await DBHelper.instance.getTransactionById(txId);
            if (createdTx != null) {
              await LocalNotificationService.scheduleservisReminder(
                transactionId: txId,
                customerName: createdTx.customerName ?? 'Pelanggan',
                transactionCode: createdTx.transactionCode ?? txId.toString(),
                scheduledDate: scheduledDate,
              );
            }
          }
        } catch (e) {
          debugPrint('Error scheduling servis reminder: $e');
        }
      }

      return txId;
    } catch (e) {
      debugPrint('createTransaction error: $e');
      rethrow;
    }
  }

  Future<void> mergeTransaction({
    required int existingTxId,
    required Map<Product, double> cartItems,
    required int additionalTotalAmount,
    required int additionalGrandTotal,
    Map<int, String>? itemNotes,
  }) async {
    try {
      final Map<int, String> itemNotesMap =
          itemNotes ?? ref.read(cartItemNotesProvider);
      final allDiscounts = ref.read(discountsProvider);
      final hardwareSettings = ref.read(hardwarePricingSettingsProvider);
      final priceOverrides = ref.read(cartPriceOverridesProvider);
      final items = cartItems.entries.map((e) {
        final billableQty =
            CartNotifier.billableQty(e.key, e.value, hardwareSettings);
        final overrideUnitPrice = _overrideUnitPriceFor(e.key, priceOverrides);
        final normalPricing = CartNotifier.resolveUnitPricing(
          e.key,
          e.value,
          allDiscounts,
          hardwareSettings: hardwareSettings,
        );
        final pricing = CartNotifier.resolveUnitPricing(
          e.key,
          e.value,
          allDiscounts,
          hardwareSettings: hardwareSettings,
          unitPriceOverride: overrideUnitPrice,
        );
        final hasPriceOverride = overrideUnitPrice != null &&
            overrideUnitPrice != normalPricing.finalUnitPrice;
        final unitPrice = pricing.finalUnitPrice;
        final subtotal = (unitPrice * billableQty).round();
        final originalUnitPrice = hasPriceOverride
            ? normalPricing.finalUnitPrice
            : pricing.originalUnitPrice;
        final originalSubtotal = (originalUnitPrice * billableQty).round();
        final priceOverrideAmount =
            hasPriceOverride ? originalSubtotal - subtotal : 0;
        return TransactionItem(
          transactionId: existingTxId,
          productId: e.key.id!,
          productName: e.key.name,
          qty: e.value,
          unitPrice: unitPrice,
          originalUnitPrice: originalUnitPrice,
          originalSubtotal: originalSubtotal,
          priceOverrideAmount: priceOverrideAmount,
          subtotal: subtotal,
          note: itemNotesMap[e.key.id!],
          appliedDiscountName:
              hasPriceOverride || pricing.appliedDiscountName.isEmpty
                  ? null
                  : pricing.appliedDiscountName,
          appliedDiscountIsPercentage:
              hasPriceOverride ? 0 : pricing.appliedDiscountIsPercentage,
          appliedDiscountValue:
              hasPriceOverride ? 0 : pricing.appliedDiscountValue,
          isPriceOverride: hasPriceOverride ? 1 : 0,
          unit: e.key.unit,
          isHardware: e.key.isHardware,
        );
      }).toList();

      final net = POSNetworkService.instance;
      if (net.mode == POSNetworkMode.terminal) {
        await net.mergeTransaction(
          existingTxId: existingTxId,
          items: items,
          additionalTotalAmount: additionalTotalAmount,
          additionalGrandTotal: additionalGrandTotal,
        );
        ref.read(cartItemNotesProvider.notifier).clearNotes();
        ref.read(cartPriceOverridesProvider.notifier).clearOverrides();
        await loadTransactions();
        return;
      }

      await DBHelper.instance.mergeTransaction(
        existingTxId,
        additionalTotalAmount,
        additionalGrandTotal,
        items,
      );
      final activeStaff = ref.read(activeStaffProvider);
      final staffName = activeStaff?.name ?? 'Kasir';
      final priceOverrideCount =
          items.where((item) => item.hasPriceOverride).length;
      final totalPriceOverrideAmount = items.fold<int>(
        0,
        (sum, item) => sum + item.effectivePriceOverrideAmount,
      );
      if (priceOverrideCount > 0) {
        await DBHelper.instance.insertAuditLog(AuditLog(
          action: 'price_override_applied',
          entityType: 'transaction',
          entityId: existingTxId,
          staffId: activeStaff?.id,
          staffName: staffName,
          staffRole: activeStaff?.role ?? '',
          amount: totalPriceOverrideAmount,
          note:
              '$priceOverrideCount item tambahan memakai harga nego di order servis.',
          metadataJson: jsonEncode({
            'item_count': priceOverrideCount,
            'price_override_amount': totalPriceOverrideAmount,
          }),
          createdAt: DateTime.now().toIso8601String(),
        ));
      }

      final table = await DBHelper.instance
          .getservisStationByTransactionId(existingTxId);
      if (table != null) {
        final nowIso = DateTime.now().toIso8601String();
        await DBHelper.instance.insertservisWorkshopTicket(
          servisWorkshopTicket(
            transactionId: existingTxId,
            tableName: table.name,
            customerName: 'Meja ${table.name}',
            orderType: 'Tambahan Pesanan',
            status: 'queued',
            station: 'Workshop',
            note: 'Tambahan item dari gabung pesanan',
            createdAt: nowIso,
            updatedAt: nowIso,
          ),
        );
        await ref.read(servisWorkshopTicketsProvider.notifier).loadTickets();
      }

      // Clear notes after successful merge
      ref.read(cartItemNotesProvider.notifier).clearNotes();
      ref.read(cartPriceOverridesProvider.notifier).clearOverrides();

      await ref.read(productsProvider.notifier).loadProducts();
      await loadTransactions();
    } catch (e) {
      debugPrint('mergeTransaction error: $e');
      rethrow;
    }
  }

  Future<void> addCicilan({
    required int transactionId,
    required Cicilan cicilan,
    required int newAmountPaid,
    required int grandTotal,
  }) async {
    try {
      await DBHelper.instance.insertCicilan(cicilan);

      // Update amount paid in DB
      await DBHelper.instance
          .updateTransactionAmountPaid(transactionId, newAmountPaid);

      // Auto-update status to Lunas if fully paid
      if (newAmountPaid >= grandTotal) {
        await DBHelper.instance.updateTransactionStatus(transactionId, "Lunas");
        await DBHelper.instance
            .releaseservisStationByTransactionId(transactionId);
        await DBHelper.instance.updateWorkshopTicketStatusByTransaction(
          transactionId,
          'done',
        );
      }

      final staff = ref.read(activeStaffProvider);
      await DBHelper.instance.insertAuditLog(AuditLog(
        action: 'piutang_payment',
        entityType: 'transaction',
        entityId: transactionId,
        staffId: staff?.id,
        staffName: staff?.name ?? 'Kasir',
        staffRole: staff?.role ?? '',
        amount: cicilan.nominal,
        note: 'Pembayaran piutang servis dicatat',
        createdAt: DateTime.now().toIso8601String(),
      ));

      await loadTransactions();
      await ref.read(servisStationsProvider.notifier).loadTables();
      await ref.read(servisWorkshopTicketsProvider.notifier).loadTickets();
      _invalidateHistory();
    } catch (e) {
      debugPrint('addCicilan error: $e');
      rethrow;
    }
  }

  Future<int> _recordRemainingPaymentIfNeeded({
    required int txId,
    required int grandTotal,
    required String paymentMethod,
  }) async {
    final tx = await DBHelper.instance.getTransactionById(txId);
    final targetTotal = grandTotal > 0 ? grandTotal : tx?.grandTotal ?? 0;
    if (targetTotal <= 0) return 0;

    final paidNet = tx == null
        ? 0
        : (tx.amountPaid - tx.changeAmount).clamp(0, targetTotal).toInt();
    final remaining = (targetTotal - paidNet).clamp(0, targetTotal).toInt();
    if (remaining <= 0) return 0;

    await DBHelper.instance.insertCicilan(
      Cicilan(
        transactionId: txId,
        nominal: remaining,
        metodePembayaran:
            paymentMethod.trim().isEmpty ? 'tunai' : paymentMethod.trim(),
        createdAt: DateTime.now().toIso8601String(),
      ),
    );
    return remaining;
  }

  Future<bool> _shouldReplaceTransactionPaymentMethod(int txId) async {
    final tx = await DBHelper.instance.getTransactionById(txId);
    if (tx == null) return true;
    final paidNet = (tx.amountPaid - tx.changeAmount)
        .clamp(0, tx.grandTotal > 0 ? tx.grandTotal : tx.amountPaid)
        .toInt();
    return paidNet <= 0;
  }

  Future<void> updateservisStatus(
      int txId, String status, String? kelengkapan) async {
    try {
      final net = POSNetworkService.instance;
      if (net.mode == POSNetworkMode.terminal && net.masterIp != null) {
        final ok = await net.updateTransactionservisStatus(
          txId: txId,
          status: status,
          kelengkapan: kelengkapan,
        );
        if (!ok) {
          throw Exception('Gagal sinkron status transaksi ke master');
        }
        if (status == 'Selesai') {
          await LocalNotificationService.cancelservisReminder(txId);
        }
        await loadTransactions();
        _invalidateHistory();
        return;
      }

      await DBHelper.instance
          .updateTransactionservisStatus(txId, status, kelengkapan);

      // Cancel reminder if servis is finished
      if (status == 'Selesai') {
        await LocalNotificationService.cancelservisReminder(txId);
      }

      await loadTransactions();
      _invalidateHistory();
    } catch (e) {
      debugPrint('updateservisStatus error: $e');
    }
  }

  /// Mark a transaction as paid (full payment) and set servis status to Selesai.
  Future<void> markAsPaidAndFinish({
    required int txId,
    required int grandTotal,
    required String paymentMethod,
    required String? kelengkapan,
  }) async {
    try {
      final net = POSNetworkService.instance;
      final shouldReplacePaymentMethod =
          await _shouldReplaceTransactionPaymentMethod(txId);
      if (net.mode == POSNetworkMode.terminal && net.masterIp != null) {
        final ok = await net.markTransactionPaid(
          txId: txId,
          grandTotal: grandTotal,
          paymentMethod: paymentMethod,
          finish: true,
          kelengkapan: kelengkapan,
          replacePaymentMethod: shouldReplacePaymentMethod,
        );
        if (!ok) {
          throw Exception('Gagal sinkron pelunasan transaksi ke master');
        }
        await LocalNotificationService.cancelservisReminder(txId);
        await loadTransactions();
        _invalidateHistory();
        return;
      }

      final paidNow = await _recordRemainingPaymentIfNeeded(
        txId: txId,
        grandTotal: grandTotal,
        paymentMethod: paymentMethod,
      );
      // Update amount paid
      await DBHelper.instance.updateTransactionAmountPaid(txId, grandTotal);
      // Update payment status
      await DBHelper.instance.updateTransactionStatus(txId, 'Lunas');
      // Update payment method
      final db = await DBHelper.instance.database;
      await db.update(
          'transactions',
          {
            if (shouldReplacePaymentMethod) 'payment_method': paymentMethod,
            'updated_at': DateTime.now().toIso8601String(),
          },
          where: 'id = ?',
          whereArgs: [txId]);
      // Set servis status to Selesai
      await DBHelper.instance
          .updateTransactionservisStatus(txId, 'Selesai', kelengkapan);
      // Cancel any scheduled reminder
      await LocalNotificationService.cancelservisReminder(txId);

      final staff = ref.read(activeStaffProvider);
      await DBHelper.instance.insertAuditLog(AuditLog(
        action: 'piutang_payment',
        entityType: 'transaction',
        entityId: txId,
        staffId: staff?.id,
        staffName: staff?.name ?? 'Kasir',
        staffRole: staff?.role ?? '',
        amount: paidNow,
        note: 'Pelunasan order servis dan selesai',
        metadataJson: jsonEncode({'payment_method': paymentMethod}),
        createdAt: DateTime.now().toIso8601String(),
      ));

      await loadTransactions();
      _invalidateHistory();
    } catch (e) {
      debugPrint('markAsPaidAndFinish error: $e');
      rethrow;
    }
  }

  /// Mark a transaction as paid (full payment) without changing servis status.
  Future<void> markAsPaidOnly({
    required int txId,
    required int grandTotal,
    required String paymentMethod,
  }) async {
    try {
      final net = POSNetworkService.instance;
      final shouldReplacePaymentMethod =
          await _shouldReplaceTransactionPaymentMethod(txId);
      if (net.mode == POSNetworkMode.terminal && net.masterIp != null) {
        final ok = await net.markTransactionPaid(
          txId: txId,
          grandTotal: grandTotal,
          paymentMethod: paymentMethod,
          replacePaymentMethod: shouldReplacePaymentMethod,
        );
        if (!ok) {
          throw Exception('Gagal sinkron pelunasan transaksi ke master');
        }
        await loadTransactions();
        _invalidateHistory();
        return;
      }

      final paidNow = await _recordRemainingPaymentIfNeeded(
        txId: txId,
        grandTotal: grandTotal,
        paymentMethod: paymentMethod,
      );
      await DBHelper.instance.updateTransactionAmountPaid(txId, grandTotal);
      await DBHelper.instance.updateTransactionStatus(txId, 'Lunas');
      final db = await DBHelper.instance.database;
      await db.update(
          'transactions',
          {
            if (shouldReplacePaymentMethod) 'payment_method': paymentMethod,
            'updated_at': DateTime.now().toIso8601String(),
          },
          where: 'id = ?',
          whereArgs: [txId]);
      final staff = ref.read(activeStaffProvider);
      await DBHelper.instance.insertAuditLog(AuditLog(
        action: 'piutang_payment',
        entityType: 'transaction',
        entityId: txId,
        staffId: staff?.id,
        staffName: staff?.name ?? 'Kasir',
        staffRole: staff?.role ?? '',
        amount: paidNow,
        note: 'Pelunasan order servis',
        metadataJson: jsonEncode({'payment_method': paymentMethod}),
        createdAt: DateTime.now().toIso8601String(),
      ));
      await loadTransactions();
      _invalidateHistory();
    } catch (e) {
      debugPrint('markAsPaidOnly error: $e');
      rethrow;
    }
  }

  void _invalidateHistory() {
    // Only invalidate providers that are NOT already watching transactionsProvider.
    // lunasSummary, lunasTransactions, piutangSummary, and dashboardProvider
    // already have ref.watch(transactionsProvider), so they rebuild automatically.
    ref.invalidate(walletBalanceProvider);
  }

  Future<void> deleteTransaction(int id) async {
    try {
      final tx = await DBHelper.instance.getTransactionById(id);
      await DBHelper.instance.softDeleteTransaction(id);
      await DBHelper.instance.releaseservisStationByTransactionId(id);
      await DBHelper.instance
          .updateWorkshopTicketStatusByTransaction(id, 'done');

      // Cancel reminder if transaction is deleted
      await LocalNotificationService.cancelservisReminder(id);

      final staff = ref.read(activeStaffProvider);
      await DBHelper.instance.insertAuditLog(AuditLog(
        action: 'transaction_deleted',
        entityType: 'transaction',
        entityId: id,
        staffId: staff?.id,
        staffName: staff?.name ?? 'Kasir',
        staffRole: staff?.role ?? '',
        amount: tx?.grandTotal ?? 0,
        note: 'Order servis dihapus',
        createdAt: DateTime.now().toIso8601String(),
      ));

      await loadTransactions();
      // Refresh relevant data
      ref.read(productsProvider.notifier).loadProducts();
      await ref.read(servisStationsProvider.notifier).loadTables();
      await ref.read(servisWorkshopTicketsProvider.notifier).loadTickets();
      _invalidateHistory();
    } catch (e) {
      debugPrint('deleteTransaction error: $e');
      rethrow;
    }
  }

  Future<void> restoreTransaction(int id) async {
    try {
      await DBHelper.instance.restoreTransaction(id);
      await loadTransactions();
      // Refresh relevant data
      ref.read(productsProvider.notifier).loadProducts();
      _invalidateHistory();
    } catch (e) {
      debugPrint('restoreTransaction error: $e');
      rethrow;
    }
  }
}

// ==============================
// HISTORY (RIWAYAT) PROVIDERS
// ==============================
final riwayatTabProvider =
    NotifierProvider<RiwayatTabNotifier, int>(() => RiwayatTabNotifier());

class RiwayatTabNotifier extends Notifier<int> {
  @override
  int build() => 0;
  void set(int v) => state = v;
}

final riwayatSearchProvider = NotifierProvider<RiwayatSearchNotifier, String>(
    () => RiwayatSearchNotifier());

class RiwayatSearchNotifier extends Notifier<String> {
  @override
  String build() => '';
  void set(String v) => state = v;
}

final riwayatPeriodTypeProvider =
    NotifierProvider<RiwayatPeriodTypeNotifier, String>(
        () => RiwayatPeriodTypeNotifier());

class RiwayatPeriodTypeNotifier extends Notifier<String> {
  @override
  String build() => 'monthly';
  void set(String v) => state = v;
}

final riwayatSelectedDateProvider =
    NotifierProvider<RiwayatSelectedDateNotifier, DateTime>(
        () => RiwayatSelectedDateNotifier());

class RiwayatSelectedDateNotifier extends Notifier<DateTime> {
  @override
  DateTime build() => DateTime.now();
  void set(DateTime v) => state = v;
}

final piutangPeriodTypeProvider =
    NotifierProvider<PiutangPeriodTypeNotifier, String>(
        () => PiutangPeriodTypeNotifier());

class PiutangPeriodTypeNotifier extends Notifier<String> {
  @override
  String build() => 'monthly';
  void set(String v) => state = v;
}

final piutangSelectedDateProvider =
    NotifierProvider<PiutangSelectedDateNotifier, DateTime>(
        () => PiutangSelectedDateNotifier());

class PiutangSelectedDateNotifier extends Notifier<DateTime> {
  @override
  DateTime build() => DateTime.now();
  void set(DateTime v) => state = v;
}

final lunasSummaryProvider = FutureProvider<Map<String, int>>((ref) async {
  ref.watch(transactionsProvider);
  final periodType = ref.watch(riwayatPeriodTypeProvider);
  final date = ref.watch(riwayatSelectedDateProvider);
  return DBHelper.instance.getPaidSummaryByPeriod(
    periodType: periodType,
    selectedDate: date,
  );
});

final lunasTransactionsProvider =
    FutureProvider<List<Transaction>>((ref) async {
  ref.watch(transactionsProvider);
  final periodType = ref.watch(riwayatPeriodTypeProvider);
  final date = ref.watch(riwayatSelectedDateProvider);
  return DBHelper.instance.getTransactionsByPeriod(
    periodType: periodType,
    selectedDate: date,
    isPaid: true,
  );
});

final piutangSummaryProvider = FutureProvider<Map<String, int>>((ref) async {
  ref.watch(transactionsProvider);
  final periodType = ref.watch(riwayatPeriodTypeProvider);
  final date = ref.watch(riwayatSelectedDateProvider);
  return DBHelper.instance.getUnpaidSummaryByPeriod(
    periodType: periodType,
    selectedDate: date,
  );
});

final piutangTransactionsProvider =
    FutureProvider<List<Transaction>>((ref) async {
  ref.watch(transactionsProvider);
  final periodType = ref.watch(riwayatPeriodTypeProvider);
  final date = ref.watch(riwayatSelectedDateProvider);
  return DBHelper.instance.getTransactionsByPeriod(
    periodType: periodType,
    selectedDate: date,
    isPaid: false,
  );
});

// ==============================
// DISCOUNTS PROVIDER
// ==============================
final discountsProvider = NotifierProvider<DiscountsNotifier, List<Discount>>(
    () => DiscountsNotifier());

class DiscountsNotifier extends Notifier<List<Discount>> {
  @override
  List<Discount> build() {
    loadDiscounts();
    return [];
  }

  Future<void> loadDiscounts() async {
    try {
      state = await DBHelper.instance.getAllDiscounts();
    } catch (e) {
      debugPrint('loadDiscounts error: $e');
    }
  }

  Future<void> addDiscount(Discount d) async {
    try {
      await DBHelper.instance.insertDiscount(d);
      await loadDiscounts();
    } catch (e) {
      debugPrint('addDiscount error: $e');
      rethrow;
    }
  }

  Future<void> updateDiscount(Discount d) async {
    try {
      await DBHelper.instance.updateDiscount(d);
      await loadDiscounts();
    } catch (e) {
      debugPrint('updateDiscount error: $e');
      rethrow;
    }
  }

  Future<void> deleteDiscount(int id) async {
    try {
      await DBHelper.instance.deleteDiscount(id);
      await loadDiscounts();
    } catch (e) {
      debugPrint('deleteDiscount error: $e');
      rethrow;
    }
  }
}

// ==============================
// KASIR SESSION PROVIDER
// ==============================
class ShiftSettings {
  final bool enableShift;
  final List<String> shiftNames;

  ShiftSettings({this.enableShift = false, this.shiftNames = const []});

  ShiftSettings copyWith({bool? enableShift, List<String>? shiftNames}) {
    return ShiftSettings(
      enableShift: enableShift ?? this.enableShift,
      shiftNames: shiftNames ?? this.shiftNames,
    );
  }
}

final shiftSettingsProvider =
    NotifierProvider<ShiftSettingsNotifier, ShiftSettings>(
        () => ShiftSettingsNotifier());

class ShiftSettingsNotifier extends Notifier<ShiftSettings> {
  static const _keyEnable = 'shift_enable';
  static const _keyNames = 'shift_names';

  @override
  ShiftSettings build() {
    _load();
    return ShiftSettings(
        enableShift: true, shiftNames: ['Shift Pagi', 'Shift Sore']);
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final enable = prefs.getBool(_keyEnable) ?? true;
      final namesStr = prefs.getStringList(_keyNames);
      final names = namesStr != null && namesStr.isNotEmpty
          ? namesStr
          : ['Shift Pagi', 'Shift Sore'];
      state = ShiftSettings(enableShift: enable, shiftNames: names);
    } catch (e) {
      debugPrint('ShiftSettings _load error: $e');
    }
  }

  Future<void> updateSettings(ShiftSettings s) async {
    try {
      state = s;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_keyEnable, s.enableShift);
      await prefs.setStringList(_keyNames, s.shiftNames);
    } catch (e) {
      debugPrint('ShiftSettings updateSettings error: $e');
      rethrow;
    }
  }
}

final kasirSessionsProvider =
    NotifierProvider<KasirSessionsNotifier, List<KasirSession>>(
        () => KasirSessionsNotifier());

class KasirSessionsNotifier extends Notifier<List<KasirSession>> {
  @override
  List<KasirSession> build() {
    _load();
    return [];
  }

  Future<void> _load() async {
    try {
      state = await DBHelper.instance.getAllKasirSessions();
    } catch (e) {
      debugPrint('kasirSessions _load error: $e');
    }
  }

  Future<void> reload() => _load();

  /// Buka sesi kasir baru. Returns id sesi baru.
  Future<int> openSession({
    required String kasirName,
    required int openingCash,
    String? shiftName,
    int? staffId,
    String? staffName,
    String? staffRole,
  }) async {
    try {
      final deviceId = await _currentDeviceIdForShift();
      final session = KasirSession(
        kasirName: kasirName,
        openedAt: DateTime.now().toIso8601String(),
        openingCash: openingCash,
        shiftName: shiftName,
        staffId: staffId,
        staffName: staffName,
        staffRole: staffRole,
        deviceId: deviceId,
      );
      final id = await DBHelper.instance.insertKasirSession(session);
      await DBHelper.instance.insertAuditLog(AuditLog(
        action: 'shift_opened',
        entityType: 'kasir_session',
        entityId: id,
        staffId: staffId,
        staffName: staffName ?? kasirName,
        staffRole: staffRole ?? '',
        amount: openingCash,
        note: 'Buka kasir servis${shiftName == null ? '' : ' - $shiftName'}',
        createdAt: DateTime.now().toIso8601String(),
      ));
      await _load();
      return id;
    } catch (e) {
      debugPrint('openSession error: $e');
      rethrow;
    }
  }

  /// Tutup sesi aktif. [sessionId] = id sesi yang dibuka.
  Future<void> closeSession({
    required int sessionId,
    required String openedAt,
    required int openingCash,
    required int closingCash,
    String? notes,
  }) async {
    try {
      final now = DateTime.now().toIso8601String();
      final deviceId = await _currentDeviceIdForShift();
      Map<String, dynamic> summary;
      try {
        summary =
            await DBHelper.instance.getTransactionSummaryBetween(openedAt, now);
      } catch (e, st) {
        debugPrint('closeSession summary error: $e\n$st');
        summary = const {
          'total_transactions': 0,
          'total_revenue': 0,
          'total_cash': 0,
          'total_non_cash': 0,
        };
      }
      await DBHelper.instance.closeKasirSession(
        id: sessionId,
        closedAt: now,
        closingCash: closingCash,
        totalTransactions:
            (summary['total_transactions'] as num?)?.toInt() ?? 0,
        totalRevenue: (summary['total_revenue'] as num?)?.toInt() ?? 0,
        totalCash: (summary['total_cash'] as num?)?.toInt() ?? 0,
        totalNonCash: (summary['total_non_cash'] as num?)?.toInt() ?? 0,
        notes: notes,
        deviceId: deviceId,
      );
      final staff = ref.read(activeStaffProvider);
      final expectedCash =
          openingCash + ((summary['total_cash'] as num?)?.toInt() ?? 0);
      final difference = closingCash - expectedCash;
      try {
        await DBHelper.instance.insertAuditLog(AuditLog(
          action: 'shift_closed',
          entityType: 'kasir_session',
          entityId: sessionId,
          staffId: staff?.id,
          staffName: staff?.name ?? 'Kasir',
          staffRole: staff?.role ?? '',
          amount: difference,
          note: 'Tutup kasir servis. Selisih kas: $difference',
          metadataJson: jsonEncode({
            'opening_cash': openingCash,
            'closing_cash': closingCash,
            'expected_cash': expectedCash,
            'total_transactions':
                (summary['total_transactions'] as num?)?.toInt() ?? 0,
          }),
          createdAt: now,
        ));
      } catch (e, st) {
        debugPrint('closeSession audit log error: $e\n$st');
      }
      await _load();
    } catch (e) {
      debugPrint('closeSession error: $e');
      rethrow;
    }
  }

  Future<void> recordCashCount({
    required int sessionId,
    required int expectedCash,
    required int actualCash,
    String? notes,
  }) async {
    try {
      final now = DateTime.now().toIso8601String();
      final staff = ref.read(activeStaffProvider);
      final difference = actualCash - expectedCash;
      await DBHelper.instance.insertAuditLog(AuditLog(
        action: 'shift_cash_counted',
        entityType: 'kasir_session',
        entityId: sessionId,
        staffId: staff?.id,
        staffName: staff?.name ?? 'Kasir',
        staffRole: staff?.role ?? '',
        amount: difference,
        note: notes?.trim().isNotEmpty == true
            ? notes!.trim()
            : 'Hitung kas shift servis. Selisih kas: $difference',
        metadataJson: jsonEncode({
          'expected_cash': expectedCash,
          'actual_cash': actualCash,
          'difference': difference,
        }),
        createdAt: now,
      ));
      ref.invalidate(auditLogsProvider);
    } catch (e) {
      debugPrint('recordCashCount error: $e');
      rethrow;
    }
  }

  /// Tutup kasir tanpa sesi aktif (langsung hitung dari rentang custom).
  Future<void> closeDirect({
    required String kasirName,
    required int openingCash,
    required int closingCash,
    required String openedAt,
    String? notes,
    String? shiftName,
    int? staffId,
    String? staffName,
    String? staffRole,
  }) async {
    try {
      final now = DateTime.now().toIso8601String();
      final summary =
          await DBHelper.instance.getTransactionSummaryBetween(openedAt, now);
      final session = KasirSession(
        kasirName: kasirName,
        openedAt: openedAt,
        closedAt: now,
        openingCash: openingCash,
        closingCash: closingCash,
        totalTransactions:
            (summary['total_transactions'] as num?)?.toInt() ?? 0,
        totalRevenue: (summary['total_revenue'] as num?)?.toInt() ?? 0,
        totalCash: (summary['total_cash'] as num?)?.toInt() ?? 0,
        totalNonCash: (summary['total_non_cash'] as num?)?.toInt() ?? 0,
        notes: notes,
        shiftName: shiftName,
        staffId: staffId,
        staffName: staffName,
        staffRole: staffRole,
      );
      final id = await DBHelper.instance.insertKasirSession(session);
      final expectedCash = openingCash + session.totalCash;
      final difference = closingCash - expectedCash;
      await DBHelper.instance.insertAuditLog(AuditLog(
        action: 'shift_closed',
        entityType: 'kasir_session',
        entityId: id,
        staffId: staffId,
        staffName: staffName ?? kasirName,
        staffRole: staffRole ?? '',
        amount: difference,
        note: 'Tutup kasir servis langsung. Selisih kas: $difference',
        metadataJson: jsonEncode({
          'opening_cash': openingCash,
          'closing_cash': closingCash,
          'expected_cash': expectedCash,
          'total_transactions': session.totalTransactions,
        }),
        createdAt: now,
      ));
      await _load();
    } catch (e) {
      debugPrint('closeDirect error: $e');
      rethrow;
    }
  }
}

final activeKasirSessionProvider = FutureProvider<KasirSession?>((ref) async {
  ref.watch(kasirSessionsProvider);
  return DBHelper.instance.getActiveKasirSession();
});

final drawerCashProvider = FutureProvider<int>((ref) async {
  final session = await ref.watch(activeKasirSessionProvider.future);
  if (session == null) return 0;

  // Memastikan kas di laci juga update setiap ada perubahan saldo/transaksi baru
  ref.watch(walletBalanceProvider);

  final openingCash = session.openingCash;
  // Gunakan getPhysicalCashFlow untuk hanya menghitung uang tunai
  final cashFlow =
      await DBHelper.instance.getPhysicalCashFlow(since: session.openedAt);

  return openingCash + cashFlow;
});

class ActiveShiftSummary {
  final int totalTransactions;
  final int totalRevenue;
  final int cashFlow;
  final int nonCash;

  const ActiveShiftSummary({
    this.totalTransactions = 0,
    this.totalRevenue = 0,
    this.cashFlow = 0,
    this.nonCash = 0,
  });
}

final activeShiftSummaryProvider =
    FutureProvider<ActiveShiftSummary>((ref) async {
  ref.watch(transactionsProvider);
  ref.watch(walletTransactionsProvider);
  final session = await ref.watch(activeKasirSessionProvider.future);
  if (session == null) return const ActiveShiftSummary();

  final now = DateTime.now().toIso8601String();
  final summary = await DBHelper.instance.getTransactionSummaryBetween(
    session.openedAt,
    now,
  );
  final totalRevenue = (summary['total_revenue'] as num?)?.toInt() ?? 0;
  final cashFlow = (summary['total_cash'] as num?)?.toInt() ?? 0;
  final nonCashFlow = (summary['total_non_cash'] as num?)?.toInt() ?? 0;

  return ActiveShiftSummary(
    totalTransactions: (summary['total_transactions'] as num?)?.toInt() ?? 0,
    totalRevenue: totalRevenue,
    cashFlow: cashFlow,
    nonCash: nonCashFlow,
  );
});

final auditLogsProvider = FutureProvider<List<AuditLog>>((ref) async {
  ref.watch(transactionsProvider);
  ref.watch(kasirSessionsProvider);
  ref.watch(walletTransactionsProvider);
  return DBHelper.instance.getAuditLogs(limit: 300);
});

class TransactionSettings {
  final String prefix;
  TransactionSettings({this.prefix = 'TRX'});

  TransactionSettings copyWith({String? prefix}) {
    return TransactionSettings(prefix: prefix ?? this.prefix);
  }
}

final transactionSettingsProvider =
    NotifierProvider<TransactionSettingsNotifier, TransactionSettings>(
        () => TransactionSettingsNotifier());

class TransactionSettingsNotifier extends Notifier<TransactionSettings> {
  static const _keyPrefix = 'transaction_prefix_manual';

  @override
  TransactionSettings build() {
    _load();
    return TransactionSettings();
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString(_keyPrefix);
      if (saved != null) {
        state = TransactionSettings(prefix: saved);
      }
    } catch (e) {
      debugPrint('TransactionSettings _load error: $e');
    }
  }

  Future<void> updatePrefix(String prefix) async {
    try {
      final clean = prefix.trim().toUpperCase();
      state = state.copyWith(prefix: clean.isEmpty ? 'TRX' : clean);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyPrefix, state.prefix);
    } catch (e) {
      debugPrint('TransactionSettings updatePrefix error: $e');
      rethrow;
    }
  }
}

// ==============================
// NOTIFICATIONS PROVIDER
// ==============================
enum NotificationCategory { stok, keuangan, sistem }

class NotificationItem {
  final String id;
  final String title;
  final String subtitle;
  final String date;
  final NotificationCategory category;
  final String urgency; // 'high', 'medium', 'low'
  final Map<String, dynamic>? metadata;
  final bool isRead;

  NotificationItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.date,
    required this.category,
    this.urgency = 'medium',
    this.metadata,
    this.isRead = false,
  });

  NotificationItem copyWith({
    String? id,
    String? title,
    String? subtitle,
    String? date,
    NotificationCategory? category,
    String? urgency,
    Map<String, dynamic>? metadata,
    bool? isRead,
  }) {
    return NotificationItem(
      id: id ?? this.id,
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      date: date ?? this.date,
      category: category ?? this.category,
      urgency: urgency ?? this.urgency,
      metadata: metadata ?? this.metadata,
      isRead: isRead ?? this.isRead,
    );
  }
}

class NotificationSettings {
  final bool showStok;
  final bool showKeuangan;
  final bool showSistem;
  final bool useTTS;
  final int minStok;
  final int expiryDays;

  NotificationSettings({
    this.showStok = true,
    this.showKeuangan = true,
    this.showSistem = true,
    this.useTTS = true,
    this.minStok = 5,
    this.expiryDays = 30,
  });

  NotificationSettings copyWith({
    bool? showStok,
    bool? showKeuangan,
    bool? showSistem,
    bool? useTTS,
    int? minStok,
    int? expiryDays,
  }) {
    return NotificationSettings(
      showStok: showStok ?? this.showStok,
      showKeuangan: showKeuangan ?? this.showKeuangan,
      showSistem: showSistem ?? this.showSistem,
      useTTS: useTTS ?? this.useTTS,
      minStok: minStok ?? this.minStok,
      expiryDays: expiryDays ?? this.expiryDays,
    );
  }
}

final notificationSettingsProvider =
    NotifierProvider<NotificationSettingsNotifier, NotificationSettings>(
        () => NotificationSettingsNotifier());

class NotificationSettingsNotifier extends Notifier<NotificationSettings> {
  static const _keyPrefix = 'notif_settings_';

  @override
  NotificationSettings build() {
    _load();
    return NotificationSettings();
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      state = NotificationSettings(
        showStok: prefs.getBool('${_keyPrefix}stok') ?? true,
        showKeuangan: prefs.getBool('${_keyPrefix}keuangan') ?? true,
        showSistem: prefs.getBool('${_keyPrefix}sistem') ?? true,
        useTTS: prefs.getBool('${_keyPrefix}use_tts') ?? true,
        minStok: prefs.getInt('${_keyPrefix}min_stock') ?? 5,
        expiryDays: prefs.getInt('${_keyPrefix}expiry_days') ?? 30,
      );
    } catch (e) {
      debugPrint('NotificationSettings _load error: $e');
    }
  }

  Future<void> update(NotificationSettings s) async {
    try {
      state = s;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('${_keyPrefix}stok', s.showStok);
      await prefs.setBool('${_keyPrefix}keuangan', s.showKeuangan);
      await prefs.setBool('${_keyPrefix}sistem', s.showSistem);
      await prefs.setBool('${_keyPrefix}use_tts', s.useTTS);
      await prefs.setInt('${_keyPrefix}min_stock', s.minStok);
      await prefs.setInt('${_keyPrefix}expiry_days', s.expiryDays);
      // Invalidate the notification list to refresh it
      ref.invalidate(allNotificationsProvider);
    } catch (e) {
      debugPrint('NotificationSettings update error: $e');
      rethrow;
    }
  }
}

final allNotificationsProvider =
    FutureProvider<List<NotificationItem>>((ref) async {
  // Watch relevant providers to re-fetch when data changes
  ref.watch(productsProvider);
  ref.watch(transactionsProvider);
  ref.watch(kasirSessionsProvider);
  final settings = ref.watch(notificationSettingsProvider);

  final db = DBHelper.instance;
  final List<NotificationItem> items = [];

  // 1. Stok Category
  if (settings.showStok) {
    // Low Stock
    final rawDb = await db.database;
    final lowStock = await rawDb.rawQuery(
        'SELECT * FROM products WHERE stock <= ? AND has_stock_management = 1 ORDER BY stock ASC',
        [settings.minStok]);
    final lowStockProducts = lowStock.map((m) => Product.fromMap(m)).toList();

    for (var p in lowStockProducts) {
      items.add(NotificationItem(
        id: 'low_stock_${p.id}',
        title: 'Stok Menipis: ${p.name}',
        subtitle: 'Tersisa ${p.stock} ${p.unit}.',
        date: DateTime.now().toIso8601String(),
        category: NotificationCategory.stok,
        urgency: 'high',
        metadata: {'productId': p.id, 'type': 'low_stock'},
      ));
    }

    // Near Expiry
    final expiring = await db.getNearExpiryBatches(days: settings.expiryDays);
    for (var m in expiring) {
      items.add(NotificationItem(
        id: 'expiry_${m['id']}',
        title: 'Hampir Kedaluwarsa: ${m['product_name']}',
        subtitle:
            'Batch ${m['stock_name'] ?? 'tanpa nama'} segera kedaluwarsa (${m['expiry_date']}).',
        date: m['expiry_date'] ?? '',
        category: NotificationCategory.stok,
        urgency: 'medium',
        metadata: {'productId': m['product_id'], 'type': 'expiry'},
      ));
    }
  }

  // 2. Keuangan Category
  if (settings.showKeuangan) {
    final unpaid = await db.getUnpaidTransactions();
    final now = DateTime.now();
    for (var tx in unpaid) {
      bool isOverdue = false;
      if (tx.pickupSchedule != null && tx.pickupSchedule!.isNotEmpty) {
        final dt = DateTime.tryParse(tx.pickupSchedule!);
        if (dt != null && dt.isBefore(now)) {
          isOverdue = true;
        }
      }

      // Only show push notification if it's past the estimated completion date
      if (isOverdue) {
        items.add(NotificationItem(
          id: 'unpaid_${tx.id}',
          title: 'Tagihan Servis: ${tx.customerName ?? "Pelanggan Umum"}',
          subtitle:
              'Tagihan Belum Lunas: Rp${tx.grandTotal - tx.amountPaid} (Melewati estimasi selesai).',
          date: tx.createdAt,
          category: NotificationCategory.keuangan,
          urgency: 'high',
          metadata: {'transactionId': tx.id, 'type': 'piutang'},
        ));
      }
    }
  }

  // 3. Sistem Category
  if (settings.showSistem) {
    final activeSession = await db.getActiveKasirSession();
    if (activeSession != null) {
      final openedAt = DateTime.tryParse(activeSession.openedAt);
      if (openedAt != null &&
          DateTime.now().difference(openedAt).inHours >= 12) {
        items.add(NotificationItem(
          id: 'active_session_${activeSession.id}',
          title: 'Sesi Shift Masih Terbuka',
          subtitle:
              'Petugas ${activeSession.kasirName} belum menutup shift sejak ${activeSession.openedAt.substring(11, 16)}.',
          date: activeSession.openedAt,
          category: NotificationCategory.sistem,
          urgency: 'medium',
          metadata: {'sessionId': activeSession.id, 'type': 'session'},
        ));
      }
    }
  }

  // Sort by urgency (high first) then by date (newest first)
  items.sort((a, b) {
    if (a.urgency == b.urgency) {
      return b.date.compareTo(a.date);
    }
    if (a.urgency == 'high') return -1;
    if (b.urgency == 'high') return 1;
    return 0;
  });

  return items;
});

// ==============================
// READ NOTIFICATIONS PROVIDER (Async Version)
// ==============================
final readNotificationsProvider =
    AsyncNotifierProvider<ReadNotificationsNotifier, Set<String>>(
        () => ReadNotificationsNotifier());

class ReadNotificationsNotifier extends AsyncNotifier<Set<String>> {
  static const _key = 'read_notifications';

  @override
  Future<Set<String>> build() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final ids = prefs.getStringList(_key) ?? [];
      debugPrint(
          '[ReadNotif] Loaded ${ids.length} read notification IDs from SharedPreferences');
      return ids.toSet();
    } catch (e) {
      debugPrint('ReadNotificationsNotifier build error: $e');
      return <String>{};
    }
  }

  Future<void> markAsRead(String notificationId) async {
    try {
      final currentState = state.asData?.value ?? <String>{};
      final Set<String> updated = {...currentState, notificationId};
      state = AsyncValue.data(updated);

      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_key, updated.toList());

      debugPrint(
          '[ReadNotif] Marked single notification as read: $notificationId');

      // No need to invalidate, unreadNotificationsProvider watches readNotificationsProvider
      // ref.invalidate(unreadNotificationsProvider);
    } catch (e) {
      debugPrint('ReadNotificationsNotifier markAsRead error: $e');
      rethrow;
    }
  }

  Future<void> markAllAsRead() async {
    try {
      final allNotifications = await ref.read(allNotificationsProvider.future);
      final allIds = allNotifications.map((n) => n.id).toSet();

      debugPrint('[ReadNotif] markAllAsRead called');
      debugPrint('[ReadNotif] Total notifications: ${allIds.length}');
      debugPrint('[ReadNotif] Notification IDs: $allIds');

      // Update state
      state = AsyncValue.data(allIds);
      debugPrint('[ReadNotif] State updated to: ${allIds.length} items');

      // Save to SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_key, allIds.toList());
      debugPrint('[ReadNotif] Saved to SharedPreferences');

      // No need to invalidate manually
      // ref.invalidate(unreadNotificationsProvider);
      // debugPrint('[ReadNotif] Invalidated unreadNotificationsProvider');

      // Small delay for propagation
      await Future.delayed(const Duration(milliseconds: 50));
      debugPrint('[ReadNotif] Invalidation complete');
    } catch (e) {
      debugPrint('ReadNotificationsNotifier markAllAsRead error: $e');
      rethrow;
    }
  }

  Future<void> clearAll() async {
    try {
      state = const AsyncValue.data(<String>{});

      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_key, []);

      // No need to invalidate manually
      // ref.invalidate(unreadNotificationsProvider);
      debugPrint('[ReadNotif] Cleared all read notifications');
    } catch (e) {
      debugPrint('ReadNotificationsNotifier clearAll error: $e');
      rethrow;
    }
  }
}

// Provider untuk mendapatkan unread notifications only
// Diubah menjadi Provider sinkron untuk menghindari CircularDependencyError
final unreadNotificationsProvider = Provider<List<NotificationItem>>((ref) {
  final allNotificationsAsync = ref.watch(allNotificationsProvider);
  final readIdsAsync = ref.watch(readNotificationsProvider);

  final allNotifications = allNotificationsAsync.asData?.value ?? [];
  final readIds = readIdsAsync.asData?.value ?? <String>{};

  final unread =
      allNotifications.where((n) => !readIds.contains(n.id)).toList();
  return unread;
});

// ==============================
// RETURNS PROVIDER
// ==============================
final returnsProvider =
    NotifierProvider<ReturnsNotifier, List<ReturnTransaction>>(
        () => ReturnsNotifier());

class ReturnsNotifier extends Notifier<List<ReturnTransaction>> {
  @override
  List<ReturnTransaction> build() {
    loadReturns();
    return [];
  }

  Future<void> loadReturns() async {
    try {
      state = await DBHelper.instance.getAllReturns();
    } catch (e) {
      debugPrint('loadReturns error: $e');
    }
  }

  Future<int> createReturn({
    required int transactionId,
    String? customerName,
    required String reason,
    required String refundMethod,
    required int totalRefund,
    String? note,
    required List<ReturnItem> items,
  }) async {
    try {
      final ret = ReturnTransaction(
        transactionId: transactionId,
        customerName: customerName,
        reason: reason,
        refundMethod: refundMethod,
        totalRefund: totalRefund,
        note: note,
        createdAt: DateTime.now().toIso8601String(),
      );
      final id = await DBHelper.instance.insertReturn(ret, items);
      final staff = ref.read(activeStaffProvider);
      await DBHelper.instance.insertAuditLog(AuditLog(
        action: 'refund_created',
        entityType: 'return_transaction',
        entityId: id,
        staffId: staff?.id,
        staffName: staff?.name ?? 'Kasir',
        staffRole: staff?.role ?? '',
        amount: totalRefund,
        note: 'Refund layanan transaksi #$transactionId',
        metadataJson: jsonEncode({
          'transaction_id': transactionId,
          'customer_name': customerName,
          'reason': reason,
          'refund_method': refundMethod,
          'items': items
              .map((item) => {
                    'product_id': item.productId,
                    'product_name': item.productName,
                    'qty': item.qty,
                    'subtotal': item.subtotal,
                  })
              .toList(),
        }),
        createdAt: DateTime.now().toIso8601String(),
      ));
      await loadReturns();
      // Refresh products and wallet
      ref.invalidate(productsProvider);
      ref.invalidate(walletBalanceProvider);
      ref.invalidate(walletTransactionsProvider);
      await ref.read(transactionsProvider.notifier).loadTransactions();
      ref.invalidate(dashboardProvider);
      ref.invalidate(aiBusinessSnapshotProvider);
      ref.invalidate(auditLogsProvider);
      return id;
    } catch (e) {
      debugPrint('createReturn error: $e');
      rethrow;
    }
  }
}

// ==============================
// SALES TARGET PROVIDER
// ==============================
class SalesTarget {
  final int dailyTarget;
  final int monthlyTarget;

  SalesTarget({this.dailyTarget = 0, this.monthlyTarget = 0});
}

final salesTargetProvider = NotifierProvider<SalesTargetNotifier, SalesTarget>(
    () => SalesTargetNotifier());

class SalesTargetNotifier extends Notifier<SalesTarget> {
  static const _keyDaily = 'sales_target_daily';
  static const _keyMonthly = 'sales_target_monthly';

  @override
  SalesTarget build() {
    _load();
    return SalesTarget();
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      state = SalesTarget(
        dailyTarget: prefs.getInt(_keyDaily) ?? 0,
        monthlyTarget: prefs.getInt(_keyMonthly) ?? 0,
      );
    } catch (e) {
      debugPrint('SalesTarget _load error: $e');
    }
  }

  Future<void> setTargets({required int daily, required int monthly}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_keyDaily, daily);
      await prefs.setInt(_keyMonthly, monthly);
      state = SalesTarget(dailyTarget: daily, monthlyTarget: monthly);
      ref.invalidate(salesProgressProvider);
    } catch (e) {
      debugPrint('SalesTarget setTargets error: $e');
      rethrow;
    }
  }
}

// ==============================
// SALES PROGRESS PROVIDER
// ==============================
class SalesProgress {
  final int todaySales;
  final int dailyTarget;
  final int monthSales;
  final int monthlyTarget;
  final int yesterdaySales;
  final int lastMonthSales;

  SalesProgress({
    this.todaySales = 0,
    this.dailyTarget = 0,
    this.monthSales = 0,
    this.monthlyTarget = 0,
    this.yesterdaySales = 0,
    this.lastMonthSales = 0,
  });

  double get dailyProgressPct =>
      dailyTarget > 0 ? (todaySales / dailyTarget).clamp(0.0, 2.0) : 0;

  double get monthlyProgressPct =>
      monthlyTarget > 0 ? (monthSales / monthlyTarget).clamp(0.0, 2.0) : 0;

  double get dailyGrowthPct {
    if (yesterdaySales == 0) return todaySales > 0 ? 100.0 : 0;
    return ((todaySales - yesterdaySales) / yesterdaySales) * 100;
  }

  double get monthlyGrowthPct {
    if (lastMonthSales == 0) return monthSales > 0 ? 100.0 : 0;
    return ((monthSales - lastMonthSales) / lastMonthSales) * 100;
  }
}

final salesProgressProvider = FutureProvider<SalesProgress>((ref) async {
  ref.watch(transactionsProvider); // Re-compute on new transactions
  final target = ref.watch(salesTargetProvider);
  final db = DBHelper.instance;

  final todaySales = await db.getTodaySalesTotal();
  final monthSales = await db.getMonthSalesTotal();
  final yesterdaySales = await db.getYesterdaySalesTotal();
  final lastMonthSales = await db.getLastMonthSalesTotal();

  return SalesProgress(
    todaySales: todaySales,
    dailyTarget: target.dailyTarget,
    monthSales: monthSales,
    monthlyTarget: target.monthlyTarget,
    yesterdaySales: yesterdaySales,
    lastMonthSales: lastMonthSales,
  );
});

// ==============================
// PROFIL PROVIDER
// ==============================
final profilProvider =
    NotifierProvider<ProfilNotifier, Profile>(() => ProfilNotifier());

class ProfilNotifier extends Notifier<Profile> {
  static const _legacyDefaultAdminPin = '123456';
  Future<void>? _profileLoadInFlight;

  @override
  Profile build() {
    loadProfil();
    return Profile(nama: '', fotoPath: '');
  }

  Future<void> loadProfil() {
    final inFlight = _profileLoadInFlight;
    if (inFlight != null) return inFlight;

    final future = _loadProfil().whenComplete(() {
      _profileLoadInFlight = null;
    });
    _profileLoadInFlight = future;
    return future;
  }

  Future<void> _loadProfil() async {
    try {
      final res = await DBHelper.instance.getProfil();
      final profile = Profile.fromMap(res);
      if (!profile.hasAdminPin && profile.legacyAdminPin.isNotEmpty) {
        final migratedHash = profile.legacyAdminPin == _legacyDefaultAdminPin
            ? ''
            : AuthService.hashPin(profile.legacyAdminPin);
        await DBHelper.instance.saveProfil(
          nama: profile.nama,
          fotoPath: profile.fotoPath,
          adminPinHash: migratedHash,
        );
        state = profile.copyWith(
          adminPinHash: migratedHash,
          legacyAdminPin: '',
        );
        return;
      }

      state = profile;
    } catch (e) {
      debugPrint('loadProfil error: $e');
    }
  }

  Future<void> updateProfil(
      {required String nama, required String fotoPath}) async {
    try {
      await DBHelper.instance.saveProfil(nama: nama, fotoPath: fotoPath);
      state = state.copyWith(nama: nama, fotoPath: fotoPath);
    } catch (e) {
      debugPrint('updateProfil error: $e');
      rethrow;
    }
  }

  Future<void> updateAdminPin(String newPin) async {
    try {
      final hashedPin = AuthService.hashPin(newPin);
      await DBHelper.instance.saveProfil(
        nama: state.nama,
        fotoPath: state.fotoPath,
        adminPinHash: hashedPin,
      );
      state = state.copyWith(adminPinHash: hashedPin, legacyAdminPin: '');
    } catch (e) {
      debugPrint('updateAdminPin error: $e');
      rethrow;
    }
  }

  bool get hasConfiguredAdminPin => state.hasAdminPin;

  bool verifyPin(String inputPin) {
    if (!state.hasAdminPin) return false;
    return AuthService.hashPin(inputPin) == state.adminPinHash;
  }

  /// Koreksi saldo profesional: membuat entri adjustment
  /// sehingga saldo aktual menjadi [targetBalance].
  Future<void> adjustWalletBalance({
    required String walletId,
    required int targetBalance,
  }) async {
    await DBHelper.instance.adjustWalletBalance(
      walletId: walletId,
      targetBalance: targetBalance,
    );
  }
}

// ==============================
// LABEL SETTINGS PROVIDER
// ==============================
class LabelSettingsNotifier extends Notifier<LabelSettings> {
  @override
  LabelSettings build() => LabelSettings();

  void set(LabelSettings settings) => state = settings;
}

final labelSettingsProvider =
    NotifierProvider<LabelSettingsNotifier, LabelSettings>(
        () => LabelSettingsNotifier());

enum MenuCategory { star, plowhorse, puzzle, dog }

class MenuEngineeringItem {
  final int productId;
  final String productName;
  final int totalQty;
  final int totalProfit;
  final String? imagePath;
  final String? categoryName;
  final MenuCategory classification;

  MenuEngineeringItem({
    required this.productId,
    required this.productName,
    required this.totalQty,
    required this.totalProfit,
    this.imagePath,
    this.categoryName,
    required this.classification,
  });
}

final menuEngineeringProvider =
    FutureProvider<List<MenuEngineeringItem>>((ref) async {
  ref.watch(transactionsProvider);
  final raw = await DBHelper.instance.getMenuEngineeringData(days: 30);
  if (raw.isEmpty) return [];

  // Calculate averages for classification
  double totalQtySum = 0;
  double totalProfitSum = 0;
  for (var row in raw) {
    totalQtySum += (row['total_qty'] as num).toDouble();
    totalProfitSum += (row['total_profit'] as num).toDouble();
  }

  final avgQty = totalQtySum / raw.length;
  final avgProfit = totalProfitSum / raw.length;

  return raw.map((row) {
    final qty = (row['total_qty'] as num).toDouble();
    final profit = (row['total_profit'] as num).toDouble();

    MenuCategory cat;
    if (qty >= avgQty && profit >= avgProfit) {
      cat = MenuCategory.star;
    } else if (qty >= avgQty && profit < avgProfit) {
      cat = MenuCategory.plowhorse;
    } else if (qty < avgQty && profit >= avgProfit) {
      cat = MenuCategory.puzzle;
    } else {
      cat = MenuCategory.dog;
    }

    return MenuEngineeringItem(
      productId: row['product_id'] as int,
      productName: row['product_name'] as String,
      totalQty: (row['total_qty'] as num?)?.toInt() ?? 0,
      totalProfit: (row['total_profit'] as num?)?.toInt() ?? 0,
      imagePath: row['image_path'] as String?,
      categoryName: row['category_name'] as String?,
      classification: cat,
    );
  }).toList();
});

final categoryPerformanceProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async {
  ref.watch(transactionsProvider);
  return await DBHelper.instance.getCategoryPerformance(days: 30);
});

final paymentStatsProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async {
  ref.watch(transactionsProvider);
  return await DBHelper.instance.getPaymentMethodStats(days: 30);
});

final servisProfitSummaryProvider =
    FutureProvider<Map<String, dynamic>>((ref) async {
  ref.watch(transactionsProvider);
  return await DBHelper.instance.getservisProfitSummary(days: 30);
});

final servisDailySalesProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async {
  ref.watch(transactionsProvider);
  return await DBHelper.instance.getservisDailySalesStats(days: 30);
});




