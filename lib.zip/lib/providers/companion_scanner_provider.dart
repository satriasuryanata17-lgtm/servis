import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/scanner_server_service.dart';

const Object _scannerUnset = Object();

final scannerServerServiceProvider = Provider<ScannerServerService>((ref) {
  final service = ScannerServerService();
  ref.onDispose(() => service.stopServer());
  return service;
});

class ScannerServerState {
  final String? ipAddress;
  final int port;
  final bool isRunning;
  final bool isStarting;
  final DateTime? lastActivity;
  final List<String> connectedDevices;
  final String? authToken;
  final String? errorMessage;
  final bool autoStartEnabled;
  final bool isSettingsLoaded;
  final bool isRetryScheduled;
  final int retryAttempt;
  final DateTime? nextRetryAt;

  const ScannerServerState({
    this.ipAddress,
    this.port = 0,
    this.isRunning = false,
    this.isStarting = false,
    this.lastActivity,
    this.connectedDevices = const [],
    this.authToken,
    this.errorMessage,
    this.autoStartEnabled = true,
    this.isSettingsLoaded = false,
    this.isRetryScheduled = false,
    this.retryAttempt = 0,
    this.nextRetryAt,
  });

  ScannerServerState copyWith({
    Object? ipAddress = _scannerUnset,
    int? port,
    bool? isRunning,
    bool? isStarting,
    Object? lastActivity = _scannerUnset,
    List<String>? connectedDevices,
    Object? authToken = _scannerUnset,
    Object? errorMessage = _scannerUnset,
    bool? autoStartEnabled,
    bool? isSettingsLoaded,
    bool? isRetryScheduled,
    int? retryAttempt,
    Object? nextRetryAt = _scannerUnset,
    bool clearError = false,
    bool clearNextRetry = false,
  }) {
    return ScannerServerState(
      ipAddress: identical(ipAddress, _scannerUnset)
          ? this.ipAddress
          : ipAddress as String?,
      port: port ?? this.port,
      isRunning: isRunning ?? this.isRunning,
      isStarting: isStarting ?? this.isStarting,
      lastActivity: identical(lastActivity, _scannerUnset)
          ? this.lastActivity
          : lastActivity as DateTime?,
      connectedDevices: connectedDevices ?? this.connectedDevices,
      authToken: identical(authToken, _scannerUnset)
          ? this.authToken
          : authToken as String?,
      errorMessage: clearError
          ? null
          : (identical(errorMessage, _scannerUnset)
              ? this.errorMessage
              : errorMessage as String?),
      autoStartEnabled: autoStartEnabled ?? this.autoStartEnabled,
      isSettingsLoaded: isSettingsLoaded ?? this.isSettingsLoaded,
      isRetryScheduled: isRetryScheduled ?? this.isRetryScheduled,
      retryAttempt: retryAttempt ?? this.retryAttempt,
      nextRetryAt: clearNextRetry
          ? null
          : (identical(nextRetryAt, _scannerUnset)
              ? this.nextRetryAt
              : nextRetryAt as DateTime?),
    );
  }
}

final companionScannerStateProvider =
    NotifierProvider<CompanionScannerNotifier, ScannerServerState>(() {
  return CompanionScannerNotifier();
});

class CompanionScannerNotifier extends Notifier<ScannerServerState> {
  static const _tokenPrefKey = 'remote_scanner_auth_token';
  static const _autoStartPrefKey = 'remote_scanner_host_auto_start';
  static final Random _random = Random.secure();

  Future<void>? _hydrateFuture;
  Timer? _retryTimer;
  bool _desiredHostActive = false;

  @override
  ScannerServerState build() {
    final service = ref.watch(scannerServerServiceProvider);
    ref.onDispose(() {
      _retryTimer?.cancel();
      service.stopServer();
    });
    _hydrateFuture ??= _hydrateSettings();
    return const ScannerServerState();
  }

  void updateActivity() {
    state = state.copyWith(lastActivity: DateTime.now());
  }

  void addDevice(String name) {
    if (!state.connectedDevices.contains(name)) {
      state = state.copyWith(
        lastActivity: DateTime.now(),
        connectedDevices: [...state.connectedDevices, name],
      );
    }
  }

  void removeDevice(String name) {
    state = state.copyWith(
      connectedDevices: state.connectedDevices.where((d) => d != name).toList(),
    );
  }

  Future<void> _hydrateSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final autoStart = prefs.getBool(_autoStartPrefKey) ?? true;
    final existingToken = prefs.getString(_tokenPrefKey)?.trim();

    state = state.copyWith(
      autoStartEnabled: autoStart,
      isSettingsLoaded: true,
      authToken: (existingToken == null || existingToken.isEmpty)
          ? null
          : existingToken,
    );
  }

  Future<void> _ensureHydrated() async {
    _hydrateFuture ??= _hydrateSettings();
    await _hydrateFuture;
  }

  Future<void> setAutoStartEnabled(bool enabled) async {
    await _ensureHydrated();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_autoStartPrefKey, enabled);

    state = state.copyWith(autoStartEnabled: enabled, clearError: true);

    if (!enabled) {
      stopServer(clearError: true);
      return;
    }

    if (_desiredHostActive) {
      unawaited(startServer());
    }
  }

  Future<void> syncHostSession({required bool shouldBeActive}) async {
    _desiredHostActive = shouldBeActive;
    await _ensureHydrated();

    if (!shouldBeActive) {
      stopServer(clearError: true);
      return;
    }

    if (state.autoStartEnabled) {
      unawaited(startServer());
    }
  }

  Future<bool> startServer({bool force = false}) async {
    await _ensureHydrated();

    if (!Platform.isWindows && !Platform.isLinux && !Platform.isMacOS) {
      state = state.copyWith(
        isRunning: false,
        isStarting: false,
        errorMessage: 'Host scanner remote hanya tersedia di desktop.',
      );
      return false;
    }

    if (!force && (!_desiredHostActive || !state.autoStartEnabled)) {
      return false;
    }

    if (state.isStarting) return false;

    final service = ref.read(scannerServerServiceProvider);
    if (service.isRunning && state.isRunning) {
      return true;
    }

    _retryTimer?.cancel();
    _retryTimer = null;

    state = state.copyWith(
      isStarting: true,
      isRetryScheduled: false,
      clearNextRetry: true,
      clearError: true,
    );

    try {
      final token = await _loadOrCreateAuthToken();
      final started = await service.startServer(authToken: token);
      final ip = started ? await service.getLocalIp() : null;

      if (!started || ip == null || ip.trim().isEmpty || service.port <= 0) {
        state = state.copyWith(
          ipAddress: null,
          port: 0,
          isRunning: false,
          isStarting: false,
          connectedDevices: const [],
          authToken: token,
          isRetryScheduled: false,
          clearNextRetry: true,
          errorMessage:
              'Server remote scanner gagal diaktifkan. Pastikan port tersedia dan firewall mengizinkan koneksi lokal.',
        );
        _scheduleRetryIfNeeded();
        return false;
      }

      state = state.copyWith(
        ipAddress: ip,
        port: service.port,
        isRunning: true,
        isStarting: false,
        connectedDevices: const [],
        authToken: token,
        isRetryScheduled: false,
        retryAttempt: 0,
        clearNextRetry: true,
        clearError: true,
      );
      return true;
    } catch (_) {
      state = state.copyWith(
        ipAddress: null,
        port: 0,
        isRunning: false,
        isStarting: false,
        connectedDevices: const [],
        isRetryScheduled: false,
        clearNextRetry: true,
        errorMessage:
            'Startup remote scanner mengalami kegagalan tak terduga. Periksa izin jaringan lokal dan firewall.',
      );
      _scheduleRetryIfNeeded();
      return false;
    }
  }

  void _scheduleRetryIfNeeded() {
    if (!_desiredHostActive || !state.autoStartEnabled) {
      return;
    }

    final nextAttempt = state.retryAttempt + 1;
    const retrySteps = <int>[2, 5, 10, 20, 30];
    final seconds = retrySteps[min(nextAttempt - 1, retrySteps.length - 1)];
    final retryAt = DateTime.now().add(Duration(seconds: seconds));

    _retryTimer?.cancel();
    state = state.copyWith(
      isRetryScheduled: true,
      retryAttempt: nextAttempt,
      nextRetryAt: retryAt,
    );

    _retryTimer = Timer(Duration(seconds: seconds), () {
      _retryTimer = null;
      if (_desiredHostActive && state.autoStartEnabled) {
        unawaited(startServer());
      }
    });
  }

  void stopServer({bool clearError = false}) {
    final service = ref.read(scannerServerServiceProvider);
    _retryTimer?.cancel();
    _retryTimer = null;
    service.stopServer();
    state = state.copyWith(
      ipAddress: null,
      port: 0,
      isRunning: false,
      isStarting: false,
      connectedDevices: const [],
      isRetryScheduled: false,
      retryAttempt: 0,
      clearNextRetry: true,
      clearError: clearError,
    );
  }

  Future<bool> restartServer({bool force = true}) async {
    stopServer(clearError: true);
    return startServer(force: force);
  }

  Future<bool> startManually() async {
    return startServer(force: true);
  }

  Future<String> _loadOrCreateAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    final cached = state.authToken?.trim() ?? '';
    if (cached.isNotEmpty) {
      return cached;
    }

    final existing = prefs.getString(_tokenPrefKey)?.trim() ?? '';
    if (existing.isNotEmpty) {
      state = state.copyWith(authToken: existing);
      return existing;
    }

    final bytes = List<int>.generate(24, (_) => _random.nextInt(256));
    final token = base64UrlEncode(bytes).replaceAll('=', '');
    await prefs.setString(_tokenPrefKey, token);
    state = state.copyWith(authToken: token);
    return token;
  }
}

final remoteBarcodeStreamProvider = Provider<Stream<String>>((ref) {
  final service = ref.watch(scannerServerServiceProvider);
  return service.barcodeStream.where((barcode) {
    if (barcode.startsWith("__CONNECT__:")) {
      final name = barcode.substring(12);
      ref.read(companionScannerStateProvider.notifier).addDevice(name);
      return false;
    }
    if (barcode.startsWith("__DISCONNECT__:")) {
      final name = barcode.substring(15);
      ref.read(companionScannerStateProvider.notifier).removeDevice(name);
      return false;
    }

    ref.read(companionScannerStateProvider.notifier).updateActivity();
    return true;
  });
});

