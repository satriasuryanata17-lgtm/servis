import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum ShortcutAction {
  checkout,
  quickPayPas,
  holdTransaction,
  clearCart,
  focusSearch,
  nextCategory,
  prevCategory,
  selectCustomer,
  printLast,
  goToCashier,
}

class ShortcutMapping {
  final ShortcutAction action;
  final LogicalKeyboardKey key;

  ShortcutMapping(this.action, this.key);

  Map<String, dynamic> toJson() => {
        'action': action.name,
        'keyId': key.keyId,
      };

  factory ShortcutMapping.fromJson(Map<String, dynamic> json) {
    return ShortcutMapping(
      ShortcutAction.values.firstWhere((e) => e.name == json['action']),
      LogicalKeyboardKey(json['keyId']),
    );
  }
}

// Signal provider for events triggered by shortcuts
final shortcutSignalProvider =
    NotifierProvider<ShortcutSignalNotifier, ShortcutAction?>(() {
  return ShortcutSignalNotifier();
});

class ShortcutSignalNotifier extends Notifier<ShortcutAction?> {
  @override
  ShortcutAction? build() => null;

  void trigger(ShortcutAction action) {
    state = action;
    // Reset after a short delay so it can be triggered again
    Future.delayed(const Duration(milliseconds: 100), () {
      if (state == action) {
        state = null;
      }
    });
  }

  void clear() {
    state = null;
  }
}

final shortcutProvider =
    NotifierProvider<ShortcutNotifier, Map<ShortcutAction, LogicalKeyboardKey>>(
        () {
  return ShortcutNotifier();
});

class ShortcutNotifier
    extends Notifier<Map<ShortcutAction, LogicalKeyboardKey>> {
  static const String _prefKey = 'keyboard_shortcuts_map';

  @override
  Map<ShortcutAction, LogicalKeyboardKey> build() {
    Future<void>.microtask(_loadFromPrefs);
    return {
      ShortcutAction.checkout: LogicalKeyboardKey.enter,
      ShortcutAction.quickPayPas: LogicalKeyboardKey.f4,
      ShortcutAction.holdTransaction: LogicalKeyboardKey.f3,
      ShortcutAction.clearCart: LogicalKeyboardKey.escape,
      ShortcutAction.focusSearch: LogicalKeyboardKey.f1,
      ShortcutAction.nextCategory: LogicalKeyboardKey.tab,
      ShortcutAction.prevCategory: LogicalKeyboardKey.tab,
      ShortcutAction.selectCustomer: LogicalKeyboardKey.f2,
      ShortcutAction.printLast: LogicalKeyboardKey.f12,
      ShortcutAction.goToCashier: LogicalKeyboardKey.space,
    };
  }

  Future<void> _loadFromPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final data = prefs.getString(_prefKey);
      if (data != null) {
        final Map<String, dynamic> json = jsonDecode(data);
        final newState = <ShortcutAction, LogicalKeyboardKey>{};
        json.forEach((key, value) {
          try {
            final action =
                ShortcutAction.values.firstWhere((e) => e.name == key);
            newState[action] = LogicalKeyboardKey(value as int);
          } catch (_) {}
        });
        if (newState.isNotEmpty) {
          state = {...state, ...newState};
        }
      }
    } catch (_) {}
  }

  Future<void> updateShortcut(
      ShortcutAction action, LogicalKeyboardKey key) async {
    state = {...state, action: key};
    _saveToPrefs();
  }

  Future<void> resetToDefaults() async {
    state = {
      ShortcutAction.checkout: LogicalKeyboardKey.enter,
      ShortcutAction.quickPayPas: LogicalKeyboardKey.f4,
      ShortcutAction.holdTransaction: LogicalKeyboardKey.f3,
      ShortcutAction.clearCart: LogicalKeyboardKey.escape,
      ShortcutAction.focusSearch: LogicalKeyboardKey.f1,
      ShortcutAction.nextCategory: LogicalKeyboardKey.tab,
      ShortcutAction.prevCategory: LogicalKeyboardKey.tab,
      ShortcutAction.selectCustomer: LogicalKeyboardKey.f2,
      ShortcutAction.printLast: LogicalKeyboardKey.f12,
      ShortcutAction.goToCashier: LogicalKeyboardKey.space,
    };
    _saveToPrefs();
  }

  Future<void> _saveToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonMap = <String, int>{};
    state.forEach((action, key) {
      jsonMap[action.name] = key.keyId;
    });
    await prefs.setString(_prefKey, jsonEncode(jsonMap));
  }

  void triggerAction(ShortcutAction action) {
    ref.read(shortcutSignalProvider.notifier).trigger(action);
  }
}

// Helper to get human readable key name
String getReadableKeyName(LogicalKeyboardKey key) {
  if (key == LogicalKeyboardKey.enter) return "ENTER";
  if (key == LogicalKeyboardKey.numpadEnter) return "NUMPAD ENTER";
  if (key == LogicalKeyboardKey.tab) return "TAB";
  if (key == LogicalKeyboardKey.space) return "SPACE";
  if (key == LogicalKeyboardKey.escape) return "ESC";

  return key.keyLabel.toUpperCase();
}

