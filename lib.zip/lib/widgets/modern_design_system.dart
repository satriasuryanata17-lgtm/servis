import 'package:flutter/material.dart';
import '../core/theme.dart';

///
/// - MODERN & FLAT DESIGN UTILITIES
///
/// Semua komponen menggunakan:
/// - Border radius FLAT (0 atau minimal)
/// - Shadow tipis untuk kedalaman
/// - Color dari theme yang sudah defined
/// - Padding/margin yang konsisten
///

//
// MODERN SHAPE UTILITIES
//

class ModernShapes {
  /// Flat card dengan subtle shadow
  static ShapeDecoration cardFlat({Color? bgColor}) => ShapeDecoration(
        color: bgColor ?? AppColors.surface,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        shadows: AppShadow.card,
      );

  /// Flat button dengan subtle shadow
  static ShapeDecoration buttonFlat({Color? bgColor}) => ShapeDecoration(
        color: bgColor ?? AppColors.primary,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        shadows: [
          BoxShadow(
            color: (bgColor ?? AppColors.primary).withValues(alpha: 0.15),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      );

  /// Flat input field style
  static InputDecoration fieldFlat({
    required String label,
    String? hint,
    IconData? icon,
    Widget? prefix,
    Widget? suffix,
  }) =>
      InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: AppColors.surfaceDim,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: AppColors.divider),
        ),
        enabledBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: AppColors.divider),
        ),
        focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: AppColors.primary, width: 1.5),
        ),
        errorBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: AppColors.danger),
        ),
        focusedErrorBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: AppColors.danger, width: 1.5),
        ),
        prefixIcon:
            icon != null ? Icon(icon, color: AppColors.textCaption) : prefix,
        suffixIcon: suffix,
        labelStyle: AppText.body.copyWith(color: AppColors.textCaption),
        hintStyle: AppText.body.copyWith(color: AppColors.textCaption),
      );
}

//
// MODERN BUTTON STYLES
//

/// Flat professional button
class ModernButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final Color? bgColor;
  final Color? textColor;
  final bool isLoading;
  final Widget? icon;
  final bool isFullWidth;
  final EdgeInsets? padding;

  const ModernButton({
    super.key,
    required this.label,
    this.onPressed,
    this.bgColor,
    this.textColor,
    this.isLoading = false,
    this.icon,
    this.isFullWidth = false,
    this.padding,
  });

  @override
  State<ModernButton> createState() => _ModernButtonState();
}

class _ModernButtonState extends State<ModernButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 80),
      lowerBound: 0.96,
      upperBound: 1.0,
      value: 1.0,
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: widget.onPressed != null ? (_) => _ctrl.reverse() : null,
      onTapUp: widget.onPressed != null
          ? (_) {
              _ctrl.forward();
              widget.onPressed!();
            }
          : null,
      onTapCancel: () => _ctrl.forward(),
      child: ScaleTransition(
        scale: _ctrl,
        child: Container(
          width: widget.isFullWidth ? double.infinity : null,
          padding: widget.padding ??
              const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          decoration: BoxDecoration(
            color: widget.bgColor ?? AppColors.primary,
            borderRadius: BorderRadius.zero,
            boxShadow: widget.onPressed != null
                ? [
                    BoxShadow(
                      color: (widget.bgColor ?? AppColors.primary)
                          .withValues(alpha: 0.15),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : [],
          ),
          child: Row(
            mainAxisSize:
                widget.isFullWidth ? MainAxisSize.max : MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (widget.icon != null) ...[
                widget.icon!,
                const SizedBox(width: 8),
              ],
              if (widget.isLoading)
                const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                )
              else
                Text(
                  widget.label,
                  style: AppText.h3.copyWith(
                    color: widget.textColor ?? Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Flat secondary button
class ModernSecondaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final Color? bgColor;
  final Color? textColor;
  final Widget? icon;

  const ModernSecondaryButton({
    super.key,
    required this.label,
    this.onPressed,
    this.bgColor,
    this.textColor,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: bgColor ?? AppColors.background,
          border: Border.all(color: AppColors.divider),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              icon!,
              const SizedBox(width: 8),
            ],
            Text(
              label,
              style: AppText.body.copyWith(
                color: textColor ?? AppColors.textTitle,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//
// MODERN CARD COMPONENTS
//

/// Flat info card dengan icon
class ModernInfoCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color iconBgColor;
  final Color iconColor;
  final VoidCallback? onTap;

  const ModernInfoCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    this.iconBgColor = AppColors.iconBlueBg,
    this.iconColor = AppColors.iconBlue,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.zero,
          boxShadow: AppShadow.card,
          border: Border.all(color: AppColors.divider, width: 0.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(title, style: AppText.caption),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: iconBgColor,
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Icon(icon, color: iconColor, size: 18),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(value, style: AppText.h2),
          ],
        ),
      ),
    );
  }
}

/// Flat list tile modern
class ModernListTile extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? leading;
  final Widget? trailing;
  final VoidCallback? onTap;
  final Color? bgColor;

  const ModernListTile({
    super.key,
    required this.title,
    this.subtitle,
    this.leading,
    this.trailing,
    this.onTap,
    this.bgColor,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgColor ?? AppColors.surface,
          borderRadius: BorderRadius.zero,
          border: const Border(bottom: BorderSide(color: AppColors.divider)),
        ),
        child: Row(
          children: [
            if (leading != null) ...[
              leading!,
              const SizedBox(width: 12),
            ],
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: AppText.body),
                  if (subtitle != null) ...[
                    const SizedBox(height: 4),
                    Text(subtitle!, style: AppText.caption),
                  ],
                ],
              ),
            ),
            if (trailing != null) ...[
              const SizedBox(width: 12),
              trailing!,
            ],
          ],
        ),
      ),
    );
  }
}

//
// MODERN DIALOG
//

void showModernDialog({
  required BuildContext context,
  required String title,
  required String content,
  String? confirmText,
  String? cancelText,
  VoidCallback? onConfirm,
  VoidCallback? onCancel,
  bool isDanger = false,
}) {
  showDialog(
    context: context,
    builder: (ctx) => Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.zero,
          boxShadow: AppShadow.card,
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: AppText.h2),
            const SizedBox(height: 12),
            Text(content, style: AppText.body),
            const SizedBox(height: 24),
            Align(
              alignment: Alignment.centerRight,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (cancelText != null)
                    ModernSecondaryButton(
                      label: cancelText,
                      onPressed: () {
                        Navigator.pop(ctx);
                        onCancel?.call();
                      },
                    ),
                  if (cancelText != null) const SizedBox(width: 12),
                  ModernButton(
                    label: confirmText ?? 'OK',
                    onPressed: () {
                      Navigator.pop(ctx);
                      onConfirm?.call();
                    },
                    bgColor: isDanger ? AppColors.danger : AppColors.primary,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

//
// MODERN BOTTOM SHEET
//

void showModernBottomSheet({
  required BuildContext context,
  required String title,
  required Widget body,
  VoidCallback? onClose,
}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.zero,
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle bar
            Padding(
              padding: const EdgeInsets.only(top: 12, bottom: 16),
              child: Container(
                width: 40,
                height: 4,
                decoration: const BoxDecoration(
                  color: AppColors.divider,
                  borderRadius: BorderRadius.zero,
                ),
              ),
            ),
            // Title
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Text(title, style: AppText.h2),
            ),
            const SizedBox(height: 16),
            // Body
            Flexible(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  24,
                  0,
                  24,
                  MediaQuery.of(ctx).viewInsets.bottom + 24,
                ),
                child: body,
              ),
            ),
          ],
        ),
      ),
    ),
  ).then((_) => onClose?.call());
}

//
// MODERN APP BAR
//

AppBar buildModernAppBar({
  required String title,
  bool showLeading = true,
  List<Widget>? actions,
  Color? bgColor,
  PreferredSizeWidget? bottom,
}) {
  return AppBar(
    title: Text(title, style: AppText.h2),
    backgroundColor: bgColor ?? AppColors.surface,
    elevation: 0,
    surfaceTintColor: Colors.transparent,
    leading: showLeading ? const BackButton(color: AppColors.textTitle) : null,
    actions: actions,
    bottom: bottom,
    shape: const Border(
      bottom: BorderSide(color: AppColors.divider, width: 0.5),
    ),
  );
}

//
// MODERN SECTION HEADER
//

class ModernSectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final VoidCallback? onViewAll;

  const ModernSectionHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.onViewAll,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: AppText.h2),
                if (subtitle != null) ...[
                  const SizedBox(height: 4),
                  Text(subtitle!, style: AppText.caption),
                ],
              ],
            ),
            if (onViewAll != null)
              GestureDetector(
                onTap: onViewAll,
                child: Text(
                  'Lihat Semua',
                  style: AppText.body.copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 16),
      ],
    );
  }
}

