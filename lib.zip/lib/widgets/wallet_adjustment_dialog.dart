import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../core/theme.dart';
import '../screens/arus_kas_screen.dart';
import 'admin_pin_dialog.dart';
import '../utils/currency_input_formatter.dart';

class WalletAdjustmentDialog {
  static Future<void> show(BuildContext context, WidgetRef ref) async {
    // 1. Verify PIN
    final pinOk = await AdminPinDialog.show(
      context,
      verifyPin: (pin) {
        final profilNotifier = ref.read(profilProvider.notifier);
        if (!profilNotifier.hasConfiguredAdminPin) {
          return 'PIN admin belum diatur. Buka Pengaturan Profil.';
        }
        final ok = profilNotifier.verifyPin(pin);
        return ok ? '' : 'PIN salah';
      },
      title: 'Koreksi Saldo Buku Kas',
      subtitle: 'Masukkan PIN Admin untuk menyesuaikan saldo Buku Kas Usaha',
    );
    if (!pinOk || !context.mounted) return;

    // 2. Show adjustment dialog
    final tunai =
        ref.read(walletBalanceByIdProvider('tunai')).asData?.value ?? 0;
    final nonTunai =
        ref.read(walletBalanceByIdProvider('non_tunai')).asData?.value ?? 0;

    final tunaiCtrl = TextEditingController(text: formatCurrencyInput(tunai));
    final nonTunaiCtrl =
        TextEditingController(text: formatCurrencyInput(nonTunai));

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.orange.shade50,
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Icon(Icons.tune_rounded,
                        color: Colors.orange.shade700, size: 22),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Koreksi Saldo Buku Kas',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w700)),
                        Text(
                            'Untuk pembukuan Buku Kas Usaha, bukan Kas Shift fisik di laci.',
                            style:
                                TextStyle(fontSize: 12, color: Colors.black45)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _AdjustField(
                  label: 'Saldo Kas Tunai Sebenarnya',
                  ctrl: tunaiCtrl,
                  current: tunai),
              const SizedBox(height: 14),
              _AdjustField(
                  label: 'Saldo Kas Non-Tunai Sebenarnya',
                  ctrl: nonTunaiCtrl,
                  current: nonTunai),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.black54,
                        side: const BorderSide(color: Color(0xFFD0D5DD)),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                      ),
                      child: const Text('Batal'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                      ),
                      child: const Text('Sesuaikan',
                          style: TextStyle(fontWeight: FontWeight.w600)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (confirmed != true || !context.mounted) return;

    final newTunai = tunaiCtrl.text.trim().isEmpty
        ? tunai
        : parseCurrencyInput(tunaiCtrl.text);
    final newNonTunai = nonTunaiCtrl.text.trim().isEmpty
        ? nonTunai
        : parseCurrencyInput(nonTunaiCtrl.text);

    try {
      if (newTunai != tunai) {
        await ref.read(profilProvider.notifier).adjustWalletBalance(
              walletId: 'tunai',
              targetBalance: newTunai,
            );
      }
      if (newNonTunai != nonTunai) {
        await ref.read(profilProvider.notifier).adjustWalletBalance(
              walletId: 'non_tunai',
              targetBalance: newNonTunai,
            );
      }

      // Refresh providers
      ref.invalidate(walletBalanceProvider);
      ref.invalidate(walletTransactionsProvider);
      ref.invalidate(walletBalanceByIdProvider('tunai'));
      ref.invalidate(walletBalanceByIdProvider('non_tunai'));
      ref.invalidate(drawerCashProvider); // Add for dashboard compatibility

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Saldo berhasil disesuaikan'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ));
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Gagal menyesuaikan saldo. Silakan coba lagi.'),
          backgroundColor: AppColors.danger,
        ));
      }
    }
  }
}

class _AdjustField extends StatelessWidget {
  final String label;
  final TextEditingController ctrl;
  final int current;

  const _AdjustField(
      {required this.label, required this.ctrl, required this.current});

  String _fmtRp(int v) {
    final s = v.abs().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp${v < 0 ? '-' : ''}$buf';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(label,
                style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: Colors.black54)),
            const Spacer(),
            Text('Saat ini: ${_fmtRp(current)}',
                style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
          ],
        ),
        const SizedBox(height: 6),
        TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          inputFormatters: const [CurrencyInputFormatter()],
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
          decoration: const InputDecoration(
            prefixText: 'Rp ',
            border: OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFD0D5DD))),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFD0D5DD))),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide:
                    BorderSide(color: AppColors.primaryBrand, width: 1.5)),
            contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
      ],
    );
  }
}

