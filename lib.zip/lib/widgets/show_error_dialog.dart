import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Specialized dialog for professional error reporting.
/// Designed to be "premium", "flat", and "modern" as per user request.
class KasirErrorDialog extends StatelessWidget {
  final String title;
  final String message;
  final String buttonLabel;

  const KasirErrorDialog({
    super.key,
    required this.title,
    required this.message,
    this.buttonLabel = 'Tutup',
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      elevation: 0,
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 40),
      child: Container(
        padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.zero,
          boxShadow: Sh.md,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            //  ICON
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.danger.withValues(alpha: 0.1),
                shape: BoxShape.rectangle,
              ),
              child: const Icon(
                Icons.cancel_rounded,
                color: AppColors.danger,
                size: 54,
              ),
            ),
            const SizedBox(height: 24),

            //  TITLE
            Text(
              title,
              textAlign: TextAlign.center,
              style: AppText.h2.copyWith(
                color: AppColors.textTitle,
                fontSize: 22,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 12),

            //  MESSAGE
            Text(
              message,
              textAlign: TextAlign.center,
              style: AppText.bodySmall.copyWith(
                color: AppColors.textBody.withValues(alpha: 0.7),
                fontSize: 14,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 32),

            //  BUTTON
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBrand,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero,
                  ),
                ),
                child: Text(
                  buttonLabel,
                  style: AppText.h3.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Helper function to show the professional error dialog.
Future<void> showKasirErrorDialog(
  BuildContext context, {
  required String title,
  required String message,
  String buttonLabel = 'Tutup',
}) {
  return showGeneralDialog(
    context: context,
    barrierDismissible: true,
    barrierLabel: '',
    barrierColor: Colors.black.withValues(alpha: 0.4),
    transitionDuration: const Duration(milliseconds: 250),
    pageBuilder: (ctx, anim1, anim2) => KasirErrorDialog(
      title: title,
      message: message,
      buttonLabel: buttonLabel,
    ),
    transitionBuilder: (ctx, anim1, anim2, child) {
      final curve = Curves.easeOutBack.transform(anim1.value);
      return Transform.scale(
        scale: curve,
        child: FadeTransition(
          opacity: anim1,
          child: child,
        ),
      );
    },
  );
}

