import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:barcode_widget/barcode_widget.dart';
import '../models/db_models.dart';

class LabelPreviewWidget extends StatelessWidget {
  final LabelSettings settings;
  final Product sampleProduct;

  const LabelPreviewWidget({
    super.key,
    required this.settings,
    required this.sampleProduct,
  });

  @override
  Widget build(BuildContext context) {
    // Kertas 58mm = ~220px, 80mm = ~300px
    final double width = settings.paperSizeMm == 58 ? 220 : 300;

    TextAlign txtAlign;
    if (settings.priceAlign == 'left') {
      txtAlign = TextAlign.left;
    } else if (settings.priceAlign == 'right') {
      txtAlign = TextAlign.right;
    } else {
      txtAlign = TextAlign.center;
    }

    // Ukuran font
    double nameSize = 14;
    double priceSize = 20;
    if (settings.fontSize == 'small') {
      nameSize = 12;
      priceSize = 16;
    }
    if (settings.fontSize == 'large') {
      nameSize = 16;
      priceSize = 26;
    }

    return Container(
      width: width,
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
            color: Colors.grey.shade400, width: 1.5, style: BorderStyle.solid),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 5,
              offset: const Offset(2, 2))
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: settings.priceAlign == 'left'
            ? CrossAxisAlignment.start
            : (settings.priceAlign == 'right'
                ? CrossAxisAlignment.end
                : CrossAxisAlignment.center),
        children: [
          if (settings.showStoreName) ...[
            Text(settings.storeName,
                style:
                    const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                textAlign: txtAlign),
            const SizedBox(height: 6),
          ],
          if (settings.showName) ...[
            Text(sampleProduct.name,
                style:
                    TextStyle(fontSize: nameSize, fontWeight: FontWeight.bold),
                textAlign: txtAlign),
            const SizedBox(height: 4),
          ],
          if (settings.showPrice) ...[
            Text('Rp ${_fmtNumber(sampleProduct.sellPrice)}',
                style:
                    TextStyle(fontSize: priceSize, fontWeight: FontWeight.w900),
                textAlign: txtAlign),
            const SizedBox(height: 6),
          ],
          if (settings.showSku &&
              sampleProduct.sku != null &&
              sampleProduct.sku!.isNotEmpty) ...[
            Text('SKU: ${sampleProduct.sku}',
                style: const TextStyle(fontSize: 10), textAlign: txtAlign),
            const SizedBox(height: 4),
          ],
          if (settings.showBarcode) ...[
            const SizedBox(height: 4),
            if (sampleProduct.barcode != null &&
                sampleProduct.barcode!.isNotEmpty)
              SizedBox(
                width: width * 0.8,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 4, vertical: 2),
                      color: Colors.white,
                      child: BarcodeWidget(
                        barcode: Barcode
                            .code128(), // ESC/POS natively uses Code128 mostly
                        data: sampleProduct.barcode!,
                        height: 40,
                        drawText: false,
                        errorBuilder: (context, error) => const Center(
                            child: Text('Barcode Invalid',
                                style: TextStyle(
                                    color: Colors.red, fontSize: 10))),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      sampleProduct.barcode!,
                      style: const TextStyle(
                          fontSize: 11,
                          letterSpacing: 4,
                          fontWeight: FontWeight.w800),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              )
            else
              Container(
                height: 40,
                width: width * 0.8,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.zero,
                  border: Border.all(
                      color: Colors.grey.shade400, style: BorderStyle.solid),
                ),
                alignment: Alignment.center,
                child: const Text('BARCODE KOSONG',
                    style: TextStyle(
                        color: Colors.black45,
                        fontSize: 10,
                        fontWeight: FontWeight.bold)),
              ),
            const SizedBox(height: 4),
          ],
          if (settings.showDate) ...[
            const SizedBox(height: 4),
            Text(DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now()),
                style: const TextStyle(fontSize: 9), textAlign: txtAlign),
          ]
        ],
      ),
    );
  }

  String _fmtNumber(int number) {
    final s = number.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }
}

