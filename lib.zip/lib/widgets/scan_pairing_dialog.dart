import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:barcode_widget/barcode_widget.dart' as bw;
import '../providers/companion_scanner_provider.dart';
import '../core/theme.dart';

class ScanPairingDialog extends ConsumerWidget {
  const ScanPairingDialog({super.key});

  static void show(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => const ScanPairingDialog(),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(companionScannerStateProvider);
    final notifier = ref.read(companionScannerStateProvider.notifier);
    const brandColor = AppColors.primaryBrand;

    if (!state.isRunning ||
        state.ipAddress == null ||
        state.authToken == null) {
      return _buildDialogFrame(
        context: context,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              state.isStarting
                  ? Icons.sync_rounded
                  : Icons.error_outline_rounded,
              size: 48,
              color: state.isStarting ? brandColor : Colors.orange,
            ),
            const SizedBox(height: 16),
            Text(
              state.isStarting ? 'Mengaktifkan Server' : 'Server Belum Siap',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              state.errorMessage ??
                  'Layanan scanner remote belum aktif. Aktifkan server dari dialog ini lalu scan ulang QR pairing.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black54),
            ),
            if (state.isRetryScheduled && state.nextRetryAt != null) ...[
              const SizedBox(height: 8),
              Text(
                'Akan coba lagi otomatis sekitar ${state.nextRetryAt!.hour.toString().padLeft(2, '0')}:${state.nextRetryAt!.minute.toString().padLeft(2, '0')}:${state.nextRetryAt!.second.toString().padLeft(2, '0')}',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.orange,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
            if (state.isStarting) ...[
              const SizedBox(height: 16),
              const CircularProgressIndicator(color: brandColor),
            ],
            const SizedBox(height: 16),
            _autoStartTile(state, notifier),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: state.isStarting
                    ? null
                    : () async {
                        await notifier.restartServer(force: true);
                      },
                style: ElevatedButton.styleFrom(
                  backgroundColor: brandColor,
                  foregroundColor: Colors.white,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
                child: Text(
                  state.isStarting ? 'Mengaktifkan...' : 'Aktifkan Server',
                ),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () => Navigator.pop(context),
                style: OutlinedButton.styleFrom(
                  foregroundColor: brandColor,
                  side: const BorderSide(color: brandColor),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
                child: const Text('Tutup'),
              ),
            ),
          ],
        ),
      );
    }

    final qrData = jsonEncode({
      'action': 'connect_scanner',
      'protocol_version': 2,
      'ip': state.ipAddress,
      'port': state.port,
      'token': state.authToken,
    });

    return _buildDialogFrame(
      context: context,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.qr_code_scanner, size: 40, color: brandColor),
          const SizedBox(height: 12),
          const Text(
            'Hubungkan HP Sebagai Scanner',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          const Text(
            'Scan QR Code ini dari menu "Pemindai Remote" di aplikasi HP untuk menyambungkan HP sebagai pemindai barcode nirkabel.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black54, fontSize: 13),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.grey.shade100),
            ),
            child: bw.BarcodeWidget(
              barcode: bw.Barcode.qrCode(),
              data: qrData,
              width: 200,
              height: 200,
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Text(
              'ALAMAT IP: ${state.ipAddress}:${state.port}',
              style: const TextStyle(
                fontFamily: 'monospace',
                fontWeight: FontWeight.bold,
                color: brandColor,
                fontSize: 12,
              ),
            ),
          ),
          const SizedBox(height: 16),
          _autoStartTile(state, notifier),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: state.isStarting
                      ? null
                      : () => notifier.restartServer(force: true),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: brandColor,
                    side: const BorderSide(color: brandColor),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                  icon: const Icon(Icons.refresh_rounded, size: 18),
                  label: const Text('Restart Server'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              border: Border.all(color: Colors.blue.shade100),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.usb_rounded,
                        size: 16, color: Colors.blue.shade800),
                    const SizedBox(width: 8),
                    Text(
                      'TIPS: TANPA WIFI?',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue.shade800,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                const Text(
                  'Gunakan kabel USB & aktifkan "USB Tethering" di pengaturan HP jika tidak ada WiFi. Pastikan QR di atas sudah berubah sesuai IP kabel sebelum di-scan.',
                  style: TextStyle(
                      fontSize: 11, color: Colors.blueGrey, height: 1.4),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () => Navigator.pop(context),
              style: OutlinedButton.styleFrom(
                foregroundColor: brandColor,
                side: const BorderSide(color: brandColor),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: const Text('Tutup'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDialogFrame({
    required BuildContext context,
    required Widget child,
  }) {
    final screenHeight = MediaQuery.of(context).size.height;
    final double maxHeight =
        (screenHeight - 48).clamp(280.0, screenHeight).toDouble();

    return Dialog(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      backgroundColor: Colors.white,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: 450,
          maxHeight: maxHeight,
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: SizedBox(width: double.infinity, child: child),
        ),
      ),
    );
  }

  Widget _autoStartTile(
    ScannerServerState state,
    CompanionScannerNotifier notifier,
  ) {
    const brandColor = AppColors.primaryBrand;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Mulai Otomatis di Desktop',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 2),
                Text(
                  'Server scanner remote akan aktif otomatis setelah login desktop.',
                  style: TextStyle(fontSize: 11, color: Colors.black54),
                ),
              ],
            ),
          ),
          Switch(
            value: state.autoStartEnabled,
            onChanged: (value) => notifier.setAutoStartEnabled(value),
            activeThumbColor: brandColor,
          ),
        ],
      ),
    );
  }
}

