import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../database/db_helper.dart';
import '../../models/db_models.dart';

class SupplierFormSheet extends StatefulWidget {
  final Supplier? supplier;
  final Function(Supplier)? onSaved;

  const SupplierFormSheet({super.key, this.supplier, this.onSaved});

  @override
  State<SupplierFormSheet> createState() => _SupplierFormSheetState();
}

class _SupplierFormSheetState extends State<SupplierFormSheet> {
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _keteranganCtrl = TextEditingController();
  bool _saving = false;

  final Color _kBrand = AppColors.primaryBrand;
  final Color _kBrandLight = AppColors.primaryBrand.withValues(alpha: 0.08);

  @override
  void initState() {
    super.initState();
    if (widget.supplier != null) {
      _nameCtrl.text = widget.supplier!.name;
      _phoneCtrl.text = widget.supplier!.phone ?? '';
      _addressCtrl.text = widget.supplier!.address ?? '';
      _keteranganCtrl.text = widget.supplier!.keterangan ?? '';
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _addressCtrl.dispose();
    _keteranganCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) return;
    setState(() => _saving = true);

    final s = Supplier(
      id: widget.supplier?.id,
      name: name,
      phone: _phoneCtrl.text.trim().isEmpty ? null : _phoneCtrl.text.trim(),
      address:
          _addressCtrl.text.trim().isEmpty ? null : _addressCtrl.text.trim(),
      keterangan: _keteranganCtrl.text.trim().isEmpty
          ? null
          : _keteranganCtrl.text.trim(),
      hutang: widget.supplier?.hutang ?? 0,
      createdAt: widget.supplier?.createdAt ?? DateTime.now().toIso8601String(),
    );

    if (widget.supplier == null) {
      final id = await DBHelper.instance.insertSupplier(s);
      final newSupplier = s.copyWith(id: id);
      widget.onSaved?.call(newSupplier);
    } else {
      await DBHelper.instance.updateSupplier(s);
      widget.onSaved?.call(s);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.supplier != null;
    final isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;

    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        top: 8,
        left: 20,
        right: 20,
      ),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: const BoxDecoration(
                  color: Colors.black12,
                  borderRadius: BorderRadius.zero,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: _kBrandLight,
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Icon(Icons.business_rounded, color: _kBrand, size: 20),
                ),
                const SizedBox(width: 12),
                Text(
                  isEdit ? 'Ubah Supplier' : 'Tambah Supplier',
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                if (isLandscape)
                  SizedBox(
                    height: 36,
                    child: ElevatedButton(
                      onPressed: _saving ? null : _save,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                      ),
                      child: _saving
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                  color: Colors.white, strokeWidth: 2))
                          : Text(isEdit ? 'Simpan' : 'Tambah',
                              style: const TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.bold)),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            if (isLandscape)
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      children: [
                        TextField(
                          controller: _nameCtrl,
                          textCapitalization: TextCapitalization.words,
                          decoration: _inputDecor('Nama Supplier *'),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _phoneCtrl,
                          keyboardType: TextInputType.phone,
                          decoration: _inputDecor('Nomor HP'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      children: [
                        TextField(
                          controller: _addressCtrl,
                          maxLines: 2,
                          decoration: _inputDecor('Alamat'),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _keteranganCtrl,
                          decoration: _inputDecor('Keterangan'),
                        ),
                      ],
                    ),
                  ),
                ],
              )
            else
              Column(
                children: [
                  TextField(
                    controller: _nameCtrl,
                    textCapitalization: TextCapitalization.words,
                    decoration: _inputDecor('Nama Supplier *'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _phoneCtrl,
                    keyboardType: TextInputType.phone,
                    decoration: _inputDecor('Nomor HP'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _addressCtrl,
                    maxLines: 2,
                    decoration: _inputDecor('Alamat'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _keteranganCtrl,
                    decoration:
                        _inputDecor('Keterangan (misal: Supplier Makanan)'),
                  ),
                ],
              ),
            if (!isLandscape) ...[
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _saving ? null : _save,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kBrand,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                  child: _saving
                      ? const CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2)
                      : Text(
                          isEdit ? 'Simpan Perubahan' : 'Tambah Supplier',
                          style: const TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w600),
                        ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  InputDecoration _inputDecor(String hint) => InputDecoration(
        hintText: hint,
        isDense: true,
        filled: true,
        fillColor: const Color(0xFFF6F7F9),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: Color(0xFFE8E8E8)),
        ),
        enabledBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: Color(0xFFE8E8E8)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: _kBrand, width: 1.5),
        ),
      );
}

