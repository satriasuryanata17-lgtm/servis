import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../core/theme.dart';
import '../providers/providers.dart';
// import '../services/pos_network_service.dart';
import '../screens/main_shell.dart';
import '../utils/staff_access.dart';

const Color _kTeal = AppColors.primaryBrand;
const Color _kTealDark = Color(0xFF1E40AF); // Indigo Blue
const Color _kTealDeep = AppColors.primaryDark;
const Color _kWhite = Colors.white;
const Color _kText = Color(0xFF0F172A); // Dark slate text
const Color _kSubtext = Color(0xFF94A3B8); // Slate subtext
const String _kDrawerAccessDeniedMessage =
    'Akses Dibatasi: Admin/Owner dapat mengubah izin di menu Karyawan.';

void _showDrawerAccessDenied(BuildContext context) {
  ScaffoldMessenger.of(context)
    ..clearSnackBars()
    ..showSnackBar(
      const SnackBar(
        content: Text(_kDrawerAccessDeniedMessage),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
        duration: Duration(milliseconds: 1500),
      ),
    );
}

class KasirDrawer extends ConsumerWidget {
  final String? selectedRoute;
  const KasirDrawer({super.key, this.selectedRoute});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final shell = ShellScope.of(context);
    void close() => Navigator.pop(context);

    void go(String route) {
      close();

      // Mapping routes to MainShell indices for unified navigation
      final shellRoutes = {
        '/': 0,
        '/transaksi': 1,
        '/produk': 2,
        '/pesanan': 3,
        '/riwayat': 4,
        '/laporan': 5,
        '/pelanggan': 6,
        '/karyawan': 7,
        '/notifikasi': 8,
        '/setting': 9,
        '/servis_status': 10,
        '/sync_settings': 11,
        '/juragan_sync': 11,
        '/ai': 12,
      };

      if (shell != null && shellRoutes.containsKey(route)) {
        shell.onNavigate(shellRoutes[route]!);
      } else {
        Navigator.pushNamed(context, route);
      }
    }

    return Drawer(
      width: (MediaQuery.of(context).size.width * 0.85).clamp(280.0, 320.0),
      elevation: 0,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: Container(
        decoration: const BoxDecoration(color: Color(0xFFFBFBFB)),
        child: Column(
          children: [
            _buildHeader(context, ref, go),
            Expanded(
              child: Theme(
                data: Theme.of(context)
                    .copyWith(dividerColor: Colors.transparent),
                child: Consumer(
                  builder: (context, ref, child) {
                    final activeStaff = ref.watch(activeStaffProvider);
                    final canDashboard = StaffAccess.can(
                        activeStaff, StaffPermissionKey.dashboard);
                    final canOrder =
                        StaffAccess.can(activeStaff, StaffPermissionKey.order);
                    final canStatus = StaffAccess.can(
                        activeStaff, StaffPermissionKey.servisStatus);
                    final canProducts = StaffAccess.can(
                        activeStaff, StaffPermissionKey.products);
                    final canHistory = StaffAccess.can(
                        activeStaff, StaffPermissionKey.history);
                    final canWallet =
                        StaffAccess.can(activeStaff, StaffPermissionKey.wallet);
                    final canReports = StaffAccess.can(
                        activeStaff, StaffPermissionKey.reports);
                    final canCustomers = StaffAccess.can(
                        activeStaff, StaffPermissionKey.customers);
                    final canEmployees = StaffAccess.can(
                        activeStaff, StaffPermissionKey.employees);
                    final canSettings = StaffAccess.can(
                        activeStaff, StaffPermissionKey.settings);
                    final canSync =
                        StaffAccess.can(activeStaff, StaffPermissionKey.sync);
                    final canAi =
                        StaffAccess.can(activeStaff, StaffPermissionKey.ai);
                    final canRemoteScanner = StaffAccess.can(
                        activeStaff, StaffPermissionKey.remoteScanner);

                    VoidCallback guarded(bool canOpen, VoidCallback action) {
                      return canOpen
                          ? action
                          : () => _showDrawerAccessDenied(context);
                    }

                    return ListView(
                      padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
                      children: [
                        //  SPECIAL: DASBOR UTAMA (Desktop only, Admin)
                        if (!Platform.isAndroid && !Platform.isIOS)
                          Container(
                            margin: const EdgeInsets.only(
                                bottom: 16, left: 0, right: 0),
                            decoration: BoxDecoration(
                              color: canDashboard
                                  ? _kTeal
                                  : const Color(0xFFE2E8F0),
                              borderRadius: BorderRadius.zero,
                              boxShadow: [
                                BoxShadow(
                                  color: _kTeal.withValues(
                                      alpha: canDashboard ? 0.2 : 0.0),
                                  blurRadius: 8,
                                  offset: const Offset(0, 4),
                                )
                              ],
                            ),
                            child: _buildItem(
                                Icons.grid_view_rounded,
                                'Dasbor Utama',
                                canDashboard ? Colors.white : _kSubtext,
                                guarded(canDashboard, () => go('/')),
                                isInsideTeal: true,
                                active: selectedRoute == '/',
                                locked: !canDashboard),
                          ),

                        //  OPERASIONAL
                        _buildLabel('OPERASIONAL'),
                        _buildItem(
                          Icons.shopping_cart_outlined,
                          'Order Servis',
                          _kTeal,
                          guarded(canOrder, () => go('/transaksi')),
                          active: selectedRoute == '/transaksi',
                          locked: !canOrder,
                        ),
                        _buildItem(
                          Icons.handyman_outlined,
                          'Status Servis',
                          _kTeal,
                          guarded(canStatus, () => go('/servis_status')),
                          active: selectedRoute == '/servis_status',
                          locked: !canStatus,
                        ),
                        _buildItem(
                          Icons.dry_cleaning_outlined,
                          'Layanan & Inventori',
                          _kTeal,
                          guarded(canProducts, () => go('/produk')),
                          active: selectedRoute == '/produk',
                          locked: !canProducts,
                        ),
                        _buildItem(
                          Icons.assignment_outlined,
                          'Riwayat Pesanan',
                          _kTeal,
                          guarded(canHistory, () => go('/riwayat')),
                          active: selectedRoute == '/riwayat',
                          locked: !canHistory,
                        ),
                        _buildItem(
                          Icons.trending_up_rounded,
                          'Buku Kas Usaha',
                          _kTeal,
                          guarded(canWallet, () => go('/dompet')),
                          active: selectedRoute == '/dompet',
                          locked: !canWallet,
                        ),

                        const SizedBox(height: 16),

                        //  MANAJEMEN
                        _buildLabel('MANAJEMEN'),
                        _buildItem(
                          Icons.analytics_outlined,
                          'Laporan',
                          _kTeal,
                          guarded(canReports, () => go('/laporan')),
                          active: selectedRoute == '/laporan',
                          locked: !canReports,
                        ),
                        _buildItem(
                          Icons.people_alt_outlined,
                          'Pelanggan',
                          _kTeal,
                          guarded(canCustomers, () => go('/pelanggan')),
                          active: selectedRoute == '/pelanggan',
                          locked: !canCustomers,
                        ),
                        _buildItem(
                          Icons.badge_outlined,
                          'Karyawan',
                          _kTeal,
                          guarded(canEmployees, () => go('/karyawan')),
                          active: selectedRoute == '/karyawan',
                          locked: !canEmployees,
                        ),

                        const SizedBox(height: 16),

                        _buildLabel('SISTEM & ALAT'),
                        _buildItem(
                          Icons.sync_rounded,
                          'Sinkronisasi',
                          _kTeal,
                          guarded(canSync, () => go('/juragan_sync')),
                          active: selectedRoute == '/juragan_sync',
                          locked: !canSync,
                        ),
                        _buildItem(
                          Icons.auto_awesome_outlined,
                          'Asisten AI',
                          _kTeal,
                          guarded(canAi, () => go('/ai')),
                          active: selectedRoute == '/ai',
                          locked: !canAi,
                        ),

                        //  DISCONNECT BUTTON (Terminal Mode Only)
                        /*
                        if (POSNetworkService.instance.mode ==
                            POSNetworkMode.terminal)
                          _buildItem(Icons.link_off_rounded,
                              'Putus Koneksi Sync', Colors.redAccent, () async {
                            await POSNetworkService.instance.stop();
                            close();
                            // Refresh providers to switch back to local DB
                            ref.read(productsProvider.notifier).loadProducts();
                            ref
                                .read(categoriesProvider.notifier)
                                .loadCategories();
                            ref
                                .read(transactionsProvider.notifier)
                                .loadTransactions();
                          }),
                        */
                        _buildItem(
                          Icons.settings_outlined,
                          'Pengaturan',
                          _kTeal,
                          guarded(canSettings, () => go('/setting')),
                          active: selectedRoute == '/setting',
                          locked: !canSettings,
                        ),
                        if (!Platform.isAndroid && !Platform.isIOS)
                          _buildItem(
                            Icons.backup_rounded,
                            'Backup & Restore',
                            _kTeal,
                            guarded(canSettings, () => go('/backup_restore')),
                            active: selectedRoute == '/backup_restore',
                            locked: !canSettings,
                          ),
                        if (Platform.isAndroid || Platform.isIOS)
                          _buildItem(
                            Icons.qr_code_scanner,
                            'Scanner PC',
                            _kTeal,
                            guarded(
                                canRemoteScanner, () => go('/remote_scanner')),
                            active: selectedRoute == '/remote_scanner',
                            locked: !canRemoteScanner,
                          ),
                        _buildItem(
                          Icons.headset_mic_outlined,
                          'Pusat Bantuan',
                          _kTeal,
                          () => go('/pusat_bantuan'),
                          active: selectedRoute == '/pusat_bantuan',
                        ),

                        const SizedBox(height: 16),
                      ],
                    );
                  },
                ),
              ),
            ),
            _buildFooter(context, ref, close),
          ],
        ),
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 20, bottom: 8, top: 4),
      child: Text(
        text,
        style: GoogleFonts.inter(
          fontSize: 10,
          fontWeight: FontWeight.w800,
          color: Colors.black38,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  //  Menu Item
  Widget _buildItem(
      IconData icon, String label, Color color, VoidCallback onTap,
      {bool isInsideTeal = false, bool active = false, bool locked = false}) {
    final activeBg = color.withValues(alpha: 0.08);
    final effectiveColor = locked && !isInsideTeal ? _kSubtext : color;
    final textColor = locked && !isInsideTeal
        ? const Color(0xFF64748B)
        : (isInsideTeal ? Colors.white : _kText);
    return Container(
      margin: const EdgeInsets.only(bottom: 4, left: 8, right: 8),
      decoration: active
          ? BoxDecoration(
              color: activeBg,
              borderRadius: BorderRadius.zero,
            )
          : null,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.zero,
        child: InkWell(
          borderRadius: BorderRadius.zero,
          onTap: onTap,
          splashColor: effectiveColor.withValues(alpha: 0.08),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: [
                Icon(icon,
                    color: isInsideTeal
                        ? (locked ? Colors.white70 : Colors.white)
                        : effectiveColor,
                    size: 20),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: active ? FontWeight.w800 : FontWeight.w600,
                      color: textColor,
                    ),
                  ),
                ),
                if (locked)
                  Container(
                    width: 22,
                    height: 22,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: AppColors.danger.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: const Icon(
                      Icons.lock_rounded,
                      color: AppColors.danger,
                      size: 13,
                    ),
                  )
                else if (active)
                  Icon(Icons.check_circle_outline_rounded,
                      color: color.withValues(alpha: 0.5), size: 14)
                else
                  Icon(Icons.chevron_right_rounded,
                      color: isInsideTeal
                          ? Colors.white.withValues(alpha: 0.5)
                          : Colors.black12,
                      size: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(
      BuildContext context, WidgetRef ref, void Function(String) go) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_kTeal, _kTealDark, _kTealDeep],
          stops: [0.0, 0.55, 1.0],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Consumer(
            builder: (context, ref, child) {
              // Watch both providers di dalam Consumer agar nama & foto
              // langsung update ketika profil berubah (e.g. setelah simpan)
              final profile = ref.watch(profilProvider);
              final activeStaff = ref.watch(activeStaffProvider);

              // Jika ID -1 (Master Admin) atau tidak ada staff aktif, gunakan nama dari Profil (Owner)
              final name = (activeStaff != null && activeStaff.id != -1)
                  ? activeStaff.name
                  : (profile.nama.isNotEmpty ? profile.nama : 'Owner');

              final role = activeStaff?.role ?? 'Administrator';

              return Row(
                children: [
                  // PHOTO
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.12),
                      border: Border.all(
                          color: Colors.white.withValues(alpha: 0.3), width: 2),
                      borderRadius: BorderRadius.zero,
                      image: profile.fotoPath.isNotEmpty &&
                              File(profile.fotoPath).existsSync()
                          ? DecorationImage(
                              image: FileImage(File(profile.fotoPath)),
                              fit: BoxFit.cover,
                            )
                          : null,
                    ),
                    child: profile.fotoPath.isEmpty ||
                            !File(profile.fotoPath).existsSync()
                        ? const Icon(Icons.person_rounded,
                            color: Colors.white, size: 28)
                        : null,
                  ),
                  const SizedBox(width: 14),
                  // NAME & ROLE
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name,
                          style: GoogleFonts.poppins(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          role,
                          style: GoogleFonts.inter(
                            fontSize: 10,
                            color: _kSubtext,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.center_focus_weak_rounded,
                        color: Colors.white, size: 22),
                    onPressed: () => go('/continuous_scanner'),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildFooter(
      BuildContext drawerContext, WidgetRef ref, VoidCallback close) {
    return Consumer(
      builder: (ctx, ref, _) {
        final activeStaff = ref.watch(activeStaffProvider);
        final isStaffAdmin =
            activeStaff == null || StaffAccess.isAdmin(activeStaff);
        final sessionAsync = ref.watch(activeKasirSessionProvider);
        final hasActiveSession = sessionAsync.maybeWhen(
          data: (s) => s != null,
          orElse: () => false,
        );

        Future<void> doTutupKasir() async {
          close();
          Navigator.pushNamed(drawerContext, '/riwayat_tutup_kasir',
              arguments: true);
        }

        Future<void> doKunci() async {
          if (!drawerContext.mounted) return;
          final confirmed = await showDialog<bool>(
            context: drawerContext,
            useRootNavigator: true,
            builder: (dialogCtx) => AlertDialog(
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              title: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppColors.primaryBrand.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: const Icon(Icons.lock_person_rounded,
                        color: AppColors.primaryBrand, size: 20),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child:
                        Text('Kunci Terminal?', style: TextStyle(fontSize: 16)),
                  ),
                ],
              ),
              content: Text(
                hasActiveSession
                    ? 'Shift kasir tetap aktif dan tidak ditutup. Masukkan PIN untuk membuka terminal kembali.'
                    : 'Akses terminal akan dikunci. Masukkan PIN untuk masuk kembali.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogCtx, false),
                  child: const Text('Batal'),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryBrand,
                    foregroundColor: Colors.white,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                  onPressed: () => Navigator.pop(dialogCtx, true),
                  icon: const Icon(Icons.lock_person_rounded, size: 16),
                  label: const Text('Kunci Sekarang'),
                ),
              ],
            ),
          );
          if (confirmed != true || !drawerContext.mounted) {
            return;
          }
          close();
          await ref.read(activeStaffProvider.notifier).set(null);
        }

        return Container(
          decoration: BoxDecoration(
            color: _kWhite,
            border: Border(
                top: BorderSide(color: Colors.black.withValues(alpha: 0.08))),
          ),
          child: SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // TUTUP KASIR - hanya tampil jika admin & ada sesi aktif
                  if (isStaffAdmin && hasActiveSession) ...[
                    _FooterButton(
                      icon: Icons.power_settings_new_rounded,
                      label: 'Tutup Kasir',
                      semanticLabel: 'Tutup Kasir',
                      color: AppColors.danger,
                      onTap: doTutupKasir,
                    ),
                    const SizedBox(width: 8),
                  ],

                  // KUNCI
                  _FooterButton(
                    icon: Icons.lock_person_rounded,
                    label: isStaffAdmin ? 'Kunci' : 'Ganti Shift',
                    semanticLabel:
                        isStaffAdmin ? 'Kunci Terminal' : 'Ganti Shift',
                    color: _kTealDeep,
                    onTap: doKunci,
                  ),

                  const SizedBox(width: 10),
                  const Spacer(),

                  // BRANDING
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('JuraganKasir',
                          style: GoogleFonts.poppins(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: _kTeal)),
                      const Text('v1.0.0',
                          style: TextStyle(fontSize: 9, color: Colors.black26)),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// _FooterButton - tombol compact untuk footer drawer
// ---------------------------------------------------------------------------
class _FooterButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? semanticLabel;
  final Color color;
  final VoidCallback onTap;

  const _FooterButton({
    required this.icon,
    required this.label,
    this.semanticLabel,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final accessibleLabel = semanticLabel ?? label;

    return Tooltip(
      message: accessibleLabel,
      child: Semantics(
        button: true,
        label: accessibleLabel,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            splashColor: color.withValues(alpha: 0.12),
            highlightColor: color.withValues(alpha: 0.08),
            child: Container(
              constraints: const BoxConstraints(minHeight: 36),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.zero,
                border: Border.all(color: color.withValues(alpha: 0.22)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: color, size: 15),
                  const SizedBox(width: 6),
                  Text(
                    label,
                    style: GoogleFonts.inter(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: color,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.visible,
                    softWrap: false,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

