// Re-export from screens  keeps both import paths working.
export '../screens/kasir_nav_rail.dart';

