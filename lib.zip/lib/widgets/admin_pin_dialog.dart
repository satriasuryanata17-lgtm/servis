import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/theme.dart';

const Color _kBrand = AppColors.primaryBrand;

/// Dialog untuk verifikasi PIN Admin.
/// Kembalikan true jika PIN benar, false/null jika batal.
class AdminPinDialog extends StatefulWidget {
  final String Function(String) verifyPin;
  final String title;
  final String subtitle;

  const AdminPinDialog({
    super.key,
    required this.verifyPin,
    this.title = 'Verifikasi PIN Admin',
    this.subtitle = 'Masukkan PIN Admin untuk melanjutkan',
  });

  /// Tampilkan dialog dan tunggu hasilnya.
  /// Kembalikan true jika PIN valid, false/null jika batal.
  static Future<bool> show(
    BuildContext context, {
    required String Function(String) verifyPin,
    String title = 'Verifikasi PIN Admin',
    String subtitle = 'Masukkan PIN Admin untuk melanjutkan',
  }) async {
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AdminPinDialog(
        verifyPin: verifyPin,
        title: title,
        subtitle: subtitle,
      ),
    );
    return result == true;
  }

  @override
  State<AdminPinDialog> createState() => _AdminPinDialogState();
}

class _AdminPinDialogState extends State<AdminPinDialog> {
  final _pinCtrl = TextEditingController();
  final _focusNode = FocusNode();
  bool _obscure = true;
  String? _errorText;
  bool _shaking = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _focusNode.requestFocus());
  }

  @override
  void dispose() {
    _pinCtrl.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _verify() {
    final pin = _pinCtrl.text.trim();
    if (pin.isEmpty) {
      setState(() => _errorText = 'PIN tidak boleh kosong');
      return;
    }
    if (pin.length != 6) {
      setState(() => _errorText = 'PIN harus 6 digit');
      return;
    }
    final error = widget.verifyPin(pin);
    if (error.isEmpty) {
      Navigator.pop(context, true);
    } else {
      _pinCtrl.clear();
      setState(() {
        _errorText = error;
        _shaking = true;
      });
      Future.delayed(const Duration(milliseconds: 400), () {
        if (mounted) setState(() => _shaking = false);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        transform:
            _shaking ? Matrix4.translationValues(6, 0, 0) : Matrix4.identity(),
        padding: const EdgeInsets.all(28),
        constraints: const BoxConstraints(maxWidth: 420),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            //  Icon + Title
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: _kBrand.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: const Icon(Icons.lock_outline_rounded,
                      color: _kBrand, size: 22),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.title,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        widget.subtitle,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black45,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            //  PIN Input
            TextField(
              controller: _pinCtrl,
              focusNode: _focusNode,
              obscureText: _obscure,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              maxLength: 6,
              onSubmitted: (_) => _verify(),
              onChanged: (_) {
                if (_errorText != null) setState(() => _errorText = null);
              },
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                letterSpacing: 4,
              ),
              decoration: InputDecoration(
                hintText: '',
                hintStyle:
                    const TextStyle(letterSpacing: 4, color: Colors.black26),
                counterText: '',
                errorText: _errorText,
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscure
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: Colors.black38,
                  ),
                  onPressed: () => setState(() => _obscure = !_obscure),
                ),
                border: const OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: Color(0xFFD0D5DD)),
                ),
                enabledBorder: const OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: Color(0xFFD0D5DD)),
                ),
                focusedBorder: const OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: _kBrand, width: 1.5),
                ),
                errorBorder: const OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: AppColors.danger),
                ),
                focusedErrorBorder: const OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: AppColors.danger, width: 1.5),
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
            ),

            const SizedBox(height: 24),

            //  Buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context, false),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.black54,
                      side: const BorderSide(color: Color(0xFFD0D5DD)),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: const Text('Batal'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _verify,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: const Text(
                      'Konfirmasi',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Dialog untuk mengubah PIN Admin.
/// Meminta PIN lama  PIN baru  konfirmasi PIN baru.
class ChangePinDialog extends StatefulWidget {
  final bool requiresCurrentPin;
  final bool Function(String) verifyCurrentPin;
  final String? hint;

  const ChangePinDialog({
    super.key,
    required this.requiresCurrentPin,
    required this.verifyCurrentPin,
    this.hint,
  });

  static Future<String?> show(
    BuildContext context, {
    required bool requiresCurrentPin,
    required bool Function(String) verifyCurrentPin,
    String? hint,
  }) {
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) => ChangePinDialog(
        requiresCurrentPin: requiresCurrentPin,
        verifyCurrentPin: verifyCurrentPin,
        hint: hint,
      ),
    );
  }

  @override
  State<ChangePinDialog> createState() => _ChangePinDialogState();
}

class _ChangePinDialogState extends State<ChangePinDialog> {
  final _oldCtrl = TextEditingController();
  final _newCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _obscureOld = true;
  bool _obscureNew = true;
  bool _obscureConfirm = true;
  String? _error;

  @override
  void dispose() {
    _oldCtrl.dispose();
    _newCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  void _submit() {
    final oldPin = _oldCtrl.text.trim();
    final newPin = _newCtrl.text.trim();
    final confirmPin = _confirmCtrl.text.trim();

    if (widget.requiresCurrentPin && oldPin.length != 6) {
      setState(() => _error = 'PIN lama harus 6 digit');
      return;
    }
    if (widget.requiresCurrentPin && !widget.verifyCurrentPin(oldPin)) {
      setState(() => _error = 'PIN lama tidak benar');
      return;
    }
    if (newPin.length != 6) {
      setState(() => _error = 'PIN baru harus 6 digit');
      return;
    }

    if (newPin != confirmPin) {
      setState(() => _error = 'Konfirmasi PIN tidak cocok');
      return;
    }
    Navigator.pop(context, newPin);
  }

  Widget _pinField(TextEditingController ctrl, String label, bool obscure,
      VoidCallback toggleObscure) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Colors.black54)),
        const SizedBox(height: 6),
        TextField(
          controller: ctrl,
          obscureText: obscure,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          maxLength: 6,
          onChanged: (_) {
            if (_error != null) setState(() => _error = null);
          },
          decoration: InputDecoration(
            counterText: '',
            suffixIcon: IconButton(
              icon: Icon(
                  obscure
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  color: Colors.black38,
                  size: 18),
              onPressed: toggleObscure,
            ),
            border: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFD0D5DD))),
            enabledBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFD0D5DD))),
            focusedBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: _kBrand, width: 1.5)),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Ganti PIN Admin',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(
              widget.hint ??
                  (widget.requiresCurrentPin
                      ? 'Gunakan PIN yang mudah diingat dan aman'
                      : 'Atur PIN admin baru untuk melindungi aksi sensitif'),
              style: const TextStyle(fontSize: 12, color: Colors.black45),
            ),
            const SizedBox(height: 20),
            if (widget.requiresCurrentPin) ...[
              _pinField(_oldCtrl, 'PIN Lama', _obscureOld,
                  () => setState(() => _obscureOld = !_obscureOld)),
              const SizedBox(height: 14),
            ],
            _pinField(_newCtrl, 'PIN Baru', _obscureNew,
                () => setState(() => _obscureNew = !_obscureNew)),
            const SizedBox(height: 14),
            _pinField(_confirmCtrl, 'Konfirmasi PIN Baru', _obscureConfirm,
                () => setState(() => _obscureConfirm = !_obscureConfirm)),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                color: AppColors.danger.withValues(alpha: 0.08),
                child: Row(
                  children: [
                    const Icon(Icons.error_outline,
                        color: AppColors.danger, size: 16),
                    const SizedBox(width: 8),
                    Text(_error!,
                        style: const TextStyle(
                            fontSize: 13, color: AppColors.danger)),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.black54,
                      side: const BorderSide(color: Color(0xFFD0D5DD)),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    child: const Text('Batal'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    child: const Text('Simpan PIN',
                        style: TextStyle(fontWeight: FontWeight.w600)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

