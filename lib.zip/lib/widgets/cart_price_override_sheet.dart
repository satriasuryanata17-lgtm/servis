import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../utils/currency_input_formatter.dart';

class CartPriceOverrideSheet extends ConsumerStatefulWidget {
  final Product product;
  final double qty;

  const CartPriceOverrideSheet({
    super.key,
    required this.product,
    required this.qty,
  });

  static Future<void> show(
    BuildContext context, {
    required Product product,
    required double qty,
  }) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.white,
      constraints: const BoxConstraints(maxWidth: 560),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (_) => CartPriceOverrideSheet(product: product, qty: qty),
    );
  }

  @override
  ConsumerState<CartPriceOverrideSheet> createState() =>
      _CartPriceOverrideSheetState();
}

class _CartPriceOverrideSheetState
    extends ConsumerState<CartPriceOverrideSheet> {
  late final TextEditingController _priceCtrl;
  String? _errorText;

  @override
  void initState() {
    super.initState();
    final allDiscounts = ref.read(discountsProvider);
    final hardwareSettings = ref.read(hardwarePricingSettingsProvider);
    final overrides = ref.read(cartPriceOverridesProvider);
    final normalPricing = CartNotifier.resolveUnitPricing(
      widget.product,
      widget.qty,
      allDiscounts,
      hardwareSettings: hardwareSettings,
    );
    final currentPrice =
        overrides[widget.product.id]?.unitPrice ?? normalPricing.finalUnitPrice;
    _priceCtrl = TextEditingController(text: formatCurrencyInput(currentPrice));
  }

  @override
  void dispose() {
    _priceCtrl.dispose();
    super.dispose();
  }

  String _money(int value) => 'Rp ${formatCurrencyInput(value)}';

  String _qtyLabel(double value) {
    return value % 1 == 0 ? value.toInt().toString() : value.toString();
  }

  void _submit() {
    final productId = widget.product.id;
    final value = parseCurrencyInput(_priceCtrl.text);
    if (productId == null) {
      setState(() => _errorText = 'Produk belum valid.');
      return;
    }
    if (value <= 0) {
      setState(() => _errorText = 'Harga harus lebih dari 0.');
      return;
    }

    final normalPricing = CartNotifier.resolveUnitPricing(
      widget.product,
      widget.qty,
      ref.read(discountsProvider),
      hardwareSettings: ref.read(hardwarePricingSettingsProvider),
    );
    final notifier = ref.read(cartPriceOverridesProvider.notifier);
    if (value == normalPricing.finalUnitPrice) {
      notifier.removeOverride(productId);
    } else {
      notifier.setOverride(productId, value);
    }
    Navigator.of(context).pop();
  }

  void _reset() {
    final productId = widget.product.id;
    if (productId != null) {
      ref.read(cartPriceOverridesProvider.notifier).removeOverride(productId);
    }
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final allDiscounts = ref.watch(discountsProvider);
    final hardwareSettings = ref.watch(hardwarePricingSettingsProvider);
    final overrides = ref.watch(cartPriceOverridesProvider);
    final hasOverride =
        widget.product.id != null && overrides.containsKey(widget.product.id);
    final normalPricing = CartNotifier.resolveUnitPricing(
      widget.product,
      widget.qty,
      allDiscounts,
      hardwareSettings: hardwareSettings,
    );
    final billableQty =
        CartNotifier.billableQty(widget.product, widget.qty, hardwareSettings);
    final inputPrice = parseCurrencyInput(_priceCtrl.text);
    final previewTotal = (inputPrice * billableQty).round();
    final isBelowCost = inputPrice > 0 &&
        widget.product.buyPrice > 0 &&
        inputPrice < widget.product.buyPrice;

    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          18,
          10,
          18,
          18 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
                child: Container(
                    width: 38, height: 4, color: const Color(0xFFE2E8F0))),
            const SizedBox(height: 18),
            Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.primaryBrand.withValues(alpha: 0.10),
                    border: Border.all(
                      color: AppColors.primaryBrand.withValues(alpha: 0.18),
                    ),
                  ),
                  child: const Icon(Icons.sell_outlined,
                      color: AppColors.primaryBrand, size: 19),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Ubah Harga Jual',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFF111827),
                        ),
                      ),
                      Text(
                        widget.product.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFF64748B),
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Column(
                children: [
                  _PriceInfoRow(
                    label: 'Jumlah masuk',
                    value: '${_qtyLabel(widget.qty)} ${widget.product.unit}',
                  ),
                  const SizedBox(height: 8),
                  _PriceInfoRow(
                    label: 'Jumlah ditagih',
                    value: '${_qtyLabel(billableQty)} ${widget.product.unit}',
                  ),
                  const SizedBox(height: 8),
                  _PriceInfoRow(
                    label: 'Harga aktif',
                    value: _money(normalPricing.finalUnitPrice),
                  ),
                  const SizedBox(height: 8),
                  _PriceInfoRow(
                    label: 'Modal/HPP',
                    value: widget.product.buyPrice > 0
                        ? _money(widget.product.buyPrice)
                        : 'Belum diisi',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _priceCtrl,
              autofocus: true,
              keyboardType: TextInputType.number,
              inputFormatters: const [CurrencyInputFormatter()],
              onChanged: (_) => setState(() => _errorText = null),
              onSubmitted: (_) => _submit(),
              decoration: InputDecoration(
                labelText: 'Harga baru per ${widget.product.unit}',
                prefixText: 'Rp ',
                errorText: _errorText,
                border:
                    const OutlineInputBorder(borderRadius: BorderRadius.zero),
                enabledBorder: const OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: Color(0xFFD6DEE3)),
                ),
                focusedBorder: const OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide:
                      BorderSide(color: AppColors.primaryBrand, width: 1.3),
                ),
              ),
            ),
            if (isBelowCost) ...[
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFFEF2F2),
                  border: Border.all(color: const Color(0xFFFECACA)),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.warning_amber_rounded,
                        color: Color(0xFFDC2626), size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Harga jual di bawah modal ${_money(widget.product.buyPrice)}. Transaksi tetap bisa dilanjutkan.',
                        style: const TextStyle(
                          color: Color(0xFF991B1B),
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Total item',
                    style: TextStyle(
                      color: Color(0xFF64748B),
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                Text(
                  _money(previewTotal),
                  style: const TextStyle(
                    color: AppColors.primaryBrand,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                if (hasOverride) ...[
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _reset,
                      icon: const Icon(Icons.restart_alt_rounded, size: 17),
                      label: const Text('Reset'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF475569),
                        side: const BorderSide(color: Color(0xFFCBD5E1)),
                        minimumSize: const Size.fromHeight(46),
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  flex: hasOverride ? 2 : 1,
                  child: ElevatedButton.icon(
                    onPressed: _submit,
                    icon: const Icon(Icons.check_rounded, size: 18),
                    label: const Text('Terapkan Harga'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryBrand,
                      foregroundColor: Colors.white,
                      minimumSize: const Size.fromHeight(48),
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _PriceInfoRow extends StatelessWidget {
  final String label;
  final String value;

  const _PriceInfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              color: Color(0xFF64748B),
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            color: Color(0xFF111827),
            fontSize: 12.5,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }
}

