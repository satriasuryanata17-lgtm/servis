// Re-export from screens  keeps both import paths working.
export '../screens/responsive_layout.dart';

