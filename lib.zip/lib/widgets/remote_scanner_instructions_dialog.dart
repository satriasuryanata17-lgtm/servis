import 'package:flutter/material.dart';

import '../core/theme.dart';

class RemoteScannerInstructionsDialog extends StatelessWidget {
  const RemoteScannerInstructionsDialog({
    super.key,
    required this.showStartAction,
  });

  final bool showStartAction;

  static Future<bool> show(
    BuildContext context, {
    bool showStartAction = false,
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => RemoteScannerInstructionsDialog(
        showStartAction: showStartAction,
      ),
    );
    return result ?? false;
  }

  @override
  Widget build(BuildContext context) {
    const brandColor = AppColors.primaryBrand;
    final screenHeight = MediaQuery.of(context).size.height;
    final maxHeight = (screenHeight - 48).clamp(320.0, screenHeight);

    return Dialog(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      backgroundColor: Colors.white,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 420, maxHeight: maxHeight),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(
                Icons.qr_code_scanner_rounded,
                color: brandColor,
                size: 40,
              ),
              const SizedBox(height: 12),
              const Text(
                'Tutorial Scanner Remote',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              const Text(
                'Gunakan HP sebagai scanner barcode untuk aplikasi desktop.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black54, fontSize: 13),
              ),
              const SizedBox(height: 24),
              const _InstructionStep(
                number: '1',
                title: 'Siapkan desktop',
                description:
                    'Buka Juragan Servis di PC, lalu tampilkan QR pairing dari tombol Scanner Remote atau ikon QR di dashboard.',
              ),
              const _InstructionStep(
                number: '2',
                title: 'Samakan jaringan',
                description:
                    'Pastikan HP dan PC berada di Wi-Fi yang sama. Jika tidak ada Wi-Fi, gunakan kabel USB dan aktifkan USB Tethering.',
              ),
              const _InstructionStep(
                number: '3',
                title: 'Scan QR pairing',
                description:
                    'Arahkan kamera HP ke QR pairing di layar PC sampai status berubah menjadi Scanner Remote.',
              ),
              const _InstructionStep(
                number: '4',
                title: 'Scan barcode produk',
                description:
                    'Setelah tersambung, arahkan kamera HP ke barcode produk. Hasil scan akan masuk ke aplikasi desktop.',
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF6FF),
                  border: Border.all(color: const Color(0xFFBFDBFE)),
                ),
                child: const Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.info_outline_rounded,
                      color: brandColor,
                      size: 18,
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Izinkan akses kamera saat diminta. QR pairing lama perlu di-scan ulang jika koneksi terputus.',
                        style: TextStyle(
                          color: Color(0xFF1E3A8A),
                          fontSize: 12,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context, false),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: brandColor,
                        side: const BorderSide(color: brandColor),
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero,
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: Text(showStartAction ? 'Batal' : 'Tutup'),
                    ),
                  ),
                  if (showStartAction) ...[
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => Navigator.pop(context, true),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: brandColor,
                          foregroundColor: Colors.white,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero,
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        child: const Text('Mulai Scanner'),
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InstructionStep extends StatelessWidget {
  const _InstructionStep({
    required this.number,
    required this.title,
    required this.description,
  });

  final String number;
  final String title;
  final String description;

  @override
  Widget build(BuildContext context) {
    const brandColor = AppColors.primaryBrand;

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 28,
            height: 28,
            alignment: Alignment.center,
            decoration: const BoxDecoration(color: brandColor),
            child: Text(
              number,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: 13,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF101828),
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF475467),
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

