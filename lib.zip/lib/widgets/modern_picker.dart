import 'package:flutter/material.dart';
import '../core/theme.dart';

/// A modern, bottom-sheet based selector that replaces legacy DropdownButton.
class ModernPicker<T> extends StatelessWidget {
  final T? value;
  final List<T> items;
  final String label;
  final String? hint;
  final String Function(T) itemLabel;
  final Widget Function(BuildContext, T)? itemBuilder;
  final ValueChanged<T> onChanged;
  final bool searchable;
  final String? searchHint;
  final String? sheetTitle;
  final IconData? icon;
  final bool allowCustomString;
  final String customStringLabel;
  final String customStringHint;
  final bool Function(T)? canDeleteItem;
  final ValueChanged<T>? onDeleteItem;

  const ModernPicker({
    super.key,
    required this.value,
    required this.items,
    required this.onChanged,
    required this.itemLabel,
    this.label = '',
    this.hint,
    this.itemBuilder,
    this.searchable = false,
    this.searchHint,
    this.sheetTitle,
    this.icon,
    this.allowCustomString = false,
    this.customStringLabel = 'Tambah manual',
    this.customStringHint = 'Tulis pilihan baru...',
    this.canDeleteItem,
    this.onDeleteItem,
  });

  @override
  Widget build(BuildContext context) {
    final selectedValue = value;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (label.isNotEmpty) ...[
          Text(
            label,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: Colors.black54,
            ),
          ),
          const SizedBox(height: 6),
        ],
        InkWell(
          onTap: () => _showPicker(context),
          borderRadius: BorderRadius.zero,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xFFF7F7F9),
              borderRadius: BorderRadius.zero,
              border: Border.all(color: const Color(0xFFE0E0E0)),
            ),
            child: Row(
              children: [
                if (icon != null) ...[
                  Icon(icon, size: 20, color: Colors.black38),
                  const SizedBox(width: 12),
                ],
                Expanded(
                  child: Text(
                    selectedValue == null
                        ? (hint ?? 'Pilih...')
                        : itemLabel(selectedValue),
                    style: TextStyle(
                      fontSize: 14,
                      color: selectedValue != null
                          ? Colors.black87
                          : Colors.black38,
                      fontWeight: selectedValue != null
                          ? FontWeight.w600
                          : FontWeight.normal,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: Colors.black26,
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _showPicker(BuildContext context) async {
    final selected = await showModalBottomSheet<T>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _ModernPickerSheet<T>(
        title: sheetTitle ?? label,
        items: items,
        selectedValue: value,
        itemLabel: itemLabel,
        itemBuilder: itemBuilder,
        searchable: searchable,
        searchHint: searchHint,
        allowCustomString: allowCustomString,
        customStringLabel: customStringLabel,
        customStringHint: customStringHint,
        canDeleteItem: canDeleteItem,
        onDeleteItem: onDeleteItem,
      ),
    );

    if (selected != null) {
      onChanged(selected);
    }
  }
}

class _ModernPickerSheet<T> extends StatefulWidget {
  final String title;
  final List<T> items;
  final T? selectedValue;
  final String Function(T) itemLabel;
  final Widget Function(BuildContext, T)? itemBuilder;
  final bool searchable;
  final String? searchHint;
  final bool allowCustomString;
  final String customStringLabel;
  final String customStringHint;
  final bool Function(T)? canDeleteItem;
  final ValueChanged<T>? onDeleteItem;

  const _ModernPickerSheet({
    required this.title,
    required this.items,
    required this.selectedValue,
    required this.itemLabel,
    this.itemBuilder,
    required this.searchable,
    this.searchHint,
    required this.allowCustomString,
    required this.customStringLabel,
    required this.customStringHint,
    this.canDeleteItem,
    this.onDeleteItem,
  });

  @override
  State<_ModernPickerSheet<T>> createState() => _ModernPickerSheetState<T>();
}

class _ModernPickerSheetState<T> extends State<_ModernPickerSheet<T>> {
  String _query = '';
  final _searchCtrl = TextEditingController();
  final _customCtrl = TextEditingController();
  final _customFormKey = GlobalKey<FormState>();
  final Set<String> _deletedLabels = {};
  bool _showCustomInput = false;

  @override
  void dispose() {
    _searchCtrl.dispose();
    _customCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final canAddCustomString = widget.allowCustomString && T == String;
    final visibleItems = widget.items.where((item) {
      final label = widget.itemLabel(item).trim().toLowerCase();
      return !_deletedLabels.contains(label);
    }).toList();
    final filtered = visibleItems.where((item) {
      if (!widget.searchable || _query.isEmpty) return true;
      return widget
          .itemLabel(item)
          .toLowerCase()
          .contains(_query.toLowerCase());
    }).toList();
    final customQuery = _query.trim();
    final showCustomQuery = canAddCustomString &&
        customQuery.isNotEmpty &&
        !visibleItems.any(
          (item) =>
              widget.itemLabel(item).trim().toLowerCase() ==
              customQuery.toLowerCase(),
        );

    return Container(
      height: MediaQuery.of(context).size.height *
          (widget.searchable || canAddCustomString ? 0.72 : 0.6),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      child: Column(
        children: [
          const SizedBox(height: 12),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.zero,
            ),
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: SizedBox(
              height: 40,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Center(
                    child: Text(
                      widget.title.isNotEmpty
                          ? widget.title
                          : 'Pilih Salah Satu',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                  ),
                  if (canAddCustomString)
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton.icon(
                        onPressed: _openCustomStringInput,
                        icon: const Icon(Icons.add_rounded, size: 18),
                        label: const Text('Tambah'),
                        style: TextButton.styleFrom(
                          foregroundColor: AppColors.primaryBrand,
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          textStyle: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          if (_showCustomInput) ...[
            const SizedBox(height: 12),
            _customStringInputPanel(),
          ],
          if (widget.searchable) ...[
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                height: 44,
                decoration: const BoxDecoration(
                  color: Color(0xFFF2F2F4),
                  borderRadius: BorderRadius.zero,
                ),
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (v) => setState(() => _query = v),
                  decoration: InputDecoration(
                    hintText: widget.searchHint ?? 'Cari...',
                    hintStyle:
                        const TextStyle(fontSize: 13, color: Colors.black38),
                    prefixIcon: const Icon(Icons.search,
                        color: Colors.black38, size: 20),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          Expanded(
            child: filtered.isEmpty && !showCustomQuery
                ? const Center(
                    child: Text(
                      'Data tidak ditemukan',
                      style: TextStyle(color: Colors.black38, fontSize: 14),
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                    itemCount: filtered.length + (showCustomQuery ? 1 : 0),
                    separatorBuilder: (_, __) => const Divider(
                      height: 1,
                      color: Color(0xFFF5F5F5),
                    ),
                    itemBuilder: (ctx, i) {
                      if (showCustomQuery && i == filtered.length) {
                        return ListTile(
                          onTap: () => Navigator.pop(context, customQuery as T),
                          contentPadding:
                              const EdgeInsets.symmetric(vertical: 4),
                          leading: Container(
                            width: 34,
                            height: 34,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBrand
                                  .withValues(alpha: 0.10),
                              border: Border.all(
                                color: AppColors.primaryBrand
                                    .withValues(alpha: 0.22),
                              ),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: const Icon(
                              Icons.add_rounded,
                              color: AppColors.primaryBrand,
                              size: 18,
                            ),
                          ),
                          title: Text(
                            'Gunakan "$customQuery"',
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              color: AppColors.primaryBrand,
                            ),
                          ),
                          subtitle: const Text(
                            'Tambahkan sebagai software manual',
                            style:
                                TextStyle(fontSize: 12, color: Colors.black45),
                          ),
                        );
                      }

                      final item = filtered[i];
                      final isSelected = widget.selectedValue == item;
                      final canDelete =
                          widget.canDeleteItem?.call(item) == true;

                      if (widget.itemBuilder != null) {
                        return InkWell(
                          onTap: () => Navigator.pop(context, item),
                          child: widget.itemBuilder!(context, item),
                        );
                      }

                      return ListTile(
                        onTap: () => Navigator.pop(context, item),
                        contentPadding: const EdgeInsets.symmetric(vertical: 2),
                        title: Text(
                          widget.itemLabel(item),
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight:
                                isSelected ? FontWeight.bold : FontWeight.w600,
                            color: isSelected
                                ? AppColors.primaryBrand
                                : Colors.black87,
                          ),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (canDelete)
                              IconButton(
                                tooltip: 'Hapus software',
                                visualDensity: VisualDensity.compact,
                                onPressed: () => _deleteItem(item),
                                icon: const Icon(
                                  Icons.delete_outline_rounded,
                                  color: Color(0xFFE11D48),
                                  size: 20,
                                ),
                              ),
                            if (isSelected)
                              const Icon(Icons.check_circle,
                                  color: AppColors.primaryBrand, size: 22),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _openCustomStringInput() {
    setState(() => _showCustomInput = true);
  }

  Widget _customStringInputPanel() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Form(
        key: _customFormKey,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFEFF6FF),
            border: Border.all(color: const Color(0xFFBFDBFE)),
            borderRadius: BorderRadius.zero,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: TextFormField(
                  controller: _customCtrl,
                  autofocus: true,
                  textInputAction: TextInputAction.done,
                  decoration: InputDecoration(
                    hintText: widget.customStringHint,
                    isDense: true,
                    filled: true,
                    fillColor: Colors.white,
                    border: const OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                    focusedBorder: const OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(
                        color: AppColors.primaryBrand,
                        width: 1.5,
                      ),
                    ),
                  ),
                  validator: _validateCustomString,
                  onFieldSubmitted: (_) => _submitCustomString(),
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                height: 48,
                child: ElevatedButton(
                  onPressed: _submitCustomString,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryBrand,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                  ),
                  child: const Text(
                    'Simpan',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String? _validateCustomString(String? value) {
    final text = (value ?? '').trim();
    if (text.isEmpty) return 'Software wajib diisi';
    final alreadyExists = widget.items.any(
      (item) =>
          widget.itemLabel(item).trim().toLowerCase() == text.toLowerCase(),
    );
    if (alreadyExists) return 'Software sudah ada';
    return null;
  }

  void _submitCustomString() {
    if (!(_customFormKey.currentState?.validate() ?? false)) return;
    Navigator.pop(context, _customCtrl.text.trim() as T);
  }

  void _deleteItem(T item) {
    widget.onDeleteItem?.call(item);
    setState(() {
      _deletedLabels.add(widget.itemLabel(item).trim().toLowerCase());
    });
  }
}

