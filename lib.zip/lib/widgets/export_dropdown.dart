import 'package:flutter/material.dart';
import '../core/theme.dart';

const Color _kBrand = AppColors.primaryBrand;

/// Reusable export dropdown bottom sheet.
/// Show 3 options: CSV, PDF, Print Langsung.
class ExportDropdown {
  /// Show the export options bottom sheet.
  /// Returns the selected option: 'csv', 'pdf', 'print', or null if cancelled.
  static Future<String?> show(BuildContext context) async {
    return await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.zero,
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: const BoxDecoration(
                    color: AppColors.brandLight,
                    borderRadius: BorderRadius.zero,
                  ),
                  child: const Icon(Icons.file_download_outlined,
                      color: _kBrand, size: 22),
                ),
                const SizedBox(width: 12),
                const Text(
                  'Ekspor Laporan',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            const Text(
              'Pilih format ekspor atau cetak langsung',
              style: TextStyle(fontSize: 13, color: Colors.black45),
            ),
            const SizedBox(height: 18),

            // CSV Option
            _ExportTile(
              icon: Icons.table_chart_outlined,
              label: 'CSV (.csv)',
              subtitle: 'Spreadsheet  bisa dibuka di Excel',
              onTap: () => Navigator.pop(ctx, 'csv'),
            ),
            const SizedBox(height: 8),

            // PDF Option
            _ExportTile(
              icon: Icons.picture_as_pdf_outlined,
              label: 'PDF (.pdf)',
              subtitle: 'Dokumen profesional siap cetak',
              onTap: () => Navigator.pop(ctx, 'pdf'),
            ),
            const SizedBox(height: 8),

            // Print Option
            _ExportTile(
              icon: Icons.print_outlined,
              label: 'Print Langsung',
              subtitle: 'Cetak ke printer WiFi/Bluetooth',
              onTap: () => Navigator.pop(ctx, 'print'),
            ),
            const SizedBox(height: 12),

            // Cancel
            SizedBox(
              width: double.infinity,
              height: 46,
              child: TextButton(
                onPressed: () => Navigator.pop(ctx),
                style: TextButton.styleFrom(
                  backgroundColor: const Color(0xFFF5F5F5),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
                child: const Text(
                  'Batal',
                  style: TextStyle(
                      color: Colors.black54, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ExportTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final VoidCallback onTap;

  const _ExportTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.zero,
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            border: Border.all(color: const Color(0xFFE8E8E8)),
            borderRadius: BorderRadius.zero,
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: const BoxDecoration(
                  color: AppColors.brandLight,
                  borderRadius: BorderRadius.zero,
                ),
                child: Icon(icon, color: _kBrand, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label,
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14)),
                    const SizedBox(height: 2),
                    Text(subtitle,
                        style: const TextStyle(
                            color: Colors.black45, fontSize: 12)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded,
                  color: Colors.black26, size: 20),
            ],
          ),
        ),
      ),
    );
  }
}

