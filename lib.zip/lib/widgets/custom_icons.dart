import 'package:flutter/material.dart';
import '../core/theme.dart';

class QuickActionIcon extends StatelessWidget {
  final IconData iconData;
  final Color primaryColor;
  final Widget? badge;

  const QuickActionIcon({
    super.key,
    required this.iconData,
    required this.primaryColor,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 44,
      height: 44,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Simulated "outline/shadow" effect by drawing a slightly larger dark version behind
          // Or we can just use a filled background approach
          Icon(iconData, color: AppColors.iconOutline, size: 40),
          // Filled version (using offset or custom painter ideally, but we'll use a layered approach)
          Icon(iconData, color: primaryColor, size: 36),
          // Small black stroke outline effect
          Icon(iconData, color: AppColors.iconOutline, size: 38),

          if (badge != null)
            Positioned(
              top: 0,
              right: 0,
              child: badge!,
            ),
        ],
      ),
    );
  }
}

class DashboardIcons {
  static Widget get transaksi => QuickActionIcon(
        iconData: Icons.shopping_cart_outlined,
        primaryColor: const Color(0xFF2FA2ED), // Light blue inside
        badge: Container(
          width: 14,
          height: 14,
          decoration: BoxDecoration(
            color: const Color(0xFFFFD158),
            shape: BoxShape.rectangle,
            border: Border.all(color: AppColors.iconOutline, width: 1.5),
          ),
          child: const Icon(Icons.add, size: 10, color: AppColors.iconOutline),
        ),
      );

  static Widget get produk => const QuickActionIcon(
        iconData: Icons.inventory_2_outlined,
        primaryColor: Color(0xFFE5A84B),
      );

  static Widget get laporan => const QuickActionIcon(
        iconData: Icons.bar_chart_rounded,
        primaryColor: Color(0xFF33CDB1),
      );

  static Widget get stok => const QuickActionIcon(
        iconData: Icons.warehouse_outlined,
        primaryColor: Color(0xFFE5A84B),
      );

  static Widget get pelanggan => const QuickActionIcon(
        iconData: Icons.people_alt_outlined,
        primaryColor: Color(0xFFEAA1B2),
      );

  static Widget get pengaturan => const QuickActionIcon(
        iconData: Icons.settings_outlined,
        primaryColor: Color(0xFFAAB2BC),
      );
}

class BarcodeIcon extends StatelessWidget {
  final double width;
  final double height;
  final Color? color;

  const BarcodeIcon({
    super.key,
    this.width = 22,
    this.height = 14,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final iconColor = color ?? IconTheme.of(context).color ?? Colors.black87;
    return SizedBox(
      width: width,
      height: height * 1.2,
      child: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _bar(1.8, iconColor),
            const SizedBox(width: 1),
            _bar(0.8, iconColor),
            const SizedBox(width: 2),
            _bar(2.5, iconColor),
            const SizedBox(width: 1),
            _bar(0.6, iconColor),
            const SizedBox(width: 1),
            _bar(1.8, iconColor),
            const SizedBox(width: 2),
            _bar(0.8, iconColor),
            const SizedBox(width: 1),
            _bar(2.2, iconColor),
          ],
        ),
      ),
    );
  }

  Widget _bar(double w, Color c) => Container(
        width: w,
        height: height,
        decoration: BoxDecoration(
          color: c,
          borderRadius: BorderRadius.zero,
        ),
      );
}

