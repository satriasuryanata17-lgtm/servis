import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'dart:io' show Platform;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'core/app_runtime_config.dart';
import 'core/app_branding.dart';
import 'core/theme.dart';
import 'providers/providers.dart';
import 'providers/companion_scanner_provider.dart';
import 'providers/shortcut_provider.dart';
import 'models/db_models.dart';
import 'database/db_helper.dart';
import 'dart:async';
import 'services/scan_feedback_service.dart';
import 'services/pos_network_service.dart';
import 'services/backup_service.dart';

import 'screens/transaksi_screen.dart';
import 'screens/produk_screen.dart';
import 'screens/laporan_screen.dart';
import 'screens/stok_screen.dart';
import 'screens/setting_screen.dart';
import 'screens/notifikasi_screen.dart';
import 'screens/admin/admin_dashboard_screen.dart';
import 'screens/daftar_notifikasi_screen.dart';
import 'screens/checkout_screen.dart';
import 'screens/login_lisensi_screen.dart';
import 'screens/riwayat_screen.dart';
import 'screens/struk_screen.dart';
import 'screens/remote_scanner_screen.dart';
import 'screens/welcome_screen.dart';

import 'screens/pesanan_screen.dart';
import 'screens/pengaturan_servis_screen.dart';
import 'screens/pengaturan_hardware_screen.dart';
import 'screens/riwayat_pesanan_terhapus_screen.dart';

import 'screens/karyawan_screen.dart';
import 'screens/daftar_karyawan_screen.dart';
import 'screens/riwayat_tutup_kasir_screen.dart';
import 'screens/audit_kasir_screen.dart';
import 'screens/ai_insight_screen.dart';

import 'screens/pelanggan_menu_screen.dart';
import 'screens/daftar_pelanggan_screen.dart';
import 'screens/transaksi_pelanggan_screen.dart';

import 'screens/transaksi_penjualan_laporan_screen.dart';
import 'screens/omzet_per_bulan_screen.dart';
import 'screens/produk_terlaris_screen.dart';
import 'screens/produk_terjual_screen.dart';
import 'screens/arus_kas_screen.dart';
import 'screens/gudang_laporan_screen.dart';
import 'screens/riwayat_stok_laporan_screen.dart';
import 'screens/kategori_screen.dart';
import 'screens/kategori_keuangan_screen.dart';
import 'screens/juragan_sync_screen.dart';
import 'screens/masa_berlaku_produk_screen.dart';
import 'screens/tambah_transaksi_dompet_screen.dart';

import 'screens/admin/sync_settings_screen.dart';
import 'screens/backup_restore_screen.dart';
import 'screens/laporan_laba_rugi_screen.dart';
import 'screens/supplier_screen.dart';
import 'screens/purchase_order_screen.dart';
import 'screens/pengeluaran_screen.dart';
import 'screens/laporan_keuangan_screen.dart';
import 'screens/retur_screen.dart';
import 'screens/target_penjualan_screen.dart';
import 'screens/main_shell.dart';
import 'screens/cetak_resi_marketplace_screen.dart';
import 'screens/continuous_scanner_screen.dart';
import 'screens/servis_status_screen.dart';
import 'screens/pusat_bantuan_screen.dart';
import 'package:window_manager/window_manager.dart';
import 'services/resi_print_service.dart';

import 'package:intl/date_symbol_data_local.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  String? startupError;

  if (Platform.isWindows || Platform.isLinux) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }

  try {
    if (Platform.isWindows || Platform.isMacOS || Platform.isLinux) {
      await _prepareDesktopWindow();
    }
  } catch (e) {
    startupError = e.toString();
  }

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));
  runApp(
    ProviderScope(
      child: JuraganServisApp(startupError: startupError),
    ),
  );
}

Future<void> _prepareDesktopWindow() async {
  await windowManager.ensureInitialized();

  const windowOptions = WindowOptions(
    size: Size(1300, 850),
    center: true,
    backgroundColor: Colors.transparent,
    skipTaskbar: false,
    titleBarStyle: TitleBarStyle.normal,
    minimumSize: Size(1080, 740),
  );

  windowManager.waitUntilReadyToShow(windowOptions, () async {
    await windowManager.setTitle(AppBranding.appName);
    await windowManager.setIcon('assets/images/app_icon.ico');
    await windowManager.show();
    await windowManager.focus();
  });
}

Future<void> _bootstrapAppCore() async {
  final releaseIssues = AppRuntimeConfig.validateReleaseConfiguration();
  if (releaseIssues.isNotEmpty) {
    throw StateError(releaseIssues.join('\n'));
  }

  await initializeDateFormatting('id', null);
  await _initializeCloudServices();
}

Future<void> _initializeCloudServices() async {
  try {
    await Supabase.initialize(
      url: AppRuntimeConfig.supabaseUrl,
      anonKey: AppRuntimeConfig.supabaseAnonKey,
    );
  } catch (e) {
    debugPrint('Supabase initialization failed: $e');
  }
}

class JuraganServisApp extends ConsumerStatefulWidget {
  final String? startupError;

  const JuraganServisApp({super.key, this.startupError});

  @override
  ConsumerState<JuraganServisApp> createState() => _JuraganServisAppState();
}

// Provider terpisah untuk welcome screen — tidak ikut rebuild MaterialApp
final _showWelcomeProvider =
    NotifierProvider<_ShowWelcomeNotifier, bool>(_ShowWelcomeNotifier.new);

class _ShowWelcomeNotifier extends Notifier<bool> {
  @override
  bool build() => false;

  void show() => state = true;
  void hide() => state = false;
}

class _JuraganServisAppState extends ConsumerState<JuraganServisApp> {
  final _navigatorKey = GlobalKey<NavigatorState>();
  final _scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();
  late final NavigatorObserver _snackBarRouteObserver =
      _SnackBarRouteObserver(_scaffoldMessengerKey);
  StreamSubscription<String>? _globalRemoteScannerSub;
  bool? _lastRemoteScannerDesired;
  Timer? _posNetworkTimer;
  Timer? _autoBackupTimer;
  Timer? _resiWatcherTimer;
  bool _bootstrapDone = false;
  bool _splashMinShown = false;
  String? _startupError;

  // Global Barcode Buffer for Hardware Scanners
  String _hardwareBuffer = '';
  DateTime _lastHardwareTime = DateTime.now();

  @override
  void initState() {
    super.initState();
    _startupError = widget.startupError;
    if (_startupError == null) {
      unawaited(_bootstrap());
    }

    Timer(const Duration(milliseconds: 1200), () {
      if (mounted) {
        setState(() => _splashMinShown = true);
      }
    });

    // Cek apakah welcome screen perlu ditampilkan (Android/iOS saja)
    if (Platform.isAndroid || Platform.isIOS) {
      isWelcomeScreenSeen().then((seen) {
        if (mounted && !seen) {
          ref.read(_showWelcomeProvider.notifier).show();
        }
      });
    }

    // Listen for Physical Hardware Scanners (USB/Bluetooth)
    HardwareKeyboard.instance.addHandler(_handleHardwareKey);
  }

  Future<void> _bootstrap() async {
    try {
      await _bootstrapAppCore();
      if (!mounted) return;
      setState(() => _bootstrapDone = true);
      _scheduleDeferredStartupWork();
    } catch (e) {
      if (!mounted) return;
      setState(() => _startupError = e.toString());
    }
  }

  void _scheduleDeferredStartupWork() {
    Timer(const Duration(milliseconds: 500), () {
      if (!mounted) return;
      _attachDesktopRemoteScanner();
    });

    _posNetworkTimer ??= Timer(const Duration(seconds: 3), () {
      if (!mounted) return;
      unawaited(POSNetworkService.instance.initialize().catchError((e) {
        debugPrint('POSNetworkService initialization failed: $e');
      }));
    });

    _resiWatcherTimer ??= Timer(const Duration(seconds: 10), () {
      if (!mounted || !Platform.isWindows) return;
      ResiPrintService().startFolderWatcher();
    });

    _autoBackupTimer ??= Timer(const Duration(seconds: 20), () {
      if (!mounted) return;
      unawaited(BackupService.performAutoBackup());
    });
  }

  void _attachDesktopRemoteScanner() {
    if (!Platform.isWindows && !Platform.isLinux && !Platform.isMacOS) return;
    if (_globalRemoteScannerSub != null) return;

    _globalRemoteScannerSub =
        ref.read(remoteBarcodeStreamProvider).listen((code) {
      if (mounted) {
        unawaited(_handleGlobalBarcode(code));
      }
    });
    unawaited(_syncDesktopScannerForAuth(ref.read(authProvider)));
  }

  @override
  void dispose() {
    _posNetworkTimer?.cancel();
    _autoBackupTimer?.cancel();
    _resiWatcherTimer?.cancel();
    _globalRemoteScannerSub?.cancel();
    HardwareKeyboard.instance.removeHandler(_handleHardwareKey);
    ref
        .read(companionScannerStateProvider.notifier)
        .stopServer(clearError: true);
    unawaited(ScanFeedbackService.instance.stop());
    ResiPrintService().stopFolderWatcher();
    super.dispose();
  }

  Future<void> _syncDesktopScannerForAuth(AuthStatus status) async {
    if (!mounted) return;
    if (!Platform.isWindows && !Platform.isLinux && !Platform.isMacOS) return;

    final shouldBeActive = status != AuthStatus.unauthorized;
    if (_lastRemoteScannerDesired == shouldBeActive) return;

    _lastRemoteScannerDesired = shouldBeActive;
    await ref
        .read(companionScannerStateProvider.notifier)
        .syncHostSession(shouldBeActive: shouldBeActive);
  }

  bool _handleHardwareKey(KeyEvent event) {
    if (event is KeyDownEvent) {
      final key = event.logicalKey;

      // 0. Global Desktop Shortcuts (F11 Fullscreen)
      if (key == LogicalKeyboardKey.f11) {
        if (Platform.isWindows || Platform.isMacOS || Platform.isLinux) {
          windowManager.isFullScreen().then((isFull) {
            windowManager.setFullScreen(!isFull);
          });
          return true;
        }
      }

      // 1. Check for Configurable Shortcuts first
      final shortcutMap = ref.read(shortcutProvider);

      // We only trigger shortcuts if NOT typing in a TextField
      final isTyping = FocusManager.instance.primaryFocus?.debugLabel
                  ?.contains('EditableText') ==
              true ||
          FocusManager.instance.primaryFocus?.context?.widget is EditableText;

      if (!isTyping) {
        // Find if this key matches any action
        for (final entry in shortcutMap.entries) {
          final mappedKey = entry.value;

          // Match the key, treating Numpad Enter same as Main Enter for shortcuts
          bool matched = (mappedKey == key);
          if (!matched) {
            if (mappedKey == LogicalKeyboardKey.enter &&
                key == LogicalKeyboardKey.numpadEnter) {
              matched = true;
            } else if (mappedKey == LogicalKeyboardKey.numpadEnter &&
                key == LogicalKeyboardKey.enter) {
              matched = true;
            }
          }

          if (matched) {
            // SPECIAL CASE: Global Navigation to Cashier
            if (entry.key == ShortcutAction.goToCashier) {
              // Specifically check for CTRL + MappedKey for this action
              if (HardwareKeyboard.instance.isControlPressed) {
                final context = _navigatorKey.currentContext;
                if (context != null) {
                  _navigateToKasir(context);
                  return true;
                }
              }
              // If we matched the key (Spasi) but CTRL wasn't pressed,
              // we don't consume it here, let it be used as Spasi
              return false;
            }

            // Standard Trigger the action
            ref.read(shortcutProvider.notifier).triggerAction(entry.key);
            return true; // Consume the event
          }
        }
      }

      // 2. Original Barcode Scanning Logic
      // If Enter is pressed, finalize the barcode
      if (key == LogicalKeyboardKey.enter ||
          key == LogicalKeyboardKey.numpadEnter) {
        if (_hardwareBuffer.isNotEmpty) {
          unawaited(_handleGlobalBarcode(_hardwareBuffer));
          _hardwareBuffer = '';
          return true; // Consume Enter if it was for a barcode
        }
        return false;
      }

      // Check for timeout (if user types manually slowly, clear the buffer)
      final now = DateTime.now();
      if (now.difference(_lastHardwareTime).inMilliseconds > 100) {
        _hardwareBuffer = '';
      }
      _lastHardwareTime = now;

      // Only buffer alphanumeric characters and common barcode symbols
      final char = event.character;
      if (char != null && char.isNotEmpty) {
        // Check if it's a "printable" character that could be part of a barcode
        // Barcodes are usually alphanumeric.
        if (RegExp(r'[a-zA-Z0-9]').hasMatch(char) || char.length == 1) {
          _hardwareBuffer += char;
        }
      }
    }
    return false; // Let other widgets get the events if not consumed
  }

  /// Cari produk berdasarkan barcode dengan berbagai strategi matching
  Product? _findProductByBarcode(String code, List<Product> products) {
    String normalized = code.trim().toLowerCase();
    if (normalized.isEmpty) return null;

    // Contoh: "(90)MD123" -> "MD123", "(01)899(17)26" -> "899"
    String cleaned = normalized;
    final gs1AIPattern = RegExp(r'\(\d{2,4}\)');
    if (gs1AIPattern.hasMatch(normalized)) {
      // Jika ada pola (...), coba ambil yang di antaranya
      final parts = normalized.split(gs1AIPattern);
      // Ambil bagian terpanjang yang bukan kosong, biasanya itu kodenya
      cleaned = parts
          .where((s) => s.isNotEmpty)
          .fold("", (p, e) => e.length > p.length ? e : p);
      if (cleaned.isEmpty) cleaned = normalized.replaceAll(gs1AIPattern, '');
    }
    cleaned = cleaned.trim();

    for (final p in products) {
      final pBarcode = (p.barcode ?? '').trim().toLowerCase();
      final pSku = (p.sku ?? '').trim().toLowerCase();
      final pId = (p.id ?? 0).toString();

      if (pBarcode == normalized || pBarcode == cleaned) return p;
      if (pSku == normalized || pSku == cleaned) return p;
      if (pId == normalized || pId == cleaned) return p;
    }

    String stripZeros(String value) => value.replaceFirst(RegExp(r'^0+'), '');
    final sScan = stripZeros(cleaned);
    if (sScan.isNotEmpty) {
      for (final p in products) {
        final pB = stripZeros((p.barcode ?? '').trim().toLowerCase());
        if (pB.isNotEmpty && pB == sScan) return p;
      }
    }

    // Bagus untuk barcode yang punya suffix/prefix tambahan
    for (final p in products) {
      final pB = (p.barcode ?? '').trim().toLowerCase();
      if (pB.length >= 4) {
        if (cleaned.contains(pB) || pB.contains(cleaned)) return p;
      }
    }

    for (final p in products) {
      if (p.name.toLowerCase() == cleaned ||
          p.name.toLowerCase() == normalized) {
        return p;
      }
    }

    return null;
  }

  Future<void> _handleGlobalBarcode(String code) async {
    final trimmed = code.trim();
    if (trimmed.isEmpty) return;

    final context = _navigatorKey.currentContext;
    if (context == null) return;

    final useTts = ref.read(notificationSettingsProvider).useTTS;

    // 1. Cek apakah ini barcode Struk/Resi (No Transaksi)
    final tx = await DBHelper.instance.getTransactionByCode(trimmed);
    if (tx != null) {
      HapticFeedback.vibrate();
      await ScanFeedbackService.instance.playProductFound(
        useTts: useTts,
        productName: 'Transaksi Ditemukan',
      );

      if (!context.mounted) return;
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Transaksi ${tx.transactionCode} ditemukan!'),
        backgroundColor: AppColors.primaryBrand,
        duration: const Duration(seconds: 1),
      ));

      // Buka halaman detail struk untuk cek/update status servis
      _navigatorKey.currentState?.push(
        MaterialPageRoute(
          builder: (context) => StrukScreen(transactionId: tx.id!),
        ),
      );
      return;
    }

    // 2. Jika bukan transaksi, cari produk di katalog (untuk kasir)
    final products = ref.read(productsProvider);
    final found = _findProductByBarcode(trimmed, products);

    if (found != null) {
      if (!context.mounted) return;
      // Navigasi ke halaman kasir jika belum di sana
      _navigateToKasir(context);

      final cart = ref.read(cartProvider);
      if (cart.containsKey(found)) {
        // Jika sudah ada, jangan tambah qty, beri info saja
        await ScanFeedbackService.instance.playAlreadyInCart(
          useTts: useTts,
          productName: found.name,
        );
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).clearSnackBars();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('"${found.name}" sudah ada di keranjang'),
          backgroundColor: Colors.orange.shade800,
          duration: const Duration(seconds: 1),
        ));
      } else {
        // Jika belum ada, tambahkan 1
        ref.read(cartProvider.notifier).addItem(found, qty: 1);
        await ScanFeedbackService.instance.playProductFound(
          useTts: useTts,
          productName: found.name,
        );

        if (!context.mounted) return;
        ScaffoldMessenger.of(context).clearSnackBars();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('"${found.name}" ditambahkan via Remote Scanner'),
          backgroundColor: AppColors.primaryBrand,
          duration: const Duration(seconds: 1),
        ));
      }
    } else {
      HapticFeedback.vibrate();
      await ScanFeedbackService.instance.playNotFound(useTts: useTts);
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Produk dengan kode "$trimmed" tidak ditemukan.'),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 2),
      ));
    }
  }

  void _navigateToKasir(BuildContext context) {
    // Cek apakah sudah di halaman transaksi
    bool isAlreadyKasir = false;
    Navigator.popUntil(context, (route) {
      if (route.settings.name == '/transaksi') isAlreadyKasir = true;
      return true; // tidak pop apapun, hanya cek
    });
    if (!isAlreadyKasir) {
      _navigatorKey.currentState?.pushNamed('/transaksi');
    }
  }

  bool _isTransferDialogShowing = false;

  void _showTransferApprovalDialog(PendingTransferInfo info) {
    if (_isTransferDialogShowing) return;
    final ctx = _navigatorKey.currentContext;
    if (ctx == null) return;

    _isTransferDialogShowing = true;

    final platformLabel = info.requesterPlatform == 'android'
        ? 'Android'
        : info.requesterPlatform == 'desktop'
            ? 'PC/Desktop'
            : info.requesterPlatform;

    showDialog<void>(
      context: ctx,
      barrierDismissible: false,
      builder: (dialogCtx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Row(
          children: [
            Icon(Icons.swap_horiz_rounded,
                color: AppColors.primaryBrand, size: 24),
            SizedBox(width: 8),
            Expanded(child: Text('Permintaan Pindah Perangkat')),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Ada perangkat baru yang ingin menggunakan lisensi Anda:',
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFF3F4F6),
                border: Border.all(color: const Color(0xFFE5E7EB)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        info.requesterPlatform == 'android'
                            ? Icons.phone_android_rounded
                            : Icons.computer_rounded,
                        size: 18,
                        color: const Color(0xFF6B7280),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Platform: $platformLabel',
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Device: ${info.requesterDeviceId}',
                    style: const TextStyle(
                      fontSize: 11,
                      color: Color(0xFF9CA3AF),
                      fontFamily: 'monospace',
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFEF2F2),
                border: Border.all(color: const Color(0xFFFCA5A5)),
              ),
              child: const Text(
                'Jika Anda setujui, akun di perangkat ini akan otomatis keluar.',
                style: TextStyle(
                  fontSize: 12,
                  color: Color(0xFF991B1B),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(dialogCtx);
              _isTransferDialogShowing = false;
              await ref.read(authProvider.notifier).respondToTransfer(
                    requestId: info.requestId,
                    licenseId: info.licenseId,
                    approve: false,
                  );
            },
            child: const Text('Tolak'),
          ),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBrand,
              foregroundColor: Colors.white,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            onPressed: () async {
              Navigator.pop(dialogCtx);
              _isTransferDialogShowing = false;
              await ref.read(authProvider.notifier).respondToTransfer(
                    requestId: info.requestId,
                    licenseId: info.licenseId,
                    approve: true,
                  );
            },
            icon: const Icon(Icons.check_rounded, size: 18),
            label: const Text('Setujui & Keluar'),
          ),
        ],
      ),
    ).then((_) => _isTransferDialogShowing = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_startupError != null) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: _StartupIssueScreen(message: _startupError!),
      );
    }

    if (!_bootstrapDone) {
      return MaterialApp(
        title: AppBranding.appName,
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: AppColors.primaryBrand,
            brightness: Brightness.light,
          ),
          scaffoldBackgroundColor: Colors.white,
        ),
        home: const _SplashScreen(),
      );
    }

    // Hanya gunakan ref.listen — bukan ref.watch — agar MaterialApp
    // tidak rebuild setiap kali auth status berubah.
    ref.listen<AuthStatus>(authProvider, (previous, next) {
      if (previous != next) {
        unawaited(_syncDesktopScannerForAuth(next));
      }
    });

    ref.listen<PendingTransferInfo?>(pendingTransferProvider, (prev, next) {
      if (next != null && prev == null) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _showTransferApprovalDialog(next);
        });
      }
    });

    // MaterialApp sekarang stabil — tidak rebuild saat auth berubah.
    // Pergantian screen ditangani oleh _AuthGate di dalamnya.
    return MaterialApp(
      navigatorKey: _navigatorKey,
      scaffoldMessengerKey: _scaffoldMessengerKey,
      navigatorObservers: [_snackBarRouteObserver],
      title: AppBranding.appName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primaryBrand,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: Colors.white,
        splashFactory: InkRipple.splashFactory,
        dialogTheme: const DialogThemeData(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.zero,
          ),
          surfaceTintColor: Colors.transparent,
        ),
        datePickerTheme: DatePickerThemeData(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.transparent,
          headerBackgroundColor: AppColors.primaryBrand,
          headerForegroundColor: Colors.white,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.zero,
          ),
          elevation: 0,
          todayForegroundColor: WidgetStateProperty.all(AppColors.primaryBrand),
        ),
        textTheme: TextTheme(
          displayLarge: AppText.h1,
          displayMedium: AppText.h2,
          displaySmall: AppText.h3,
          bodyLarge: AppText.body,
          bodyMedium: AppText.body,
          labelLarge: AppText.caption,
        ),
        snackBarTheme: const SnackBarThemeData(
          backgroundColor: Color(0xFF1F2937),
          contentTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 12.5,
            fontWeight: FontWeight.w700,
            letterSpacing: 0,
            height: 1.25,
          ),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
          ),
          elevation: 0,
          insetPadding: EdgeInsets.fromLTRB(14, 0, 14, 12),
        ),
      ),
      home: _AuthGate(splashMinShown: _splashMinShown),
      routes: {
        '/dashboard': (_) => const MainShell(),
        '/transaksi': (_) => const TransaksiScreen(),
        '/produk': (_) => const ProdukScreen(),
        '/kategori': (_) => const KategoriScreen(),
        '/kategori_keuangan': (_) => const KategoriKeuanganScreen(),
        '/laporan': (_) => const LaporanScreen(),
        '/stok': (_) => const StokScreen(),
        '/setting': (_) => const SettingScreen(),
        '/pusat_bantuan': (_) => const PusatBantuanScreen(),
        '/notifikasi': (_) => const DaftarNotifikasiScreen(),
        '/pengaturan_notifikasi': (_) => const NotifikasiScreen(),
        '/sync_settings': (_) => const SyncSettingsScreen(),
        '/juragan_sync': (_) => const JuraganSyncScreen(),
        // Legacy route: arahkan ke checkout baru agar tidak muncul alur checkout ganda.
        '/keranjang': (_) => const CheckoutScreen(),
        '/checkout': (_) => const CheckoutScreen(),
        '/riwayat': (_) => const RiwayatScreen(),
        '/dompet': (_) => const ArusKasScreen(),
        '/arus_kas': (_) => const ArusKasScreen(),
        '/remote_scanner': (_) => const RemoteScannerScreen(),
        '/servis_ops': (_) => const servisStatusScreen(),

        '/pesanan': (_) => const PesananScreen(),
        '/pengaturan_servis': (_) => const PengaturanservisScreen(),
        '/pengaturan_hardware': (_) => const PengaturanHardwareScreen(),
        '/riwayat_pesanan_terhapus': (_) =>
            const RiwayatPesananTerhapusScreen(),

        '/karyawan': (_) => const KaryawanScreen(),
        '/daftar_karyawan': (_) => const DaftarKaryawanScreen(),
        '/riwayat_tutup_kasir': (_) => const RiwayatTutupKasirScreen(),
        '/audit_kasir': (_) => const AuditKasirScreen(),
        '/ai': (_) => const AIInsightScreen(),

        '/pelanggan': (_) => const PelangganMenuScreen(),
        '/daftar_pelanggan': (_) => const DaftarPelangganScreen(),
        '/transaksi_pelanggan': (_) => const TransaksiPelangganScreen(),

        '/laporan/transaksi_penjualan': (_) =>
            const AnalisisLayananservisScreen(),
        '/laporan/omzet_per_bulan': (_) => const OmzetPerBulanScreen(),
        '/laporan/produk_terlaris': (_) => const ProdukTerlarisScreen(),
        '/laporan/produk_terjual': (_) => const ProdukTerjualScreen(),
        '/laporan/arus_kas': (_) => const ArusKasScreen(),
        '/laporan/gudang': (_) => const GudangLaporanScreen(),
        '/laporan/riwayat_stok': (_) => const RiwayatStokLaporanScreen(),
        '/laporan/masa_berlaku_produk': (_) => const MasaBerlakuProdukScreen(),
        '/laporan/keuangan': (_) => const LaporanKeuanganScreen(),

        '/backup_restore': (_) => const BackupRestoreScreen(),
        '/laporan/laba_rugi': (_) => const AnalisisKeuntunganScreen(),
        '/supplier': (_) => const SupplierScreen(),
        '/purchase_order': (_) => const PurchaseOrderScreen(),
        '/pengeluaran': (_) => const PengeluaranScreen(),

        '/retur': (_) => const ReturScreen(),
        '/target_penjualan': (_) => const TargetPenjualanScreen(),
        '/cetak_resi_marketplace': (_) => const CetakResiMarketplaceScreen(),
        '/continuous_scanner': (_) => const ContinuousScannerScreen(),

        '/tambah_transaksi_dompet': (ctx) {
          final type =
              ModalRoute.of(ctx)!.settings.arguments as String? ?? 'masuk';
          return TambahTransaksiDompetScreen(initialType: type);
        },
      },
    );
  }
}

// ---------------------------------------------------------------------------
// _AuthGate — mengganti home screen dengan animasi smooth saat auth berubah.
// Hanya widget ini yang rebuild saat AuthStatus berubah, bukan seluruh
// MaterialApp beserta theme dan routes-nya.
// ---------------------------------------------------------------------------
class _SnackBarRouteObserver extends NavigatorObserver {
  final GlobalKey<ScaffoldMessengerState> _messengerKey;

  _SnackBarRouteObserver(this._messengerKey);

  void _clearSnackBars() {
    _messengerKey.currentState?.clearSnackBars();
  }

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPush(route, previousRoute);
    _clearSnackBars();
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPop(route, previousRoute);
    _clearSnackBars();
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
    _clearSnackBars();
  }

  @override
  void didRemove(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didRemove(route, previousRoute);
    _clearSnackBars();
  }
}

class _AuthGate extends ConsumerWidget {
  final bool splashMinShown;

  const _AuthGate({required this.splashMinShown});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final status = ref.watch(authProvider);
    final showWelcome = ref.watch(_showWelcomeProvider);

    Widget child;
    String key;
    if (status == AuthStatus.initializing || !splashMinShown) {
      child = const _SplashScreen();
      key = 'splash';
    } else {
      switch (status) {
        case AuthStatus.admin:
          child = const AdminDashboardScreen();
          key = 'admin';
          break;
        case AuthStatus.licensee:
          child = const MainShell();
          key = 'licensee';
          break;
        case AuthStatus.initializing:
          child = const _SplashScreen();
          key = 'initializing';
          break;
        case AuthStatus.unauthorized:
          if (showWelcome && (Platform.isAndroid || Platform.isIOS)) {
            child = WelcomeScreen(
              onMasuk: () {
                ref.read(_showWelcomeProvider.notifier).hide();
              },
            );
            key = 'welcome';
          } else {
            child = const LoginLisensiScreen();
            key = 'login';
          }
          break;
      }
    }

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      transitionBuilder: (child, animation) {
        return FadeTransition(
          opacity: CurvedAnimation(
            parent: animation,
            curve: Curves.easeOut,
          ),
          child: child,
        );
      },
      child: KeyedSubtree(
        key: ValueKey(key),
        child: child,
      ),
    );
  }
}

class _StartupIssueScreen extends StatelessWidget {
  final String message;

  const _StartupIssueScreen({required this.message});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: const BoxDecoration(
                      color: AppColors.dangerBg,
                      borderRadius: BorderRadius.zero,
                    ),
                    child: const Icon(
                      Icons.error_outline_rounded,
                      color: AppColors.danger,
                      size: 28,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Aplikasi Belum Siap Dibuka',
                    style: AppText.h2,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Bootstrap gagal karena konfigurasi atau layanan inti belum valid.',
                    style: AppText.body,
                  ),
                  const SizedBox(height: 16),
                  SelectableText(
                    message,
                    style: AppText.caption.copyWith(color: AppColors.danger),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// _SplashScreen — fade-in logo saat pertama muncul, loading indicator smooth
// ---------------------------------------------------------------------------
class _SplashScreen extends StatefulWidget {
  const _SplashScreen();

  @override
  State<_SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<_SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fadeAnim;
  late final Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    // Mulai animasi setelah frame pertama render
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: FadeTransition(
          opacity: _fadeAnim,
          child: SlideTransition(
            position: _slideAnim,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset(
                  'assets/images/logo.png',
                  width: 120,
                  height: 120,
                  errorBuilder: (ctx, _, __) => const Icon(
                    Icons.store_rounded,
                    color: AppColors.primaryBrand,
                    size: 80,
                  ),
                ),
                const SizedBox(height: 24),
                const CircularProgressIndicator(
                  color: AppColors.primaryBrand,
                  strokeWidth: 3,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

