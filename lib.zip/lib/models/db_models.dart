import 'dart:convert';

class Product {
  final int? id;
  final String name;
  final int categoryId;
  final int stock;
  final int buyPrice;
  final int sellPrice;
  final String unit;
  final int minStock;
  final String? createdAt;
  final String? imagePath; // local path to thumbnail image
  final String? description;
  final String? sku;
  final String? barcode;
  final int hasStockManagement;
  final int hasWholesale;
  final int wholesaleMinQty;
  final int wholesalePrice;
  final int hasExtraPopup;
  final int isExtra;
  final String? extraTargetCategories; // comma-separated category IDs
  final String? extraTargetProducts; // comma-separated product IDs
  final String? expiryDate; // expiry date for product (yyyy-MM-dd)
  final int isHardware; // 1=true, 0=false
  final int durationHours; // duration in hours for servis processing
  final int isMaterial; // 1 = bahan baku internal, tidak tampil di order
  final int? supplierId;

  Product({
    this.id,
    required this.name,
    required this.categoryId,
    required this.stock,
    required this.buyPrice,
    required this.sellPrice,
    required this.unit,
    required this.minStock,
    this.createdAt,
    this.imagePath,
    this.description,
    this.sku,
    this.barcode,
    this.hasStockManagement = 0,
    this.hasWholesale = 0,
    this.wholesaleMinQty = 0,
    this.wholesalePrice = 0,
    this.hasExtraPopup = 0,
    this.isExtra = 0,
    this.extraTargetCategories,
    this.extraTargetProducts,
    this.expiryDate,
    this.isHardware = 0,
    this.durationHours = 0,
    this.isMaterial = 0,
    this.supplierId,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'category_id': categoryId,
      'stock': stock,
      'buy_price': buyPrice,
      'sell_price': sellPrice,
      'unit': unit,
      'min_stock': minStock,
      'created_at': createdAt,
      'image_path': imagePath,
      'description': description,
      'sku': sku,
      'barcode': barcode,
      'has_stock_management': hasStockManagement,
      'has_wholesale': hasWholesale,
      'wholesale_min_qty': wholesaleMinQty,
      'wholesale_price': wholesalePrice,
      'has_extra_popup': hasExtraPopup,
      'is_extra': isExtra,
      'extra_target_categories': extraTargetCategories ?? '',
      'extra_target_products': extraTargetProducts ?? '',
      'expiry_date': expiryDate,
      'is_hardware': isHardware,
      'duration_hours': durationHours,
      'is_material': isMaterial,
      'supplier_id': supplierId,
    };
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Product && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;

  Product copyWith({
    int? id,
    String? name,
    int? categoryId,
    int? stock,
    int? buyPrice,
    int? sellPrice,
    String? unit,
    int? minStock,
    String? createdAt,
    String? imagePath,
    String? description,
    String? sku,
    String? barcode,
    int? hasStockManagement,
    int? hasWholesale,
    int? wholesaleMinQty,
    int? wholesalePrice,
    int? hasExtraPopup,
    int? isExtra,
    String? extraTargetCategories,
    String? extraTargetProducts,
    String? expiryDate,
    int? isHardware,
    int? durationHours,
    int? isMaterial,
    int? supplierId,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      categoryId: categoryId ?? this.categoryId,
      stock: stock ?? this.stock,
      buyPrice: buyPrice ?? this.buyPrice,
      sellPrice: sellPrice ?? this.sellPrice,
      unit: unit ?? this.unit,
      minStock: minStock ?? this.minStock,
      createdAt: createdAt ?? this.createdAt,
      imagePath: imagePath ?? this.imagePath,
      description: description ?? this.description,
      sku: sku ?? this.sku,
      barcode: barcode ?? this.barcode,
      hasStockManagement: hasStockManagement ?? this.hasStockManagement,
      hasWholesale: hasWholesale ?? this.hasWholesale,
      wholesaleMinQty: wholesaleMinQty ?? this.wholesaleMinQty,
      wholesalePrice: wholesalePrice ?? this.wholesalePrice,
      hasExtraPopup: hasExtraPopup ?? this.hasExtraPopup,
      isExtra: isExtra ?? this.isExtra,
      extraTargetCategories:
          extraTargetCategories ?? this.extraTargetCategories,
      extraTargetProducts: extraTargetProducts ?? this.extraTargetProducts,
      expiryDate: expiryDate ?? this.expiryDate,
      isHardware: isHardware ?? this.isHardware,
      durationHours: durationHours ?? this.durationHours,
      isMaterial: isMaterial ?? this.isMaterial,
      supplierId: supplierId ?? this.supplierId,
    );
  }

  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'] as int?,
      name: map['name'] ?? '',
      categoryId: map['category_id'] as int,
      stock: map['stock'] as int,
      buyPrice: map['buy_price'] as int,
      sellPrice: map['sell_price'] as int,
      unit: map['unit'] ?? 'pcs',
      minStock: map['min_stock'] as int,
      createdAt: map['created_at'],
      imagePath: map['image_path'] as String?,
      description: map['description'] as String?,
      sku: map['sku'] as String?,
      barcode: map['barcode'] as String?,
      hasStockManagement: map['has_stock_management'] as int? ?? 0,
      hasWholesale: map['has_wholesale'] as int? ?? 0,
      wholesaleMinQty: map['wholesale_min_qty'] as int? ?? 0,
      wholesalePrice: map['wholesale_price'] as int? ?? 0,
      hasExtraPopup: map['has_extra_popup'] as int? ?? 0,
      isExtra: map['is_extra'] as int? ?? 0,
      extraTargetCategories: map['extra_target_categories'] as String?,
      extraTargetProducts: map['extra_target_products'] as String?,
      expiryDate: map['expiry_date'] as String?,
      isHardware: (map['is_hardware'] as int?) ?? 0,
      durationHours: (map['duration_hours'] as int?) ?? 0,
      isMaterial: (map['is_material'] as int?) ?? 0,
      supplierId: map['supplier_id'] as int?,
    );
  }

  /// Menghitung harga per unit berdasarkan jumlah item (mendukung harga grosir)
  int getPrice(double q) {
    if (hasWholesale == 1 && q >= wholesaleMinQty && wholesalePrice > 0) {
      return wholesalePrice;
    }
    return sellPrice;
  }

  bool get tracksInventory => hasStockManagement == 1;

  bool get isMaterialItem => isMaterial == 1;

  bool get isOutOfStock => stock <= 0;
}

class Category {
  final int? id;
  final String? name;
  final int durationHours;

  Category({this.id, this.name, this.durationHours = 0});

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'duration_hours': durationHours,
      };

  factory Category.fromMap(Map<String, dynamic> map) => Category(
        id: map['id'] as int?,
        name: map['name'] as String?,
        durationHours: (map['duration_hours'] as int?) ?? 0,
      );
}

class FinanceCategory {
  final int? id;
  final String name;
  final String type; // 'masuk' | 'keluar'
  final String iconKey;
  final String colorHex;
  final int isSystem;
  final int isActive;
  final int sortOrder;
  final String createdAt;
  final String updatedAt;

  const FinanceCategory({
    this.id,
    required this.name,
    required this.type,
    this.iconKey = 'receipt',
    this.colorHex = '#3A7D7C',
    this.isSystem = 0,
    this.isActive = 1,
    this.sortOrder = 0,
    required this.createdAt,
    required this.updatedAt,
  });

  bool get isIncome => type == 'masuk';
  bool get isExpense => type == 'keluar';
  bool get system => isSystem == 1;
  bool get active => isActive == 1;

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'type': type,
        'icon_key': iconKey,
        'color_hex': colorHex,
        'is_system': isSystem,
        'is_active': isActive,
        'sort_order': sortOrder,
        'created_at': createdAt,
        'updated_at': updatedAt,
      };

  FinanceCategory copyWith({
    int? id,
    String? name,
    String? type,
    String? iconKey,
    String? colorHex,
    int? isSystem,
    int? isActive,
    int? sortOrder,
    String? createdAt,
    String? updatedAt,
  }) {
    return FinanceCategory(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      iconKey: iconKey ?? this.iconKey,
      colorHex: colorHex ?? this.colorHex,
      isSystem: isSystem ?? this.isSystem,
      isActive: isActive ?? this.isActive,
      sortOrder: sortOrder ?? this.sortOrder,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  factory FinanceCategory.fromMap(Map<String, dynamic> map) {
    return FinanceCategory(
      id: map['id'] as int?,
      name: map['name'] as String? ?? '',
      type: map['type'] as String? ?? 'keluar',
      iconKey: map['icon_key'] as String? ?? 'receipt',
      colorHex: map['color_hex'] as String? ?? '#3A7D7C',
      isSystem: (map['is_system'] as num?)?.toInt() ?? 0,
      isActive: (map['is_active'] as num?)?.toInt() ?? 1,
      sortOrder: (map['sort_order'] as num?)?.toInt() ?? 0,
      createdAt: map['created_at'] as String? ?? '',
      updatedAt: map['updated_at'] as String? ?? '',
    );
  }
}

class ProductRecipe {
  final int? id;
  final int serviceProductId;
  final int materialProductId;
  final double qtyPerUnit;
  final String createdAt;

  ProductRecipe({
    this.id,
    required this.serviceProductId,
    required this.materialProductId,
    required this.qtyPerUnit,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'service_product_id': serviceProductId,
        'material_product_id': materialProductId,
        'qty_per_unit': qtyPerUnit,
        'created_at': createdAt,
      };

  factory ProductRecipe.fromMap(Map<String, dynamic> map) => ProductRecipe(
        id: map['id'] as int?,
        serviceProductId: map['service_product_id'] as int,
        materialProductId: map['material_product_id'] as int,
        qtyPerUnit: (map['qty_per_unit'] as num?)?.toDouble() ?? 0,
        createdAt: map['created_at'] as String? ?? '',
      );
}

class servisStation {
  final int? id;
  final String name;
  final String area;
  final int seats;
  final String status;
  final int? activeTransactionId;
  final int? mergedToTableId;
  final String qrSlug;
  final int sortOrder;
  final String updatedAt;

  servisStation({
    this.id,
    required this.name,
    this.area = 'Workshop Utama',
    this.seats = 2,
    this.status = 'available',
    this.activeTransactionId,
    this.mergedToTableId,
    required this.qrSlug,
    this.sortOrder = 0,
    required this.updatedAt,
  });

  String get displayArea =>
      area.trim().isEmpty ? 'Workshop Utama' : area.trim();

  bool get isAvailable => status == 'available' && activeTransactionId == null;

  bool get isOccupied => status == 'occupied' || activeTransactionId != null;

  bool get isMerged => status == 'merged' || mergedToTableId != null;

  String get qrPayload => 'juragan-servis://qr-order/table/$qrSlug';

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'area': area,
        'seats': seats,
        'status': status,
        'active_transaction_id': activeTransactionId,
        'merged_to_table_id': mergedToTableId,
        'qr_slug': qrSlug,
        'sort_order': sortOrder,
        'updated_at': updatedAt,
      };

  factory servisStation.fromMap(Map<String, dynamic> map) => servisStation(
        id: map['id'] as int?,
        name: map['name'] as String? ?? '',
        area: map['area'] as String? ?? 'Workshop Utama',
        seats: (map['seats'] as int?) ?? 2,
        status: map['status'] as String? ?? 'available',
        activeTransactionId: map['active_transaction_id'] as int?,
        mergedToTableId: map['merged_to_table_id'] as int?,
        qrSlug: map['qr_slug'] as String? ?? '',
        sortOrder: (map['sort_order'] as int?) ?? 0,
        updatedAt: map['updated_at'] as String? ?? '',
      );

  servisStation copyWith({
    int? id,
    String? name,
    String? area,
    int? seats,
    String? status,
    int? activeTransactionId,
    bool clearActiveTransaction = false,
    int? mergedToTableId,
    bool clearMergedToTable = false,
    String? qrSlug,
    int? sortOrder,
    String? updatedAt,
  }) {
    return servisStation(
      id: id ?? this.id,
      name: name ?? this.name,
      area: area ?? this.area,
      seats: seats ?? this.seats,
      status: status ?? this.status,
      activeTransactionId: clearActiveTransaction
          ? null
          : (activeTransactionId ?? this.activeTransactionId),
      mergedToTableId:
          clearMergedToTable ? null : (mergedToTableId ?? this.mergedToTableId),
      qrSlug: qrSlug ?? this.qrSlug,
      sortOrder: sortOrder ?? this.sortOrder,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

class servisWorkshopTicket {
  final int? id;
  final int transactionId;
  final String tableName;
  final String? customerName;
  final String? orderType;
  final String status;
  final String station;
  final String? note;
  final String createdAt;
  final String updatedAt;

  servisWorkshopTicket({
    this.id,
    required this.transactionId,
    required this.tableName,
    this.customerName,
    this.orderType,
    this.status = 'queued',
    this.station = 'Workshop',
    this.note,
    required this.createdAt,
    required this.updatedAt,
  });

  bool get isDone => status == 'done';

  Map<String, dynamic> toMap() => {
        'id': id,
        'transaction_id': transactionId,
        'table_name': tableName,
        'customer_name': customerName,
        'order_type': orderType,
        'status': status,
        'station': station,
        'note': note,
        'created_at': createdAt,
        'updated_at': updatedAt,
      };

  factory servisWorkshopTicket.fromMap(Map<String, dynamic> map) =>
      servisWorkshopTicket(
        id: map['id'] as int?,
        transactionId: map['transaction_id'] as int,
        tableName: map['table_name'] as String? ?? '',
        customerName: map['customer_name'] as String?,
        orderType: map['order_type'] as String?,
        status: map['status'] as String? ?? 'queued',
        station: map['station'] as String? ?? 'Workshop',
        note: map['note'] as String?,
        createdAt: map['created_at'] as String? ?? '',
        updatedAt: map['updated_at'] as String? ?? '',
      );
}

class StockLog {
  final int? id;
  final int productId;
  final String type; // 'in' or 'out'
  final int qty;
  final String date;
  final String? stockName; // Nama Stok / batch name e.g. "MAR-JZG"
  final String? entryDate; // Tanggal Masuk (yyyy-MM-dd)
  final String? expiryDate; // Tanggal Kedaluwarsa (nullable)
  final int? oldQty; // Stok sebelum perubahan
  final int? newQty; // Stok setelah perubahan
  final String? employeeName; // Nama karyawan yang input

  StockLog({
    this.id,
    required this.productId,
    required this.type,
    required this.qty,
    required this.date,
    this.stockName,
    this.entryDate,
    this.expiryDate,
    this.oldQty,
    this.newQty,
    this.employeeName,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'product_id': productId,
      'type': type,
      'qty': qty,
      'date': date,
      'stock_name': stockName,
      'entry_date': entryDate,
      'expiry_date': expiryDate,
      'old_qty': oldQty,
      'new_qty': newQty,
      'employee_name': employeeName,
    };
  }

  factory StockLog.fromMap(Map<String, dynamic> map) {
    return StockLog(
      id: map['id'] as int?,
      productId: map['product_id'] as int,
      type: map['type'] ?? 'out',
      qty: map['qty'] as int,
      date: map['date'] ?? '',
      stockName: map['stock_name'] as String?,
      entryDate: map['entry_date'] as String?,
      expiryDate: map['expiry_date'] as String?,
      oldQty: map['old_qty'] as int?,
      newQty: map['new_qty'] as int?,
      employeeName: map['employee_name'] as String?,
    );
  }
}

class License {
  final int? id;
  final String? licenseId;
  final String? serial;
  final String serialHash;
  final String deviceId;
  final int isActive; // SQLite ga ada boolean, pake INTEGER (1=true, 0=false)
  final String? expiredAt;
  final String? lastValidatedAt;
  final String? validationExpiresAt;
  final String signature;
  final int canRemotePrint; // 1=true, 0=false
  final int isTrial; // 1=true, 0=false
  final int ldrPrintCount;

  License({
    this.id,
    this.licenseId,
    this.serial,
    required this.serialHash,
    required this.deviceId,
    required this.isActive,
    this.expiredAt,
    this.lastValidatedAt,
    this.validationExpiresAt,
    this.signature = '',
    this.canRemotePrint = 0,
    this.isTrial = 0,
    this.ldrPrintCount = 0,
  });

  License copyWith({
    int? id,
    String? licenseId,
    String? serial,
    String? serialHash,
    String? deviceId,
    int? isActive,
    String? expiredAt,
    String? lastValidatedAt,
    String? validationExpiresAt,
    String? signature,
    int? canRemotePrint,
    int? isTrial,
    int? ldrPrintCount,
  }) {
    return License(
      id: id ?? this.id,
      licenseId: licenseId ?? this.licenseId,
      serial: serial ?? this.serial,
      serialHash: serialHash ?? this.serialHash,
      deviceId: deviceId ?? this.deviceId,
      isActive: isActive ?? this.isActive,
      expiredAt: expiredAt ?? this.expiredAt,
      lastValidatedAt: lastValidatedAt ?? this.lastValidatedAt,
      validationExpiresAt: validationExpiresAt ?? this.validationExpiresAt,
      signature: signature ?? this.signature,
      canRemotePrint: canRemotePrint ?? this.canRemotePrint,
      isTrial: isTrial ?? this.isTrial,
      ldrPrintCount: ldrPrintCount ?? this.ldrPrintCount,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'license_id': licenseId,
      'serial': serial,
      'serial_hash': serialHash,
      'device_id': deviceId,
      'is_active': isActive,
      'expired_at': expiredAt,
      'last_validated_at': lastValidatedAt,
      'validation_expires_at': validationExpiresAt,
      'signature': signature,
      'can_remote_print': canRemotePrint,
      'is_trial': isTrial,
      'ldr_print_count': ldrPrintCount,
    };
  }

  factory License.fromMap(Map<String, dynamic> map) {
    return License(
      id: map['id'] as int?,
      licenseId: map['license_id']?.toString(),
      serial: map['serial']?.toString(),
      serialHash: map['serial_hash'] ?? '',
      deviceId: map['device_id'] ?? '',
      isActive: map['is_active'] as int,
      expiredAt: map['expired_at'],
      lastValidatedAt: map['last_validated_at']?.toString(),
      validationExpiresAt: map['validation_expires_at']?.toString(),
      signature: map['signature']?.toString() ?? '',
      canRemotePrint: (map['can_remote_print'] as int?) ?? 0,
      isTrial: (map['is_trial'] as int?) ?? 0,
      ldrPrintCount: (map['ldr_print_count'] as int?) ?? 0,
    );
  }
}

// ==============================
// CUSTOMER MODEL
// ==============================
class Customer {
  final int? id;
  final String name;
  final String? phone;
  final String? address;
  final double discountPct; // 0-100, diskon member (%)
  final String? memberCode;
  final String? whatsappValidatedAt;
  final String? whatsappValidatedPhone;
  final String? createdAt;

  Customer({
    this.id,
    required this.name,
    this.phone,
    this.address,
    this.discountPct = 0,
    this.memberCode,
    this.whatsappValidatedAt,
    this.whatsappValidatedPhone,
    this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'address': address,
      'discount_pct': discountPct,
      'member_code': memberCode,
      'whatsapp_validated_at': whatsappValidatedAt,
      'whatsapp_validated_phone': whatsappValidatedPhone,
      'created_at': createdAt,
    };
  }

  factory Customer.fromMap(Map<String, dynamic> map) {
    return Customer(
      id: map['id'] as int?,
      name: map['name'] ?? '',
      phone: map['phone'] as String?,
      address: map['address'] as String?,
      discountPct: (map['discount_pct'] as num?)?.toDouble() ?? 0,
      memberCode: map['member_code'] as String?,
      whatsappValidatedAt: map['whatsapp_validated_at'] as String?,
      whatsappValidatedPhone: map['whatsapp_validated_phone'] as String?,
      createdAt: map['created_at'] as String?,
    );
  }
}

// ==============================
// EMPLOYEE MODEL
// ==============================
class Employee {
  final int? id;
  final String name;
  final String role;
  final String? phone;
  final String? pin;
  final String? permissionsJson;
  final String createdAt;
  final int isActive; // 1 = aktif, 0 = nonaktif

  Employee({
    this.id,
    required this.name,
    this.role = 'Kasir',
    this.phone,
    this.pin,
    this.permissionsJson,
    required this.createdAt,
    this.isActive = 1,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'role': role,
      'phone': phone,
      'pin': pin,
      'permissions_json': permissionsJson,
      'created_at': createdAt,
      'is_active': isActive,
    };
  }

  factory Employee.fromMap(Map<String, dynamic> map) {
    return Employee(
      id: map['id'] as int?,
      name: map['name'] ?? '',
      role: map['role'] ?? 'Kasir',
      phone: map['phone'] as String?,
      pin: map['pin'] as String?,
      permissionsJson: map['permissions_json'] as String?,
      createdAt: map['created_at'] ?? '',
      isActive: (map['is_active'] as int?) ?? 1,
    );
  }
}

// ==============================
// TRANSACTION MODEL
// ==============================
class Transaction {
  final int? id;
  final int? customerId;
  final String? customerName;
  final int totalAmount; // total sebelum diskon & biaya
  final int discountAmount; // diskon (Rp)
  final int additionalCharges; // biaya tambahan (pajak, ongkir, dll)
  final int grandTotal; // total akhir setelah diskon & biaya
  final String paymentMethod; // 'cash', 'qris', 'transfer'
  final int amountPaid; // uang diterima
  final int changeAmount; // kembalian
  final String? note;
  final String createdAt;
  final String updatedAt;
  final int isDeleted;
  final String? deletedAt;
  final String? orderType;
  final String? pickupSchedule;
  final String? fulfillmentType;
  final String? serviceLevel;
  final int slaHours;
  final String? paymentStatus;
  final int queueNumber;
  final String? transactionCode;
  final String servisStatus;
  final String? kelengkapan;
  final String? merekBarang;
  final String? keluhan;
  final String? sandiPola;
  final String? address;
  final String? dueDate;
  final String? lastReminderAt;
  final int reminderCount;

  Transaction({
    this.id,
    this.customerId,
    this.customerName,
    required this.totalAmount,
    this.discountAmount = 0,
    this.additionalCharges = 0,
    this.additionalChargesJson,
    required this.grandTotal,
    required this.paymentMethod,
    required this.amountPaid,
    this.changeAmount = 0,
    this.note,
    required this.createdAt,
    this.updatedAt = '',
    this.isDeleted = 0,
    this.deletedAt,
    this.orderType,
    this.pickupSchedule,
    this.fulfillmentType,
    this.serviceLevel,
    this.slaHours = 0,
    this.paymentStatus,
    this.queueNumber = 0,
    this.transactionCode,
    this.servisStatus = 'Antri',
    this.kelengkapan,
    this.merekBarang,
    this.keluhan,
    this.sandiPola,
    this.address,
    this.dueDate,
    this.lastReminderAt,
    this.reminderCount = 0,
  });

  /// Nama per-item tambahan (Pajak, Ongkir, dsb) dalam bentuk JSON
  final String? additionalChargesJson;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customer_id': customerId,
      'customer_name': customerName,
      'total_amount': totalAmount,
      'discount_amount': discountAmount,
      'additional_charges': additionalCharges,
      'additional_charges_json': additionalChargesJson,
      'grand_total': grandTotal,
      'payment_method': paymentMethod,
      'amount_paid': amountPaid,
      'change_amount': changeAmount,
      'note': note,
      'created_at': createdAt,
      'updated_at': updatedAt.isNotEmpty ? updatedAt : createdAt,
      'is_deleted': isDeleted,
      'deleted_at': deletedAt,
      'order_type': orderType,
      'pickup_schedule': pickupSchedule,
      'fulfillment_type': fulfillmentType,
      'service_level': serviceLevel,
      'sla_hours': slaHours,
      'payment_status': paymentStatus,
      'queue_number': queueNumber,
      'transaction_code': transactionCode,
      'servis_status': servisStatus,
      'kelengkapan': kelengkapan,
      'merek_barang': merekBarang,
      'keluhan': keluhan,
      'sandi_pola': sandiPola,
      'address': address,
      'due_date': dueDate,
      'last_reminder_at': lastReminderAt,
      'reminder_count': reminderCount,
    };
  }

  factory Transaction.fromMap(Map<String, dynamic> map) {
    return Transaction(
      id: map['id'] as int?,
      customerId: map['customer_id'] as int?,
      customerName: map['customer_name'] as String?,
      totalAmount: (map['total_amount'] as int?) ?? 0,
      discountAmount: (map['discount_amount'] as int?) ?? 0,
      additionalCharges: (map['additional_charges'] as int?) ?? 0,
      additionalChargesJson: map['additional_charges_json'] as String?,
      grandTotal: (map['grand_total'] as int?) ?? 0,
      paymentMethod: map['payment_method'] ?? 'cash',
      amountPaid: (map['amount_paid'] as int?) ?? 0,
      changeAmount: (map['change_amount'] as int?) ?? 0,
      note: map['note'] as String?,
      createdAt: map['created_at'] ?? '',
      updatedAt: map['updated_at'] as String? ?? map['created_at'] ?? '',
      isDeleted: map['is_deleted'] as int? ?? 0,
      deletedAt: map['deleted_at'] as String?,
      orderType: map['order_type'] as String?,
      pickupSchedule: map['pickup_schedule'] as String?,
      fulfillmentType: map['fulfillment_type'] as String?,
      serviceLevel: map['service_level'] as String?,
      slaHours: (map['sla_hours'] as num?)?.toInt() ?? 0,
      paymentStatus: map['payment_status'] as String?,
      queueNumber: (map['queue_number'] as int?) ?? 0,
      transactionCode: map['transaction_code'] as String?,
      servisStatus: map['servis_status'] as String? ?? 'Antri',
      kelengkapan: map['kelengkapan'] as String?,
      merekBarang: map['merek_barang'] as String?,
      keluhan: map['keluhan'] as String?,
      sandiPola: map['sandi_pola'] as String?,
      address: map['address'] as String?,
      dueDate: map['due_date'] as String?,
      lastReminderAt: map['last_reminder_at'] as String?,
      reminderCount: (map['reminder_count'] as int?) ?? 0,
    );
  }

  /// Membaca list rincian biaya tambahan dari JSON
  List<Map<String, dynamic>> get chargesList {
    if (additionalChargesJson == null || additionalChargesJson!.isEmpty) {
      return [];
    }
    try {
      return List<Map<String, dynamic>>.from(
          jsonDecode(additionalChargesJson!));
    } catch (_) {
      return [];
    }
  }
}

// ==============================
// AUDIT LOG MODEL
// ==============================
class AuditLog {
  final int? id;
  final String action;
  final String entityType;
  final int? entityId;
  final int? staffId;
  final String staffName;
  final String staffRole;
  final int amount;
  final String note;
  final String? metadataJson;
  final String createdAt;

  AuditLog({
    this.id,
    required this.action,
    required this.entityType,
    this.entityId,
    this.staffId,
    this.staffName = 'Sistem',
    this.staffRole = '',
    this.amount = 0,
    this.note = '',
    this.metadataJson,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'action': action,
        'entity_type': entityType,
        'entity_id': entityId,
        'staff_id': staffId,
        'staff_name': staffName,
        'staff_role': staffRole,
        'amount': amount,
        'note': note,
        'metadata_json': metadataJson,
        'created_at': createdAt,
      };

  factory AuditLog.fromMap(Map<String, dynamic> map) => AuditLog(
        id: map['id'] as int?,
        action: map['action'] as String? ?? '',
        entityType: map['entity_type'] as String? ?? '',
        entityId: map['entity_id'] as int?,
        staffId: map['staff_id'] as int?,
        staffName: map['staff_name'] as String? ?? 'Sistem',
        staffRole: map['staff_role'] as String? ?? '',
        amount: map['amount'] as int? ?? 0,
        note: map['note'] as String? ?? '',
        metadataJson: map['metadata_json'] as String?,
        createdAt: map['created_at'] as String? ?? '',
      );
}

// ==============================
// TRANSACTION ITEM MODEL
// ==============================
class TransactionItem {
  final int? id;
  final int transactionId;
  final int productId;
  final String productName;
  final double qty;
  final int unitPrice;
  final int originalUnitPrice;
  final int originalSubtotal;
  final int priceOverrideAmount;
  final int subtotal;
  final String? note;
  final String? appliedDiscountName;
  final int appliedDiscountIsPercentage;
  final int appliedDiscountValue;
  final int isPriceOverride;
  final String? unit;
  final int isHardware;

  TransactionItem({
    this.id,
    required this.transactionId,
    required this.productId,
    required this.productName,
    required this.qty,
    required this.unitPrice,
    this.originalUnitPrice = 0,
    this.originalSubtotal = 0,
    this.priceOverrideAmount = 0,
    required this.subtotal,
    this.note,
    this.appliedDiscountName,
    this.appliedDiscountIsPercentage = 0,
    this.appliedDiscountValue = 0,
    this.isPriceOverride = 0,
    this.unit,
    this.isHardware = 0,
  });

  int get effectiveOriginalUnitPrice =>
      originalUnitPrice > 0 ? originalUnitPrice : unitPrice;

  int get effectiveOriginalSubtotal =>
      originalSubtotal > 0 ? originalSubtotal : subtotal;

  bool get hasPriceOverride => isPriceOverride == 1;

  bool get hasAppliedPromo =>
      !hasPriceOverride && effectiveOriginalUnitPrice > unitPrice;

  int get unitSavings =>
      hasAppliedPromo ? effectiveOriginalUnitPrice - unitPrice : 0;

  double get totalSavings => unitSavings * qty;

  int get effectivePriceOverrideAmount {
    if (!hasPriceOverride) return 0;
    if (priceOverrideAmount != 0) return priceOverrideAmount;
    return effectiveOriginalSubtotal - subtotal;
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'transaction_id': transactionId,
      'product_id': productId,
      'product_name': productName,
      'qty': qty,
      'unit_price': unitPrice,
      'original_unit_price': originalUnitPrice,
      'original_subtotal': originalSubtotal,
      'price_override_amount': priceOverrideAmount,
      'subtotal': subtotal,
      'note': note,
      'applied_discount_name': appliedDiscountName,
      'applied_discount_is_percentage': appliedDiscountIsPercentage,
      'applied_discount_value': appliedDiscountValue,
      'is_price_override': isPriceOverride,
      'unit': unit,
      'is_hardware': isHardware,
    };
  }

  factory TransactionItem.fromMap(Map<String, dynamic> map) {
    return TransactionItem(
      id: map['id'] as int?,
      transactionId: map['transaction_id'] as int,
      productId: map['product_id'] as int,
      productName: map['product_name'] ?? '',
      qty: (map['qty'] as num).toDouble(),
      unitPrice: map['unit_price'] as int,
      originalUnitPrice: (map['original_unit_price'] as int?) ?? 0,
      originalSubtotal: (map['original_subtotal'] as int?) ?? 0,
      priceOverrideAmount: (map['price_override_amount'] as int?) ?? 0,
      subtotal: map['subtotal'] as int,
      note: map['note'] as String?,
      appliedDiscountName: map['applied_discount_name'] as String?,
      appliedDiscountIsPercentage:
          (map['applied_discount_is_percentage'] as int?) ?? 0,
      appliedDiscountValue: (map['applied_discount_value'] as int?) ?? 0,
      isPriceOverride: (map['is_price_override'] as int?) ?? 0,
      unit: map['unit'] as String?,
      isHardware: (map['is_hardware'] as int?) ?? 0,
    );
  }
}

class Cicilan {
  final int? id;
  final int transactionId;
  final int nominal;
  final String metodePembayaran; // 'tunai' | 'non_tunai'
  final String createdAt;

  Cicilan({
    this.id,
    required this.transactionId,
    required this.nominal,
    required this.metodePembayaran,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'transaction_id': transactionId,
        'nominal': nominal,
        'metode_pembayaran': metodePembayaran,
        'created_at': createdAt,
      };

  factory Cicilan.fromMap(Map<String, dynamic> map) => Cicilan(
        id: map['id'] as int?,
        transactionId: map['transaction_id'] as int,
        nominal: map['nominal'] as int? ?? 0,
        metodePembayaran: map['metode_pembayaran'] as String? ?? 'tunai',
        createdAt: map['created_at'] as String? ?? '',
      );
}

class WalletTransaction {
  final int? id;
  final String walletId; // 'tunai' | 'non_tunai'
  final int nominal;
  final String type; // 'masuk' | 'keluar'
  final String tanggal;
  final String waktu;
  final String keterangan;
  final String createdAt;
  final String?
      kategori; // 'Sewa'|'Listrik/Air'|'Gaji'|'Bahan Baku'|'Transportasi'|'Lainnya'|''
  final int? categoryId;
  final String? fotoPath; // path foto nota
  final String source; // 'manual' | 'system' | 'adjustment'
  final int isDeleted;
  final String? deletedAt;
  final String? updatedAt;

  WalletTransaction({
    this.id,
    required this.walletId,
    required this.nominal,
    required this.type,
    required this.tanggal,
    required this.waktu,
    required this.keterangan,
    required this.createdAt,
    this.kategori,
    this.categoryId,
    this.fotoPath,
    this.source = 'manual',
    this.isDeleted = 0,
    this.deletedAt,
    this.updatedAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'wallet_id': walletId,
        'nominal': nominal,
        'type': type,
        'tanggal': tanggal,
        'waktu': waktu,
        'keterangan': keterangan,
        'created_at': createdAt,
        'kategori': kategori ?? '',
        'category_id': categoryId,
        'foto_path': fotoPath ?? '',
        'source': source,
        'is_deleted': isDeleted,
        'deleted_at': deletedAt,
        'updated_at': updatedAt,
      };

  factory WalletTransaction.fromMap(Map<String, dynamic> map) =>
      WalletTransaction(
        id: map['id'] as int?,
        walletId: map['wallet_id'] ?? 'tunai',
        nominal: (map['nominal'] as num?)?.toInt() ?? 0,
        type: map['type'] ?? 'masuk',
        tanggal: map['tanggal'] ?? '',
        waktu: map['waktu'] ?? '',
        keterangan: map['keterangan'] ?? '',
        createdAt: map['created_at'] ?? '',
        kategori: map['kategori'] as String?,
        categoryId: (map['category_id'] as num?)?.toInt(),
        fotoPath: map['foto_path'] as String?,
        source: map['source'] as String? ?? 'manual',
        isDeleted: map['is_deleted'] as int? ?? 0,
        deletedAt: map['deleted_at'] as String?,
        updatedAt: map['updated_at'] as String?,
      );
}

// ==============================
// KASIR SESSION MODEL
// ==============================
class KasirSession {
  final int? id;
  final String kasirName;
  final String openedAt;
  final String? closedAt;
  final int openingCash;
  final int closingCash;
  final int totalTransactions;
  final int totalRevenue;
  final int totalCash;
  final int totalNonCash;
  final String? notes;
  final String? shiftName;
  final int? staffId;
  final String? staffName;
  final String? staffRole;
  final String deviceId;

  KasirSession({
    this.id,
    required this.kasirName,
    required this.openedAt,
    this.closedAt,
    required this.openingCash,
    this.closingCash = 0,
    this.totalTransactions = 0,
    this.totalRevenue = 0,
    this.totalCash = 0,
    this.totalNonCash = 0,
    this.notes,
    this.shiftName,
    this.staffId,
    this.staffName,
    this.staffRole,
    this.deviceId = '',
  });

  bool get isOpen => closedAt == null || closedAt!.isEmpty;

  int get selisihKas => closingCash - (openingCash + totalCash);

  Map<String, dynamic> toMap() => {
        'id': id,
        'kasir_name': kasirName,
        'opened_at': openedAt,
        'closed_at': closedAt,
        'opening_cash': openingCash,
        'closing_cash': closingCash,
        'total_transactions': totalTransactions,
        'total_revenue': totalRevenue,
        'total_cash': totalCash,
        'total_non_cash': totalNonCash,
        'notes': notes,
        'shift_name': shiftName,
        'staff_id': staffId,
        'staff_name': staffName,
        'staff_role': staffRole,
        'device_id': deviceId,
      };

  factory KasirSession.fromMap(Map<String, dynamic> map) => KasirSession(
        id: map['id'] as int?,
        kasirName: map['kasir_name'] as String? ?? '',
        openedAt: map['opened_at'] as String? ?? '',
        closedAt: map['closed_at'] as String?,
        openingCash: map['opening_cash'] as int? ?? 0,
        closingCash: map['closing_cash'] as int? ?? 0,
        totalTransactions: map['total_transactions'] as int? ?? 0,
        totalRevenue: map['total_revenue'] as int? ?? 0,
        totalCash: map['total_cash'] as int? ?? 0,
        totalNonCash: map['total_non_cash'] as int? ?? 0,
        notes: map['notes'] as String?,
        shiftName: map['shift_name'] as String?,
        staffId: map['staff_id'] as int?,
        staffName: map['staff_name'] as String?,
        staffRole: map['staff_role'] as String?,
        deviceId: map['device_id']?.toString() ?? '',
      );
}

class Discount {
  final int? id;
  final String name;
  final int nominal;
  final int isPercentage; // 0 for Rp, 1 for %
  final String startDate; // ISO String
  final String endDate; // ISO String
  final String productIds; // Comma-separated product IDs
  final String createdAt;

  Discount({
    this.id,
    required this.name,
    required this.nominal,
    required this.isPercentage,
    required this.startDate,
    required this.endDate,
    required this.productIds,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'nominal': nominal,
        'is_percentage': isPercentage,
        'start_date': startDate,
        'end_date': endDate,
        'product_ids': productIds,
        'created_at': createdAt,
      };

  factory Discount.fromMap(Map<String, dynamic> map) => Discount(
        id: map['id'] as int?,
        name: map['name'] ?? '',
        nominal: map['nominal'] as int? ?? 0,
        isPercentage: map['is_percentage'] as int? ?? 0,
        startDate: map['start_date'] ?? '',
        endDate: map['end_date'] ?? '',
        productIds: map['product_ids'] ?? '',
        createdAt: map['created_at'] ?? '',
      );
}

// SUPPLIER MODEL

class Supplier {
  final int? id;
  final String name;
  final String? phone;
  final String? address;
  final int hutang; // total hutang (Rp) ke supplier ini
  final String? keterangan; // keterangan supplier (e.g. supplier makanan)
  final String? createdAt;

  Supplier({
    this.id,
    required this.name,
    this.phone,
    this.address,
    this.hutang = 0,
    this.keterangan,
    this.createdAt,
  });

  Supplier copyWith({
    int? id,
    String? name,
    String? phone,
    String? address,
    int? hutang,
    String? keterangan,
    String? createdAt,
  }) {
    return Supplier(
      id: id ?? this.id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      address: address ?? this.address,
      hutang: hutang ?? this.hutang,
      keterangan: keterangan ?? this.keterangan,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'phone': phone,
        'address': address,
        'hutang': hutang,
        'keterangan': keterangan,
        'created_at': createdAt,
      };

  factory Supplier.fromMap(Map<String, dynamic> map) => Supplier(
        id: map['id'] as int?,
        name: map['name'] ?? '',
        phone: map['phone'] as String?,
        address: map['address'] as String?,
        hutang: map['hutang'] as int? ?? 0,
        keterangan: map['keterangan'] as String?,
        createdAt: map['created_at'] as String?,
      );
}

// PURCHASE ORDER MODEL

class PurchaseOrder {
  final int? id;
  final int? supplierId;
  final String supplierName;
  final int totalAmount;
  final String status; // 'draft' | 'partial_received' | 'received'
  final String? note;
  final String createdAt;
  final String? receivedAt;
  final int isPaid; // 0 = belum bayar, 1 = lunas
  final int paidAmount;
  final int receivedAmount;

  PurchaseOrder({
    this.id,
    this.supplierId,
    required this.supplierName,
    required this.totalAmount,
    this.status = 'draft',
    this.note,
    required this.createdAt,
    this.receivedAt,
    this.isPaid = 0,
    this.paidAmount = 0,
    this.receivedAmount = 0,
  });

  bool get isFullyReceived => status == 'received';
  bool get isPartiallyReceived => status == 'partial_received';
  bool get hasReceivedGoods => isFullyReceived || isPartiallyReceived;

  int get effectivePaidAmount => isPaid == 1 && paidAmount <= 0
      ? totalAmount
      : paidAmount.clamp(0, totalAmount).toInt();

  int get outstandingAmount {
    final payableBase = receivedAmount > 0
        ? receivedAmount
        : (hasReceivedGoods ? totalAmount : 0);
    final remaining = payableBase - effectivePaidAmount;
    return remaining > 0 ? remaining : 0;
  }

  String get itemStatusLabel {
    if (isFullyReceived) return 'Diterima';
    if (isPartiallyReceived) return 'Diterima Sebagian';
    return 'Menunggu Terima';
  }

  String get paymentStatusLabel {
    if (isPaid == 1 || effectivePaidAmount >= totalAmount) return 'Lunas';
    if (hasReceivedGoods && outstandingAmount <= 0 && effectivePaidAmount > 0) {
      return 'Dibayar';
    }
    if (effectivePaidAmount > 0) return 'Bayar Sebagian';
    return 'Tempo';
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'supplier_id': supplierId,
        'supplier_name': supplierName,
        'total_amount': totalAmount,
        'status': status,
        'note': note,
        'created_at': createdAt,
        'received_at': receivedAt,
        'is_paid': isPaid,
        'paid_amount': paidAmount,
      };

  factory PurchaseOrder.fromMap(Map<String, dynamic> map) => PurchaseOrder(
        id: map['id'] as int?,
        supplierId: map['supplier_id'] as int?,
        supplierName: map['supplier_name'] ?? '',
        totalAmount: map['total_amount'] as int? ?? 0,
        status: map['status'] ?? 'draft',
        note: map['note'] as String?,
        createdAt: map['created_at'] ?? '',
        receivedAt: map['received_at'] as String?,
        isPaid: map['is_paid'] as int? ?? 0,
        paidAmount: map['paid_amount'] as int? ??
            (((map['is_paid'] as int? ?? 0) == 1)
                ? (map['total_amount'] as int? ?? 0)
                : 0),
        receivedAmount: (map['received_amount'] as num?)?.toInt() ??
            (map['total_received_amount'] as num?)?.toInt() ??
            (((map['status'] ?? 'draft') == 'received')
                ? (map['total_amount'] as int? ?? 0)
                : 0),
      );
}

// PURCHASE ITEM MODEL

class PurchaseItem {
  final int? id;
  final int purchaseOrderId;
  final int productId;
  final String productName;
  final int qty;
  final int unitPrice;
  final int subtotal;
  final int receivedQty;

  PurchaseItem({
    this.id,
    required this.purchaseOrderId,
    required this.productId,
    required this.productName,
    required this.qty,
    required this.unitPrice,
    required this.subtotal,
    this.receivedQty = 0,
  });

  int get remainingQty {
    final remaining = qty - receivedQty;
    return remaining > 0 ? remaining : 0;
  }

  bool get isFullyReceived => receivedQty >= qty;

  Map<String, dynamic> toMap() => {
        'id': id,
        'purchase_order_id': purchaseOrderId,
        'product_id': productId,
        'product_name': productName,
        'qty': qty,
        'unit_price': unitPrice,
        'subtotal': subtotal,
        'received_qty': receivedQty,
      };

  factory PurchaseItem.fromMap(Map<String, dynamic> map) => PurchaseItem(
        id: map['id'] as int?,
        purchaseOrderId: map['purchase_order_id'] as int,
        productId: map['product_id'] as int,
        productName: map['product_name'] ?? '',
        qty: (map['qty'] as num?)?.toInt() ?? 0,
        unitPrice: map['unit_price'] as int? ?? 0,
        subtotal: map['subtotal'] as int? ?? 0,
        receivedQty: (map['received_qty'] as num?)?.toInt() ?? 0,
      );
}

// RETURN TRANSACTION MODEL

class ReturnTransaction {
  final int? id;
  final int transactionId;
  final String? customerName;
  final String reason; // 'cacat', 'salah_item', 'kadaluarsa', 'lainnya'
  final String refundMethod; // 'tunai', 'non_tunai', legacy 'kredit'
  final int totalRefund;
  final String? note;
  final String createdAt;

  ReturnTransaction({
    this.id,
    required this.transactionId,
    this.customerName,
    required this.reason,
    required this.refundMethod,
    required this.totalRefund,
    this.note,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'transaction_id': transactionId,
        'customer_name': customerName,
        'reason': reason,
        'refund_method': refundMethod,
        'total_refund': totalRefund,
        'note': note,
        'created_at': createdAt,
      };

  factory ReturnTransaction.fromMap(Map<String, dynamic> map) =>
      ReturnTransaction(
        id: map['id'] as int?,
        transactionId: map['transaction_id'] as int,
        customerName: map['customer_name'] as String?,
        reason: map['reason'] ?? '',
        refundMethod: map['refund_method'] ?? 'tunai',
        totalRefund: map['total_refund'] as int? ?? 0,
        note: map['note'] as String?,
        createdAt: map['created_at'] ?? '',
      );

  String get reasonLabel {
    switch (reason.trim().toLowerCase()) {
      case 'cacat':
      case 'rusak':
      case 'cacat / rusak':
        return 'Barang Cacat';
      case 'salah_item':
      case 'salah item':
        return 'Salah Item';
      case 'hasil_kurang_baik':
      case 'hasil kurang baik':
        return 'Hasil Kurang Baik';
      case 'hilang_tertukar':
      case 'hilang / tertukar':
        return 'Hilang / Tertukar';
      case 'batal_layanan':
      case 'batal / lainnya':
        return 'Batal Layanan';
      case 'kadaluarsa':
        return 'Kadaluarsa';
      case 'lainnya':
        return 'Lainnya';
      default:
        return reason;
    }
  }

  String get normalizedRefundMethod {
    final value = refundMethod.trim().toLowerCase();
    if (value == 'cash' || value == 'tunai') return 'tunai';
    if (value == 'non_tunai' ||
        value == 'nontunai' ||
        value == 'non tunai' ||
        value == 'transfer' ||
        value == 'qris') {
      return 'non_tunai';
    }
    if (value == 'piutang' || value == 'kredit' || value == 'saldo') {
      return 'kredit';
    }
    return value.isEmpty ? 'tunai' : value;
  }

  bool get isCashRefund => normalizedRefundMethod == 'tunai';

  String get refundMethodLabel {
    switch (normalizedRefundMethod) {
      case 'tunai':
        return 'Tunai';
      case 'non_tunai':
        return 'Non Tunai';
      case 'kredit':
        return 'Kredit Pelanggan';
      default:
        return refundMethod;
    }
  }
}

// RETURN ITEM MODEL

class ReturnItem {
  final int? id;
  final int returnId;
  final int productId;
  final String productName;
  final double qty;
  final int unitPrice;
  final int subtotal;

  ReturnItem({
    this.id,
    required this.returnId,
    required this.productId,
    required this.productName,
    required this.qty,
    required this.unitPrice,
    required this.subtotal,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'return_id': returnId,
        'product_id': productId,
        'product_name': productName,
        'qty': qty,
        'unit_price': unitPrice,
        'subtotal': subtotal,
      };

  factory ReturnItem.fromMap(Map<String, dynamic> map) => ReturnItem(
        id: map['id'] as int?,
        returnId: map['return_id'] as int,
        productId: map['product_id'] as int,
        productName: map['product_name'] ?? '',
        qty: (map['qty'] as num?)?.toDouble() ?? 0.0,
        unitPrice: map['unit_price'] as int? ?? 0,
        subtotal: map['subtotal'] as int? ?? 0,
      );
}

class Profile {
  final String nama;
  final String fotoPath;
  final String adminPinHash;
  final String legacyAdminPin;

  Profile({
    required this.nama,
    required this.fotoPath,
    this.adminPinHash = '',
    this.legacyAdminPin = '',
  });

  bool get hasAdminPin => adminPinHash.trim().isNotEmpty;

  Map<String, dynamic> toMap() => {
        'nama': nama,
        'foto_path': fotoPath,
        'admin_pin_hash': adminPinHash,
        'admin_pin': legacyAdminPin,
      };

  factory Profile.fromMap(Map<String, dynamic> map) => Profile(
        nama: map['nama'] ?? '',
        fotoPath: map['foto_path'] ?? '',
        adminPinHash: map['admin_pin_hash'] as String? ?? '',
        legacyAdminPin: map['admin_pin'] as String? ?? '',
      );

  Profile copyWith({
    String? nama,
    String? fotoPath,
    String? adminPinHash,
    String? legacyAdminPin,
  }) {
    return Profile(
      nama: nama ?? this.nama,
      fotoPath: fotoPath ?? this.fotoPath,
      adminPinHash: adminPinHash ?? this.adminPinHash,
      legacyAdminPin: legacyAdminPin ?? this.legacyAdminPin,
    );
  }
}

class LabelSettings {
  final int paperSizeMm; // 58 or 80
  final bool showName;
  final bool showPrice;
  final bool showSku;
  final bool showBarcode;
  final bool showStoreName;
  final bool showDate;
  final String priceAlign; // 'left' | 'center' | 'right'
  final String barcodePosition; // 'top' | 'bottom'
  final String fontSize; // 'small' | 'normal' | 'large'
  final int labelsPerRow; // 1 or 2
  final String storeName;
  final int thermalBarcodeHeight; // ESC/POS dots
  final int thermalBarcodeWidth; // ESC/POS module width 2..6

  LabelSettings({
    this.paperSizeMm = 58,
    this.showName = true,
    this.showPrice = true,
    this.showSku = false,
    this.showBarcode = true,
    this.showStoreName = true,
    this.showDate = false,
    this.priceAlign = 'center',
    this.barcodePosition = 'bottom',
    this.fontSize = 'normal',
    this.labelsPerRow = 1,
    this.storeName = 'Toko Anda',
    this.thermalBarcodeHeight = 64,
    this.thermalBarcodeWidth = 2,
  });

  LabelSettings copyWith({
    int? paperSizeMm,
    bool? showName,
    bool? showPrice,
    bool? showSku,
    bool? showBarcode,
    bool? showStoreName,
    bool? showDate,
    String? priceAlign,
    String? barcodePosition,
    String? fontSize,
    int? labelsPerRow,
    String? storeName,
    int? thermalBarcodeHeight,
    int? thermalBarcodeWidth,
  }) {
    return LabelSettings(
      paperSizeMm: paperSizeMm ?? this.paperSizeMm,
      showName: showName ?? this.showName,
      showPrice: showPrice ?? this.showPrice,
      showSku: showSku ?? this.showSku,
      showBarcode: showBarcode ?? this.showBarcode,
      showStoreName: showStoreName ?? this.showStoreName,
      showDate: showDate ?? this.showDate,
      priceAlign: priceAlign ?? this.priceAlign,
      barcodePosition: barcodePosition ?? this.barcodePosition,
      fontSize: fontSize ?? this.fontSize,
      labelsPerRow: labelsPerRow ?? this.labelsPerRow,
      storeName: storeName ?? this.storeName,
      thermalBarcodeHeight: thermalBarcodeHeight ?? this.thermalBarcodeHeight,
      thermalBarcodeWidth: thermalBarcodeWidth ?? this.thermalBarcodeWidth,
    );
  }
}

