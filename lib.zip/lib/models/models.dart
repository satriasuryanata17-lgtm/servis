import 'package:flutter/material.dart';

class Transaction {
  final String id;
  final String name;
  final String amount;
  final bool isPositive;
  const Transaction({
    required this.id,
    required this.name,
    required this.amount,
    this.isPositive = true,
  });
}

class QuickAction {
  final String label;
  final Color cardColor;
  final Widget iconContent; // Using generic widget to allow stacked icons
  final String route;
  const QuickAction({
    required this.label,
    required this.cardColor,
    required this.iconContent,
    required this.route,
  });
}

