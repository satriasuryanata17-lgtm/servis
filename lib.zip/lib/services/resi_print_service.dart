import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:printing/printing.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image/image.dart' as img;
import 'resi_log_service.dart';
import 'resi_ocr_service.dart';
import 'esc_pos_helper.dart';

class ResiBatchStatus {
  final int total;
  final int current;
  final String fileName;
  final bool isDone;

  ResiBatchStatus(
      {required this.total,
      required this.current,
      required this.fileName,
      this.isDone = false});
}

/// Top-level function for isolate processing (must be top-level for compute())
Uint8List? _imageProcess(
    ({Uint8List bytes, bool optimize, String brandingText}) data) {
  var image = img.decodeImage(data.bytes);
  if (image == null) return null;

  //  Smart Rotation
  if (image.width > image.height) {
    image = img.copyRotate(image, angle: 90);
  }

  //  Auto Crop
  if (data.optimize) {
    int top = image.height, bottom = 0, left = image.width, right = 0;
    bool found = false;
    for (int y = 0; y < image.height; y++) {
      for (int x = 0; x < image.width; x++) {
        final pixel = image.getPixel(x, y);
        if (pixel.r < 240 || pixel.g < 240 || pixel.b < 240) {
          if (x < left) left = x;
          if (x > right) right = x;
          if (y < top) top = y;
          if (y > bottom) bottom = y;
          found = true;
        }
      }
    }
    if (found) {
      left = (left - 5).clamp(0, image.width);
      top = (top - 5).clamp(0, image.height);
      right = (right + 5).clamp(0, image.width);
      bottom = (bottom + 5).clamp(0, image.height);
      image = img.copyCrop(image,
          x: left, y: top, width: right - left, height: bottom - top);
    }
  }

  //  Branding (Footer)
  if (data.brandingText.isNotEmpty) {
    const footerHeight = 40;
    final newImage =
        img.Image(width: image.width, height: image.height + footerHeight);
    img.fill(newImage, color: img.ColorRgb8(255, 255, 255));
    img.compositeImage(newImage, image);

    // Draw separator line
    img.drawLine(newImage,
        x1: 10,
        y1: image.height + 5,
        x2: image.width - 10,
        y2: image.height + 5,
        color: img.ColorRgb8(200, 200, 200),
        thickness: 1);

    image = newImage;
  }

  return Uint8List.fromList(img.encodePng(image));
}

class ResiPrintService {
  static final _instance = ResiPrintService._internal();
  factory ResiPrintService() => _instance;
  ResiPrintService._internal();

  StreamSubscription<FileSystemEvent>? _watcherSubscription;
  bool _isWatching = false;

  //  SETTINGS
  static const String keyPaperSize = 'resi_paper_size'; // 58 or 80
  static const String keyAutoPrint = 'resi_auto_print';
  static const String keyWatchPath = 'resi_watch_path';
  static const String keyWinPrinter = 'resi_win_printer';
  static const String keyOptimizePaper = 'resi_optimize_paper';
  static const String keyAutoDelete = 'resi_auto_delete_7d';
  static const String keyBrandingText = 'resi_branding_text';

  final _batchStatusController = StreamController<ResiBatchStatus>.broadcast();
  Stream<ResiBatchStatus> get batchStatusStream =>
      _batchStatusController.stream;

  Future<int> getPaperSize() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(keyPaperSize) ?? 58;
  }

  Future<void> setPaperSize(int size) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(keyPaperSize, size);
  }

  Future<void> setAutoPrint(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(keyAutoPrint, enabled);
    if (enabled) {
      await startFolderWatcher();
    } else {
      stopFolderWatcher();
    }
  }

  Future<void> setWatchPath(String path) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(keyWatchPath, path);
    if (_isWatching) {
      stopFolderWatcher();
      await startFolderWatcher();
    }
  }

  Future<String?> getWatchPath() async {
    final prefs = await SharedPreferences.getInstance();
    String? path = prefs.getString(keyWatchPath);
    if (path == null && Platform.isWindows) {
      final downloadDir = await getDownloadsDirectory();
      path = downloadDir?.path;
    }
    return path;
  }

  Future<bool> getAutoPrint() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(keyAutoPrint) ?? false;
  }

  Future<String?> getWinPrinter() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyWinPrinter);
  }

  Future<void> setWinPrinter(String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(keyWinPrinter, name);
  }

  Future<bool> getOptimizePaper() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(keyOptimizePaper) ?? false;
  }

  Future<void> setOptimizePaper(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(keyOptimizePaper, enabled);
  }

  Future<bool> getAutoDelete() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(keyAutoDelete) ?? false;
  }

  Future<void> setAutoDelete(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(keyAutoDelete, enabled);
  }

  Future<String> getBrandingText() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyBrandingText) ?? '';
  }

  Future<void> setBrandingText(String text) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(keyBrandingText, text);
  }

  //  PRINTING LOGIC

  /// Memproses file (PDF/Image) untuk dicetak ke printer thermal
  Future<bool> printFile(File file, {bool isBatch = false}) async {
    final bytes = await file.readAsBytes();
    final ext = file.path.split('.').last.toLowerCase();

    // OCR Detection
    final ocrResult = await ResiOcrService().detect(file);
    final tracking = ocrResult.trackingNumber;
    final courier = ocrResult.courier;

    if (ext == 'pdf') {
      return await _processAndPrintPdf(bytes, tracking, courier, isBatch);
    }

    if (['jpg', 'jpeg', 'png', 'webp'].contains(ext)) {
      return await _processAndPrintImage(bytes, tracking, courier, isBatch);
    }
    return false;
  }

  /// Memproses antrean cetak banyak file
  Future<void> printBatch(List<File> files) async {
    int total = files.length;
    for (int i = 0; i < total; i++) {
      final file = files[i];
      _batchStatusController.add(ResiBatchStatus(
          total: total,
          current: i + 1,
          fileName: file.path.split(Platform.pathSeparator).last));

      await printFile(file, isBatch: true);

      // Delay kecil antar cetakan agar printer thermal tidak overheat/skip
      await Future.delayed(const Duration(milliseconds: 800));
    }
    _batchStatusController.add(ResiBatchStatus(
        total: total, current: total, fileName: '', isDone: true));
  }

  Future<bool> _processAndPrintPdf(
      Uint8List pdfBytes, String tracking, String courier, bool isBatch) async {
    try {
      await for (var page in Printing.raster(pdfBytes, pages: [0], dpi: 200)) {
        final imageBytes = await page.toPng();
        return await _processAndPrintImage(
            imageBytes, tracking, courier, isBatch);
      }
    } catch (e) {
      debugPrint('Error processing PDF: $e');
    }
    return false;
  }

  Future<bool> _processAndPrintImage(
      Uint8List bytes, String tracking, String courier, bool isBatch) async {
    var imageToPrint = bytes;

    // Resolve async values BEFORE passing to isolate
    final optimize = await getOptimizePaper();
    final brandingText = await getBrandingText();

    // Run heavy image processing in background isolate
    final processed = await compute(_imageProcess,
        (bytes: bytes, optimize: optimize, brandingText: brandingText));

    if (processed != null) imageToPrint = processed;

    final success = await printImage(imageToPrint);
    if (success) {
      await ResiLogService().logPrint(
          trackingNumber: tracking,
          courier: courier,
          source: isBatch
              ? 'Bulk Print'
              : (Platform.isWindows ? 'Manual Windows' : 'Mobile Share'));
    }
    return success;
  }

  /// Mencetak Image ke printer (Bluetooth untuk Mobile, System untuk Windows)
  Future<bool> printImage(Uint8List imageBytes) async {
    final paperSize = await getPaperSize();

    if (kIsWeb) return false;

    if (Platform.isWindows) {
      final winPrinter = await getWinPrinter();

      Future<Uint8List> onLayout(PdfPageFormat format) async {
        final doc = pw.Document();
        final image = pw.MemoryImage(imageBytes);
        doc.addPage(
          pw.Page(
            pageFormat: PdfPageFormat(
              (paperSize == 80 ? 80 : 58) * PdfPageFormat.mm,
              200 * PdfPageFormat.mm, // Panjang fleksibel
              marginAll: 0,
            ),
            build: (pw.Context context) {
              return pw.Center(child: pw.Image(image));
            },
          ),
        );
        return doc.save();
      }

      if (winPrinter != null && winPrinter.isNotEmpty) {
        // Direct print bypasses the dialog
        try {
          final printers = await Printing.listPrinters();
          final printer = printers.firstWhere((p) => p.name == winPrinter);
          return await Printing.directPrintPdf(
            printer: printer,
            onLayout: onLayout,
            format: PdfPageFormat(
                (paperSize == 80 ? 80 : 58) * PdfPageFormat.mm,
                200 * PdfPageFormat.mm),
          );
        } catch (e) {
          debugPrint('Direct print failed, falling back to layout: $e');
        }
      }

      // Default to layout (showing dialog) if printer not set or failed
      return await Printing.layoutPdf(onLayout: onLayout);
    } else {
      // Di Mobile (Android/iOS), hubungkan printer bluetooth
      bool isConnected = await PrintBluetoothThermal.connectionStatus;

      if (!isConnected) {
        // "Smart" Auto-Connect: Coba hubungkan ke printer yang terakhir kali digunakan (terbagi dengan Struk Kasir)
        final prefs = await SharedPreferences.getInstance();
        final mac = prefs.getString('struk_printerMac') ?? '';

        if (mac.isNotEmpty) {
          debugPrint('Printer tidak terhubung, mencoba auto-connect ke: $mac');
          isConnected =
              await PrintBluetoothThermal.connect(macPrinterAddress: mac);
        }
      }

      if (!isConnected) return false;

      // Berikan jeda sedikit setelah koneksi berhasil
      await Future.delayed(const Duration(milliseconds: 500));

      // Convert image bytes (PNG/JPG) to ESC/POS raster bytes
      final decodedImage = img.decodeImage(imageBytes);
      if (decodedImage == null) return false;

      final List<int> printerBytes = [0x1B, 0x40]; // Initialize
      final rasterBytes =
          EscPosHelper.imageToRasterBytes(decodedImage, paperSize: paperSize);
      printerBytes.addAll(rasterBytes);

      // Add feed and cut
      printerBytes.addAll([0x0A, 0x0A, 0x1D, 0x56, 0x01]);

      return await PrintBluetoothThermal.writeBytes(printerBytes);
    }
  }

  //  WINDOWS AUTO-PRINT (WATCHER)

  Future<void> startFolderWatcher() async {
    if (_isWatching || !Platform.isWindows) return;

    final isAuto = await getAutoPrint();
    if (!isAuto) return;

    String? path = await getWatchPath();
    if (path == null || !Directory(path).existsSync()) {
      debugPrint('Watch Path not found or invalid: $path');
      return;
    }

    debugPrint('Starting Folder Watcher on: $path');
    _isWatching = true;

    // Run cleanup once on start
    _cleanupOldArchive(path);

    _watcherSubscription = Directory(path).watch().listen((event) {
      if (event.type == FileSystemEvent.create) {
        final filePath = event.path;
        final ext = filePath.split('.').last.toLowerCase();
        if (['pdf', 'jpg', 'jpeg', 'png', 'webp'].contains(ext)) {
          debugPrint('New file detected: $filePath. Printing in 1s...');

          Future.delayed(const Duration(seconds: 1), () async {
            final file = File(filePath);
            if (await file.exists()) {
              final success = await printFile(file);

              if (success) {
                // "Very Smart" Logic: Move to archive folder so it doesn't get printed again
                // and keeps the monitored folder clean.
                try {
                  final archiveDir = Directory(
                      '${file.parent.path}${Platform.pathSeparator}tercetak');
                  if (!archiveDir.existsSync()) {
                    archiveDir.createSync();
                  }

                  final fileName = file.path.split(Platform.pathSeparator).last;
                  final newPath =
                      '${archiveDir.path}${Platform.pathSeparator}$fileName';

                  // Handle name collision in archive
                  var finalPath = newPath;
                  if (File(finalPath).existsSync()) {
                    final timestamp = DateTime.now().millisecondsSinceEpoch;
                    finalPath =
                        '${archiveDir.path}${Platform.pathSeparator}${timestamp}_$fileName';
                  }

                  await file.rename(finalPath);
                  debugPrint('File archived to: $finalPath');
                } catch (e) {
                  debugPrint('Error archiving file: $e');
                }
              }
            }
          });
        }
      }
    });
  }

  void stopFolderWatcher() {
    _watcherSubscription?.cancel();
    _isWatching = false;
  }

  /// Menghapus file di folder 'tercetak' yang sudah lebih dari 7 hari
  Future<void> _cleanupOldArchive(String watchPath) async {
    final isAutoDelete = await getAutoDelete();
    if (!isAutoDelete) return;

    try {
      final archiveDir =
          Directory('$watchPath${Platform.pathSeparator}tercetak');
      if (archiveDir.existsSync()) {
        final now = DateTime.now();
        final sevenDaysAgo = now.subtract(const Duration(days: 7));

        await for (var file in archiveDir.list()) {
          if (file is File) {
            final stat = await file.stat();
            if (stat.modified.isBefore(sevenDaysAgo)) {
              await file.delete();
              debugPrint('Auto-deleted old archive: ${file.path}');
            }
          }
        }
      }
    } catch (e) {
      debugPrint('Error during archive cleanup: $e');
    }
  }
}

