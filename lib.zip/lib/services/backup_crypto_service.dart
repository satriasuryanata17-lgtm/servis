import 'dart:convert';
import 'dart:math';

import 'package:cryptography/cryptography.dart' as cryptography;

class BackupCryptoService {
  static const encryptedExtension = 'jkb';
  static const _envelopeType = 'juraganservis_encrypted_backup';
  static const _legacyEnvelopeType = 'juragankasir_encrypted_backup';
  static const _formatVersion = 1;
  static const _kdfIterations = 120000;
  static final Random _secureRandom = Random.secure();
  static final cryptography.AesGcm _cipher = cryptography.AesGcm.with256bits();
  static final cryptography.Pbkdf2 _kdf = cryptography.Pbkdf2(
    macAlgorithm: cryptography.Hmac.sha256(),
    iterations: _kdfIterations,
    bits: 256,
  );

  static bool looksLikeEncryptedEnvelope(Map<String, dynamic> data) {
    return (data['type'] == _envelopeType ||
            data['type'] == _legacyEnvelopeType) &&
        data['ciphertext_b64'] is String &&
        data['nonce_b64'] is String &&
        data['salt_b64'] is String &&
        data['mac_b64'] is String;
  }

  static void validatePassphrase(String passphrase) {
    final clean = passphrase.trim();
    if (clean.length < 8) {
      throw const FormatException(
        'Kata sandi backup minimal 8 karakter.',
      );
    }
  }

  static Future<Map<String, dynamic>> encryptJsonPayload({
    required String payloadJson,
    required int appVersion,
    required String exportedAt,
    required String passphrase,
  }) async {
    validatePassphrase(passphrase);

    final salt = _randomBytes(16);
    final nonce = _randomBytes(12);
    final secretKey = await _kdf.deriveKeyFromPassword(
      password: passphrase.trim(),
      nonce: salt,
    );
    final secretBox = await _cipher.encrypt(
      utf8.encode(payloadJson),
      secretKey: secretKey,
      nonce: nonce,
    );

    return {
      'type': _envelopeType,
      'format_version': _formatVersion,
      'app_version': appVersion,
      'exported_at': exportedAt,
      'cipher': 'aes_gcm_256',
      'kdf': 'pbkdf2_hmac_sha256',
      'iterations': _kdfIterations,
      'salt_b64': _encodeBase64(salt),
      'nonce_b64': _encodeBase64(secretBox.nonce),
      'mac_b64': _encodeBase64(secretBox.mac.bytes),
      'ciphertext_b64': _encodeBase64(secretBox.cipherText),
    };
  }

  static Future<Map<String, dynamic>> decryptJsonPayload({
    required Map<String, dynamic> envelope,
    required String passphrase,
  }) async {
    if (!looksLikeEncryptedEnvelope(envelope)) {
      throw const FormatException(
        'Format backup terenkripsi tidak valid atau tidak lengkap.',
      );
    }

    validatePassphrase(passphrase);

    final salt = _decodeBase64(envelope['salt_b64']);
    final nonce = _decodeBase64(envelope['nonce_b64']);
    final mac = _decodeBase64(envelope['mac_b64']);
    final cipherText = _decodeBase64(envelope['ciphertext_b64']);
    final iterations =
        (envelope['iterations'] as num?)?.toInt() ?? _kdfIterations;

    final kdf = cryptography.Pbkdf2(
      macAlgorithm: cryptography.Hmac.sha256(),
      iterations: iterations,
      bits: 256,
    );
    final secretKey = await kdf.deriveKeyFromPassword(
      password: passphrase.trim(),
      nonce: salt,
    );

    try {
      final clearBytes = await _cipher.decrypt(
        cryptography.SecretBox(
          cipherText,
          nonce: nonce,
          mac: cryptography.Mac(mac),
        ),
        secretKey: secretKey,
      );
      final decoded = jsonDecode(utf8.decode(clearBytes));
      if (decoded is! Map) {
        throw const FormatException('Payload backup terenkripsi tidak valid.');
      }
      return decoded.map(
        (key, value) => MapEntry(key.toString(), value),
      );
    } on cryptography.SecretBoxAuthenticationError {
      throw const FormatException(
        'Kata sandi backup salah atau file backup telah dimodifikasi.',
      );
    }
  }

  static String? readExportedAt(Map<String, dynamic> envelope) {
    return envelope['exported_at']?.toString();
  }

  static int? readAppVersion(Map<String, dynamic> envelope) {
    return (envelope['app_version'] as num?)?.toInt() ??
        (envelope['version'] as num?)?.toInt();
  }

  static List<int> _randomBytes(int length) {
    return List<int>.generate(length, (_) => _secureRandom.nextInt(256));
  }

  static String _encodeBase64(List<int> bytes) {
    return base64UrlEncode(bytes).replaceAll('=', '');
  }

  static List<int> _decodeBase64(dynamic value) {
    final raw = value?.toString().trim() ?? '';
    if (raw.isEmpty) {
      throw const FormatException('Field backup terenkripsi tidak lengkap.');
    }
    final padding = (4 - raw.length % 4) % 4;
    return base64Url.decode('$raw${'=' * padding}');
  }
}

