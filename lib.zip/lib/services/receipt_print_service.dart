import 'dart:io';
import 'dart:math' as math;

import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:image/image.dart' as img;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:flutter_thermal_printer/Windows/printers_data.dart' as ftp_win;
import 'package:flutter_thermal_printer/Windows/print_data.dart' as ftp_print;
import 'package:win32/win32.dart' as win32;
import 'package:ffi/ffi.dart' as ffi;
import 'esc_pos_helper.dart';

enum ReceiptPrintLineStyle { normal, bold, largeBold }

enum ReceiptPrintLineAlign { left, center, right }

class ReceiptPrintLine {
  final String text;
  final ReceiptPrintLineStyle style;
  final ReceiptPrintLineAlign align;

  const ReceiptPrintLine(
    this.text, {
    this.style = ReceiptPrintLineStyle.normal,
    this.align = ReceiptPrintLineAlign.left,
  });
}

class ReceiptPrintItem {
  final String name;
  final double qty;
  final int unitPrice;
  final int subtotal;
  final String unit;
  final int isHardware;
  final String note;
  final int originalUnitPrice;
  final int originalSubtotal;
  final int priceOverrideAmount;
  final String appliedDiscountName;
  final int appliedDiscountIsPercentage;
  final int appliedDiscountValue;
  final bool isPriceOverride;

  const ReceiptPrintItem({
    required this.name,
    required this.qty,
    required this.unitPrice,
    required this.subtotal,
    this.unit = '',
    this.isHardware = 0,
    this.note = '',
    this.originalUnitPrice = 0,
    this.originalSubtotal = 0,
    this.priceOverrideAmount = 0,
    this.appliedDiscountName = '',
    this.appliedDiscountIsPercentage = 0,
    this.appliedDiscountValue = 0,
    this.isPriceOverride = false,
  });

  int get effectiveOriginalUnitPrice =>
      originalUnitPrice > 0 ? originalUnitPrice : unitPrice;

  bool get hasAppliedPromo =>
      !isPriceOverride && effectiveOriginalUnitPrice > unitPrice;

  int get effectivePriceOverrideAmount {
    if (!isPriceOverride) return 0;
    if (priceOverrideAmount != 0) return priceOverrideAmount;
    final baseSubtotal = originalSubtotal > 0 ? originalSubtotal : subtotal;
    return baseSubtotal - subtotal;
  }

  double get billableQty {
    if (unitPrice <= 0 || subtotal <= 0) return qty;
    final billed = subtotal / unitPrice;
    return billed > 0 ? billed : qty;
  }

  bool get hasRoundedBilling {
    final normalizedUnit = unit.trim().toLowerCase();
    if (normalizedUnit != 'kg' && isHardware != 1) return false;
    return (billableQty - qty).abs() > 0.001;
  }
}

class ReceiptPrintCharge {
  final String label;
  final int value;

  const ReceiptPrintCharge({
    required this.label,
    required this.value,
  });
}

class ReceiptPrintDocument {
  final int paperSize;
  final int lineWidth;
  final List<ReceiptPrintLine> lines;
  final List<ReceiptPrintItem> items;
  final int subtotal;
  final int discountAmount;
  final List<ReceiptPrintCharge> charges;
  final int additionalCharges;
  final int grandTotal;
  final int amountPaid;
  final int changeAmount;
  final String namaWarung;
  final String alamat;
  final String telepon;
  final String footer;
  final String instagram;
  final String facebook;
  final String tiktok;
  final String noTransaksi;
  final String tanggal;
  final String kasirName;
  final String paymentMethod;
  final bool showAlamat;
  final bool showTelepon;
  final bool showTotalPesanan;
  final String? customerName;
  final String? orderType;
  final String? pickupSchedule;
  final String? paymentStatus;
  final String? kelengkapan;
  final String? note;
  final int queueNumber;
  final String logoPosition; // 'top', 'bottom', 'left'
  final double logoWidth; // in mm (e.g., 30, 40, 50)
  final double storeNameFontSize;
  final bool showWatermark;
  final String title;
  final bool isWorkshop;

  const ReceiptPrintDocument({
    required this.paperSize,
    required this.lineWidth,
    required this.lines,
    required this.items,
    required this.subtotal,
    required this.discountAmount,
    required this.charges,
    required this.additionalCharges,
    required this.grandTotal,
    required this.amountPaid,
    required this.changeAmount,
    required this.namaWarung,
    required this.alamat,
    required this.telepon,
    required this.footer,
    required this.instagram,
    required this.facebook,
    required this.tiktok,
    required this.noTransaksi,
    required this.tanggal,
    required this.kasirName,
    required this.paymentMethod,
    required this.showAlamat,
    required this.showTelepon,
    required this.showTotalPesanan,
    this.customerName,
    this.orderType,
    this.pickupSchedule,
    this.paymentStatus,
    this.kelengkapan,
    this.note,
    this.queueNumber = 0,
    this.logoPosition = 'top',
    this.logoWidth = 40.0,
    this.storeNameFontSize = 18.0,
    this.showWatermark = false,
    this.title = 'STRUK servis',
    this.isWorkshop = false,
  });
}

class ReceiptPdfPrintData {
  final pw.Document document;
  final PdfPageFormat format;

  const ReceiptPdfPrintData({
    required this.document,
    required this.format,
  });
}

class ReceiptPrintService {
  static List<int> cashDrawerKickBytes({
    int pin = 0,
    int onTimeMs = 120,
    int offTimeMs = 240,
  }) {
    final int safePin = pin == 1 ? 1 : 0;
    final int onUnits = (onTimeMs / 2).round().clamp(1, 255).toInt();
    final int offUnits = (offTimeMs / 2).round().clamp(1, 255).toInt();
    return <int>[0x1B, 0x70, safePin, onUnits, offUnits];
  }

  static int paperSizeFromUkuran(String ukuranKertas) {
    return ukuranKertas == '80mm' ? 80 : 58;
  }

  static int lineWidthFromUkuran(String ukuranKertas) {
    return ukuranKertas == '80mm'
        ? 38
        : 28; // Maximum safety margins for Windows drivers
  }

  static ReceiptPrintDocument buildDocument({
    required String ukuranKertas,
    required String namaWarung,
    required String alamat,
    required String telepon,
    required String footer,
    required String instagram,
    required String facebook,
    required String tiktok,
    String logoPosition = 'top',
    double logoWidth = 40.0,
    double storeNameFontSize = 18.0,
    required bool showAlamat,
    required bool showTelepon,
    required bool showTotalPesanan,
    bool showWatermark = false,
    required String noTransaksi,
    required String tanggal,
    required String kasirName,
    required String paymentMethod,
    required List<ReceiptPrintItem> items,
    required int subtotal,
    required int discountAmount,
    required List<ReceiptPrintCharge> charges,
    required int additionalCharges,
    int? grandTotal,
    int? amountPaid,
    int? changeAmount,
    String? customerName,
    String? orderType,
    String? pickupSchedule,
    String? paymentStatus,
    String? kelengkapan,
    String? note,
    int queueNumber = 0,
    String title = 'STRUK servis',
    bool isWorkshop = false,
  }) {
    final int paperSize = paperSizeFromUkuran(ukuranKertas);
    final int lineWidth = lineWidthFromUkuran(ukuranKertas);

    return ReceiptPrintDocument(
      paperSize: paperSize,
      lineWidth: lineWidth,
      lines: const [],
      items: items,
      subtotal: subtotal,
      discountAmount: discountAmount,
      charges: charges,
      additionalCharges: additionalCharges,
      grandTotal: grandTotal ?? 0,
      amountPaid: amountPaid ?? 0,
      changeAmount: changeAmount ?? 0,
      namaWarung: namaWarung,
      alamat: alamat,
      telepon: telepon,
      footer: footer,
      instagram: instagram,
      facebook: facebook,
      tiktok: tiktok,
      noTransaksi: noTransaksi,
      tanggal: tanggal,
      kasirName: kasirName,
      paymentMethod: paymentMethod,
      showAlamat: showAlamat,
      showTelepon: showTelepon,
      showTotalPesanan: showTotalPesanan,
      customerName: customerName,
      orderType: orderType,
      pickupSchedule: pickupSchedule,
      paymentStatus: paymentStatus,
      kelengkapan: kelengkapan,
      note: note,
      queueNumber: queueNumber,
      logoPosition: logoPosition,
      logoWidth: logoWidth,
      storeNameFontSize: storeNameFontSize,
      showWatermark: showWatermark,
      title: title,
      isWorkshop: isWorkshop,
    );
  }

  static double _normalizedStoreNameFontSize(double value) {
    return value.clamp(14.0, 32.0).toDouble();
  }

  static double _pdfStoreNameFontSize(
    ReceiptPrintDocument document, {
    bool compact = false,
  }) {
    final base = _normalizedStoreNameFontSize(document.storeNameFontSize);
    final double adjusted = compact
        ? base - (document.paperSize == 80 ? 3.0 : 2.0)
        : base + (document.paperSize == 80 ? 2.0 : 0.0);

    return adjusted
        .clamp(compact ? 12.0 : 16.0, compact ? 22.0 : 30.0)
        .toDouble();
  }

  static int _pdfStoreNameMaxLines(ReceiptPrintDocument document) {
    // Dinamically determine maxLines: prefer 1 line, but allow 2 if name is too long
    // Threshold: ~30 chars for readable output on thermal printer width
    return document.namaWarung.length <= 30 ? 1 : 2;
  }

  static Future<ReceiptPdfPrintData> buildPdfDocument({
    required ReceiptPrintDocument document,
    required String logoPath,
  }) async {
    final pdf = pw.Document();
    // Using Roboto Mono (Sans-Serif Monospaced) to perfectly match the Android/Hardware font look
    final font = await PdfGoogleFonts.robotoMonoBold();
    final fontBold = await PdfGoogleFonts.robotoMonoBold();

    // CALIBRATION: Use Pure Printable Width for PDF Document
    // Using the exact printable width (48mm for 58mm paper, 72mm for 80mm paper)
    // prevents Windows drivers from adding unwanted margins or shifting the content.
    final bool is80 = document.paperSize == 80;
    final double printableWidth = is80 ? 72.0 : 48.0;

    // 28 chars * 0.6 * 7.5pt = 126 pts. (Fits in 48mm/136pts with ~5pts margin)
    final double normalFontSize = is80 ? 8.5 : 7.5;
    final double storeNameFontSize = _pdfStoreNameFontSize(document);
    final double compactStoreNameFontSize =
        _pdfStoreNameFontSize(document, compact: true);
    final double smallFontSize = is80 ? 7.5 : 6.0;

    final format = PdfPageFormat(
      printableWidth * PdfPageFormat.mm,
      double.infinity,
      marginAll: 0,
    );

    pw.ImageProvider? logoImage;
    if (logoPath.isNotEmpty) {
      try {
        final logoFile = File(logoPath);
        if (await logoFile.exists()) {
          logoImage = pw.MemoryImage(await logoFile.readAsBytes());
        }
      } catch (_) {}
    }

    pdf.addPage(
      pw.Page(
        pageFormat: format,
        margin: pw.EdgeInsets.zero,
        build: (context) {
          final logoWidget = logoImage != null
              ? pw.Container(
                  width: document.logoWidth * PdfPageFormat.mm,
                  height: document.logoWidth * PdfPageFormat.mm,
                  margin: pw.EdgeInsets.only(
                      bottom: document.logoPosition == 'top'
                          ? 5 * PdfPageFormat.mm
                          : 0),
                  child: pw.Image(logoImage, fit: pw.BoxFit.contain),
                )
              : pw.SizedBox();

          return pw.Padding(
            padding: const pw.EdgeInsets.symmetric(
                horizontal: 0, vertical: 5 * PdfPageFormat.mm),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.center,
              children: [
                // 1. Logo TOP
                if (document.logoPosition == 'top') logoWidget,

                // 2. Header (Name + Logo LEFT)
                if (document.namaWarung.isNotEmpty)
                  if (document.logoPosition == 'left' && logoImage != null)
                    pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.center,
                      crossAxisAlignment: pw.CrossAxisAlignment.center,
                      children: [
                        pw.Container(
                          width: (document.logoWidth * 0.6) * PdfPageFormat.mm,
                          margin: const pw.EdgeInsets.only(
                              right: 5 * PdfPageFormat.mm),
                          child: pw.Image(logoImage),
                        ),
                        pw.Expanded(
                          child: pw.Text(
                            document.namaWarung.toUpperCase(),
                            maxLines: _pdfStoreNameMaxLines(document),
                            textAlign: pw.TextAlign.left,
                            style: pw.TextStyle(
                                font: fontBold,
                                fontSize: compactStoreNameFontSize,
                                fontWeight: pw.FontWeight.bold,
                                lineSpacing: 1.0),
                          ),
                        ),
                      ],
                    )
                  else
                    pw.Text(document.namaWarung.toUpperCase(),
                        maxLines: _pdfStoreNameMaxLines(document),
                        style: pw.TextStyle(
                            font: fontBold,
                            fontSize: storeNameFontSize,
                            lineSpacing: 1.0),
                        textAlign: pw.TextAlign.center),

                if (document.showAlamat && document.alamat.isNotEmpty)
                  pw.Text(document.alamat,
                      style: pw.TextStyle(font: font, fontSize: smallFontSize),
                      textAlign: pw.TextAlign.center),
                if (document.showTelepon && document.telepon.isNotEmpty)
                  pw.Text('Telp: ${document.telepon}',
                      style: pw.TextStyle(font: font, fontSize: smallFontSize),
                      textAlign: pw.TextAlign.center),

                pw.SizedBox(height: 5 * PdfPageFormat.mm),
                pw.Text('-' * document.lineWidth,
                    style: pw.TextStyle(font: font, fontSize: normalFontSize)),

                // INFO
                pw.Padding(
                  padding: const pw.EdgeInsets.symmetric(
                      vertical: 2 * PdfPageFormat.mm),
                  child: pw.Column(
                    children: [
                      _pdfRow('NO: ${document.noTransaksi}', document.tanggal,
                          font, normalFontSize),
                      if (document.isWorkshop)
                        pw.Padding(
                          padding: const pw.EdgeInsets.symmetric(vertical: 2),
                          child: pw.Text(
                              document.customerName?.toUpperCase() ?? 'MEJA: -',
                              style: pw.TextStyle(
                                  font: fontBold,
                                  fontSize: normalFontSize + 4)),
                        )
                      else ...[
                        if (document.paymentMethod
                            .toUpperCase()
                            .startsWith('CAMPURAN'))
                          pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                _pdfRow(
                                    'KASIR: ${document.kasirName.toUpperCase()}',
                                    '',
                                    font,
                                    normalFontSize),
                                pw.Padding(
                                  padding: const pw.EdgeInsets.only(top: 2),
                                  child: pw.Text(
                                      'Pembayaran: ${document.paymentMethod.toUpperCase()}',
                                      style: pw.TextStyle(
                                          font: font, fontSize: smallFontSize)),
                                ),
                              ])
                        else
                          _pdfRow(
                              'KASIR: ${document.kasirName.toUpperCase()}',
                              document.paymentMethod.toUpperCase(),
                              font,
                              normalFontSize),
                        if (document.customerName != null &&
                            document.customerName!.isNotEmpty)
                          pw.Text('Pelanggan: ${document.customerName}',
                              style: pw.TextStyle(
                                  font: fontBold, fontSize: normalFontSize)),
                      ],
                      if (document.orderType != null &&
                          document.orderType!.isNotEmpty)
                        pw.Text('Jenis: ${document.orderType}',
                            style: pw.TextStyle(
                                font: fontBold, fontSize: normalFontSize)),
                      if (document.pickupSchedule != null &&
                          document.pickupSchedule!.isNotEmpty)
                        pw.Text('Est. Pengambilan: ${document.pickupSchedule}',
                            style: pw.TextStyle(
                                font: font, fontSize: normalFontSize)),
                      if (!document.isWorkshop &&
                          document.paymentStatus != null &&
                          document.paymentStatus!.isNotEmpty)
                        pw.Text('Status: ${document.paymentStatus}',
                            style: pw.TextStyle(
                                font: fontBold, fontSize: normalFontSize)),
                      if (document.kelengkapan != null &&
                          document.kelengkapan!.isNotEmpty &&
                          document.kelengkapan != 'None')
                        pw.Text('Parfum: ${document.kelengkapan}',
                            style: pw.TextStyle(
                                font: font, fontSize: normalFontSize)),
                    ],
                  ),
                ),

                pw.Text('-' * document.lineWidth,
                    style: pw.TextStyle(font: font, fontSize: normalFontSize)),
                pw.SizedBox(height: 2 * PdfPageFormat.mm),

                // ITEMS
                ...document.items.map((item) => pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        if (document.isWorkshop)
                          pw.Row(
                            crossAxisAlignment: pw.CrossAxisAlignment.start,
                            children: [
                              pw.Text('${_itemQtyLabel(item)} x ',
                                  style: pw.TextStyle(
                                      font: fontBold,
                                      fontSize: normalFontSize + 4)),
                              pw.Expanded(
                                child: pw.Text(item.name,
                                    style: pw.TextStyle(
                                        font: fontBold,
                                        fontSize: normalFontSize + 2)),
                              ),
                            ],
                          )
                        else ...[
                          pw.Text(item.name,
                              style: pw.TextStyle(
                                  font: fontBold, fontSize: normalFontSize)),
                          _pdfRow(
                              '  ${_itemPriceLine(item, rupiah: false)}${_getItemSimpleDiscountInfo(item)}',
                              _formatNumber(item.subtotal),
                              font,
                              normalFontSize),
                          if (item.isPriceOverride)
                            pw.Text(
                              '  Harga awal ${_formatNumber(item.originalSubtotal > 0 ? item.originalSubtotal : item.subtotal + item.effectivePriceOverrideAmount)}',
                              style: pw.TextStyle(
                                font: font,
                                fontSize: normalFontSize - 1,
                              ),
                            ),
                        ],
                        if (item.note.isNotEmpty)
                          pw.Padding(
                            padding: const pw.EdgeInsets.only(left: 4),
                            child: pw.Text('  Catatan: ${item.note}',
                                style: pw.TextStyle(
                                    font: fontBold,
                                    fontSize: normalFontSize,
                                    fontStyle: pw.FontStyle.italic)),
                          ),
                        pw.SizedBox(height: 1 * PdfPageFormat.mm),
                      ],
                    )),

                pw.SizedBox(height: 2 * PdfPageFormat.mm),
                pw.Text('-' * document.lineWidth,
                    style: pw.TextStyle(font: font, fontSize: normalFontSize)),

                // TOTALS
                if (!document.isWorkshop) ...[
                  pw.SizedBox(height: 2 * PdfPageFormat.mm),
                  if (document.showTotalPesanan)
                    _pdfRow('Subtotal', _formatNumber(document.subtotal), font,
                        normalFontSize),
                  if (document.discountAmount > 0)
                    _pdfRow(
                        _getDiskonLabel(document),
                        '-${_formatNumber(document.discountAmount)}',
                        font,
                        normalFontSize),
                  ...document.charges.map((c) => _pdfRow(
                      c.label, _formatNumber(c.value), font, normalFontSize)),
                  pw.SizedBox(height: 1 * PdfPageFormat.mm),
                  pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    children: [
                      pw.Text('GRAND TOTAL',
                          style: pw.TextStyle(
                              font: fontBold, fontSize: normalFontSize + 1)),
                      pw.Text(_formatNumber(document.grandTotal),
                          style: pw.TextStyle(
                              font: fontBold, fontSize: normalFontSize + 1)),
                    ],
                  ),
                  pw.SizedBox(height: 1 * PdfPageFormat.mm),
                  _pdfRow('Bayar', _formatNumber(document.amountPaid), font,
                      normalFontSize),
                  _pdfRow('Kembalian', _formatNumber(document.changeAmount),
                      font, normalFontSize),
                  pw.SizedBox(height: 5 * PdfPageFormat.mm),
                  pw.Text('-' * document.lineWidth,
                      style:
                          pw.TextStyle(font: font, fontSize: normalFontSize)),
                  pw.SizedBox(height: 2 * PdfPageFormat.mm),

                  // SOCIAL MEDIA
                  _buildPdfSocial(document, font, smallFontSize),
                  pw.SizedBox(height: 2 * PdfPageFormat.mm),

                  pw.Text('-' * document.lineWidth,
                      style:
                          pw.TextStyle(font: font, fontSize: normalFontSize)),
                  pw.SizedBox(height: 2 * PdfPageFormat.mm),

                  // FOOTER
                  if (document.note != null && document.note!.isNotEmpty) ...[
                    pw.Align(
                      alignment: pw.Alignment.centerLeft,
                      child: pw.Text(
                        'Catatan Tambahan',
                        style: pw.TextStyle(
                          font: fontBold,
                          fontSize: normalFontSize,
                        ),
                      ),
                    ),
                    pw.SizedBox(height: 2),
                    pw.Align(
                      alignment: pw.Alignment.centerLeft,
                      child: pw.Text(
                        document.note!,
                        style: pw.TextStyle(
                          font: font,
                          fontSize: normalFontSize,
                        ),
                      ),
                    ),
                    pw.SizedBox(height: 2 * PdfPageFormat.mm),
                    pw.Text('-' * document.lineWidth,
                        style:
                            pw.TextStyle(font: font, fontSize: normalFontSize)),
                    pw.SizedBox(height: 2 * PdfPageFormat.mm),
                  ],

                  pw.Text(
                    document.footer.isNotEmpty
                        ? document.footer
                        : 'Terima kasih telah berbelanja!',
                    style: pw.TextStyle(font: font, fontSize: normalFontSize),
                    textAlign: pw.TextAlign.center,
                  ),
                ] else ...[
                  pw.SizedBox(height: 10 * PdfPageFormat.mm),
                  pw.Text('TIKET WORKSHOP - JURAGAN servis',
                      style:
                          pw.TextStyle(font: font, fontSize: smallFontSize - 1),
                      textAlign: pw.TextAlign.center),
                ],
                if (document.showWatermark)
                  pw.Text('Powered by Juragan Servis',
                      style:
                          pw.TextStyle(font: font, fontSize: smallFontSize - 1),
                      textAlign: pw.TextAlign.center),

                pw.SizedBox(height: 5 * PdfPageFormat.mm),
                // BARCODE FOR PICKUP
                pw.Center(
                  child: pw.Container(
                    width: 40 * PdfPageFormat.mm,
                    height: 10 * PdfPageFormat.mm,
                    child: pw.BarcodeWidget(
                      barcode: pw.Barcode.code128(),
                      data: document.noTransaksi,
                      drawText: false,
                    ),
                  ),
                ),
                pw.Text(document.noTransaksi,
                    style: pw.TextStyle(font: font, fontSize: smallFontSize),
                    textAlign: pw.TextAlign.center),

                // 3. Logo BOTTOM
                if (document.logoPosition == 'bottom')
                  pw.Container(
                    margin:
                        const pw.EdgeInsets.only(top: 10 * PdfPageFormat.mm),
                    child: logoWidget,
                  ),

                pw.SizedBox(
                    height: 15 * PdfPageFormat.mm), // Generous feed for Windows
              ],
            ),
          );
        },
      ),
    );

    return ReceiptPdfPrintData(document: pdf, format: format);
  }

  /// PRO-GRADE: Direct Raw Print for Windows Desktop
  /// Sends ESC/POS byte commands directly to the hardware printer factory font.
  static Future<void> printRawEscPosDesktop({
    required List<int> bytes,
    required String printerName,
  }) async {
    if (printerName.isEmpty) throw 'Nama printer belum dikonfigurasi.';

    // VERSION 1.2.1+1 Internal API usage for stability on Windows
    final devices = ftp_win.PrinterNames(win32.PRINTER_ENUM_LOCAL);
    String? matchedName;

    // Search for the printer by name
    for (var name in devices.all()) {
      if (name.toLowerCase() == printerName.toLowerCase() ||
          name.toLowerCase().contains(printerName.toLowerCase())) {
        matchedName = name;
        break;
      }
    }

    if (matchedName == null) {
      throw 'Printer "$printerName" tidak ditemukan. Pastikan sudah terinstall di Windows.';
    }

    // Direct Win32 Raw Print Spooling
    ffi.using((ffi.Arena alloc) {
      final printer = ftp_print.RawPrinter(matchedName!, alloc);
      printer.printEscPosWin32(bytes);
    });
  }

  static pw.Widget _pdfRow(
      String left, String right, pw.Font font, double size) {
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pw.Expanded(
            child:
                pw.Text(left, style: pw.TextStyle(font: font, fontSize: size))),
        pw.Text(right, style: pw.TextStyle(font: font, fontSize: size)),
      ],
    );
  }

  static Future<img.Image?> _loadSafeEscPosLogo({
    required ReceiptPrintDocument document,
    required String logoPath,
  }) async {
    if (logoPath.isEmpty) return null;

    final logoFile = File(logoPath);
    if (!await logoFile.exists()) return null;

    final decoded = img.decodeImage(await logoFile.readAsBytes());
    if (decoded == null) return null;

    var logo = img.bakeOrientation(decoded);
    if (logo.numChannels == 4) {
      logo = img.trim(logo, mode: img.TrimMode.transparent);
    }
    logo = _normalizeCornerBackgroundToWhite(logo);
    logo = img.trim(logo, mode: img.TrimMode.topLeftColor);
    logo = _flattenLogoOnWhite(logo);

    final int maxWidthPx = document.paperSize == 80 ? 320 : 220;
    final int maxHeightPx = document.paperSize == 80 ? 180 : 120;
    final int requestedWidthPx =
        ((document.logoWidth.clamp(20.0, 60.0)) * 8).round();

    final double widthScale = requestedWidthPx / logo.width;
    final double maxWidthScale = maxWidthPx / logo.width;
    final double maxHeightScale = maxHeightPx / logo.height;
    final double scale = math.max(
      0.1,
      math.min(widthScale, math.min(maxWidthScale, maxHeightScale)),
    );

    final int targetWidth = math.max(1, (logo.width * scale).round());
    final int targetHeight = math.max(1, (logo.height * scale).round());
    logo = img.copyResize(
      logo,
      width: targetWidth,
      height: targetHeight,
      interpolation: img.Interpolation.linear,
    );

    return _convertLogoToThermalInk(logo);
  }

  static img.Image _normalizeCornerBackgroundToWhite(img.Image src) {
    if (src.width <= 1 || src.height <= 1) return src;

    final corners = <img.Pixel>[
      src.getPixel(0, 0),
      src.getPixel(src.width - 1, 0),
      src.getPixel(0, src.height - 1),
      src.getPixel(src.width - 1, src.height - 1),
    ];
    final reference = corners.first;
    final similarCornerCount = corners
        .where((corner) => _isSimilarColor(corner, reference, tolerance: 28))
        .length;
    if (similarCornerCount < 3) return src;

    final int backgroundLuminance = _pixelLuminance(reference);
    if (backgroundLuminance > 235 && reference.a >= 250) {
      return src;
    }

    bool hasBrighterForeground = false;
    final int stepX = math.max(1, src.width ~/ 24);
    final int stepY = math.max(1, src.height ~/ 24);
    for (int y = 0; y < src.height && !hasBrighterForeground; y += stepY) {
      for (int x = 0; x < src.width; x += stepX) {
        final pixel = src.getPixel(x, y);
        if (_pixelLuminance(pixel) > backgroundLuminance + 50 &&
            !_isSimilarColor(pixel, reference, tolerance: 36)) {
          hasBrighterForeground = true;
          break;
        }
      }
    }
    if (!hasBrighterForeground) return src;

    final normalized = img.Image(width: src.width, height: src.height);
    for (int y = 0; y < src.height; y++) {
      for (int x = 0; x < src.width; x++) {
        final pixel = src.getPixel(x, y);
        if (_isSimilarColor(pixel, reference, tolerance: 32)) {
          normalized.setPixelRgba(x, y, 255, 255, 255, 255);
        } else {
          normalized.setPixelRgba(x, y, pixel.r, pixel.g, pixel.b, pixel.a);
        }
      }
    }

    return normalized;
  }

  static bool _isSimilarColor(
    img.Pixel a,
    img.Pixel b, {
    int tolerance = 24,
  }) {
    return (a.r - b.r).abs() <= tolerance &&
        (a.g - b.g).abs() <= tolerance &&
        (a.b - b.b).abs() <= tolerance &&
        (a.a - b.a).abs() <= tolerance;
  }

  static int _pixelLuminance(img.Pixel pixel) {
    return (0.299 * pixel.r + 0.587 * pixel.g + 0.114 * pixel.b).round();
  }

  static img.Image _convertLogoToThermalInk(img.Image src) {
    final corners = <img.Pixel>[
      src.getPixel(0, 0),
      src.getPixel(src.width - 1, 0),
      src.getPixel(0, src.height - 1),
      src.getPixel(src.width - 1, src.height - 1),
    ];
    final int bgR = (corners.fold<int>(
              0,
              (sum, pixel) => sum + pixel.r.toInt(),
            ) /
            corners.length)
        .round();
    final int bgG = (corners.fold<int>(
              0,
              (sum, pixel) => sum + pixel.g.toInt(),
            ) /
            corners.length)
        .round();
    final int bgB = (corners.fold<int>(
              0,
              (sum, pixel) => sum + pixel.b.toInt(),
            ) /
            corners.length)
        .round();

    final thermal = img.Image(width: src.width, height: src.height);
    img.fill(thermal, color: img.ColorRgb8(255, 255, 255));

    for (int y = 0; y < src.height; y++) {
      for (int x = 0; x < src.width; x++) {
        final pixel = src.getPixel(x, y);
        final int pxR = pixel.r.toInt();
        final int pxG = pixel.g.toInt();
        final int pxB = pixel.b.toInt();
        final int deltaR = (pxR - bgR).abs();
        final int deltaG = (pxG - bgG).abs();
        final int deltaB = (pxB - bgB).abs();
        final int maxDelta = math.max(deltaR, math.max(deltaG, deltaB));
        final int avgDelta = ((deltaR + deltaG + deltaB) / 3).round();
        final int minChannel = math.min(pxR, math.min(pxG, pxB));
        final int maxChannel = math.max(pxR, math.max(pxG, pxB));
        final int chroma = maxChannel - minChannel;
        final int darkness = 255 - _pixelLuminance(pixel);

        final int inkStrength = math.min(
          255,
          math.max(
            maxDelta * 2,
            math.max(avgDelta * 3, math.max(chroma * 3, darkness * 2)),
          ),
        );
        final int gray = 255 - inkStrength;
        thermal.setPixelRgb(x, y, gray, gray, gray);
      }
    }

    return thermal;
  }

  static img.Image _flattenLogoOnWhite(img.Image src) {
    final flattened = img.Image(width: src.width, height: src.height);
    img.fill(flattened, color: img.ColorRgb8(255, 255, 255));

    for (int y = 0; y < src.height; y++) {
      for (int x = 0; x < src.width; x++) {
        final pixel = src.getPixel(x, y);
        final int alpha = pixel.a.toInt().clamp(0, 255);
        if (alpha <= 0) {
          flattened.setPixelRgb(x, y, 255, 255, 255);
          continue;
        }
        if (alpha >= 255) {
          flattened.setPixelRgb(x, y, pixel.r, pixel.g, pixel.b);
          continue;
        }

        final double opacity = alpha / 255.0;
        final int red = (255 + ((pixel.r - 255) * opacity)).round();
        final int green = (255 + ((pixel.g - 255) * opacity)).round();
        final int blue = (255 + ((pixel.b - 255) * opacity)).round();
        flattened.setPixelRgb(x, y, red, green, blue);
      }
    }

    return flattened;
  }

  static List<int> _appendRasterLogoBands(
    Generator generator,
    ReceiptPrintDocument document,
    img.Image logo,
  ) {
    List<int> bytes = generator.setStyles(
      const PosStyles(align: PosAlign.center),
    );
    const int bandHeight = 96;

    for (int top = 0; top < logo.height; top += bandHeight) {
      final int height = math.min(bandHeight, logo.height - top);
      final band = img.copyCrop(
        logo,
        x: 0,
        y: top,
        width: logo.width,
        height: height,
      );
      bytes += EscPosHelper.imageToRasterBytes(
        band,
        paperSize: document.paperSize,
      );
    }

    return bytes;
  }

  static int _measureBitmapTextWidth(String text, img.BitmapFont font) {
    int width = 0;
    for (final codeUnit in text.codeUnits) {
      if (font.characters.containsKey(codeUnit)) {
        width += font.characters[codeUnit]!.xAdvance;
      } else {
        width += font.base ~/ 2;
      }
    }
    return width;
  }

  static String _truncateBitmapText(
    String text,
    img.BitmapFont font,
    int maxWidth,
  ) {
    if (_measureBitmapTextWidth(text, font) <= maxWidth) return text;

    const String ellipsis = '...';
    final StringBuffer buffer = StringBuffer();
    for (final codeUnit in text.codeUnits) {
      final candidate = '${buffer.toString()}${String.fromCharCode(codeUnit)}';
      if (_measureBitmapTextWidth('$candidate$ellipsis', font) > maxWidth) {
        break;
      }
      buffer.writeCharCode(codeUnit);
    }

    final truncated = buffer.toString().trimRight();
    return truncated.isEmpty ? ellipsis : '$truncated$ellipsis';
  }

  static List<String> _wrapBitmapText(
    String text,
    img.BitmapFont font,
    int maxWidth, {
    int maxLines = 2,
  }) {
    final normalized = text.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (normalized.isEmpty) return const <String>[];

    final List<String> lines = [];
    String current = '';

    void pushWord(String word) {
      if (lines.length >= maxLines) return;

      final candidate = current.isEmpty ? word : '$current $word';
      if (_measureBitmapTextWidth(candidate, font) <= maxWidth) {
        current = candidate;
        return;
      }

      if (current.isNotEmpty) {
        lines.add(current);
        current = '';
        if (lines.length >= maxLines) return;
      }

      if (_measureBitmapTextWidth(word, font) <= maxWidth) {
        current = word;
        return;
      }

      final chars = word.split('');
      final StringBuffer part = StringBuffer();
      for (final ch in chars) {
        final candidatePart = '${part.toString()}$ch';
        if (_measureBitmapTextWidth(candidatePart, font) <= maxWidth) {
          part.write(ch);
          continue;
        }

        final piece = part.toString().trim();
        if (piece.isNotEmpty) {
          lines.add(piece);
          if (lines.length >= maxLines) return;
        }
        part
          ..clear()
          ..write(ch);
      }
      current = part.toString();
    }

    for (final word in normalized.split(' ')) {
      if (word.isEmpty) continue;
      pushWord(word);
      if (lines.length >= maxLines) break;
    }

    if (lines.length < maxLines && current.isNotEmpty) {
      lines.add(current);
    }

    if (lines.length > maxLines) {
      return lines.take(maxLines).toList();
    }

    if (lines.isEmpty) return const <String>[];
    if (lines.length == maxLines &&
        _measureBitmapTextWidth(lines.last, font) > maxWidth) {
      lines[lines.length - 1] = _truncateBitmapText(lines.last, font, maxWidth);
    }
    return lines;
  }

  static img.BitmapFont _leftHeaderFont(ReceiptPrintDocument document) {
    final double fontSize =
        _normalizedStoreNameFontSize(document.storeNameFontSize);
    if (document.paperSize == 80) {
      return fontSize >= 18.0 ? img.arial24 : img.arial14;
    }
    return fontSize >= 17.0 ? img.arial24 : img.arial14;
  }

  static img.Image? _buildLeftHeaderImage({
    required ReceiptPrintDocument document,
    required img.Image logo,
  }) {
    final int maxPaperWidth = document.paperSize == 80 ? 512 : 344;
    final int outerPadding = document.paperSize == 80 ? 16 : 10;
    final int gap = document.paperSize == 80 ? 16 : 10;
    final int verticalPadding = document.paperSize == 80 ? 10 : 6;
    final int maxLogoWidth = document.paperSize == 80 ? 150 : 100;
    final int maxLogoHeight = document.paperSize == 80 ? 90 : 60;

    img.Image workingLogo = logo;
    final double logoScale = math.min(
      1.0,
      math.min(
        maxLogoWidth / workingLogo.width,
        maxLogoHeight / workingLogo.height,
      ),
    );
    if (logoScale < 1.0) {
      workingLogo = img.copyResize(
        workingLogo,
        width: math.max(1, (workingLogo.width * logoScale).round()),
        height: math.max(1, (workingLogo.height * logoScale).round()),
        interpolation: img.Interpolation.linear,
      );
      workingLogo = img.luminanceThreshold(
        img.contrast(img.grayscale(workingLogo), contrast: 180.0),
        threshold: 0.62,
      );
    }

    final int availableTextWidth =
        maxPaperWidth - (outerPadding * 2) - workingLogo.width - gap;
    if (availableTextWidth < 72) return null;

    final font = _leftHeaderFont(document);
    final lines = _wrapBitmapText(
      document.namaWarung.toUpperCase(),
      font,
      availableTextWidth,
      maxLines: 2,
    );
    if (lines.isEmpty) return null;

    final int lineHeight = font.lineHeight > 0 ? font.lineHeight : font.base;
    final int maxLineWidth = lines.fold<int>(
      0,
      (maxWidth, line) => math.max(
        maxWidth,
        _measureBitmapTextWidth(line, font),
      ),
    );

    final int totalContentWidth = workingLogo.width + gap + maxLineWidth;
    final int textHeight = lines.length * lineHeight;
    final int canvasHeight =
        math.max(workingLogo.height, textHeight) + (verticalPadding * 2);
    final int canvasWidth = totalContentWidth + (outerPadding * 2);

    final canvas = img.Image(width: canvasWidth, height: canvasHeight);
    img.fill(canvas, color: img.ColorRgb8(255, 255, 255));

    final int startX = outerPadding;
    final int logoY = ((canvasHeight - workingLogo.height) / 2).round();
    img.compositeImage(canvas, workingLogo, dstX: startX, dstY: logoY);

    final int textX = startX + workingLogo.width + gap;
    final int textY = ((canvasHeight - textHeight) / 2).round();
    for (int i = 0; i < lines.length; i++) {
      img.drawString(
        canvas,
        lines[i],
        font: font,
        x: textX,
        y: textY + (i * lineHeight),
        color: img.ColorRgb8(0, 0, 0),
      );
    }

    return img.luminanceThreshold(
      img.contrast(img.grayscale(canvas), contrast: 180.0),
      threshold: 0.62,
    );
  }

  static PosTextSize _storeNameEscPosSize(ReceiptPrintDocument document) {
    final double fontSize =
        _normalizedStoreNameFontSize(document.storeNameFontSize);
    if (document.paperSize == 80) {
      if (fontSize >= 26.0) return PosTextSize.size3;
      if (fontSize >= 18.0) return PosTextSize.size2;
      return PosTextSize.size1;
    }
    if (fontSize >= 21.0) return PosTextSize.size2;
    return PosTextSize.size1;
  }

  static int _storeNameWidthFactor(PosTextSize size) {
    switch (size) {
      case PosTextSize.size2:
        return 2;
      case PosTextSize.size3:
        return 3;
      default:
        return 1;
    }
  }

  static String _truncateByCharacters(String text, int maxChars) {
    if (text.length <= maxChars) return text;
    if (maxChars <= 3) return text.substring(0, maxChars);
    return '${text.substring(0, maxChars - 3).trimRight()}...';
  }

  static List<String> _wrapTextByCharacters(
    String text,
    int maxChars, {
    int maxLines = 2,
  }) {
    final normalized = text.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (normalized.isEmpty) return const <String>[];

    final words = normalized.split(' ');
    final lines = <String>[];
    String current = '';
    bool truncated = false;

    void pushCurrent() {
      if (current.isEmpty || lines.length >= maxLines) return;
      lines.add(current);
      current = '';
    }

    for (final word in words) {
      if (word.isEmpty) continue;
      final candidate = current.isEmpty ? word : '$current $word';
      if (candidate.length <= maxChars) {
        current = candidate;
        continue;
      }

      if (current.isNotEmpty) {
        pushCurrent();
        if (lines.length >= maxLines) {
          truncated = true;
          break;
        }
      }

      if (word.length <= maxChars) {
        current = word;
        continue;
      }

      int start = 0;
      while (start < word.length) {
        if (lines.length >= maxLines) {
          truncated = true;
          break;
        }
        final int end = math.min(word.length, start + maxChars);
        final String slice = word.substring(start, end);
        if (end < word.length && lines.length == maxLines - 1) {
          lines.add(_truncateByCharacters(word.substring(start), maxChars));
          truncated = true;
          start = word.length;
          break;
        }
        lines.add(slice);
        start = end;
      }

      if (truncated) break;
    }

    if (!truncated && current.isNotEmpty) {
      if (lines.length < maxLines) {
        lines.add(current);
      } else {
        truncated = true;
      }
    }

    if (truncated && lines.isNotEmpty) {
      lines[lines.length - 1] =
          _truncateByCharacters(lines.last.trimRight(), maxChars);
    }

    return lines.take(maxLines).toList();
  }

  static List<String> _wrapStoreNameLines(ReceiptPrintDocument document) {
    final PosTextSize size = _storeNameEscPosSize(document);
    final int widthFactor = _storeNameWidthFactor(size);
    int maxChars = (document.lineWidth / widthFactor).floor();
    if (document.paperSize == 58 && widthFactor > 1) {
      maxChars -= 1;
    }
    maxChars = math.max(8, maxChars);

    final String storeName = document.namaWarung.toUpperCase();
    // Dinamically determine maxLines: prefer 1 line, but allow 2 if name is too long
    final int maxLines = storeName.length <= maxChars ? 1 : 2;

    return _wrapTextByCharacters(
      storeName,
      maxChars,
      maxLines: maxLines,
    );
  }

  static PosStyles _storeNameStyles(ReceiptPrintDocument document) {
    final PosTextSize textSize = _storeNameEscPosSize(document);

    return PosStyles(
      align: PosAlign.center,
      bold: true,
      height: textSize,
      width: textSize,
    );
  }

  static int _escPosColumnCharWidth(ReceiptPrintDocument document, int width) {
    return ((document.lineWidth * width) / 12).floor();
  }

  static List<int> _escPosInfoRow(
    Generator generator,
    ReceiptPrintDocument document, {
    required String label,
    required String value,
    int labelWidth = 4,
    int valueWidth = 8,
    PosStyles valueStyles = const PosStyles(align: PosAlign.right),
  }) {
    final normalizedValue = value.trim().replaceAll(RegExp(r'\s+'), ' ');
    final valueMaxChars = _escPosColumnCharWidth(document, valueWidth);

    if (normalizedValue.length <= valueMaxChars) {
      return generator.row([
        PosColumn(text: label, width: labelWidth),
        PosColumn(
          text: normalizedValue,
          width: valueWidth,
          styles: valueStyles,
        ),
      ]);
    }

    return [
      ...generator.row([
        PosColumn(text: label, width: labelWidth),
        PosColumn(text: '', width: valueWidth),
      ]),
      ...generator.text(
        _truncateByCharacters(normalizedValue, document.lineWidth),
        styles: const PosStyles(align: PosAlign.right),
      ),
    ];
  }

  static Future<List<int>> buildEscPosBytes({
    required ReceiptPrintDocument document,
    required String logoPath,
  }) async {
    final profile = await CapabilityProfile.load();
    final generator = Generator(
        document.paperSize == 80 ? PaperSize.mm80 : PaperSize.mm58, profile);
    List<int> bytes = [];

    bytes += generator.reset();
    // Manual Left Margin Reset (GS L 0 0) - forces printer to use absolute left
    bytes += [0x1D, 0x4C, 0x00, 0x00];

    final safeLogo = await _loadSafeEscPosLogo(
      document: document,
      logoPath: logoPath,
    );
    final leftHeaderImage = safeLogo != null &&
            document.logoPosition == 'left' &&
            document.namaWarung.trim().isNotEmpty
        ? _buildLeftHeaderImage(document: document, logo: safeLogo)
        : null;
    final storeNameLines = document.namaWarung.trim().isEmpty
        ? const <String>[]
        : _wrapStoreNameLines(document);

    final bool shouldPrintLogoOnTop = safeLogo != null &&
        document.logoPosition != 'bottom' &&
        leftHeaderImage == null;
    if (shouldPrintLogoOnTop) {
      bytes += _appendRasterLogoBands(generator, document, safeLogo);
      bytes += generator.feed(1);
      bytes += generator.reset();
      bytes += [0x1D, 0x4C, 0x00, 0x00];
    }

    if (leftHeaderImage != null) {
      bytes += _appendRasterLogoBands(generator, document, leftHeaderImage);
      bytes += generator.feed(1);
      bytes += generator.reset();
      bytes += [0x1D, 0x4C, 0x00, 0x00];
    } else if (storeNameLines.isNotEmpty) {
      final styles = _storeNameStyles(document);
      for (final line in storeNameLines) {
        bytes += generator.text(line, styles: styles);
      }
    }

    // Shared Header info (Address, Phone)
    if (document.namaWarung.isNotEmpty) {
      if (document.showAlamat && document.alamat.isNotEmpty) {
        bytes += generator.text(document.alamat,
            styles: const PosStyles(align: PosAlign.center));
      }
      if (document.showTelepon && document.telepon.isNotEmpty) {
        bytes += generator.text(document.telepon,
            styles: const PosStyles(align: PosAlign.center));
      }
    }

    bytes += generator.hr();
    bytes += generator.text(document.title,
        styles: const PosStyles(align: PosAlign.center, bold: true));
    bytes += generator.hr();

    // Info
    bytes += generator.row([
      PosColumn(text: 'No.', width: 4),
      PosColumn(
          text: document.noTransaksi,
          width: 8,
          styles: const PosStyles(align: PosAlign.right)),
    ]);
    bytes += generator.row([
      PosColumn(text: 'Tanggal', width: 4),
      PosColumn(
          text: document.tanggal,
          width: 8,
          styles: const PosStyles(align: PosAlign.right)),
    ]);
    if (document.paymentMethod.toLowerCase().startsWith('campuran')) {
      if (document.kasirName.isNotEmpty) {
        bytes += generator.row([
          PosColumn(text: 'Kasir', width: 4),
          PosColumn(
              text: document.kasirName,
              width: 8,
              styles: const PosStyles(align: PosAlign.right)),
        ]);
      }
      bytes +=
          generator.text('Pembayaran:', styles: const PosStyles(bold: true));
      bytes += generator.text(document.paymentMethod);
    } else {
      if (document.kasirName.isNotEmpty) {
        bytes += generator.row([
          PosColumn(text: 'Kasir', width: 4),
          PosColumn(
              text: document.kasirName,
              width: 8,
              styles: const PosStyles(align: PosAlign.right)),
        ]);
      }
      bytes += generator.row([
        PosColumn(text: 'Pembayaran', width: 5),
        PosColumn(
            text: document.paymentMethod,
            width: 7,
            styles: const PosStyles(align: PosAlign.right)),
      ]);
    }

    if (document.isWorkshop) {
      bytes += generator.text(document.customerName?.toUpperCase() ?? 'MEJA: -',
          styles: const PosStyles(
              align: PosAlign.center,
              bold: true,
              height: PosTextSize.size2,
              width: PosTextSize.size2));
      bytes += generator.feed(1);
    } else {
      if (document.customerName != null && document.customerName!.isNotEmpty) {
        bytes += generator.row([
          PosColumn(text: 'Pelanggan', width: 4),
          PosColumn(
              text: document.customerName!,
              width: 8,
              styles: const PosStyles(align: PosAlign.right, bold: true)),
        ]);
      }
    }

    if (document.orderType != null && document.orderType!.isNotEmpty) {
      bytes += generator.row([
        PosColumn(text: 'Jenis', width: 4),
        PosColumn(
            text: document.orderType!,
            width: 8,
            styles: const PosStyles(align: PosAlign.right, bold: true)),
      ]);
    }
    if (document.pickupSchedule != null &&
        document.pickupSchedule!.isNotEmpty) {
      bytes += _escPosInfoRow(
        generator,
        document,
        label: 'Est.Ambil',
        value: document.pickupSchedule!,
      );
    }
    if (!document.isWorkshop &&
        document.paymentStatus != null &&
        document.paymentStatus!.isNotEmpty) {
      bytes += generator.row([
        PosColumn(text: 'Status', width: 4),
        PosColumn(
            text: document.paymentStatus!,
            width: 8,
            styles: const PosStyles(align: PosAlign.right, bold: true)),
      ]);
    }
    if (document.kelengkapan != null &&
        document.kelengkapan!.isNotEmpty &&
        document.kelengkapan != 'None') {
      bytes += generator.row([
        PosColumn(text: 'Parfum', width: 4),
        PosColumn(
            text: document.kelengkapan!,
            width: 8,
            styles: const PosStyles(align: PosAlign.right)),
      ]);
    }

    bytes += generator.hr();

    // Items
    for (final item in document.items) {
      if (document.isWorkshop) {
        bytes += generator.text('${_itemQtyLabel(item)} x ${item.name}',
            styles: const PosStyles(bold: true));
      } else {
        bytes += generator.text(item.name, styles: const PosStyles(bold: true));
        if (item.hasRoundedBilling) {
          final unit = item.unit.trim().isEmpty ? 'kg' : item.unit.trim();
          bytes += generator.row([
            PosColumn(
                text:
                    '${_itemQtyLabel(item)} -> ${_formatQty(item.billableQty)} $unit',
                width: 7),
            PosColumn(
                text: 'Rp${_formatNumber(item.subtotal)}',
                width: 5,
                styles: const PosStyles(align: PosAlign.right)),
          ]);
          bytes += generator.text(
              '  Rp${_formatNumber(item.unitPrice)}/$unit${_getItemSimpleDiscountInfo(item)}');
          if (item.isPriceOverride) {
            final originalSubtotal = item.originalSubtotal > 0
                ? item.originalSubtotal
                : item.subtotal + item.effectivePriceOverrideAmount;
            bytes += generator.text(
              '  Harga awal Rp${_formatNumber(originalSubtotal)}',
            );
          }
        } else {
          bytes += generator.row([
            PosColumn(
                text:
                    '${_itemPriceLine(item)}${_getItemSimpleDiscountInfo(item)}',
                width: 7),
            PosColumn(
                text: 'Rp${_formatNumber(item.subtotal)}',
                width: 5,
                styles: const PosStyles(align: PosAlign.right)),
          ]);
          if (item.isPriceOverride) {
            final originalSubtotal = item.originalSubtotal > 0
                ? item.originalSubtotal
                : item.subtotal + item.effectivePriceOverrideAmount;
            bytes += generator.text(
              '  Harga awal Rp${_formatNumber(originalSubtotal)}',
            );
          }
        }
      }
      if (item.note.isNotEmpty) {
        bytes += generator.text('  Catatan: ${item.note}',
            styles: const PosStyles(bold: false));
      }
    }

    bytes += generator.hr();

    // Totals
    if (!document.isWorkshop) {
      if (document.showTotalPesanan) {
        bytes += generator.row([
          PosColumn(text: 'Subtotal', width: 6),
          PosColumn(
              text: 'Rp${_formatNumber(document.subtotal)}',
              width: 6,
              styles: const PosStyles(align: PosAlign.right)),
        ]);
      }
      if (document.discountAmount > 0) {
        bytes += generator.row([
          PosColumn(text: _getDiskonLabel(document), width: 6),
          PosColumn(
              text: '- Rp${_formatNumber(document.discountAmount)}',
              width: 6,
              styles: const PosStyles(align: PosAlign.right)),
        ]);
      }

      for (final charge in document.charges) {
        bytes += generator.row([
          PosColumn(text: charge.label, width: 6),
          PosColumn(
              text: 'Rp${_formatNumber(charge.value)}',
              width: 6,
              styles: const PosStyles(align: PosAlign.right)),
        ]);
      }
      if (document.additionalCharges > 0 && document.charges.isEmpty) {
        bytes += generator.row([
          PosColumn(text: 'Biaya Tmbhn', width: 6),
          PosColumn(
              text: 'Rp${_formatNumber(document.additionalCharges)}',
              width: 6,
              styles: const PosStyles(align: PosAlign.right)),
        ]);
      }

      bytes += generator.row([
        PosColumn(text: 'TOTAL', width: 6, styles: const PosStyles(bold: true)),
        PosColumn(
            text: 'Rp${_formatNumber(document.grandTotal)}',
            width: 6,
            styles: const PosStyles(align: PosAlign.right, bold: true)),
      ]);
      bytes += generator.row([
        PosColumn(text: 'Bayar', width: 6),
        PosColumn(
            text: 'Rp${_formatNumber(document.amountPaid)}',
            width: 6,
            styles: const PosStyles(align: PosAlign.right)),
      ]);
      if (document.changeAmount > 0) {
        bytes += generator.row([
          PosColumn(text: 'Kembali', width: 6),
          PosColumn(
              text: 'Rp${_formatNumber(document.changeAmount)}',
              width: 6,
              styles: const PosStyles(align: PosAlign.right)),
        ]);
      }
    } else {
      bytes += generator.feed(1);
      final workshopFooter =
          document.footer.isNotEmpty ? document.footer : 'TIKET WORKSHOP';
      bytes += generator.text(workshopFooter,
          styles: const PosStyles(align: PosAlign.center, bold: true));
    }

    if (!document.isWorkshop) {
      bytes += generator.hr();

      final List<String> handles = [];
      if (document.instagram.isNotEmpty) {
        handles.add('IG:@${document.instagram}');
      }
      if (document.facebook.isNotEmpty) {
        handles.add('FB:@${document.facebook}');
      }
      if (document.tiktok.isNotEmpty) handles.add('TT:@${document.tiktok}');

      for (final handle in handles) {
        bytes += generator.text(
          handle,
          styles: const PosStyles(align: PosAlign.center),
        );
      }

      if (handles.isNotEmpty) {
        bytes += generator.hr();
      }

      if (document.note != null && document.note!.isNotEmpty) {
        bytes += generator.text('Catatan Tambahan',
            styles: const PosStyles(bold: true, align: PosAlign.left));
        bytes += generator.text(document.note!,
            styles: const PosStyles(align: PosAlign.left));
        bytes += generator.hr();
      }

      final String footerText = document.footer.isNotEmpty
          ? document.footer
          : 'Terima kasih telah berbelanja!';

      bytes += generator.text(
        footerText,
        styles: const PosStyles(align: PosAlign.center),
      );

      if (document.showWatermark) {
        bytes += generator.text(
          'Powered by Juragan Servis',
          styles: const PosStyles(
              align: PosAlign.center, height: PosTextSize.size1),
        );
      }

      // QR CODE FOR FAST SCANNING & PICKUP
      // Menggunakan QR Code karena Code128 sering melebihi lebar kertas 58mm (buffer overflow)
      bytes += generator.feed(1);
      bytes += generator.qrcode(
        document.noTransaksi,
        size: QRSize.size5,
      );
    }

    // Logo (BOTTOM position in ESC/POS)
    if (safeLogo != null && document.logoPosition == 'bottom') {
      bytes += generator.feed(1);
      bytes += _appendRasterLogoBands(generator, document, safeLogo);
    }

    bytes += generator.feed(document.paperSize == 80 ? 6 : 8);

    return bytes;
  }

  static String _formatNumber(int value) {
    if (value == 0) return '0';
    final String source = value.toString();
    final StringBuffer buffer = StringBuffer();
    int count = 0;

    for (int i = source.length - 1; i >= 0; i--) {
      buffer.write(source[i]);
      count++;
      if (count % 3 == 0 && i != 0) {
        buffer.write('.');
      }
    }

    return buffer.toString().split('').reversed.join();
  }

  static String _formatQty(double value) {
    return value
        .toStringAsFixed(2)
        .replaceAll(RegExp(r'0+$'), '')
        .replaceAll(RegExp(r'\.$'), '')
        .replaceAll('.', ',');
  }

  static String _itemQtyLabel(ReceiptPrintItem item) {
    final unit = item.unit.trim();
    final qty = _formatQty(item.qty);
    if (unit.isEmpty) return qty;
    return '$qty $unit';
  }

  static String _itemPriceLine(ReceiptPrintItem item, {bool rupiah = true}) {
    final unit = item.unit.trim();
    final price = rupiah
        ? 'Rp${_formatNumber(item.unitPrice)}'
        : _formatNumber(item.unitPrice);
    final billed = item.hasRoundedBilling
        ? ' (tagih ${_formatQty(item.billableQty)} $unit)'
        : '';
    return '${_itemQtyLabel(item)}$billed x $price';
  }

  static pw.Widget _buildPdfSocial(
      ReceiptPrintDocument document, pw.Font font, double size) {
    final List<String> parts = [];
    if (document.instagram.isNotEmpty) parts.add('IG:@${document.instagram}');
    if (document.facebook.isNotEmpty) parts.add('FB:@${document.facebook}');
    if (document.tiktok.isNotEmpty) parts.add('TT:@${document.tiktok}');

    if (parts.isEmpty) return pw.SizedBox();

    return pw.Text(
      parts.join('  '),
      textAlign: pw.TextAlign.center,
      style: pw.TextStyle(font: font, fontSize: size),
    );
  }

  static String _getDiskonLabel(ReceiptPrintDocument doc) {
    if (doc.discountAmount <= 0 || doc.subtotal <= 0) return 'Diskon';
    final pct = (doc.discountAmount / doc.subtotal * 100);
    if (pct > 0 && pct <= 100) {
      if (pct == pct.toInt().toDouble()) {
        return 'Diskon (${pct.toInt()}%)';
      } else {
        return 'Diskon (${pct.toStringAsFixed(1).replaceAll(RegExp(r'\.0$'), '')}%)';
      }
    }
    return 'Diskon';
  }

  static String _getItemSimpleDiscountInfo(ReceiptPrintItem item) {
    // Harga nego sudah dijelaskan oleh baris "Harga awal". Menambahkan label
    // di baris harga membuat detail item terpotong pada kertas 58 mm.
    if (item.isPriceOverride) return '';
    if (!item.hasAppliedPromo) return '';
    final value = item.appliedDiscountValue;
    final isPercentage = item.appliedDiscountIsPercentage == 1;
    if (isPercentage && value > 0) return ' (disc. $value%)';
    if (!isPercentage && value > 0) {
      return ' (disc. -Rp${_formatNumber(value)})';
    }
    return ' (promo)';
  }
}

