import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:textify/textify.dart';

class ResiOcrResult {
  final String trackingNumber;
  final String courier;
  final String rawText;

  ResiOcrResult({
    required this.trackingNumber,
    required this.courier,
    this.rawText = '',
  });
}

class ResiOcrService {
  static final ResiOcrService _instance = ResiOcrService._internal();

  factory ResiOcrService() => _instance;

  ResiOcrService._internal();

  Textify? _textify;
  bool _textifyInitialized = false;

  static final Map<String, RegExp> _patterns = {
    'Shopee Express': RegExp(r'SPXID[0-9]{10,}', caseSensitive: false),
    'J&T': RegExp(r'(JT|JP)[0-9]{10,}', caseSensitive: false),
    'JNE': RegExp(
      r'(SOCAG|TPNK|CGK|TLU|JOG)[0-9A-Z]{10,}',
      caseSensitive: false,
    ),
    'SiCepat': RegExp(r'00[0-9]{10,}', caseSensitive: false),
    'Anteraja': RegExp(r'(ANT|10)[0-9]{10,}', caseSensitive: false),
    'Ninja Xpress': RegExp(r'(NINV|NV)[A-Z0-9]{8,}', caseSensitive: false),
    'Grab': RegExp(r'GRB[0-9]{10,}', caseSensitive: false),
    'Gojek': RegExp(r'GK-[0-9]{8,}', caseSensitive: false),
    'ID Express': RegExp(r'IDE[0-9]{10,}', caseSensitive: false),
    'SAP Express': RegExp(r'SAP[0-9]{10,}', caseSensitive: false),
  };

  Future<void> _ensureTextifyInit() async {
    if (_textifyInitialized) {
      return;
    }

    try {
      _textify = Textify();
      await _textify!.init();
      _textifyInitialized = true;
      debugPrint('Textify OCR engine initialized');
    } catch (e) {
      debugPrint('Textify init error: $e');
      _textify = null;
    }
  }

  Future<ResiOcrResult> detect(File file) async {
    var ocrText = '';

    try {
      if (!kIsWeb && Platform.isWindows) {
        ocrText = await _windowsOcr(file);
        debugPrint('WinRT OCR: ${ocrText.length} chars');

        if (ocrText.trim().isEmpty) {
          ocrText = await _textifyOcr(file);
          debugPrint('Textify OCR fallback: ${ocrText.length} chars');
        }
      } else if (!kIsWeb) {
        ocrText = await _textifyOcr(file);
        debugPrint('Textify OCR: ${ocrText.length} chars');
      }
    } catch (e) {
      debugPrint('OCR error: $e');
    }

    debugPrint('OCR result length: ${ocrText.length}');

    if (ocrText.trim().isNotEmpty) {
      return _parseText(ocrText);
    }

    return _detectFromFileName(file.path);
  }

  Future<String> _windowsOcr(File imageFile) async {
    var targetPath = imageFile.path;
    File? tempFile;

    final extension = imageFile.path.split('.').last.toLowerCase();
    if (extension == 'webp') {
      try {
        final bytes = await imageFile.readAsBytes();
        final decoded = img.decodeImage(bytes);
        if (decoded != null) {
          final tempDir = await getTemporaryDirectory();
          tempFile = File(
            '${tempDir.path}${Platform.pathSeparator}'
            'ocr_temp_${DateTime.now().millisecondsSinceEpoch}.png',
          );
          await tempFile.writeAsBytes(img.encodePng(decoded));
          targetPath = tempFile.path;
          debugPrint('WebP converted to PNG for OCR');
        }
      } catch (e) {
        debugPrint('WebP conversion error: $e');
      }
    }

    final escapedPath = targetPath.replaceAll("'", "''");
    final script = '''
try {
  [Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
  [Windows.Graphics.Imaging.BitmapDecoder,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
  [Windows.Storage.StorageFile,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null

  \$awaiterType = [System.Type]::GetType("System.Runtime.WindowsRuntime.WindowsRuntimeSystemExtensions, System.Runtime.WindowsRuntime")
  \$awaiter = \$awaiterType.GetMethods() | Where-Object { \$_.Name -eq "GetAwaiter" -and \$_.GetParameters().Count -eq 1 -and \$_.GetParameters()[0].ParameterType.Name.StartsWith("IAsyncOperation") } | Select-Object -First 1

  \$fileOp = [Windows.Storage.StorageFile]::GetFileFromPathAsync('$escapedPath')
  \$a = \$awaiter.MakeGenericMethod([Windows.Storage.StorageFile]).Invoke(\$null, @(\$fileOp))
  \$file = \$a.GetResult()

  \$streamOp = \$file.OpenAsync([Windows.Storage.FileAccessMode]::Read)
  \$a2 = \$awaiter.MakeGenericMethod([Windows.Storage.Streams.IRandomAccessStream]).Invoke(\$null, @(\$streamOp))
  \$stream = \$a2.GetResult()

  \$decoderOp = [Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync(\$stream)
  \$a3 = \$awaiter.MakeGenericMethod([Windows.Graphics.Imaging.BitmapDecoder]).Invoke(\$null, @(\$decoderOp))
  \$decoder = \$a3.GetResult()

  \$bitmapOp = \$decoder.GetSoftwareBitmapAsync()
  \$a4 = \$awaiter.MakeGenericMethod([Windows.Graphics.Imaging.SoftwareBitmap]).Invoke(\$null, @(\$bitmapOp))
  \$bitmap = \$a4.GetResult()

  \$ocrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
  \$ocrOp = \$ocrEngine.RecognizeAsync(\$bitmap)
  \$a5 = \$awaiter.MakeGenericMethod([Windows.Media.Ocr.OcrResult]).Invoke(\$null, @(\$ocrOp))
  \$result = \$a5.GetResult()

  Write-Output \$result.Text
} catch {
  Write-Error \$_.Exception.Message
}
''';

    try {
      final result = await Process.run(
        'powershell',
        ['-NoProfile', '-NonInteractive', '-Command', script],
      ).timeout(
        const Duration(seconds: 15),
        onTimeout: () => ProcessResult(0, 1, '', 'timeout'),
      );

      final stdout = result.stdout.toString().trim();
      final stderr = result.stderr.toString().trim();

      if (stderr.isNotEmpty) {
        debugPrint('WinRT OCR stderr: $stderr');
      }

      return stdout;
    } catch (e) {
      debugPrint('PowerShell OCR failed: $e');
      return '';
    } finally {
      if (tempFile != null && await tempFile.exists()) {
        await tempFile.delete();
      }
    }
  }

  Future<String> _textifyOcr(File imageFile) async {
    await _ensureTextifyInit();
    if (_textify == null) {
      return '';
    }

    try {
      final uiImage = await _decodeUiImage(await imageFile.readAsBytes());
      try {
        return await _textify!.getTextFromImage(image: uiImage);
      } finally {
        uiImage.dispose();
      }
    } catch (e) {
      debugPrint('Textify OCR error: $e');
      try {
        return await _textifyOcrWithPreprocess(imageFile);
      } catch (fallbackError) {
        debugPrint('Textify OCR preprocess error: $fallbackError');
        return '';
      }
    }
  }

  Future<String> _textifyOcrWithPreprocess(File imageFile) async {
    if (_textify == null) {
      return '';
    }

    final bytes = await imageFile.readAsBytes();
    var decoded = img.decodeImage(bytes);
    if (decoded == null) {
      return '';
    }

    decoded = img.grayscale(decoded);
    decoded = img.adjustColor(decoded, contrast: 1.5);

    final processedBytes = Uint8List.fromList(img.encodePng(decoded));
    final uiImage = await _decodeUiImage(processedBytes);
    try {
      return await _textify!.getTextFromImage(image: uiImage);
    } finally {
      uiImage.dispose();
    }
  }

  Future<ui.Image> _decodeUiImage(Uint8List bytes) async {
    final codec = await ui.instantiateImageCodec(bytes);
    final frameInfo = await codec.getNextFrame();
    return frameInfo.image;
  }

  ResiOcrResult _parseText(String text) {
    final resiLabelPattern = RegExp(
      r'(?:No\.?\s*Resi|Nomor\s*Resi|Resi\s*No|AWB|Tracking)\s*[:\-]?\s*([A-Z0-9]{8,25})',
      caseSensitive: false,
    );
    final resiLabelMatch = resiLabelPattern.firstMatch(text);
    if (resiLabelMatch != null) {
      final trackingNum = resiLabelMatch.group(1)!;
      final courier = _detectCourierFromTracking(trackingNum, text);
      return ResiOcrResult(
        trackingNumber: trackingNum,
        courier: courier,
        rawText: text,
      );
    }

    for (final entry in _patterns.entries) {
      final match = entry.value.firstMatch(text);
      if (match != null) {
        return ResiOcrResult(
          trackingNumber: match.group(0)!,
          courier: entry.key,
          rawText: text,
        );
      }
    }

    final alphanumPattern = RegExp(r'[A-Z]{2,5}[-]?[A-Z0-9]{5,20}');
    final alphanumMatches = alphanumPattern.allMatches(text).toList();
    for (final match in alphanumMatches) {
      final code = match.group(0)!;
      if (_isCommonWord(code)) {
        continue;
      }

      final courier = _detectCourierFromTracking(code, text);
      return ResiOcrResult(
        trackingNumber: code,
        courier: courier,
        rawText: text,
      );
    }

    final courier = _detectCourierFromKeyword(text.toLowerCase());
    var tracking = '-';
    final allNumbers = RegExp(r'[0-9]{10,20}').allMatches(text);
    for (final match in allNumbers) {
      final number = match.group(0)!;
      if (_isPhoneNumber(number)) {
        continue;
      }
      tracking = number;
      break;
    }

    return ResiOcrResult(
      trackingNumber: tracking,
      courier: courier,
      rawText: text,
    );
  }

  bool _isPhoneNumber(String value) {
    if (value.startsWith('62') && value.length >= 11 && value.length <= 15) {
      return true;
    }
    if (value.startsWith('08') && value.length >= 10 && value.length <= 13) {
      return true;
    }
    if (value.startsWith('021') ||
        value.startsWith('031') ||
        value.startsWith('022')) {
      return true;
    }
    return false;
  }

  bool _isCommonWord(String code) {
    const skip = {
      'HOME',
      'PICK',
      'CASHLESS',
      'EXPRESS',
      'STORE',
      'JAWA',
      'TIMUR',
      'BARAT',
      'KOTA',
      'BUDURAN',
      'SIDOARJO',
      'TANGERANG',
    };
    return skip.contains(code.toUpperCase());
  }

  String _detectCourierFromTracking(String tracking, String fullText) {
    final upper = tracking.toUpperCase();
    if (upper.startsWith('SPXID')) return 'Shopee Express';
    if (upper.startsWith('JT') || upper.startsWith('JP')) return 'J&T';
    if (upper.startsWith('SOCAG') ||
        upper.startsWith('TPNK') ||
        upper.startsWith('CGK')) {
      return 'JNE';
    }
    if (upper.startsWith('00')) return 'SiCepat';
    if (upper.startsWith('ANT')) return 'Anteraja';
    if (upper.startsWith('NV') || upper.startsWith('NINV')) {
      return 'Ninja Xpress';
    }
    if (upper.startsWith('IDE')) return 'ID Express';

    return _detectCourierFromKeyword(fullText.toLowerCase());
  }

  ResiOcrResult _detectFromFileName(String filePath) {
    final fileName = filePath.split(Platform.pathSeparator).last;
    final nameWithoutExt = fileName.split('.').first;

    for (final entry in _patterns.entries) {
      final match = entry.value.firstMatch(nameWithoutExt);
      if (match != null) {
        return ResiOcrResult(
          trackingNumber: match.group(0)!,
          courier: entry.key,
        );
      }
    }

    final courier = _detectCourierFromKeyword(nameWithoutExt.toLowerCase());
    final numberMatch = RegExp(r'[0-9]{8,20}').firstMatch(nameWithoutExt);

    return ResiOcrResult(
      trackingNumber: numberMatch?.group(0) ?? nameWithoutExt,
      courier: courier,
    );
  }

  String _detectCourierFromKeyword(String lowerText) {
    if (lowerText.contains('shopee') || lowerText.contains('spx')) {
      return 'Shopee Express';
    }
    if (lowerText.contains('j&t') ||
        lowerText.contains('jnt') ||
        lowerText.contains('j_t')) {
      return 'J&T';
    }
    if (lowerText.contains('jne')) return 'JNE';
    if (lowerText.contains('sicepat') || lowerText.contains('sicpt')) {
      return 'SiCepat';
    }
    if (lowerText.contains('anteraja') || lowerText.contains('anter')) {
      return 'Anteraja';
    }
    if (lowerText.contains('ninja') || lowerText.contains('ninjaxpress')) {
      return 'Ninja Xpress';
    }
    if (lowerText.contains('grab')) return 'Grab Express';
    if (lowerText.contains('gojek') || lowerText.contains('gosend')) {
      return 'GoSend';
    }
    if (lowerText.contains('idexpress') || lowerText.contains('id_express')) {
      return 'ID Express';
    }
    if (lowerText.contains('tiki')) return 'TIKI';
    if (lowerText.contains('pos') || lowerText.contains('posindo')) {
      return 'Pos Indonesia';
    }
    if (lowerText.contains('lazada') || lowerText.contains('lex')) {
      return 'Lazada Express';
    }
    if (lowerText.contains('tokopedia') || lowerText.contains('toped')) {
      return 'TokoCabang';
    }
    return 'Marketplace';
  }

  void dispose() {
    // Textify is handled by its own plugin lifecycle if needed
  }
}

