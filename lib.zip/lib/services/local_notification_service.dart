import 'dart:io';
import 'dart:ui' show Color;

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

/// Cross-platform wrapper for local notifications.
class LocalNotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static bool _initialized = false;

  /// Initialize the notification plugin. Call once in main or on first use.
  static Future<void> init() async {
    if (_initialized) return;
    if (kIsWeb || Platform.isWindows) return;

    const androidSettings =
        AndroidInitializationSettings('@drawable/ic_launcher_foreground');
    const darwinSettings = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: darwinSettings,
      macOS: darwinSettings,
    );

    await _plugin.initialize(initSettings);
    await _requestPermissions();
    tz.initializeTimeZones();
    _initialized = true;
  }

  static Future<void> _requestPermissions() async {
    if (kIsWeb) return;

    if (Platform.isAndroid) {
      await _plugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
      return;
    }

    if (Platform.isIOS) {
      await _plugin
          .resolvePlatformSpecificImplementation<
              IOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(alert: true, badge: true, sound: true);
      return;
    }

    if (Platform.isMacOS) {
      await _plugin
          .resolvePlatformSpecificImplementation<
              MacOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(alert: true, badge: true, sound: true);
    }
  }

  /// Show a simple notification.
  static Future<void> show({
    required int id,
    required String title,
    required String body,
  }) async {
    if (kIsWeb || Platform.isWindows) return;

    await init();

    const androidDetails = AndroidNotificationDetails(
      'sales_target_channel',
      'Target Penjualan',
      channelDescription: 'Notifikasi pencapaian target penjualan',
      importance: Importance.high,
      priority: Priority.high,
      icon:
          '@drawable/ic_notification', // Changed to use a dedicated transparent notification icon
      color: Color(0xFF2563EB),
      playSound: true,
    );
    const darwinDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      presentBanner: true,
      presentList: true,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: darwinDetails,
      macOS: darwinDetails,
    );

    await _plugin.show(id, title, body, details);
  }

  /// Show target achievement notification.
  static Future<void> showTargetAchieved({
    required String type,
    required int amount,
    required int target,
  }) async {
    final fmtAmount = _fmtRp(amount);
    final fmtTarget = _fmtRp(target);

    await show(
      id: type == 'harian' ? 1001 : 1002,
      title: 'Target ${type == 'harian' ? 'Harian' : 'Bulanan'} Tercapai!',
      body:
          'Selamat! Omzet $type mencapai Rp$fmtAmount dari target Rp$fmtTarget.',
    );
  }

  static String _fmtRp(int n) {
    if (n == 0) return '0';
    String s = n.toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return r;
  }

  /// Show authentication or license related notifications.
  static Future<void> showAuthNotification({
    required String title,
    required String body,
  }) async {
    await show(
      id: 2001,
      title: title,
      body: body,
    );
  }

  /// Schedule a servis reminder.
  static Future<void> scheduleservisReminder({
    required int transactionId,
    required String customerName,
    required String transactionCode,
    required DateTime scheduledDate,
  }) async {
    if (kIsWeb || Platform.isWindows) return;
    await init();

    // Only schedule if the date is in the future
    if (scheduledDate.isBefore(DateTime.now())) return;

    const androidDetails = AndroidNotificationDetails(
      'servis_reminder_channel',
      'Pengingat Servis',
      channelDescription:
          'Pengingat untuk menghubungi pelanggan saat servis selesai',
      importance: Importance.high,
      priority: Priority.high,
      icon:
          '@drawable/ic_notification', // Changed to use a dedicated transparent notification icon
      color: Color(0xFF2563EB),
      playSound: true,
    );
    const darwinDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const details = NotificationDetails(
      android: androidDetails,
      iOS: darwinDetails,
      macOS: darwinDetails,
    );

    // ID range 3000+ for servis reminders
    final notificationId = 3000 + transactionId;

    await _plugin.zonedSchedule(
      notificationId,
      'Servis Selesai: $customerName',
      'Pesanan #$transactionCode sudah mencapai estimasi waktu selesai. Jangan lupa hubungi pelanggan!',
      tz.TZDateTime.from(scheduledDate, tz.local),
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
    );
  }

  /// Cancel a servis reminder for a specific transaction.
  static Future<void> cancelservisReminder(int transactionId) async {
    if (kIsWeb || Platform.isWindows) return;
    await init();
    await _plugin.cancel(3000 + transactionId);
  }
}

