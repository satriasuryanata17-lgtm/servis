import 'export_service.dart';

/// Compatibility wrapper for older callers. All PDF reports use ExportService
/// so the visual style, summary, and charts stay consistent across pages.
class PdfExportService {
  const PdfExportService._();

  static Future<void> exportAndSharePdf({
    required String title,
    required String filePrefix,
    required List<String> headers,
    required List<List<String>> rows,
    String? subtitle,
    String? period,
  }) async {
    await ExportService.exportPdfLaporan(
      title: title,
      subtitle: _combineSubtitle(subtitle, period),
      headers: headers,
      rows: rows,
    );
  }

  static Future<void> printPdf({
    required String title,
    required List<String> headers,
    required List<List<String>> rows,
    String? subtitle,
    String? period,
  }) async {
    await ExportService.printPdfLaporan(
      title: title,
      subtitle: _combineSubtitle(subtitle, period),
      headers: headers,
      rows: rows,
    );
  }

  static String? _combineSubtitle(String? subtitle, String? period) {
    final parts = [
      if (subtitle != null && subtitle.trim().isNotEmpty) subtitle.trim(),
      if (period != null && period.trim().isNotEmpty)
        'Periode: ${period.trim()}',
    ];
    return parts.isEmpty ? null : parts.join(' | ');
  }
}

