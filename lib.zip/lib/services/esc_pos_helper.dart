import 'package:image/image.dart' as img;

class EscPosHelper {
  /// Converts an image to ESC/POS raster bit image commands (GS v 0)
  /// width should be multiple of 8
  static List<int> imageToRasterBytes(img.Image src, {int paperSize = 58}) {
    // 1. Resize if needed
    final maxWidth = paperSize == 80 ? 576 : 384;
    img.Image image = src;

    if (src.width > maxWidth) {
      image = img.copyResize(src, width: maxWidth);
    }

    // Ensure width is multiple of 8 (pad with white if necessary)
    if (image.width % 8 != 0) {
      final newWidth = (image.width / 8).ceil() * 8;
      final padded = img.Image(width: newWidth, height: image.height);
      img.fill(padded, color: img.ColorRgb8(255, 255, 255));
      img.compositeImage(padded, image);
      image = padded;
    }

    final int width = image.width;
    final int height = image.height;
    final int widthBytes = width ~/ 8;

    final List<int> bytes = [];

    // GS v 0 0 xL xH yL yH
    bytes.addAll([0x1D, 0x76, 0x30, 0x00]);
    bytes.add(widthBytes % 256); // xL
    bytes.add(widthBytes ~/ 256); // xH
    bytes.add(height % 256); // yL
    bytes.add(height ~/ 256); // yH

    for (int y = 0; y < height; y++) {
      for (int x = 0; x < widthBytes; x++) {
        int byte = 0;
        for (int bit = 0; bit < 8; bit++) {
          final px = x * 8 + bit;
          if (px < width) {
            final pixel = image.getPixel(px, y);
            // Get luminance
            final gray = (0.299 * pixel.r + 0.587 * pixel.g + 0.114 * pixel.b);
            if (gray < 128) {
              byte |= (0x80 >> bit);
            }
          }
        }
        bytes.add(byte);
      }
    }

    return bytes;
  }
}

