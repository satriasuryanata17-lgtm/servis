import 'dart:io';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import 'dart:math';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import '../database/db_helper.dart';

class ProfitLossPdfService {
  const ProfitLossPdfService._();

  static const _brand = PdfColor.fromInt(0xFF2563EB);
  static const _brandLight = PdfColor.fromInt(0xFFEFF6FF);
  static const _dark = PdfColor.fromInt(0xFF111111);
  static const _red = PdfColor.fromInt(0xFFB22038);
  static const _green = PdfColor.fromInt(0xFF16A34A);

  static String _fRp(int n) {
    if (n == 0) return 'Rp 0';
    final neg = n < 0;
    String s = n.abs().toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return 'Rp ${neg ? '-' : ''}$r';
  }

  static Future<void> generateAndShare({
    required String period,
    required Map<String, int> summary,
    required Map<String, int> expensesByCategory,
    required List<Map<String, dynamic>> productMargins,
  }) async {
    final pdfBytes = await _buildPdf(
      period: period,
      summary: summary,
      expensesByCategory: expensesByCategory,
      productMargins: productMargins,
    );

    final dir = await getTemporaryDirectory();
    final filename = 'Laporan_Laba_Rugi_${period.replaceAll(' ', '_')}.pdf';
    final file = File(p.join(dir.path, filename));
    await file.writeAsBytes(pdfBytes);

    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      String? outputFile = await FilePicker.platform.saveFile(
        dialogTitle: 'Simpan Laporan Laba Rugi',
        fileName: filename,
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );
      if (outputFile != null) {
        await file.copy(outputFile);
      }
    } else {
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path)],
          subject: 'Laporan Laba Rugi $period',
          text: 'Laporan Laba Rugi untuk periode $period',
        ),
      );
    }
  }

  static Future<void> printReport({
    required String period,
    required Map<String, int> summary,
    required Map<String, int> expensesByCategory,
    required List<Map<String, dynamic>> productMargins,
  }) async {
    final pdfBytes = await _buildPdf(
      period: period,
      summary: summary,
      expensesByCategory: expensesByCategory,
      productMargins: productMargins,
    );

    await Printing.layoutPdf(
      onLayout: (_) async => pdfBytes,
      name: 'Laba Rugi $period',
    );
  }

  static Future<Uint8List> _buildPdf({
    required String period,
    required Map<String, int> summary,
    required Map<String, int> expensesByCategory,
    required List<Map<String, dynamic>> productMargins,
  }) async {
    final pdf = pw.Document();
    final warung = await DBHelper.instance.getWarungProfile();
    final storeName =
        (warung['nama'] ?? '').isNotEmpty ? warung['nama']! : 'Juragan Servis';
    final storeAddress = warung['alamat'] ?? '';
    final rawPhone = (warung['telepon'] ?? '').trim();
    final storePhone = rawPhone.isEmpty
        ? ''
        : (rawPhone.startsWith('0') || rawPhone.startsWith('+')
            ? rawPhone
            : '0$rawPhone');

    // Load logo
    pw.ImageProvider? logoImage;
    final logoPath = warung['logo_path'] ?? '';
    if (logoPath.isNotEmpty && File(logoPath).existsSync()) {
      try {
        final logoBytes = await File(logoPath).readAsBytes();
        logoImage = pw.MemoryImage(logoBytes);
      } catch (_) {}
    }

    final omzetKotor = summary['omzet_kotor'] ?? summary['omzet'] ?? 0;
    final retur = summary['retur_penjualan'] ?? 0;
    final omzet = summary['omzet'] ?? 0;
    final hpp = summary['hpp'] ?? 0;
    final labaKotor = summary['laba_kotor'] ?? 0;
    final totalExpenses = summary['pengeluaran'] ?? 0;
    final labaBersih = summary['laba_bersih'] ?? 0;
    final pembelianStok = summary['pembelian_stok'] ?? 0;

    final marginKotor =
        omzet > 0 ? (labaKotor / omzet * 100).toStringAsFixed(1) : '0.0';
    final marginBersih =
        omzet > 0 ? (labaBersih / omzet * 100).toStringAsFixed(1) : '0.0';

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        header: (context) => _buildHeader(
            storeName, storeAddress, storePhone, logoImage, period),
        footer: (context) => _buildFooter(storeName, context),
        build: (context) => [
          _buildSummaryCards(omzet, hpp, labaBersih, marginBersih),
          pw.SizedBox(height: 24),
          _buildSectionHeader('LAPORAN LABA RUGI'),
          _buildPLRow('OMZET KOTOR servis', omzetKotor, isBold: true),
          if (retur > 0)
            _buildPLRow('REFUND / RETUR servis', -retur, color: _red),
          _buildPLRow('OMZET BERSIH servis', omzet, isBold: true),
          _buildPLRow('HARGA POKOK PENJUALAN (HPP)', -hpp, isBold: true),
          pw.Divider(thickness: 1, color: PdfColors.grey400),
          _buildPLRow('LABA KOTOR', labaKotor,
              isBold: true,
              color: _green,
              subtitle: 'Margin Kotor: $marginKotor%'),
          pw.SizedBox(height: 12),
          _buildSectionHeader('BIAYA OPERASIONAL'),
          if (expensesByCategory.isEmpty)
            _buildPLRow('Tidak ada pengeluaran tercatat', 0)
          else
            ...expensesByCategory.entries
                .map((e) => _buildPLRow(e.key.toUpperCase(), -e.value)),
          pw.Divider(thickness: 1, color: PdfColors.grey400),
          _buildPLRow('TOTAL BIAYA OPERASIONAL', -totalExpenses, isBold: true),
          pw.SizedBox(height: 12),
          _buildPLRow('LABA BERSIH', labaBersih,
              isBold: true,
              color: labaBersih >= 0 ? _green : _red,
              subtitle: 'Margin Bersih: $marginBersih%'),
          if (pembelianStok > 0) ...[
            pw.SizedBox(height: 16),
            _buildSectionHeader('CATATAN ARUS KAS STOK'),
            _buildPLRow('PEMBELIAN STOK / ASET', pembelianStok,
                isBold: true,
                color: _brand,
                subtitle:
                    'Dicatat sebagai arus kas keluar dan aset. Beban diakui saat bahan baku dipakai.'),
          ],
          pw.SizedBox(height: 40),
          _buildSectionHeader('GRAFIK KOMPOSISI LABA RUGI'),
          _buildChart(hpp, totalExpenses, labaBersih),
          pw.NewPage(),
          _buildSectionHeader('RINCIAN PERSENTASE MARGIN PER ITEM'),
          _buildProductTable(productMargins),
        ],
      ),
    );

    return pdf.save();
  }

  static pw.Widget _buildHeader(String name, String address, String phone,
      pw.ImageProvider? logo, String period) {
    return pw.Column(
      children: [
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Row(
              children: [
                if (logo != null)
                  pw.Container(
                    width: 60,
                    height: 60,
                    margin: const pw.EdgeInsets.only(right: 15),
                    child: pw.Image(logo, fit: pw.BoxFit.contain),
                  ),
                pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(name.toUpperCase(),
                        style: pw.TextStyle(
                            fontSize: 18,
                            fontWeight: pw.FontWeight.bold,
                            color: _brand)),
                    if (address.isNotEmpty)
                      pw.Text(address,
                          style: const pw.TextStyle(
                              fontSize: 10, color: PdfColors.grey700)),
                    if (phone.isNotEmpty)
                      pw.Text('Tel: $phone',
                          style: const pw.TextStyle(
                              fontSize: 10, color: PdfColors.grey700)),
                  ],
                ),
              ],
            ),
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.end,
              children: [
                pw.Text('LAPORAN LABA RUGI',
                    style: pw.TextStyle(
                        fontSize: 14,
                        fontWeight: pw.FontWeight.bold,
                        color: _dark)),
                pw.Text('Periode: $period',
                    style: const pw.TextStyle(
                        fontSize: 11, color: PdfColors.grey700)),
                pw.Text(
                    'Dicetak: ${DateFormat('dd MMM yyyy HH:mm').format(DateTime.now())}',
                    style: const pw.TextStyle(
                        fontSize: 8, color: PdfColors.grey600)),
              ],
            ),
          ],
        ),
        pw.SizedBox(height: 8),
        pw.Divider(color: _brand, thickness: 2),
        pw.SizedBox(height: 20),
      ],
    );
  }

  static pw.Widget _buildFooter(String storeName, pw.Context context) {
    return pw.Container(
      alignment: pw.Alignment.centerRight,
      margin: const pw.EdgeInsets.only(top: 20),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text('$storeName - Juragan Servis',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
          pw.Text('Halaman ${context.pageNumber} dari ${context.pagesCount}',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
        ],
      ),
    );
  }

  static pw.Widget _buildSectionHeader(String title) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.symmetric(vertical: 6, horizontal: 10),
      margin: const pw.EdgeInsets.only(bottom: 12),
      decoration: const pw.BoxDecoration(
        color: _brand,
        borderRadius: pw.BorderRadius.all(pw.Radius.zero),
      ),
      child: pw.Text(title,
          style: pw.TextStyle(
              color: PdfColors.white,
              fontWeight: pw.FontWeight.bold,
              fontSize: 11,
              letterSpacing: 1.2)),
    );
  }

  static pw.Widget _buildPLRow(String label, int value,
      {bool isBold = false,
      bool isDoubleUnderline = false,
      PdfColor? color,
      String? subtitle}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 4, horizontal: 10),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(label,
                  style: pw.TextStyle(
                      fontSize: 10,
                      fontWeight:
                          isBold ? pw.FontWeight.bold : pw.FontWeight.normal,
                      color: isBold ? _dark : PdfColors.grey800)),
              if (subtitle != null)
                pw.Text(subtitle,
                    style: const pw.TextStyle(
                        fontSize: 8, color: PdfColors.grey600)),
            ],
          ),
          pw.Container(
            padding:
                isDoubleUnderline ? const pw.EdgeInsets.only(bottom: 2) : null,
            decoration: isDoubleUnderline
                ? const pw.BoxDecoration(
                    border: pw.Border(bottom: pw.BorderSide(width: 1.5)))
                : null,
            child: pw.Text(value == 0 && !isBold ? '-' : _fRp(value),
                style: pw.TextStyle(
                    fontSize: 11,
                    fontWeight:
                        isBold ? pw.FontWeight.bold : pw.FontWeight.normal,
                    color: color ?? (value < 0 ? _red : _dark))),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildSummaryCards(
      int omzet, int hpp, int net, String margin) {
    return pw.Row(
      children: [
        _buildStatBox('Omzet Bersih', _fRp(omzet), _brand),
        pw.SizedBox(width: 10),
        _buildStatBox('HPP', _fRp(hpp), _red),
        pw.SizedBox(width: 10),
        _buildStatBox('Laba Bersih', _fRp(net), _green,
            subtitle: 'Margin $margin%'),
      ],
    );
  }

  static pw.Widget _buildStatBox(String label, String value, PdfColor color,
      {String? subtitle}) {
    return pw.Expanded(
      child: pw.Container(
        padding: const pw.EdgeInsets.all(10),
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColors.grey300),
          borderRadius: const pw.BorderRadius.all(pw.Radius.zero),
          color: PdfColors.grey50,
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(label,
                style:
                    const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
            pw.SizedBox(height: 4),
            pw.Text(value,
                style: pw.TextStyle(
                    fontSize: 12,
                    fontWeight: pw.FontWeight.bold,
                    color: color)),
            if (subtitle != null)
              pw.Text(subtitle, style: pw.TextStyle(fontSize: 7, color: color)),
          ],
        ),
      ),
    );
  }

  static pw.Widget _buildChart(int hpp, int expenses, int net) {
    final data = {
      'HPP': max(0.0, hpp.toDouble()),
      'Biaya': max(0.0, expenses.toDouble()),
      'Laba': max(0.0, net.toDouble()),
    };

    if (hpp <= 0 && expenses <= 0 && net <= 0) {
      return pw.Text('Tidak ada data untuk grafik',
          style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey500));
    }

    final total = data.values.fold<double>(0, (sum, value) => sum + value);

    return pw.Row(
      children: [
        pw.Expanded(
          flex: 1,
          child: pw.SizedBox(
            height: 120,
            child: pw.Chart(
              grid: pw.PieGrid(),
              datasets: data.entries.map((e) {
                final color = e.key == 'HPP'
                    ? _red
                    : (e.key == 'Laba' ? _green : PdfColors.orange700);
                return pw.PieDataSet(
                  value: e.value,
                  legend: e.key,
                  color: color,
                );
              }).toList(),
            ),
          ),
        ),
        pw.SizedBox(width: 40),
        pw.Expanded(
          flex: 1,
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: data.entries.map((e) {
              final color = e.key == 'HPP'
                  ? _red
                  : (e.key == 'Laba' ? _green : PdfColors.orange700);
              final pct =
                  total > 0 ? (e.value / total * 100).toStringAsFixed(1) : '0';
              return pw.Padding(
                padding: const pw.EdgeInsets.symmetric(vertical: 4),
                child: pw.Row(
                  children: [
                    pw.Container(width: 12, height: 12, color: color),
                    pw.SizedBox(width: 8),
                    pw.Text('${e.key}: $pct%',
                        style: pw.TextStyle(
                            fontSize: 10, fontWeight: pw.FontWeight.bold)),
                    pw.Spacer(),
                    pw.Text(_fRp(e.value.toInt()),
                        style: const pw.TextStyle(fontSize: 10)),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  static pw.Widget _buildProductTable(
      List<Map<String, dynamic>> productMargins) {
    if (productMargins.isEmpty) {
      return pw.Text('Tidak ada rincian item/layanan',
          style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey600));
    }

    return pw.TableHelper.fromTextArray(
      headers: [
        'Item/Layanan',
        'Terjual',
        'Omzet',
        'HPP',
        'Sumber HPP',
        'Laba Kotor',
        'Margin %'
      ],
      data: productMargins
          .map((p) => [
                p['product_name'] ?? '-',
                '${p['total_qty'] ?? 0}',
                _fRp(p['total_omzet'] ?? 0),
                (p['hpp_source'] ?? 'HPP tidak dihitung') ==
                        'HPP tidak dihitung'
                    ? '-'
                    : _fRp(p['total_hpp'] ?? 0),
                p['hpp_source'] ?? 'HPP tidak dihitung',
                _fRp(p['laba_kotor'] ?? 0),
                '${p['margin_pct'] ?? 0}%',
              ])
          .toList(),
      headerStyle: pw.TextStyle(
          fontWeight: pw.FontWeight.bold, color: PdfColors.white, fontSize: 9),
      headerDecoration: const pw.BoxDecoration(color: _brand),
      cellStyle: const pw.TextStyle(fontSize: 8),
      cellAlignments: {
        0: pw.Alignment.centerLeft,
        1: pw.Alignment.center,
        2: pw.Alignment.centerRight,
        3: pw.Alignment.centerRight,
        4: pw.Alignment.center,
        5: pw.Alignment.centerRight,
        6: pw.Alignment.centerRight,
      },
      oddRowDecoration: const pw.BoxDecoration(color: _brandLight),
      border: pw.TableBorder.all(color: PdfColors.grey300),
      cellPadding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 4),
    );
  }
}

