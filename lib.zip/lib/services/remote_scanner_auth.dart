import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';

class RemoteScannerAuth {
  static const Duration allowedClockSkew = Duration(seconds: 45);
  static final Random _secureRandom = Random.secure();

  static Map<String, dynamic> signPayload({
    required String secret,
    required String method,
    required String path,
    required Map<String, dynamic> payload,
    DateTime? nowUtc,
    String? nonce,
  }) {
    final issuedAt = (nowUtc ?? DateTime.now().toUtc()).millisecondsSinceEpoch;
    final cleanNonce = nonce ?? generateNonce();
    final signature = computeSignature(
      secret: secret,
      method: method,
      path: path,
      timestampMs: issuedAt,
      nonce: cleanNonce,
      payload: payload,
    );
    return {
      ...payload,
      'auth': {
        'timestamp_ms': issuedAt,
        'nonce': cleanNonce,
        'signature': signature,
      },
    };
  }

  static String computeSignature({
    required String secret,
    required String method,
    required String path,
    required int timestampMs,
    required String nonce,
    required Map<String, dynamic> payload,
  }) {
    final message = [
      method.trim().toUpperCase(),
      path.trim(),
      timestampMs.toString(),
      nonce.trim(),
      canonicalJson(payload),
    ].join('\n');
    final digest = Hmac(sha256, utf8.encode(secret.trim())).convert(
      utf8.encode(message),
    );
    return base64UrlEncode(digest.bytes).replaceAll('=', '');
  }

  static bool isTimestampFresh(
    int timestampMs, {
    DateTime? nowUtc,
  }) {
    final now = (nowUtc ?? DateTime.now().toUtc()).millisecondsSinceEpoch;
    final age = (now - timestampMs).abs();
    return age <= allowedClockSkew.inMilliseconds;
  }

  static String generateNonce() {
    final bytes = List<int>.generate(18, (_) => _secureRandom.nextInt(256));
    return base64UrlEncode(bytes).replaceAll('=', '');
  }

  static String canonicalJson(dynamic value) {
    return jsonEncode(_canonicalize(value));
  }

  static bool constantTimeEquals(String left, String right) {
    final leftBytes = utf8.encode(left);
    final rightBytes = utf8.encode(right);
    final maxLength = leftBytes.length > rightBytes.length
        ? leftBytes.length
        : rightBytes.length;

    var diff = leftBytes.length ^ rightBytes.length;
    for (var i = 0; i < maxLength; i++) {
      final leftByte = i < leftBytes.length ? leftBytes[i] : 0;
      final rightByte = i < rightBytes.length ? rightBytes[i] : 0;
      diff |= leftByte ^ rightByte;
    }
    return diff == 0;
  }

  static dynamic _canonicalize(dynamic value) {
    if (value is Map) {
      final keys = value.keys.map((key) => key.toString()).toList()..sort();
      final normalized = <String, dynamic>{};
      for (final key in keys) {
        normalized[key] = _canonicalize(value[key]);
      }
      return normalized;
    }
    if (value is List) {
      return value.map(_canonicalize).toList();
    }
    return value;
  }
}

