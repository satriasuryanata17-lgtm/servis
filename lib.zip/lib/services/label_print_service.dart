import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/db_models.dart';
import '../screens/cetak_label_screen.dart';

class LabelPrintException implements Exception {
  final String message;

  const LabelPrintException(this.message);

  @override
  String toString() => message;
}

typedef LabelPrintProgress = void Function(String message);

class LabelPrintService {
  static const String printerNotSelectedMessage =
      'Printer bluetooth belum dipilih.';
  static const String bluetoothDisabledMessage =
      'Bluetooth belum aktif. Nyalakan Bluetooth lalu coba cetak ulang.';
  static const String printerUnavailableMessage =
      'Printer thermal tidak dapat dihubungkan. Pastikan printer menyala, sudah dipasangkan, dan berada dekat dengan kasir.';

  static String errorMessage(Object error) {
    final raw = error.toString().replaceFirst('Exception: ', '').trim();
    if (raw.isEmpty) {
      return 'Gagal mencetak barcode. Periksa printer lalu coba lagi.';
    }
    return raw;
  }

  static bool isPrinterSetupError(Object error) {
    final message = errorMessage(error).toLowerCase();
    return message.contains('printer bluetooth') ||
        message.contains('printer thermal') ||
        message.contains('bluetooth belum aktif') ||
        message.contains('belum dipilih') ||
        message.contains('tidak dapat dihubungkan');
  }

  static Future<bool> ensureBluetoothConnected({
    String? macPrinterAddress,
    LabelPrintProgress? onProgress,
  }) async {
    onProgress?.call('Mengecek Bluetooth...');
    final bluetoothOn = await PrintBluetoothThermal.bluetoothEnabled;
    if (!bluetoothOn) {
      throw const LabelPrintException(bluetoothDisabledMessage);
    }

    final alreadyConnected = await PrintBluetoothThermal.connectionStatus;
    if (alreadyConnected) {
      onProgress?.call('Printer thermal sudah terhubung.');
      return true;
    }

    final mac = macPrinterAddress?.trim() ?? '';
    if (mac.isEmpty) {
      throw const LabelPrintException(printerNotSelectedMessage);
    }

    for (var attempt = 1; attempt <= 3; attempt++) {
      onProgress?.call('Menghubungkan printer thermal ($attempt/3)...');
      final connected =
          await PrintBluetoothThermal.connect(macPrinterAddress: mac);
      if (connected) {
        onProgress?.call('Printer thermal terhubung.');
        return true;
      }
      if (attempt < 3) {
        await Future.delayed(const Duration(milliseconds: 650));
      }
    }

    throw const LabelPrintException(printerUnavailableMessage);
  }

  static String _fmtRp(int value) {
    final s = value.toString();
    final buf = StringBuffer('Rp');
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  static List<int> _escLine(String text) {
    return [...text.codeUnits, 0x0A];
  }

  /// Print advanced labels using configurations from LabelSettings
  static Future<bool> printAdvancedLabels(
    List<ProductPrintItem> printItems,
    LabelSettings settings, {
    LabelPrintProgress? onProgress,
    String? bluetoothMacAddress,
  }) async {
    if (printItems.isEmpty) {
      throw const LabelPrintException('Tidak ada barcode yang dipilih.');
    }
    await ensureBluetoothConnected(
      macPrinterAddress: bluetoothMacAddress,
      onProgress: onProgress,
    );

    List<int> bytes = [];

    // init printer
    bytes.addAll([0x1B, 0x40]);

    for (final item in printItems) {
      final product = item.product;
      for (int i = 0; i < item.qty; i++) {
        // Alignment
        int alignHex = 0x01; // center
        if (settings.priceAlign == 'left') {
          alignHex = 0x00;
        }
        if (settings.priceAlign == 'right') {
          alignHex = 0x02;
        }
        bytes.addAll([0x1B, 0x61, alignHex]);

        // Store Name
        if (settings.showStoreName) {
          bytes.addAll([0x1B, 0x21, 0x00]); // Normal font
          bytes.addAll(_escLine(settings.storeName));
        }

        // Product Name
        if (settings.showName) {
          int fontConfig = 0x00; // Normal
          if (settings.fontSize == 'small') {
            fontConfig = 0x01;
          } else if (settings.fontSize == 'large') {
            fontConfig = 0x10; // Double height
          }

          bytes.addAll([0x1B, 0x21, fontConfig]); // Font size
          bytes.addAll([0x1B, 0x45, 0x01]); // Bold on
          bytes.addAll(_escLine(product.name));
          bytes.addAll([0x1B, 0x45, 0x00]); // Bold off
        }

        // Price
        if (settings.showPrice) {
          int fontConfig = 0x00; // Normal
          if (settings.fontSize == 'small') {
            fontConfig = 0x00;
          } else if (settings.fontSize == 'large') {
            fontConfig = 0x11; // Double width & height
          } else {
            fontConfig = 0x10; // Double height for normal
          }

          bytes.addAll([0x1B, 0x21, fontConfig]); // Font size
          bytes.addAll([0x1B, 0x45, 0x01]); // Bold on
          bytes.addAll(_escLine(_fmtRp(product.sellPrice)));
          bytes.addAll([0x1B, 0x45, 0x00]); // Bold off
        }

        // SKU
        if (settings.showSku &&
            product.sku != null &&
            product.sku!.isNotEmpty) {
          bytes.addAll([0x1B, 0x21, 0x01]); // Small font
          bytes.addAll(_escLine('SKU: ${product.sku!}'));
        }

        // Barcode (CODE128)
        if (settings.showBarcode &&
            product.barcode != null &&
            product.barcode!.isNotEmpty) {
          final barcodeHeight =
              settings.thermalBarcodeHeight.clamp(32, 180).toInt();
          final barcodeWidth = settings.thermalBarcodeWidth.clamp(2, 6).toInt();
          bytes.addAll([0x1D, 0x68, barcodeHeight]); // Barcode height
          bytes.addAll([0x1D, 0x77, barcodeWidth]); // Barcode width
          bytes.addAll([0x1D, 0x48, 0x02]); // Text below barcode

          // Print CODE128
          String bc = product.barcode!;
          bytes.addAll([0x1D, 0x6B, 0x49, bc.length]); // GS k m n
          bytes.addAll(bc.codeUnits);
          bytes.addAll([0x0A]);
        }

        // Date
        if (settings.showDate) {
          bytes.addAll([0x1B, 0x21, 0x01]); // Small font
          bytes.addAll(
              _escLine(DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())));
        }

        // Space before cut
        bytes.addAll([0x0A, 0x0A]);

        // Cut paper (partial cut)
        bytes.addAll([0x1D, 0x56, 0x01]);
      }
    }

    onProgress?.call('Mengirim barcode ke printer...');
    final ok = await PrintBluetoothThermal.writeBytes(bytes);
    if (!ok) throw const LabelPrintException('Printer tidak merespon.');
    return ok;
  }

  /// Print single product directly to bluetooth thermal printer using text format (Legacy support)
  static Future<bool> printLabels(
      Product product, int quantity, int paperSizeMm) async {
    final prefs = await SharedPreferences.getInstance();
    final bluetoothMacAddress = prefs.getString('struk_printerMac') ?? '';
    final settings = LabelSettings(
      paperSizeMm: paperSizeMm,
      showName: true,
      showPrice: true,
      showBarcode: true,
      priceAlign: 'center',
      fontSize: 'normal',
      showStoreName: false,
    );
    final printItem = ProductPrintItem(product: product, qty: quantity);
    return printAdvancedLabels(
      [printItem],
      settings,
      bluetoothMacAddress: bluetoothMacAddress,
    );
  }
}

