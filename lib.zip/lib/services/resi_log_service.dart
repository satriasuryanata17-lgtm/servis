import '../database/db_helper.dart';

class ResiLogService {
  static final ResiLogService _instance = ResiLogService._internal();
  factory ResiLogService() => _instance;
  ResiLogService._internal();

  Future<void> logPrint({
    required String trackingNumber,
    required String courier,
    required String source,
  }) async {
    await DBHelper.instance.insertResiLog(
      trackingNumber: trackingNumber,
      courier: courier,
      source: source,
    );
  }

  Future<List<Map<String, dynamic>>> getHistory({int limit = 100}) async {
    return await DBHelper.instance.getResiLogs(limit: limit);
  }

  Future<void> autoCleanup(int days) async {
    await DBHelper.instance.clearOldResiLogs(days);
  }
}

