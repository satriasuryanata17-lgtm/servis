import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';

enum POSNetworkMode { none, master, terminal }

class POSNetworkService {
  static final POSNetworkService instance = POSNetworkService._();
  POSNetworkService._();

  static const int _discoveryPort = 9091;
  static const int _serverPort = 9090;
  static const String _discoveryMsg = 'JURAGAN_servis_MASTER';

  static const String _prefMode = 'pos_network_mode';
  static const String _prefIp = 'pos_network_master_ip';

  HttpServer? _server;
  RawDatagramSocket? _discoverySocket;
  Timer? _broadcastTimer;
  POSNetworkMode _mode = POSNetworkMode.none;
  String? _masterIp;

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    final savedMode = prefs.getString(_prefMode);
    _masterIp = prefs.getString(_prefIp);

    if (savedMode == POSNetworkMode.master.name) {
      await startMasterMode();
    } else if (savedMode == POSNetworkMode.terminal.name) {
      _mode = POSNetworkMode.terminal;
      if (_masterIp != null) {
        _log('Auto-connect ke Master: $_masterIp');
      }
    }
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefMode, _mode.name);
    if (_masterIp != null) {
      await prefs.setString(_prefIp, _masterIp!);
    }
  }

  POSNetworkMode get mode => _mode;
  String? get masterIp => _masterIp;
  bool get isRunning => _server != null || _discoverySocket != null;

  final StreamController<String> _logController =
      StreamController<String>.broadcast();
  Stream<String> get logStream => _logController.stream;

  //
  //  MASTER MODE (SERVER)
  //

  Future<bool> startMasterMode() async {
    try {
      if (isRunning) await stop();

      // 1. Start HTTP Server
      _server = await HttpServer.bind(InternetAddress.anyIPv4, _serverPort);
      _server!.listen(_handleRequest);

      _mode = POSNetworkMode.master;
      await _saveSettings();
      _log('Server Utama aktif di port $_serverPort');

      // 2. Start UDP Broadcaster
      _discoverySocket =
          await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      _discoverySocket!.broadcastEnabled = true;

      _broadcastTimer =
          Timer.periodic(const Duration(seconds: 5), (timer) async {
        final ip = await _getLocalIp();
        if (ip != null) {
          final data = utf8.encode('$_discoveryMsg|$ip');
          _discoverySocket!
              .send(data, InternetAddress('255.255.255.255'), _discoveryPort);
        }
      });

      return true;
    } catch (e) {
      _log('Gagal mengaktifkan Server Utama: $e');
      return false;
    }
  }

  /// Memukul "Lonceng" untuk memberitahu semua client ada data baru
  Future<void> notifyClients() async {
    if (_discoverySocket == null) return;
    try {
      final data = utf8.encode('JURAGAN_servis_UPDATE');
      _discoverySocket!
          .send(data, InternetAddress('255.255.255.255'), _discoveryPort);
      _log('Sinyal update dikirim ke semua perangkat');
    } catch (e) {
      _log('Gagal mengirim sinyal update: $e');
    }
  }

  void _handleRequest(HttpRequest request) async {
    final path = request.uri.path;
    final method = request.method;

    _log(
        'Request: $method $path from ${request.connectionInfo?.remoteAddress.address}');

    try {
      if (path == '/ping') {
        _sendResponse(request, {'status': 'ok', 'app': 'Juragan Servis'});
      } else if (path == '/sync/menu' && method == 'GET') {
        final products = await DBHelper.instance.getAllProducts();
        final categories = await DBHelper.instance.getCategories();
        _sendResponse(request, {
          'products': products.map((e) => e.toMap()).toList(),
          'categories': categories.map((e) => e.toMap()).toList(),
        });
      } else if (path == '/sync/transactions' && method == 'GET') {
        final transactions = await DBHelper.instance.getAllTransactions();
        _sendResponse(request, transactions.map((e) => e.toMap()).toList());
      } else if (path == '/sync/merge' && method == 'POST') {
        final body = await _readBody(request);
        final txId = body['existingTxId'] as int;
        final itemsMaps = List<Map<String, dynamic>>.from(body['items']);
        final items = itemsMaps.map((e) => TransactionItem.fromMap(e)).toList();
        final addTotal = body['additionalTotalAmount'] as int;
        final addGrand = body['additionalGrandTotal'] as int;

        await DBHelper.instance
            .mergeTransaction(txId, addTotal, addGrand, items);
        _sendResponse(request, {'status': 'ok'});
        notifyClients();
      } else if (path == '/transaction/servis-status' && method == 'POST') {
        final body = await _readBody(request);
        final txId = body['txId'] as int;
        final status = body['status'] as String;
        final kelengkapan = body['kelengkapan'] as String?;

        await DBHelper.instance
            .updateTransactionservisStatus(txId, status, kelengkapan);
        _sendResponse(request, {'status': 'ok'});
        notifyClients();
      } else if (path == '/transaction/mark-paid' && method == 'POST') {
        final body = await _readBody(request);
        final txId = body['txId'] as int;
        final grandTotal = body['grandTotal'] as int;
        final paymentMethod = body['paymentMethod'] as String;
        final finish = body['finish'] as bool? ?? false;
        final kelengkapan = body['kelengkapan'] as String?;
        final replacePaymentMethod =
            body['replacePaymentMethod'] as bool? ?? true;

        final paidNow = await _recordRemainingPaymentIfNeeded(
          txId: txId,
          grandTotal: grandTotal,
          paymentMethod: paymentMethod,
        );
        await DBHelper.instance.updateTransactionAmountPaid(txId, grandTotal);
        await DBHelper.instance.updateTransactionStatus(txId, 'Lunas');
        final db = await DBHelper.instance.database;
        await db.update(
          'transactions',
          {
            if (replacePaymentMethod) 'payment_method': paymentMethod,
            'updated_at': DateTime.now().toIso8601String(),
          },
          where: 'id = ?',
          whereArgs: [txId],
        );
        if (finish) {
          await DBHelper.instance
              .updateTransactionservisStatus(txId, 'Selesai', kelengkapan);
        }
        await DBHelper.instance.insertAuditLog(AuditLog(
          action: 'piutang_payment',
          entityType: 'transaction',
          entityId: txId,
          staffName: 'Terminal',
          amount: paidNow,
          note: finish
              ? 'Pelunasan order servis dan selesai dari terminal'
              : 'Pelunasan order servis dari terminal',
          metadataJson: jsonEncode({
            'payment_method': paymentMethod,
            'source': 'terminal_sync',
          }),
          createdAt: DateTime.now().toIso8601String(),
        ));

        _sendResponse(request, {'status': 'ok', 'paid_now': paidNow});
        notifyClients();
      } else if (path == '/order/send' && method == 'POST') {
        final body = await _readBody(request);
        final txMap = Map<String, dynamic>.from(body['transaction']);
        final itemsMaps = List<Map<String, dynamic>>.from(body['items']);

        final tx = Transaction.fromMap(txMap);
        final items = itemsMaps.map((e) => TransactionItem.fromMap(e)).toList();

        final newTxId = await DBHelper.instance.insertTransaction(tx, items);

        final servisStationId = body['servisStationId'] as int?;
        final servisStationName = body['servisStationName'] as String?;

        final nowIso = DateTime.now().toIso8601String();
        await DBHelper.instance.insertservisWorkshopTicket(
          servisWorkshopTicket(
            transactionId: newTxId,
            tableName: servisStationName?.isNotEmpty == true
                ? servisStationName!
                : (tx.customerName ?? 'Pelanggan Umum'),
            customerName: tx.customerName,
            orderType: tx.orderType ?? 'Ambil Sendiri',
            status: 'queued',
            station: 'Workshop',
            note: tx.note,
            createdAt: nowIso,
            updatedAt: nowIso,
          ),
        );

        if (servisStationId != null) {
          await DBHelper.instance.assignservisStationToTransaction(
            stationId: servisStationId,
            transactionId: newTxId,
          );
        }

        _sendResponse(request,
            {'status': 'success', 'msg': 'Pesanan diterima', 'id': newTxId});
        notifyClients();
      } else if (path == '/workshop/tickets' && method == 'GET') {
        final tickets = await DBHelper.instance.getservisWorkshopTickets();
        _sendResponse(request, tickets.map((e) => e.toMap()).toList());
      } else if (path == '/workshop/update' && method == 'POST') {
        final body = await _readBody(request);
        final id = body['id'] as int;
        final status = body['status'] as String;
        await DBHelper.instance.updateservisWorkshopTicketStatus(id, status);
        _sendResponse(request, {'status': 'ok'});
        notifyClients();
      } else {
        request.response.statusCode = HttpStatus.notFound;
        await request.response.close();
      }
    } catch (e) {
      _log('Error handle request: $e');
      request.response.statusCode = HttpStatus.internalServerError;
      request.response.write(jsonEncode({'error': e.toString()}));
      await request.response.close();
    }
  }

  Future<int> _recordRemainingPaymentIfNeeded({
    required int txId,
    required int grandTotal,
    required String paymentMethod,
  }) async {
    final tx = await DBHelper.instance.getTransactionById(txId);
    final targetTotal = grandTotal > 0 ? grandTotal : tx?.grandTotal ?? 0;
    if (targetTotal <= 0) return 0;

    final paidNet = tx == null
        ? 0
        : (tx.amountPaid - tx.changeAmount).clamp(0, targetTotal).toInt();
    final remaining = (targetTotal - paidNet).clamp(0, targetTotal).toInt();
    if (remaining <= 0) return 0;

    await DBHelper.instance.insertCicilan(
      Cicilan(
        transactionId: txId,
        nominal: remaining,
        metodePembayaran:
            paymentMethod.trim().isEmpty ? 'tunai' : paymentMethod.trim(),
        createdAt: DateTime.now().toIso8601String(),
      ),
    );
    return remaining;
  }

  //
  //  TERMINAL MODE (CLIENT)
  //

  final StreamController<String> _discoveryController =
      StreamController<String>.broadcast();
  Stream<String> get discoveryStream => _discoveryController.stream;

  final StreamController<void> _notifyController =
      StreamController<void>.broadcast();
  Stream<void> get updateSignalStream => _notifyController.stream;

  Future<void> startDiscovery() async {
    try {
      if (_discoverySocket != null) await stop();

      // Bind to fixed port to hear broadcasts from Master
      _discoverySocket = await RawDatagramSocket.bind(
        InternetAddress.anyIPv4,
        _discoveryPort,
        reuseAddress: true,
      );
      _discoverySocket!.broadcastEnabled = true;
      _log('Mencari Server Utama...');

      _discoverySocket!.listen((RawSocketEvent event) {
        if (event == RawSocketEvent.read) {
          final dg = _discoverySocket!.receive();
          if (dg != null) {
            final msg = utf8.decode(dg.data);
            if (msg.startsWith(_discoveryMsg)) {
              final ip = msg.split('|').last;
              _discoveryController.add(ip);
            } else if (msg == 'JURAGAN_servis_UPDATE') {
              _notifyController.add(null);
            }
          }
        }
      });
    } catch (e) {
      _log('Gagal menjalankan pencarian: $e');
    }
  }

  Future<bool> connectToMaster(String ip) async {
    _masterIp = ip;
    _mode = POSNetworkMode.terminal;
    await _saveSettings();
    _log('Terhubung ke Server Utama: $ip');
    return true;
  }

  //
  //  DATA SYNC METHODS (TERMINAL)
  //

  Future<Map<String, dynamic>?> fetchMenu() async {
    if (_masterIp == null) return null;
    try {
      final client = HttpClient();
      final request = await client
          .getUrl(Uri.parse('http://$_masterIp:$_serverPort/sync/menu'));
      final response = await request.close();
      if (response.statusCode == HttpStatus.ok) {
        final content = await utf8.decoder.bind(response).join();
        return jsonDecode(content);
      }
    } catch (e) {
      _log('Gagal ambil menu: $e');
    }
    return null;
  }

  Future<int?> sendOrder({
    required Transaction transaction,
    required List<TransactionItem> items,
    List<servisWorkshopTicket>? tickets,
    int? servisStationId,
    String? servisStationName,
  }) async {
    if (_masterIp == null) return null;
    try {
      final client = HttpClient();
      final request = await client
          .postUrl(Uri.parse('http://$_masterIp:$_serverPort/order/send'));
      request.headers.contentType = ContentType.json;

      final body = {
        'transaction': transaction.toMap(),
        'items': items.map((e) => e.toMap()).toList(),
        'tickets': tickets?.map((e) => e.toMap()).toList() ?? [],
        'servisStationId': servisStationId,
        'servisStationName': servisStationName,
      };

      request.write(jsonEncode(body));
      final response = await request.close();
      if (response.statusCode == HttpStatus.ok) {
        final content = await utf8.decoder.bind(response).join();
        final data = jsonDecode(content);
        return data['id'] as int?;
      }
    } catch (e) {
      _log('Gagal kirim pesanan: $e');
    }
    return null;
  }

  Future<List<Transaction>> fetchTransactions() async {
    if (_masterIp == null) return [];
    try {
      final client = HttpClient();
      final request = await client.getUrl(
          Uri.parse('http://$_masterIp:$_serverPort/sync/transactions'));
      final response = await request.close();
      if (response.statusCode == HttpStatus.ok) {
        final content = await utf8.decoder.bind(response).join();
        final List list = jsonDecode(content);
        return list.map((e) => Transaction.fromMap(e)).toList();
      }
    } catch (e) {
      _log('Gagal ambil riwayat: $e');
    }
    return [];
  }

  Future<List<servisWorkshopTicket>> fetchWorkshopTickets() async {
    if (_masterIp == null) return [];
    try {
      final client = HttpClient();
      final request = await client
          .getUrl(Uri.parse('http://$_masterIp:$_serverPort/workshop/tickets'));
      final response = await request.close();
      if (response.statusCode == HttpStatus.ok) {
        final content = await utf8.decoder.bind(response).join();
        final List list = jsonDecode(content);
        return list.map((e) => servisWorkshopTicket.fromMap(e)).toList();
      }
    } catch (e) {
      _log('Gagal ambil tiket workshop: $e');
    }
    return [];
  }

  Future<bool> updateWorkshopStatus(int ticketId, String status) async {
    if (_masterIp == null) return false;
    try {
      final client = HttpClient();
      final request = await client
          .postUrl(Uri.parse('http://$_masterIp:$_serverPort/workshop/update'));
      request.headers.contentType = ContentType.json;
      request.write(jsonEncode({'id': ticketId, 'status': status}));
      final response = await request.close();
      return response.statusCode == HttpStatus.ok;
    } catch (e) {
      _log('Gagal update status workshop: $e');
      return false;
    }
  }

  Future<bool> updateTransactionservisStatus({
    required int txId,
    required String status,
    String? kelengkapan,
  }) async {
    if (_masterIp == null) return false;
    try {
      final client = HttpClient();
      final request = await client.postUrl(
        Uri.parse('http://$_masterIp:$_serverPort/transaction/servis-status'),
      );
      request.headers.contentType = ContentType.json;
      request.write(jsonEncode({
        'txId': txId,
        'status': status,
        'kelengkapan': kelengkapan,
      }));
      final response = await request.close();
      return response.statusCode == HttpStatus.ok;
    } catch (e) {
      _log('Gagal update status transaksi: $e');
      return false;
    }
  }

  Future<bool> markTransactionPaid({
    required int txId,
    required int grandTotal,
    required String paymentMethod,
    bool finish = false,
    String? kelengkapan,
    bool replacePaymentMethod = true,
  }) async {
    if (_masterIp == null) return false;
    try {
      final client = HttpClient();
      final request = await client.postUrl(
        Uri.parse('http://$_masterIp:$_serverPort/transaction/mark-paid'),
      );
      request.headers.contentType = ContentType.json;
      request.write(jsonEncode({
        'txId': txId,
        'grandTotal': grandTotal,
        'paymentMethod': paymentMethod,
        'finish': finish,
        'kelengkapan': kelengkapan,
        'replacePaymentMethod': replacePaymentMethod,
      }));
      final response = await request.close();
      return response.statusCode == HttpStatus.ok;
    } catch (e) {
      _log('Gagal sinkron pelunasan transaksi: $e');
      return false;
    }
  }

  Future<bool> mergeTransaction({
    required int existingTxId,
    required List<TransactionItem> items,
    required int additionalTotalAmount,
    required int additionalGrandTotal,
  }) async {
    if (_masterIp == null) return false;
    try {
      final client = HttpClient();
      final request = await client
          .postUrl(Uri.parse('http://$_masterIp:$_serverPort/sync/merge'));
      request.headers.contentType = ContentType.json;

      final body = {
        'existingTxId': existingTxId,
        'items': items.map((e) => e.toMap()).toList(),
        'additionalTotalAmount': additionalTotalAmount,
        'additionalGrandTotal': additionalGrandTotal,
      };

      request.write(jsonEncode(body));
      final response = await request.close();
      return response.statusCode == HttpStatus.ok;
    } catch (e) {
      _log('Gagal gabung pesanan: $e');
      return false;
    }
  }

  //
  //  HELPER METHODS
  //

  Future<void> stop() async {
    await _server?.close(force: true);
    _discoverySocket?.close();
    _discoverySocket = null; // Ensure null to prevent reuse
    _broadcastTimer?.cancel();
    _server = null;
    _broadcastTimer = null;
    _mode = POSNetworkMode.none;
    await _saveSettings();
    _log('Layanan jaringan dihentikan');
    // Give OS a moment to release the port
    await Future.delayed(const Duration(milliseconds: 200));
  }

  void _log(String msg) {
    debugPrint('[JuraganSync] $msg');
    _logController.add(msg);
  }

  void _sendResponse(HttpRequest request, dynamic data) {
    request.response
      ..statusCode = HttpStatus.ok
      ..headers.contentType = ContentType.json
      ..write(jsonEncode(data))
      ..close();
  }

  Future<Map<String, dynamic>> _readBody(HttpRequest request) async {
    final content = await utf8.decoder.bind(request).join();
    return jsonDecode(content) as Map<String, dynamic>;
  }

  Future<String?> _getLocalIp() async {
    try {
      final interfaces =
          await NetworkInterface.list(type: InternetAddressType.IPv4);
      for (final interface in interfaces) {
        for (final addr in interface.addresses) {
          if (!addr.isLoopback &&
              (addr.address.startsWith('192.168.') ||
                  addr.address.startsWith('10.'))) {
            return addr.address;
          }
        }
      }
    } catch (_) {}
    return null;
  }
}

