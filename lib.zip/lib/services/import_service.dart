import 'dart:io';

import 'package:csv/csv.dart';
import 'package:excel/excel.dart';

/// Represents a single row parsed from an import file.
class ImportedProduct {
  final String name;
  final int stock;
  final int minStock;
  final int buyPrice;
  final int sellPrice;
  final String unit;
  final String? sku;
  final String? barcode;
  final String? description;
  final String? categoryName;

  const ImportedProduct({
    required this.name,
    required this.stock,
    required this.minStock,
    required this.buyPrice,
    required this.sellPrice,
    required this.unit,
    this.sku,
    this.barcode,
    this.description,
    this.categoryName,
  });
}

/// Result of an import operation.
class ImportResult {
  final List<ImportedProduct> products;
  final List<String> errors;
  final int skippedRows;

  const ImportResult({
    required this.products,
    required this.errors,
    required this.skippedRows,
  });
}

class _HeaderMatch {
  final int rowIndex;
  final Map<String, int> colMap;

  const _HeaderMatch(this.rowIndex, this.colMap);
}

class ImportService {
  const ImportService._();

  // Keep aliases permissive so template files, exported CSV files, and manual
  // Excel sheets can be imported without users needing exact column names.
  static const _nameKeys = [
    'nama layanan',
    'nama produk',
    'nama barang',
    'nama item',
    'nama',
    'layanan',
    'produk',
    'barang',
    'item',
    'product name',
    'product',
    'name',
  ];
  static const _stockKeys = [
    'stok',
    'stok saat ini',
    'stock',
    'qty',
    'quantity',
    'jumlah',
  ];
  static const _minStockKeys = [
    'min stok',
    'stok minimal',
    'minimum stok',
    'stok minimum',
    'min stock',
    'minimum stock',
  ];
  static const _buyPriceKeys = [
    'harga beli',
    'modal',
    'harga modal',
    'hpp',
    'buy price',
    'purchase price',
  ];
  static const _sellPriceKeys = [
    'harga jual',
    'harga layanan',
    'harga',
    'harga produk',
    'harga software',
    'jual',
    'sell price',
    'selling price',
    'price',
  ];
  static const _unitKeys = ['software', 'software produk', 'unit'];
  static const _skuKeys = [
    'sku',
    'kode layanan',
    'kode produk',
    'kode barang',
    'kode item',
    'kode',
  ];
  static const _barcodeKeys = ['barcode', 'kode barcode', 'bar code'];
  static const _descKeys = [
    'deskripsi',
    'description',
    'keterangan',
    'catatan',
  ];
  static const _categoryKeys = ['kategori', 'category', 'jenis'];

  /// Parse a `.xlsx` or `.csv` file from [filePath].
  static Future<ImportResult> parseFile(String filePath) async {
    final ext = filePath.toLowerCase();
    if (ext.endsWith('.xlsx') || ext.endsWith('.xls')) {
      return _parseXlsx(filePath);
    } else if (ext.endsWith('.csv')) {
      return _parseCsv(filePath);
    } else {
      return const ImportResult(
        products: [],
        errors: ['Format file tidak didukung. Gunakan .xlsx atau .csv'],
        skippedRows: 0,
      );
    }
  }

  static ImportResult _parseXlsx(String filePath) {
    late final Excel excel;
    try {
      final bytes = File(filePath).readAsBytesSync();
      excel = Excel.decodeBytes(bytes);
    } catch (_) {
      return const ImportResult(
        products: [],
        errors: [
          'File Excel tidak bisa dibaca. Simpan ulang sebagai .xlsx atau gunakan template CSV.',
        ],
        skippedRows: 0,
      );
    }

    if (excel.tables.isEmpty) {
      return const ImportResult(
        products: [],
        errors: ['Sheet kosong atau tidak ditemukan.'],
        skippedRows: 0,
      );
    }

    var scannedRows = 0;
    for (final sheet in excel.tables.values) {
      if (sheet.rows.isEmpty) continue;
      final rows =
          sheet.rows.map((row) => row.map(_cellString).toList()).toList();
      scannedRows += rows.length;
      final header = _findHeaderRow(rows);
      if (header != null) {
        return _parseRows(rows, header);
      }
    }

    return ImportResult(
      products: const [],
      errors: const [
        'Kolom "Nama Layanan" dan "Harga Jual" wajib ada di file. Pastikan file sesuai template.',
      ],
      skippedRows: scannedRows,
    );
  }

  static Future<ImportResult> _parseCsv(String filePath) async {
    String raw = await File(filePath).readAsString();
    if (raw.startsWith('\uFEFF')) raw = raw.substring(1);

    late final List<List<dynamic>> table;
    try {
      table = const CsvDecoder().convert(raw);
    } catch (_) {
      return const ImportResult(
        products: [],
        errors: [
          'File CSV tidak bisa dibaca. Simpan ulang file atau gunakan template impor layanan.',
        ],
        skippedRows: 0,
      );
    }
    if (table.isEmpty) {
      return const ImportResult(
        products: [],
        errors: ['File CSV kosong.'],
        skippedRows: 0,
      );
    }

    final rows = table
        .map((row) => row.map((cell) => cell.toString().trim()).toList())
        .toList();
    final header = _findHeaderRow(rows);
    if (header == null) {
      return ImportResult(
        products: const [],
        errors: const [
          'Kolom "Nama Layanan" dan "Harga Jual" wajib ada di file. Pastikan file sesuai template.',
        ],
        skippedRows: rows.length,
      );
    }

    return _parseRows(rows, header);
  }

  static ImportResult _parseRows(List<List<String>> rows, _HeaderMatch header) {
    final products = <ImportedProduct>[];
    final errors = <String>[];
    var skipped = header.rowIndex;

    for (int i = header.rowIndex + 1; i < rows.length; i++) {
      final rowNum = i + 1;
      final result = _parseRow(rows[i], header.colMap, rowNum);
      if (result == null) {
        skipped++;
        continue;
      }
      if (result is String) {
        errors.add(result);
        skipped++;
      } else {
        products.add(result as ImportedProduct);
      }
    }

    if (products.isEmpty && errors.isEmpty) {
      errors.add(
        'Header file sudah terbaca, tetapi tidak ada baris layanan yang berisi data.',
      );
    }

    return ImportResult(
      products: products,
      errors: errors,
      skippedRows: skipped,
    );
  }

  /// Returns [ImportedProduct] on success, [String] error message on failure,
  /// [null] if row is blank/should be silently skipped.
  static dynamic _parseRow(
    List<String> cells,
    Map<String, int> colMap,
    int rowNum,
  ) {
    String get(String key) {
      final idx = colMap[key];
      if (idx == null || idx >= cells.length) return '';
      return cells[idx].trim();
    }

    final name = get('name');
    if (name.isEmpty) return null;

    if (!colMap.containsKey('sellPrice')) {
      return 'Baris $rowNum ($name): kolom Harga Jual tidak ditemukan.';
    }

    final sellPriceRaw = get('sellPrice');
    final sellPrice = _parseInt(sellPriceRaw);
    if (sellPrice == null) {
      return 'Baris $rowNum ($name): Harga Jual tidak valid ("$sellPriceRaw").';
    }

    final stock = _parseInt(get('stock')) ?? 0;
    final minStock = _parseInt(get('minStock')) ?? 0;
    final buyPrice = _parseInt(get('buyPrice')) ?? 0;
    final unit = get('unit').isEmpty ? 'pcs' : get('unit');

    return ImportedProduct(
      name: name,
      stock: stock,
      minStock: minStock,
      buyPrice: buyPrice,
      sellPrice: sellPrice,
      unit: unit,
      sku: _nullIfEmpty(get('sku')),
      barcode: _nullIfEmpty(get('barcode')),
      description: _nullIfEmpty(get('description')),
      categoryName: _nullIfEmpty(get('categoryName')),
    );
  }

  static _HeaderMatch? _findHeaderRow(List<List<String>> rows) {
    for (var i = 0; i < rows.length; i++) {
      final colMap = _buildColumnMap(rows[i]);
      if (colMap != null) return _HeaderMatch(i, colMap);
    }
    return null;
  }

  /// Builds a map from semantic key to column index by matching header aliases.
  static Map<String, int>? _buildColumnMap(List<String> headers) {
    final map = <String, int>{};
    void add(String key, List<String> aliases) {
      for (int i = 0; i < headers.length; i++) {
        if (aliases.contains(_normalizeHeader(headers[i]))) {
          map[key] = i;
          break;
        }
      }
    }

    add('name', _nameKeys);
    add('stock', _stockKeys);
    add('minStock', _minStockKeys);
    add('buyPrice', _buyPriceKeys);
    add('sellPrice', _sellPriceKeys);
    add('unit', _unitKeys);
    add('sku', _skuKeys);
    add('barcode', _barcodeKeys);
    add('description', _descKeys);
    add('categoryName', _categoryKeys);

    if (!map.containsKey('name')) return null;
    if (!map.containsKey('sellPrice') && !map.containsKey('buyPrice')) {
      return null;
    }
    return map;
  }

  static String _normalizeHeader(String value) {
    return value
        .replaceAll('\uFEFF', '')
        .toLowerCase()
        .replaceAll(RegExp(r'[_\-/]+'), ' ')
        .replaceAll(RegExp(r'[\(\)\[\]\{\}:]+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static String _cellString(dynamic cell) {
    if (cell == null) return '';
    if (cell is Data) {
      final value = cell.value;
      if (value == null) return '';
      if (value is TextCellValue) return value.value.toString().trim();
      if (value is IntCellValue) return value.value.toString();
      if (value is DoubleCellValue) return value.value.toStringAsFixed(0);
      if (value is BoolCellValue) return value.value ? '1' : '0';
      if (value is DateCellValue) return value.toString();
      return value.toString().trim();
    }
    return cell.toString().trim();
  }

  static int? _parseInt(String value) {
    if (value.trim().isEmpty) return null;
    var cleaned = value
        .toLowerCase()
        .replaceAll('rp', '')
        .replaceAll(RegExp(r'[^0-9,\.\-]'), '')
        .trim();
    if (cleaned.isEmpty || cleaned == '-') return null;

    final lastDot = cleaned.lastIndexOf('.');
    final lastComma = cleaned.lastIndexOf(',');

    if (lastDot >= 0 && lastComma >= 0) {
      if (lastComma > lastDot) {
        cleaned = cleaned.replaceAll('.', '');
        cleaned = cleaned.substring(0, cleaned.lastIndexOf(','));
      } else {
        cleaned = cleaned.replaceAll(',', '');
        cleaned = cleaned.substring(0, cleaned.lastIndexOf('.'));
      }
    } else if (lastComma >= 0) {
      final parts = cleaned.split(',');
      if (parts.length == 2 && parts.last.length <= 2) {
        cleaned = parts.first;
      } else {
        cleaned = cleaned.replaceAll(',', '');
      }
    } else if (lastDot >= 0) {
      final thousandPattern = RegExp(r'^-?\d{1,3}(\.\d{3})+$');
      if (thousandPattern.hasMatch(cleaned)) {
        cleaned = cleaned.replaceAll('.', '');
      } else {
        final parts = cleaned.split('.');
        if (parts.length == 2 && parts.last.length <= 2) {
          cleaned = parts.first;
        } else {
          cleaned = cleaned.replaceAll('.', '');
        }
      }
    }

    cleaned = cleaned.replaceAll(RegExp(r'[^0-9\-]'), '');
    return int.tryParse(cleaned);
  }

  static String? _nullIfEmpty(String value) {
    final trimmed = value.trim();
    return trimmed.isEmpty ? null : trimmed;
  }
}

