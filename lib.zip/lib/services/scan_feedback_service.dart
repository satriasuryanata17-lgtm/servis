import 'dart:io' show Platform;

import 'package:flutter/services.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:flutter_tts/flutter_tts.dart';

enum ScanFeedbackTone {
  success,
  warning,
  error,
}

class ScanFeedbackService {
  ScanFeedbackService._();

  static final ScanFeedbackService instance = ScanFeedbackService._();

  final FlutterTts _tts = FlutterTts();
  Future<void>? _ttsInitFuture;

  Future<void> playProductFound({
    required bool useTts,
    required String productName,
  }) async {
    if (useTts && await _speak(productName)) {
      return;
    }
    await playTone(ScanFeedbackTone.success);
  }

  Future<void> playAlreadyInCart({
    required bool useTts,
    required String productName,
  }) async {
    if (useTts && await _speak('$productName sudah ada di keranjang')) {
      return;
    }
    await playTone(ScanFeedbackTone.warning);
  }

  Future<void> playNotFound({
    required bool useTts,
  }) async {
    if (useTts && await _speak('Produk tidak ditemukan')) {
      return;
    }
    await playTone(ScanFeedbackTone.error);
  }

  Future<void> playTtsPreview({
    required bool useTts,
  }) async {
    const previewText =
        'Contoh suara scanner. Ganti LCD HP berhasil masuk keranjang.';
    if (useTts && await _speak(previewText)) {
      return;
    }
    await playTone(ScanFeedbackTone.success);
  }

  Future<void> playTone(ScanFeedbackTone tone) async {
    switch (tone) {
      case ScanFeedbackTone.success:
        if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
          try {
            await SystemSound.play(SystemSoundType.click);
            return;
          } catch (_) {}
        }
        try {
          FlutterRingtonePlayer().playNotification();
          return;
        } catch (_) {}
        try {
          await SystemSound.play(SystemSoundType.click);
          return;
        } catch (_) {}
        break;
      case ScanFeedbackTone.warning:
        try {
          await SystemSound.play(SystemSoundType.click);
          return;
        } catch (_) {}
        break;
      case ScanFeedbackTone.error:
        try {
          await SystemSound.play(SystemSoundType.alert);
          return;
        } catch (_) {}
        break;
    }

    try {
      await SystemSound.play(SystemSoundType.click);
    } catch (_) {}
  }

  Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }

  Future<void> _ensureTtsReady() {
    return _ttsInitFuture ??= _initTts();
  }

  Future<void> _initTts() async {
    try {
      await _tts.setLanguage('id-ID');
      await _tts.setSpeechRate(0.45);
      await _tts.setVolume(1.0);
      await _tts.setPitch(1.0);
      await _tts.awaitSpeakCompletion(false);
    } catch (_) {
      // Fallback tone will be used when TTS engine is unavailable.
    }
  }

  Future<bool> _speak(String text) async {
    final normalized = text.trim();
    if (normalized.isEmpty) return false;

    try {
      await _ensureTtsReady();
      await _tts.stop();
      final result = await _tts.speak(normalized);
      return result != 0;
    } catch (_) {
      return false;
    }
  }
}

