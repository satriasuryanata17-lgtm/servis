import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/receipt_print_service.dart';
import '../services/auth_service.dart';
import '../database/db_helper.dart';

class RemotePrintService {
  static final SupabaseClient _client = Supabase.instance.client;

  static Future<void> sendPrintRequest(ReceiptPrintDocument document) async {
    final license = await DBHelper.instance.getLicense();
    final warung = await DBHelper.instance.getWarungProfile();

    final Map<String, dynamic> docJson = {
      'paperSize': document.paperSize,
      'lineWidth': document.lineWidth,
      'items': document.items
          .map((e) => {
                'name': e.name,
                'qty': e.qty,
                'unitPrice': e.unitPrice,
                'subtotal': e.subtotal,
                'note': e.note,
                'originalUnitPrice': e.originalUnitPrice,
                'originalSubtotal': e.originalSubtotal,
                'priceOverrideAmount': e.priceOverrideAmount,
                'isPriceOverride': e.isPriceOverride,
                'appliedDiscountName': e.appliedDiscountName,
                'appliedDiscountIsPercentage': e.appliedDiscountIsPercentage,
                'appliedDiscountValue': e.appliedDiscountValue,
              })
          .toList(),
      'subtotal': document.subtotal,
      'discountAmount': document.discountAmount,
      'charges': document.charges
          .map((e) => {'label': e.label, 'value': e.value})
          .toList(),
      'additionalCharges': document.additionalCharges,
      'grandTotal': document.grandTotal,
      'amountPaid': document.amountPaid,
      'changeAmount': document.changeAmount,
      'namaWarung': document.namaWarung,
      'alamat': document.alamat,
      'telepon': document.telepon,
      'footer': document.footer,
      'instagram': document.instagram,
      'facebook': document.facebook,
      'tiktok': document.tiktok,
      'noTransaksi': document.noTransaksi,
      'tanggal': document.tanggal,
      'kasirName': document.kasirName,
      'paymentMethod': document.paymentMethod,
      'showAlamat': document.showAlamat,
      'showTelepon': document.showTelepon,
      'showTotalPesanan': document.showTotalPesanan,
      'customerName': document.customerName,
      'orderType': document.orderType,
      'pickupSchedule': document.pickupSchedule,
      'paymentStatus': document.paymentStatus,
      'queueNumber': document.queueNumber,
      'logoPosition': document.logoPosition,
      'logoWidth': document.logoWidth,
      'storeNameFontSize': document.storeNameFontSize,
      'showWatermark': document.showWatermark,
      'title': document.title,
    };

    if (license?.isTrial == 1 && (license?.ldrPrintCount ?? 0) >= 3) {
      throw StateError(
          'Trial cetak struk habis. Silakan hubungi admin untuk upgrade lisensi.');
    }

    try {
      await _client.from('remote_print_requests').insert({
        'serial_license': license?.serial,
        'store_name': warung['nama'] ?? 'Unknown Store',
        'print_data': docJson,
        'status': 'pending',
      });

      if (license?.isTrial == 1) {
        final deviceId = await AuthService.getDeviceId();
        await _client.rpc('rpc_increment_trial_print',
            params: {'p_device_id': deviceId});

        // Update local license count
        if (license != null) {
          final updated =
              license.copyWith(ldrPrintCount: (license.ldrPrintCount) + 1);
          await DBHelper.instance.insertLicense(updated);
        }
      }
    } catch (e) {
      rethrow;
    }
  }

  static Stream<List<Map<String, dynamic>>> streamPendingRequests() {
    return _client
        .from('remote_print_requests')
        .stream(primaryKey: ['id'])
        .eq('status', 'pending')
        .order('created_at', ascending: true);
  }

  static Future<void> markAsPrinted(String id) async {
    await _client
        .from('remote_print_requests')
        .update({'status': 'printed'}).eq('id', id);
  }

  static Future<void> deleteRequest(String id) async {
    await _client.from('remote_print_requests').delete().eq('id', id);
  }

  static ReceiptPrintDocument jsonToDocument(Map<String, dynamic> json) {
    final items = (json['items'] as List)
        .map((e) => ReceiptPrintItem(
              name: e['name'],
              qty: e['qty'],
              unitPrice: e['unitPrice'],
              subtotal: e['subtotal'],
              note: e['note'] ?? '',
              originalUnitPrice: e['originalUnitPrice'] ?? 0,
              originalSubtotal: e['originalSubtotal'] ?? 0,
              priceOverrideAmount: e['priceOverrideAmount'] ?? 0,
              isPriceOverride: e['isPriceOverride'] == true,
              appliedDiscountName: e['appliedDiscountName'] ?? '',
              appliedDiscountIsPercentage:
                  e['appliedDiscountIsPercentage'] ?? 0,
              appliedDiscountValue: e['appliedDiscountValue'] ?? 0,
            ))
        .toList();

    final charges = (json['charges'] as List)
        .map((e) => ReceiptPrintCharge(
              label: e['label'],
              value: e['value'],
            ))
        .toList();

    return ReceiptPrintDocument(
      paperSize: json['paperSize'],
      lineWidth: json['lineWidth'],
      lines: [],
      items: items,
      subtotal: json['subtotal'],
      discountAmount: json['discountAmount'],
      charges: charges,
      additionalCharges: json['additionalCharges'],
      grandTotal: json['grandTotal'],
      amountPaid: json['amountPaid'],
      changeAmount: json['changeAmount'],
      namaWarung: json['namaWarung'],
      alamat: json['alamat'],
      telepon: json['telepon'],
      footer: json['footer'],
      instagram: json['instagram'],
      facebook: json['facebook'],
      tiktok: json['tiktok'],
      noTransaksi: json['noTransaksi'],
      tanggal: json['tanggal'],
      kasirName: json['kasirName'],
      paymentMethod: json['paymentMethod'],
      showAlamat: json['showAlamat'],
      showTelepon: json['showTelepon'],
      showTotalPesanan: json['showTotalPesanan'],
      customerName: json['customerName'],
      orderType: json['orderType'],
      pickupSchedule: json['pickupSchedule'],
      paymentStatus: json['paymentStatus'],
      queueNumber: json['queueNumber'] ?? 0,
      logoPosition: json['logoPosition'] ?? 'top',
      logoWidth: (json['logoWidth'] as num?)?.toDouble() ?? 40.0,
      storeNameFontSize:
          (json['storeNameFontSize'] as num?)?.toDouble() ?? 18.0,
      showWatermark: json['showWatermark'] ?? true,
      title: json['title'] ?? 'STRUK PEMBELIAN',
    );
  }
}

