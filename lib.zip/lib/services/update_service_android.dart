// File ini tidak digunakan  update_service.dart menangani
// semua logika secara langsung dengan Platform.isAndroid guard.
// Dibiarkan kosong agar tidak ada error kompilasi.

