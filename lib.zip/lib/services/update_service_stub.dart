// Stub untuk platform non-Android (Windows, dll)
// Semua fungsi tidak melakukan apa-apa.

Future<bool> checkUpdateAvailable() async => false;

Future<void> startFlexibleUpdate({
  required void Function(double progress) onProgress,
  required void Function() onDownloaded,
}) async {}

Future<void> completeUpdate() async {}

