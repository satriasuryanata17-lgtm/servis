import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:android_id/android_id.dart';
import 'package:crypto/crypto.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../database/db_helper.dart';
import '../models/db_models.dart';

class DeviceLockedException implements Exception {
  final String oldDeviceId;

  DeviceLockedException(this.oldDeviceId);
}

class DeviceLimitReachedException implements Exception {
  final int maxDevices;
  final int currentDevices;

  DeviceLimitReachedException({
    required this.maxDevices,
    required this.currentDevices,
  });
}

class DeviceReplacementCooldownException implements Exception {
  final String message;

  const DeviceReplacementCooldownException(this.message);

  @override
  String toString() => message;
}

class AuthBackendRequiredException implements Exception {
  final String message;

  const AuthBackendRequiredException(this.message);

  @override
  String toString() => message;
}

class DemoTrialException implements Exception {
  final String message;

  const DemoTrialException(this.message);

  @override
  String toString() => message;
}

class LicenseDeviceInfo {
  final String deviceId;
  final String platform;
  final String? activatedAt;
  final String? lastSeenAt;

  const LicenseDeviceInfo({
    required this.deviceId,
    required this.platform,
    this.activatedAt,
    this.lastSeenAt,
  });

  factory LicenseDeviceInfo.fromMap(Map<String, dynamic> map) {
    return LicenseDeviceInfo(
      deviceId: map['device_id']?.toString() ?? '',
      platform: map['platform']?.toString() ?? 'unknown',
      activatedAt: (map['activated_at'] ?? map['created_at'])?.toString(),
      lastSeenAt: map['last_seen_at']?.toString(),
    );
  }
}

enum _RevalidationStatus { valid, invalid, unavailable }

class _RpcLicenseLookupOutcome {
  final bool available;
  final Map<String, dynamic>? record;
  final String? code;
  final String? deviceId;
  final int? maxDevices;
  final int? currentDevices;

  const _RpcLicenseLookupOutcome._({
    required this.available,
    required this.record,
    required this.code,
    required this.deviceId,
    this.maxDevices,
    this.currentDevices,
  });

  const _RpcLicenseLookupOutcome.unavailable()
      : this._(available: false, record: null, code: null, deviceId: null);

  const _RpcLicenseLookupOutcome.invalid({
    String? code,
    String? deviceId,
    int? maxDevices,
    int? currentDevices,
  }) : this._(
          available: true,
          record: null,
          code: code,
          deviceId: deviceId,
          maxDevices: maxDevices,
          currentDevices: currentDevices,
        );

  const _RpcLicenseLookupOutcome.success(Map<String, dynamic> record)
      : this._(
          available: true,
          record: record,
          code: null,
          deviceId: null,
        );

  bool get isSuccess => record != null;
}

class AuthService {
  static const Duration _automaticDemoDuration = Duration(hours: 24);
  static const Duration _rpcTimeout = Duration(seconds: 15);
  static const Duration _remoteValidationFreshFor = Duration(hours: 6);

  static const _androidIdPlugin = AndroidId();
  static const _licensePasswordSalt = 'juragankasir_license_v1_';
  static const _adminPasswordSalt = 'admin_SALT_juragankasir_';
  static const _pinSalt = 'juragankasir_pos_v2_';
  static String? _currentAdminUsername;
  static String? _currentAdminPasswordHash;

  static bool get hasAdminSession => adminRpcParams != null;

  static Map<String, dynamic>? get adminRpcParams {
    final username = _currentAdminUsername?.trim();
    final passwordHash = _currentAdminPasswordHash?.trim();
    if (username == null ||
        username.isEmpty ||
        passwordHash == null ||
        passwordHash.isEmpty) {
      return null;
    }
    return {
      'p_username': username,
      'p_password_hash': passwordHash,
    };
  }

  static Map<String, dynamic> requireAdminRpcParams() {
    final params = adminRpcParams;
    if (params == null) {
      throw StateError('Sesi admin tidak aktif. Silakan login ulang.');
    }
    return params;
  }

  /// Mengambil unik Device ID.
  static Future<String> getDeviceId() async {
    if (kIsWeb) return 'web_browser_device_debug';

    var deviceId = 'unknown_device';
    try {
      if (Platform.isAndroid) {
        final id = await _androidIdPlugin.getId();
        if (id != null) deviceId = id;
      } else if (Platform.isIOS) {
        final deviceInfo = DeviceInfoPlugin();
        final iosInfo = await deviceInfo.iosInfo;
        deviceId = iosInfo.identifierForVendor ?? 'ios_unknown';
      } else if (Platform.isWindows) {
        final deviceInfo = DeviceInfoPlugin();
        final windowsInfo = await deviceInfo.windowsInfo;
        deviceId = windowsInfo.deviceId;
      } else if (Platform.isLinux) {
        final deviceInfo = DeviceInfoPlugin();
        final linuxInfo = await deviceInfo.linuxInfo;
        deviceId = linuxInfo.machineId ?? 'linux_unknown';
      } else if (Platform.isMacOS) {
        final deviceInfo = DeviceInfoPlugin();
        final macInfo = await deviceInfo.macOsInfo;
        deviceId = macInfo.systemGUID ?? 'mac_unknown';
      }
    } catch (_) {
      // Jangan bocorkan info perangkat ke log produksi.
    }
    return deviceId;
  }

  /// Hash PIN karyawan dengan SHA-256 + salt tetap.
  static String hashPin(String plainPin) {
    final bytes = utf8.encode(_pinSalt + plainPin);
    return sha256.convert(bytes).toString();
  }

  /// Memverifikasi PIN karyawan.
  static bool verifyStaffPin(Employee employee, String plainPin) {
    if (employee.pin == null || employee.pin!.isEmpty) return false;
    final hashed = hashPin(plainPin);
    return hashed == employee.pin;
  }

  /// Hash Lisensi (untuk jejak lokal dan audit integritas).
  static String hashLicense(String serial, String password, String deviceId) {
    final raw = 'LCNS_${_normalizeSerial(serial)}-${password.trim()}-$deviceId';
    return sha256.convert(utf8.encode(raw)).toString();
  }

  static String hashLicensePassword(String plainPassword) {
    return sha256
        .convert(utf8.encode('$_licensePasswordSalt${plainPassword.trim()}'))
        .toString();
  }

  static String _hashDemoLicense({
    required String? licenseId,
    required String serial,
    required String deviceId,
  }) {
    final raw = 'DEMO_${licenseId ?? ''}-${_normalizeSerial(serial)}-$deviceId';
    return sha256.convert(utf8.encode(raw)).toString();
  }

  /// Hash Password Admin Utama.
  static String hashAdminPassword(String plain) {
    return sha256.convert(utf8.encode('$_adminPasswordSalt$plain')).toString();
  }

  static Future<void> clearLocalLicense() async {
    await DBHelper.instance.deleteLicense();
  }

  static void clearAdminSession() {
    _currentAdminUsername = null;
    _currentAdminPasswordHash = null;
  }

  /// Login Lisensi Online ke Supabase
  static Future<bool> activateLicense(
    String serial,
    String password,
  ) async {
    final cleanSerial = _normalizeSerial(serial);
    final cleanPassword = password.trim();
    if (cleanSerial.isEmpty || cleanPassword.isEmpty) return false;

    try {
      final deviceId = await getDeviceId();
      final platform = _currentPlatformLabel();
      final rpcOutcome = await _activateLicenseViaRpc(
        serial: cleanSerial,
        passwordHash: hashLicensePassword(cleanPassword),
        deviceId: deviceId,
        platform: platform,
      );
      if (!rpcOutcome.available) {
        throw const AuthBackendRequiredException(
          'Layanan aktivasi lisensi tidak dapat dijangkau. Pastikan perangkat terhubung ke internet dan silakan coba beberapa saat lagi.',
        );
      }

      if (rpcOutcome.isSuccess) {
        final serialRecord = rpcOutcome.record!;
        await _persistValidatedLicense(
          licenseId: serialRecord['id']?.toString(),
          serial: cleanSerial,
          serialHash: hashLicense(cleanSerial, cleanPassword, deviceId),
          deviceId: deviceId,
          isActive: 1,
          expiredAt: serialRecord['expired_at']?.toString(),
          canRemotePrint: _isTruthy(serialRecord['can_remote_print']) ? 1 : 0,
          isTrial: _isTruthy(serialRecord['is_trial']) ? 1 : 0,
          ldrPrintCount:
              (serialRecord['ldr_print_count'] as num?)?.toInt() ?? 0,
        );
        return true;
      }

      final rejectionCode = rpcOutcome.code?.trim().toUpperCase();

      if (rejectionCode == 'DEVICE_LOCKED' ||
          rejectionCode == 'ADMIN_RESET_REQUIRED') {
        throw DeviceLockedException(
          _normalizeStoredDeviceId(rpcOutcome.deviceId) ?? '',
        );
      }
      if (rejectionCode == 'DEVICE_LIMIT_REACHED') {
        throw DeviceLimitReachedException(
          maxDevices: rpcOutcome.maxDevices ?? 1,
          currentDevices: rpcOutcome.currentDevices ?? 1,
        );
      }
      if (rejectionCode == 'TRIAL_DEVICE_EXPIRED' ||
          rejectionCode == 'TRIAL_EXPIRED') {
        throw const AuthBackendRequiredException(
          'Masa trial akun ini sudah habis. Silakan hubungi admin untuk upgrade lisensi.',
        );
      }
      if (rejectionCode == 'EXPIRED' || rejectionCode == 'LICENSE_EXPIRED') {
        throw const AuthBackendRequiredException(
          'Masa berlaku lisensi sudah habis. Silakan hubungi admin untuk memperpanjang atau upgrade lisensi.',
        );
      }
      if (rejectionCode == 'INACTIVE' ||
          rejectionCode == 'REVOKED' ||
          rejectionCode == 'DISABLED') {
        throw const AuthBackendRequiredException(
          'Lisensi ini sudah dinonaktifkan. Silakan hubungi admin.',
        );
      }
      if (rejectionCode == 'PLATFORM_NOT_ALLOWED') {
        throw const AuthBackendRequiredException(
          'Platform perangkat ini tidak diizinkan oleh lisensi. Hubungi admin.',
        );
      }
      return false;
    } catch (e) {
      debugPrint('DEBUG: Error in activateLicense: $e');
      if (e is DeviceLockedException ||
          e is DeviceLimitReachedException ||
          e is AuthBackendRequiredException) {
        rethrow;
      }
      return false;
    }
  }

  static Future<List<LicenseDeviceInfo>> fetchReplaceableDevices({
    required String serial,
    required String password,
  }) async {
    final cleanSerial = _normalizeSerial(serial);
    final cleanPassword = password.trim();
    if (cleanSerial.isEmpty || cleanPassword.isEmpty) return [];

    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_public_list_license_devices',
        params: {
          'p_serial': cleanSerial,
          'p_password_hash': hashLicensePassword(cleanPassword),
        },
      ).timeout(_rpcTimeout);
      final payload = _asStringKeyedMap(response);
      if (payload == null || !_isTruthy(payload['ok'])) {
        throw const AuthBackendRequiredException(
          'Gagal membaca daftar perangkat aktif. Pastikan koneksi internet aktif.',
        );
      }

      final devices = payload['devices'];
      if (devices is! List) return [];
      return devices
          .whereType<Map>()
          .map(
            (item) => LicenseDeviceInfo.fromMap(
              item.map((key, value) => MapEntry(key.toString(), value)),
            ),
          )
          .where((device) => device.deviceId.trim().isNotEmpty)
          .toList();
    } catch (e) {
      if (e is AuthBackendRequiredException) rethrow;
      throw const AuthBackendRequiredException(
        'Gagal membaca daftar perangkat aktif. Pastikan koneksi internet aktif.',
      );
    }
  }

  static Future<bool> replaceDeviceAndActivate({
    required String serial,
    required String password,
    required String oldDeviceId,
  }) async {
    final cleanSerial = _normalizeSerial(serial);
    final cleanPassword = password.trim();
    final cleanOldDeviceId = oldDeviceId.trim();
    if (cleanSerial.isEmpty ||
        cleanPassword.isEmpty ||
        cleanOldDeviceId.isEmpty) {
      return false;
    }

    final newDeviceId = await getDeviceId();
    final platform = _currentPlatformLabel();

    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_replace_license_device',
        params: {
          'p_serial': cleanSerial,
          'p_password_hash': hashLicensePassword(cleanPassword),
          'p_old_device_id': cleanOldDeviceId,
          'p_new_device_id': newDeviceId,
          'p_platform': platform,
        },
      ).timeout(_rpcTimeout);
      final payload = _asStringKeyedMap(response);
      if (payload == null) {
        throw const AuthBackendRequiredException(
          'Gagal mengganti perangkat. Pastikan koneksi internet aktif.',
        );
      }
      if (!_isTruthy(payload['ok'])) {
        final code = payload['code']?.toString();
        if (code == 'DEVICE_REPLACE_COOLDOWN') {
          throw const DeviceReplacementCooldownException(
            'Perangkat baru saja diganti. Demi keamanan, pergantian berikutnya bisa dilakukan setelah 24 jam.',
          );
        }
        if (code == 'DEVICE_NOT_FOUND') {
          throw const AuthBackendRequiredException(
            'Perangkat lama sudah tidak aktif. Silakan coba login ulang.',
          );
        }
        if (code == 'PLATFORM_NOT_ALLOWED') {
          throw const AuthBackendRequiredException(
            'Platform perangkat ini tidak diizinkan oleh lisensi.',
          );
        }
        throw const AuthBackendRequiredException(
          'Gagal mengganti perangkat. Silakan coba lagi.',
        );
      }

      final record = _asStringKeyedMap(payload['license']);
      if (record == null) {
        throw const AuthBackendRequiredException(
          'Gagal membaca lisensi setelah perangkat diganti.',
        );
      }

      await _persistValidatedLicense(
        licenseId: record['id']?.toString(),
        serial: _normalizeSerial(record['serial']?.toString() ?? cleanSerial),
        serialHash: hashLicense(cleanSerial, cleanPassword, newDeviceId),
        deviceId: newDeviceId,
        isActive: 1,
        expiredAt: record['expired_at']?.toString(),
        canRemotePrint: _isTruthy(record['can_remote_print']) ? 1 : 0,
        isTrial: _isTruthy(record['is_trial']) ? 1 : 0,
        ldrPrintCount: (record['ldr_print_count'] as num?)?.toInt() ?? 0,
      );
      return true;
    } catch (e) {
      if (e is DeviceReplacementCooldownException ||
          e is AuthBackendRequiredException) {
        rethrow;
      }
      throw const AuthBackendRequiredException(
        'Gagal mengganti perangkat. Pastikan koneksi internet aktif.',
      );
    }
  }

  /// Mulai demo otomatis tanpa serial/password.
  static Future<bool> startDemoTrial() async {
    try {
      final deviceId = await getDeviceId();
      final platform = _currentPlatformLabel();
      final rpcOutcome = await _startDemoTrialViaRpc(
        deviceId: deviceId,
        platform: platform,
      );

      if (!rpcOutcome.available) {
        throw const AuthBackendRequiredException(
          'Layanan demo trial tidak dapat dijangkau. Pastikan perangkat terhubung ke internet dan coba lagi.',
        );
      }

      if (!rpcOutcome.isSuccess) {
        final rejectionCode = rpcOutcome.code?.trim().toUpperCase();
        final message = switch (rejectionCode) {
          'DEMO_EXPIRED' => 'Masa demo di perangkat ini sudah berakhir.',
          'DEMO_TRIAL_USED' =>
            'Demo gratis sudah pernah digunakan di perangkat ini.',
          'DEMO_REVOKED' => 'Akses demo di perangkat ini telah dinonaktifkan.',
          _ => 'Demo trial tidak dapat diaktifkan di perangkat ini.',
        };
        throw DemoTrialException(message);
      }

      final record = rpcOutcome.record!;
      final licenseId = record['id']?.toString();
      final fallbackId = deviceId.substring(0, math.min(8, deviceId.length));
      final demoSerial = _normalizeSerial(
        record['serial']?.toString() ?? 'DEMO-${licenseId ?? fallbackId}',
      );
      final demoExpiredAt = _cappedAutomaticDemoExpiredAt(
        record['expired_at']?.toString(),
        startedAt: _recordDemoStartedAt(record),
      );
      if (_isExpired(demoExpiredAt)) {
        throw const DemoTrialException(
          'Masa demo di perangkat ini sudah berakhir.',
        );
      }

      await _persistValidatedLicense(
        licenseId: licenseId,
        serial: demoSerial,
        serialHash: _hashDemoLicense(
          licenseId: licenseId,
          serial: demoSerial,
          deviceId: deviceId,
        ),
        deviceId: deviceId,
        isActive: 1,
        expiredAt: demoExpiredAt,
        canRemotePrint: _isTruthy(record['can_remote_print']) ? 1 : 0,
        isTrial: 1,
        ldrPrintCount: (record['ldr_print_count'] as num?)?.toInt() ?? 0,
      );
      return true;
    } on AuthBackendRequiredException {
      rethrow;
    } on DemoTrialException {
      rethrow;
    } catch (e) {
      debugPrint('DEBUG: Error in startDemoTrial: $e');
      throw const AuthBackendRequiredException(
        'Layanan demo trial tidak dapat dijangkau. Pastikan perangkat terhubung ke internet dan coba lagi.',
      );
    }
  }

  /// Cek validitas lisensi. Secara default, validasi server yang masih segar
  /// dipakai ulang supaya aplikasi tidak mengirim request berulang saat idle.
  static Future<bool> checkLicenseValid({bool forceRemote = false}) async {
    final current = await DBHelper.instance.getLicense();
    if (current == null) return false;

    final deviceId = await getDeviceId();
    if (!_isStoredLicenseLocallyConsistent(current, deviceId)) {
      await clearLocalLicense();
      return false;
    }

    if (!forceRemote && _isRemoteValidationFresh(current.lastValidatedAt)) {
      return true;
    }

    final refreshResult = await _revalidateStoredLicense(current, deviceId);
    // Jika backend tidak tersedia (offline), tetap anggap valid selama
    // data lokal konsisten. Hanya tolak jika server secara eksplisit
    // menyatakan lisensi tidak valid (expired/revoked).
    return refreshResult != _RevalidationStatus.invalid;
  }

  /// Login Admin Utama ke Supabase.
  static Future<bool> adminLogin(String username, String password) async {
    final cleanUser = username.trim();
    final cleanPassword = password.trim();
    if (cleanUser.isEmpty || cleanPassword.isEmpty) {
      clearAdminSession();
      return false;
    }
    final hashed = hashAdminPassword(cleanPassword);

    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_admin_login',
        params: {
          'p_username': cleanUser,
          'p_password_hash': hashed,
        },
      );
      final ok = _isTruthy(response);
      if (ok) {
        _storeAdminSession(username: cleanUser, passwordHash: hashed);
      } else {
        clearAdminSession();
      }
      return ok;
    } catch (_) {
      clearAdminSession();
      throw const AuthBackendRequiredException(
        'Gagal terhubung ke pusat data admin. Pastikan perangkat terhubung ke internet dan silakan coba lagi.',
      );
    }
  }

  static Future<void> changeAdminPassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    final username = _currentAdminUsername?.trim();
    final sessionPasswordHash = _currentAdminPasswordHash?.trim();
    final cleanCurrent = currentPassword.trim();
    final cleanNew = newPassword.trim();

    if (username == null ||
        username.isEmpty ||
        sessionPasswordHash == null ||
        sessionPasswordHash.isEmpty) {
      throw StateError('Sesi admin tidak aktif. Silakan login ulang.');
    }
    if (cleanCurrent.isEmpty) {
      throw const FormatException('Kata sandi lama wajib diisi.');
    }
    if (cleanNew.isEmpty) {
      throw const FormatException('Kata sandi baru wajib diisi.');
    }
    if (cleanNew.length < 10) {
      throw const FormatException(
        'Kata sandi baru minimal 10 karakter.',
      );
    }

    final oldHash = hashAdminPassword(cleanCurrent);
    if (!_secureEquals(oldHash, sessionPasswordHash)) {
      throw StateError('Kata sandi lama salah.');
    }

    final newHash = hashAdminPassword(cleanNew);
    if (_secureEquals(newHash, sessionPasswordHash)) {
      throw const FormatException(
        'Kata sandi baru harus berbeda dari kata sandi lama.',
      );
    }

    const backendUnavailableMessage =
        'Gagal memproses perubahan kata sandi. Pastikan perangkat terhubung ke internet dan silakan coba lagi.';

    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_admin_change_password',
        params: {
          'p_username': username,
          'p_old_password_hash': oldHash,
          'p_new_password_hash': newHash,
        },
      );

      if (!_isTruthy(response)) {
        throw const AuthBackendRequiredException(backendUnavailableMessage);
      }

      _storeAdminSession(username: username, passwordHash: newHash);
    } on PostgrestException catch (e) {
      if (e.code == '28000') {
        throw StateError('Kata sandi lama salah.');
      }
      if (e.code == '22023') {
        throw const FormatException('Kata sandi baru tidak valid.');
      }
      throw const AuthBackendRequiredException(backendUnavailableMessage);
    } on AuthBackendRequiredException {
      rethrow;
    } catch (_) {
      throw const AuthBackendRequiredException(backendUnavailableMessage);
    }
  }

  static Future<void> changeLicensePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    final license = await DBHelper.instance.getLicense();
    if (license == null) {
      throw StateError(
          'Lisensi tidak ditemukan. Silakan login lisesnsi ulang.');
    }

    if (license.isTrial == 1) {
      throw const FormatException(
        'Akun trial tidak dapat mengubah kata sandi.',
      );
    }

    final serial = _normalizeSerial(license.serial ?? '');
    if (serial.isEmpty) {
      throw StateError('Serial lisensi tidak valid.');
    }

    final cleanCurrent = currentPassword.trim();
    final cleanNew = newPassword.trim();

    if (cleanCurrent.isEmpty) {
      throw const FormatException('Kata sandi lama wajib diisi.');
    }
    if (cleanNew.isEmpty) {
      throw const FormatException('Kata sandi baru wajib diisi.');
    }
    if (cleanNew.length < 8) {
      throw const FormatException('Kata sandi baru minimal 8 karakter.');
    }

    final oldHash = hashLicensePassword(cleanCurrent);
    final newHash = hashLicensePassword(cleanNew);

    if (oldHash == newHash) {
      throw const FormatException('Kata sandi baru harus berbeda.');
    }

    const backendUnavailableMessage =
        'Layanan ubah kata sandi lisensi sedang tidak tersedia. Harap pastikan koneksi internet aktif.';

    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_license_change_password',
        params: {
          'p_serial': serial,
          'p_old_password_hash': oldHash,
          'p_new_password_hash': newHash,
        },
      );

      if (!_isTruthy(response)) {
        throw const AuthBackendRequiredException(backendUnavailableMessage);
      }

      // Perbarui jejak lokal agar hash serial konsisten dengan password terbaru.
      final deviceId = await getDeviceId();
      final newSerialHash = hashLicense(serial, cleanNew, deviceId);
      final updatedLicense = license.copyWith(
        serialHash: newSerialHash,
        lastValidatedAt: DateTime.now().toUtc().toIso8601String(),
        validationExpiresAt: null,
        signature: '',
      );
      await DBHelper.instance.insertLicense(updatedLicense);
    } on PostgrestException catch (e) {
      if (e.code == 'P0002') {
        throw StateError('Lisensi tidak ditemukan di server.');
      }
      if (e.code == '28000') {
        throw StateError('Kata sandi lama salah.');
      }
      throw const AuthBackendRequiredException(backendUnavailableMessage);
    } catch (_) {
      throw const AuthBackendRequiredException(backendUnavailableMessage);
    }
  }

  static Future<_RevalidationStatus> _revalidateStoredLicense(
    License current,
    String deviceId,
  ) async {
    final lookupId = current.licenseId?.trim();
    final lookupSerial = _normalizeSerial(current.serial ?? '');
    if ((lookupId == null || lookupId.isEmpty) && lookupSerial.isEmpty) {
      await clearLocalLicense();
      return _RevalidationStatus.invalid;
    }

    try {
      if (_isAutomaticDemoLicense(current)) {
        final demoOutcome = await _startDemoTrialViaRpc(
          deviceId: deviceId,
          platform: _currentPlatformLabel(),
        );
        if (demoOutcome.available) {
          if (!demoOutcome.isSuccess) {
            await clearLocalLicense();
            return _RevalidationStatus.invalid;
          }

          final record = demoOutcome.record!;
          await _persistValidatedLicense(
            licenseId: record['id']?.toString() ?? lookupId,
            serial:
                _normalizeSerial(record['serial']?.toString() ?? lookupSerial),
            serialHash: current.serialHash,
            deviceId: deviceId,
            isActive: 1,
            expiredAt: _cappedAutomaticDemoExpiredAt(
              record['expired_at']?.toString(),
              currentExpiredAt: current.expiredAt,
              startedAt: _recordDemoStartedAt(record),
            ),
            canRemotePrint: _isTruthy(record['can_remote_print']) ? 1 : 0,
            isTrial: 1,
            ldrPrintCount: (record['ldr_print_count'] as num?)?.toInt() ?? 0,
          );
          return _RevalidationStatus.valid;
        }
        return _RevalidationStatus.unavailable;
      }

      final rpcOutcome = await _revalidateLicenseViaRpc(
        licenseId: lookupId,
        serial: lookupSerial,
        deviceId: deviceId,
      );
      if (rpcOutcome.available) {
        if (!rpcOutcome.isSuccess) {
          await clearLocalLicense();
          return _RevalidationStatus.invalid;
        }

        final record = rpcOutcome.record!;
        await _persistValidatedLicense(
          licenseId: record['id']?.toString() ?? lookupId,
          serial: lookupSerial.isNotEmpty
              ? lookupSerial
              : _normalizeSerial(record['serial']?.toString() ?? ''),
          serialHash: current.serialHash,
          deviceId: deviceId,
          isActive: 1,
          expiredAt: record['expired_at']?.toString(),
          canRemotePrint: record['can_remote_print'] == true ? 1 : 0,
          isTrial: record['is_trial'] == true ? 1 : 0,
          ldrPrintCount: (record['ldr_print_count'] as num?)?.toInt() ?? 0,
        );
        return _RevalidationStatus.valid;
      }
      return _RevalidationStatus.unavailable;
    } catch (_) {
      return _RevalidationStatus.unavailable;
    }
  }

  static bool _isAutomaticDemoLicense(License current) {
    final serial = _normalizeSerial(current.serial ?? '');
    return current.isTrial == 1 && serial.startsWith('DEMO-');
  }

  static String _cappedAutomaticDemoExpiredAt(
    String? serverExpiredAt, {
    String? currentExpiredAt,
    String? startedAt,
  }) {
    final now = DateTime.now().toUtc();
    final started = _parseUtc(startedAt);
    final candidates = <DateTime>[
      (started ?? now).add(_automaticDemoDuration),
    ];
    final serverExpiry = _parseUtc(serverExpiredAt);
    if (serverExpiry != null) candidates.add(serverExpiry);
    final currentExpiry = _parseUtc(currentExpiredAt);
    if (currentExpiry != null) candidates.add(currentExpiry);
    candidates.sort();
    return candidates.first.toIso8601String();
  }

  static String? _recordDemoStartedAt(Map<String, dynamic> record) {
    const keys = [
      'trial_started_at',
      'started_at',
      'activated_at',
      'created_at',
      'createdAt',
    ];
    for (final key in keys) {
      final value = record[key]?.toString();
      if (value != null && value.trim().isNotEmpty) return value;
    }
    return null;
  }

  static Future<void> _persistValidatedLicense({
    required String? licenseId,
    required String serial,
    required String serialHash,
    required String deviceId,
    required int isActive,
    required String? expiredAt,
    int canRemotePrint = 0,
    int isTrial = 0,
    int ldrPrintCount = 0,
  }) async {
    final now = DateTime.now().toUtc();
    final baseLicense = License(
      licenseId: licenseId,
      serial: _normalizeSerial(serial),
      serialHash: serialHash,
      deviceId: deviceId,
      isActive: isActive,
      expiredAt: expiredAt,
      lastValidatedAt: now.toIso8601String(),
      validationExpiresAt: null,
      signature: '',
      canRemotePrint: canRemotePrint,
      isTrial: isTrial,
      ldrPrintCount: ldrPrintCount,
    );
    await DBHelper.instance.insertLicense(baseLicense);
  }

  static bool isLicenseLocallyValid(License current, String deviceId) {
    return _isStoredLicenseLocallyConsistent(current, deviceId);
  }

  static bool _isStoredLicenseLocallyConsistent(
    License current,
    String deviceId,
  ) {
    if (current.isActive != 1) return false;
    if (current.deviceId != deviceId) return false;
    if (_isExpired(current.expiredAt)) return false;
    if ((current.licenseId?.trim().isEmpty ?? true) &&
        (current.serial?.trim().isEmpty ?? true)) {
      return false;
    }
    if (current.serialHash.trim().isEmpty) return false;
    return true;
  }

  static String _normalizeSerial(String value) {
    return value.trim().toUpperCase();
  }

  static void _storeAdminSession({
    required String username,
    required String passwordHash,
  }) {
    _currentAdminUsername = username.trim();
    _currentAdminPasswordHash = passwordHash.trim();
  }

  static String _currentPlatformLabel() {
    if (Platform.isAndroid || Platform.isIOS) return 'android';
    return 'desktop';
  }

  static Future<_RpcLicenseLookupOutcome> _activateLicenseViaRpc({
    required String serial,
    required String passwordHash,
    required String deviceId,
    String platform = 'unknown',
  }) async {
    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_activate_license',
        params: {
          'p_serial': serial,
          'p_password_hash': passwordHash,
          'p_device_id': deviceId,
          'p_force_device': false,
          'p_platform': platform,
        },
      );
      return _parseRpcLicenseOutcome(response);
    } catch (e) {
      debugPrint('DEBUG: Supabase RPC Error (activate): $e');
      return const _RpcLicenseLookupOutcome.unavailable();
    }
  }

  static Future<_RpcLicenseLookupOutcome> _startDemoTrialViaRpc({
    required String deviceId,
    String platform = 'unknown',
  }) async {
    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_start_demo_trial',
        params: {
          'p_device_id': deviceId,
          'p_platform': platform,
        },
      );
      return _parseRpcLicenseOutcome(response);
    } catch (e) {
      debugPrint('DEBUG: Supabase RPC Error (demo trial): $e');
      return const _RpcLicenseLookupOutcome.unavailable();
    }
  }

  static Future<_RpcLicenseLookupOutcome> _revalidateLicenseViaRpc({
    required String? licenseId,
    required String serial,
    required String deviceId,
  }) async {
    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_revalidate_license',
        params: {
          'p_license_id':
              (licenseId?.trim().isEmpty ?? true) ? null : licenseId,
          'p_serial': serial.isEmpty ? null : serial,
          'p_device_id': deviceId,
        },
      );
      return _parseRpcLicenseOutcome(response);
    } catch (_) {
      return const _RpcLicenseLookupOutcome.unavailable();
    }
  }

  static _RpcLicenseLookupOutcome _parseRpcLicenseOutcome(dynamic response) {
    final payload = _asStringKeyedMap(response);
    if (payload == null) {
      return const _RpcLicenseLookupOutcome.unavailable();
    }

    final record = _asStringKeyedMap(payload['license']);
    if (_isTruthy(payload['ok']) && record != null) {
      return _RpcLicenseLookupOutcome.success(record);
    }

    return _RpcLicenseLookupOutcome.invalid(
      code: payload['code']?.toString(),
      deviceId: payload['device_id']?.toString(),
      maxDevices: (payload['max_devices'] as num?)?.toInt(),
      currentDevices: (payload['current_devices'] as num?)?.toInt(),
    );
  }

  static Map<String, dynamic>? _asStringKeyedMap(dynamic value) {
    if (value is Map) {
      return value.map(
        (key, val) => MapEntry(key.toString(), val),
      );
    }
    return null;
  }

  static String? _normalizeStoredDeviceId(String? value) {
    if (value == null) return null;
    final normalized = value.trim();
    if (normalized.isEmpty || normalized == 'null') return null;
    return normalized;
  }

  static DateTime? _parseUtc(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    return DateTime.tryParse(value)?.toUtc();
  }

  static bool _isExpired(String? value) {
    final expiry = _parseUtc(value);
    return expiry != null && expiry.isBefore(DateTime.now().toUtc());
  }

  static bool _isRemoteValidationFresh(String? value) {
    final validatedAt = _parseUtc(value);
    if (validatedAt == null) return false;
    final age = DateTime.now().toUtc().difference(validatedAt);
    return !age.isNegative && age < _remoteValidationFreshFor;
  }

  static bool _secureEquals(String left, String right) {
    final leftBytes = utf8.encode(left);
    final rightBytes = utf8.encode(right);
    final maxLength = math.max(leftBytes.length, rightBytes.length);

    var diff = leftBytes.length ^ rightBytes.length;
    for (var i = 0; i < maxLength; i++) {
      final leftByte = i < leftBytes.length ? leftBytes[i] : 0;
      final rightByte = i < rightBytes.length ? rightBytes[i] : 0;
      diff |= leftByte ^ rightByte;
    }
    return diff == 0;
  }

  static bool _isTruthy(dynamic value) {
    return value == true || value == 1 || value == '1' || value == 'true';
  }

  //
  // DEVICE TRANSFER
  //

  /// HP2: Minta transfer device  mengembalikan request info atau null.
  static Future<Map<String, dynamic>?> requestDeviceTransfer({
    required String serial,
    required String password,
  }) async {
    final cleanSerial = _normalizeSerial(serial);
    final passwordHash = hashLicensePassword(password.trim());
    final deviceId = await getDeviceId();
    final platform = _currentPlatformLabel();

    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_request_device_transfer',
        params: {
          'p_serial': cleanSerial,
          'p_password_hash': passwordHash,
          'p_device_id': deviceId,
          'p_platform': platform,
        },
      );
      final payload = _asStringKeyedMap(response);
      if (payload != null && _isTruthy(payload['ok'])) return payload;
      return null;
    } catch (_) {
      return null;
    }
  }

  /// HP2: Polling status transfer request.
  static Future<Map<String, dynamic>?> checkTransferStatus(
    String requestId,
  ) async {
    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_check_transfer_status',
        params: {'p_request_id': requestId},
      );
      final payload = _asStringKeyedMap(response);
      if (payload != null && _isTruthy(payload['ok'])) return payload;
      return null;
    } catch (_) {
      return null;
    }
  }

  /// HP1: Setujui atau tolak transfer request.
  static Future<bool> respondDeviceTransfer({
    required String requestId,
    required String licenseId,
    required bool approve,
  }) async {
    final deviceId = await getDeviceId();
    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_respond_device_transfer',
        params: {
          'p_request_id': requestId,
          'p_license_id': licenseId,
          'p_approver_device_id': deviceId,
          'p_approve': approve,
        },
      );
      final payload = _asStringKeyedMap(response);
      return payload != null && _isTruthy(payload['ok']);
    } catch (_) {
      return false;
    }
  }

  /// HP1: Cek apakah ada pending transfer untuk lisensi ini.
  static Future<Map<String, dynamic>?> checkPendingTransfer({
    required String licenseId,
  }) async {
    final deviceId = await getDeviceId();
    try {
      final response = await Supabase.instance.client.rpc(
        'rpc_check_pending_transfer',
        params: {
          'p_license_id': licenseId,
          'p_device_id': deviceId,
        },
      );
      final payload = _asStringKeyedMap(response);
      if (payload != null &&
          _isTruthy(payload['ok']) &&
          _isTruthy(payload['has_pending'])) {
        return payload;
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  /// Membebaskan kuota perangkat saat pengguna log out dari aplikasi.
  static Future<void> unregisterDevice(String licenseId) async {
    final deviceId = await getDeviceId();
    try {
      await Supabase.instance.client.rpc(
        'rpc_user_logout_device',
        params: {
          'p_license_id': licenseId,
          'p_device_id': deviceId,
        },
      );
    } catch (_) {
      // Abaikan jika gagal (misal tidak ada internet),
      // namun lisensi lokal tetap dihapus.
    }
  }
}

