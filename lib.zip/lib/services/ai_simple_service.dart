import 'dart:math';

import '../database/db_helper.dart';
import '../models/db_models.dart';

class AiBusinessSnapshot {
  final DateTime generatedAt;
  final int healthScore;
  final String statusLabel;
  final AiLearningProfile learningProfile;
  final String executiveSummary;
  final AiSalesForecast salesForecast;
  final List<AiRestockRecommendation> restockRecommendations;
  final List<AiCrossSellRecommendation> crossSellRecommendations;
  final List<AiBusyHour> busyHours;
  final List<AiAnomalyAlert> anomalyAlerts;
  final List<AiPriceSuggestion> priceSuggestions;
  final List<AiTopProduct> topProducts;
  final Map<String, int> paymentMethods;
  final Map<String, dynamic> inventoryAnalysis;
  final List<Map<String, dynamic>> topCustomers;
  final List<Map<String, dynamic>> supplierDebts;
  final AiservisOperations servisOperations;
  final List<AiQuickAnswer> quickAnswers;

  const AiBusinessSnapshot({
    required this.generatedAt,
    required this.healthScore,
    required this.statusLabel,
    required this.learningProfile,
    required this.executiveSummary,
    required this.salesForecast,
    required this.restockRecommendations,
    required this.crossSellRecommendations,
    required this.busyHours,
    required this.anomalyAlerts,
    required this.priceSuggestions,
    required this.topProducts,
    required this.paymentMethods,
    required this.inventoryAnalysis,
    required this.topCustomers,
    required this.supplierDebts,
    required this.servisOperations,
    required this.quickAnswers,
  });
}

class AiLearningProfile {
  final int activeSalesDays;
  final int totalTransactions;
  final int totalProducts;
  final int inventoryProducts;
  final int dataMaturity;
  final String level;
  final String learningSummary;
  final List<String> strongSignals;
  final List<String> missingSignals;

  const AiLearningProfile({
    required this.activeSalesDays,
    required this.totalTransactions,
    required this.totalProducts,
    required this.inventoryProducts,
    required this.dataMaturity,
    required this.level,
    required this.learningSummary,
    required this.strongSignals,
    required this.missingSignals,
  });
}

class AiSalesForecast {
  final int todaySales;
  final int yesterdaySales;
  final int average7Days;
  final int average14Days;
  final int tomorrowLow;
  final int tomorrowHigh;
  final int next7DaysForecast;
  final double trendPercent;
  final int confidence;
  final List<AiDailySalesPoint> dailyPoints;

  const AiSalesForecast({
    required this.todaySales,
    required this.yesterdaySales,
    required this.average7Days,
    required this.average14Days,
    required this.tomorrowLow,
    required this.tomorrowHigh,
    required this.next7DaysForecast,
    required this.trendPercent,
    required this.confidence,
    required this.dailyPoints,
  });
}

class AiDailySalesPoint {
  final DateTime date;
  final int sales;
  final int transactionCount;

  const AiDailySalesPoint({
    required this.date,
    required this.sales,
    required this.transactionCount,
  });
}

class AiRestockRecommendation {
  final Product product;
  final double averageDailySales;
  final int daysLeft;
  final int recommendedQty;
  final String priority;
  final String reason;

  const AiRestockRecommendation({
    required this.product,
    required this.averageDailySales,
    required this.daysLeft,
    required this.recommendedQty,
    required this.priority,
    required this.reason,
  });
}

class AiCrossSellRecommendation {
  final String productA;
  final String productB;
  final int togetherCount;
  final int confidence;
  final String suggestion;

  const AiCrossSellRecommendation({
    required this.productA,
    required this.productB,
    required this.togetherCount,
    required this.confidence,
    required this.suggestion,
  });
}

class AiBusyHour {
  final int hour;
  final int transactionCount;
  final int totalSales;
  final int intensity;
  final String label;

  const AiBusyHour({
    required this.hour,
    required this.transactionCount,
    required this.totalSales,
    required this.intensity,
    required this.label,
  });
}

class AiAnomalyAlert {
  final String severity;
  final String title;
  final String message;
  final String action;

  const AiAnomalyAlert({
    required this.severity,
    required this.title,
    required this.message,
    required this.action,
  });
}

class AiPriceSuggestion {
  final Product product;
  final int currentPrice;
  final int suggestedPrice;
  final double currentMarginPercent;
  final String reason;

  const AiPriceSuggestion({
    required this.product,
    required this.currentPrice,
    required this.suggestedPrice,
    required this.currentMarginPercent,
    required this.reason,
  });
}

class AiTopProduct {
  final int productId;
  final String productName;
  final int totalQty;
  final int totalSales;

  const AiTopProduct({
    required this.productId,
    required this.productName,
    required this.totalQty,
    required this.totalSales,
  });
}

class AiservisOrderRisk {
  final int transactionId;
  final String customerName;
  final String status;
  final String orderType;
  final DateTime pickupSchedule;
  final int minutesDelta;
  final int grandTotal;

  const AiservisOrderRisk({
    required this.transactionId,
    required this.customerName,
    required this.status,
    required this.orderType,
    required this.pickupSchedule,
    required this.minutesDelta,
    required this.grandTotal,
  });
}

class AiservisOperations {
  final int activeOrders;
  final int readyForPickup;
  final int overdueOrders;
  final int dueSoonOrders;
  final int expressActiveOrders;
  final int unpaidActiveOrders;
  final int completedCreatedToday;
  final int averagePlannedHours;
  final double completionRatio;
  final Map<String, int> statusCounts;
  final Map<String, int> serviceTypes;
  final Map<String, int> kelengkapanCounts;
  final List<AiservisOrderRisk> overdueDetails;
  final List<AiservisOrderRisk> dueSoonDetails;

  const AiservisOperations({
    required this.activeOrders,
    required this.readyForPickup,
    required this.overdueOrders,
    required this.dueSoonOrders,
    required this.expressActiveOrders,
    required this.unpaidActiveOrders,
    required this.completedCreatedToday,
    required this.averagePlannedHours,
    required this.completionRatio,
    required this.statusCounts,
    required this.serviceTypes,
    required this.kelengkapanCounts,
    required this.overdueDetails,
    required this.dueSoonDetails,
  });

  String get dominantStatus {
    if (statusCounts.isEmpty) return '-';
    final entries = statusCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return entries.first.key;
  }

  String get dominantServiceType {
    if (serviceTypes.isEmpty) return '-';
    final entries = serviceTypes.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return entries.first.key;
  }

  String get favoriteKelengkapan {
    if (kelengkapanCounts.isEmpty) return '-';
    final entries = kelengkapanCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return entries.first.key;
  }
}

class AiQuickAnswer {
  final String question;
  final String answer;

  const AiQuickAnswer({
    required this.question,
    required this.answer,
  });
}

class AISimpleService {
  final DBHelper db = DBHelper.instance;

  Future<AiBusinessSnapshot> getBusinessSnapshot() async {
    final results = await Future.wait<dynamic>([
      getSalesForecast(),
      getRestockRecommendations(),
      getCrossSellRecommendations(),
      getBusyHourAnalysis(),
      getAnomalyAlerts(),
      getPriceSuggestions(),
      getTopSellingProducts(),
      _getLearningProfile(),
      db.getSalesByPaymentMethod(DateTime.now().year, DateTime.now().month),
      db.getInventoryAnalysis(),
      db.getTopCustomers(limit: 5),
      db.getSupplierDebtSummary(),
      getservisOperations(),
    ]);

    final forecast = results[0] as AiSalesForecast;
    final restocks = results[1] as List<AiRestockRecommendation>;
    final bundles = results[2] as List<AiCrossSellRecommendation>;
    final busyHours = results[3] as List<AiBusyHour>;
    final anomalies = results[4] as List<AiAnomalyAlert>;
    final prices = results[5] as List<AiPriceSuggestion>;
    final topProducts = results[6] as List<AiTopProduct>;
    final learningProfile = results[7] as AiLearningProfile;
    final paymentMethods = results[8] as Map<String, int>;
    final inventoryAnalysis = results[9] as Map<String, dynamic>;
    final topCustomers = results[10] as List<Map<String, dynamic>>;
    final supplierDebts = results[11] as List<Map<String, dynamic>>;
    final servisOps = results[12] as AiservisOperations;

    final score = _calculateHealthScore(
      forecast: forecast,
      restocks: restocks,
      anomalies: anomalies,
      prices: prices,
      servisOps: servisOps,
    );
    final summary = _buildExecutiveSummary(
      forecast: forecast,
      restocks: restocks,
      bundles: bundles,
      busyHours: busyHours,
      anomalies: anomalies,
      prices: prices,
      servisOps: servisOps,
    );

    return AiBusinessSnapshot(
      generatedAt: DateTime.now(),
      healthScore: score,
      statusLabel: _scoreLabel(score),
      learningProfile: learningProfile,
      executiveSummary: summary,
      salesForecast: forecast,
      restockRecommendations: restocks,
      crossSellRecommendations: bundles,
      busyHours: busyHours,
      anomalyAlerts: anomalies,
      priceSuggestions: prices,
      topProducts: topProducts,
      paymentMethods: paymentMethods,
      inventoryAnalysis: inventoryAnalysis,
      topCustomers: topCustomers,
      supplierDebts: supplierDebts,
      servisOperations: servisOps,
      quickAnswers: _buildQuickAnswers(
        forecast: forecast,
        restocks: restocks,
        bundles: bundles,
        busyHours: busyHours,
        anomalies: anomalies,
        servisOps: servisOps,
      ),
    );
  }

  Future<AiSalesForecast> getSalesForecast() async {
    final database = await db.database;
    final today = _startOfDay(DateTime.now());
    final start = today.subtract(const Duration(days: 34));
    final rows = await database.rawQuery('''
      SELECT DATE(created_at) as date,
             COALESCE(SUM(grand_total), 0) as sales,
             COUNT(*) as count
      FROM transactions
      WHERE is_deleted = 0 AND created_at >= ? AND created_at < ?
      GROUP BY DATE(created_at)
      ORDER BY date ASC
    ''', [
      start.toIso8601String(),
      today.add(const Duration(days: 1)).toIso8601String()
    ]);

    final byDate = <String, AiDailySalesPoint>{};
    for (final row in rows) {
      final dateText = row['date']?.toString();
      if (dateText == null || dateText.isEmpty) continue;
      final date = DateTime.tryParse(dateText);
      if (date == null) continue;
      byDate[_dateKey(date)] = AiDailySalesPoint(
        date: date,
        sales: _asInt(row['sales']),
        transactionCount: _asInt(row['count']),
      );
    }

    final points = <AiDailySalesPoint>[];
    for (int i = 34; i >= 0; i--) {
      final date = today.subtract(Duration(days: i));
      points.add(byDate[_dateKey(date)] ??
          AiDailySalesPoint(date: date, sales: 0, transactionCount: 0));
    }

    final todaySales = points.last.sales;
    final yesterdaySales =
        points.length > 1 ? points[points.length - 2].sales : 0;
    final last7 = points.skip(max(0, points.length - 7)).toList();
    final previous7 = points.length >= 14
        ? points.sublist(points.length - 14, points.length - 7)
        : <AiDailySalesPoint>[];
    final last14 = points.skip(max(0, points.length - 14)).toList();

    final avg7 = _averageSales(last7);
    final avg14 = _averageSales(last14);
    final prevAvg7 = _averageSales(previous7);
    final trend = prevAvg7 == 0 ? 0.0 : ((avg7 - prevAvg7) / prevAvg7) * 100;
    final weekdayFactor =
        _weekdayFactor(points, today.add(const Duration(days: 1)).weekday);
    final base = avg7 > 0 ? avg7 : avg14;
    final tomorrow = (base * weekdayFactor).round();
    final confidence = _forecastConfidence(points);

    return AiSalesForecast(
      todaySales: todaySales,
      yesterdaySales: yesterdaySales,
      average7Days: avg7.round(),
      average14Days: avg14.round(),
      tomorrowLow: (tomorrow * 0.85).round(),
      tomorrowHigh: (tomorrow * 1.15).round(),
      next7DaysForecast: (max(avg7, avg14) * 7).round(),
      trendPercent: trend,
      confidence: confidence,
      dailyPoints: points,
    );
  }

  Future<List<AiRestockRecommendation>> getRestockRecommendations() async {
    final products = await db.getAllProducts();
    final salesMap = await _productSalesMap(days: 30);
    final recommendations = <AiRestockRecommendation>[];

    for (final product in products) {
      if (!product.tracksInventory) continue;
      final soldQty = salesMap[product.id] ?? 0;
      final avgDaily = soldQty / 30.0;
      final daysLeft = product.stock <= 0
          ? 0
          : avgDaily <= 0
              ? 999
              : (product.stock / avgDaily).ceil();

      final isUrgent = daysLeft <= 3 || product.stock <= product.minStock;
      final isWatch = daysLeft <= 7 || product.stock <= product.minStock + 2;
      if (!isUrgent && !isWatch) continue;

      final targetDays = daysLeft <= 3 ? 14 : 10;
      final targetStock = max(product.minStock, (avgDaily * targetDays).ceil());
      final recommendedQty = max(product.minStock, targetStock - product.stock);
      final priority = daysLeft <= 3 || product.stock <= 0
          ? 'urgent'
          : daysLeft <= 7
              ? 'watch'
              : 'low';

      recommendations.add(AiRestockRecommendation(
        product: product,
        averageDailySales: avgDaily,
        daysLeft: daysLeft,
        recommendedQty: recommendedQty,
        priority: priority,
        reason: daysLeft == 999
            ? 'Stok sudah mendekati minimum, tetapi penjualan 30 hari terakhir masih rendah.'
            : 'Rata-rata terjual ${avgDaily.toStringAsFixed(1)} ${product.unit}/hari. Perlu stok aman untuk $targetDays hari.',
      ));
    }

    recommendations.sort((a, b) {
      final priorityCompare =
          _priorityRank(a.priority).compareTo(_priorityRank(b.priority));
      if (priorityCompare != 0) return priorityCompare;
      return a.daysLeft.compareTo(b.daysLeft);
    });
    return recommendations.take(12).toList();
  }

  Future<List<AiCrossSellRecommendation>> getCrossSellRecommendations() async {
    final database = await db.database;
    final since =
        DateTime.now().subtract(const Duration(days: 60)).toIso8601String();
    final rows = await database.rawQuery('''
      SELECT ti.transaction_id, ti.product_name
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      WHERE t.is_deleted = 0 AND t.created_at >= ?
      ORDER BY ti.transaction_id ASC
    ''', [since]);

    final baskets = <int, Set<String>>{};
    for (final row in rows) {
      final transactionId = _asInt(row['transaction_id']);
      final name = (row['product_name'] ?? '').toString().trim();
      if (transactionId <= 0 || name.isEmpty) continue;
      baskets.putIfAbsent(transactionId, () => <String>{}).add(name);
    }

    final pairCount = <String, int>{};
    final productCount = <String, int>{};
    for (final basket in baskets.values) {
      final names = basket.toList()..sort();
      for (final name in names) {
        productCount[name] = (productCount[name] ?? 0) + 1;
      }
      for (int i = 0; i < names.length; i++) {
        for (int j = i + 1; j < names.length; j++) {
          final key = '${names[i]}|||${names[j]}';
          pairCount[key] = (pairCount[key] ?? 0) + 1;
        }
      }
    }

    final result = <AiCrossSellRecommendation>[];
    for (final entry in pairCount.entries) {
      if (entry.value < 2) continue;
      final parts = entry.key.split('|||');
      final minBase =
          max(1, min(productCount[parts[0]] ?? 1, productCount[parts[1]] ?? 1));
      final confidence = ((entry.value / minBase) * 100).clamp(1, 99).round();
      result.add(AiCrossSellRecommendation(
        productA: parts[0],
        productB: parts[1],
        togetherCount: entry.value,
        confidence: confidence,
        suggestion:
            'Tawarkan ${parts[1]} saat pelanggan membeli ${parts[0]}, atau jadikan paket hemat.',
      ));
    }

    result.sort((a, b) {
      final countCompare = b.togetherCount.compareTo(a.togetherCount);
      if (countCompare != 0) return countCompare;
      return b.confidence.compareTo(a.confidence);
    });
    return result.take(10).toList();
  }

  Future<List<AiBusyHour>> getBusyHourAnalysis() async {
    final database = await db.database;
    final since =
        DateTime.now().subtract(const Duration(days: 30)).toIso8601String();
    final rows = await database.rawQuery('''
      SELECT CAST(strftime('%H', created_at) AS INTEGER) as hour,
             COUNT(*) as count,
             COALESCE(SUM(grand_total), 0) as sales
      FROM transactions
      WHERE is_deleted = 0 AND created_at >= ?
      GROUP BY hour
      ORDER BY count DESC, sales DESC
    ''', [since]);

    final maxCount =
        rows.isEmpty ? 1 : rows.map((r) => _asInt(r['count'])).reduce(max);
    return rows.take(8).map((row) {
      final hour = _asInt(row['hour']);
      final count = _asInt(row['count']);
      final intensity = ((count / maxCount) * 100).clamp(5, 100).round();
      return AiBusyHour(
        hour: hour,
        transactionCount: count,
        totalSales: _asInt(row['sales']),
        intensity: intensity,
        label:
            '${hour.toString().padLeft(2, '0')}:00-${((hour + 1) % 24).toString().padLeft(2, '0')}:00',
      );
    }).toList();
  }

  Future<AiservisOperations> getservisOperations() async {
    final database = await db.database;
    final now = DateTime.now();
    final today = _startOfDay(now);
    final since = today.subtract(const Duration(days: 90));
    final rows = await database.query(
      'transactions',
      where:
          "is_deleted = 0 AND (created_at >= ? OR COALESCE(servis_status, '') != 'Selesai')",
      whereArgs: [since.toIso8601String()],
      orderBy: 'created_at DESC',
    );

    final statusCounts = <String, int>{};
    final serviceTypes = <String, int>{};
    final kelengkapanCounts = <String, int>{};
    final overdueDetails = <AiservisOrderRisk>[];
    final dueSoonDetails = <AiservisOrderRisk>[];
    final plannedHours = <int>[];

    var activeOrders = 0;
    var readyForPickup = 0;
    var overdueOrders = 0;
    var dueSoonOrders = 0;
    var expressActiveOrders = 0;
    var unpaidActiveOrders = 0;
    var completedCreatedToday = 0;
    var finishedInWindow = 0;
    var totalInWindow = 0;

    for (final row in rows) {
      final status = _cleanText(row['servis_status'], fallback: 'Diterima');
      final orderType = _cleanText(row['order_type'], fallback: 'Regular');
      final kelengkapan = _cleanText(row['kelengkapan'], fallback: '');
      final createdAt = DateTime.tryParse(row['created_at']?.toString() ?? '');
      final pickupSchedule =
          DateTime.tryParse(row['pickup_schedule']?.toString() ?? '');
      final amountPaid = _asInt(row['amount_paid']);
      final grandTotal = _asInt(row['grand_total']);

      totalInWindow++;
      statusCounts[status] = (statusCounts[status] ?? 0) + 1;
      serviceTypes[orderType] = (serviceTypes[orderType] ?? 0) + 1;
      if (kelengkapan.isNotEmpty) {
        kelengkapanCounts[kelengkapan] = (kelengkapanCounts[kelengkapan] ?? 0) + 1;
      }
      if (status.toLowerCase() == 'selesai') {
        finishedInWindow++;
        if (createdAt != null && _isSameDay(createdAt, today)) {
          completedCreatedToday++;
        }
      }
      if (createdAt != null && pickupSchedule != null) {
        final hours = pickupSchedule.difference(createdAt).inHours;
        if (hours > 0 && hours <= 24 * 14) plannedHours.add(hours);
      }

      final isFinished = status.toLowerCase() == 'selesai';
      if (isFinished) continue;

      activeOrders++;
      if (status.toLowerCase() == 'siap ambil' ||
          status.toLowerCase() == 'siap') {
        readyForPickup++;
      }
      if (orderType.toLowerCase().contains('express') ||
          orderType.toLowerCase().contains('ekspres')) {
        expressActiveOrders++;
      }
      if (amountPaid < grandTotal) {
        unpaidActiveOrders++;
      }
      if (pickupSchedule == null) continue;

      final minutesDelta = now.difference(pickupSchedule).inMinutes;
      final risk = AiservisOrderRisk(
        transactionId: _asInt(row['id']),
        customerName: _cleanText(row['customer_name'], fallback: 'Pelanggan'),
        status: status,
        orderType: orderType,
        pickupSchedule: pickupSchedule,
        minutesDelta: minutesDelta,
        grandTotal: grandTotal,
      );

      if (pickupSchedule.isBefore(now)) {
        overdueOrders++;
        overdueDetails.add(risk);
      } else if (pickupSchedule.difference(now).inHours <= 4) {
        dueSoonOrders++;
        dueSoonDetails.add(risk);
      }
    }

    overdueDetails.sort((a, b) => b.minutesDelta.compareTo(a.minutesDelta));
    dueSoonDetails.sort((a, b) => a.pickupSchedule.compareTo(b.pickupSchedule));

    final avgHours = plannedHours.isEmpty
        ? 0
        : (plannedHours.fold<int>(0, (sum, value) => sum + value) /
                plannedHours.length)
            .round();

    return AiservisOperations(
      activeOrders: activeOrders,
      readyForPickup: readyForPickup,
      overdueOrders: overdueOrders,
      dueSoonOrders: dueSoonOrders,
      expressActiveOrders: expressActiveOrders,
      unpaidActiveOrders: unpaidActiveOrders,
      completedCreatedToday: completedCreatedToday,
      averagePlannedHours: avgHours,
      completionRatio:
          totalInWindow == 0 ? 0 : finishedInWindow / totalInWindow,
      statusCounts: statusCounts,
      serviceTypes: serviceTypes,
      kelengkapanCounts: kelengkapanCounts,
      overdueDetails: overdueDetails.take(8).toList(),
      dueSoonDetails: dueSoonDetails.take(8).toList(),
    );
  }

  Future<List<AiAnomalyAlert>> getAnomalyAlerts() async {
    final alerts = <AiAnomalyAlert>[];
    final forecast = await getSalesForecast();
    final products = await db.getAllProducts();
    final servisOps = await getservisOperations();

    if (forecast.average7Days > 0 &&
        forecast.todaySales > 0 &&
        forecast.todaySales < forecast.average7Days * 0.65) {
      alerts.add(AiAnomalyAlert(
        severity: 'warning',
        title: 'Omzet hari ini lebih rendah',
        message:
            'Omzet hari ini sekitar ${_percentOf(forecast.todaySales, forecast.average7Days)}% dari rata-rata 7 hari.',
        action:
            'Cek layanan terlaris, stok bahan kosong, dan jam ramai yang belum tercapai.',
      ));
    }

    if (servisOps.overdueOrders > 0) {
      final first = servisOps.overdueDetails.isNotEmpty
          ? servisOps.overdueDetails.first
          : null;
      alerts.add(AiAnomalyAlert(
        severity: servisOps.overdueOrders >= 3 ? 'danger' : 'warning',
        title: 'Order servis melewati estimasi',
        message: first == null
            ? '${servisOps.overdueOrders} order belum selesai atau belum diambil melewati jadwal.'
            : '${servisOps.overdueOrders} order melewati estimasi. Prioritas: ${first.customerName}, status ${first.status}.',
        action:
            'Cek rak/workshop, hubungi pelanggan bila sudah siap, dan update status agar daftar kerja bersih.',
      ));
    }

    if (servisOps.dueSoonOrders > 0) {
      alerts.add(AiAnomalyAlert(
        severity: 'warning',
        title: 'Estimasi pickup dekat',
        message:
            '${servisOps.dueSoonOrders} order jatuh tempo dalam 4 jam ke depan.',
        action:
            'Prioritaskan finishing, packing, dan quality control untuk order yang estimasinya paling dekat.',
      ));
    }

    if (servisOps.readyForPickup >= 5) {
      alerts.add(AiAnomalyAlert(
        severity: 'warning',
        title: 'Rak siap ambil mulai menumpuk',
        message:
            '${servisOps.readyForPickup} order sudah siap ambil tetapi belum selesai.',
        action:
            'Kirim reminder WhatsApp dan pastikan label/invoice mudah dicari saat pelanggan datang.',
      ));
    }

    if (servisOps.expressActiveOrders > 0 &&
        servisOps.expressActiveOrders >=
            max(2, servisOps.activeOrders ~/ 3)) {
      alerts.add(AiAnomalyAlert(
        severity: 'warning',
        title: 'Beban express tinggi',
        message:
            '${servisOps.expressActiveOrders} dari ${servisOps.activeOrders} order aktif adalah express/ekspres.',
        action:
            'Amankan kapasitas mesin, perbaikan, dan packing untuk express sebelum menerima order cepat baru.',
      ));
    }

    final negativeStocks = products
        .where((p) => p.tracksInventory && p.stock < 0)
        .take(3)
        .toList();
    for (final product in negativeStocks) {
      alerts.add(AiAnomalyAlert(
        severity: 'danger',
        title: 'Stok minus terdeteksi',
        message:
            '${product.name} memiliki stok ${product.stock} ${product.unit}.',
        action: 'Lakukan koreksi stok agar laporan gudang akurat.',
      ));
    }

    final badMargins = products
        .where((p) => p.buyPrice > 0 && p.sellPrice <= p.buyPrice)
        .take(5)
        .toList();
    for (final product in badMargins) {
      alerts.add(AiAnomalyAlert(
        severity: 'danger',
        title: 'Harga jual tidak sehat',
        message:
            '${product.name} dijual Rp${product.sellPrice}, sedangkan modal Rp${product.buyPrice}.',
        action: 'Naikkan harga jual atau cek ulang harga modal.',
      ));
    }

    final database = await db.database;
    final oldDebtRows = await database.rawQuery('''
      SELECT COUNT(*) as count, COALESCE(SUM(grand_total - amount_paid), 0) as amount
      FROM transactions
      WHERE is_deleted = 0
        AND amount_paid < grand_total
        AND created_at < ?
    ''', [DateTime.now().subtract(const Duration(days: 7)).toIso8601String()]);
    final oldDebtCount = _asInt(oldDebtRows.first['count']);
    if (oldDebtCount > 0) {
      alerts.add(AiAnomalyAlert(
        severity: 'warning',
        title: 'Piutang lama perlu ditagih',
        message: '$oldDebtCount transaksi belum lunas lebih dari 7 hari.',
        action:
            'Buka riwayat piutang dan prioritaskan pelanggan dengan nominal terbesar.',
      ));
    }

    if (alerts.isEmpty) {
      alerts.add(const AiAnomalyAlert(
        severity: 'info',
        title: 'Tidak ada anomali besar',
        message:
            'Data transaksi, stok, dan harga terlihat normal berdasarkan aturan offline.',
        action: 'Tetap pantau restock dan jam sibuk secara rutin.',
      ));
    }

    return alerts.take(8).toList();
  }

  Future<List<AiPriceSuggestion>> getPriceSuggestions() async {
    final products = await db.getAllProducts();
    final salesMap = await _productSalesMap(days: 30);
    final suggestions = <AiPriceSuggestion>[];

    for (final product in products) {
      if (product.buyPrice <= 0 || product.sellPrice <= 0) continue;
      final soldQty = salesMap[product.id] ?? 0;
      final margin =
          ((product.sellPrice - product.buyPrice) / product.sellPrice) * 100;

      if (soldQty >= 10 && margin < 18) {
        final suggested = _roundPrice((product.buyPrice / 0.78).ceil());
        if (suggested > product.sellPrice) {
          suggestions.add(AiPriceSuggestion(
            product: product,
            currentPrice: product.sellPrice,
            suggestedPrice: suggested,
            currentMarginPercent: margin,
            reason:
                'Produk cukup laku, tetapi margin masih tipis. Target margin sekitar 22%.',
          ));
        }
      } else if (soldQty == 0 && product.stock > max(product.minStock, 5)) {
        final suggested = _roundPrice(
            max(product.buyPrice, (product.sellPrice * 0.95).round()));
        if (suggested < product.sellPrice) {
          suggestions.add(AiPriceSuggestion(
            product: product,
            currentPrice: product.sellPrice,
            suggestedPrice: suggested,
            currentMarginPercent: margin,
            reason:
                'Belum terjual 30 hari terakhir. Cocok untuk promo ringan agar stok bergerak.',
          ));
        }
      }
    }

    suggestions.sort(
        (a, b) => a.currentMarginPercent.compareTo(b.currentMarginPercent));
    return suggestions.take(10).toList();
  }

  Future<List<AiTopProduct>> getTopSellingProducts() async {
    final database = await db.database;
    final since =
        DateTime.now().subtract(const Duration(days: 30)).toIso8601String();
    final rows = await database.rawQuery('''
      SELECT ti.product_id,
             ti.product_name,
             COALESCE(SUM(ti.qty), 0) as qty,
             COALESCE(SUM(ti.subtotal), 0) as sales
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      WHERE t.is_deleted = 0 AND t.created_at >= ?
      GROUP BY ti.product_id, ti.product_name
      ORDER BY qty DESC, sales DESC
      LIMIT 10
    ''', [since]);

    return rows
        .map(
          (row) => AiTopProduct(
            productId: _asInt(row['product_id']),
            productName: (row['product_name'] ?? '').toString(),
            totalQty: _asInt(row['qty']),
            totalSales: _asInt(row['sales']),
          ),
        )
        .where((item) => item.productName.trim().isNotEmpty)
        .toList();
  }

  Future<AiLearningProfile> _getLearningProfile() async {
    final database = await db.database;
    final since =
        DateTime.now().subtract(const Duration(days: 60)).toIso8601String();
    final rows = await database.rawQuery('''
      SELECT COUNT(*) as trx,
             COUNT(DISTINCT DATE(created_at)) as active_days
      FROM transactions
      WHERE is_deleted = 0 AND created_at >= ?
    ''', [since]);
    final products = await db.getAllProducts();
    final activeDays = _asInt(rows.first['active_days']);
    final transactions = _asInt(rows.first['trx']);
    final inventoryProducts = products.where((p) => p.tracksInventory).length;
    final servisOps = await getservisOperations();

    var maturity = 12;
    maturity += min(34, activeDays * 3);
    maturity += min(34, transactions);
    maturity += min(20, products.length);
    if (servisOps.statusCounts.length >= 3) maturity += 6;
    if (servisOps.averagePlannedHours > 0) maturity += 6;
    if (servisOps.serviceTypes.length >= 2) maturity += 4;
    maturity = maturity.clamp(0, 100);

    final strongSignals = <String>[];
    final missingSignals = <String>[];
    if (transactions >= 30) {
      strongSignals.add('Pola transaksi mulai stabil');
    } else {
      missingSignals.add('Butuh lebih banyak transaksi untuk prediksi tajam');
    }
    if (activeDays >= 14) {
      strongSignals.add('Tren harian sudah bisa dibandingkan');
    } else {
      missingSignals.add('Butuh riwayat beberapa hari lagi');
    }
    if (products.length >= 10) {
      strongSignals.add('Data layanan dan produk cukup untuk ranking');
    } else {
      missingSignals
          .add('Tambahkan master layanan/produk agar rekomendasi lebih kaya');
    }
    if (inventoryProducts >= 5) {
      strongSignals.add('Stok bisa dianalisis otomatis');
    } else {
      missingSignals
          .add('Aktifkan manajemen stok untuk bahan dan produk utama');
    }
    if (servisOps.statusCounts.length >= 3) {
      strongSignals.add('Status servis cukup kaya untuk audit operasional');
    } else {
      missingSignals
          .add('Update status order sampai Siap Ambil/Selesai secara rutin');
    }
    if (servisOps.averagePlannedHours > 0) {
      strongSignals.add('Estimasi pickup bisa dipakai membaca keterlambatan');
    } else {
      missingSignals
          .add('Isi estimasi pengambilan agar risiko telat bisa dibaca');
    }

    return AiLearningProfile(
      activeSalesDays: activeDays,
      totalTransactions: transactions,
      totalProducts: products.length,
      inventoryProducts: inventoryProducts,
      dataMaturity: maturity,
      level: _learningLevel(maturity),
      learningSummary: _learningSummary(maturity, activeDays, transactions),
      strongSignals: strongSignals,
      missingSignals: missingSignals,
    );
  }

  Future<Map<Product, int>> getStockDepletionEstimates() async {
    final products = await db.getAllProducts();
    final salesMap = await _productSalesMap(days: 30);
    final estimates = <Product, int>{};

    for (final product in products) {
      if (!product.tracksInventory) continue;
      if (product.stock <= 0) {
        estimates[product] = 0;
        continue;
      }
      final avgDailySales = (salesMap[product.id] ?? 0) / 30.0;
      estimates[product] =
          avgDailySales <= 0 ? 999 : (product.stock / avgDailySales).ceil();
    }

    return estimates;
  }

  Future<Map<String, List<Product>>> getInsights() async {
    final estimates = await getStockDepletionEstimates();
    final urgentRestock = <Product>[];
    final deadStock = <Product>[];

    for (final entry in estimates.entries) {
      final product = entry.key;
      final daysLeft = entry.value;
      if (daysLeft < 3 || product.stock <= product.minStock) {
        urgentRestock.add(product);
      }
      if (daysLeft == 999 && product.createdAt != null) {
        final creation = DateTime.tryParse(product.createdAt!);
        if (creation != null &&
            DateTime.now().difference(creation).inDays > 30) {
          deadStock.add(product);
        }
      }
    }

    return {
      'urgent_restock': urgentRestock,
      'dead_stock': deadStock,
    };
  }

  Future<Map<int, int>> _productSalesMap({required int days}) async {
    final database = await db.database;
    final since =
        DateTime.now().subtract(Duration(days: days)).toIso8601String();
    final rows = await database.rawQuery('''
      SELECT ti.product_id, COALESCE(SUM(ti.qty), 0) as qty
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      WHERE t.is_deleted = 0 AND t.created_at >= ?
      GROUP BY ti.product_id
    ''', [since]);

    return {
      for (final row in rows) _asInt(row['product_id']): _asInt(row['qty']),
    };
  }

  String _buildExecutiveSummary({
    required AiSalesForecast forecast,
    required List<AiRestockRecommendation> restocks,
    required List<AiCrossSellRecommendation> bundles,
    required List<AiBusyHour> busyHours,
    required List<AiAnomalyAlert> anomalies,
    required List<AiPriceSuggestion> prices,
    required AiservisOperations servisOps,
  }) {
    final parts = <String>[];
    final trendText = forecast.trendPercent >= 0 ? 'naik' : 'turun';
    parts.add(
      'Omzet 7 hari terakhir cenderung $trendText ${forecast.trendPercent.abs().toStringAsFixed(1)}% dibanding 7 hari sebelumnya. Perkiraan omzet besok berada di kisaran Rp${forecast.tomorrowLow}-Rp${forecast.tomorrowHigh}.',
    );
    parts.add(
      'Operasional saat ini memiliki ${servisOps.activeOrders} order aktif, ${servisOps.readyForPickup} siap ambil, ${servisOps.overdueOrders} melewati estimasi, dan ${servisOps.dueSoonOrders} jatuh tempo dalam 4 jam.',
    );
    if (servisOps.expressActiveOrders > 0) {
      parts.add(
        'Ada ${servisOps.expressActiveOrders} order express/ekspres aktif yang perlu dijaga kapasitasnya.',
      );
    }
    if (restocks.isNotEmpty) {
      parts.add(
        '${restocks.length} item perlu perhatian stok. Prioritas pertama: ${restocks.first.product.name}, estimasi habis ${restocks.first.daysLeft >= 999 ? 'lama' : 'dalam ${restocks.first.daysLeft} hari'}.',
      );
    }
    if (busyHours.isNotEmpty) {
      parts.add(
          'Jam tersibuk saat ini adalah ${busyHours.first.label}, cocok untuk menambah kesiapan kasir, workshop, dan stok bahan.');
    }
    if (bundles.isNotEmpty) {
      parts.add(
          'Peluang paket/add-on terbaik: ${bundles.first.productA} + ${bundles.first.productB}.');
    }
    if (prices.isNotEmpty) {
      parts.add(
          '${prices.length} layanan/produk punya peluang penyesuaian harga atau promo.');
    }
    if (anomalies
        .any((a) => a.severity == 'danger' || a.severity == 'warning')) {
      parts.add('Ada alert operasional yang perlu dicek sebelum servis tutup.');
    }
    return parts.join(' ');
  }

  List<AiQuickAnswer> _buildQuickAnswers({
    required AiSalesForecast forecast,
    required List<AiRestockRecommendation> restocks,
    required List<AiCrossSellRecommendation> bundles,
    required List<AiBusyHour> busyHours,
    required List<AiAnomalyAlert> anomalies,
    required AiservisOperations servisOps,
  }) {
    return [
      AiQuickAnswer(
        question: 'Berapa prediksi omzet besok?',
        answer:
            'Kisaran Rp${forecast.tomorrowLow}-Rp${forecast.tomorrowHigh} dengan confidence ${forecast.confidence}%.',
      ),
      AiQuickAnswer(
        question: 'Stok apa yang harus dibeli dulu?',
        answer: restocks.isEmpty
            ? 'Belum ada prioritas restock kritis.'
            : '${restocks.first.product.name}, saran beli ${restocks.first.recommendedQty} ${restocks.first.product.unit}.',
      ),
      AiQuickAnswer(
        question: 'Jam paling ramai kapan?',
        answer: busyHours.isEmpty
            ? 'Data jam ramai belum cukup.'
            : '${busyHours.first.label} dengan ${busyHours.first.transactionCount} transaksi dalam 30 hari terakhir.',
      ),
      AiQuickAnswer(
        question: 'Bundling apa yang potensial?',
        answer: bundles.isEmpty
            ? 'Belum ada pola paket/add-on yang kuat.'
            : '${bundles.first.productA} + ${bundles.first.productB}, muncul bersama ${bundles.first.togetherCount} kali.',
      ),
      AiQuickAnswer(
        question: 'Ada order servis terlambat?',
        answer: servisOps.overdueOrders == 0
            ? 'Tidak ada order aktif yang melewati estimasi.'
            : '${servisOps.overdueOrders} order melewati estimasi. Prioritas: ${servisOps.overdueDetails.isEmpty ? 'cek daftar status' : servisOps.overdueDetails.first.customerName}.',
      ),
      AiQuickAnswer(
        question: 'Berapa order siap ambil?',
        answer:
            '${servisOps.readyForPickup} order siap ambil dari ${servisOps.activeOrders} order aktif.',
      ),
      AiQuickAnswer(
        question: 'Ada masalah penting?',
        answer: anomalies.isEmpty
            ? 'Tidak ada alert penting.'
            : '${anomalies.first.title}: ${anomalies.first.action}',
      ),
    ];
  }

  int _calculateHealthScore({
    required AiSalesForecast forecast,
    required List<AiRestockRecommendation> restocks,
    required List<AiAnomalyAlert> anomalies,
    required List<AiPriceSuggestion> prices,
    required AiservisOperations servisOps,
  }) {
    var score = 78;
    if (forecast.trendPercent > 10) score += 8;
    if (forecast.trendPercent < -10) score -= 10;
    score -= restocks.where((r) => r.priority == 'urgent').length * 5;
    score -= anomalies.where((a) => a.severity == 'danger').length * 10;
    score -= anomalies.where((a) => a.severity == 'warning').length * 4;
    score -= min(10, prices.length * 2);
    score -= min(18, servisOps.overdueOrders * 6);
    score -= min(8, servisOps.dueSoonOrders * 2);
    if (servisOps.readyForPickup >= 8) score -= 5;
    if (servisOps.completionRatio > 0.75) score += 4;
    return score.clamp(0, 100);
  }

  String _scoreLabel(int score) {
    if (score >= 85) return 'Sangat Sehat';
    if (score >= 70) return 'Stabil';
    if (score >= 55) return 'Perlu Perhatian';
    return 'Kritis';
  }

  String _learningLevel(int maturity) {
    if (maturity >= 85) return 'Expert';
    if (maturity >= 65) return 'Cerdas';
    if (maturity >= 40) return 'Belajar Cepat';
    return 'Pemula';
  }

  String _learningSummary(int maturity, int activeDays, int transactions) {
    if (maturity >= 85) {
      return 'Saya sudah memiliki histori yang kuat. Prediksi, restock, jam sibuk, dan paket layanan bisa dibaca lebih percaya diri.';
    }
    if (maturity >= 65) {
      return 'Saya sudah cukup mengenali pola servis. Semakin rutin order dicatat, rekomendasi akan makin presisi.';
    }
    if (maturity >= 40) {
      return 'Saya sedang belajar dari $transactions transaksi di $activeDays hari aktif. Insight dasar sudah bisa dipakai, tetapi prediksi masih akan membaik.';
    }
    return 'Saya baru mulai belajar dari data servis. Catat order detail beberapa hari lagi agar jawaban lebih pintar dan stabil.';
  }

  int _priorityRank(String priority) {
    switch (priority) {
      case 'urgent':
        return 0;
      case 'watch':
        return 1;
      default:
        return 2;
    }
  }

  int _roundPrice(int value) {
    if (value <= 1000) return ((value / 100).ceil() * 100);
    return ((value / 500).ceil() * 500);
  }

  int _percentOf(int part, int base) {
    if (base <= 0) return 0;
    return ((part / base) * 100).round();
  }

  int _asInt(Object? value) {
    if (value is int) return value;
    if (value is num) return value.round();
    return int.tryParse(value?.toString() ?? '') ?? 0;
  }

  String _cleanText(Object? value, {required String fallback}) {
    final text = value?.toString().trim() ?? '';
    return text.isEmpty ? fallback : text;
  }

  DateTime _startOfDay(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  String _dateKey(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

  double _averageSales(List<AiDailySalesPoint> points) {
    if (points.isEmpty) return 0;
    return points.fold<int>(0, (sum, p) => sum + p.sales) / points.length;
  }

  double _weekdayFactor(List<AiDailySalesPoint> points, int weekday) {
    final sameDays =
        points.where((p) => p.date.weekday == weekday && p.sales > 0).toList();
    final activeDays = points.where((p) => p.sales > 0).toList();
    if (sameDays.isEmpty || activeDays.isEmpty) return 1.0;
    final sameAvg = _averageSales(sameDays);
    final allAvg = _averageSales(activeDays);
    if (allAvg <= 0) return 1.0;
    return (sameAvg / allAvg).clamp(0.75, 1.35);
  }

  int _forecastConfidence(List<AiDailySalesPoint> points) {
    final activeDays = points.where((p) => p.transactionCount > 0).length;
    if (activeDays >= 21) return 86;
    if (activeDays >= 14) return 76;
    if (activeDays >= 7) return 64;
    if (activeDays >= 3) return 48;
    return 30;
  }
}

