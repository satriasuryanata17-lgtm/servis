import 'dart:io';
import 'dart:ui' show Color;

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'android_notification_branding.dart';

class servisBadgeService {
  servisBadgeService._();

  static const int _notificationId = 9901;
  static const String _channelId = 'servis_active_badge';
  static const String _channelName = 'Servis Berjalan';
  static const String _androidNotificationIcon =
      AndroidNotificationBranding.smallIcon;
  static const Color _androidIconColor = AndroidNotificationBranding.color;

  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static bool _initialized = false;
  static int? _lastCount;

  static Future<void> _init() async {
    if (_initialized) return;

    const androidSettings =
        AndroidInitializationSettings(_androidNotificationIcon);
    const darwinSettings = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: true,
      requestSoundPermission: false,
    );

    await _plugin.initialize(
      const InitializationSettings(
        android: androidSettings,
        iOS: darwinSettings,
        macOS: darwinSettings,
      ),
    );

    if (Platform.isAndroid) {
      await _plugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
    } else if (Platform.isIOS) {
      await _plugin
          .resolvePlatformSpecificImplementation<
              IOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(alert: true, badge: true, sound: false);
    } else if (Platform.isMacOS) {
      await _plugin
          .resolvePlatformSpecificImplementation<
              MacOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(alert: true, badge: true, sound: false);
    }

    _initialized = true;
  }

  static Future<void> updateBadge(int count) async {
    if (kIsWeb) return;
    if (!Platform.isAndroid && !Platform.isIOS && !Platform.isMacOS) return;
    if (_lastCount == count) return;
    _lastCount = count;

    await _init();

    if (count <= 0) {
      await _plugin.cancel(_notificationId);
      return;
    }

    final body = count == 1
        ? '1 pesanan servis masih berjalan'
        : '$count pesanan servis masih berjalan';

    if (Platform.isAndroid) {
      final androidDetails = AndroidNotificationDetails(
        _channelId,
        _channelName,
        channelDescription:
            'Menampilkan jumlah pesanan servis yang belum selesai',
        importance: Importance.low,
        priority: Priority.low,
        ongoing: false,
        autoCancel: false,
        onlyAlertOnce: true,
        number: count,
        icon: _androidNotificationIcon,
        color: _androidIconColor,
        colorized: true,
        showWhen: false,
        enableVibration: false,
        playSound: false,
        silent: true,
      );

      await _plugin.show(
        _notificationId,
        'Juragan Servis',
        body,
        NotificationDetails(android: androidDetails),
      );
      return;
    }

    final darwinDetails = DarwinNotificationDetails(
      badgeNumber: count,
      presentAlert: true,
      presentBadge: true,
      presentSound: false,
    );
    await _plugin.show(
      _notificationId,
      'Juragan Servis',
      body,
      NotificationDetails(iOS: darwinDetails, macOS: darwinDetails),
    );
  }

  static Future<void> clearBadge() => updateBadge(0);
}

