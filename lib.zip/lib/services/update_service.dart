import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:in_app_update/in_app_update.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/app_runtime_config.dart';
import 'backup_service.dart';

class UpdatePreferences {
  static const _autoUpdateEnabledKey = 'auto_update_enabled';
  static const _lastAutoCheckKey = 'auto_update_last_check_at';
  static const _autoCheckCooldown = Duration(hours: 6);

  static Future<bool> isAutoUpdateEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_autoUpdateEnabledKey) ?? true;
  }

  static Future<void> setAutoUpdateEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_autoUpdateEnabledKey, enabled);
  }

  static Future<bool> shouldRunAutoCheck() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_lastAutoCheckKey);
    final last = raw == null ? null : DateTime.tryParse(raw);
    if (last == null) return true;
    return DateTime.now().difference(last) >= _autoCheckCooldown;
  }

  static Future<void> markAutoCheck() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_lastAutoCheckKey, DateTime.now().toIso8601String());
  }
}

enum UpdateStatus {
  idle,
  available,
  downloading,
  readyToInstall,
  notAvailable,
  required,
  backupRequired,
}

class UpdateState {
  static const Object _keepValue = Object();

  final UpdateStatus status;
  final double downloadProgress;
  final String? latestVersion;
  final int? latestBuildNumber;
  final String? releaseNotes;
  final String? installerUrl;
  final String? installerPath;
  final String? sha256;
  final int? sizeBytes;
  final String? errorMessage;

  const UpdateState({
    this.status = UpdateStatus.idle,
    this.downloadProgress = 0.0,
    this.latestVersion,
    this.latestBuildNumber,
    this.releaseNotes,
    this.installerUrl,
    this.installerPath,
    this.sha256,
    this.sizeBytes,
    this.errorMessage,
  });

  bool get hasUpdate => status == UpdateStatus.available;
  bool get isDownloading => status == UpdateStatus.downloading;
  bool get readyToInstall => status == UpdateStatus.readyToInstall;
  bool get isRequired => status == UpdateStatus.required;
  bool get needsBackup => status == UpdateStatus.backupRequired;

  UpdateState copyWith({
    UpdateStatus? status,
    double? downloadProgress,
    String? latestVersion,
    int? latestBuildNumber,
    String? releaseNotes,
    String? installerUrl,
    String? installerPath,
    String? sha256,
    int? sizeBytes,
    Object? errorMessage = _keepValue,
  }) {
    return UpdateState(
      status: status ?? this.status,
      downloadProgress: downloadProgress ?? this.downloadProgress,
      latestVersion: latestVersion ?? this.latestVersion,
      latestBuildNumber: latestBuildNumber ?? this.latestBuildNumber,
      releaseNotes: releaseNotes ?? this.releaseNotes,
      installerUrl: installerUrl ?? this.installerUrl,
      installerPath: installerPath ?? this.installerPath,
      sha256: sha256 ?? this.sha256,
      sizeBytes: sizeBytes ?? this.sizeBytes,
      errorMessage: identical(errorMessage, _keepValue)
          ? this.errorMessage
          : errorMessage as String?,
    );
  }

  UpdateState _withManifest(_UpdateManifest manifest) {
    return copyWith(
      latestVersion: manifest.latestVersion,
      latestBuildNumber: manifest.buildNumber,
      releaseNotes: manifest.notes,
      installerUrl: manifest.installerUrl,
      sha256: manifest.sha256,
      sizeBytes: manifest.sizeBytes,
      errorMessage: null,
    );
  }
}

class UpdateNotifier extends Notifier<UpdateState> {
  static const int _immediatePriorityThreshold = 4;
  static const int _immediateStalenessDays = 7;
  static const MethodChannel _installerChannel =
      MethodChannel('juragan_servis/update_installer');

  @override
  UpdateState build() => const UpdateState();

  bool get _androidSupported => Platform.isAndroid && !kDebugMode;
  bool get _androidR2Supported =>
      _androidSupported && AppRuntimeConfig.useAndroidR2Updates;
  bool get _androidPlayStoreSupported =>
      _androidSupported && !AppRuntimeConfig.useAndroidR2Updates;
  bool get _windowsSupported => Platform.isWindows && !kDebugMode;

  Future<void> checkForUpdate({bool force = false}) async {
    if (!force) {
      if (!await UpdatePreferences.isAutoUpdateEnabled()) {
        state = state.copyWith(
          status: UpdateStatus.notAvailable,
          errorMessage: null,
        );
        return;
      }
      if (!await UpdatePreferences.shouldRunAutoCheck()) {
        return;
      }
      await UpdatePreferences.markAutoCheck();
    }

    if (!_androidR2Supported &&
        !_androidPlayStoreSupported &&
        !_windowsSupported) {
      if (force) {
        state = state.copyWith(
          status: UpdateStatus.idle,
          errorMessage: null,
        );
      }
      return;
    }

    if (_androidR2Supported) {
      await _checkAndroidR2Update();
      return;
    }
    if (_androidPlayStoreSupported) {
      await _checkAndroidPlayStoreUpdate();
      return;
    }
    if (_windowsSupported) {
      await _checkWindowsUpdate();
      return;
    }
  }

  Future<void> _checkAndroidPlayStoreUpdate() async {
    try {
      final info = await InAppUpdate.checkForUpdate();
      final updateAvailable =
          info.updateAvailability == UpdateAvailability.updateAvailable;
      if (!updateAvailable) {
        state = state.copyWith(
          status: UpdateStatus.notAvailable,
          errorMessage: null,
        );
        return;
      }

      if (!await _hasRequiredBackup()) {
        state = state.copyWith(
          status: UpdateStatus.backupRequired,
          errorMessage: null,
        );
        return;
      }

      if (_shouldUseImmediateUpdate(info)) {
        await performImmediateUpdate(skipBackupCheck: true);
        return;
      }

      state = state.copyWith(
        status: info.flexibleUpdateAllowed
            ? UpdateStatus.available
            : UpdateStatus.notAvailable,
        errorMessage: null,
      );
    } catch (e) {
      state = state.copyWith(
        status: UpdateStatus.notAvailable,
        errorMessage: _friendlyError(e),
      );
    }
  }

  Future<void> _checkAndroidR2Update() async {
    try {
      final manifest = await _fetchManifest(
        AppRuntimeConfig.androidUpdateManifestUrl,
        expectedPlatform: 'android',
      );
      if (!manifest.isNewerThan(
        expectedPlatform: 'android',
        currentBuildNumber: AppRuntimeConfig.appBuildNumber,
      )) {
        state = state.copyWith(
          status: UpdateStatus.notAvailable,
          errorMessage: null,
        );
        return;
      }

      final nextStatus =
          manifest.required ? UpdateStatus.required : UpdateStatus.available;
      final nextState = state._withManifest(manifest).copyWith(
            status: nextStatus,
            downloadProgress: 0,
          );

      if (!await _hasRequiredBackup()) {
        state = nextState.copyWith(status: UpdateStatus.backupRequired);
        return;
      }

      state = nextState;
    } catch (e) {
      state = state.copyWith(
        status: UpdateStatus.notAvailable,
        errorMessage: _friendlyError(e),
      );
    }
  }

  Future<void> _checkWindowsUpdate() async {
    try {
      final manifest = await _fetchWindowsManifest();
      if (!manifest.isNewerThan(
        expectedPlatform: 'windows',
        currentBuildNumber: AppRuntimeConfig.appBuildNumber,
      )) {
        state = state.copyWith(
          status: UpdateStatus.notAvailable,
          errorMessage: null,
        );
        return;
      }

      final nextStatus =
          manifest.required ? UpdateStatus.required : UpdateStatus.available;
      final nextState = state._withManifest(manifest).copyWith(
            status: nextStatus,
            downloadProgress: 0,
          );

      if (!await _hasRequiredBackup()) {
        state = nextState.copyWith(status: UpdateStatus.backupRequired);
        return;
      }

      state = nextState;
    } catch (e) {
      state = state.copyWith(
        status: UpdateStatus.notAvailable,
        errorMessage: _friendlyError(e),
      );
    }
  }

  bool _shouldUseImmediateUpdate(AppUpdateInfo info) {
    final staleDays = info.clientVersionStalenessDays ?? 0;
    return info.immediateUpdateAllowed &&
        (info.updatePriority >= _immediatePriorityThreshold ||
            staleDays >= _immediateStalenessDays);
  }

  Future<bool> _hasRequiredBackup() {
    return BackupService.hasFreshBackupForUpdate();
  }

  Future<void> performImmediateUpdate({bool skipBackupCheck = false}) async {
    if (_androidR2Supported) {
      await _performAndroidR2Update(skipBackupCheck: skipBackupCheck);
      return;
    }
    if (_androidPlayStoreSupported) {
      await _performAndroidPlayStoreImmediateUpdate(
        skipBackupCheck: skipBackupCheck,
      );
      return;
    }
    if (_windowsSupported) {
      await _performWindowsImmediateUpdate(skipBackupCheck: skipBackupCheck);
    }
  }

  Future<void> _performAndroidPlayStoreImmediateUpdate({
    bool skipBackupCheck = false,
  }) async {
    try {
      if (!skipBackupCheck && !await _hasRequiredBackup()) {
        state = state.copyWith(
          status: UpdateStatus.backupRequired,
          errorMessage: null,
        );
        return;
      }
      state = state.copyWith(
        status: UpdateStatus.required,
        errorMessage: null,
      );
      final result = await InAppUpdate.performImmediateUpdate();
      if (result != AppUpdateResult.success) {
        await checkForUpdate(force: true);
      }
    } catch (e) {
      state = state.copyWith(
        status: UpdateStatus.notAvailable,
        errorMessage: _friendlyError(e),
      );
    }
  }

  Future<void> _performAndroidR2Update({
    bool skipBackupCheck = false,
  }) async {
    if (!skipBackupCheck && !await _hasRequiredBackup()) {
      state = state.copyWith(
        status: UpdateStatus.backupRequired,
        errorMessage: null,
      );
      return;
    }

    await _downloadAndroidInstaller(skipBackupCheck: true);
    if (state.readyToInstall) {
      await completeUpdate();
    }
  }

  Future<void> _performWindowsImmediateUpdate({
    bool skipBackupCheck = false,
  }) async {
    if (!skipBackupCheck && !await _hasRequiredBackup()) {
      state = state.copyWith(
        status: UpdateStatus.backupRequired,
        errorMessage: null,
      );
      return;
    }
    await startFlexibleUpdate();
    if (state.readyToInstall) {
      await completeUpdate();
    }
  }

  Future<void> startFlexibleUpdate() async {
    if (_androidR2Supported) {
      await _downloadAndroidInstaller();
      return;
    }
    if (_androidPlayStoreSupported) {
      await _startAndroidPlayStoreFlexibleUpdate();
      return;
    }
    if (_windowsSupported) {
      await _downloadWindowsInstaller();
    }
  }

  Future<void> _startAndroidPlayStoreFlexibleUpdate() async {
    if (state.status != UpdateStatus.available) return;

    try {
      if (!await _hasRequiredBackup()) {
        state = state.copyWith(
          status: UpdateStatus.backupRequired,
          errorMessage: null,
        );
        return;
      }

      state = state.copyWith(
        status: UpdateStatus.downloading,
        downloadProgress: 0.0,
        errorMessage: null,
      );

      final result = await InAppUpdate.startFlexibleUpdate();
      if (result != AppUpdateResult.success) {
        state = state.copyWith(
          status: UpdateStatus.available,
          errorMessage: null,
        );
        return;
      }

      while (state.isDownloading) {
        await Future.delayed(const Duration(seconds: 2));
        try {
          final info = await InAppUpdate.checkForUpdate();
          final installStatus = info.installStatus;

          if (installStatus == InstallStatus.downloaded) {
            state = state.copyWith(
              status: UpdateStatus.readyToInstall,
              downloadProgress: 1.0,
              errorMessage: null,
            );
            break;
          } else if (installStatus == InstallStatus.downloading) {
            state = state.copyWith(downloadProgress: 0.5);
          } else if (installStatus == InstallStatus.failed ||
              installStatus == InstallStatus.canceled) {
            state = state.copyWith(
              status: UpdateStatus.available,
              errorMessage: null,
            );
            break;
          }
        } catch (_) {
          break;
        }
      }
    } catch (e) {
      state = state.copyWith(
        status: UpdateStatus.available,
        errorMessage: _friendlyError(e),
      );
    }
  }

  Future<void> _downloadAndroidInstaller({
    bool skipBackupCheck = false,
  }) async {
    if (state.status != UpdateStatus.available &&
        state.status != UpdateStatus.required) {
      return;
    }

    final previousStatus = state.status;
    try {
      if (!skipBackupCheck && !await _hasRequiredBackup()) {
        state = state.copyWith(
          status: UpdateStatus.backupRequired,
          errorMessage: null,
        );
        return;
      }

      var installerUrl = state.installerUrl;
      var sha256Value = state.sha256;
      var version = state.latestVersion;
      var buildNumber = state.latestBuildNumber;

      if (installerUrl == null || installerUrl.isEmpty || buildNumber == null) {
        final manifest = await _fetchManifest(
          AppRuntimeConfig.androidUpdateManifestUrl,
          expectedPlatform: 'android',
        );
        installerUrl = manifest.installerUrl;
        sha256Value = manifest.sha256;
        version = manifest.latestVersion;
        buildNumber = manifest.buildNumber;
        state = state._withManifest(manifest);
      }

      state = state.copyWith(
        status: UpdateStatus.downloading,
        downloadProgress: 0,
        errorMessage: null,
      );

      final file = await _downloadInstallerFile(
        url: installerUrl,
        version: version ?? 'latest',
        buildNumber: buildNumber,
        sha256Value: sha256Value,
        filePrefix: 'JuraganServis',
        fileExtension: 'apk',
      );

      state = state.copyWith(
        status: UpdateStatus.readyToInstall,
        downloadProgress: 1,
        installerPath: file.path,
        errorMessage: null,
      );
    } catch (e) {
      state = state.copyWith(
        status: previousStatus == UpdateStatus.required
            ? UpdateStatus.required
            : UpdateStatus.available,
        errorMessage: _friendlyError(e),
      );
    }
  }

  Future<void> _downloadWindowsInstaller() async {
    if (state.status != UpdateStatus.available &&
        state.status != UpdateStatus.required) {
      return;
    }

    final previousStatus = state.status;
    try {
      if (!await _hasRequiredBackup()) {
        state = state.copyWith(
          status: UpdateStatus.backupRequired,
          errorMessage: null,
        );
        return;
      }

      var installerUrl = state.installerUrl;
      var sha256Value = state.sha256;
      var version = state.latestVersion;
      var buildNumber = state.latestBuildNumber;

      if (installerUrl == null || installerUrl.isEmpty || buildNumber == null) {
        final manifest = await _fetchWindowsManifest();
        installerUrl = manifest.installerUrl;
        sha256Value = manifest.sha256;
        version = manifest.latestVersion;
        buildNumber = manifest.buildNumber;
        state = state._withManifest(manifest);
      }

      state = state.copyWith(
        status: UpdateStatus.downloading,
        downloadProgress: 0,
        errorMessage: null,
      );

      final file = await _downloadInstallerFile(
        url: installerUrl,
        version: version ?? 'latest',
        buildNumber: buildNumber,
        sha256Value: sha256Value,
        filePrefix: 'JuraganServis_Setup',
        fileExtension: 'exe',
      );

      state = state.copyWith(
        status: UpdateStatus.readyToInstall,
        downloadProgress: 1,
        installerPath: file.path,
        errorMessage: null,
      );
    } catch (e) {
      state = state.copyWith(
        status: previousStatus == UpdateStatus.required
            ? UpdateStatus.required
            : UpdateStatus.available,
        errorMessage: _friendlyError(e),
      );
    }
  }

  Future<File> _downloadInstallerFile({
    required String url,
    required String version,
    required int buildNumber,
    String? sha256Value,
    required String filePrefix,
    required String fileExtension,
  }) async {
    final uri = Uri.parse(url);
    final tempDir = await getTemporaryDirectory();
    final file = File(
      '${tempDir.path}${Platform.pathSeparator}'
      '${filePrefix}_${_safeFilePart(version)}_$buildNumber.$fileExtension',
    );
    if (await file.exists()) {
      try {
        await _verifyInstallerHash(file, sha256Value);
        return file;
      } catch (_) {
        try {
          await file.delete();
        } catch (_) {}
      }
    }

    final partialFile = File('${file.path}.part');
    if (await partialFile.exists()) {
      try {
        await partialFile.delete();
      } catch (_) {}
    }

    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 20);
    try {
      final request = await client.getUrl(uri);
      final response = await request.close();
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException(
          'Download update gagal (${response.statusCode})',
          uri: uri,
        );
      }

      final total = response.contentLength;
      var received = 0;
      final sink = partialFile.openWrite();
      try {
        await for (final chunk in response) {
          received += chunk.length;
          sink.add(chunk);
          if (total > 0) {
            state = state.copyWith(
              downloadProgress: (received / total).clamp(0.0, 0.98),
            );
          }
        }
      } finally {
        await sink.close();
      }
    } finally {
      client.close(force: true);
    }

    await _verifyInstallerHash(partialFile, sha256Value);
    if (await file.exists()) {
      await file.delete();
    }
    return partialFile.rename(file.path);
  }

  Future<void> _verifyInstallerHash(File file, String? expectedHash) async {
    final hash = expectedHash?.trim().toLowerCase() ?? '';
    final isRealSha256 = RegExp(r'^[a-f0-9]{64}$').hasMatch(hash);
    if (!isRealSha256) return;

    final actual = await sha256.bind(file.openRead()).first;
    if (actual.toString() != hash) {
      try {
        await file.delete();
      } catch (_) {}
      throw const FileSystemException('Hash installer update tidak cocok.');
    }
  }

  Future<void> completeUpdate() async {
    if (_androidR2Supported) {
      await _installAndroidApk();
      return;
    }
    if (_androidPlayStoreSupported) {
      await _completeAndroidPlayStoreUpdate();
      return;
    }
    if (_windowsSupported) {
      await _installWindowsUpdate();
    }
  }

  Future<void> _completeAndroidPlayStoreUpdate() async {
    if (!state.readyToInstall) return;
    try {
      await InAppUpdate.completeFlexibleUpdate();
    } catch (_) {}
  }

  Future<void> _installAndroidApk() async {
    if (!state.readyToInstall) return;
    final path = state.installerPath;
    if (path == null || path.isEmpty || !await File(path).exists()) {
      state = state.copyWith(
        status: UpdateStatus.available,
        errorMessage: 'File APK update tidak ditemukan. Unduh ulang update.',
      );
      return;
    }

    try {
      await _installerChannel.invokeMethod<bool>('installApk', {'path': path});
    } on PlatformException {
      // Android bisa meminta izin "install unknown apps" dulu.
      // Installer tetap siap agar pengguna bisa tekan Pasang lagi.
      state = state.copyWith(
        status: UpdateStatus.readyToInstall,
        errorMessage:
            'Izinkan pemasangan aplikasi dari sumber ini lalu tekan Pasang lagi.',
      );
    }
  }

  Future<void> _installWindowsUpdate() async {
    if (!state.readyToInstall) return;
    final path = state.installerPath;
    if (path == null || path.isEmpty || !await File(path).exists()) {
      state = state.copyWith(
        status: UpdateStatus.available,
        errorMessage:
            'File installer update tidak ditemukan. Unduh ulang update.',
      );
      return;
    }

    await Process.start(
      path,
      const [
        '/SILENT',
        '/SUPPRESSMSGBOXES',
        '/CLOSEAPPLICATIONS',
        '/RESTARTAPPLICATIONS',
        '/NORESTART',
      ],
      mode: ProcessStartMode.detached,
    );

    await Future.delayed(const Duration(milliseconds: 600));
    exit(0);
  }

  Future<_UpdateManifest> _fetchWindowsManifest() {
    return _fetchManifest(
      AppRuntimeConfig.windowsUpdateManifestUrl,
      expectedPlatform: 'windows',
    );
  }

  Future<_UpdateManifest> _fetchManifest(
    String manifestUrl, {
    required String expectedPlatform,
  }) async {
    final uri = Uri.parse(manifestUrl);
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 12);
    try {
      final request = await client.getUrl(uri);
      final response = await request.close();
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException(
          'Manifest update tidak tersedia (${response.statusCode})',
          uri: uri,
        );
      }
      final body = await utf8.decodeStream(response);
      final data = jsonDecode(body) as Map<String, dynamic>;
      return _UpdateManifest.fromJson(data, expectedPlatform: expectedPlatform);
    } finally {
      client.close(force: true);
    }
  }

  void dismiss() {
    state = state.copyWith(
      status: UpdateStatus.notAvailable,
      errorMessage: null,
    );
  }

  String _safeFilePart(String value) {
    return value.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_');
  }

  String _friendlyError(Object error) {
    if (error is SocketException) {
      return 'Koneksi ke server update gagal. Periksa internet lalu coba lagi.';
    }
    if (error is HandshakeException) {
      return 'Koneksi server update tidak aman. Pastikan alamat update memakai HTTPS yang valid.';
    }
    if (error is TimeoutException) {
      return 'Server update terlalu lama merespons. Coba lagi beberapa saat.';
    }
    if (error is HttpException) {
      return error.message;
    }
    if (error is FormatException) {
      return error.message;
    }
    if (error is FileSystemException) {
      return error.message;
    }
    return 'Update belum bisa dicek. Coba lagi setelah koneksi stabil.';
  }
}

class _UpdateManifest {
  final String app;
  final String platform;
  final String latestVersion;
  final int buildNumber;
  final bool required;
  final String installerUrl;
  final String? sha256;
  final int? sizeBytes;
  final String? notes;

  const _UpdateManifest({
    required this.app,
    required this.platform,
    required this.latestVersion,
    required this.buildNumber,
    required this.required,
    required this.installerUrl,
    this.sha256,
    this.sizeBytes,
    this.notes,
  });

  factory _UpdateManifest.fromJson(
    Map<String, dynamic> json, {
    required String expectedPlatform,
  }) {
    final app =
        (json['app'] ?? 'juragan-servis').toString().trim().toLowerCase();
    final platform =
        (json['platform'] ?? expectedPlatform).toString().trim().toLowerCase();
    if (app != 'juragan-servis') {
      throw const FormatException(
          'Manifest update bukan untuk Juragan Servis.');
    }
    if (platform != expectedPlatform) {
      throw const FormatException(
          'Manifest update tidak sesuai perangkat ini.');
    }

    final buildNumber = json['build_number'];
    final installerUrl = (json['installer_url'] ?? '').toString().trim();
    if (installerUrl.isEmpty) {
      throw const FormatException('installer_url kosong.');
    }
    final uri = Uri.tryParse(installerUrl);
    if (uri == null || !uri.hasScheme || uri.scheme.toLowerCase() != 'https') {
      throw const FormatException('installer_url harus memakai HTTPS.');
    }

    return _UpdateManifest(
      app: app,
      platform: platform,
      latestVersion: (json['latest_version'] ?? '0.0.0').toString(),
      buildNumber: buildNumber is int
          ? buildNumber
          : int.tryParse(buildNumber.toString()) ?? 0,
      required: json['required'] == true,
      installerUrl: installerUrl,
      sha256: json['sha256']?.toString(),
      sizeBytes: json['size_bytes'] is int
          ? json['size_bytes'] as int
          : int.tryParse((json['size_bytes'] ?? '').toString()),
      notes: json['notes']?.toString(),
    );
  }

  bool isNewerThan({
    required String expectedPlatform,
    required int currentBuildNumber,
  }) {
    return app == 'juragan-servis' &&
        platform == expectedPlatform &&
        buildNumber > currentBuildNumber;
  }
}

final updateProvider =
    NotifierProvider<UpdateNotifier, UpdateState>(UpdateNotifier.new);

class UpdateAutoCheckNotifier extends AsyncNotifier<bool> {
  @override
  Future<bool> build() {
    return UpdatePreferences.isAutoUpdateEnabled();
  }

  Future<void> setEnabled(bool enabled) async {
    state = AsyncValue.data(enabled);
    await UpdatePreferences.setAutoUpdateEnabled(enabled);

    if (enabled) {
      await ref.read(updateProvider.notifier).checkForUpdate(force: true);
    } else {
      ref.read(updateProvider.notifier).dismiss();
    }
  }
}

final updateAutoCheckEnabledProvider =
    AsyncNotifierProvider<UpdateAutoCheckNotifier, bool>(
  UpdateAutoCheckNotifier.new,
);

