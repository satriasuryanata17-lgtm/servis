//
//  PATCH: lib/screens/struk_screen.dart
//
//  Tambahkan tombol "Kirim ke WA" di bagian bawah action buttons.
//  Cukup tambah 2 hal:
//    1. Import url_launcher di bagian atas
//    2. Method _shareToWhatsapp() di dalam _StrukScreenState
//    3. Tombol WA di bagian bawah build()
//

//  STEP 1: tambah import di bagian atas struk_screen.dart
// import 'package:url_launcher/url_launcher.dart';
// import 'package:share_plus/share_plus.dart';
// import 'package:printing/printing.dart'; // sudah ada

//  STEP 2: tambah method ini di dalam class _StrukScreenState

/*
  String _buildStrukText() {
    if (_tx == null) return '';
    final namaWarung   = _namaWarung.isNotEmpty ? _namaWarung : 'Toko Kami';
    final noTx         = _formatNoTransaksi(_tx!.id!, _tx!.createdAt);
    final tanggal      = DateFormat('dd/MM/yyyy HH:mm').format(
        DateTime.tryParse(_tx!.createdAt) ?? DateTime.now());

    final buf = StringBuffer();
    buf.writeln('- *STRUK servis*');
    buf.writeln('*$namaWarung*');
    if (_alamat.isNotEmpty) buf.writeln(_alamat);
    if (_telepon.isNotEmpty) buf.writeln('Telp: $_telepon');
    buf.writeln('');
    buf.writeln('No. Transaksi: $noTx');
    buf.writeln('Tanggal      : $tanggal');
    if (_kasirName.isNotEmpty) buf.writeln('Kasir        : $_kasirName');
    buf.writeln('');

    for (final row in _itemsWithExtra) {
      final item   = row['item'] as TransactionItem;
      final isExtra = (row['isExtra'] as bool?) ?? false;
      final name   = isExtra ? '  + ${item.productName}' : item.productName;
      buf.writeln(name);
      buf.writeln('  ${item.qty}x Rp ${_f(item.unitPrice)}  =  Rp ${_f(item.subtotal)}');
    }

    buf.writeln('');
    if (_tx!.discountAmount > 0) {
      buf.writeln('Subtotal   : Rp ${_f(_tx!.totalAmount)}');
      buf.writeln('Diskon     : -Rp ${_f(_tx!.discountAmount)}');
    }
    buf.writeln('*TOTAL     : Rp ${_f(_tx!.grandTotal)}*');
    buf.writeln('Bayar      : Rp ${_f(_tx!.amountPaid)}');
    if (_tx!.changeAmount > 0) {
      buf.writeln('Kembali    : Rp ${_f(_tx!.changeAmount)}');
    }
    buf.writeln('');
    if (_footer.isNotEmpty) buf.writeln(_footer);
    buf.writeln('Terima kasih sudah menggunakan jasa servis kami! -');

    return buf.toString();
  }

  Future<void> _shareToWhatsapp() async {
    final text = _buildStrukText();
    final phone = _tx?.customerId != null
        ? await _getCustomerPhone(_tx!.customerId!)
        : null;

    if (phone != null && phone.isNotEmpty) {
      // Format nomor: hilangkan +62 atau 0 di depan, ganti jadi 62
      String num = phone.replaceAll(RegExp(r'[^0-9]'), '');
      if (num.startsWith('0')) num = '62${num.substring(1)}';
      if (!num.startsWith('62')) num = '62$num';

      final encoded = Uri.encodeComponent(text);
      final url = Uri.parse('https://wa.me/$num?text=$encoded');
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
        return;
      }
    }

    // Fallback: buka WA tanpa nomor (user pilih sendiri)
    final encoded = Uri.encodeComponent(text);
    final url = Uri.parse('https://wa.me/?text=$encoded');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  Future<String?> _getCustomerPhone(int customerId) async {
    final customer = await DBHelper.instance.getAllCustomers();
    final found = customer.where((c) => c.id == customerId).toList();
    return found.isNotEmpty ? found.first.phone : null;
  }
*/

//  STEP 3: tambah tombol WA di build()
// Cari bagian action buttons di PesananBerhasilScreen atau di
// StrukScreen bagian bawah, tambahkan:
/*
  Widget _buildWaButton() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: _tx == null ? null : _shareToWhatsapp,
        icon: const Icon(Icons.whatsapp, color: Color(0xFF25D366)),
        label: const Text(
          'Kirim ke WhatsApp',
          style: TextStyle(color: Color(0xFF25D366), fontWeight: FontWeight.w600),
        ),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 14),
          side: const BorderSide(color: Color(0xFF25D366), width: 1.5),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      ),
    );
  }
*/

//
// WhatsApp Share Helper  bisa digunakan dari mana saja di app
//
// ignore_for_file: unused_import
import 'dart:io';

import 'package:url_launcher/url_launcher.dart';

class WhatsAppHelper {
  /// Buka WhatsApp dengan pesan yang sudah diisi.
  /// [phone] opsional (dengan atau tanpa +62).
  static Future<bool> sendMessage({
    required String message,
    String? phone,
  }) async {
    String num = '';
    if (phone != null && phone.isNotEmpty) {
      num = phone.replaceAll(RegExp(r'[^0-9]'), '');
      if (num.startsWith('0')) num = '62${num.substring(1)}';
      if (!num.startsWith('62')) num = '62$num';
    }

    final encoded = Uri.encodeComponent(message);

    Future<bool> tryLaunch(
      Uri uri, {
      LaunchMode mode = LaunchMode.externalApplication,
    }) async {
      try {
        return await launchUrl(uri, mode: mode);
      } catch (_) {
        return false;
      }
    }

    Future<bool> tryOpenWindowsUrl(Uri uri) async {
      if (!Platform.isWindows) return false;
      try {
        final result = await Process.run(
          'rundll32.exe',
          ['url.dll,FileProtocolHandler', uri.toString()],
        );
        if (result.exitCode == 0) return true;
      } catch (_) {
        // Fallback to url_launcher below.
      }
      return tryLaunch(uri, mode: LaunchMode.platformDefault);
    }

    if (Platform.isWindows || Platform.isMacOS || Platform.isLinux) {
      final desktopUri = Uri.parse(num.isNotEmpty
          ? 'whatsapp://send?phone=$num&text=$encoded'
          : 'whatsapp://send?text=$encoded');
      if (Platform.isWindows) {
        if (await tryOpenWindowsUrl(desktopUri)) return true;
      } else if (await canLaunchUrl(desktopUri) &&
          await tryLaunch(desktopUri, mode: LaunchMode.platformDefault)) {
        return true;
      }

      final webUri = Uri.parse(num.isNotEmpty
          ? 'https://web.whatsapp.com/send?phone=$num&text=$encoded'
          : 'https://web.whatsapp.com/send?text=$encoded');
      if (await tryLaunch(webUri)) return true;

      final waMeUri = Uri.parse(num.isNotEmpty
          ? 'https://wa.me/$num?text=$encoded'
          : 'https://wa.me/?text=$encoded');
      return tryLaunch(waMeUri);
    }

    final waMeUri = Uri.parse(num.isNotEmpty
        ? 'https://wa.me/$num?text=$encoded'
        : 'https://wa.me/?text=$encoded');
    if (await tryLaunch(waMeUri)) return true;

    // Pada cold start Android/iOS, handler WhatsApp kadang belum siap pada
    // percobaan pertama. Beri waktu singkat sebelum mencoba skema aplikasi.
    await Future<void>.delayed(const Duration(milliseconds: 350));
    final appUri = Uri.parse(num.isNotEmpty
        ? 'whatsapp://send?phone=$num&text=$encoded'
        : 'whatsapp://send?text=$encoded');
    if (await tryLaunch(appUri)) return true;

    final apiUri = Uri.parse(num.isNotEmpty
        ? 'https://api.whatsapp.com/send?phone=$num&text=$encoded'
        : 'https://api.whatsapp.com/send?text=$encoded');
    return tryLaunch(apiUri);
  }

  /// Format teks struk dari data transaksi
  static String buildStrukText({
    required String namaWarung,
    required String noTransaksi,
    required String tanggal,
    required String kasirName,
    required String alamat,
    required String telepon,
    required String footer,
    required List<Map<String, dynamic>> items,
    required int totalAmount,
    required int discountAmount,
    required int grandTotal,
    required int amountPaid,
    required int changeAmount,
  }) {
    String fRp(int n) {
      if (n == 0) return '0';
      String s = n.toString(), r = '';
      int c = 0;
      for (int i = s.length - 1; i >= 0; i--) {
        r = s[i] + r;
        c++;
        if (c % 3 == 0 && i != 0) r = '.$r';
      }
      return r;
    }

    String fQty(dynamic value) {
      final qty = value is num
          ? value.toDouble()
          : double.tryParse(value.toString().replaceAll(',', '.')) ?? 0;
      return qty
          .toStringAsFixed(2)
          .replaceAll(RegExp(r'0+$'), '')
          .replaceAll(RegExp(r'\.$'), '')
          .replaceAll('.', ',');
    }

    final buf = StringBuffer();
    buf.writeln('Halo 👋, ini adalah e-Receipt dari *$namaWarung*.');
    buf.writeln('Terima kasih telah menggunakan layanan kami.');
    buf.writeln('');
    buf.writeln('🧾 *DETAIL TRANSAKSI*');
    buf.writeln('--------------------------------');
    buf.writeln('No. Invoice : $noTransaksi');
    buf.writeln('Tanggal     : $tanggal');
    if (kasirName.isNotEmpty) buf.writeln('Kasir       : $kasirName');
    buf.writeln('--------------------------------');
    buf.writeln('');

    for (final row in items) {
      final name = row['name'] as String;
      final qty = fQty(row['qty']);
      final price = row['price'] as int;
      final sub = row['subtotal'] as int;
      buf.writeln('🔸 *$name*');
      buf.writeln('   ${qty}x Rp ${fRp(price)} = Rp ${fRp(sub)}');
    }

    buf.writeln('');
    buf.writeln('--------------------------------');
    if (discountAmount > 0) {
      buf.writeln('Subtotal    : Rp ${fRp(totalAmount)}');
      buf.writeln('Diskon      : -Rp ${fRp(discountAmount)}');
    }
    buf.writeln('*TOTAL TAGIHAN : Rp ${fRp(grandTotal)}*');
    buf.writeln('--------------------------------');
    buf.writeln('Bayar       : Rp ${fRp(amountPaid)}');
    if (changeAmount > 0) buf.writeln('Kembali     : Rp ${fRp(changeAmount)}');
    buf.writeln('');
    if (footer.isNotEmpty) {
      buf.writeln('📌 $footer');
      buf.writeln('');
    }
    buf.writeln('Terima kasih dan ditunggu kedatangannya kembali! ✨');

    return buf.toString();
  }

  /// Format pesan status servis (misal: Selesai / Siap Ambil)
  static String buildservisStatusMessage({
    required String namaWarung,
    required String customerName,
    required String noTransaksi,
    required String status,
    required int grandTotal,
    required String paymentStatus,
  }) {
    String fRp(int n) {
      if (n == 0) return '0';
      String s = n.toString(), r = '';
      int c = 0;
      for (int i = s.length - 1; i >= 0; i--) {
        r = s[i] + r;
        c++;
        if (c % 3 == 0 && i != 0) r = '.$r';
      }
      return r;
    }

    final normalizedPaymentStatus = paymentStatus.trim().toLowerCase();
    final isPaid = normalizedPaymentStatus == 'lunas' ||
        normalizedPaymentStatus == 'paid' ||
        normalizedPaymentStatus == 'sudah lunas';

    final buf = StringBuffer();
    buf.writeln('Halo Kak *$customerName* 👋,');
    buf.writeln('');
    buf.writeln(
        'Terima kasih telah mempercayakan perbaikan perangkat Anda kepada *$namaWarung*.');
    buf.writeln('Berikut ini adalah rincian pesanan servis Anda:');
    buf.writeln('');
    buf.writeln('🧾 *No. Invoice:* $noTransaksi');
    buf.writeln('🏷️ *Status Servis:* ${status.toUpperCase()}');
    buf.writeln('💳 *Status Pembayaran:* ${paymentStatus.toUpperCase()}');
    if (!isPaid) {
      buf.writeln('💰 *Total Tagihan:* Rp ${fRp(grandTotal)}');
    }
    buf.writeln('');

    if (status.toLowerCase() == 'siap ambil') {
      buf.writeln('Pesanan Kakak sudah selesai dikerjakan dan *SIAP DIAMBIL*.');
      buf.writeln('Ditunggu kedatangannya ya Kak.');
    } else {
      buf.writeln('Pesanan Kakak saat ini sedang dalam proses *$status*.');
      buf.writeln(
          'Kami akan mengirimkan notifikasi kembali setelah pesanan Kakak selesai.');
    }
    buf.writeln('');
    buf.writeln(
        'Untuk mengecek status pesanan atau jika ada pertanyaan lebih lanjut, jangan ragu untuk membalas pesan ini. Kami siap melayani Anda.');
    buf.writeln('');
    buf.writeln('Terima kasih dan semoga hari Kakak menyenangkan! ✨');

    return buf.toString();
  }
}

