import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:intl/intl.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import 'dart:io';
import 'package:file_picker/file_picker.dart';

class MasterReportService {
  MasterReportService._();

  static const _brand = PdfColor.fromInt(0xFF2563EB);
  static const _brandLight = PdfColor.fromInt(0xFFEFF6FF);
  static const _ink = PdfColor.fromInt(0xFF0F172A);
  static const _muted = PdfColor.fromInt(0xFF64748B);
  static const _line = PdfColor.fromInt(0xFFE2E8F0);
  static const _paper = PdfColor.fromInt(0xFFF8FAFC);
  static const _success = PdfColor.fromInt(0xFF059669);
  static const _warning = PdfColor.fromInt(0xFFF59E0B);
  static const _danger = PdfColor.fromInt(0xFFDC2626);
  static const _accent = PdfColor.fromInt(0xFF7C3AED);

  static const _chartColors = <PdfColor>[
    _brand,
    _success,
    _warning,
    _danger,
    _accent,
    PdfColor.fromInt(0xFF0F766E),
  ];

  static String _fRp(int n) {
    if (n == 0) return 'Rp 0';
    final neg = n < 0;
    String s = n.abs().toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return 'Rp ${neg ? '-' : ''}$r';
  }

  static Future<void> generateAndShare({
    required int year,
    required int month,
    bool isPrint = false,
  }) async {
    final font = await PdfGoogleFonts.robotoRegular();
    final fontBold = await PdfGoogleFonts.robotoBold();
    final doc = pw.Document(
      theme: pw.ThemeData.withFont(
        base: font,
        bold: fontBold,
      ),
    );
    final db = DBHelper.instance;

    // 1. Fetch Data
    final warung = await db.getWarungProfile();
    final storeName = (warung['nama'] ?? 'Juragan Servis').toUpperCase();
    final storeAddr = warung['alamat'] ?? '';

    final periodName =
        DateFormat('MMMM yyyy', 'id').format(DateTime(year, month));
    final startDate = DateTime(year, month, 1);
    final endDate =
        month == 12 ? DateTime(year + 1, 1, 1) : DateTime(year, month + 1, 1);

    final summary = await db.getLabaRugiBulan(year, month);
    final inventory = await db.getInventoryAnalysis();
    final topProducts = await db
        .getTopSellingProductsByDateRange(startDate, endDate, limit: 10);
    final walletTunai = await db.getWalletBalance(walletId: 'tunai');
    final walletNonTunai = await db.getWalletBalance(walletId: 'non_tunai');
    final topCustomers = await db.getTopCustomers(limit: 5);
    final totalCustomers = await db.getTotalCustomerCount();

    // BI Data
    final dailySales = await db.getDailySalesSummary(year, month);
    final paymentMethods = await db.getSalesByPaymentMethod(year, month);
    final inventoryValuation = await db.getInventoryValuationByCategory();
    final supplierDebt = await db.getSupplierDebtSummary();
    final deletedTransactions = await db.getDeletedTransactions();

    // 2. Build PDF Layout
    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        header: (context) => _buildHeader(storeName, storeAddr, periodName),
        footer: (context) => _buildFooter(context),
        build: (context) => [
          // Section 1: Executive Summary
          _buildSectionTitle('RINGKASAN EKSEKUTIF'),
          pw.SizedBox(height: 12),
          _buildKpiGrid([
            _KpiData('Omzet Bersih', _fRp(summary['omzet'] ?? 0), _brand),
            _KpiData('Laba Bersih', _fRp(summary['laba_bersih'] ?? 0), _brand),
            _KpiData('Biaya Operasional', _fRp(summary['pengeluaran'] ?? 0),
                PdfColors.orange800),
            _KpiData('Total Aset Stok', _fRp(inventory['total_value'] ?? 0),
                PdfColors.blue800),
          ]),
          pw.SizedBox(height: 18),
          _buildSectionTitle('VISUALISASI KINERJA BISNIS'),
          pw.SizedBox(height: 8),
          _buildStrategicCharts(
            summary: summary,
            paymentMethods: paymentMethods,
            topProducts: topProducts,
            dailySales: dailySales,
          ),
          pw.SizedBox(height: 24),

          // Section 2: Keuangan Detail
          _buildSectionTitle('ANALISIS KEUANGAN & LABA RUGI'),
          pw.SizedBox(height: 8),
          _buildDetailTable(
            headers: ['Keterangan', 'Nilai'],
            rows: [
              ['Omzet Kotor Servis', _fRp(summary['omzet_kotor'] ?? 0)],
              ['Refund / Retur Servis', _fRp(summary['retur_penjualan'] ?? 0)],
              ['Omzet Bersih Servis', _fRp(summary['omzet'] ?? 0)],
              ['HPP / Bahan Baku Terpakai', _fRp(summary['hpp'] ?? 0)],
              ['Laba Kotor (Gross Profit)', _fRp(summary['laba_kotor'] ?? 0)],
              ['Total Biaya Operasional', _fRp(summary['pengeluaran'] ?? 0)],
              ['Laba Bersih (Net Profit)', _fRp(summary['laba_bersih'] ?? 0)],
              [
                'Pembelian Stok/Aset (bukan beban)',
                _fRp(summary['pembelian_stok'] ?? 0)
              ],
              ['Posisi Kas Tunai (Wallet)', _fRp(walletTunai)],
              ['Posisi Kas Bank/Digital', _fRp(walletNonTunai)],
            ],
          ),
          pw.SizedBox(height: 24),

          // Section 3: Tren Penjualan Harian
          if (dailySales.isNotEmpty) ...[
            _buildSectionTitle('TREN PENJUALAN HARIAN'),
            pw.SizedBox(height: 8),
            _buildDetailTable(
              headers: ['Tanggal', 'Transaksi', 'Omzet'],
              rows: dailySales
                  .map((d) => [
                        d['date'].toString(),
                        '${d['transaction_count']} Trx',
                        _fRp(d['total_sales'] as int? ?? 0),
                      ])
                  .toList(),
            ),
            pw.SizedBox(height: 24),
          ],

          // Section 4: Distribusi Pembayaran
          if (paymentMethods.isNotEmpty) ...[
            _buildSectionTitle('DISTRIBUSI METODE PEMBAYARAN'),
            pw.SizedBox(height: 8),
            _buildDetailTable(
              headers: ['Metode', 'Total Omzet'],
              rows: paymentMethods.entries
                  .map((e) => [
                        e.key,
                        _fRp(e.value),
                      ])
                  .toList(),
            ),
            pw.SizedBox(height: 24),
          ],

          // Section 5: Performa Produk
          _buildSectionTitle('TOP 10 LAYANAN TERLARIS'),
          pw.SizedBox(height: 8),
          _buildDetailTable(
            headers: ['Nama Layanan', 'Total'],
            rows: topProducts
                .map((p) => [
                      (p['name'] ?? '-').toString(),
                      '${p['total_sold']} ${p['unit'] ?? 'pcs'}'
                    ])
                .toList(),
          ),
          pw.SizedBox(height: 24),

          // Section 6: Inventori & Valuasi
          _buildSectionTitle('VALUASI LAYANAN & ITEM PER KATEGORI'),
          pw.SizedBox(height: 8),
          _buildDetailTable(
            headers: ['Kategori', 'Jumlah Layanan', 'Total Qty', 'Nilai Aset'],
            rows: inventoryValuation
                .map((v) => [
                      v['category_name'].toString(),
                      '${v['sku_count']} Item',
                      '${v['total_qty']}',
                      _fRp(v['total_valuation'] as int? ?? 0),
                    ])
                .toList(),
          ),
          pw.SizedBox(height: 12),
          if (inventory['low_stock_list'] != null &&
              (inventory['low_stock_list'] as List).isNotEmpty) ...[
            pw.Text('Daftar Stok Menipis (Segera Restock):',
                style: pw.TextStyle(
                    fontWeight: pw.FontWeight.bold,
                    fontSize: 10,
                    color: PdfColors.red800)),
            pw.SizedBox(height: 6),
            _buildDetailTable(
              headers: ['Nama Layanan/Item', 'Stok', 'Min. Stok'],
              rows: (inventory['low_stock_list'] as List).take(15).map((p) {
                final prod = p as Product;
                return [
                  prod.name,
                  '${prod.stock} ${prod.unit}',
                  '${prod.minStock} ${prod.unit}',
                ];
              }).toList(),
            ),
          ],
          pw.SizedBox(height: 24),

          // Section 7: Audit Hutang & Pelanggan
          _buildSectionTitle('PELANGGAN & HUTANG SUPPLIER'),
          pw.SizedBox(height: 8),
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text('Terhutang ke Supplier:',
                        style: pw.TextStyle(
                            fontWeight: pw.FontWeight.bold, fontSize: 10)),
                    pw.SizedBox(height: 4),
                    if (supplierDebt.isEmpty)
                      pw.Text('Tidak ada hutang aktif.',
                          style: const pw.TextStyle(
                              fontSize: 9, color: PdfColors.grey700))
                    else
                      _buildDetailTable(
                        headers: ['Supplier', 'Saldo Hutang'],
                        rows: supplierDebt
                            .map((s) => [
                                  s['name'].toString(),
                                  _fRp(s['hutang'] as int? ?? 0),
                                ])
                            .toList(),
                      ),
                  ],
                ),
              ),
              pw.SizedBox(width: 20),
              pw.Expanded(
                  child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                    pw.Text('Statistik Pelanggan',
                        style: pw.TextStyle(
                            fontWeight: pw.FontWeight.bold, fontSize: 10)),
                    pw.SizedBox(height: 4),
                    pw.Bullet(
                        text: 'Total Pelanggan Terdaftar: $totalCustomers'),
                    pw.SizedBox(height: 8),
                    if (topCustomers.isNotEmpty) ...[
                      pw.Text('Top 5 Pelanggan (Omzet Tertinggi):',
                          style: pw.TextStyle(
                              fontWeight: pw.FontWeight.bold, fontSize: 10)),
                      _buildDetailTable(
                        headers: ['Nama', 'Total Belanja'],
                        rows: topCustomers
                            .map((c) => [
                                  (c['customer_name'] ?? '-').toString(),
                                  _fRp(c['total_spending'] as int? ?? 0),
                                ])
                            .toList(),
                      ),
                    ]
                  ])),
            ],
          ),
          pw.SizedBox(height: 24),

          // Section 8: Audit Log (Keamanan)
          if (deletedTransactions.isNotEmpty) ...[
            _buildSectionTitle('AUDIT LOG: TRANSAKSI DIHAPUS (90 HARI)'),
            pw.SizedBox(height: 8),
            _buildDetailTable(
              headers: ['Tanggal', 'Pelanggan', 'Total', 'Status'],
              rows: deletedTransactions
                  .map((t) => [
                        t.createdAt,
                        t.customerName ?? '-',
                        _fRp(t.grandTotal),
                        'HAPUS'
                      ])
                  .toList(),
            ),
          ],
        ],
      ),
    );

    // 3. Output
    final bytes = await doc.save();
    final filename = 'Laporan_Komprehensif_${year}_$month.pdf';

    if (isPrint) {
      await Printing.layoutPdf(
          onLayout: (format) async => bytes, name: filename);
    } else {
      if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
        String? outputFile = await FilePicker.platform.saveFile(
          dialogTitle: 'Simpan Laporan Komprehensif',
          fileName: filename,
          type: FileType.custom,
          allowedExtensions: ['pdf'],
        );
        if (outputFile != null) {
          final file = File(outputFile);
          await file.writeAsBytes(bytes);
        }
      } else {
        await Printing.sharePdf(bytes: bytes, filename: filename);
      }
    }
  }

  static pw.Widget _buildHeader(String name, String addr, String period) {
    return pw.Column(
      children: [
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('LAPORAN STRATEGIS BISNIS',
                    style: pw.TextStyle(
                        fontSize: 20,
                        fontWeight: pw.FontWeight.bold,
                        color: _brand)),
                pw.Text('Periode Analisis: $period',
                    style: const pw.TextStyle(
                        fontSize: 12, color: PdfColors.grey700)),
              ],
            ),
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.end,
              children: [
                pw.Text(name,
                    style: pw.TextStyle(
                        fontSize: 14,
                        fontWeight: pw.FontWeight.bold,
                        color: _brand)),
                if (addr.isNotEmpty)
                  pw.Container(
                    width: 200,
                    child: pw.Text(addr,
                        textAlign: pw.TextAlign.right,
                        style: const pw.TextStyle(
                            fontSize: 9, color: PdfColors.grey600)),
                  ),
              ],
            ),
          ],
        ),
        pw.SizedBox(height: 10),
        pw.Divider(color: _brand, thickness: 2),
        pw.SizedBox(height: 20),
      ],
    );
  }

  static pw.Widget _buildFooter(pw.Context context) {
    return pw.Container(
      alignment: pw.Alignment.centerRight,
      margin: const pw.EdgeInsets.only(top: 10),
      padding: const pw.EdgeInsets.only(top: 8),
      decoration: const pw.BoxDecoration(
        border: pw.Border(top: pw.BorderSide(color: PdfColors.grey200)),
      ),
      child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(
                'Dicetak Otomatis pada: ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())}',
                style:
                    const pw.TextStyle(fontSize: 7, color: PdfColors.grey500)),
            pw.Text(
              'Halaman ${context.pageNumber} dari ${context.pagesCount} | Juragan Servis Business Intelligence Suite',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
            ),
          ]),
    );
  }

  static pw.Widget _buildSectionTitle(String title) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: const pw.BoxDecoration(
        color: _brand,
        borderRadius: pw.BorderRadius.all(pw.Radius.zero),
      ),
      child: pw.Text(title,
          style: pw.TextStyle(
              fontSize: 11,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.white,
              letterSpacing: 0.5)),
    );
  }

  static pw.Widget _buildKpiGrid(List<_KpiData> data,
      {double itemWidth = 110}) {
    return pw.Wrap(
      spacing: 12,
      runSpacing: 12,
      children: data
          .map((d) => pw.Container(
                width: itemWidth,
                padding: const pw.EdgeInsets.all(12),
                decoration: pw.BoxDecoration(
                  color: PdfColors.white,
                  borderRadius: const pw.BorderRadius.all(pw.Radius.zero),
                  border: pw.Border.all(color: d.color, width: 1.5),
                ),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(d.label,
                        style: const pw.TextStyle(
                            fontSize: 8, color: PdfColors.grey700)),
                    pw.SizedBox(height: 6),
                    pw.Text(d.value,
                        style: pw.TextStyle(
                            fontSize: 11,
                            fontWeight: pw.FontWeight.bold,
                            color: d.color)),
                  ],
                ),
              ))
          .toList(),
    );
  }

  static pw.Widget _buildStrategicCharts({
    required Map<String, int> summary,
    required Map<String, int> paymentMethods,
    required List<Map<String, dynamic>> topProducts,
    required List<Map<String, dynamic>> dailySales,
  }) {
    final financeData = [
      _ChartEntry('Omzet', (summary['omzet'] ?? 0).toDouble(), _brand),
      _ChartEntry('HPP', (summary['hpp'] ?? 0).toDouble(), _warning),
      _ChartEntry('Biaya Operasional', (summary['pengeluaran'] ?? 0).toDouble(),
          _danger),
      _ChartEntry(
        'Laba Bersih',
        (summary['laba_bersih'] ?? 0).toDouble(),
        (summary['laba_bersih'] ?? 0) >= 0 ? _success : _danger,
      ),
    ];

    final distributionData = paymentMethods.isNotEmpty
        ? paymentMethods.entries
            .map((e) => _ChartEntry(e.key, e.value.toDouble(), _brand))
            .toList()
        : topProducts
            .take(6)
            .map((p) => _ChartEntry(
                  (p['name'] ?? '-').toString(),
                  _asDouble(p['total_sold']),
                  _brand,
                ))
            .toList();

    final trendData = dailySales
        .take(16)
        .map((d) => _ChartEntry(
              d['date'].toString(),
              _asDouble(d['total_sales']),
              _brand,
            ))
        .where((entry) => entry.value.abs() > 0)
        .toList();

    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Expanded(
              child: _buildBarChartPanel(
                title: 'Komposisi Keuangan',
                subtitle: 'Omzet, biaya, dan laba bersih',
                entries: financeData,
                currency: true,
              ),
            ),
            pw.SizedBox(width: 12),
            pw.Expanded(
              child: _buildPieChartPanel(
                title: paymentMethods.isNotEmpty
                    ? 'Metode Pembayaran'
                    : 'Layanan Terlaris',
                subtitle: paymentMethods.isNotEmpty
                    ? 'Distribusi omzet per metode'
                    : 'Distribusi penjualan layanan',
                entries: distributionData,
                currency: paymentMethods.isNotEmpty,
              ),
            ),
          ],
        ),
        if (trendData.isNotEmpty) ...[
          pw.SizedBox(height: 12),
          _buildTrendPanel(trendData),
        ],
      ],
    );
  }

  static pw.Widget _buildBarChartPanel({
    required String title,
    required String subtitle,
    required List<_ChartEntry> entries,
    required bool currency,
  }) {
    final maxValue = entries.fold<double>(
      0,
      (max, entry) => mathMax(max, entry.value.abs()),
    );

    return pw.Container(
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        color: PdfColors.white,
        border: pw.Border.all(color: _line),
        borderRadius: const pw.BorderRadius.all(pw.Radius.circular(5)),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          _buildChartPanelHeader(title, subtitle),
          pw.SizedBox(height: 10),
          ...entries.map((entry) {
            final ratio = maxValue <= 0 ? 0.0 : entry.value.abs() / maxValue;
            return pw.Padding(
              padding: const pw.EdgeInsets.only(bottom: 8),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    children: [
                      pw.Text(entry.label,
                          style: const pw.TextStyle(fontSize: 8, color: _ink)),
                      pw.Text(
                        currency
                            ? _fRp(entry.value.toInt())
                            : _fNumber(entry.value),
                        style: pw.TextStyle(
                          fontSize: 8,
                          color: entry.value < 0 ? _danger : _ink,
                          fontWeight: pw.FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  pw.SizedBox(height: 3),
                  pw.Container(
                    width: 190,
                    height: 6,
                    decoration: const pw.BoxDecoration(
                      color: _line,
                      borderRadius: pw.BorderRadius.all(pw.Radius.circular(3)),
                    ),
                    child: pw.Row(
                      children: [
                        pw.Container(
                          width: 190 * ratio.clamp(0.0, 1.0),
                          height: 6,
                          decoration: pw.BoxDecoration(
                            color: entry.color,
                            borderRadius: const pw.BorderRadius.all(
                              pw.Radius.circular(3),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  static pw.Widget _buildPieChartPanel({
    required String title,
    required String subtitle,
    required List<_ChartEntry> entries,
    required bool currency,
  }) {
    final filtered = entries.where((entry) => entry.value.abs() > 0).toList();
    final total =
        filtered.fold<double>(0, (sum, entry) => sum + entry.value.abs());

    return pw.Container(
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        color: PdfColors.white,
        border: pw.Border.all(color: _line),
        borderRadius: const pw.BorderRadius.all(pw.Radius.circular(5)),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          _buildChartPanelHeader(title, subtitle),
          pw.SizedBox(height: 10),
          if (filtered.isEmpty)
            pw.Container(
              height: 126,
              alignment: pw.Alignment.center,
              decoration: const pw.BoxDecoration(color: _paper),
              child: pw.Text('Belum ada data grafik',
                  style: const pw.TextStyle(fontSize: 9, color: _muted)),
            )
          else
            pw.Row(
              children: [
                pw.Container(
                  width: 112,
                  height: 112,
                  padding: const pw.EdgeInsets.all(6),
                  decoration: const pw.BoxDecoration(
                    color: _paper,
                    borderRadius: pw.BorderRadius.all(pw.Radius.circular(5)),
                  ),
                  child: pw.Chart(
                    grid: pw.PieGrid(),
                    datasets: filtered.asMap().entries.map((entry) {
                      final index = entry.key;
                      final item = entry.value;
                      return pw.PieDataSet(
                        value: item.value.abs(),
                        legend: item.label,
                        color: _chartColor(index),
                      );
                    }).toList(),
                  ),
                ),
                pw.SizedBox(width: 10),
                pw.Expanded(
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: filtered.asMap().entries.map((entry) {
                      final index = entry.key;
                      final item = entry.value;
                      final percent =
                          total <= 0 ? 0.0 : item.value.abs() / total * 100;
                      return pw.Padding(
                        padding: const pw.EdgeInsets.only(bottom: 5),
                        child: pw.Row(
                          children: [
                            pw.Container(
                              width: 7,
                              height: 7,
                              color: _chartColor(index),
                            ),
                            pw.SizedBox(width: 5),
                            pw.Expanded(
                              child: pw.Text(
                                _compact(item.label, 18),
                                maxLines: 1,
                                style: const pw.TextStyle(
                                    fontSize: 7.5, color: _ink),
                              ),
                            ),
                            pw.Text(
                              currency
                                  ? _fRp(item.value.toInt())
                                  : '${percent.toStringAsFixed(1)}%',
                              style: const pw.TextStyle(
                                  fontSize: 7.5, color: _muted),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  static pw.Widget _buildTrendPanel(List<_ChartEntry> entries) {
    final maxValue =
        entries.fold<double>(0, (max, entry) => mathMax(max, entry.value));

    return pw.Container(
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        color: PdfColors.white,
        border: pw.Border.all(color: _line),
        borderRadius: const pw.BorderRadius.all(pw.Radius.circular(5)),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          _buildChartPanelHeader(
            'Tren Omzet Harian',
            'Pergerakan omzet pada periode laporan',
          ),
          pw.SizedBox(height: 10),
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: entries.map((entry) {
              final ratio = maxValue <= 0 ? 0.0 : entry.value / maxValue;
              final barHeight = 72 * ratio.clamp(0.0, 1.0);
              return pw.Expanded(
                child: pw.Padding(
                  padding: const pw.EdgeInsets.symmetric(horizontal: 2),
                  child: pw.Column(
                    mainAxisAlignment: pw.MainAxisAlignment.end,
                    children: [
                      pw.Container(
                        height: barHeight,
                        decoration: const pw.BoxDecoration(
                          color: _brand,
                          borderRadius: pw.BorderRadius.only(
                            topLeft: pw.Radius.circular(3),
                            topRight: pw.Radius.circular(3),
                          ),
                        ),
                      ),
                      pw.SizedBox(height: 4),
                      pw.Text(
                        _compact(entry.label, 5),
                        maxLines: 1,
                        style: const pw.TextStyle(fontSize: 6, color: _muted),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildChartPanelHeader(String title, String subtitle) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(title,
            style: pw.TextStyle(
                fontSize: 10, fontWeight: pw.FontWeight.bold, color: _ink)),
        pw.SizedBox(height: 2),
        pw.Text(subtitle,
            style: const pw.TextStyle(fontSize: 7.5, color: _muted)),
      ],
    );
  }

  static pw.Widget _buildDetailTable({
    required List<String> headers,
    required List<List<String>> rows,
  }) {
    return pw.TableHelper.fromTextArray(
      headers: headers,
      data: rows,
      border: pw.TableBorder.all(color: PdfColors.grey200, width: 0.5),
      headerStyle: pw.TextStyle(
          fontWeight: pw.FontWeight.bold, color: _brand, fontSize: 8),
      headerDecoration: const pw.BoxDecoration(color: _brandLight),
      cellStyle: const pw.TextStyle(fontSize: 8, color: PdfColors.black),
      cellPadding: const pw.EdgeInsets.all(6),
      oddRowDecoration: const pw.BoxDecoration(color: PdfColors.grey50),
      headerAlignment: pw.Alignment.centerLeft,
      cellAlignment: pw.Alignment.centerLeft,
    );
  }

  static PdfColor _chartColor(int index) {
    return _chartColors[index % _chartColors.length];
  }

  static double _asDouble(Object? value) {
    if (value is num) {
      return value.toDouble();
    }
    return double.tryParse(value?.toString() ?? '') ?? 0;
  }

  static String _fNumber(num value) {
    final raw = value.round().toString();
    final buffer = StringBuffer();
    for (var i = 0; i < raw.length; i++) {
      final remaining = raw.length - i;
      buffer.write(raw[i]);
      if (remaining > 1 && remaining % 3 == 1) {
        buffer.write('.');
      }
    }
    return buffer.toString();
  }

  static String _compact(String value, int maxLength) {
    final trimmed = value.trim();
    if (trimmed.length <= maxLength) {
      return trimmed;
    }
    return '${trimmed.substring(0, maxLength - 3)}...';
  }

  static double mathMax(double a, double b) => a > b ? a : b;
}

class _KpiData {
  final String label;
  final String value;
  final PdfColor color;
  _KpiData(this.label, this.value, this.color);
}

class _ChartEntry {
  final String label;
  final double value;
  final PdfColor color;

  _ChartEntry(this.label, this.value, this.color);
}

