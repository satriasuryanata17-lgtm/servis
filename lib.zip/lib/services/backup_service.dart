import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

import 'package:url_launcher/url_launcher.dart';

import '../database/db_helper.dart';
import 'backup_crypto_service.dart';

class _NativeSignatureValidationResult {
  final String? error;
  final bool hasVerifiedSignature;

  const _NativeSignatureValidationResult._({
    required this.error,
    required this.hasVerifiedSignature,
  });

  const _NativeSignatureValidationResult.verified()
      : this._(error: null, hasVerifiedSignature: true);

  const _NativeSignatureValidationResult.legacy()
      : this._(error: null, hasVerifiedSignature: false);

  const _NativeSignatureValidationResult.invalid(String message)
      : this._(error: message, hasVerifiedSignature: false);
}

class BackupService {
  static const Duration updateBackupFreshness = Duration(hours: 24);

  static const String _backupPrefix = 'juraganservis_backup_';
  static const String _legacyBackupPrefix = 'juragankasir_backup_';
  static const String _preRestorePrefix = 'juraganservis_pre_restore_';
  static const String _legacyPreRestorePrefix = 'juragankasir_pre_restore_';
  static const String _lastBackupKey = 'last_backup_date';
  static const String _autoBackupEnabledKey = 'auto_backup_enabled';
  static const String _autoBackupFrequencyKey = 'auto_backup_frequency';
  static const String _backupPathKey = 'auto_backup_path';
  static const String _backupRetentionKey = 'auto_backup_retention';
  static const String _lastAutoBackupDateKey = 'last_auto_backup_date';
  static const int _minCompatibleVersion = 15;
  static const String autoFrequencyDaily = 'daily';
  static const String autoFrequencyWeekly = 'weekly';
  static const String autoFrequencyMonthly = 'monthly';
  static String? _documentsDirectoryOverride;

  static int get _currentVersion => DBHelper.schemaVersion;

  static bool requiresPassphrase(File file) {
    return file.path.split('.').last.toLowerCase() ==
        BackupCryptoService.encryptedExtension;
  }

  static void overrideDocumentsDirectoryForTesting(String? path) {
    _documentsDirectoryOverride = path;
  }

  static Future<Directory> _getDocumentsDirectory() async {
    final overridePath = _documentsDirectoryOverride;
    if (overridePath != null && overridePath.trim().isNotEmpty) {
      final directory = Directory(overridePath);
      await directory.create(recursive: true);
      return directory;
    }
    return getApplicationDocumentsDirectory();
  }

  static String _computeChecksum(String jsonData) {
    final dataBytes = utf8.encode(jsonData);
    return sha256.convert(dataBytes).toString();
  }

  static String _computeBytesChecksum(List<int> bytes) {
    return sha256.convert(bytes).toString();
  }

  static String _backupTimestamp(DateTime value) {
    return '${value.year}${value.month.toString().padLeft(2, '0')}${value.day.toString().padLeft(2, '0')}_'
        '${value.hour.toString().padLeft(2, '0')}${value.minute.toString().padLeft(2, '0')}${value.second.toString().padLeft(2, '0')}_'
        '${value.millisecond.toString().padLeft(3, '0')}';
  }

  static File _nativeSignatureFile(File backupFile) {
    return File('${backupFile.path}.sig');
  }

  static Future<void> _writeNativeBackupSignature(File backupFile) async {
    final bytes = await backupFile.readAsBytes();
    final signature = <String, dynamic>{
      'type': 'juraganservis_native_backup',
      'version': _currentVersion,
      'signed_at': DateTime.now().toIso8601String(),
      'file_name': backupFile.uri.pathSegments.isNotEmpty
          ? backupFile.uri.pathSegments.last
          : backupFile.path,
      'file_size': bytes.length,
      '_checksum_sha256': _computeBytesChecksum(bytes),
    };

    await _nativeSignatureFile(backupFile).writeAsString(
      const JsonEncoder.withIndent('  ').convert(signature),
      encoding: utf8,
    );
  }

  static const List<Map<String, String>> _portableMediaColumns = [
    {'table': 'products', 'column': 'image_path'},
    {'table': 'profil', 'column': 'foto_path'},
    {'table': 'warung_profile', 'column': 'logo_path'},
    {'table': 'payment_settings', 'column': 'qris_path'},
    {'table': 'wallet_transactions', 'column': 'foto_path'},
  ];

  static Future<Map<String, dynamic>> _buildPortableBackupPayload() async {
    final rawData = await DBHelper.instance.exportAllData();
    await _embedPortableMedia(rawData);
    return _buildBackupPayload(rawData);
  }

  static Future<void> _embedPortableMedia(Map<String, dynamic> data) async {
    final media = <Map<String, dynamic>>[];
    final embeddedPaths = <String>{};

    for (final spec in _portableMediaColumns) {
      final table = spec['table']!;
      final column = spec['column']!;
      final rows = data[table];
      if (rows is! List) continue;

      for (var i = 0; i < rows.length; i++) {
        final row = rows[i];
        if (row is! Map) continue;
        final rawPath = row[column]?.toString().trim() ?? '';
        if (rawPath.isEmpty || embeddedPaths.contains(rawPath)) continue;

        final file = File(rawPath);
        if (!await file.exists()) continue;

        try {
          final bytes = await file.readAsBytes();
          media.add({
            'table': table,
            'column': column,
            'row_id': row['id'],
            'row_index': i,
            'original_path': rawPath,
            'file_name': file.uri.pathSegments.isNotEmpty
                ? file.uri.pathSegments.last
                : 'media_${media.length + 1}',
            'size': bytes.length,
            'data_b64': base64Encode(bytes),
          });
          embeddedPaths.add(rawPath);
        } catch (e) {
          debugPrint('BackupService: gagal menyertakan media $rawPath: $e');
        }
      }
    }

    data['_media_files'] = media;
  }

  static Future<void> _restoreEmbeddedMedia(Map<String, dynamic> data) async {
    final media = data['_media_files'];
    if (media is! List || media.isEmpty) return;

    final docDir = await _getDocumentsDirectory();
    final mediaDir = Directory('${docDir.path}/Juragan Servis_Restored_Media');
    await mediaDir.create(recursive: true);

    for (var i = 0; i < media.length; i++) {
      final item = media[i];
      if (item is! Map) continue;

      final table = item['table']?.toString() ?? '';
      final column = item['column']?.toString() ?? '';
      final originalPath = item['original_path']?.toString() ?? '';
      final encoded = item['data_b64']?.toString() ?? '';
      if (table.isEmpty || column.isEmpty || encoded.isEmpty) continue;

      try {
        final bytes = base64Decode(encoded);
        final fileName = _safeMediaFileName(
          item['file_name']?.toString() ?? 'media_$i',
          i,
        );
        final restoredPath =
            '${mediaDir.path}${Platform.pathSeparator}$fileName';
        await File(restoredPath).writeAsBytes(bytes, flush: true);
        _remapMediaPath(
          data: data,
          table: table,
          column: column,
          rowId: item['row_id'],
          rowIndex: (item['row_index'] as num?)?.toInt(),
          originalPath: originalPath,
          restoredPath: restoredPath,
        );
      } catch (e) {
        debugPrint('BackupService: gagal restore media portable: $e');
      }
    }
  }

  static Future<void> restoreEmbeddedMediaForTesting(
    Map<String, dynamic> data,
  ) {
    return _restoreEmbeddedMedia(data);
  }

  static String _safeMediaFileName(String fileName, int index) {
    final cleaned = fileName
        .replaceAll(RegExp(r'[\\/:*?"<>|]'), '_')
        .replaceAll(RegExp(r'\s+'), '_')
        .trim();
    final name = cleaned.isEmpty ? 'media_$index' : cleaned;
    return '${DateTime.now().millisecondsSinceEpoch}_${index}_$name';
  }

  static void _remapMediaPath({
    required Map<String, dynamic> data,
    required String table,
    required String column,
    required dynamic rowId,
    required int? rowIndex,
    required String originalPath,
    required String restoredPath,
  }) {
    final rows = data[table];
    if (rows is! List) return;

    for (var i = 0; i < rows.length; i++) {
      final row = rows[i];
      if (row is! Map) continue;
      final sameId = rowId != null && row['id']?.toString() == rowId.toString();
      final sameIndex = rowIndex != null && rowIndex == i;
      final samePath = originalPath.isNotEmpty && row[column] == originalPath;
      if (sameId || sameIndex || samePath) {
        row[column] = restoredPath;
      }
    }
  }

  static Map<String, dynamic> _buildBackupPayload(Map<String, dynamic> data) {
    final payload = Map<String, dynamic>.from(data)
      ..['version'] = _currentVersion
      ..['app_version'] = _currentVersion
      ..['exported_at'] = DateTime.now().toIso8601String();

    final payloadJson = const JsonEncoder().convert(payload);
    payload['_checksum_sha256'] = _computeChecksum(payloadJson);
    return payload;
  }

  static Future<String> createBackupFile() async {
    final data = await _buildPortableBackupPayload();
    final jsonStr = const JsonEncoder.withIndent('  ').convert(data);

    final dir = await _getDocumentsDirectory();
    final now = DateTime.now();
    final fname =
        '$_backupPrefix${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}.json';
    final file = File('${dir.path}/$fname');
    await file.writeAsString(jsonStr, encoding: utf8);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_lastBackupKey, now.toIso8601String());
    return file.path;
  }

  static Future<String> createEncryptedPortableBackupFile({
    required String passphrase,
  }) async {
    final data = await _buildPortableBackupPayload();
    final payloadJson = const JsonEncoder().convert(data);
    final envelope = await BackupCryptoService.encryptJsonPayload(
      payloadJson: payloadJson,
      appVersion: _currentVersion,
      exportedAt:
          data['exported_at']?.toString() ?? DateTime.now().toIso8601String(),
      passphrase: passphrase,
    );

    final dir = await _getDocumentsDirectory();
    final now = DateTime.now();
    final fname =
        '$_backupPrefix${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}.${BackupCryptoService.encryptedExtension}';
    final file = File('${dir.path}/$fname');
    await file.writeAsString(
      const JsonEncoder.withIndent('  ').convert(envelope),
      encoding: utf8,
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_lastBackupKey, now.toIso8601String());
    return file.path;
  }

  static Future<void> shareEncryptedPortableBackup({
    required String passphrase,
  }) async {
    final path = await createEncryptedPortableBackupFile(
      passphrase: passphrase,
    );
    final xFile = XFile(
      path,
      mimeType: 'application/octet-stream',
      name: path.split(Platform.pathSeparator).last,
    );
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      final fname = path.split(Platform.pathSeparator).last;
      String? outputFile = await FilePicker.platform.saveFile(
        dialogTitle: 'Simpan Backup Terenkripsi',
        fileName: fname,
        type: FileType.custom,
        allowedExtensions: [BackupCryptoService.encryptedExtension],
      );
      if (outputFile != null) {
        await File(path).copy(outputFile);
      }
    } else {
      await SharePlus.instance.share(
        ShareParams(
          files: [xFile],
          subject: 'Backup Data Juragan Servis (Terenkripsi)',
          text:
              'Ini adalah file backup terenkripsi Juragan Servis. Simpan kata sandinya di tempat yang aman.',
        ),
      );
    }
  }

  static Future<String?> saveEncryptedPortableBackupToDownloads({
    required String passphrase,
  }) async {
    try {
      final data = await _buildPortableBackupPayload();
      final payloadJson = const JsonEncoder().convert(data);
      final envelope = await BackupCryptoService.encryptJsonPayload(
        payloadJson: payloadJson,
        appVersion: _currentVersion,
        exportedAt:
            data['exported_at']?.toString() ?? DateTime.now().toIso8601String(),
        passphrase: passphrase,
      );
      final jsonStr = const JsonEncoder.withIndent('  ').convert(envelope);
      final now = DateTime.now();
      final fname =
          '$_backupPrefix${_backupTimestamp(now)}.${BackupCryptoService.encryptedExtension}';

      if (Platform.isAndroid || Platform.isIOS) {
        final outputPath = await _saveBytesWithPicker(
          dialogTitle: 'Simpan File Backup Terenkripsi',
          fileName: fname,
          allowedExtensions: [BackupCryptoService.encryptedExtension],
          bytes: Uint8List.fromList(utf8.encode(jsonStr)),
        );
        if (outputPath == null) return null;

        await _markManualBackupSaved(now);
        return outputPath;
      }

      final outputPath = await FilePicker.platform.saveFile(
        dialogTitle: 'Simpan File Backup Terenkripsi',
        fileName: fname,
        type: FileType.custom,
        allowedExtensions: [BackupCryptoService.encryptedExtension],
      );

      if (outputPath == null) return null;

      final file = File(outputPath);
      await file.writeAsString(jsonStr, encoding: utf8);

      await _markManualBackupSaved(now);
      return file.path;
    } catch (e) {
      debugPrint('saveEncryptedPortableBackupToDownloads error: $e');
      return null;
    }
  }

  static Future<void> shareBackup(BuildContext context) async {
    try {
      final path = await createBackupFile();
      final xFile = XFile(
        path,
        mimeType: 'application/json',
        name: path.split(Platform.pathSeparator).last,
      );
      if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
        final fname = path.split(Platform.pathSeparator).last;
        String? outputFile = await FilePicker.platform.saveFile(
          dialogTitle: 'Simpan File Backup',
          fileName: fname,
          type: FileType.custom,
          allowedExtensions: ['json'],
        );
        if (outputFile != null) {
          await File(path).copy(outputFile);
        }
      } else {
        await SharePlus.instance.share(
          ShareParams(
            files: [xFile],
            subject: 'Backup Data Juragan Servis',
            text:
                'Ini adalah file backup data toko. Simpan di tempat yang aman agar data tidak hilang.',
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Gagal membuat backup. Silakan coba lagi.')),
        );
      }
    }
  }

  static Future<String?> saveBackupToDownloads() async {
    try {
      final data = await _buildPortableBackupPayload();
      final jsonStr = const JsonEncoder.withIndent('  ').convert(data);
      final now = DateTime.now();
      final fname = '$_backupPrefix${_backupTimestamp(now)}.json';

      if (Platform.isAndroid || Platform.isIOS) {
        final outputPath = await _saveBytesWithPicker(
          dialogTitle: 'Simpan File Backup',
          fileName: fname,
          allowedExtensions: const ['json'],
          bytes: Uint8List.fromList(utf8.encode(jsonStr)),
        );
        if (outputPath == null) return null;

        await _markManualBackupSaved(now);
        return outputPath;
      }

      // Professional way: Use FilePicker to let user choose where to save
      final outputPath = await FilePicker.platform.saveFile(
        dialogTitle: 'Simpan File Backup',
        fileName: fname,
        type: FileType.custom,
        allowedExtensions: ['json'],
      );

      if (outputPath == null) return null;

      final file = File(outputPath);
      await file.writeAsString(jsonStr, encoding: utf8);

      await _markManualBackupSaved(now);

      return file.path;
    } catch (e) {
      debugPrint('saveBackupToDownloads error: $e');
      return null;
    }
  }

  static Future<String?> saveNativeBackupWithPicker() async {
    final now = DateTime.now();
    final fileName = '$_backupPrefix${_backupTimestamp(now)}.db';

    if (Platform.isAndroid || Platform.isIOS) {
      final tempDir = await getTemporaryDirectory();
      final tempFile =
          File('${tempDir.path}${Platform.pathSeparator}$fileName');
      try {
        final ok = await DBHelper.instance.backupDatabaseTo(tempFile.path);
        if (!ok) return null;

        final outputPath = await _saveBytesWithPicker(
          dialogTitle: 'Simpan Backup Database',
          fileName: fileName,
          allowedExtensions: const ['db'],
          bytes: await tempFile.readAsBytes(),
        );
        if (outputPath == null) return null;

        await _markManualBackupSaved(now);
        return outputPath;
      } finally {
        try {
          if (await tempFile.exists()) await tempFile.delete();
        } catch (_) {}
      }
    }

    final outputPath = await FilePicker.platform.saveFile(
      dialogTitle: 'Simpan Backup Database',
      fileName: fileName,
      type: FileType.custom,
      allowedExtensions: const ['db'],
    );
    if (outputPath == null) return null;

    final ok = await DBHelper.instance.backupDatabaseTo(outputPath);
    if (!ok) return null;

    final targetFile = File(outputPath);
    try {
      await _writeNativeBackupSignature(targetFile);
    } catch (e) {
      debugPrint('saveNativeBackupWithPicker signature skipped: $e');
    }

    await _markManualBackupSaved(now);
    return outputPath;
  }

  static Future<String?> _saveBytesWithPicker({
    required String dialogTitle,
    required String fileName,
    required List<String> allowedExtensions,
    required Uint8List bytes,
  }) {
    return FilePicker.platform.saveFile(
      dialogTitle: dialogTitle,
      fileName: fileName,
      type: FileType.custom,
      allowedExtensions: allowedExtensions,
      bytes: bytes,
    );
  }

  static Future<void> _markManualBackupSaved(DateTime now) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_lastBackupKey, now.toIso8601String());
    await prefs.setString(_lastAutoBackupDateKey, now.toIso8601String());
  }

  static Future<List<File>> getLocalBackupFiles() async {
    try {
      final dir = await getBackupDirectory();
      final entities = await _safeListFiles(dir);

      final files = entities.whereType<File>().where((f) {
        try {
          if (!f.existsSync()) return false;
        } catch (_) {
          return false; // OS permission errors during exist check
        }
        final name = f.path.split(Platform.pathSeparator).last;
        // Include native backups, json backups, and emergency restore points
        return (name.startsWith(_backupPrefix) ||
                name.startsWith(_legacyBackupPrefix) ||
                name.startsWith(_preRestorePrefix) ||
                name.startsWith(_legacyPreRestorePrefix)) &&
            (name.endsWith('.db') ||
                name.endsWith('.json') ||
                name.endsWith('.${BackupCryptoService.encryptedExtension}'));
      }).toList();

      // Sort by modified date descending (newest first)
      files.sort((a, b) {
        try {
          // Additional safety check during sort
          if (!a.existsSync() || !b.existsSync()) return 0;
          return b.lastModifiedSync().compareTo(a.lastModifiedSync());
        } catch (_) {
          return 0;
        }
      });
      return files;
    } catch (e) {
      debugPrint('Error listing backups: $e');
      return [];
    }
  }

  static bool _hasLoggedPermissionWarning = false;

  static Future<List<FileSystemEntity>> _safeListFiles(
      Directory initialDir) async {
    try {
      if (!await initialDir.exists()) return [];
      return await initialDir.list().toList();
    } catch (e) {
      if (e.toString().contains('Permission denied') ||
          e.toString().contains('Access denied')) {
        if (!_hasLoggedPermissionWarning) {
          debugPrint(
              'BackupService: Access denied to ${initialDir.path}. Falling back to default app directory.');
          _hasLoggedPermissionWarning = true;
        }
        final docDir = await getApplicationDocumentsDirectory();
        final fallbackDir = Directory('${docDir.path}/Juragan Servis_Backups');
        if (!await fallbackDir.exists()) return [];
        return await fallbackDir.list().toList();
      }
      rethrow;
    }
  }

  static Future<void> deleteBackupFile(File file) async {
    if (await file.exists()) {
      await file.delete();
      // Also delete signature if exists
      final sig = _nativeSignatureFile(file);
      if (await sig.exists()) {
        await sig.delete();
      }
    }
  }

  /// Extracts metadata from backup file without restoring it
  static Future<Map<String, dynamic>> getBackupFileSummary(
    File file, {
    String? passphrase,
  }) async {
    final ext = file.path.split('.').last.toLowerCase();

    if (ext == 'json') {
      try {
        final jsonStr = await file.readAsString(encoding: utf8);
        final data = jsonDecode(jsonStr) as Map<String, dynamic>;
        return {
          'exported_at': data['exported_at'],
          'version': data['version'] ?? data['app_version'],
          'products': (data['products'] as List?)?.length ?? 0,
          'transactions': (data['transactions'] as List?)?.length ?? 0,
          'categories': (data['categories'] as List?)?.length ?? 0,
          'media_files': (data['_media_files'] as List?)?.length ?? 0,
          'type': 'JSON Portable',
        };
      } catch (_) {
        return {};
      }
    } else if (ext == BackupCryptoService.encryptedExtension) {
      try {
        final envelope = await _readJsonMap(file);
        if (!BackupCryptoService.looksLikeEncryptedEnvelope(envelope)) {
          return {};
        }

        if (passphrase == null || passphrase.trim().isEmpty) {
          return {
            'exported_at': BackupCryptoService.readExportedAt(envelope),
            'version': BackupCryptoService.readAppVersion(envelope),
            'type': 'JSON Portable (Terenkripsi)',
            'is_encrypted': true,
          };
        }

        final data = await BackupCryptoService.decryptJsonPayload(
          envelope: envelope,
          passphrase: passphrase,
        );
        return {
          'exported_at': data['exported_at'],
          'version': data['version'] ?? data['app_version'],
          'products': (data['products'] as List?)?.length ?? 0,
          'transactions': (data['transactions'] as List?)?.length ?? 0,
          'categories': (data['categories'] as List?)?.length ?? 0,
          'media_files': (data['_media_files'] as List?)?.length ?? 0,
          'type': 'JSON Portable (Terenkripsi)',
          'is_encrypted': true,
        };
      } catch (_) {
        return {};
      }
    } else if (ext == 'db') {
      Database? db;
      try {
        // Use singleInstance: false to avoid conflicts with main DB
        db = await openDatabase(file.path,
            readOnly: true, singleInstance: false);
        final nativeSignature = await _validateNativeSignature(file);
        final dbVersion = Sqflite.firstIntValue(
              await db.rawQuery('PRAGMA user_version;'),
            ) ??
            0;
        final nativeSignatureStatus = nativeSignature.error != null
            ? 'invalid'
            : (nativeSignature.hasVerifiedSignature ? 'verified' : 'legacy');
        final pCount = Sqflite.firstIntValue(
                await db.rawQuery('SELECT COUNT(*) FROM products')) ??
            0;
        final tCount = Sqflite.firstIntValue(
                await db.rawQuery('SELECT COUNT(*) FROM transactions')) ??
            0;
        final cCount = Sqflite.firstIntValue(
                await db.rawQuery('SELECT COUNT(*) FROM categories')) ??
            0;

        // Try to get signature info
        String? signedAt;
        final sigFile = _nativeSignatureFile(file);
        if (await sigFile.exists()) {
          try {
            final sig = jsonDecode(await sigFile.readAsString());
            signedAt = sig['signed_at'];
          } catch (_) {}
        }

        return {
          'exported_at': signedAt,
          'version': dbVersion > 0 ? dbVersion : null,
          'products': pCount,
          'transactions': tCount,
          'categories': cCount,
          'type': nativeSignatureStatus == 'verified'
              ? 'Native Database'
              : (nativeSignatureStatus == 'legacy'
                  ? 'Native Database (Legacy)'
                  : 'Native Database (Signature Bermasalah)'),
          'native_signature_status': nativeSignatureStatus,
          if (nativeSignature.error != null)
            'native_signature_error': nativeSignature.error,
        };
      } catch (e) {
        debugPrint('Error reading .db summary: $e');
        return {};
      } finally {
        await db?.close();
      }
    }
    return {};
  }

  static Future<Map<String, dynamic>> readBackupPayloadFromFile(
    File file, {
    String? passphrase,
  }) async {
    final ext = file.path.split('.').last.toLowerCase();
    if (ext == 'json') {
      return _readJsonMap(file);
    }
    if (ext == BackupCryptoService.encryptedExtension) {
      if (passphrase == null || passphrase.trim().isEmpty) {
        throw const FormatException(
          'Kata sandi backup terenkripsi wajib diisi.',
        );
      }
      final envelope = await _readJsonMap(file);
      return BackupCryptoService.decryptJsonPayload(
        envelope: envelope,
        passphrase: passphrase,
      );
    }
    throw const FormatException(
      'File backup tidak mendukung pembacaan payload langsung.',
    );
  }

  static Future<Map<String, dynamic>> _readJsonMap(File file) async {
    final content = await file.readAsString(encoding: utf8);
    final decoded = jsonDecode(content);
    if (decoded is! Map) {
      throw const FormatException('Isi file backup tidak valid.');
    }
    return decoded.map(
      (key, value) => MapEntry(key.toString(), value),
    );
  }

  static String? validateBackup(Map<String, dynamic> data) {
    if (!data.containsKey('exported_at') && !data.containsKey('categories')) {
      return 'File tidak valid: bukan file backup Juragan Servis.';
    }

    final backupVersion =
        data['version'] as int? ?? data['app_version'] as int? ?? 0;
    if (backupVersion < _minCompatibleVersion) {
      return 'File backup terlalu lama (versi $backupVersion). '
          'Versi minimum yang didukung adalah $_minCompatibleVersion.';
    }
    if (backupVersion > _currentVersion) {
      return 'File backup dari versi aplikasi yang lebih baru (v$backupVersion). '
          'Update aplikasi terlebih dahulu sebelum restore.';
    }

    final storedChecksum = data['_checksum_sha256'] as String?;
    if (storedChecksum == null || storedChecksum.trim().isEmpty) {
      return 'File backup JSON tidak memiliki checksum integritas.';
    }

    final payloadData = Map<String, dynamic>.from(data)
      ..remove('_checksum_sha256');
    final payloadJson = const JsonEncoder().convert(payloadData);
    final expectedChecksum = _computeChecksum(payloadJson);
    if (storedChecksum != expectedChecksum) {
      return 'Integritas file backup gagal diverifikasi. '
          'File mungkin telah dimodifikasi atau rusak.';
    }

    for (final table in DBHelper.requiredBackupTables) {
      if (data[table] is! List) {
        return 'File backup JSON tidak lengkap. Bagian data "$table" tidak ditemukan.';
      }
    }

    return null;
  }

  static Future<String?> validateNativeBackupFile(File file) async {
    Database? db;
    try {
      final signatureValidation = await _validateNativeSignature(file);
      if (signatureValidation.error != null) {
        return signatureValidation.error;
      }

      db = await openDatabase(file.path, readOnly: true);
      final backupVersion = Sqflite.firstIntValue(
            await db.rawQuery('PRAGMA user_version;'),
          ) ??
          0;
      if (backupVersion > _currentVersion) {
        return 'Backup native berasal dari versi aplikasi yang lebih baru.';
      }
      if (backupVersion > 0 && backupVersion < _minCompatibleVersion) {
        return 'Backup native terlalu lama (versi $backupVersion). '
            'Versi minimum yang didukung adalah $_minCompatibleVersion.';
      }

      final integrityRows = await db.rawQuery('PRAGMA integrity_check;');
      final integrityResult = integrityRows.isNotEmpty
          ? integrityRows.first.values.first.toString()
          : '';
      if (integrityResult.toLowerCase() != 'ok') {
        return 'File database gagal melewati pengecekan keamanan sistem.';
      }

      final tables = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type = 'table'",
      );
      final names = tables
          .map((row) => row['name']?.toString() ?? '')
          .where((name) => name.isNotEmpty)
          .toSet();

      for (final table in DBHelper.requiredBackupTables) {
        if (!names.contains(table)) {
          return 'File database tidak dikenali sebagai format Juragan Servis yang valid.';
        }
      }
      return null;
    } catch (e) {
      return 'File database tidak dapat dibuka. File mungkin rusak atau tidak didukung.';
    } finally {
      await db?.close();
    }
  }

  static Future<_NativeSignatureValidationResult> _validateNativeSignature(
    File file,
  ) async {
    final signatureFile = _nativeSignatureFile(file);
    if (!await signatureFile.exists()) {
      return const _NativeSignatureValidationResult.legacy();
    }

    try {
      final signature = jsonDecode(
        await signatureFile.readAsString(encoding: utf8),
      ) as Map<String, dynamic>;
      final storedChecksum =
          signature['_checksum_sha256']?.toString().trim() ?? '';
      if (storedChecksum.isEmpty) {
        return const _NativeSignatureValidationResult.invalid(
          'Kode verifikasi backup database rusak atau tidak lengkap.',
        );
      }

      final signedVersion = signature['version'] as int? ?? 0;
      if (signedVersion > _currentVersion) {
        return const _NativeSignatureValidationResult.invalid(
          'Backup native berasal dari versi aplikasi yang lebih baru.',
        );
      }

      final bytes = await file.readAsBytes();
      final expectedChecksum = _computeBytesChecksum(bytes);
      if (expectedChecksum != storedChecksum) {
        return const _NativeSignatureValidationResult.invalid(
          'Integritas backup native gagal diverifikasi.',
        );
      }
    } catch (e) {
      return const _NativeSignatureValidationResult.invalid(
        'Gagal memverifikasi kode keamanan backup database. File mungkin rusak.',
      );
    }

    return const _NativeSignatureValidationResult.verified();
  }

  static Future<bool> restoreFromFile(BuildContext context) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: Platform.isAndroid ? FileType.any : FileType.custom,
        allowedExtensions: Platform.isAndroid
            ? null
            : ['json', BackupCryptoService.encryptedExtension, 'db'],
        dialogTitle: 'Pilih File Backup Juragan Servis',
      );

      if (result == null || result.files.single.path == null) return false;
      if (!context.mounted) return false;

      final path = result.files.single.path!;
      if (!path.toLowerCase().endsWith('.json') &&
          !path.toLowerCase().endsWith(
                '.${BackupCryptoService.encryptedExtension}',
              ) &&
          !path.toLowerCase().endsWith('.db')) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'File tidak valid. Harus .json, .${BackupCryptoService.encryptedExtension}, atau .db',
            ),
          ),
        );
        return false;
      }

      final file = File(path);
      return restoreFromSpecificFile(context, file);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text(
                  'Restore gagal. Silakan pastikan file backup valid dan coba lagi.')),
        );
      }
      return false;
    }
  }

  static Future<bool> restoreFromSpecificFile(
    BuildContext context,
    File file, {
    String? passphrase,
  }) async {
    final ext = file.path.split('.').last.toLowerCase();
    if (ext == 'db') {
      return _restoreNativeBackup(context, file);
    }
    return _restoreJsonBackup(
      context,
      file,
      passphrase: passphrase,
    );
  }

  static Future<bool> _restoreJsonBackup(
    BuildContext context,
    File file, {
    String? passphrase,
  }) async {
    final data = await readBackupPayloadFromFile(
      file,
      passphrase: passphrase,
    );
    final validationError = validateBackup(data);
    if (!context.mounted) return false;
    if (validationError != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(validationError),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 5),
        ),
      );
      return false;
    }

    final confirmed = await _confirmRestore(
      context,
      exportedAt: data['exported_at']?.toString(),
      backupVersion:
          data['version'] as int? ?? data['app_version'] as int? ?? 0,
      restoreModeLabel:
          requiresPassphrase(file) ? 'JSON terenkripsi' : 'JSON terstruktur',
    );
    if (!confirmed) return false;

    await _createEmergencyRestorePoint();
    await _restoreEmbeddedMedia(data);
    await DBHelper.instance.restoreAllData(data);
    return true;
  }

  static Future<bool> _restoreNativeBackup(
    BuildContext context,
    File file,
  ) async {
    final validationError = await validateNativeBackupFile(file);
    if (!context.mounted) return false;
    if (validationError != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(validationError),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 5),
        ),
      );
      return false;
    }

    final confirmed = await _confirmRestore(
      context,
      exportedAt: null,
      backupVersion: null,
      restoreModeLabel: 'Database native (.db)',
    );
    if (!confirmed) return false;

    await _createEmergencyRestorePoint();
    await DBHelper.instance.replaceDatabaseWithFile(file);
    return true;
  }

  static Future<bool> _confirmRestore(
    BuildContext context, {
    required String? exportedAt,
    required int? backupVersion,
    required String restoreModeLabel,
  }) async {
    if (!context.mounted) return false;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Text('Konfirmasi Restore'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Semua data saat ini akan DIGANTI dengan data dari file backup.\n',
            ),
            Text(
              'Mode restore: $restoreModeLabel',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            if (exportedAt != null && exportedAt.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(
                'Tanggal backup: ${exportedAt.substring(0, 10)}',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ],
            if (backupVersion != null) ...[
              const SizedBox(height: 4),
              Text(
                'Versi backup: $backupVersion',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ],
            const SizedBox(height: 8),
            const Text(
              'Backup darurat dari database saat ini akan dibuat otomatis sebelum restore.',
              style: TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 8),
            const Text(
              'Proses ini tidak dapat dibatalkan.',
              style: TextStyle(color: Colors.red),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text(
              'Ya, Restore',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
    return confirm == true;
  }

  static Future<void> _createEmergencyRestorePoint() async {
    final targetDir = await getBackupDirectory();
    final now = DateTime.now();
    final timestamp =
        '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_'
        '${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}${now.second.toString().padLeft(2, '0')}';
    final emergencyFile =
        File('${targetDir.path}/$_preRestorePrefix$timestamp.db');
    await DBHelper.instance.backupDatabaseTo(emergencyFile.path);
    await _writeNativeBackupSignature(emergencyFile);
  }

  static Future<bool> shouldRemindBackup() async {
    try {
      final db = await DBHelper.instance.database;
      final pResult = await db.rawQuery('SELECT COUNT(*) as c FROM products');
      final pCount = (pResult.first['c'] as int?) ?? 0;

      final tResult =
          await db.rawQuery('SELECT COUNT(*) as c FROM transactions');
      final tCount = (tResult.first['c'] as int?) ?? 0;

      if (pCount == 0 && tCount == 0) {
        return false;
      }
    } catch (_) {
      // Fallback aman: jika gagal menghitung, tetap evaluasi tanggal backup.
    }

    final prefs = await SharedPreferences.getInstance();
    final lastBackup = prefs.getString(_lastBackupKey);
    if (lastBackup == null) return true;
    final last = DateTime.tryParse(lastBackup);
    if (last == null) return true;
    return DateTime.now().difference(last).inDays >= 7;
  }

  static Future<DateTime?> getLastBackupDate() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_lastBackupKey);
    return s != null ? DateTime.tryParse(s) : null;
  }

  static Future<bool> hasFreshBackupForUpdate({
    Duration maxAge = updateBackupFreshness,
  }) async {
    final last = await getLastBackupDate();
    if (last == null) return false;
    return DateTime.now().difference(last) <= maxAge;
  }

  static Future<int> estimateBackupSize() async {
    final data = await DBHelper.instance.exportAllData();
    final jsonStr = jsonEncode(data);
    return jsonStr.length;
  }

  static Future<Directory> getBackupDirectory() async {
    final prefs = await SharedPreferences.getInstance();
    final customPath = prefs.getString(_backupPathKey);

    if (customPath != null && customPath.isNotEmpty) {
      final dir = Directory(customPath);
      if (await dir.exists()) return dir;
    }

    final docDir = await _getDocumentsDirectory();
    final defaultDir = Directory('${docDir.path}/Juragan Servis_Backups');
    if (!await defaultDir.exists()) {
      await defaultDir.create(recursive: true);
    }
    return defaultDir;
  }

  static Future<String?> runNativeBackup() async {
    try {
      final targetDir = await getBackupDirectory();
      final now = DateTime.now();
      final timestamp =
          '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_'
          '${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}${now.second.toString().padLeft(2, '0')}';

      final targetFile = File('${targetDir.path}/$_backupPrefix$timestamp.db');

      try {
        final ok = await DBHelper.instance.backupDatabaseTo(targetFile.path);
        if (ok) {
          await _finalizeBackup(targetFile, now);
          return targetFile.path;
        }
      } catch (e) {
        // If permission denied to custom path, try internal path automatically
        if (e is PathAccessException ||
            e.toString().contains('Permission denied')) {
          debugPrint(
              'BackupService: Access denied to ${targetDir.path}. Trying fallback to internal storage...');

          final docDir = await getApplicationDocumentsDirectory();
          final fallbackDir =
              Directory('${docDir.path}/Juragan Servis_Backups');
          if (!await fallbackDir.exists()) {
            await fallbackDir.create(recursive: true);
          }

          final fallbackFile =
              File('${fallbackDir.path}/$_backupPrefix$timestamp.db');
          final ok =
              await DBHelper.instance.backupDatabaseTo(fallbackFile.path);

          if (ok) {
            await _finalizeBackup(fallbackFile, now);
            return 'fallback:${fallbackFile.path}';
          }
        }
        rethrow;
      }
      return null;
    } catch (e, stack) {
      debugPrint('runNativeBackup error: $e\n$stack');
      return null;
    }
  }

  static Future<void> _finalizeBackup(File targetFile, DateTime now) async {
    await _writeNativeBackupSignature(targetFile);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_lastBackupKey, now.toIso8601String());
    await prefs.setString(_lastAutoBackupDateKey, now.toIso8601String());
    await rotateBackups();
  }

  static Future<void> rotateBackups() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final limit = prefs.getInt(_backupRetentionKey) ?? 10;
      final targetDir = await getBackupDirectory();

      final files = await _safeListFiles(targetDir);
      final backupFiles = files.whereType<File>().where((f) {
        final name = f.path.split(Platform.pathSeparator).last;
        return (name.startsWith(_backupPrefix) ||
                name.startsWith(_legacyBackupPrefix)) &&
            (name.endsWith('.db') ||
                name.endsWith('.json') ||
                name.endsWith('.${BackupCryptoService.encryptedExtension}'));
      }).toList()
        ..sort((a, b) => a.path.compareTo(b.path));

      if (backupFiles.length <= limit) return;

      final deleteCount = backupFiles.length - limit;
      for (var i = 0; i < deleteCount; i++) {
        final signatureFile = _nativeSignatureFile(backupFiles[i]);
        if (await signatureFile.exists()) {
          await signatureFile.delete();
        }
        await backupFiles[i].delete();
      }
    } catch (_) {
      // Rotasi tidak boleh menghentikan flow utama.
    }
  }

  static Future<void> performAutoBackup() async {
    final prefs = await SharedPreferences.getInstance();
    final isEnabled = prefs.getBool(_autoBackupEnabledKey) ?? true;
    if (!isEnabled) return;

    final lastAuto = prefs.getString(_lastAutoBackupDateKey);
    final lastDate = lastAuto == null ? null : DateTime.tryParse(lastAuto);
    final frequency =
        prefs.getString(_autoBackupFrequencyKey) ?? autoFrequencyDaily;
    if (!_isAutoBackupDue(lastDate, DateTime.now(), frequency)) {
      return;
    }

    await runNativeBackup();
  }

  static bool _isAutoBackupDue(
    DateTime? lastBackup,
    DateTime now,
    String frequency,
  ) {
    if (lastBackup == null) return true;
    final elapsed = now.difference(lastBackup);
    switch (frequency) {
      case autoFrequencyMonthly:
        return elapsed.inDays >= 30;
      case autoFrequencyWeekly:
        return elapsed.inDays >= 7;
      case autoFrequencyDaily:
      default:
        return elapsed.inDays >= 1 ||
            lastBackup.year != now.year ||
            lastBackup.month != now.month ||
            lastBackup.day != now.day;
    }
  }

  static Future<bool> isAutoBackupEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_autoBackupEnabledKey) ?? true;
  }

  static Future<void> setAutoBackupEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_autoBackupEnabledKey, value);
  }

  static Future<String> getAutoBackupFrequency() async {
    final prefs = await SharedPreferences.getInstance();
    final value = prefs.getString(_autoBackupFrequencyKey);
    if (value == autoFrequencyWeekly || value == autoFrequencyMonthly) {
      return value!;
    }
    return autoFrequencyDaily;
  }

  static Future<void> setAutoBackupFrequency(String value) async {
    final prefs = await SharedPreferences.getInstance();
    final clean = switch (value) {
      autoFrequencyWeekly => autoFrequencyWeekly,
      autoFrequencyMonthly => autoFrequencyMonthly,
      _ => autoFrequencyDaily,
    };
    await prefs.setString(_autoBackupFrequencyKey, clean);
  }

  static Future<int> getBackupRetention() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_backupRetentionKey) ?? 10;
  }

  static Future<void> setBackupRetention(int value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_backupRetentionKey, value);
  }

  static Future<void> setBackupPath(String path) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_backupPathKey, path);
  }

  static Future<bool> canWriteToBackupDirectory(String path) async {
    try {
      final dir = Directory(path);
      if (!await dir.exists()) return false;
      final probe = File(
        '${dir.path}${Platform.pathSeparator}.juraganservis_write_test_${DateTime.now().microsecondsSinceEpoch}',
      );
      await probe.writeAsString('ok', flush: true);
      if (await probe.exists()) {
        await probe.delete();
      }
      return true;
    } catch (e) {
      debugPrint(
          'BackupService: selected backup directory is not writable: $e');
      return false;
    }
  }

  static Future<String?> getCustomBackupPath() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_backupPathKey);
  }

  static Future<bool> openBackupDirectory() async {
    final dir = await getBackupDirectory();
    final path = dir.path;
    try {
      final uri = Uri.file(path);
      if (await canLaunchUrl(uri)) {
        return await launchUrl(uri);
      } else if (Platform.isWindows) {
        // Fallback specifically for Windows if file URI fails
        final res = await Process.run('explorer.exe', [path]);
        return res.exitCode == 0;
      }
    } catch (_) {}
    return false;
  }
}

