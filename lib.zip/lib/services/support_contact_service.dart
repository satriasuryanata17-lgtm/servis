import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/app_runtime_config.dart';
import 'auth_service.dart';
import 'whatsapp_helper.dart';

class SupportContactService {
  static final SupabaseClient _client = Supabase.instance.client;
  static const _rpcUnavailableMessage =
      'Gagal memperbarui pengaturan dukungan. Pastikan perangkat terhubung ke internet dan silakan coba lagi.';

  static String get fallbackWhatsappNumber =>
      normalizePhone(AppRuntimeConfig.supportWhatsappNumber);

  static String normalizePhone(String phone) {
    var value = phone.replaceAll(RegExp(r'[^0-9]'), '');
    if (value.startsWith('0')) {
      value = '62${value.substring(1)}';
    }
    if (value.isNotEmpty && !value.startsWith('62')) {
      value = '62$value';
    }
    return value;
  }

  static String buildWhatsappUrl(String phone) {
    final normalized = normalizePhone(phone);
    return 'https://wa.me/$normalized';
  }

  static Future<String> getSupportWhatsappNumber() async {
    try {
      final response = await _client.rpc('rpc_get_support_whatsapp');
      final normalized = normalizePhone(response?.toString() ?? '');
      if (normalized.isNotEmpty) {
        return normalized;
      }
    } catch (_) {
      // Fallback ke bootstrap config jika backend setting belum tersedia.
    }
    return fallbackWhatsappNumber;
  }

  static Future<void> updateSupportWhatsappNumber(String value) async {
    final normalized = normalizePhone(value);
    if (normalized.length < 10) {
      throw const FormatException('Nomor WhatsApp support tidak valid.');
    }

    final adminParams = AuthService.requireAdminRpcParams();
    try {
      final response = await _client.rpc(
        'rpc_admin_update_support_whatsapp',
        params: {
          ...adminParams,
          'p_value': normalized,
        },
      );
      final stored = normalizePhone(response?.toString() ?? '');
      if (stored.isEmpty) {
        throw const AuthBackendRequiredException(_rpcUnavailableMessage);
      }
    } catch (e) {
      if (e is FormatException || e is StateError) rethrow;
      throw const AuthBackendRequiredException(_rpcUnavailableMessage);
    }
  }

  static Future<void> launchSupportWhatsapp({String? message}) async {
    final phone = await getSupportWhatsappNumber();
    final text = message ??
        'Halo Support Juragan Servis, saya ingin bertanya tentang upgrade lisensi.';
    await WhatsAppHelper.sendMessage(message: text, phone: phone);
  }

  //
  // PLAY STORE URL
  //
  static const _fallbackPlayStoreUrl =
      'https://play.google.com/store/apps/details?id=com.juraganservis.app';

  /// Ambil URL Play Store dari Supabase; fallback ke default jika gagal.
  static Future<String> getPlayStoreUrl() async {
    try {
      final response = await _client.rpc('rpc_get_playstore_url');
      final url = response?.toString().trim() ?? '';
      if (url.isNotEmpty) return url;
    } catch (_) {}
    return _fallbackPlayStoreUrl;
  }

  /// Update URL Play Store  hanya bisa oleh admin.
  static Future<void> updatePlayStoreUrl(String url) async {
    final trimmed = url.trim();
    if (trimmed.isEmpty) throw const FormatException('URL tidak boleh kosong.');
    if (!trimmed.startsWith('http')) {
      throw const FormatException('URL harus dimulai dengan http atau https.');
    }

    final adminParams = AuthService.requireAdminRpcParams();
    try {
      await _client.rpc(
        'rpc_admin_update_playstore_url',
        params: {
          ...adminParams,
          'p_value': trimmed,
        },
      );
    } catch (e) {
      if (e is FormatException || e is StateError) rethrow;
      throw const AuthBackendRequiredException(
          'Gagal memperbarui URL Play Store. Pastikan RPC sudah tersedia di Supabase.');
    }
  }
}

