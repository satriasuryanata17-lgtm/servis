import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'remote_scanner_auth.dart';

class ScannerServerService {
  static const int _maxBodyBytes = 16 * 1024;
  static const Duration _nonceTtl = Duration(minutes: 2);

  HttpServer? _server;
  String? _authToken;
  final Map<String, DateTime> _usedNonces = <String, DateTime>{};
  final StreamController<String> _barcodeStreamController =
      StreamController<String>.broadcast();

  Stream<String> get barcodeStream => _barcodeStreamController.stream;

  bool get isRunning => _server != null;

  int get port => _server?.port ?? 0;

  Future<String?> getLocalIp() async {
    try {
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLinkLocal: false,
        includeLoopback: false,
      );

      for (final interface in interfaces) {
        // Typically we want Wi-Fi or local area network, skip virtual adapters if possible
        if (interface.name.toLowerCase().contains('virtual')) continue;

        for (final addr in interface.addresses) {
          if (addr.address.startsWith('192.168.') ||
              addr.address.startsWith('10.') ||
              addr.address.startsWith('172.')) {
            return addr.address;
          }
        }
      }

      // Fallback to first available if no standard local subnet is found
      if (interfaces.isNotEmpty && interfaces.first.addresses.isNotEmpty) {
        return interfaces.first.addresses.first.address;
      }
    } catch (e) {
      debugPrint('Error getting local IP: $e');
    }
    return null;
  }

  Future<bool> startServer({required String authToken}) async {
    if (_server != null) return true; // Already running

    _authToken = authToken.trim();
    if (_authToken!.isEmpty) {
      throw StateError('Remote scanner token belum tersedia.');
    }

    try {
      _server = await HttpServer.bind(InternetAddress.anyIPv4, 8080);
    } catch (e) {
      debugPrint(
        'Failed to start scanner server on port 8080, trying dynamic port. Error: $e',
      );
      try {
        _server = await HttpServer.bind(
            InternetAddress.anyIPv4, 0); // 0 means random available port
      } catch (e2) {
        debugPrint('Failed completely to start scanner server: $e2');
        _server = null;
        return false;
      }
    }

    debugPrint('Scanner Server running on port ${_server!.port}');

    final connectedDevices = <String>{};

    _server!.listen((HttpRequest request) async {
      try {
        if (request.uri.path == '/connect' && request.method == 'POST') {
          final data = await _readJsonBody(request);
          if (!_isAuthorized(
            request: request,
            body: data,
          )) {
            await _writeUnauthorized(request.response);
            return;
          }

          final deviceName = data['deviceName']?.toString() ??
              request.connectionInfo?.remoteAddress.address ??
              'Unknown Device';
          connectedDevices.add(deviceName);
          _barcodeStreamController.add("__CONNECT__:$deviceName");

          request.response
            ..statusCode = HttpStatus.ok
            ..headers.contentType = ContentType.json
            ..write(
              jsonEncode({
                'status': 'connected',
                'devices': connectedDevices.toList(),
              }),
            )
            ..close();
        } else if (request.uri.path == '/disconnect' &&
            request.method == 'POST') {
          final data = await _readJsonBody(request);
          if (!_isAuthorized(
            request: request,
            body: data,
          )) {
            await _writeUnauthorized(request.response);
            return;
          }

          final deviceName = data['deviceName']?.toString() ??
              request.connectionInfo?.remoteAddress.address ??
              'Unknown Device';
          connectedDevices.remove(deviceName);
          _barcodeStreamController.add("__DISCONNECT__:$deviceName");

          request.response
            ..statusCode = HttpStatus.ok
            ..headers.contentType = ContentType.json
            ..write(jsonEncode({'status': 'disconnected'}))
            ..close();
        } else if (request.uri.path == '/scan' && request.method == 'POST') {
          final data = await _readJsonBody(request);
          if (!_isAuthorized(
            request: request,
            body: data,
          )) {
            await _writeUnauthorized(request.response);
            return;
          }

          if (data.containsKey('barcode')) {
            final barcode = data['barcode'].toString().trim();
            if (barcode.isNotEmpty) {
              _barcodeStreamController.add(barcode);
            }

            request.response
              ..statusCode = HttpStatus.ok
              ..headers.contentType = ContentType.json
              ..write(jsonEncode({'status': 'success'}))
              ..close();
          } else {
            request.response
              ..statusCode = HttpStatus.badRequest
              ..headers.contentType = ContentType.json
              ..write(
                jsonEncode(
                  {
                    'error': 'Invalid payload, expected {"barcode": "code"}',
                  },
                ),
              )
              ..close();
          }
        } else if (request.uri.path == '/ping' && request.method == 'GET') {
          request.response
            ..statusCode = HttpStatus.ok
            ..headers.contentType = ContentType.json
            ..write(
              jsonEncode({'system': 'Juragan Servis', 'status': 'ready'}),
            )
            ..close();
        } else {
          request.response
            ..statusCode = HttpStatus.notFound
            ..headers.contentType = ContentType.text
            ..write('Not Found')
            ..close();
        }
      } on FormatException catch (e) {
        request.response
          ..statusCode = HttpStatus.badRequest
          ..headers.contentType = ContentType.json
          ..write(jsonEncode({'error': e.message}))
          ..close();
      } catch (e) {
        request.response
          ..statusCode = HttpStatus.internalServerError
          ..headers.contentType = ContentType.json
          ..write(jsonEncode({'error': e.toString()}))
          ..close();
      }
    });
    return true;
  }

  void stopServer() {
    _server?.close(force: true);
    _server = null;
    _authToken = null;
    _usedNonces.clear();
  }

  Future<Map<String, dynamic>> _readJsonBody(HttpRequest request) async {
    if (request.contentLength > _maxBodyBytes) {
      throw const FormatException('Payload scanner terlalu besar.');
    }

    final bytes = <int>[];
    await for (final chunk in request) {
      bytes.addAll(chunk);
      if (bytes.length > _maxBodyBytes) {
        throw const FormatException('Payload scanner terlalu besar.');
      }
    }

    final content = utf8.decode(bytes);
    final decoded = jsonDecode(content);
    if (decoded is! Map) {
      throw const FormatException('Payload JSON harus object.');
    }
    return decoded.map(
      (key, value) => MapEntry(key.toString(), value),
    );
  }

  bool _isAuthorized({
    required HttpRequest request,
    required Map<String, dynamic> body,
  }) {
    final expectedToken = _authToken;
    if (expectedToken == null || expectedToken.isEmpty) {
      return false;
    }

    final authRaw = body['auth'];
    if (authRaw is! Map) {
      return false;
    }

    final auth = authRaw.map(
      (key, value) => MapEntry(key.toString(), value),
    );
    final timestampMs = (auth['timestamp_ms'] as num?)?.toInt();
    final nonce = auth['nonce']?.toString().trim() ?? '';
    final signature = auth['signature']?.toString().trim() ?? '';
    if (timestampMs == null || nonce.isEmpty || signature.isEmpty) {
      return false;
    }
    if (!RemoteScannerAuth.isTimestampFresh(timestampMs)) {
      return false;
    }

    _pruneUsedNonces();
    if (_usedNonces.containsKey(nonce)) {
      return false;
    }

    final payload = Map<String, dynamic>.from(body)..remove('auth');
    final expectedSignature = RemoteScannerAuth.computeSignature(
      secret: expectedToken,
      method: request.method,
      path: request.uri.path,
      timestampMs: timestampMs,
      nonce: nonce,
      payload: payload,
    );
    if (!RemoteScannerAuth.constantTimeEquals(signature, expectedSignature)) {
      return false;
    }

    _usedNonces[nonce] = DateTime.now().toUtc().add(_nonceTtl);
    return true;
  }

  void _pruneUsedNonces() {
    final now = DateTime.now().toUtc();
    _usedNonces.removeWhere((_, expiresAt) => expiresAt.isBefore(now));
  }

  Future<void> _writeUnauthorized(HttpResponse response) async {
    response
      ..statusCode = HttpStatus.unauthorized
      ..headers.contentType = ContentType.json
      ..write(
        jsonEncode({'error': 'Unauthorized remote scanner request'}),
      );
    await response.close();
  }
}

