import 'package:supabase_flutter/supabase_flutter.dart';

import 'auth_service.dart';

class AdminLicenseService {
  static final SupabaseClient _client = Supabase.instance.client;
  static const _rpcRequiredMessage =
      'Gagal menghubungi server manajemen lisensi. Pastikan perangkat terhubung ke internet dan silakan coba lagi.';

  static Future<List<Map<String, dynamic>>> fetchLicenses() async {
    final adminParams = AuthService.requireAdminRpcParams();
    try {
      final response = await _client.rpc(
        'rpc_admin_list_licenses',
        params: adminParams,
      );
      if (response is! List) {
        throw const AuthBackendRequiredException(_rpcRequiredMessage);
      }
      return response
          .whereType<Map>()
          .map(
            (item) => item.map(
              (key, value) => MapEntry(key.toString(), value),
            ),
          )
          .toList();
    } catch (_) {
      throw const AuthBackendRequiredException(_rpcRequiredMessage);
    }
  }

  static Future<void> createLicense({
    required String serial,
    required String password,
    required String name,
    required String email,
    required String phone,
    int maxDevices = 1,
    String licenseType = 'single',
    String allowedPlatforms = 'all',
    bool canRemotePrint = false,
    bool isTrial = false,
    String? label,
    String? expiredAt,
  }) async {
    final adminParams = AuthService.requireAdminRpcParams();
    final cleanSerial = serial.trim().toUpperCase();
    final cleanPassword = password.trim();
    final cleanName = name.trim();
    final cleanEmail = email.trim();
    final cleanPhone = phone.trim();
    try {
      await _client.rpc(
        'rpc_admin_create_license_v2',
        params: {
          ...adminParams,
          'p_serial': cleanSerial,
          'p_password_hash_license': AuthService.hashLicensePassword(
            cleanPassword,
          ),
          'p_customer_name': cleanName,
          'p_customer_email': cleanEmail.isEmpty ? null : cleanEmail,
          'p_customer_phone': cleanPhone.isEmpty ? null : cleanPhone,
          'p_max_devices': maxDevices,
          'p_license_type': licenseType,
          'p_allowed_platforms': allowedPlatforms,
          'p_can_remote_print': canRemotePrint,
          'p_is_trial': isTrial,
          'p_label': label,
          'p_expired_at': expiredAt,
        },
      );
    } catch (_) {
      throw const AuthBackendRequiredException(_rpcRequiredMessage);
    }
  }

  static Future<void> resetDevice(String licenseId, {String? deviceId}) async {
    final adminParams = AuthService.requireAdminRpcParams();
    final cleanLicenseId = licenseId.trim();
    try {
      final response = await _client.rpc(
        'rpc_admin_reset_license_device',
        params: {
          ...adminParams,
          'p_license_id': cleanLicenseId,
          'p_device_id': deviceId?.trim(),
        },
      );
      final ok = response == true ||
          response == 1 ||
          response == '1' ||
          response == 'true';
      if (!ok) {
        throw StateError('Lisensi tidak ditemukan atau gagal di-reset.');
      }
    } on StateError {
      rethrow;
    } catch (_) {
      throw const AuthBackendRequiredException(_rpcRequiredMessage);
    }
  }

  static Future<void> updateLicenseConfig({
    required String licenseId,
    int? maxDevices,
    String? licenseType,
    String? allowedPlatforms,
    bool? canRemotePrint,
    bool? isTrial,
    String? label,
    String? expiredAt,
    bool? isActive,
  }) async {
    final adminParams = AuthService.requireAdminRpcParams();
    try {
      final response = await _client.rpc(
        'rpc_admin_update_license_config_v2',
        params: {
          ...adminParams,
          'p_license_id': licenseId.trim(),
          if (maxDevices != null) 'p_max_devices': maxDevices,
          if (licenseType != null) 'p_license_type': licenseType,
          if (allowedPlatforms != null) 'p_allowed_platforms': allowedPlatforms,
          if (canRemotePrint != null) 'p_can_remote_print': canRemotePrint,
          if (isTrial != null) 'p_is_trial': isTrial,
          if (label != null) 'p_label': label,
          if (expiredAt != null) 'p_expired_at': expiredAt,
          if (isActive != null) 'p_is_active': isActive,
        },
      );
      final ok = response == true ||
          response == 1 ||
          response == '1' ||
          response == 'true';
      if (!ok) {
        throw StateError('Lisensi tidak ditemukan atau gagal diperbarui.');
      }
    } on StateError {
      rethrow;
    } catch (_) {
      throw const AuthBackendRequiredException(_rpcRequiredMessage);
    }
  }

  static Future<List<Map<String, dynamic>>> fetchLicenseDevices(
      String licenseId) async {
    final adminParams = AuthService.requireAdminRpcParams();
    try {
      final response = await _client.rpc(
        'rpc_admin_list_license_devices',
        params: {
          ...adminParams,
          'p_license_id': licenseId.trim(),
        },
      );
      if (response is! List) return [];
      return response
          .whereType<Map>()
          .map(
            (item) => item.map(
              (key, value) => MapEntry(key.toString(), value),
            ),
          )
          .toList();
    } catch (_) {
      return [];
    }
  }
}

