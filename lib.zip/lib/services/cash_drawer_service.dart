import 'dart:io';

import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'receipt_print_service.dart';

class CashDrawerService {
  static const String enabledPrefKey = 'struk_cashDrawerEnabled';
  static const String pinPrefKey = 'struk_cashDrawerPin';

  static bool paymentMethodHasCash(String paymentMethod) {
    final normalized = _normalizePaymentMethod(paymentMethod);
    if (normalized.isEmpty) return false;

    final hasMixedLabel = _hasAnyPhrase(normalized, const [
      'campuran',
      'mixed',
      'mixto',
      'misto',
    ]);
    final hasCashLabel = _hasAnyPhrase(normalized, const [
      'cash',
      'tunai',
      'efectivo',
      'dinheiro',
    ]);

    if (!hasCashLabel) return false;
    if (hasMixedLabel) return true;

    final isExplicitNonCash = _hasAnyPhrase(normalized, const [
      'non cash',
      'noncash',
      'non tunai',
      'nontunai',
      'cashless',
      'sin efectivo',
      'sem dinheiro',
    ]);
    return !isExplicitNonCash;
  }

  static String _normalizePaymentMethod(String value) {
    var text = value.trim().toLowerCase();
    const replacements = <String, String>{
      '\u00e1': 'a',
      '\u00e0': 'a',
      '\u00e2': 'a',
      '\u00e3': 'a',
      '\u00e4': 'a',
      '\u00e9': 'e',
      '\u00e8': 'e',
      '\u00ea': 'e',
      '\u00eb': 'e',
      '\u00ed': 'i',
      '\u00ec': 'i',
      '\u00ee': 'i',
      '\u00ef': 'i',
      '\u00f3': 'o',
      '\u00f2': 'o',
      '\u00f4': 'o',
      '\u00f5': 'o',
      '\u00f6': 'o',
      '\u00fa': 'u',
      '\u00f9': 'u',
      '\u00fb': 'u',
      '\u00fc': 'u',
      '\u00f1': 'n',
      '\u00e7': 'c',
    };
    for (final entry in replacements.entries) {
      text = text.replaceAll(entry.key, entry.value);
    }
    return text
        .replaceAll(RegExp(r'[^a-z0-9]+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static bool _hasAnyPhrase(String normalized, List<String> phrases) {
    final padded = ' $normalized ';
    return phrases.any((phrase) => padded.contains(' $phrase '));
  }

  static Future<bool> isEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(enabledPrefKey) ?? false;
  }

  static Future<bool> openAfterCashPayment(String paymentMethod) async {
    if (!paymentMethodHasCash(paymentMethod)) return false;
    if (!await isEnabled()) return false;
    await openConfiguredDrawer();
    return true;
  }

  static Future<void> openConfiguredDrawer() async {
    final prefs = await SharedPreferences.getInstance();
    final pin = prefs.getInt(pinPrefKey) ?? 0;
    final bytes = ReceiptPrintService.cashDrawerKickBytes(pin: pin);

    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      final printerName = prefs.getString('desktop_printerName') ?? '';
      if (printerName.trim().isEmpty) {
        throw Exception('Printer desktop belum dipilih.');
      }
      await ReceiptPrintService.printRawEscPosDesktop(
        bytes: bytes,
        printerName: printerName,
      );
      return;
    }

    final mac = prefs.getString('struk_printerMac') ?? '';
    if (mac.trim().isEmpty) {
      throw Exception('Printer Bluetooth belum dipilih.');
    }

    bool connectedByService = false;
    try {
      final alreadyConnected = await PrintBluetoothThermal.connectionStatus;
      if (!alreadyConnected) {
        connectedByService =
            await PrintBluetoothThermal.connect(macPrinterAddress: mac);
        if (!connectedByService) {
          throw Exception('Gagal terhubung ke printer Bluetooth.');
        }
        await Future.delayed(const Duration(milliseconds: 350));
      }

      final accepted = await PrintBluetoothThermal.writeBytes(bytes);
      if (!accepted) {
        throw Exception('Printer menolak perintah buka laci.');
      }
      await Future.delayed(const Duration(milliseconds: 250));
    } finally {
      if (connectedByService) {
        await PrintBluetoothThermal.disconnect;
      }
    }
  }
}

