import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../database/db_helper.dart';
import 'auth_service.dart';
import 'backup_service.dart';

class JuraganSyncSummary {
  final int categories;
  final int products;
  final int transactions;
  final int customers;
  final int suppliers;

  const JuraganSyncSummary({
    required this.categories,
    required this.products,
    required this.transactions,
    required this.customers,
    required this.suppliers,
  });

  factory JuraganSyncSummary.fromData(Map<String, dynamic> data) {
    int count(String table) => (data[table] as List?)?.length ?? 0;
    return JuraganSyncSummary(
      categories: count('categories'),
      products: count('products'),
      transactions: count('transactions'),
      customers: count('customers'),
      suppliers: count('suppliers'),
    );
  }

  Map<String, dynamic> toJson() => {
        'categories': categories,
        'products': products,
        'transactions': transactions,
        'customers': customers,
        'suppliers': suppliers,
      };

  factory JuraganSyncSummary.fromJson(Map<dynamic, dynamic> json) {
    int value(String key) => _int(json[key]) ?? 0;
    return JuraganSyncSummary(
      categories: value('categories'),
      products: value('products'),
      transactions: value('transactions'),
      customers: value('customers'),
      suppliers: value('suppliers'),
    );
  }
}

class JuraganSyncDeviceProfile {
  final String name;
  final String role;
  final String platform;

  const JuraganSyncDeviceProfile({
    required this.name,
    required this.role,
    required this.platform,
  });

  String get roleLabel {
    switch (role) {
      case JuraganSyncService.deviceRoleOwner:
        return 'Perangkat Utama';
      case JuraganSyncService.deviceRoleAdmin:
        return 'Perangkat Admin';
      default:
        return 'Perangkat Kasir';
    }
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'role': role,
        'platform': platform,
      };

  factory JuraganSyncDeviceProfile.fromJson(Map<dynamic, dynamic> json) {
    return JuraganSyncDeviceProfile(
      name: (json['name']?.toString().trim().isNotEmpty == true)
          ? json['name'].toString().trim()
          : 'Perangkat Juragan Servis',
      role: json['role']?.toString().trim().isNotEmpty == true
          ? json['role'].toString().trim()
          : JuraganSyncService.deviceRoleCashier,
      platform: json['platform']?.toString().trim().isNotEmpty == true
          ? json['platform'].toString().trim()
          : 'unknown',
    );
  }
}

class JuraganSyncResult {
  final JuraganSyncSummary beforeLocal;
  final JuraganSyncSummary beforePeer;
  final JuraganSyncSummary after;
  final JuraganSyncPreviewPlan plan;
  final String? backupPath;

  const JuraganSyncResult({
    required this.beforeLocal,
    required this.beforePeer,
    required this.after,
    required this.plan,
    this.backupPath,
  });
}

enum JuraganSyncTransactionResolution {
  keepDeleted,
  restoreActive,
}

enum JuraganSyncProductResolution {
  keepLocal,
  usePeer,
}

enum JuraganSyncSettingsResolution {
  keepLocal,
  usePeer,
}

const List<String> _syncSettingsTables = [
  'warung_profile',
  'profil',
  'payment_settings',
];

String _settingsTableLabel(String table) {
  switch (table) {
    case 'warung_profile':
      return 'Profil Servis';
    case 'profil':
      return 'Profil & Admin';
    case 'payment_settings':
      return 'Bank & QRIS';
    default:
      return table;
  }
}

class JuraganSyncTransactionDeleteConflict {
  final String key;
  final Map<String, dynamic> activeRow;
  final Map<String, dynamic> deletedRow;
  final bool deletedOnPeer;

  const JuraganSyncTransactionDeleteConflict({
    required this.key,
    required this.activeRow,
    required this.deletedRow,
    required this.deletedOnPeer,
  });

  String get transactionCode {
    final code = _str(activeRow['transaction_code']).trim();
    if (code.isNotEmpty) return code;
    return _str(activeRow['id']).trim().isEmpty
        ? '-'
        : '#${_str(activeRow['id']).trim()}';
  }

  String get createdAt => _str(activeRow['created_at']).trim();
  String get customerName => _str(activeRow['customer_name']).trim();
  int get grandTotal => _int(activeRow['grand_total']) ?? 0;
  String get deletedAt => _str(deletedRow['deleted_at']).trim();
}

class JuraganSyncProductConflict {
  final String key;
  final Map<String, dynamic> localRow;
  final Map<String, dynamic> peerRow;
  final List<String> changedFields;

  const JuraganSyncProductConflict({
    required this.key,
    required this.localRow,
    required this.peerRow,
    required this.changedFields,
  });

  String get name {
    final localName = _str(localRow['name']).trim();
    if (localName.isNotEmpty) return localName;
    final peerName = _str(peerRow['name']).trim();
    return peerName.isEmpty ? 'Layanan' : peerName;
  }

  int get localSellPrice => _int(localRow['sell_price']) ?? 0;
  int get peerSellPrice => _int(peerRow['sell_price']) ?? 0;
  int get localBuyPrice => _int(localRow['buy_price']) ?? 0;
  int get peerBuyPrice => _int(peerRow['buy_price']) ?? 0;
  String get localUnit => _str(localRow['unit']).trim();
  String get peerUnit => _str(peerRow['unit']).trim();
}

class JuraganSyncSettingsConflict {
  final List<String> changedTables;
  final Map<String, Map<String, dynamic>?> localRows;
  final Map<String, Map<String, dynamic>?> peerRows;

  const JuraganSyncSettingsConflict({
    required this.changedTables,
    required this.localRows,
    required this.peerRows,
  });

  String get localStoreName => _settingValue(localRows['warung_profile'], [
        'nama',
        'name',
      ]);
  String get peerStoreName => _settingValue(peerRows['warung_profile'], [
        'nama',
        'name',
      ]);
  String get localAddress => _settingValue(localRows['warung_profile'], [
        'alamat',
        'address',
      ]);
  String get peerAddress => _settingValue(peerRows['warung_profile'], [
        'alamat',
        'address',
      ]);
  String get localPaymentName => _settingValue(localRows['payment_settings'], [
        'qris_name',
        'bank_name',
      ]);
  String get peerPaymentName => _settingValue(peerRows['payment_settings'], [
        'qris_name',
        'bank_name',
      ]);

  List<String> get changedLabels =>
      changedTables.map(_settingsTableLabel).toList(growable: false);
}

class JuraganSyncTablePlan {
  final String table;
  final String label;
  final int localOnly;
  final int peerOnly;
  final int changed;
  final int finalCount;

  const JuraganSyncTablePlan({
    required this.table,
    required this.label,
    required this.localOnly,
    required this.peerOnly,
    required this.changed,
    required this.finalCount,
  });

  int get touched => localOnly + peerOnly + changed;
}

class JuraganSyncPreviewPlan {
  final JuraganSyncSummary beforeLocal;
  final JuraganSyncSummary beforePeer;
  final JuraganSyncSummary after;
  final List<JuraganSyncTablePlan> tables;
  final int transactionDeleteConflicts;
  final int productConflicts;
  final int settingsConflicts;

  const JuraganSyncPreviewPlan({
    required this.beforeLocal,
    required this.beforePeer,
    required this.after,
    required this.tables,
    required this.transactionDeleteConflicts,
    required this.productConflicts,
    this.settingsConflicts = 0,
  });

  int get incomingCount =>
      tables.fold<int>(0, (sum, item) => sum + item.peerOnly);
  int get outgoingCount =>
      tables.fold<int>(0, (sum, item) => sum + item.localOnly);
  int get changedCount =>
      tables.fold<int>(0, (sum, item) => sum + item.changed);
  int get conflictCount =>
      transactionDeleteConflicts + productConflicts + settingsConflicts;
}

class JuraganSyncPreview {
  final String host;
  final int port;
  final String pin;
  final JuraganSyncDeviceProfile localDevice;
  final JuraganSyncDeviceProfile peerDevice;
  final Map<String, dynamic> localData;
  final Map<String, dynamic> peerData;
  final JuraganSyncPreviewPlan plan;
  final List<JuraganSyncProductConflict> productConflicts;
  final List<JuraganSyncTransactionDeleteConflict> transactionDeleteConflicts;
  final JuraganSyncSettingsConflict? settingsConflict;

  const JuraganSyncPreview({
    required this.host,
    required this.port,
    required this.pin,
    required this.localDevice,
    required this.peerDevice,
    required this.localData,
    required this.peerData,
    required this.plan,
    required this.productConflicts,
    required this.transactionDeleteConflicts,
    this.settingsConflict,
  });
}

class JuraganSyncServerInfo {
  final bool running;
  final String? ip;
  final List<String> ips;
  final int port;
  final String pin;
  final DateTime? expiresAt;

  const JuraganSyncServerInfo({
    required this.running,
    required this.ip,
    required this.ips,
    required this.port,
    required this.pin,
    this.expiresAt,
  });
}

class JuraganSyncDiscoveredPeer {
  final String host;
  final int port;
  final JuraganSyncDeviceProfile device;
  final int schemaVersion;
  final bool requiresPin;

  const JuraganSyncDiscoveredPeer({
    required this.host,
    required this.port,
    required this.device,
    required this.schemaVersion,
    required this.requiresPin,
  });

  String get code => '$host:$port';
}

class JuraganSyncService {
  static final JuraganSyncService instance = JuraganSyncService._();
  JuraganSyncService._();

  static const int preferredPort = 8090;
  static const int _maxPayloadBytes = 200 * 1024 * 1024;
  static const Duration sessionTtl = Duration(minutes: 5);
  static const Duration _syncPayloadTimeout = Duration(minutes: 5);
  static const String deviceRoleOwner = 'owner';
  static const String deviceRoleCashier = 'cashier';
  static const String deviceRoleAdmin = 'admin';
  static const List<String> deviceRoles = [
    deviceRoleOwner,
    deviceRoleCashier,
    deviceRoleAdmin,
  ];
  static const String _deviceRoleKey = 'juragan_sync_device_role';
  static const String _deviceNameKey = 'juragan_sync_device_name';
  static const String _localDeviceIdFallbackKey = 'local_device_id_fallback_v1';

  HttpServer? _server;
  Timer? _expiryTimer;
  DateTime? _expiresAt;
  String _pin = _newPin();
  final StreamController<JuraganSyncSummary> _appliedController =
      StreamController<JuraganSyncSummary>.broadcast();

  bool get isRunning => _server != null;
  int get port => _server?.port ?? 0;
  String get pin => _pin;
  Stream<JuraganSyncSummary> get appliedStream => _appliedController.stream;

  Future<JuraganSyncDeviceProfile> deviceProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final rawName = prefs.getString(_deviceNameKey)?.trim();
    final rawRole = prefs.getString(_deviceRoleKey)?.trim();
    return JuraganSyncDeviceProfile(
      name: rawName == null || rawName.isEmpty ? _defaultDeviceName() : rawName,
      role: deviceRoles.contains(rawRole) ? rawRole! : deviceRoleCashier,
      platform: _platformName(),
    );
  }

  Future<String> _syncDeviceId() async {
    try {
      final id = (await AuthService.getDeviceId()).trim();
      if (id.isNotEmpty && id != 'unknown_device') return id;
    } catch (e) {
      debugPrint('JuraganSync device id error: $e');
    }

    final prefs = await SharedPreferences.getInstance();
    final existing = prefs.getString(_localDeviceIdFallbackKey)?.trim();
    if (existing != null && existing.isNotEmpty) return existing;

    final fallback = 'local-${DateTime.now().microsecondsSinceEpoch}';
    await prefs.setString(_localDeviceIdFallbackKey, fallback);
    return fallback;
  }

  Future<Map<String, dynamic>> _exportDataForSync() async {
    final data = await DBHelper.instance.exportAllData();
    final deviceId = await _syncDeviceId();
    data['_sync_device_id'] = deviceId;
    _stampKasirSessionDeviceId(data, deviceId);
    return data;
  }

  Future<void> _assertNoActiveKasirSessionForSync() async {
    if (await _hasActiveKasirSessionForSync()) {
      throw const FormatException(
        'Tutup kasir dulu di perangkat ini sebelum sinkronisasi.',
      );
    }
  }

  Future<bool> _hasActiveKasirSessionForSync() async {
    final deviceId = await _syncDeviceId();
    final session =
        await DBHelper.instance.getActiveKasirSession(deviceId: deviceId);
    return session != null;
  }

  void _stampKasirSessionDeviceId(
    Map<String, dynamic> data,
    String deviceId,
  ) {
    final cleanDeviceId = deviceId.trim();
    if (cleanDeviceId.isEmpty) return;
    final rawRows = data['kasir_sessions'];
    if (rawRows is! List) return;

    data['kasir_sessions'] = rawRows.whereType<Map>().map((rawRow) {
      final row = rawRow.map((key, value) => MapEntry(key.toString(), value));
      final current = row['device_id']?.toString().trim() ?? '';
      if (current.isEmpty) row['device_id'] = cleanDeviceId;
      return row;
    }).toList();
  }

  Future<JuraganSyncServerInfo> serverInfo() async {
    final ips = await getLocalIps().timeout(
      const Duration(seconds: 3),
      onTimeout: () => const <String>[],
    );
    return JuraganSyncServerInfo(
      running: isRunning,
      ip: ips.isEmpty ? null : ips.first,
      ips: ips,
      port: port,
      pin: pin,
      expiresAt: _expiresAt,
    );
  }

  Future<JuraganSyncServerInfo> startServer() async {
    try {
      await _assertNoActiveKasirSessionForSync();
    } on FormatException {
      await stopServer();
      rethrow;
    }
    if (_server != null) {
      _armExpiryTimer();
      return serverInfo();
    }
    _pin = _newPin();

    try {
      _server = await HttpServer.bind(InternetAddress.anyIPv4, preferredPort);
    } catch (_) {
      _server = await HttpServer.bind(InternetAddress.anyIPv4, 0);
    }

    _server!.listen(_handleRequest);
    _armExpiryTimer();
    return serverInfo();
  }

  Future<void> stopServer() async {
    _expiryTimer?.cancel();
    _expiryTimer = null;
    _expiresAt = null;
    await _server?.close(force: true);
    _server = null;
  }

  void _armExpiryTimer() {
    _expiryTimer?.cancel();
    _expiresAt = DateTime.now().add(sessionTtl);
    _expiryTimer = Timer(sessionTtl, () {
      unawaited(stopServer());
    });
  }

  Future<String?> getLocalIp() async {
    final ips = await getLocalIps();
    return ips.isEmpty ? null : ips.first;
  }

  Future<List<String>> getLocalIps() async {
    try {
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLinkLocal: false,
        includeLoopback: false,
      );
      final primary = <String>[];
      final fallback = <String>[];

      for (final item in interfaces) {
        final name = item.name.toLowerCase();
        if (name.contains('virtual') ||
            name.contains('vmware') ||
            name.contains('loopback')) {
          continue;
        }
        for (final addr in item.addresses) {
          final ip = addr.address;
          if (ip.startsWith('192.168.') ||
              ip.startsWith('10.') ||
              ip.startsWith('172.')) {
            primary.add(ip);
          } else {
            fallback.add(ip);
          }
        }
      }
      return {...primary, ...fallback}.toList();
    } catch (e) {
      debugPrint('JuraganSync getLocalIp error: $e');
    }
    return const <String>[];
  }

  Future<List<JuraganSyncDiscoveredPeer>> discoverPeers({
    Duration timeout = const Duration(milliseconds: 520),
  }) async {
    if (kIsWeb) return const <JuraganSyncDiscoveredPeer>[];
    final localIps = await getLocalIps();
    final self = localIps.toSet();
    final prefixes = localIps
        .map(_ipv4Prefix)
        .where((prefix) => prefix != null)
        .cast<String>()
        .toSet()
        .toList();
    final candidates = <String>[];
    for (final prefix in prefixes) {
      for (var i = 1; i <= 254; i++) {
        final host = '$prefix$i';
        if (!self.contains(host)) candidates.add(host);
      }
    }

    final found = <String, JuraganSyncDiscoveredPeer>{};
    const batchSize = 42;
    for (var i = 0; i < candidates.length; i += batchSize) {
      final batch = candidates.skip(i).take(batchSize);
      final results = await Future.wait(
        batch.map((host) => _probeHello(host, preferredPort, timeout)),
      );
      for (final peer in results.whereType<JuraganSyncDiscoveredPeer>()) {
        found[peer.code] = peer;
      }
    }
    return found.values.toList()
      ..sort((a, b) => a.device.name.compareTo(b.device.name));
  }

  Future<JuraganSyncResult> syncWithPeer({
    required String host,
    required int port,
    required String pin,
    Map<String, JuraganSyncProductResolution> productResolutions = const {},
    Map<String, JuraganSyncTransactionResolution> transactionResolutions =
        const {},
    JuraganSyncSettingsResolution? settingsResolution,
  }) async {
    final preview = await previewSyncWithPeer(host: host, port: port, pin: pin);
    return applyPreview(
      preview,
      productResolutions: productResolutions,
      transactionResolutions: transactionResolutions,
      settingsResolution: settingsResolution,
    );
  }

  Future<JuraganSyncPreview> previewSyncWithPeer({
    required String host,
    required int port,
    required String pin,
  }) async {
    await _assertNoActiveKasirSessionForSync();
    final peerPing = await _getJson(
      Uri.parse('http://$host:$port/juragan-sync/ping'),
      pin,
      timeout: const Duration(seconds: 4),
    );
    final localDevice = await deviceProfile();
    final rawPeerDevice = peerPing['device'];
    final peerDevice = rawPeerDevice is Map
        ? JuraganSyncDeviceProfile.fromJson(rawPeerDevice)
        : JuraganSyncDeviceProfile(
            name: host,
            role: deviceRoleCashier,
            platform: 'unknown',
          );
    final localData = await _exportDataForSync();
    final peerData = await _pullPeerData(host: host, port: port, pin: pin);
    final merged = JuraganSyncMerger.merge(localData, peerData);
    final productConflicts =
        JuraganSyncMerger.findProductConflicts(localData, peerData);
    final transactionConflicts =
        JuraganSyncMerger.findTransactionDeleteConflicts(localData, peerData);
    final settingsConflict =
        JuraganSyncMerger.findSettingsConflict(localData, peerData);
    return JuraganSyncPreview(
      host: host,
      port: port,
      pin: pin,
      localDevice: localDevice,
      peerDevice: peerDevice,
      localData: localData,
      peerData: peerData,
      plan: JuraganSyncMerger.previewPlan(
        localData,
        peerData,
        merged,
        transactionDeleteConflicts: transactionConflicts.length,
        productConflicts: productConflicts.length,
        settingsConflicts: settingsConflict == null ? 0 : 1,
      ),
      productConflicts: productConflicts,
      transactionDeleteConflicts: transactionConflicts,
      settingsConflict: settingsConflict,
    );
  }

  Future<JuraganSyncResult> applyPreview(
    JuraganSyncPreview preview, {
    Map<String, JuraganSyncProductResolution> productResolutions = const {},
    Map<String, JuraganSyncTransactionResolution> transactionResolutions =
        const {},
    JuraganSyncSettingsResolution? settingsResolution,
  }) async {
    await _assertNoActiveKasirSessionForSync();
    if (preview.settingsConflict != null && settingsResolution == null) {
      throw const FormatException(
        'Pilih pengaturan yang akan dipakai sebelum sinkron.',
      );
    }
    final merged = JuraganSyncMerger.merge(
      preview.localData,
      preview.peerData,
      productResolutions: productResolutions,
      transactionResolutions: transactionResolutions,
      settingsResolution: settingsResolution,
    );

    final backupPath = await BackupService.runNativeBackup();
    await DBHelper.instance.restoreAllData(merged);
    await _pushMergedData(
      host: preview.host,
      port: preview.port,
      pin: preview.pin,
      data: merged,
    );

    return JuraganSyncResult(
      beforeLocal: JuraganSyncSummary.fromData(preview.localData),
      beforePeer: JuraganSyncSummary.fromData(preview.peerData),
      after: JuraganSyncSummary.fromData(merged),
      plan: preview.plan,
      backupPath: backupPath,
    );
  }

  Future<void> probePeer({
    required String host,
    required int port,
    required String pin,
  }) async {
    await _getJson(
      Uri.parse('http://$host:$port/juragan-sync/ping'),
      pin,
      timeout: const Duration(seconds: 4),
    );
  }

  Future<void> _handleRequest(HttpRequest request) async {
    try {
      if (request.uri.path == '/juragan-sync/hello' &&
          request.method == 'GET') {
        final profile = await deviceProfile();
        await _writeJson(request.response, HttpStatus.ok, {
          'app': 'JuraganServis',
          'feature': 'Sinkronisasi',
          'version': DBHelper.schemaVersion,
          'device': profile.toJson(),
          'requires_pin': true,
          'port': port,
        });
        return;
      }

      if (request.uri.path == '/juragan-sync/ping' && request.method == 'GET') {
        if (!_authorized(request)) {
          await _writeJson(request.response, HttpStatus.unauthorized, {
            'error': 'PIN sinkron tidak valid.',
          });
          return;
        }
        if (await _hasActiveKasirSessionForSync()) {
          await _writeJson(request.response, HttpStatus.conflict, {
            'error':
                'Perangkat lawan masih punya sesi kasir aktif. Tutup kasir di perangkat tersebut dulu, lalu sinkron ulang.',
          });
          return;
        }
        final data = await _exportDataForSync();
        final profile = await deviceProfile();
        await _writeJson(request.response, HttpStatus.ok, {
          'app': 'JuraganServis',
          'feature': 'Sinkronisasi',
          'version': DBHelper.schemaVersion,
          'device': profile.toJson(),
          'summary': _summaryMap(data),
        });
        return;
      }

      if (request.uri.path == '/juragan-sync/export' &&
          request.method == 'GET') {
        if (!_authorized(request)) {
          await _writeJson(request.response, HttpStatus.unauthorized, {
            'error': 'PIN sinkron tidak valid.',
          });
          return;
        }
        if (await _hasActiveKasirSessionForSync()) {
          await _writeJson(request.response, HttpStatus.conflict, {
            'error':
                'Perangkat lawan masih punya sesi kasir aktif. Tutup kasir di perangkat tersebut dulu, lalu sinkron ulang.',
          });
          return;
        }
        final data = await _exportDataForSync();
        await _writeJson(request.response, HttpStatus.ok, {
          'data': data,
          'summary': _summaryMap(data),
        });
        return;
      }

      if (request.uri.path == '/juragan-sync/apply' &&
          request.method == 'POST') {
        if (!_authorized(request)) {
          await _writeJson(request.response, HttpStatus.unauthorized, {
            'error': 'PIN sinkron tidak valid.',
          });
          return;
        }
        if (await _hasActiveKasirSessionForSync()) {
          await _writeJson(request.response, HttpStatus.conflict, {
            'error':
                'Perangkat lawan masih punya sesi kasir aktif. Tutup kasir di perangkat tersebut dulu, lalu sinkron ulang.',
          });
          return;
        }
        final body = await _readJsonBody(request);
        final rawData = body['data'];
        if (rawData is! Map) {
          await _writeJson(request.response, HttpStatus.badRequest, {
            'error': 'Payload sinkron tidak valid.',
          });
          return;
        }
        final data = _stringMap(rawData);
        await BackupService.runNativeBackup();
        await DBHelper.instance.restoreAllData(data);
        _appliedController.add(JuraganSyncSummary.fromData(data));
        await _writeJson(request.response, HttpStatus.ok, {
          'ok': true,
          'summary': _summaryMap(data),
        });
        return;
      }

      await _writeJson(request.response, HttpStatus.notFound, {
        'error': 'Endpoint tidak ditemukan.',
      });
    } catch (e, stack) {
      debugPrint('JuraganSync request error: $e\n$stack');
      await _writeJson(request.response, HttpStatus.internalServerError, {
        'error': e.toString(),
      });
    }
  }

  Future<Map<String, dynamic>> _pullPeerData({
    required String host,
    required int port,
    required String pin,
  }) async {
    final json = await _getJson(
      Uri.parse('http://$host:$port/juragan-sync/export'),
      pin,
      timeout: const Duration(seconds: 90),
    );
    final rawData = json['data'];
    if (rawData is! Map) {
      throw const FormatException('Peer tidak mengirim data yang valid.');
    }
    return _stringMap(rawData);
  }

  Future<void> _pushMergedData({
    required String host,
    required int port,
    required String pin,
    required Map<String, dynamic> data,
  }) async {
    final response = await _postJson(
      Uri.parse('http://$host:$port/juragan-sync/apply'),
      pin,
      {'data': data},
    );
    if (response['ok'] != true) {
      throw const FormatException('Peer menolak hasil sinkron.');
    }
  }

  Future<JuraganSyncDiscoveredPeer?> _probeHello(
    String host,
    int port,
    Duration timeout,
  ) async {
    try {
      final client = HttpClient()..connectionTimeout = timeout;
      try {
        final request = await client
            .getUrl(Uri.parse('http://$host:$port/juragan-sync/hello'))
            .timeout(timeout);
        final response = await request.close().timeout(timeout);
        final json = await _decodeResponse(response).timeout(timeout);
        if (json['app'] != 'JuraganServis') return null;
        final rawDevice = json['device'];
        return JuraganSyncDiscoveredPeer(
          host: host,
          port: _int(json['port']) ?? port,
          device: rawDevice is Map
              ? JuraganSyncDeviceProfile.fromJson(rawDevice)
              : JuraganSyncDeviceProfile(
                  name: '$host:$port',
                  role: deviceRoleCashier,
                  platform: 'unknown',
                ),
          schemaVersion: _int(json['version']) ?? 0,
          requiresPin: json['requires_pin'] != false,
        );
      } finally {
        client.close();
      }
    } catch (_) {
      return null;
    }
  }

  Future<Map<String, dynamic>> _getJson(
    Uri uri,
    String pin, {
    Duration timeout = const Duration(seconds: 60),
  }) async {
    final client = HttpClient()..connectionTimeout = timeout;
    try {
      final request = await client.getUrl(uri);
      request.headers.set('x-juragan-sync-pin', pin.trim());
      final response = await request.close().timeout(timeout);
      return _decodeResponse(response).timeout(timeout);
    } finally {
      client.close();
    }
  }

  Future<Map<String, dynamic>> _postJson(
    Uri uri,
    String pin,
    Map<String, dynamic> payload,
  ) async {
    const timeout = _syncPayloadTimeout;
    final client = HttpClient()..connectionTimeout = timeout;
    try {
      final request = await client.postUrl(uri);
      request.headers
        ..set('x-juragan-sync-pin', pin.trim())
        ..contentType = ContentType.json;
      request.write(jsonEncode(payload));
      final response = await request.close().timeout(timeout);
      return _decodeResponse(response).timeout(timeout);
    } finally {
      client.close();
    }
  }

  Future<Map<String, dynamic>> _decodeResponse(
      HttpClientResponse response) async {
    final text = await response.transform(utf8.decoder).join();
    final decoded = text.isEmpty ? <String, dynamic>{} : jsonDecode(text);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = decoded is Map && decoded['error'] != null
          ? decoded['error'].toString()
          : 'HTTP ${response.statusCode}';
      throw HttpException(message);
    }
    if (decoded is! Map) {
      throw const FormatException('Response sinkron tidak valid.');
    }
    return _stringMap(decoded);
  }

  Future<Map<String, dynamic>> _readJsonBody(HttpRequest request) async {
    final bytes = <int>[];
    await for (final chunk in request) {
      bytes.addAll(chunk);
      if (bytes.length > _maxPayloadBytes) {
        throw const FormatException('Data sinkron terlalu besar.');
      }
    }
    final decoded = jsonDecode(utf8.decode(bytes));
    if (decoded is! Map) {
      throw const FormatException('Payload sinkron harus object.');
    }
    return _stringMap(decoded);
  }

  bool _authorized(HttpRequest request) {
    return request.headers.value('x-juragan-sync-pin')?.trim() == _pin;
  }

  Future<void> _writeJson(
    HttpResponse response,
    int statusCode,
    Map<String, dynamic> payload,
  ) async {
    response
      ..statusCode = statusCode
      ..headers.contentType = ContentType.json
      ..write(jsonEncode(payload));
    await response.close();
  }

  Map<String, dynamic> _summaryMap(Map<String, dynamic> data) {
    final summary = JuraganSyncSummary.fromData(data);
    return {
      'categories': summary.categories,
      'products': summary.products,
      'transactions': summary.transactions,
      'customers': summary.customers,
      'suppliers': summary.suppliers,
    };
  }

  static String? _ipv4Prefix(String ip) {
    final parts = ip.split('.');
    if (parts.length != 4) return null;
    if (parts.any((part) => int.tryParse(part) == null)) return null;
    return '${parts[0]}.${parts[1]}.${parts[2]}.';
  }

  static String _defaultDeviceName() {
    final host = Platform.localHostname.trim();
    if (Platform.isAndroid) return 'HP Android';
    if (Platform.isWindows) return 'Laptop/PC Windows';
    if (Platform.isIOS) return 'iPhone';
    if (Platform.isMacOS) return 'Mac';
    if (Platform.isLinux) return 'Linux';
    if (host.isNotEmpty &&
        host.toLowerCase() != 'localhost' &&
        host.toLowerCase() != 'localhost.localdomain') {
      return host;
    }
    return 'Perangkat Juragan Servis';
  }

  static String _platformName() {
    if (Platform.isAndroid) return 'android';
    if (Platform.isWindows) return 'windows';
    if (Platform.isIOS) return 'ios';
    if (Platform.isMacOS) return 'macos';
    if (Platform.isLinux) return 'linux';
    return 'unknown';
  }

  static String _newPin() {
    final random = Random.secure();
    return List.generate(6, (_) => random.nextInt(10).toString()).join();
  }
}

class JuraganSyncMerger {
  static Map<String, dynamic> merge(
    Map<String, dynamic> local,
    Map<String, dynamic> peer, {
    Map<String, JuraganSyncProductResolution> productResolutions = const {},
    Map<String, JuraganSyncTransactionResolution> transactionResolutions =
        const {},
    JuraganSyncSettingsResolution? settingsResolution,
  }) {
    final merger = _SyncMergeEngine(
      local,
      peer,
      productResolutions,
      transactionResolutions,
      settingsResolution,
    );
    return merger.merge();
  }

  static JuraganSyncPreviewPlan previewPlan(
    Map<String, dynamic> local,
    Map<String, dynamic> peer,
    Map<String, dynamic> merged, {
    required int transactionDeleteConflicts,
    required int productConflicts,
    int settingsConflicts = 0,
  }) {
    final tables = <JuraganSyncTablePlan>[
      _tablePlan(
        local,
        peer,
        merged,
        table: 'products',
        label: 'Layanan',
        keyOf: _productKeyStatic,
      ),
      _tablePlan(
        local,
        peer,
        merged,
        table: 'transactions',
        label: 'Transaksi',
        keyOf: _transactionKey,
      ),
      _tablePlan(
        local,
        peer,
        merged,
        table: 'customers',
        label: 'Pelanggan',
        keyOf: _customerKeyStatic,
      ),
      _tablePlan(
        local,
        peer,
        merged,
        table: 'suppliers',
        label: 'Supplier',
        keyOf: _supplierKeyStatic,
      ),
      _tablePlan(
        local,
        peer,
        merged,
        table: 'categories',
        label: 'Kategori',
        keyOf: _categoryKeyStatic,
      ),
    ];
    if (settingsConflicts > 0) {
      tables.add(
        JuraganSyncTablePlan(
          table: 'settings',
          label: 'Pengaturan',
          localOnly: 0,
          peerOnly: 0,
          changed: settingsConflicts,
          finalCount: 1,
        ),
      );
    }
    return JuraganSyncPreviewPlan(
      beforeLocal: JuraganSyncSummary.fromData(local),
      beforePeer: JuraganSyncSummary.fromData(peer),
      after: JuraganSyncSummary.fromData(merged),
      tables: tables,
      transactionDeleteConflicts: transactionDeleteConflicts,
      productConflicts: productConflicts,
      settingsConflicts: settingsConflicts,
    );
  }

  static JuraganSyncSettingsConflict? findSettingsConflict(
    Map<String, dynamic> local,
    Map<String, dynamic> peer,
  ) {
    final changed = <String>[];
    final localRows = <String, Map<String, dynamic>?>{};
    final peerRows = <String, Map<String, dynamic>?>{};

    for (final table in _syncSettingsTables) {
      final localRow = _rowsFromData(local, table).isNotEmpty
          ? _rowsFromData(local, table).first
          : null;
      final peerRow = _rowsFromData(peer, table).isNotEmpty
          ? _rowsFromData(peer, table).first
          : null;
      localRows[table] = localRow;
      peerRows[table] = peerRow;
      if (_settingsFingerprint(localRow) != _settingsFingerprint(peerRow)) {
        changed.add(table);
      }
    }

    if (changed.isEmpty) return null;
    return JuraganSyncSettingsConflict(
      changedTables: changed,
      localRows: localRows,
      peerRows: peerRows,
    );
  }

  static List<JuraganSyncProductConflict> findProductConflicts(
    Map<String, dynamic> local,
    Map<String, dynamic> peer,
  ) {
    final localByKey = <String, Map<String, dynamic>>{};
    final peerByKey = <String, Map<String, dynamic>>{};
    for (final row in _rowsFromData(local, 'products')) {
      localByKey.putIfAbsent(_productKeyStatic(row), () => row);
    }
    for (final row in _rowsFromData(peer, 'products')) {
      peerByKey.putIfAbsent(_productKeyStatic(row), () => row);
    }

    const fields = [
      'name',
      'buy_price',
      'sell_price',
      'unit',
      'min_stock',
      'has_stock_management',
      'has_wholesale',
      'wholesale_min_qty',
      'wholesale_price',
      'has_extra_popup',
      'is_extra',
      'extra_target_categories',
      'extra_target_products',
      'expiry_date',
      'is_hardware',
      'duration_hours',
      'is_material',
      'supplier_id',
    ];
    final conflicts = <JuraganSyncProductConflict>[];
    for (final key in <String>{...localByKey.keys, ...peerByKey.keys}) {
      final localRow = localByKey[key];
      final peerRow = peerByKey[key];
      if (localRow == null || peerRow == null) continue;
      final changed = fields
          .where((field) =>
              _normalizedValue(localRow[field]) !=
              _normalizedValue(peerRow[field]))
          .toList();
      if (changed.isEmpty) continue;
      conflicts.add(
        JuraganSyncProductConflict(
          key: key,
          localRow: localRow,
          peerRow: peerRow,
          changedFields: changed,
        ),
      );
    }
    return conflicts;
  }

  static List<JuraganSyncTransactionDeleteConflict>
      findTransactionDeleteConflicts(
    Map<String, dynamic> local,
    Map<String, dynamic> peer,
  ) {
    final localByKey = _rowsFromData(local, 'transactions')
        .fold<Map<String, Map<String, dynamic>>>(
      <String, Map<String, dynamic>>{},
      (map, row) {
        _putBestTransactionRow(map, row);
        return map;
      },
    );
    final peerByKey = _rowsFromData(peer, 'transactions')
        .fold<Map<String, Map<String, dynamic>>>(
      <String, Map<String, dynamic>>{},
      (map, row) {
        _putBestTransactionRow(map, row);
        return map;
      },
    );

    final keys = <String>{...localByKey.keys, ...peerByKey.keys};
    final conflicts = <JuraganSyncTransactionDeleteConflict>[];
    for (final key in keys) {
      final localRow = localByKey[key];
      final peerRow = peerByKey[key];
      if (localRow == null || peerRow == null) continue;

      final localDeleted = _isDeletedTransaction(localRow);
      final peerDeleted = _isDeletedTransaction(peerRow);
      if (localDeleted == peerDeleted) continue;

      conflicts.add(
        JuraganSyncTransactionDeleteConflict(
          key: key,
          activeRow: localDeleted ? peerRow : localRow,
          deletedRow: localDeleted ? localRow : peerRow,
          deletedOnPeer: peerDeleted,
        ),
      );
    }
    return conflicts;
  }
}

JuraganSyncTablePlan _tablePlan(
  Map<String, dynamic> local,
  Map<String, dynamic> peer,
  Map<String, dynamic> merged, {
  required String table,
  required String label,
  required String Function(Map<String, dynamic> row) keyOf,
}) {
  final localByKey = <String, Map<String, dynamic>>{};
  final peerByKey = <String, Map<String, dynamic>>{};
  for (final row in _rowsFromData(local, table)) {
    localByKey.putIfAbsent(keyOf(row), () => row);
  }
  for (final row in _rowsFromData(peer, table)) {
    peerByKey.putIfAbsent(keyOf(row), () => row);
  }
  final keys = <String>{...localByKey.keys, ...peerByKey.keys};
  var localOnly = 0;
  var peerOnly = 0;
  var changed = 0;
  for (final key in keys) {
    final localRow = localByKey[key];
    final peerRow = peerByKey[key];
    if (localRow == null && peerRow != null) {
      peerOnly++;
    } else if (localRow != null && peerRow == null) {
      localOnly++;
    } else if (localRow != null &&
        peerRow != null &&
        _meaningfulFingerprint(localRow) != _meaningfulFingerprint(peerRow)) {
      changed++;
    }
  }
  return JuraganSyncTablePlan(
    table: table,
    label: label,
    localOnly: localOnly,
    peerOnly: peerOnly,
    changed: changed,
    finalCount: _rowsFromData(merged, table).length,
  );
}

class _SourceRef {
  final Map<String, dynamic> data;
  final int oldId;

  const _SourceRef(this.data, this.oldId);
}

class _SyncMergeEngine {
  final Map<String, dynamic> local;
  final Map<String, dynamic> peer;
  final Map<String, JuraganSyncProductResolution> productResolutions;
  final Map<String, JuraganSyncTransactionResolution> transactionResolutions;
  final JuraganSyncSettingsResolution? settingsResolution;

  final Map<String, dynamic> out = {
    'version': DBHelper.schemaVersion,
    'exported_at': '',
  };
  final Map<String, Map<int, int>> localIds = {};
  final Map<String, Map<int, int>> peerIds = {};
  final Map<int, List<_SourceRef>> productSources = {};
  final Set<String> _deletionSideEffectsToSkip = {};

  _SyncMergeEngine(
    this.local,
    this.peer,
    this.productResolutions,
    this.transactionResolutions,
    this.settingsResolution,
  );

  Map<String, dynamic> merge() {
    out['exported_at'] = DateTime.now().toIso8601String();

    _mergeByKey('categories', _categoryKey);
    _mergeByKey('finance_categories', _financeCategoryKey);
    _mergeProducts();
    _mergeProductRecipes();
    _mergeByKey('customers', _customerKey);
    _mergeByKey('employees', _employeeKey);
    _mergeSingleton('profil');
    _mergeSingleton('warung_profile');
    _mergeByKey('discounts', _discountKey);
    _mergeSingleton('payment_settings');
    _mergeKasirSessions();
    _mergeByKey('suppliers', _supplierKey);
    _mergePurchaseOrders();
    _mergeTransactions();
    _mergeWalletTransactions();
    _mergeStockLogs();
    _mergeTransactionItems();
    _mergeTransactionMaterialUsages();
    _mergeCicilans();
    _mergeAuditLogs();
    _mergePurchaseItems();
    _mergeReturns();
    _mergeWorkshopStations();
    _mergeWorkshopTickets();
    _recalculateProductStocks();

    for (final table in DBHelper.restoreInsertOrder) {
      out.putIfAbsent(table, () => <Map<String, dynamic>>[]);
    }
    return out;
  }

  void _mergeProducts() {
    final rows = <Map<String, dynamic>>[];
    final keyToId = <String, int>{};
    out['products'] = rows;
    localIds['products'] = {};
    peerIds['products'] = {};

    void addSource(Map<String, dynamic> data, bool isPeer) {
      for (final sourceRow in _rows(data, 'products')) {
        final oldId = _int(sourceRow['id']);
        if (oldId == null) continue;
        final row = Map<String, dynamic>.from(sourceRow);
        row['category_id'] = _mapId(
              isPeer,
              'categories',
              _int(row['category_id']),
            ) ??
            1;
        final key = _productKey(row);
        final existingId = keyToId[key];
        if (existingId != null) {
          final existing = rows.firstWhere((item) => item['id'] == existingId);
          final resolution = productResolutions[key] ??
              (isPeer
                  ? JuraganSyncProductResolution.usePeer
                  : JuraganSyncProductResolution.keepLocal);
          if (!isPeer || resolution == JuraganSyncProductResolution.usePeer) {
            _mergeNonEmptyFields(
              existing,
              row,
              preserve: {'id', 'category_id', 'stock'},
            );
          } else {
            _mergeNonEmptyFields(
              existing,
              row,
              preserve: {
                'id',
                'category_id',
                'stock',
                'name',
                'buy_price',
                'sell_price',
                'unit',
                'min_stock',
                'has_stock_management',
                'has_wholesale',
                'wholesale_min_qty',
                'wholesale_price',
                'has_extra_popup',
                'is_extra',
                'extra_target_categories',
                'extra_target_products',
                'expiry_date',
                'is_hardware',
                'duration_hours',
                'is_material',
                'supplier_id',
              },
            );
          }
          (isPeer ? peerIds : localIds)['products']![oldId] = existingId;
          productSources.putIfAbsent(existingId, () => []).add(
                _SourceRef(data, oldId),
              );
          continue;
        }

        final newId = rows.length + 1;
        row['id'] = newId;
        rows.add(row);
        keyToId[key] = newId;
        (isPeer ? peerIds : localIds)['products']![oldId] = newId;
        productSources[newId] = [_SourceRef(data, oldId)];
      }
    }

    addSource(local, false);
    addSource(peer, true);
  }

  void _mergePurchaseOrders() {
    _mergeByKey(
      'purchase_orders',
      (row) =>
          '${_str(row['created_at'])}|${_str(row['supplier_name'])}|${_str(row['total_amount'])}|${_str(row['status'])}',
      transform: (row, isPeer) {
        row['supplier_id'] = _mapNullableId(
          isPeer,
          'suppliers',
          _int(row['supplier_id']),
        );
      },
    );
  }

  void _mergeProductRecipes() {
    _mergeByKey(
      'product_recipes',
      (row) => [
        _str(row['service_product_id']),
        _str(row['material_product_id']),
        _str(row['qty_per_unit']),
      ].join('|'),
      transform: (row, isPeer) {
        final serviceId = _mapId(
          isPeer,
          'products',
          _int(row['service_product_id']),
        );
        final materialId = _mapId(
          isPeer,
          'products',
          _int(row['material_product_id']),
        );
        if (serviceId == null || materialId == null) {
          row['_skip'] = true;
          return;
        }
        row['service_product_id'] = serviceId;
        row['material_product_id'] = materialId;
      },
    );
  }

  void _mergeTransactions() {
    final rows = <Map<String, dynamic>>[];
    out['transactions'] = rows;
    localIds['transactions'] = {};
    peerIds['transactions'] = {};

    final localByKey = <String, Map<String, dynamic>>{};
    final peerByKey = <String, Map<String, dynamic>>{};
    for (final row in _rows(local, 'transactions')) {
      _putBestTransactionRow(localByKey, row);
    }
    for (final row in _rows(peer, 'transactions')) {
      _putBestTransactionRow(peerByKey, row);
    }

    final keys = <String>{...localByKey.keys, ...peerByKey.keys};
    for (final key in keys) {
      final localRow = localByKey[key];
      final peerRow = peerByKey[key];

      Map<String, dynamic> selected;
      var selectedIsPeer = false;
      var customerIdSourceIsPeer = false;

      if (localRow != null && peerRow != null) {
        final localDeleted = _isDeletedTransaction(localRow);
        final peerDeleted = _isDeletedTransaction(peerRow);

        if (localDeleted != peerDeleted) {
          final resolution = transactionResolutions[key] ??
              JuraganSyncTransactionResolution.keepDeleted;
          final restoreActive =
              resolution == JuraganSyncTransactionResolution.restoreActive;
          if (restoreActive) {
            selected = localDeleted ? peerRow : localRow;
            selectedIsPeer = localDeleted;
            _markDeletionSideEffectsToSkip(
              isPeer: peerDeleted,
              transactionId: _int((peerDeleted ? peerRow : localRow)['id']),
            );
          } else {
            selected = localDeleted ? localRow : peerRow;
            selectedIsPeer = peerDeleted;
          }
        } else {
          selected = Map<String, dynamic>.from(localRow);
          _mergeNonEmptyFields(selected, peerRow, preserve: {
            'id',
            'customer_id',
          });
          _mergeTransactionPaymentState(selected, localRow, peerRow);
          final localCustomerId = _int(localRow['customer_id']);
          final peerCustomerId = _int(peerRow['customer_id']);
          if ((localCustomerId == null || localCustomerId <= 0) &&
              peerCustomerId != null &&
              peerCustomerId > 0) {
            selected['customer_id'] = peerCustomerId;
            customerIdSourceIsPeer = true;
          }
        }
      } else if (localRow != null) {
        selected = localRow;
      } else if (peerRow != null) {
        selected = peerRow;
        selectedIsPeer = true;
        customerIdSourceIsPeer = true;
      } else {
        continue;
      }

      final row = Map<String, dynamic>.from(selected);
      row['customer_id'] = _mapNullableId(
        customerIdSourceIsPeer || selectedIsPeer,
        'customers',
        _int(row['customer_id']),
      );

      final newId = rows.length + 1;
      row['id'] = newId;
      rows.add(row);

      final localOldId = localRow == null ? null : _int(localRow['id']);
      final peerOldId = peerRow == null ? null : _int(peerRow['id']);
      if (localOldId != null) localIds['transactions']![localOldId] = newId;
      if (peerOldId != null) peerIds['transactions']![peerOldId] = newId;
    }
  }

  void _mergeKasirSessions() {
    final rows = <Map<String, dynamic>>[];
    final keyToId = <String, int>{};
    out['kasir_sessions'] = rows;
    localIds['kasir_sessions'] = {};
    peerIds['kasir_sessions'] = {};

    void addSource(Map<String, dynamic> data, bool isPeer) {
      for (final sourceRow in _rows(data, 'kasir_sessions')) {
        final oldId = _int(sourceRow['id']);
        final row = Map<String, dynamic>.from(sourceRow);
        final key = _kasirSessionKey(row);
        final existingId = keyToId[key];
        if (existingId != null) {
          final existing = rows.firstWhere((item) => item['id'] == existingId);
          if (_preferKasirSessionRow(row, existing)) {
            row['id'] = existingId;
            existing
              ..clear()
              ..addAll(row);
          }
          if (oldId != null) {
            (isPeer ? peerIds : localIds)['kasir_sessions']![oldId] =
                existingId;
          }
          continue;
        }

        final newId = rows.length + 1;
        row['id'] = newId;
        rows.add(row);
        keyToId[key] = newId;
        if (oldId != null) {
          (isPeer ? peerIds : localIds)['kasir_sessions']![oldId] = newId;
        }
      }
    }

    addSource(local, false);
    addSource(peer, true);
  }

  void _mergeWalletTransactions() {
    _mergeByKey(
      'wallet_transactions',
      _walletKey,
      preferDeleted: true,
      preferLatestUpdatedAt: true,
      transform: (row, isPeer) {
        if (_isSkippedDeletionWallet(row, isPeer)) {
          row['_skip'] = true;
          return;
        }
        row['category_id'] = _mapNullableId(
          isPeer,
          'finance_categories',
          _int(row['category_id']),
        );
      },
    );
  }

  void _mergeStockLogs() {
    _mergeByKey(
      'stock_logs',
      (row) => [
        _str(row['product_id']),
        _str(row['type']),
        _str(row['qty']),
        _str(row['date']),
        _str(row['stock_name']).toLowerCase(),
      ].join('|'),
      transform: (row, isPeer) {
        if (_isSkippedDeletionStockLog(row, isPeer)) {
          row['_skip'] = true;
          return;
        }
        final productId = _mapId(isPeer, 'products', _int(row['product_id']));
        if (productId == null) {
          row['_skip'] = true;
          return;
        }
        row['product_id'] = productId;
      },
    );
  }

  void _markDeletionSideEffectsToSkip({
    required bool isPeer,
    required int? transactionId,
  }) {
    if (transactionId == null) return;
    _deletionSideEffectsToSkip.add(_sideEffectKey(isPeer, transactionId));
  }

  bool _isSkippedDeletionStockLog(
    Map<String, dynamic> row,
    bool isPeer,
  ) {
    final name = _str(row['stock_name']).trim().toLowerCase();
    for (final key in _deletionSideEffectsToSkip) {
      final parsed = _parseSideEffectKey(key);
      if (parsed == null || parsed.$1 != isPeer) continue;
      if (name == 'pembatalan transaksi #${parsed.$2}'.toLowerCase() ||
          name ==
              'pembatalan bahan baku transaksi #${parsed.$2}'.toLowerCase()) {
        return true;
      }
    }
    return false;
  }

  bool _isSkippedDeletionWallet(
    Map<String, dynamic> row,
    bool isPeer,
  ) {
    final note = _str(row['keterangan']).trim().toLowerCase();
    for (final key in _deletionSideEffectsToSkip) {
      final parsed = _parseSideEffectKey(key);
      if (parsed == null || parsed.$1 != isPeer) continue;
      if (note == 'pembatalan penjualan #${parsed.$2}'.toLowerCase()) {
        return true;
      }
    }
    return false;
  }

  void _mergeTransactionItems() {
    _mergeByKey(
      'transaction_items',
      (row) => [
        _str(row['transaction_id']),
        _str(row['product_id']),
        _str(row['qty']),
        _str(row['unit_price']),
        _str(row['subtotal']),
        _str(row['note']),
      ].join('|'),
      transform: (row, isPeer) {
        final txId =
            _mapId(isPeer, 'transactions', _int(row['transaction_id']));
        final productId = _mapId(isPeer, 'products', _int(row['product_id']));
        if (txId == null || productId == null) {
          row['_skip'] = true;
          return;
        }
        row['transaction_id'] = txId;
        row['product_id'] = productId;
      },
    );
  }

  void _mergeTransactionMaterialUsages() {
    _mergeByKey(
      'transaction_material_usages',
      (row) => [
        _str(row['transaction_id']),
        _str(row['service_product_id']),
        _str(row['material_product_id']),
        _str(row['qty']),
        _str(row['created_at']),
      ].join('|'),
      transform: (row, isPeer) {
        final txId =
            _mapId(isPeer, 'transactions', _int(row['transaction_id']));
        final serviceId = _mapId(
          isPeer,
          'products',
          _int(row['service_product_id']),
        );
        final materialId = _mapId(
          isPeer,
          'products',
          _int(row['material_product_id']),
        );
        if (txId == null || serviceId == null || materialId == null) {
          row['_skip'] = true;
          return;
        }
        row['transaction_id'] = txId;
        row['service_product_id'] = serviceId;
        row['material_product_id'] = materialId;
      },
    );
  }

  void _mergeCicilans() {
    _mergeByKey(
      'cicilans',
      (row) => [
        _str(row['transaction_id']),
        _str(row['nominal']),
        _str(row['metode_pembayaran']),
        _str(row['created_at']),
      ].join('|'),
      transform: (row, isPeer) {
        final txId =
            _mapId(isPeer, 'transactions', _int(row['transaction_id']));
        if (txId == null) {
          row['_skip'] = true;
          return;
        }
        row['transaction_id'] = txId;
      },
    );
  }

  void _mergePurchaseItems() {
    _mergeByKey(
      'purchase_items',
      (row) => [
        _str(row['purchase_order_id']),
        _str(row['product_id']),
        _str(row['qty']),
        _str(row['unit_price']),
        _str(row['subtotal']),
      ].join('|'),
      transform: (row, isPeer) {
        final poId = _mapId(
          isPeer,
          'purchase_orders',
          _int(row['purchase_order_id']),
        );
        final productId = _mapId(isPeer, 'products', _int(row['product_id']));
        if (poId == null || productId == null) {
          row['_skip'] = true;
          return;
        }
        row['purchase_order_id'] = poId;
        row['product_id'] = productId;
      },
    );
  }

  void _mergeReturns() {
    _mergeByKey(
      'return_transactions',
      (row) => [
        _str(row['transaction_id']),
        _str(row['created_at']),
        _str(row['total_refund']),
        _str(row['reason']),
      ].join('|'),
      transform: (row, isPeer) {
        final txId =
            _mapId(isPeer, 'transactions', _int(row['transaction_id']));
        if (txId == null) {
          row['_skip'] = true;
          return;
        }
        row['transaction_id'] = txId;
      },
    );

    _mergeByKey(
      'return_items',
      (row) => [
        _str(row['return_id']),
        _str(row['product_id']),
        _str(row['qty']),
        _str(row['subtotal']),
      ].join('|'),
      transform: (row, isPeer) {
        final returnId = _mapId(
          isPeer,
          'return_transactions',
          _int(row['return_id']),
        );
        final productId = _mapId(isPeer, 'products', _int(row['product_id']));
        if (returnId == null || productId == null) {
          row['_skip'] = true;
          return;
        }
        row['return_id'] = returnId;
        row['product_id'] = productId;
      },
    );
  }

  void _mergeAuditLogs() {
    _mergeByKey(
      'audit_logs',
      (row) => [
        _str(row['action']),
        _str(row['entity_type']),
        _str(row['entity_id']),
        _str(row['staff_name']).toLowerCase(),
        _str(row['amount']),
        _str(row['note']),
        _str(row['created_at']),
      ].join('|'),
      transform: (row, isPeer) {
        final entityType = _str(row['entity_type']).toLowerCase();
        final oldEntityId = _int(row['entity_id']);
        final mappedId = switch (entityType) {
          'product' || 'produk' => _mapNullableId(
              isPeer,
              'products',
              oldEntityId,
            ),
          'transaction' || 'transaksi' => _mapNullableId(
              isPeer,
              'transactions',
              oldEntityId,
            ),
          'customer' || 'pelanggan' => _mapNullableId(
              isPeer,
              'customers',
              oldEntityId,
            ),
          'employee' || 'karyawan' => _mapNullableId(
              isPeer,
              'employees',
              oldEntityId,
            ),
          _ => oldEntityId,
        };
        row['entity_id'] = mappedId;
        row['staff_id'] = _mapNullableId(
          isPeer,
          'employees',
          _int(row['staff_id']),
        );
      },
    );
  }

  void _mergeWorkshopStations() {
    _mergeByKey(
      'fnb_tables',
      (row) {
        final slug = _str(row['qr_slug']).trim().toLowerCase();
        if (slug.isNotEmpty) return 'slug:$slug';
        return '${_str(row['area']).trim().toLowerCase()}|${_str(row['name']).trim().toLowerCase()}';
      },
      transform: (row, isPeer) {
        row['_sync_is_peer'] = isPeer;
        row['_sync_old_merged_to_table_id'] = row['merged_to_table_id'];
        row['active_transaction_id'] = _mapNullableId(
          isPeer,
          'transactions',
          _int(row['active_transaction_id']),
        );
      },
    );

    for (final table in ['fnb_tables']) {
      final rows = _mutableRows(out, table);
      for (final row in rows) {
        final sourceIsPeer = row.remove('_sync_is_peer') == true;
        final oldMergedId = _int(row.remove('_sync_old_merged_to_table_id'));
        row['merged_to_table_id'] =
            _mapNullableId(sourceIsPeer, table, oldMergedId);
      }
    }
  }

  void _mergeWorkshopTickets() {
    _mergeByKey(
      'fnb_kitchen_tickets',
      (row) => [
        _str(row['transaction_id']),
        _str(row['table_name']).toLowerCase(),
        _str(row['station']).toLowerCase(),
        _str(row['status']),
        _str(row['created_at']),
      ].join('|'),
      transform: (row, isPeer) {
        final txId =
            _mapId(isPeer, 'transactions', _int(row['transaction_id']));
        if (txId == null) {
          row['_skip'] = true;
          return;
        }
        row['transaction_id'] = txId;
      },
    );
  }

  void _mergeSingleton(String table) {
    final rows = <Map<String, dynamic>>[];
    out[table] = rows;
    localIds[table] = {};
    peerIds[table] = {};

    final localRow =
        _rows(local, table).isNotEmpty ? _rows(local, table).first : null;
    final peerRow =
        _rows(peer, table).isNotEmpty ? _rows(peer, table).first : null;
    final selected = <String, dynamic>{};
    final settingsChoice =
        _syncSettingsTables.contains(table) ? settingsResolution : null;
    if (settingsChoice != null) {
      final chosen = settingsChoice == JuraganSyncSettingsResolution.usePeer
          ? peerRow ?? localRow
          : localRow ?? peerRow;
      if (chosen != null) selected.addAll(chosen);
    } else {
      if (localRow != null) selected.addAll(localRow);
      if (peerRow != null) _mergeNonEmptyFields(selected, peerRow);
    }
    if (selected.isEmpty) return;
    final oldLocalId = localRow == null ? null : _int(localRow['id']);
    final oldPeerId = peerRow == null ? null : _int(peerRow['id']);
    selected['id'] = 1;
    rows.add(selected);
    if (oldLocalId != null) localIds[table]![oldLocalId] = 1;
    if (oldPeerId != null) peerIds[table]![oldPeerId] = 1;
  }

  void _mergeByKey(
    String table,
    String Function(Map<String, dynamic> row) keyOf, {
    void Function(Map<String, dynamic> row, bool isPeer)? transform,
    bool preferDeleted = false,
    bool preferLatestUpdatedAt = false,
  }) {
    final rows = <Map<String, dynamic>>[];
    final keyToId = <String, int>{};
    out[table] = rows;
    localIds[table] = {};
    peerIds[table] = {};

    void addSource(Map<String, dynamic> data, bool isPeer) {
      for (final sourceRow in _rows(data, table)) {
        final oldId = _int(sourceRow['id']);
        final row = Map<String, dynamic>.from(sourceRow);
        transform?.call(row, isPeer);
        if (row.remove('_skip') == true) continue;

        final key = keyOf(row);
        final existingId = keyToId[key];
        if (existingId != null) {
          final existing = rows.firstWhere((item) => item['id'] == existingId);
          if (preferDeleted && _isDeletedRow(row)) {
            _mergeNonEmptyFields(existing, row, preserve: {'id'});
            existing['is_deleted'] = 1;
          } else if (preferLatestUpdatedAt && !_isDeletedRow(existing)) {
            final existingUpdatedAt = _dateTimeValue(
              existing['updated_at'] ?? existing['created_at'],
            );
            final rowUpdatedAt = _dateTimeValue(
              row['updated_at'] ?? row['created_at'],
            );
            if (existingUpdatedAt == null ||
                (rowUpdatedAt != null &&
                    rowUpdatedAt.isAfter(existingUpdatedAt))) {
              _mergeNonEmptyFields(existing, row, preserve: {'id'});
            }
          }
          if (oldId != null) {
            (isPeer ? peerIds : localIds)[table]![oldId] = existingId;
          }
          continue;
        }

        final newId = rows.length + 1;
        row['id'] = newId;
        rows.add(row);
        keyToId[key] = newId;
        if (oldId != null) {
          (isPeer ? peerIds : localIds)[table]![oldId] = newId;
        }
      }
    }

    addSource(local, false);
    addSource(peer, true);
  }

  void _recalculateProductStocks() {
    final products = _mutableRows(out, 'products');
    final logs = _mutableRows(out, 'stock_logs');
    for (final product in products) {
      if (_int(product['has_stock_management']) != 1) continue;
      final productId = _int(product['id']);
      if (productId == null) continue;

      var baseStock = _numValue(product['stock']) ?? 0;
      final refs = productSources[productId] ?? const <_SourceRef>[];
      if (refs.isNotEmpty) {
        baseStock = refs
            .map((ref) => _estimateBaseStock(ref.data, ref.oldId))
            .fold<num>(0, max);
      }

      num inQty = 0;
      num outQty = 0;
      for (final log in logs) {
        if (_int(log['product_id']) != productId) continue;
        final qty = _numValue(log['qty']) ?? 0;
        if (_str(log['type']) == 'in') {
          inQty += qty;
        } else {
          outQty += qty;
        }
      }
      product['stock'] = max(0, baseStock + inQty - outQty);
    }
  }

  num _estimateBaseStock(Map<String, dynamic> data, int oldProductId) {
    final product = _rows(data, 'products').firstWhere(
      (row) => _int(row['id']) == oldProductId,
      orElse: () => const <String, dynamic>{},
    );
    var stock = _numValue(product['stock']) ?? 0;
    num inQty = 0;
    num outQty = 0;
    for (final log in _rows(data, 'stock_logs')) {
      if (_int(log['product_id']) != oldProductId) continue;
      final qty = _numValue(log['qty']) ?? 0;
      if (_str(log['type']) == 'in') {
        inQty += qty;
      } else {
        outQty += qty;
      }
    }
    return max(0, stock - inQty + outQty);
  }

  int? _mapId(bool peerSource, String table, int? oldId) {
    if (oldId == null) return null;
    return (peerSource ? peerIds : localIds)[table]?[oldId];
  }

  int? _mapNullableId(bool peerSource, String table, int? oldId) {
    if (oldId == null || oldId <= 0) return null;
    return _mapId(peerSource, table, oldId);
  }

  List<Map<String, dynamic>> _rows(Map<String, dynamic> data, String table) {
    final raw = data[table];
    if (raw is! List) return <Map<String, dynamic>>[];
    return raw
        .whereType<Map>()
        .map((row) => row.map((key, value) => MapEntry(key.toString(), value)))
        .toList();
  }

  List<Map<String, dynamic>> _mutableRows(
    Map<String, dynamic> data,
    String table,
  ) {
    final raw = data[table];
    if (raw is! List) return <Map<String, dynamic>>[];
    return raw.whereType<Map<String, dynamic>>().toList();
  }

  String _categoryKey(Map<String, dynamic> row) {
    return _str(row['name']).trim().toLowerCase();
  }

  String _financeCategoryKey(Map<String, dynamic> row) {
    final type =
        _str(row['type']).trim().toLowerCase() == 'masuk' ? 'masuk' : 'keluar';
    return '$type|${_str(row['name']).trim().toLowerCase()}';
  }

  String _productKey(Map<String, dynamic> row) {
    final barcode = _str(row['barcode']).trim().toLowerCase();
    if (barcode.isNotEmpty) return 'barcode:$barcode';
    final sku = _str(row['sku']).trim().toLowerCase();
    if (sku.isNotEmpty) return 'sku:$sku';
    return [
      _str(row['name']).trim().toLowerCase(),
      _str(row['category_id']),
      _str(row['unit']).trim().toLowerCase(),
      _str(row['is_extra']),
      _str(row['is_hardware']),
      _str(row['is_material']),
    ].join('|');
  }

  String _customerKey(Map<String, dynamic> row) {
    final phone = _str(row['phone']).trim().toLowerCase();
    if (phone.isNotEmpty) return 'phone:$phone';
    return '${_str(row['name']).trim().toLowerCase()}|${_str(row['address']).trim().toLowerCase()}';
  }

  String _employeeKey(Map<String, dynamic> row) {
    final phone = _str(row['phone']).trim().toLowerCase();
    if (phone.isNotEmpty) return 'phone:$phone';
    return '${_str(row['name']).trim().toLowerCase()}|${_str(row['role']).trim().toLowerCase()}';
  }

  String _supplierKey(Map<String, dynamic> row) {
    final phone = _str(row['phone']).trim().toLowerCase();
    if (phone.isNotEmpty) return 'phone:$phone';
    return _str(row['name']).trim().toLowerCase();
  }

  String _walletKey(Map<String, dynamic> row) {
    final source = _str(row['source']).trim().toLowerCase();
    final createdAt = _str(row['created_at']).trim();
    if ((source == 'manual' || source == 'adjustment') &&
        createdAt.isNotEmpty) {
      return 'editable-wallet:$source|$createdAt';
    }
    return [
      _str(row['wallet_id']),
      _str(row['type']),
      _str(row['nominal']),
      _str(row['created_at']),
      _str(row['keterangan']),
    ].join('|');
  }

  String _discountKey(Map<String, dynamic> row) {
    return [
      _str(row['name']).toLowerCase(),
      _str(row['nominal']),
      _str(row['is_percentage']),
      _str(row['start_date']),
      _str(row['end_date']),
      _str(row['product_ids']),
    ].join('|');
  }

  String _kasirSessionKey(Map<String, dynamic> row) {
    return [
      _str(row['device_id']).trim().toLowerCase(),
      _str(row['kasir_name']).toLowerCase(),
      _str(row['opened_at']),
      _str(row['shift_name']).toLowerCase(),
    ].join('|');
  }

  bool _preferKasirSessionRow(
    Map<String, dynamic> candidate,
    Map<String, dynamic> current,
  ) {
    final candidateClosed = _isClosedKasirSession(candidate);
    final currentClosed = _isClosedKasirSession(current);
    if (candidateClosed != currentClosed) return candidateClosed;

    final candidateClosedAt = _dateTimeValue(candidate['closed_at']);
    final currentClosedAt = _dateTimeValue(current['closed_at']);
    if (candidateClosedAt != null && currentClosedAt != null) {
      return candidateClosedAt.isAfter(currentClosedAt);
    }
    if (candidateClosedAt != null) return true;
    if (currentClosedAt != null) return false;

    final candidateRevenue = _int(candidate['total_revenue']) ?? 0;
    final currentRevenue = _int(current['total_revenue']) ?? 0;
    if (candidateRevenue != currentRevenue) {
      return candidateRevenue > currentRevenue;
    }

    final candidateOpenedAt = _dateTimeValue(candidate['opened_at']);
    final currentOpenedAt = _dateTimeValue(current['opened_at']);
    if (candidateOpenedAt != null && currentOpenedAt != null) {
      return candidateOpenedAt.isAfter(currentOpenedAt);
    }
    return false;
  }

  bool _isClosedKasirSession(Map<String, dynamic> row) {
    return _str(row['closed_at']).trim().isNotEmpty;
  }

  void _mergeNonEmptyFields(
    Map<String, dynamic> target,
    Map<String, dynamic> source, {
    Set<String> preserve = const {'id'},
  }) {
    for (final entry in source.entries) {
      if (preserve.contains(entry.key)) continue;
      final value = entry.value;
      if (value == null) continue;
      if (value is String && value.trim().isEmpty) continue;
      target[entry.key] = value;
    }
  }

  void _mergeTransactionPaymentState(
    Map<String, dynamic> target,
    Map<String, dynamic> localRow,
    Map<String, dynamic> peerRow,
  ) {
    final localPaidNet = _transactionPaidNet(localRow);
    final peerPaidNet = _transactionPaidNet(peerRow);
    final localLunas = _isPaidTransaction(localRow);
    final peerLunas = _isPaidTransaction(peerRow);
    final selectedLunas = localLunas || peerLunas;

    final paymentSource =
        peerPaidNet > localPaidNet || (!localLunas && peerLunas)
            ? peerRow
            : localRow;

    for (final field in const [
      'amount_paid',
      'change_amount',
      'payment_status',
      'due_date',
      'last_reminder_at',
      'reminder_count',
    ]) {
      if (paymentSource.containsKey(field)) {
        target[field] = paymentSource[field];
      }
    }

    if (selectedLunas) {
      final grandTotal = _int(target['grand_total']) ?? 0;
      final amountPaid = _int(target['amount_paid']) ?? 0;
      if (amountPaid < grandTotal) {
        target['amount_paid'] = grandTotal;
        target['change_amount'] = 0;
      }
      target['payment_status'] = 'Lunas';
    } else {
      final status = _str(target['payment_status']).trim();
      if (status.isEmpty) {
        target['payment_status'] = 'Belum Lunas';
      }
    }
  }
}

Map<String, dynamic> _stringMap(Map<dynamic, dynamic> raw) {
  return raw.map((key, value) => MapEntry(key.toString(), value));
}

List<Map<String, dynamic>> _rowsFromData(
  Map<String, dynamic> data,
  String table,
) {
  final raw = data[table];
  if (raw is! List) return <Map<String, dynamic>>[];
  return raw
      .whereType<Map>()
      .map((row) => row.map((key, value) => MapEntry(key.toString(), value)))
      .toList();
}

String _categoryKeyStatic(Map<String, dynamic> row) {
  return _str(row['name']).trim().toLowerCase();
}

String _productKeyStatic(Map<String, dynamic> row) {
  final barcode = _str(row['barcode']).trim().toLowerCase();
  if (barcode.isNotEmpty) return 'barcode:$barcode';
  final sku = _str(row['sku']).trim().toLowerCase();
  if (sku.isNotEmpty) return 'sku:$sku';
  return [
    _str(row['name']).trim().toLowerCase(),
    _str(row['category_id']),
    _str(row['unit']).trim().toLowerCase(),
    _str(row['is_extra']),
    _str(row['is_hardware']),
    _str(row['is_material']),
  ].join('|');
}

String _customerKeyStatic(Map<String, dynamic> row) {
  final phone = _str(row['phone']).trim().toLowerCase();
  if (phone.isNotEmpty) return 'phone:$phone';
  return '${_str(row['name']).trim().toLowerCase()}|${_str(row['address']).trim().toLowerCase()}';
}

String _supplierKeyStatic(Map<String, dynamic> row) {
  final phone = _str(row['phone']).trim().toLowerCase();
  if (phone.isNotEmpty) return 'phone:$phone';
  return _str(row['name']).trim().toLowerCase();
}

String _meaningfulFingerprint(Map<String, dynamic> row) {
  final copy = Map<String, dynamic>.from(row)
    ..remove('id')
    ..remove('created_at');
  final entries = copy.entries.toList()..sort((a, b) => a.key.compareTo(b.key));
  return entries
      .map((entry) => '${entry.key}:${_normalizedValue(entry.value)}')
      .join('|');
}

String _normalizedValue(Object? value) {
  if (value == null) return '';
  if (value is num) return value.toString();
  return value.toString().trim();
}

String _settingsFingerprint(Map<String, dynamic>? row) {
  if (row == null || row.isEmpty) return '';
  final copy = Map<String, dynamic>.from(row)
    ..remove('id')
    ..remove('created_at')
    ..remove('updated_at');
  final entries = copy.entries.toList()..sort((a, b) => a.key.compareTo(b.key));
  return entries
      .map((entry) => '${entry.key}:${_normalizedValue(entry.value)}')
      .join('|');
}

String _settingValue(Map<String, dynamic>? row, List<String> keys) {
  if (row == null) return '';
  for (final key in keys) {
    final value = row[key]?.toString().trim() ?? '';
    if (value.isNotEmpty) return value;
  }
  return '';
}

String _transactionKey(Map<String, dynamic> row) {
  final code = _str(row['transaction_code']).trim().toLowerCase();
  if (code.isNotEmpty) return 'code:$code';
  final createdAt = _str(row['created_at']).trim();
  if (createdAt.isNotEmpty) {
    return [
      'created',
      createdAt,
      _str(row['payment_method']).trim().toLowerCase(),
      _str(row['customer_name']).trim().toLowerCase(),
      _str(row['order_type']).trim().toLowerCase(),
      _str(row['pickup_schedule']).trim().toLowerCase(),
    ].join('|');
  }
  return [
    _str(row['grand_total']),
    _str(row['payment_method']),
    _str(row['customer_name']).toLowerCase(),
  ].join('|');
}

bool _isDeletedTransaction(Map<String, dynamic> row) {
  return _int(row['is_deleted']) == 1;
}

void _putBestTransactionRow(
  Map<String, Map<String, dynamic>> rowsByKey,
  Map<String, dynamic> row,
) {
  final key = _transactionKey(row);
  final existing = rowsByKey[key];
  if (existing == null || _preferTransactionRow(row, existing)) {
    rowsByKey[key] = row;
  }
}

bool _preferTransactionRow(
  Map<String, dynamic> candidate,
  Map<String, dynamic> current,
) {
  final candidateDeleted = _isDeletedTransaction(candidate);
  final currentDeleted = _isDeletedTransaction(current);
  if (candidateDeleted != currentDeleted) return candidateDeleted;

  final candidatePaid = _isPaidTransaction(candidate);
  final currentPaid = _isPaidTransaction(current);
  if (candidatePaid != currentPaid) return candidatePaid;

  final candidatePaidNet = _transactionPaidNet(candidate);
  final currentPaidNet = _transactionPaidNet(current);
  if (candidatePaidNet != currentPaidNet) {
    return candidatePaidNet > currentPaidNet;
  }

  final candidateId = _int(candidate['id']) ?? 0;
  final currentId = _int(current['id']) ?? 0;
  return candidateId > currentId;
}

bool _isPaidTransaction(Map<String, dynamic> row) {
  final amountPaid = _int(row['amount_paid']) ?? 0;
  final grandTotal = _int(row['grand_total']) ?? 0;
  final status = _str(row['payment_status']).trim().toLowerCase();
  return (grandTotal > 0 && amountPaid >= grandTotal) || status == 'lunas';
}

int _transactionPaidNet(Map<String, dynamic> row) {
  final amountPaid = _int(row['amount_paid']) ?? 0;
  final changeAmount = _int(row['change_amount']) ?? 0;
  final grandTotal = _int(row['grand_total']) ?? 0;
  final paidNet = amountPaid - changeAmount;
  if (grandTotal <= 0) return paidNet < 0 ? 0 : paidNet;
  return paidNet.clamp(0, grandTotal).toInt();
}

bool _isDeletedRow(Map<String, dynamic> row) {
  return _int(row['is_deleted']) == 1;
}

String _sideEffectKey(bool isPeer, int transactionId) {
  return '${isPeer ? 'peer' : 'local'}:$transactionId';
}

(bool, int)? _parseSideEffectKey(String key) {
  final parts = key.split(':');
  if (parts.length != 2) return null;
  final id = int.tryParse(parts[1]);
  if (id == null) return null;
  return (parts[0] == 'peer', id);
}

String _str(Object? value) => value?.toString() ?? '';

int? _int(Object? value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse(value?.toString() ?? '');
}

num? _numValue(Object? value) {
  if (value is num) return value;
  return num.tryParse(value?.toString() ?? '');
}

DateTime? _dateTimeValue(Object? value) {
  final raw = value?.toString().trim();
  if (raw == null || raw.isEmpty) return null;
  return DateTime.tryParse(raw);
}

