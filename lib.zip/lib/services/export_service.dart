import 'dart:io';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:csv/csv.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import '../database/db_helper.dart';

class ExportService {
  const ExportService._();

  static const _brand = PdfColor.fromInt(0xFF2563EB);
  static const _brandDark = PdfColor.fromInt(0xFF1E3A8A);
  static const _ink = PdfColor.fromInt(0xFF0F172A);
  static const _muted = PdfColor.fromInt(0xFF64748B);
  static const _line = PdfColor.fromInt(0xFFE2E8F0);
  static const _paper = PdfColor.fromInt(0xFFF8FAFC);
  static const _success = PdfColor.fromInt(0xFF059669);
  static const _warning = PdfColor.fromInt(0xFFF59E0B);
  static const _danger = PdfColor.fromInt(0xFFDC2626);
  static const _accent = PdfColor.fromInt(0xFF7C3AED);
  static const _teal = PdfColor.fromInt(0xFF0F766E);
  static const _rose = PdfColor.fromInt(0xFFE11D48);

  static const _chartColors = <PdfColor>[
    _brand,
    _success,
    _warning,
    _danger,
    _accent,
    _teal,
    _rose,
  ];

  static Future<File> createCsvFile({
    required String filePrefix,
    required List<String> headers,
    required List<List<Object?>> rows,
  }) async {
    final safePrefix = _sanitize(filePrefix);
    final timestamp = DateTime.now()
        .toIso8601String()
        .replaceAll(':', '-')
        .replaceAll('.', '-');
    final csvRows = <List<dynamic>>[headers, ...rows];
    final csvString = const CsvEncoder().convert(csvRows);
    final dir = await getTemporaryDirectory();
    final file = File(p.join(dir.path, '${safePrefix}_$timestamp.csv'));

    // BOM is added so Microsoft Excel can read UTF-8 correctly.
    await file.writeAsString('\uFEFF$csvString', flush: true);
    return file;
  }

  static Future<String?> saveCsvToDevice({
    required String filePrefix,
    required List<String> headers,
    required List<List<Object?>> rows,
    String? dialogTitle,
    bool askLocationFirst = true,
  }) async {
    final safePrefix = _sanitize(filePrefix);
    final timestamp = DateTime.now()
        .toIso8601String()
        .replaceAll(':', '-')
        .replaceAll('.', '-');
    final fileName = '${safePrefix}_$timestamp.csv';
    final bytes = _buildCsvBytes(headers: headers, rows: rows);

    if (!askLocationFirst &&
        (Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      final downloadDir = await getDownloadsDirectory();
      if (downloadDir != null) {
        await downloadDir.create(recursive: true);
        final file = File(p.join(downloadDir.path, fileName));
        await file.writeAsBytes(bytes, flush: true);
        return file.path;
      }
    }

    if (!askLocationFirst && Platform.isAndroid) {
      final publicDownloads = Directory('/storage/emulated/0/Download');
      try {
        if (await publicDownloads.exists()) {
          final file = File(p.join(publicDownloads.path, fileName));
          await file.writeAsBytes(bytes, flush: true);
          return file.path;
        }
      } catch (_) {
        // Android scoped storage can block direct writes to Downloads.
      }
    }

    final outputPath = await FilePicker.platform.saveFile(
      dialogTitle: dialogTitle ?? 'Simpan File CSV',
      fileName: fileName,
      type: FileType.custom,
      allowedExtensions: const ['csv'],
      bytes: Platform.isAndroid || Platform.isIOS ? bytes : null,
    );
    if (outputPath == null) return null;

    if (!Platform.isAndroid && !Platform.isIOS) {
      await File(outputPath).writeAsBytes(bytes, flush: true);
    }
    return outputPath;
  }

  static Uint8List _buildCsvBytes({
    required List<String> headers,
    required List<List<Object?>> rows,
  }) {
    final csvRows = <List<dynamic>>[headers, ...rows];
    final csvString = const CsvEncoder().convert(csvRows);
    return Uint8List.fromList(utf8.encode('\uFEFF$csvString'));
  }

  static Future<void> exportAndShareCsv({
    required String filePrefix,
    required List<String> headers,
    required List<List<Object?>> rows,
    String? subject,
    String? message,
  }) async {
    final file = await createCsvFile(
      filePrefix: filePrefix,
      headers: headers,
      rows: rows,
    );

    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      final safePrefix = _sanitize(filePrefix);
      String? outputFile = await FilePicker.platform.saveFile(
        dialogTitle: 'Simpan Laporan CSV',
        fileName: '${safePrefix}_${DateTime.now().millisecondsSinceEpoch}.csv',
        type: FileType.custom,
        allowedExtensions: ['csv'],
      );
      if (outputFile != null) {
        await file.copy(outputFile);
      }
    } else {
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path)],
          subject: subject,
          text: message,
        ),
      );
    }
  }

  static String _sanitize(String value) {
    final cleaned = value
        .trim()
        .replaceAll(RegExp(r'\s+'), '_')
        .replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '');
    return cleaned.isEmpty ? 'export' : cleaned;
  }

  static Future<pw.Document> _buildPdfDoc({
    required String title,
    String? subtitle,
    required List<String> headers,
    required List<List<dynamic>> rows,
    Map<String, double>? pieChartData,
    Map<String, String>? summaryData,
    bool Function(List<String> row)? negativeRowChecker,
  }) async {
    final font = await PdfGoogleFonts.robotoRegular();
    final fontBold = await PdfGoogleFonts.robotoBold();
    final doc = pw.Document(
      theme: pw.ThemeData.withFont(
        base: font,
        bold: fontBold,
      ),
    );
    final warung = await DBHelper.instance.getWarungProfile();
    final storeName = (warung['nama'] ?? '').trim().isEmpty
        ? 'Juragan Servis'
        : (warung['nama'] ?? '').trim();
    final storeAddress = (warung['alamat'] ?? '').trim();
    final storePhone = _normalizePhone(warung['telepon'] ?? '');
    final logoImage = await _loadLogoImage(warung);
    final generatedAt = DateTime.now();

    final stringRows = rows.map((row) {
      final cells = row.map((cell) => cell?.toString() ?? '').toList();
      if (headers.isEmpty) {
        return cells;
      }
      if (cells.length < headers.length) {
        return [
          ...cells,
          ...List<String>.filled(headers.length - cells.length, '')
        ];
      }
      if (cells.length > headers.length) {
        return cells.take(headers.length).toList();
      }
      return cells;
    }).toList();

    final reportSummary = _buildReportSummary(
      headers: headers,
      rows: stringRows,
      providedSummary: summaryData,
    );
    final chartData = _buildReportChartData(
      headers: headers,
      rows: stringRows,
      providedPieChartData: pieChartData,
    );
    final pageFormat =
        headers.length > 7 ? PdfPageFormat.a4.landscape : PdfPageFormat.a4;

    doc.addPage(
      pw.MultiPage(
        pageFormat: pageFormat,
        margin: const pw.EdgeInsets.fromLTRB(30, 28, 30, 28),
        header: (context) {
          if (context.pageNumber == 1) {
            return pw.SizedBox();
          }
          return _buildRunningHeader(title, storeName);
        },
        footer: (context) => _buildFooter(
          context: context,
          storeName: storeName,
          generatedAt: generatedAt,
        ),
        build: (context) => [
          _buildReportHeader(
            title: title,
            subtitle: subtitle,
            storeName: storeName,
            storeAddress: storeAddress,
            storePhone: storePhone,
            generatedAt: generatedAt,
            logoImage: logoImage,
          ),
          pw.SizedBox(height: 18),
          _buildSectionTitle('Ringkasan Laporan'),
          pw.SizedBox(height: 8),
          _buildSummaryCards(reportSummary),
          if (chartData != null) ...[
            pw.SizedBox(height: 18),
            _buildSectionTitle('Grafik Ringkasan'),
            pw.SizedBox(height: 8),
            _buildChartSection(chartData),
          ],
          pw.SizedBox(height: 18),
          _buildSectionTitle('Rincian Data'),
          pw.SizedBox(height: 8),
          _buildTableSection(
            headers: headers,
            rows: stringRows,
            negativeRowChecker: negativeRowChecker,
          ),
        ],
      ),
    );

    return doc;
  }

  static Future<pw.ImageProvider?> _loadLogoImage(
    Map<String, String> profile,
  ) async {
    final logoPath = (profile['logo_path'] ?? '').trim();
    if (logoPath.isEmpty) {
      return null;
    }

    final file = File(logoPath);
    if (!file.existsSync()) {
      return null;
    }

    try {
      return pw.MemoryImage(await file.readAsBytes());
    } catch (_) {
      return null;
    }
  }

  static pw.Widget _buildReportHeader({
    required String title,
    required String? subtitle,
    required String storeName,
    required String storeAddress,
    required String storePhone,
    required DateTime generatedAt,
    required pw.ImageProvider? logoImage,
  }) {
    return pw.Container(
      decoration: const pw.BoxDecoration(
        color: _brand,
        borderRadius: pw.BorderRadius.all(pw.Radius.circular(6)),
      ),
      child: pw.Column(
        children: [
          pw.Container(
            height: 4,
            decoration: const pw.BoxDecoration(
              color: _warning,
              borderRadius: pw.BorderRadius.only(
                topLeft: pw.Radius.circular(6),
                topRight: pw.Radius.circular(6),
              ),
            ),
          ),
          pw.Padding(
            padding: const pw.EdgeInsets.all(18),
            child: pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                _buildLogoMark(storeName, logoImage),
                pw.SizedBox(width: 14),
                pw.Expanded(
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text(
                        title,
                        style: pw.TextStyle(
                          color: PdfColors.white,
                          fontSize: 20,
                          fontWeight: pw.FontWeight.bold,
                        ),
                      ),
                      if (subtitle != null && subtitle.trim().isNotEmpty) ...[
                        pw.SizedBox(height: 5),
                        pw.Text(
                          subtitle.trim(),
                          style: const pw.TextStyle(
                            color: PdfColor.fromInt(0xFFDBEAFE),
                            fontSize: 10,
                          ),
                        ),
                      ],
                      pw.SizedBox(height: 12),
                      pw.Wrap(
                        spacing: 10,
                        runSpacing: 4,
                        children: [
                          _buildHeaderPill(storeName),
                          if (storePhone.isNotEmpty)
                            _buildHeaderPill('Telp: $storePhone'),
                          _buildHeaderPill(
                            'Dibuat: ${_formatDateTime(generatedAt)}',
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                if (storeAddress.isNotEmpty)
                  pw.Container(
                    width: 150,
                    alignment: pw.Alignment.topRight,
                    child: pw.Text(
                      storeAddress,
                      textAlign: pw.TextAlign.right,
                      style: const pw.TextStyle(
                        color: PdfColor.fromInt(0xFFDBEAFE),
                        fontSize: 9,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildLogoMark(
    String storeName,
    pw.ImageProvider? logoImage,
  ) {
    if (logoImage != null) {
      return pw.Container(
        width: 52,
        height: 52,
        padding: const pw.EdgeInsets.all(4),
        decoration: const pw.BoxDecoration(
          color: PdfColors.white,
          borderRadius: pw.BorderRadius.all(pw.Radius.circular(6)),
        ),
        child: pw.Image(logoImage, fit: pw.BoxFit.contain),
      );
    }

    return pw.Container(
      width: 52,
      height: 52,
      alignment: pw.Alignment.center,
      decoration: const pw.BoxDecoration(
        color: PdfColors.white,
        borderRadius: pw.BorderRadius.all(pw.Radius.circular(6)),
      ),
      child: pw.Text(
        _initials(storeName),
        style: pw.TextStyle(
          color: _brandDark,
          fontSize: 16,
          fontWeight: pw.FontWeight.bold,
        ),
      ),
    );
  }

  static pw.Widget _buildHeaderPill(String text) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: pw.BoxDecoration(
        color: const PdfColor.fromInt(0x262563EB),
        border: pw.Border.all(color: const PdfColor.fromInt(0x66DBEAFE)),
        borderRadius: const pw.BorderRadius.all(pw.Radius.circular(3)),
      ),
      child: pw.Text(
        text,
        style: const pw.TextStyle(color: PdfColors.white, fontSize: 8),
      ),
    );
  }

  static pw.Widget _buildRunningHeader(String title, String storeName) {
    return pw.Container(
      margin: const pw.EdgeInsets.only(bottom: 12),
      padding: const pw.EdgeInsets.only(bottom: 8),
      decoration: const pw.BoxDecoration(
        border: pw.Border(bottom: pw.BorderSide(color: _line, width: 0.8)),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            title,
            style: pw.TextStyle(
              fontSize: 9,
              color: _ink,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
          pw.Text(
            storeName,
            style: const pw.TextStyle(fontSize: 8, color: _muted),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildFooter({
    required pw.Context context,
    required String storeName,
    required DateTime generatedAt,
  }) {
    return pw.Container(
      margin: const pw.EdgeInsets.only(top: 12),
      padding: const pw.EdgeInsets.only(top: 8),
      decoration: const pw.BoxDecoration(
        border: pw.Border(top: pw.BorderSide(color: _line, width: 0.8)),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            '$storeName - Laporan dibuat ${_formatDateTime(generatedAt)}',
            style: const pw.TextStyle(fontSize: 7, color: _muted),
          ),
          pw.Text(
            'Halaman ${context.pageNumber} dari ${context.pagesCount}',
            style: const pw.TextStyle(fontSize: 7, color: _muted),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildSectionTitle(String title) {
    return pw.Row(
      children: [
        pw.Container(width: 4, height: 14, color: _warning),
        pw.SizedBox(width: 7),
        pw.Text(
          title,
          style: pw.TextStyle(
            fontSize: 13,
            color: _ink,
            fontWeight: pw.FontWeight.bold,
          ),
        ),
      ],
    );
  }

  static Map<String, String> _buildReportSummary({
    required List<String> headers,
    required List<List<String>> rows,
    Map<String, String>? providedSummary,
  }) {
    final summary = <String, String>{
      if (providedSummary != null) ...providedSummary,
    };

    void putIfAbsent(String key, String value) {
      final exists = summary.keys.any(
        (existingKey) => existingKey.toLowerCase() == key.toLowerCase(),
      );
      if (!exists) {
        summary[key] = value;
      }
    }

    putIfAbsent('Total Data', '${rows.length} baris');

    final candidates = _numericColumnCandidates(headers, rows);
    for (final candidate in candidates.take(2)) {
      final label = _compactLabel(headers[candidate.index], 20);
      putIfAbsent(
        'Total $label',
        _formatReportValue(candidate.total, candidate.isCurrency),
      );
    }

    if (summary.length < 4 && candidates.isNotEmpty) {
      final candidate = candidates.first;
      final average = candidate.total / math.max(candidate.count, 1);
      putIfAbsent(
        'Rata-rata ${_compactLabel(headers[candidate.index], 14)}',
        _formatReportValue(average, candidate.isCurrency),
      );
    }

    if (rows.isEmpty) {
      putIfAbsent('Status', 'Belum ada data');
    }

    return summary;
  }

  static pw.Widget _buildSummaryCards(Map<String, String> data) {
    return pw.Wrap(
      spacing: 9,
      runSpacing: 9,
      children: data.entries.map((entry) {
        return pw.Container(
          width: 142,
          padding: const pw.EdgeInsets.all(10),
          decoration: pw.BoxDecoration(
            color: _paper,
            borderRadius: const pw.BorderRadius.all(pw.Radius.circular(5)),
            border: pw.Border.all(color: _line),
          ),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(
                entry.key.toUpperCase(),
                maxLines: 1,
                style: pw.TextStyle(
                  fontSize: 7,
                  color: _muted,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
              pw.SizedBox(height: 5),
              pw.Text(
                entry.value,
                maxLines: 2,
                style: pw.TextStyle(
                  fontSize: 11,
                  fontWeight: pw.FontWeight.bold,
                  color: _ink,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  static _ReportChartData? _buildReportChartData({
    required List<String> headers,
    required List<List<String>> rows,
    required Map<String, double>? providedPieChartData,
  }) {
    if (providedPieChartData != null && providedPieChartData.isNotEmpty) {
      final entries = _limitChartEntries(
        providedPieChartData.entries
            .where((entry) => entry.value.abs() > 0)
            .map((entry) => _ChartDatum(entry.key, entry.value.abs()))
            .toList(),
      );
      if (entries.isEmpty) {
        return null;
      }
      return _ReportChartData(
        entries: entries,
        valueLabel: 'Nilai',
        isCurrency: true,
      );
    }

    if (headers.isEmpty || rows.isEmpty) {
      return null;
    }

    final numericCandidates = _numericColumnCandidates(headers, rows);
    if (numericCandidates.isEmpty) {
      return null;
    }

    final numeric = numericCandidates.first;
    final labelIndex = _findLabelColumnIndex(
      headers: headers,
      rows: rows,
      numericColumnIndex: numeric.index,
    );
    final grouped = <String, double>{};

    for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) {
      final row = rows[rowIndex];
      final value =
          numeric.index < row.length ? _parseNumeric(row[numeric.index]) : null;
      if (value == null || value.abs() <= 0) {
        continue;
      }

      final label = labelIndex != null && labelIndex < row.length
          ? row[labelIndex].trim()
          : 'Baris ${rowIndex + 1}';
      final safeLabel = label.isEmpty ? 'Tanpa Label' : label;
      grouped[safeLabel] = (grouped[safeLabel] ?? 0) + value.abs();
    }

    final entries = _limitChartEntries(
      grouped.entries
          .map((entry) => _ChartDatum(entry.key, entry.value))
          .toList(),
    );
    if (entries.isEmpty) {
      return null;
    }

    return _ReportChartData(
      entries: entries,
      valueLabel: headers[numeric.index],
      isCurrency: numeric.isCurrency,
    );
  }

  static List<_ChartDatum> _limitChartEntries(List<_ChartDatum> entries) {
    final sorted = [...entries]..sort((a, b) => b.value.compareTo(a.value));
    if (sorted.length <= 6) {
      return sorted;
    }

    final top = sorted.take(5).toList();
    final others = sorted.skip(5).fold<double>(
          0,
          (total, entry) => total + entry.value,
        );
    if (others > 0) {
      top.add(_ChartDatum('Lainnya', others));
    }
    return top;
  }

  static pw.Widget _buildChartSection(_ReportChartData chartData) {
    final total = chartData.entries.fold<double>(
      0,
      (sum, entry) => sum + entry.value,
    );
    final maxValue = chartData.entries.fold<double>(
      0,
      (max, entry) => math.max(max, entry.value),
    );

    return pw.Container(
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        color: PdfColors.white,
        border: pw.Border.all(color: _line),
        borderRadius: const pw.BorderRadius.all(pw.Radius.circular(5)),
      ),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.center,
        children: [
          pw.Container(
            width: 158,
            height: 158,
            padding: const pw.EdgeInsets.all(8),
            decoration: const pw.BoxDecoration(
              color: _paper,
              borderRadius: pw.BorderRadius.all(pw.Radius.circular(5)),
            ),
            child: pw.Chart(
              grid: pw.PieGrid(),
              datasets: chartData.entries.asMap().entries.map((entry) {
                final index = entry.key;
                final datum = entry.value;
                return pw.PieDataSet(
                  value: datum.value,
                  legend: datum.label,
                  color: _chartColor(index),
                );
              }).toList(),
            ),
          ),
          pw.SizedBox(width: 16),
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              mainAxisAlignment: pw.MainAxisAlignment.center,
              children: [
                pw.Text(
                  'Distribusi ${chartData.valueLabel}',
                  style: pw.TextStyle(
                    fontSize: 11,
                    fontWeight: pw.FontWeight.bold,
                    color: _ink,
                  ),
                ),
                pw.SizedBox(height: 3),
                pw.Text(
                  'Total: ${_formatReportValue(total, chartData.isCurrency)}',
                  style: const pw.TextStyle(fontSize: 8, color: _muted),
                ),
                pw.SizedBox(height: 9),
                ...chartData.entries.asMap().entries.map((entry) {
                  final index = entry.key;
                  final datum = entry.value;
                  final ratio = maxValue <= 0 ? 0.0 : datum.value / maxValue;
                  final percent = total <= 0 ? 0.0 : datum.value / total * 100;

                  return pw.Padding(
                    padding: const pw.EdgeInsets.only(bottom: 7),
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Row(
                          children: [
                            pw.Container(
                              width: 8,
                              height: 8,
                              decoration: pw.BoxDecoration(
                                color: _chartColor(index),
                                borderRadius: const pw.BorderRadius.all(
                                  pw.Radius.circular(2),
                                ),
                              ),
                            ),
                            pw.SizedBox(width: 6),
                            pw.Expanded(
                              child: pw.Text(
                                _compactLabel(datum.label, 32),
                                maxLines: 1,
                                style: const pw.TextStyle(
                                  fontSize: 8,
                                  color: _ink,
                                ),
                              ),
                            ),
                            pw.Text(
                              '${percent.toStringAsFixed(1)}%',
                              style: const pw.TextStyle(
                                fontSize: 8,
                                color: _muted,
                              ),
                            ),
                          ],
                        ),
                        pw.SizedBox(height: 3),
                        pw.Row(
                          children: [
                            pw.Container(
                              width: 150,
                              height: 5,
                              decoration: const pw.BoxDecoration(
                                color: _line,
                                borderRadius: pw.BorderRadius.all(
                                  pw.Radius.circular(3),
                                ),
                              ),
                              child: pw.Row(
                                children: [
                                  pw.Container(
                                    width: 150 * ratio.clamp(0.0, 1.0),
                                    height: 5,
                                    decoration: pw.BoxDecoration(
                                      color: _chartColor(index),
                                      borderRadius: const pw.BorderRadius.all(
                                        pw.Radius.circular(3),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            pw.SizedBox(width: 8),
                            pw.Text(
                              _formatReportValue(
                                datum.value,
                                chartData.isCurrency,
                              ),
                              style: pw.TextStyle(
                                fontSize: 8,
                                color: _ink,
                                fontWeight: pw.FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildTableSection({
    required List<String> headers,
    required List<List<String>> rows,
    required bool Function(List<String> row)? negativeRowChecker,
  }) {
    if (headers.isEmpty) {
      return pw.Container(
        padding: const pw.EdgeInsets.all(12),
        decoration: pw.BoxDecoration(
          color: _paper,
          border: pw.Border.all(color: _line),
          borderRadius: const pw.BorderRadius.all(pw.Radius.circular(5)),
        ),
        child: pw.Text(
          rows.isEmpty ? 'Belum ada data untuk ditampilkan.' : rows.join('\n'),
          style: const pw.TextStyle(fontSize: 9, color: _muted),
        ),
      );
    }

    final numericColumns = _numericColumnCandidates(headers, rows)
        .map((candidate) => candidate.index)
        .toSet();
    final fontSize = headers.length >= 9
        ? 6.4
        : headers.length >= 7
            ? 7.1
            : 8.0;
    final padding = headers.length >= 8
        ? const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 4)
        : const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 5);

    return pw.TableHelper.fromTextArray(
      headers: headers,
      data: rows,
      border: pw.TableBorder.all(color: _line, width: 0.5),
      headerDecoration: const pw.BoxDecoration(color: _brandDark),
      headerPadding: padding,
      headerAlignment: pw.Alignment.centerLeft,
      headerAlignments: {
        for (final index in numericColumns) index: pw.Alignment.centerRight,
      },
      headerStyle: pw.TextStyle(
        color: PdfColors.white,
        fontSize: fontSize,
        fontWeight: pw.FontWeight.bold,
      ),
      cellPadding: padding,
      cellAlignment: pw.Alignment.centerLeft,
      cellAlignments: {
        for (final index in numericColumns) index: pw.Alignment.centerRight,
      },
      cellStyle: pw.TextStyle(fontSize: fontSize, color: _ink),
      oddRowDecoration: const pw.BoxDecoration(color: _paper),
      cellDecoration: negativeRowChecker == null
          ? null
          : (columnIndex, cell, rowNum) {
              final rowIndex = rowNum - 1;
              final isNegative = rowIndex >= 0 &&
                  rowIndex < rows.length &&
                  negativeRowChecker(rows[rowIndex]);
              return isNegative
                  ? const pw.BoxDecoration(
                      color: PdfColor.fromInt(0xFFFFF1F2),
                    )
                  : const pw.BoxDecoration();
            },
      textStyleBuilder: negativeRowChecker == null
          ? null
          : (columnIndex, cell, rowNum) {
              final rowIndex = rowNum - 1;
              final isNegative = rowIndex >= 0 &&
                  rowIndex < rows.length &&
                  negativeRowChecker(rows[rowIndex]);
              if (!isNegative) {
                return null;
              }
              return pw.TextStyle(
                fontSize: fontSize,
                color: _danger,
                fontWeight: pw.FontWeight.bold,
              );
            },
    );
  }

  static List<_NumericColumnCandidate> _numericColumnCandidates(
    List<String> headers,
    List<List<String>> rows,
  ) {
    if (headers.isEmpty || rows.isEmpty) {
      return const [];
    }

    final candidates = <_NumericColumnCandidate>[];
    for (var index = 0; index < headers.length; index++) {
      final header = headers[index];
      final normalizedHeader = _normalizeHeader(header);
      if (_looksLikeIdentifierHeader(normalizedHeader)) {
        continue;
      }

      final values = <double>[];
      for (final row in rows) {
        if (index >= row.length) {
          continue;
        }
        final parsed = _parseNumeric(row[index]);
        if (parsed != null) {
          values.add(parsed);
        }
      }

      final minimumCount =
          rows.length <= 2 ? 1 : math.max(2, (rows.length * 0.35).ceil());
      if (values.length < minimumCount) {
        continue;
      }

      final totalAbs = values.fold<double>(
        0,
        (sum, value) => sum + value.abs(),
      );
      if (totalAbs <= 0) {
        continue;
      }

      final isCurrency = _isCurrencyHeader(normalizedHeader) ||
          values.any((_) => normalizedHeader.contains('rp'));
      var score = values.length / math.max(rows.length, 1) * 10;
      score += index * 0.08;
      if (isCurrency) {
        score += 12;
      }
      if (_isPrimaryMetricHeader(normalizedHeader)) {
        score += 8;
      }
      if (_isSecondaryMetricHeader(normalizedHeader)) {
        score += 4;
      }

      candidates.add(
        _NumericColumnCandidate(
          index: index,
          score: score,
          total: values.fold<double>(0, (sum, value) => sum + value),
          count: values.length,
          isCurrency: isCurrency,
        ),
      );
    }

    candidates.sort((a, b) => b.score.compareTo(a.score));
    return candidates;
  }

  static int? _findLabelColumnIndex({
    required List<String> headers,
    required List<List<String>> rows,
    required int numericColumnIndex,
  }) {
    if (headers.length <= 1) {
      return null;
    }

    var bestIndex = -1;
    var bestScore = double.negativeInfinity;

    for (var index = 0; index < headers.length; index++) {
      if (index == numericColumnIndex) {
        continue;
      }

      final normalizedHeader = _normalizeHeader(headers[index]);
      var textCount = 0;
      var numericCount = 0;
      final uniqueValues = <String>{};

      for (final row in rows) {
        if (index >= row.length) {
          continue;
        }
        final value = row[index].trim();
        if (value.isEmpty) {
          continue;
        }
        uniqueValues.add(value.toLowerCase());
        if (_parseNumeric(value) == null) {
          textCount++;
        } else {
          numericCount++;
        }
      }

      if (textCount == 0 && uniqueValues.isEmpty) {
        continue;
      }

      var score = textCount * 2.0 - numericCount;
      score += math.min(uniqueValues.length, 8) * 0.25;
      if (_isPreferredLabelHeader(normalizedHeader)) {
        score += 8;
      }
      if (_looksLikeIdentifierHeader(normalizedHeader)) {
        score -= 10;
      }
      score -= (numericColumnIndex - index).abs() * 0.08;

      if (score > bestScore) {
        bestScore = score;
        bestIndex = index;
      }
    }

    return bestIndex >= 0 ? bestIndex : null;
  }

  static double? _parseNumeric(String value) {
    final text = value.trim();
    if (text.isEmpty || text == '-') {
      return null;
    }
    if (RegExp(r'^\d{1,4}[-/]\d{1,2}[-/]\d{1,4}').hasMatch(text) ||
        RegExp(r'^\d{1,2}:\d{2}').hasMatch(text) ||
        text.contains(':')) {
      return null;
    }

    final hasLetters = RegExp(r'[a-zA-Z]').hasMatch(text);
    final allowedUnit = RegExp(
      r'(rp|idr|kg|pcs|pc|x|hari|bulan|tahun|item|paket|layanan|produk|transaksi|nota|%)',
      caseSensitive: false,
    ).hasMatch(text);
    if (hasLetters && !allowedUnit) {
      return null;
    }

    final isNegative =
        text.startsWith('-') || (text.startsWith('(') && text.endsWith(')'));
    var cleaned = text.replaceAll(RegExp(r'[^0-9,.\-]'), '');
    cleaned = cleaned.replaceAll('-', '');
    if (!RegExp(r'\d').hasMatch(cleaned)) {
      return null;
    }

    final lastComma = cleaned.lastIndexOf(',');
    final lastDot = cleaned.lastIndexOf('.');
    if (lastComma >= 0 && lastDot >= 0) {
      if (lastComma > lastDot) {
        cleaned = cleaned.replaceAll('.', '').replaceAll(',', '.');
      } else {
        cleaned = cleaned.replaceAll(',', '');
      }
    } else if (lastComma >= 0) {
      cleaned = _looksThousandsSeparated(cleaned, ',')
          ? cleaned.replaceAll(',', '')
          : cleaned.replaceAll(',', '.');
    } else if (lastDot >= 0 && _looksThousandsSeparated(cleaned, '.')) {
      cleaned = cleaned.replaceAll('.', '');
    }

    final parsed = double.tryParse(cleaned);
    if (parsed == null || !parsed.isFinite) {
      return null;
    }
    return isNegative ? -parsed : parsed;
  }

  static bool _looksThousandsSeparated(String value, String separator) {
    final parts = value.split(separator);
    if (parts.length <= 1 || parts.first.isEmpty || parts.first.length > 3) {
      return false;
    }
    return parts.skip(1).every((part) => part.length == 3);
  }

  static bool _looksLikeIdentifierHeader(String header) {
    return RegExp(
      r'\b(no|id|kode|nota|invoice|struk|resi|tanggal|tgl|jam|waktu|telepon|telp|hp|kontak)\b',
    ).hasMatch(header);
  }

  static bool _isCurrencyHeader(String header) {
    return RegExp(
      r'\b(rp|rupiah|harga|total|nominal|omzet|saldo|kas|bayar|pembayaran|piutang|utang|modal|laba|rugi|profit|biaya|nilai|margin|diskon|pajak)\b',
    ).hasMatch(header);
  }

  static bool _isPrimaryMetricHeader(String header) {
    return RegExp(
      r'\b(total|omzet|nominal|jumlah|qty|kuantitas|terjual|stok|laba|rugi|profit|kas|masuk|keluar|bayar|nilai)\b',
    ).hasMatch(header);
  }

  static bool _isSecondaryMetricHeader(String header) {
    return RegExp(
      r'\b(berat|kg|pcs|item|paket|transaksi|retur|sisa|hari|bulan|durasi)\b',
    ).hasMatch(header);
  }

  static bool _isPreferredLabelHeader(String header) {
    return RegExp(
      r'\b(nama|produk|layanan|kategori|jenis|metode|bulan|periode|pelanggan|status|keterangan|deskripsi)\b',
    ).hasMatch(header);
  }

  static String _normalizeHeader(String header) {
    return header.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), ' ').trim();
  }

  static PdfColor _chartColor(int index) {
    return _chartColors[index % _chartColors.length];
  }

  static String _formatReportValue(num value, bool isCurrency) {
    if (isCurrency) {
      return _formatCurrency(value);
    }
    return _formatNumber(value);
  }

  static String _formatCurrency(num value) {
    final sign = value < 0 ? '-' : '';
    return '${sign}Rp ${_formatInteger(value.abs().round())}';
  }

  static String _formatNumber(num value) {
    final sign = value < 0 ? '-' : '';
    final absolute = value.abs();
    if ((absolute - absolute.round()).abs() < 0.01) {
      return '$sign${_formatInteger(absolute.round())}';
    }

    final fixed = absolute.toStringAsFixed(1);
    final parts = fixed.split('.');
    return '$sign${_formatInteger(int.parse(parts[0]))},${parts[1]}';
  }

  static String _formatInteger(int value) {
    final raw = value.toString();
    final buffer = StringBuffer();
    for (var index = 0; index < raw.length; index++) {
      final remaining = raw.length - index;
      buffer.write(raw[index]);
      if (remaining > 1 && remaining % 3 == 1) {
        buffer.write('.');
      }
    }
    return buffer.toString();
  }

  static String _compactLabel(String value, int maxLength) {
    final trimmed = value.trim();
    if (trimmed.length <= maxLength) {
      return trimmed;
    }
    return '${trimmed.substring(0, math.max(0, maxLength - 3))}...';
  }

  static String _normalizePhone(String value) {
    final phone = value.trim();
    if (phone.isEmpty || phone.startsWith('0') || phone.startsWith('+')) {
      return phone;
    }
    return '0$phone';
  }

  static String _initials(String value) {
    final parts = value
        .trim()
        .split(RegExp(r'\s+'))
        .where((part) => part.isNotEmpty)
        .toList();
    if (parts.isEmpty) {
      return 'JL';
    }
    return parts.take(2).map((part) => part[0].toUpperCase()).join();
  }

  static String _formatDateTime(DateTime value) {
    return '${_two(value.day)}/${_two(value.month)}/${value.year} '
        '${_two(value.hour)}:${_two(value.minute)}';
  }

  static String _two(int value) => value.toString().padLeft(2, '0');

  static Future<void> exportPdfLaporan({
    required String title,
    String? subtitle,
    required List<String> headers,
    required List<List<dynamic>> rows,
    Map<String, double>? pieChartData,
    Map<String, String>? summaryData,
    bool Function(List<String> row)? negativeRowChecker,
  }) async {
    final doc = await _buildPdfDoc(
      title: title,
      subtitle: subtitle,
      headers: headers,
      rows: rows,
      pieChartData: pieChartData,
      summaryData: summaryData,
      negativeRowChecker: negativeRowChecker,
    );
    final bytes = await doc.save();
    final filename =
        '${_sanitize(title)}_${DateTime.now().millisecondsSinceEpoch}.pdf';

    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      String? outputFile = await FilePicker.platform.saveFile(
        dialogTitle: 'Simpan Laporan PDF',
        fileName: filename,
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );
      if (outputFile != null) {
        final file = File(outputFile);
        await file.writeAsBytes(bytes);
      }
    } else {
      await Printing.sharePdf(bytes: bytes, filename: filename);
    }
  }

  static Future<void> printPdfLaporan({
    required String title,
    String? subtitle,
    required List<String> headers,
    required List<List<dynamic>> rows,
    Map<String, double>? pieChartData,
    Map<String, String>? summaryData,
    bool Function(List<String> row)? negativeRowChecker,
  }) async {
    final doc = await _buildPdfDoc(
      title: title,
      subtitle: subtitle,
      headers: headers,
      rows: rows,
      pieChartData: pieChartData,
      summaryData: summaryData,
      negativeRowChecker: negativeRowChecker,
    );
    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => doc.save(),
      name: title,
    );
  }
}

class _NumericColumnCandidate {
  const _NumericColumnCandidate({
    required this.index,
    required this.score,
    required this.total,
    required this.count,
    required this.isCurrency,
  });

  final int index;
  final double score;
  final double total;
  final int count;
  final bool isCurrency;
}

class _ReportChartData {
  const _ReportChartData({
    required this.entries,
    required this.valueLabel,
    required this.isCurrency,
  });

  final List<_ChartDatum> entries;
  final String valueLabel;
  final bool isCurrency;
}

class _ChartDatum {
  const _ChartDatum(this.label, this.value);

  final String label;
  final double value;
}

