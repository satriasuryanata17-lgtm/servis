import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:image/image.dart' as img;

class AndroidNotificationBranding {
  AndroidNotificationBranding._();

  static const smallIcon = 'ic_launcher_foreground';
  static const color = Color(0xFF1E3A5F);

  static Uint8List? _largeIconBytes;

  static Future<AndroidBitmap<Object>?> largeIcon() async {
    if (kIsWeb || !Platform.isAndroid) return null;

    final cached = _largeIconBytes;
    if (cached != null) return ByteArrayAndroidBitmap(cached);

    try {
      final data = await rootBundle.load('assets/images/logo.png');
      final decoded = img.decodeImage(data.buffer.asUint8List());
      if (decoded == null) {
        return const DrawableResourceAndroidBitmap(smallIcon);
      }

      var logo = img.bakeOrientation(decoded);
      if (logo.numChannels == 4) {
        logo = img.trim(logo, mode: img.TrimMode.transparent);
      }

      const canvasSize = 192;
      const maxLogoSize = 150;
      final scale = math.min(
        maxLogoSize / logo.width,
        maxLogoSize / logo.height,
      );
      final targetWidth = math.max(1, (logo.width * scale).round());
      final targetHeight = math.max(1, (logo.height * scale).round());

      final resized = img.copyResize(
        logo,
        width: targetWidth,
        height: targetHeight,
        interpolation: img.Interpolation.average,
      );
      final canvas = img.Image(width: canvasSize, height: canvasSize);
      img.fill(canvas, color: img.ColorRgb8(30, 58, 95));
      img.compositeImage(
        canvas,
        resized,
        dstX: ((canvasSize - targetWidth) / 2).round(),
        dstY: ((canvasSize - targetHeight) / 2).round(),
      );

      _largeIconBytes = Uint8List.fromList(img.encodePng(canvas));
      return ByteArrayAndroidBitmap(_largeIconBytes!);
    } catch (_) {
      return const DrawableResourceAndroidBitmap(smallIcon);
    }
  }
}

