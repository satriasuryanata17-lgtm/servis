import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dashboard_screen.dart';
import 'transaksi_screen.dart';
import 'produk_screen.dart';
import 'pesanan_screen.dart';
import 'laporan_screen.dart';
import 'pelanggan_menu_screen.dart';
import 'karyawan_screen.dart';
import 'daftar_notifikasi_screen.dart';
import 'setting_screen.dart';
import 'riwayat_screen.dart';
import 'continuous_scanner_screen.dart';
import 'servis_status_screen.dart';
import 'ai_insight_screen.dart';
import 'staff_terminal_screen.dart';
import 'juragan_sync_screen.dart';
import 'responsive_layout.dart';
import 'dart:async';
import '../widgets/admin_pin_dialog.dart';
import '../widgets/kasir_drawer.dart';
import '../core/theme.dart';
import '../database/db_helper.dart';
import '../providers/providers.dart';
import '../services/update_service.dart';
import '../services/servis_badge_service.dart';
import '../utils/staff_access.dart';
import 'dart:io' show Platform;

const Color _kservisChrome = AppColors.primaryDark;
const String _kAccessDeniedMessage =
    'Akses Dibatasi: Admin/Owner dapat mengubah izin di menu Karyawan.';

void _showAccessDeniedSnack(BuildContext context) {
  ScaffoldMessenger.of(context)
    ..clearSnackBars()
    ..showSnackBar(
      const SnackBar(
        content: Text(_kAccessDeniedMessage),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
        duration: Duration(milliseconds: 1500),
      ),
    );
}

//  SHELL SCOPE

class ShellScope extends InheritedWidget {
  final ValueChanged<int> onNavigate;
  final int currentIndex;
  final int homeIndex;
  final VoidCallback? openDrawer;
  final VoidCallback? onLongPressJual;

  const ShellScope({
    super.key,
    required this.onNavigate,
    required this.currentIndex,
    this.homeIndex = 0,
    this.openDrawer,
    this.onLongPressJual,
    required super.child,
  });

  static ShellScope? of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<ShellScope>();

  @override
  bool updateShouldNotify(ShellScope old) => currentIndex != old.currentIndex;
}

//  MAIN SHELL

class MainShell extends ConsumerStatefulWidget {
  final int initialIndex;

  const MainShell({super.key, this.initialIndex = 1});

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {
  static const int _shellScreenCount = 13;

  late int _currentIndex;
  late bool _showMainNavigation; // Toggle for Category vs Main Menu
  late final PageController _shellPageController;
  final GlobalKey<ScaffoldState> _shellScaffoldKey = GlobalKey<ScaffoldState>();
  bool _isCheckingAdminPin = true;
  bool _needsAdminPinSetup = false;
  bool _launcherBadgeRefreshQueued = false;
  final Set<int> _visitedIndexes = <int>{};

  @override
  void initState() {
    super.initState();
    final requestedIndex = ref.read(shellIndexProvider);
    _currentIndex = _isValidShellIndex(requestedIndex)
        ? requestedIndex
        : widget.initialIndex;
    _showMainNavigation = _currentIndex != 1;
    _shellPageController = PageController(initialPage: _currentIndex);
    _visitedIndexes.add(_currentIndex);
    _loadAdminPinGuard();
  }

  @override
  void dispose() {
    _shellPageController.dispose();
    super.dispose();
  }

  Future<void> _loadAdminPinGuard() async {
    try {
      final profilNotifier = ref.read(profilProvider.notifier);
      await profilNotifier.loadProfil();
      if (!mounted) return;
      setState(() {
        _isCheckingAdminPin = false;
        _needsAdminPinSetup = !profilNotifier.hasConfiguredAdminPin;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isCheckingAdminPin = false;
        _needsAdminPinSetup = true;
      });
    }
    // Cek update dijalankan setelah UI utama stabil supaya startup tidak terasa patah.
    Future.delayed(const Duration(seconds: 12), () {
      if (mounted) ref.read(updateProvider.notifier).checkForUpdate();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isCheckingAdminPin) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: CircularProgressIndicator(color: AppColors.primaryBrand),
        ),
      );
    }

    if (_needsAdminPinSetup) {
      return Scaffold(
        backgroundColor: AppColors.background,
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppColors.primaryBrand.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Icon(
                        Icons.lock_person_rounded,
                        color: AppColors.primaryBrand,
                        size: 28,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'PIN Admin Wajib Diatur',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 26,
                        fontWeight: FontWeight.w800,
                        color: const Color(0xFF0F172A),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Sebelum aplikasi dipakai, buat PIN admin 6 digit untuk melindungi login Master Admin dan aksi sensitif seperti perubahan pengaturan.',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        height: 1.55,
                        color: const Color(0xFF475569),
                      ),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _setupAdminPin,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryBrand,
                          foregroundColor: Colors.white,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero,
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 15),
                        ),
                        child: const Text(
                          'Atur PIN Admin',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    }

    final sessionRestored = ref.watch(staffSessionRestoredProvider);
    final activeStaff = ref.watch(activeStaffProvider);

    // Wait for session restoration before showing terminal screen
    // This prevents the StaffTerminalScreen from flashing on app restart
    if (!sessionRestored) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: CircularProgressIndicator(color: AppColors.primaryBrand),
        ),
      );
    }

    // Staff MUST log in before seeing the shell.
    final bool needsStaffLogin = activeStaff == null;

    if (needsStaffLogin) {
      _launcherBadgeRefreshQueued = false;
      WidgetsBinding.instance.addPostFrameCallback(
        (_) => servisBadgeService.clearBadge(),
      );
      return const StaffTerminalScreen();
    }

    _queueLauncherBadgeRefresh();

    final isTablet = KasirLayout.isTablet(context);
    final isMobile = !isTablet && (Platform.isAndroid || Platform.isIOS);
    final homeIndex = [
      0,
      1,
      10,
      4,
      8,
      2,
      5,
      6,
      7,
      9,
      11,
      12,
    ].firstWhere(
      (index) => StaffAccess.canOpenShellIndex(activeStaff, index),
      orElse: () => 1,
    );

    ref.listen<int>(shellIndexProvider, (previous, next) {
      if (!_isValidShellIndex(next) || next == _currentIndex) return;
      _navigateToShellIndex(next, syncProvider: false);
    });

    final effectiveIndex =
        StaffAccess.canOpenShellIndex(activeStaff, _currentIndex)
            ? _currentIndex
            : homeIndex;
    if (effectiveIndex != _currentIndex) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _navigateToShellIndex(effectiveIndex);
        }
      });
    }
    _visitedIndexes.add(effectiveIndex);
    final shellScreens = List<Widget>.generate(_shellScreenCount, (index) {
      if (!_visitedIndexes.contains(index)) return const SizedBox.shrink();
      return _buildShellScreen(index, homeIndex);
    });

    final showCategoryNavigation =
        StaffAccess.can(activeStaff, StaffPermissionKey.order) &&
            !_showMainNavigation;
    final useDashboardStatusBar = isMobile && effectiveIndex == 0;
    final shellBackgroundColor =
        useDashboardStatusBar ? AppColors.primaryBrand : AppColors.background;
    final overlayStyle = SystemUiOverlayStyle(
      statusBarColor: shellBackgroundColor,
      statusBarIconBrightness:
          useDashboardStatusBar ? Brightness.light : Brightness.dark,
      statusBarBrightness:
          useDashboardStatusBar ? Brightness.dark : Brightness.light,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    );

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: overlayStyle,
      child: ShellScope(
        onNavigate: _onNavigate,
        currentIndex: effectiveIndex,
        homeIndex: homeIndex,
        openDrawer: () => _shellScaffoldKey.currentState?.openDrawer(),
        onLongPressJual: _onLongPressJual,
        child: Scaffold(
          key: _shellScaffoldKey,
          backgroundColor: shellBackgroundColor,
          drawer: isMobile ? const KasirDrawer() : null,
          drawerScrimColor: Colors.transparent,
          body: SafeArea(
            bottom: false,
            child: Column(
              children: [
                const UpdateBanner(),
                Expanded(
                  child: Row(
                    children: [
                      if (isTablet)
                        showCategoryNavigation
                            ? _CategoryNavigationRail(
                                onCategorySelected: _onCategorySelected,
                                onToggle: _toggleSidebar,
                              )
                            : _ShellNavigationRail(
                                currentIndex: effectiveIndex,
                                onIndexChanged: _onNavigate,
                                onToggle: _toggleSidebar,
                              ),
                      Expanded(
                        child: PageView(
                          controller: _shellPageController,
                          physics: const NeverScrollableScrollPhysics(),
                          children: shellScreens
                              .map((screen) =>
                                  _KeepAliveShellPage(child: screen))
                              .toList(),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          bottomNavigationBar: isMobile
              ? ShellBottomNav(
                  currentIndex: effectiveIndex,
                  onTap: _onNavigate,
                  onLongPressJual: _onLongPressJual,
                )
              : null,
        ),
      ),
    );
  }

  bool _isValidShellIndex(int index) => index >= 0 && index < _shellScreenCount;

  Widget _buildShellScreen(int index, int homeIndex) {
    switch (index) {
      case 0:
        return const DashboardScreen();
      case 1:
        return const TransaksiScreen();
      case 2:
        return const ProdukScreen();
      case 3:
        return const PesananScreen();
      case 4:
        return const RiwayatScreen();
      case 5:
        return const LaporanScreen();
      case 6:
        return const PelangganMenuScreen();
      case 7:
        return const KaryawanScreen();
      case 8:
        return const DaftarNotifikasiScreen();
      case 9:
        return const SettingScreen();
      case 10:
        return const servisStatusScreen();
      case 11:
        return const JuraganSyncScreen();
      case 12:
        return AIInsightScreen(onBack: () => _onNavigate(homeIndex));
      default:
        return const SizedBox.shrink();
    }
  }

  void _jumpToShellIndex(int index) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_shellPageController.hasClients) return;
      if (_shellPageController.page?.round() == index) return;
      _shellPageController.jumpToPage(index);
    });
  }

  void _syncShellIndexProvider(int index) {
    if (ref.read(shellIndexProvider) == index) return;
    ref.read(shellIndexProvider.notifier).set(index);
  }

  void _toggleSidebar() {
    Navigator.of(context).popUntil((route) => route.isFirst);
    setState(() {
      _showMainNavigation = !_showMainNavigation;
      _currentIndex = 1;
      _visitedIndexes.add(1);
    });
    _jumpToShellIndex(1);
    _syncShellIndexProvider(1);
  }

  void _onNavigate(int index) {
    _navigateToShellIndex(index);
  }

  void _navigateToShellIndex(int index, {bool syncProvider = true}) {
    if (!_isValidShellIndex(index)) return;
    final messenger = ScaffoldMessenger.of(context)..clearSnackBars();
    final activeStaff = ref.read(activeStaffProvider);
    if (!StaffAccess.canOpenShellIndex(activeStaff, index)) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text(_kAccessDeniedMessage),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
          duration: Duration(milliseconds: 1500),
        ),
      );
      return;
    }

    if (Navigator.of(context).canPop()) {
      Navigator.of(context).popUntil((route) => route.isFirst);
    }

    setState(() {
      _currentIndex = index;
      _visitedIndexes.add(index);
      // Jika ke Transaksi (1), tampilkan kategori sidebar (false).
      // Jika menu lain, tampilkan main navigation (true).
      if (index == 1) {
        _showMainNavigation = false;
      } else {
        _showMainNavigation = true;
      }
    });
    _jumpToShellIndex(index);
    if (syncProvider) _syncShellIndexProvider(index);
  }

  void _onCategorySelected(int? categoryId) {
    // Only update the selected category, don't change sidebar view
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).popUntil((route) => route.isFirst);
    }

    setState(() {
      _currentIndex = 1;
      _visitedIndexes.add(1);
      // Keep _showMainNavigation as is, just update category
    });
    _jumpToShellIndex(1);
    _syncShellIndexProvider(1);

    // Update the selected category in the provider
    ref.read(selectedCategoryIdProvider.notifier).set(categoryId);
  }

  void _onLongPressJual() {
    final activeStaff = ref.read(activeStaffProvider);
    if (!StaffAccess.can(activeStaff, StaffPermissionKey.order)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(_kAccessDeniedMessage),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
          duration: Duration(milliseconds: 1500),
        ),
      );
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const ContinuousScannerScreen(),
      ),
    ).then((proceedToCheckout) {
      if (proceedToCheckout == true && mounted) {
        Navigator.pushNamed(context, '/checkout');
      }
    });
  }

  void _queueLauncherBadgeRefresh() {
    if (_launcherBadgeRefreshQueued) return;
    _launcherBadgeRefreshQueued = true;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(const Duration(milliseconds: 700), () {
        if (!mounted) return;
        unawaited(_refreshLauncherBadge());
      });
    });
  }

  Future<void> _refreshLauncherBadge() async {
    try {
      final activeservisCount =
          await DBHelper.instance.countActiveservisTransactions();
      if (!mounted) return;
      await servisBadgeService.updateBadge(activeservisCount);
    } catch (e) {
      debugPrint('Launcher badge refresh failed: $e');
    }
  }

  Future<void> _setupAdminPin() async {
    final newPin = await ChangePinDialog.show(
      context,
      requiresCurrentPin: false,
      verifyCurrentPin: (_) => false,
      hint: 'Buat PIN 6 digit yang tidak mudah ditebak.',
    );
    if (newPin == null || !mounted) return;

    try {
      await ref.read(profilProvider.notifier).updateAdminPin(newPin);
      if (!mounted) return;
      setState(() => _needsAdminPinSetup = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('PIN Admin berhasil diatur'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Gagal mengatur PIN Admin. Silakan coba lagi.'),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }
}

class _KeepAliveShellPage extends StatefulWidget {
  final Widget child;

  const _KeepAliveShellPage({required this.child});

  @override
  State<_KeepAliveShellPage> createState() => _KeepAliveShellPageState();
}

class _KeepAliveShellPageState extends State<_KeepAliveShellPage>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return widget.child;
  }
}

//  MOBILE BOTTOM NAV

class ShellBottomNav extends ConsumerWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final VoidCallback onLongPressJual;

  const ShellBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
    required this.onLongPressJual,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeStaff = ref.watch(activeStaffProvider);
    final canDashboard =
        StaffAccess.can(activeStaff, StaffPermissionKey.dashboard);
    final canStatus =
        StaffAccess.can(activeStaff, StaffPermissionKey.servisStatus);
    final canOrder = StaffAccess.can(activeStaff, StaffPermissionKey.order);
    final canHistory = StaffAccess.can(activeStaff, StaffPermissionKey.history);
    final canSettings =
        StaffAccess.can(activeStaff, StaffPermissionKey.settings);

    final badgeCounts = ref.watch(shellBadgeCountsProvider);
    final activeProcessCount = badgeCounts.activeservisCount;
    final pendingUnpaidCount = badgeCounts.pendingUnpaidCount;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
            top: BorderSide(
                color: Colors.black.withValues(alpha: 0.07), width: 1)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 60,
          child: Row(
            children: [
              ShellBottomNavItem(
                icon: Icons.dashboard_outlined,
                activeIcon: Icons.dashboard_rounded,
                label: 'Dashboard',
                isSelected: currentIndex == 0,
                locked: !canDashboard,
                onTap: () => onTap(0),
              ),
              ShellBottomNavItem(
                icon: Icons.handyman_outlined,
                activeIcon: Icons.handyman_rounded,
                label: 'Status',
                isSelected: currentIndex == 10,
                badgeCount: canStatus ? activeProcessCount : 0,
                hasDot: false,
                locked: !canStatus,
                onTap: () => onTap(10),
              ),
              ShellKasirCenterItem(
                isSelected: currentIndex == 1,
                locked: !canOrder,
                onTap: () => onTap(1),
                onLongPress: onLongPressJual,
              ),
              ShellBottomNavItem(
                icon: Icons.assignment_outlined,
                activeIcon: Icons.assignment_rounded,
                label: 'Riwayat',
                isSelected: currentIndex == 4,
                badgeCount: canHistory ? pendingUnpaidCount : 0,
                locked: !canHistory,
                onTap: () => onTap(4),
              ),
              ShellBottomNavItem(
                icon: Icons.settings_outlined,
                activeIcon: Icons.settings_rounded,
                label: 'Pengaturan',
                isSelected: currentIndex == 9,
                locked: !canSettings,
                onTap: () => onTap(9),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ShellBottomNavItem extends StatelessWidget {
  final IconData icon, activeIcon;
  final String label;
  final bool isSelected;
  final int badgeCount;
  final bool hasDot;
  final bool locked;
  final VoidCallback onTap;

  const ShellBottomNavItem({
    super.key,
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.isSelected,
    required this.onTap,
    this.badgeCount = 0,
    this.hasDot = false,
    this.locked = false,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          splashColor: AppColors.primaryBrand.withValues(alpha: 0.08),
          highlightColor: Colors.transparent,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 180),
                    child: Icon(
                      isSelected ? activeIcon : icon,
                      key: ValueKey(isSelected),
                      color: locked
                          ? const Color(0xFFCBD5E1)
                          : isSelected
                              ? AppColors.primaryBrand
                              : const Color(0xFF94A3B8),
                      size: 22,
                    ),
                  ),
                  if (badgeCount > 0)
                    Positioned(
                      top: -6,
                      right: -12,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: AppColors.danger,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          badgeCount > 99 ? '99+' : '$badgeCount',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    )
                  else if (hasDot)
                    Positioned(
                      top: -2,
                      right: -2,
                      child: Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: AppColors.danger,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                  if (locked)
                    Positioned(
                      right: -9,
                      bottom: -5,
                      child: Container(
                        width: 15,
                        height: 15,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppColors.danger,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 1.5),
                        ),
                        child: const Icon(
                          Icons.lock_rounded,
                          color: Colors.white,
                          size: 8.5,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 3),
              Text(
                label,
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: locked
                      ? const Color(0xFFCBD5E1)
                      : isSelected
                          ? AppColors.primaryBrand
                          : const Color(0xFF94A3B8),
                  letterSpacing: 0.1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ShellKasirCenterItem extends StatelessWidget {
  final bool isSelected;
  final bool locked;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  const ShellKasirCenterItem({
    super.key,
    required this.isSelected,
    this.locked = false,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 72,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          onLongPress: onLongPress,
          borderRadius: BorderRadius.zero,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 48,
                height: 32,
                decoration: BoxDecoration(
                  color: locked
                      ? const Color(0xFFF1F5F9)
                      : isSelected
                          ? AppColors.primaryBrand
                          : AppColors.primaryBrand.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Stack(
                  clipBehavior: Clip.none,
                  alignment: Alignment.center,
                  children: [
                    Icon(
                      isSelected
                          ? Icons.point_of_sale_rounded
                          : Icons.point_of_sale_outlined,
                      color: locked
                          ? const Color(0xFFCBD5E1)
                          : isSelected
                              ? Colors.white
                              : AppColors.primaryBrand,
                      size: 20,
                    ),
                    if (locked)
                      Positioned(
                        right: -4,
                        bottom: -4,
                        child: Container(
                          width: 15,
                          height: 15,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: AppColors.danger,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 1.5),
                          ),
                          child: const Icon(
                            Icons.lock_rounded,
                            color: Colors.white,
                            size: 8.5,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 3),
              Text(
                'Order',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: locked
                      ? const Color(0xFFCBD5E1)
                      : isSelected
                          ? AppColors.primaryBrand
                          : const Color(0xFF94A3B8),
                  letterSpacing: 0.1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

//  SHELL NAVIGATION RAIL

class _ShellNavigationRail extends ConsumerWidget {
  final int currentIndex;
  final ValueChanged<int> onIndexChanged;
  final VoidCallback onToggle;

  const _ShellNavigationRail({
    required this.currentIndex,
    required this.onIndexChanged,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeStaff = ref.watch(activeStaffProvider);
    final canDashboard =
        StaffAccess.can(activeStaff, StaffPermissionKey.dashboard);
    final canOrder = StaffAccess.can(activeStaff, StaffPermissionKey.order);
    final canProducts =
        StaffAccess.can(activeStaff, StaffPermissionKey.products);
    final canStatus =
        StaffAccess.can(activeStaff, StaffPermissionKey.servisStatus);
    final canHistory = StaffAccess.can(activeStaff, StaffPermissionKey.history);
    final canReports = StaffAccess.can(activeStaff, StaffPermissionKey.reports);
    final canCustomers =
        StaffAccess.can(activeStaff, StaffPermissionKey.customers);
    final canEmployees =
        StaffAccess.can(activeStaff, StaffPermissionKey.employees);
    final canSettings =
        StaffAccess.can(activeStaff, StaffPermissionKey.settings);
    final canSync = StaffAccess.can(activeStaff, StaffPermissionKey.sync);
    final canAi = StaffAccess.can(activeStaff, StaffPermissionKey.ai);
    final canNotifications =
        StaffAccess.can(activeStaff, StaffPermissionKey.notifications);

    final unreadCount = ref.watch(unreadNotificationsProvider).length;
    final badgeCounts = ref.watch(shellBadgeCountsProvider);
    final activeProcessCount = badgeCounts.activeservisCount;
    final pendingCount = badgeCounts.pendingUnpaidCount;

    return Container(
      width: 80,
      color: _kservisChrome,
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            const SizedBox(height: 12),
            const Divider(
                height: 1, color: Colors.white12, indent: 16, endIndent: 16),
            const SizedBox(height: 8),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  children: [
                    _ShellRailItem(
                      icon: Icons.dashboard_outlined,
                      activeIcon: Icons.dashboard_rounded,
                      label: 'Dashboard',
                      isSelected: currentIndex == 0,
                      locked: !canDashboard,
                      onTap: () => onIndexChanged(0),
                    ),
                    _ShellRailItem(
                      icon: Icons.dry_cleaning_outlined,
                      activeIcon: Icons.dry_cleaning_rounded,
                      label: 'Layanan',
                      isSelected: currentIndex == 2,
                      locked: !canProducts,
                      onTap: () => onIndexChanged(2),
                    ),
                    _ShellRailItem(
                      icon: Icons.handyman_outlined,
                      activeIcon: Icons.handyman_rounded,
                      label: 'Status',
                      isSelected: currentIndex == 10,
                      badgeCount: canStatus ? activeProcessCount : 0,
                      hasDot: false,
                      locked: !canStatus,
                      onTap: () => onIndexChanged(10),
                    ),
                    _ShellRailItem(
                      icon: Icons.assignment_outlined,
                      activeIcon: Icons.assignment_rounded,
                      label: 'Riwayat',
                      isSelected: currentIndex == 4,
                      badgeCount: canHistory ? pendingCount : 0,
                      locked: !canHistory,
                      onTap: () => onIndexChanged(4),
                    ),
                    _ShellRailItem(
                      icon: Icons.insert_chart_outlined,
                      activeIcon: Icons.insert_chart_rounded,
                      label: 'Laporan',
                      isSelected: currentIndex == 5,
                      locked: !canReports,
                      onTap: () => onIndexChanged(5),
                    ),
                    _ShellRailItem(
                      icon: Icons.auto_awesome_outlined,
                      activeIcon: Icons.auto_awesome_rounded,
                      label: 'AI',
                      isSelected: currentIndex == 12,
                      locked: !canAi,
                      onTap: () => onIndexChanged(12),
                    ),
                    _ShellRailItem(
                      icon: Icons.people_outline_rounded,
                      activeIcon: Icons.people_rounded,
                      label: 'Pelanggan',
                      isSelected: currentIndex == 6,
                      locked: !canCustomers,
                      onTap: () => onIndexChanged(6),
                    ),
                    _ShellRailItem(
                      icon: Icons.badge_outlined,
                      activeIcon: Icons.badge_rounded,
                      label: 'Karyawan',
                      isSelected: currentIndex == 7,
                      locked: !canEmployees,
                      onTap: () => onIndexChanged(7),
                    ),
                    _ShellRailItem(
                      icon: Icons.sync_rounded,
                      activeIcon: Icons.sync_rounded,
                      label: 'Sinkron',
                      isSelected: currentIndex == 11,
                      locked: !canSync,
                      onTap: () => onIndexChanged(11),
                    ),
                    _ShellRailItem(
                      icon: Icons.settings_outlined,
                      activeIcon: Icons.settings_rounded,
                      label: 'Pengaturan',
                      isSelected: currentIndex == 9,
                      locked: !canSettings,
                      onTap: () => onIndexChanged(9),
                    ),
                    _ShellRailItem(
                      icon: Icons.notifications_outlined,
                      activeIcon: Icons.notifications_rounded,
                      label: 'Notifikasi',
                      isSelected: currentIndex == 8,
                      badgeCount: canNotifications ? unreadCount : 0,
                      locked: !canNotifications,
                      onTap: () => onIndexChanged(8),
                    ),
                  ],
                ),
              ),
            ),
            _ShellRailItem(
              icon: Icons.point_of_sale_outlined,
              activeIcon: Icons.point_of_sale_rounded,
              label: 'Order',
              isSelected: currentIndex == 1,
              locked: !canOrder,
              onTap:
                  canOrder ? onToggle : () => _showAccessDeniedSnack(context),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}

//  CATEGORY NAVIGATION RAIL

class _CategoryNavigationRail extends ConsumerWidget {
  final ValueChanged<int?> onCategorySelected;
  final VoidCallback onToggle;

  const _CategoryNavigationRail({
    required this.onCategorySelected,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final allCategories = ref.watch(categoriesProvider);
    final defaultCategoryIds = allCategories
        .where((c) => DBHelper.isDefaultCategoryName(c.name))
        .map((c) => c.id)
        .whereType<int>()
        .toSet();
    final categories = allCategories
        .where((c) => !DBHelper.isDefaultCategoryName(c.name))
        .toList();
    final selectedCatId = ref.watch(selectedCategoryIdProvider);
    final isAllSelected =
        selectedCatId == null || defaultCategoryIds.contains(selectedCatId);

    return Container(
      width: 110,
      color: _kservisChrome,
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            const SizedBox(height: 16),
            GestureDetector(
              onTap: () {
                onCategorySelected(null);
                onToggle();
              },
              child: MouseRegion(
                cursor: SystemMouseCursors.click,
                child: Image.asset(
                  'assets/images/logo.png',
                  width: 44,
                  height: 44,
                  errorBuilder: (ctx, _, __) => const Icon(
                    Icons.store_rounded,
                    color: Colors.white24,
                    size: 32,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Divider(
                height: 1, color: Colors.white12, indent: 12, endIndent: 12),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                physics: const BouncingScrollPhysics(),
                itemCount: categories.length + 1,
                itemBuilder: (context, index) {
                  final isAll = index == 0;
                  final category = isAll ? null : categories[index - 1];
                  final isSelected =
                      isAll ? isAllSelected : selectedCatId == category?.id;

                  return _CategoryRailItem(
                    label: isAll ? 'Semua' : (category?.name ?? '-'),
                    isSelected: isSelected,
                    onTap: () {
                      final catId = isAll ? null : category?.id;
                      onCategorySelected(catId);
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 8),
            const Divider(
                height: 1, color: Colors.white12, indent: 16, endIndent: 16),
            const SizedBox(height: 4),
            _CategoryRailItem(
              label: 'ORDER',
              icon: Icons.point_of_sale_rounded,
              isSelected: true,
              onTap: onToggle,
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}

class _CategoryRailItem extends StatefulWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final IconData? icon;

  const _CategoryRailItem({
    required this.label,
    required this.isSelected,
    required this.onTap,
    this.icon,
  });

  @override
  State<_CategoryRailItem> createState() => _CategoryRailItemState();
}

class _CategoryRailItemState extends State<_CategoryRailItem> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: double.infinity,
          margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
          decoration: BoxDecoration(
            color: widget.isSelected
                ? Colors.white.withValues(alpha: 0.15)
                : (_isHovered
                    ? Colors.white.withValues(alpha: 0.08)
                    : Colors.transparent),
            borderRadius: BorderRadius.zero,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (widget.icon != null)
                Icon(widget.icon, color: Colors.white, size: 22)
              else
                Text(
                  widget.label,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.plusJakartaSans(
                    color: (widget.isSelected || _isHovered)
                        ? Colors.white
                        : Colors.white60,
                    fontSize: 12,
                    height: 1.2,
                    fontWeight:
                        widget.isSelected ? FontWeight.w800 : FontWeight.w600,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ShellRailItem extends StatefulWidget {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final int badgeCount;
  final bool hasDot;
  final bool locked;

  const _ShellRailItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.isSelected,
    required this.onTap,
    this.badgeCount = 0,
    this.hasDot = false,
    this.locked = false,
  });

  @override
  State<_ShellRailItem> createState() => _ShellRailItemState();
}

class _ShellRailItemState extends State<_ShellRailItem> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: double.infinity,
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: widget.isSelected
                ? Colors.white
                : (_isHovered
                    ? Colors.white.withValues(alpha: 0.08)
                    : Colors.transparent),
            borderRadius: BorderRadius.zero,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Icon(
                    widget.isSelected ? widget.activeIcon : widget.icon,
                    color: widget.locked
                        ? Colors.white30
                        : widget.isSelected
                            ? AppColors.primaryBrand
                            : (_isHovered ? Colors.white : Colors.white54),
                    size: 22,
                  ),
                  if (widget.badgeCount > 0)
                    Positioned(
                      top: -8,
                      right: -8,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: AppColors.danger,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          widget.badgeCount > 99
                              ? '99+'
                              : '${widget.badgeCount}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    )
                  else if (widget.hasDot)
                    Positioned(
                      top: -4,
                      right: -4,
                      child: Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: AppColors.danger,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                  if (widget.locked)
                    Positioned(
                      right: -9,
                      bottom: -6,
                      child: Container(
                        width: 15,
                        height: 15,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppColors.danger,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: widget.isSelected
                                ? AppColors.primaryBrand
                                : _kservisChrome,
                            width: 1.5,
                          ),
                        ),
                        child: const Icon(
                          Icons.lock_rounded,
                          color: Colors.white,
                          size: 8.5,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                widget.label,
                style: GoogleFonts.inter(
                  color: widget.locked
                      ? Colors.white30
                      : widget.isSelected
                          ? AppColors.primaryBrand
                          : (_isHovered ? Colors.white : Colors.white54),
                  fontSize: 10,
                  fontWeight:
                      widget.isSelected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

//  UPDATE BANNER
//  Muncul otomatis di atas konten jika ada update aplikasi.

class UpdateBanner extends ConsumerWidget {
  const UpdateBanner({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final update = ref.watch(updateProvider);

    // Tidak tampilkan apa-apa jika tidak relevan
    if (update.status == UpdateStatus.idle ||
        update.status == UpdateStatus.notAvailable) {
      return const SizedBox.shrink();
    }

    return AnimatedSize(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
      child: _BannerContent(update: update, ref: ref),
    );
  }
}

class _BannerContent extends StatelessWidget {
  final UpdateState update;
  final WidgetRef ref;

  const _BannerContent({required this.update, required this.ref});

  @override
  Widget build(BuildContext context) {
    final isReady = update.readyToInstall;
    final isDownloading = update.isDownloading;
    final isRequired = update.isRequired;
    final needsBackup = update.needsBackup;
    final isWindows = Platform.isWindows;

    return Container(
      width: double.infinity,
      color: needsBackup
          ? const Color(0xFF92400E)
          : isRequired
              ? AppColors.danger
              : isReady
                  ? const Color(0xFF1B5E20)
                  : AppColors.primaryBrand,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: SafeArea(
        bottom: false,
        child: Row(
          children: [
            // Ikon
            Icon(
              needsBackup
                  ? Icons.backup_rounded
                  : isRequired
                      ? Icons.priority_high_rounded
                      : isReady
                          ? Icons.system_update_rounded
                          : isDownloading
                              ? Icons.downloading_rounded
                              : Icons.new_releases_outlined,
              color: Colors.white,
              size: 18,
            ),
            const SizedBox(width: 10),

            // Teks + progress
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    needsBackup
                        ? 'Backup wajib sebelum update'
                        : isRequired
                            ? 'Update wajib diperlukan'
                            : isReady
                                ? isWindows
                                    ? 'Update siap dipasang'
                                    : 'Update siap diterapkan'
                                : isDownloading
                                    ? 'Mengunduh pembaruan...'
                                    : 'Pembaruan tersedia',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  if (isDownloading) ...[
                    const SizedBox(height: 4),
                    const ClipRRect(
                      borderRadius: BorderRadius.zero,
                      child: LinearProgressIndicator(
                        value: null,
                        backgroundColor: Colors.white24,
                        color: Colors.white,
                        minHeight: 3,
                      ),
                    ),
                  ] else ...[
                    const SizedBox(height: 2),
                    Text(
                      isReady
                          ? isWindows
                              ? 'Installer sudah siap. Aplikasi akan ditutup saat update dimulai.'
                              : 'Restart aplikasi untuk menerapkan pembaruan.'
                          : needsBackup
                              ? 'Cadangkan data dulu. Update dikunci sampai backup terbaru dibuat.'
                              : isRequired
                                  ? 'Versi ini perlu diperbarui untuk melanjutkan.'
                                  : isWindows
                                      ? 'Versi baru tersedia dari server resmi.'
                                      : 'Versi baru tersedia di Play Store.',
                      style:
                          const TextStyle(color: Colors.white70, fontSize: 11),
                    ),
                  ],
                ],
              ),
            ),

            const SizedBox(width: 8),

            // Action button
            if (isReady)
              _BannerBtn(
                label: isWindows ? 'Pasang' : 'Restart',
                onTap: () => ref.read(updateProvider.notifier).completeUpdate(),
              )
            else if (needsBackup)
              _BannerBtn(
                label: 'Backup',
                onTap: () async {
                  await Navigator.of(context).pushNamed('/backup_restore');
                  if (context.mounted) {
                    await ref
                        .read(updateProvider.notifier)
                        .checkForUpdate(force: true);
                  }
                },
              )
            else if (isRequired)
              _BannerBtn(
                label: 'Update',
                onTap: () =>
                    ref.read(updateProvider.notifier).performImmediateUpdate(),
              )
            else if (!isDownloading)
              _BannerBtn(
                label: 'Update',
                onTap: () =>
                    ref.read(updateProvider.notifier).startFlexibleUpdate(),
              ),

            // Dismiss
            if (!isDownloading && !isRequired && !needsBackup) ...[
              const SizedBox(width: 4),
              GestureDetector(
                onTap: () => ref.read(updateProvider.notifier).dismiss(),
                child: const Padding(
                  padding: EdgeInsets.all(4),
                  child: Icon(Icons.close_rounded,
                      color: Colors.white60, size: 16),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _BannerBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _BannerBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
        ),
        child: Text(
          label,
          style: const TextStyle(
            color: AppColors.primaryBrand,
            fontSize: 12,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }
}

