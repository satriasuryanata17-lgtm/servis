import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import 'responsive_layout.dart';
import '../core/theme.dart';
import '../widgets/export_dropdown.dart';
import '../services/export_service.dart';
import '../widgets/admin_pin_dialog.dart';
import 'tambah_transaksi_dompet_screen.dart';

const Color _kBrand = AppColors.primaryBrand;

final walletBalanceByIdProvider =
    FutureProvider.family<int, String>((ref, walletId) {
  ref.watch(walletBalanceProvider);
  return DBHelper.instance.getWalletBalance(walletId: walletId);
});

String _walletDisplayLabel(String walletId) {
  final id = walletId.trim().toLowerCase().replaceAll('-', '_');
  if (id == 'non_tunai' ||
      id == 'nontunai' ||
      id == 'non tunai' ||
      id == 'qris' ||
      id == 'qr' ||
      id == 'transfer' ||
      id == 'bank' ||
      id == 'debit' ||
      id == 'kartu' ||
      id == 'card' ||
      id == 'credit') {
    return 'Non Tunai';
  }
  return 'Tunai';
}

int _parseWalletCurrencyInput(String value) {
  return int.tryParse(value.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
}

String _formatWalletCurrencyInput(int value) {
  final digits = value.abs().toString();
  final buffer = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buffer.write('.');
    buffer.write(digits[i]);
  }
  return buffer.toString();
}

class _WalletCurrencyInputFormatter extends TextInputFormatter {
  const _WalletCurrencyInputFormatter();

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final nominal = _parseWalletCurrencyInput(newValue.text);
    if (nominal == 0) {
      return const TextEditingValue(
        text: '',
        selection: TextSelection.collapsed(offset: 0),
      );
    }
    final text = _formatWalletCurrencyInput(nominal);
    return TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
  }
}

String _fmtWalletRp(int value) {
  final digits = value.abs().toString();
  final buffer = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buffer.write('.');
    buffer.write(digits[i]);
  }
  return 'Rp${value < 0 ? '-' : ''}$buffer';
}

String _formatWalletDate(String value) {
  final parsed = DateTime.tryParse(value);
  if (parsed == null) return value;
  return '${parsed.day.toString().padLeft(2, '0')}/'
      '${parsed.month.toString().padLeft(2, '0')}/'
      '${parsed.year}';
}

String _walletNoteLabel(WalletTransaction tx) {
  final note = tx.keterangan
      .replaceAll(RegExp(r'\(ID Trx:.*?\)', caseSensitive: false), '')
      .trim();
  final category = (tx.kategori ?? '').trim();
  if (note.isEmpty) return '-';
  if (tx.type == 'keluar' &&
      category.isNotEmpty &&
      note.toLowerCase() == category.toLowerCase()) {
    return '-';
  }
  return note;
}

String _walletCategoryLabel(WalletTransaction tx) {
  final category = (tx.kategori ?? '').trim();
  return category.isEmpty ? '-' : category;
}

String _walletTypeLabel(WalletTransaction tx) {
  return tx.type == 'masuk' ? 'Pemasukan' : 'Pengeluaran';
}

String _walletSourceLabel(WalletTransaction tx) {
  switch (tx.source.trim().toLowerCase()) {
    case 'system':
      return 'Sistem';
    case 'adjustment':
      return 'Koreksi Saldo';
    default:
      return 'Manual';
  }
}

String _walletSignedMoney(WalletTransaction tx) {
  final value = _fmtWalletRp(tx.nominal.abs());
  return tx.type == 'keluar' ? '- $value' : '+ $value';
}

String _cleanWalletTitle(String value) {
  return value
      .replaceAll(RegExp(r'\(ID Trx:.*?\)', caseSensitive: false), '')
      .replaceAll('Penjualan', 'Servis')
      .replaceAll('Pemesanan', 'Belum Lunas')
      .replaceAll('Piutang', 'Belum Lunas')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}

String _walletDisplayTitle(WalletTransaction tx) {
  final note = _walletNoteLabel(tx);
  if (note != '-') {
    final clean = _cleanWalletTitle(note);
    return clean.isEmpty ? note : clean;
  }
  final category = _walletCategoryLabel(tx);
  if (category != '-' && category != 'Manual') return category;
  return tx.type == 'masuk' ? 'Pemasukan Manual' : 'Pengeluaran Manual';
}

String _walletTileSubtitle(WalletTransaction tx) {
  final parts = <String>[
    _formatWalletDate(tx.tanggal),
    _walletDisplayLabel(tx.walletId),
  ];
  final category = _walletCategoryLabel(tx);
  final title = _walletDisplayTitle(tx);
  if (category != '-' && category != title && category != 'Manual') {
    parts.add(category);
  }
  return parts.join(' - ');
}

class ArusKasScreen extends ConsumerStatefulWidget {
  const ArusKasScreen({super.key});

  @override
  ConsumerState<ArusKasScreen> createState() => _ArusKasScreenState();
}

class _ArusKasScreenState extends ConsumerState<ArusKasScreen> {
  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ));
  }

  Future<void> _openAdd(String type) async {
    final changed = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => TambahTransaksiDompetScreen(initialType: type),
      ),
    );
    if (changed == true) {
      ref.invalidate(drawerCashProvider);
    }
  }

  Future<void> _exportData() async {
    final choice = await ExportDropdown.show(context);
    if (choice == null) return;

    final txs = ref.read(walletTransactionsProvider).asData?.value ?? [];
    final bal = ref.read(walletBalanceProvider).asData?.value ?? 0;
    final tunai =
        ref.read(walletBalanceByIdProvider('tunai')).asData?.value ?? 0;
    final nontunai =
        ref.read(walletBalanceByIdProvider('non_tunai')).asData?.value ?? 0;

    if (!mounted) return;

    final totalMasuk = txs
        .where((tx) => tx.type == 'masuk')
        .fold<int>(0, (sum, tx) => sum + tx.nominal.abs());
    final totalKeluar = txs
        .where((tx) => tx.type == 'keluar')
        .fold<int>(0, (sum, tx) => sum + tx.nominal.abs());
    final headers = [
      'Tanggal',
      'Waktu',
      'Jenis',
      'Sumber Dana',
      'Kategori',
      'Keterangan',
      'Nominal'
    ];
    final rows = txs
        .map((tx) => [
              _formatWalletDate(tx.tanggal),
              tx.waktu.isEmpty ? '-' : tx.waktu,
              _walletTypeLabel(tx),
              _walletDisplayLabel(tx.walletId),
              _walletCategoryLabel(tx),
              _walletNoteLabel(tx),
              _walletSignedMoney(tx),
            ])
        .toList();

    final Map<String, String> summaryData = {
      'Total Saldo Buku Kas': _fmtWalletRp(bal),
      'Saldo Kas Tunai': _fmtWalletRp(tunai),
      'Saldo Kas Non-Tunai': _fmtWalletRp(nontunai),
      'Total Pemasukan': _fmtWalletRp(totalMasuk),
      'Total Pengeluaran': _fmtWalletRp(totalKeluar),
      'Total Transaksi': '${txs.length}',
    };

    const title = 'Buku Kas Usaha';
    const subtitle =
        'Ringkasan uang masuk dan keluar berdasarkan catatan aktif Buku Kas.';

    try {
      if (choice == 'csv') {
        await ExportService.exportAndShareCsv(
          filePrefix: 'arus_kas',
          headers: [
            'ID',
            'Tanggal',
            'Waktu',
            'Jenis',
            'Sumber Dana',
            'Kategori',
            'Keterangan',
            'Nominal',
            'Asal Data'
          ],
          rows: txs
              .map((tx) => [
                    tx.id,
                    _formatWalletDate(tx.tanggal),
                    tx.waktu.isEmpty ? '-' : tx.waktu,
                    _walletTypeLabel(tx),
                    _walletDisplayLabel(tx.walletId),
                    _walletCategoryLabel(tx),
                    _walletNoteLabel(tx),
                    tx.type == 'keluar' ? -tx.nominal.abs() : tx.nominal.abs(),
                    _walletSourceLabel(tx)
                  ])
              .toList(),
          subject: title,
        );
      } else if (choice == 'pdf') {
        await ExportService.exportPdfLaporan(
          title: title,
          subtitle: subtitle,
          headers: headers,
          rows: rows,
          summaryData: summaryData,
          negativeRowChecker: (row) =>
              row.length > 2 && row[2] == 'Pengeluaran',
        );
      } else if (choice == 'print') {
        await ExportService.printPdfLaporan(
          title: title,
          subtitle: subtitle,
          headers: headers,
          rows: rows,
          summaryData: summaryData,
          negativeRowChecker: (row) =>
              row.length > 2 && row[2] == 'Pengeluaran',
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content:
                Text('Gagal mengekspor laporan arus kas. Silakan coba lagi.')),
      );
    }
  }

  Future<void> _koreksiSaldo() async {
    final pinOk = await AdminPinDialog.show(
      context,
      verifyPin: (pin) {
        final profilNotifier = ref.read(profilProvider.notifier);
        if (!profilNotifier.hasConfiguredAdminPin) {
          return 'PIN admin belum diatur. Buka Pengaturan Profil.';
        }
        final ok = profilNotifier.verifyPin(pin);
        return ok ? '' : 'PIN salah';
      },
      title: 'Koreksi Saldo Buku Kas',
      subtitle: 'Masukkan PIN Admin untuk menyesuaikan saldo Buku Kas Usaha',
    );
    if (!pinOk || !mounted) return;

    final tunai =
        ref.read(walletBalanceByIdProvider('tunai')).asData?.value ?? 0;
    final nonTunai =
        ref.read(walletBalanceByIdProvider('non_tunai')).asData?.value ?? 0;

    final tunaiCtrl =
        TextEditingController(text: _formatWalletCurrencyInput(tunai));
    final nonTunaiCtrl =
        TextEditingController(text: _formatWalletCurrencyInput(nonTunai));

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: const BoxDecoration(
                      color: Color(0xFFFFF7ED),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: const Icon(Icons.tune_rounded,
                        color: AppColors.primaryBrand, size: 22),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Koreksi Saldo Buku Kas',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w700)),
                        Text(
                            'Untuk pembukuan Buku Kas Usaha, bukan Kas Shift fisik di laci.',
                            style:
                                TextStyle(fontSize: 12, color: Colors.black45)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _AdjustField(
                  label: 'Saldo Kas Tunai Sebenarnya',
                  ctrl: tunaiCtrl,
                  current: tunai),
              const SizedBox(height: 14),
              _AdjustField(
                  label: 'Saldo Kas Non-Tunai Sebenarnya',
                  ctrl: nonTunaiCtrl,
                  current: nonTunai),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.black54,
                        side: const BorderSide(color: Color(0xFFD0D5DD)),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                      ),
                      child: const Text('Batal'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                      ),
                      child: const Text('Sesuaikan',
                          style: TextStyle(fontWeight: FontWeight.w600)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (confirmed != true || !mounted) return;

    final newTunai = _parseWalletCurrencyInput(tunaiCtrl.text);
    final newNonTunai = _parseWalletCurrencyInput(nonTunaiCtrl.text);

    try {
      if (newTunai != tunai) {
        await ref.read(profilProvider.notifier).adjustWalletBalance(
              walletId: 'tunai',
              targetBalance: newTunai,
            );
      }
      if (newNonTunai != nonTunai) {
        await ref.read(profilProvider.notifier).adjustWalletBalance(
              walletId: 'non_tunai',
              targetBalance: newNonTunai,
            );
      }
      ref.invalidate(walletBalanceProvider);
      ref.invalidate(walletTransactionsProvider);
      ref.invalidate(walletBalanceByIdProvider('tunai'));
      ref.invalidate(walletBalanceByIdProvider('non_tunai'));
      ref.invalidate(drawerCashProvider);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Saldo berhasil disesuaikan'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Gagal menyesuaikan saldo. Silakan coba lagi.'),
          backgroundColor: AppColors.danger,
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final activeStaff = ref.watch(activeStaffProvider);
    final isStaffAdmin =
        activeStaff?.role.toLowerCase().contains('admin') == true ||
            activeStaff?.role.toLowerCase().contains('owner') == true;

    return KasirResponsiveScaffold(
      title: 'Buku Kas Usaha',
      showNavRail: false,
      actions: [
        if (isStaffAdmin)
          IconButton(
            icon: const Icon(Icons.tune_rounded, color: _kBrand),
            tooltip: 'Koreksi Saldo Buku Kas',
            onPressed: _koreksiSaldo,
          ),
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: GestureDetector(
            onTap: _exportData,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: const BoxDecoration(
                color: AppColors.primaryBrand,
                borderRadius: BorderRadius.zero,
              ),
              child: const Row(
                children: [
                  Icon(Icons.download_rounded, color: Colors.white, size: 15),
                  SizedBox(width: 5),
                  Text(
                    'Ekspor',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
      body: _WalletContent(
        onPemasukanTap: () => _openAdd('masuk'),
        onPengeluaranTap: () => _openAdd('keluar'),
      ),
    );
  }
}

class _WalletContent extends ConsumerWidget {
  final VoidCallback onPemasukanTap;
  final VoidCallback onPengeluaranTap;

  const _WalletContent({
    required this.onPemasukanTap,
    required this.onPengeluaranTap,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tunaiBalance =
        ref.watch(walletBalanceByIdProvider('tunai')).asData?.value ?? 0;
    final nonTunaiBalance =
        ref.watch(walletBalanceByIdProvider('non_tunai')).asData?.value ?? 0;
    final totalBalance = ref.watch(walletBalanceProvider).asData?.value ?? 0;
    final txAsync = ref.watch(walletTransactionsProvider);

    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 720) {
          return _buildMobileLayout(
              totalBalance, tunaiBalance, nonTunaiBalance, txAsync);
        }
        return ResponsiveReportLayout(
          filterPanel:
              _buildSidePanel(totalBalance, tunaiBalance, nonTunaiBalance),
          content: Column(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                color: Colors.white,
                child: Row(
                  children: [
                    Text(
                      'Riwayat Transaksi',
                      style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF1E293B)),
                    ),
                    const Spacer(),
                    const Icon(Icons.history_rounded,
                        size: 18, color: Colors.black26),
                  ],
                ),
              ),
              const Divider(height: 1, color: Color(0xFFEEEEEE)),
              Expanded(
                child: txAsync.when(
                  skipLoadingOnRefresh: true,
                  skipLoadingOnReload: true,
                  loading: () => const Center(
                      child: CircularProgressIndicator(color: _kBrand)),
                  error: (e, s) => const Center(
                      child: Text('Gagal memuat data. Silakan coba lagi.')),
                  data: (txs) {
                    if (txs.isEmpty) {
                      return const _EmptyTransactions();
                    }
                    return ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                      itemCount: txs.length,
                      itemBuilder: (context, i) {
                        final tx = txs[i];
                        return _ModernTransactionTile(tx: tx);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildMobileLayout(int total, int tunai, int nonTunai,
      AsyncValue<List<WalletTransaction>> txAsync) {
    return Column(
      children: [
        _buildMobileHeader(total, tunai, nonTunai),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          color: Colors.white,
          child: Row(
            children: [
              Text(
                'Riwayat Transaksi',
                style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF1E293B)),
              ),
              const Spacer(),
              const Icon(Icons.history_rounded,
                  size: 18, color: Colors.black26),
            ],
          ),
        ),
        const Divider(height: 1, color: Color(0xFFEEEEEE)),
        Expanded(
          child: txAsync.when(
            skipLoadingOnRefresh: true,
            skipLoadingOnReload: true,
            loading: () =>
                const Center(child: CircularProgressIndicator(color: _kBrand)),
            error: (e, s) => const Center(
                child: Text('Gagal memuat data. Silakan coba lagi.')),
            data: (txs) {
              if (txs.isEmpty) {
                return const _EmptyTransactions();
              }
              return ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                itemCount: txs.length,
                itemBuilder: (context, i) {
                  final tx = txs[i];
                  return _ModernTransactionTile(tx: tx);
                },
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildMobileHeader(int total, int tunai, int nonTunai) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Total Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_kBrand, Color(0xFF1E40AF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.zero,
              boxShadow: [
                BoxShadow(
                  color: _kBrand.withValues(alpha: 0.2),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                )
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.account_balance_wallet_rounded,
                        color: Colors.white70, size: 18),
                    SizedBox(width: 8),
                    Text('Total Saldo Buku Kas',
                        style: TextStyle(
                            color: Colors.white70,
                            fontWeight: FontWeight.w500,
                            fontSize: 13)),
                  ],
                ),
                const SizedBox(height: 12),
                Text(_fmtRp(total),
                    style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Tunai / Non-Tunai row
          Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.payments_rounded,
                          color: Colors.teal, size: 20),
                      const SizedBox(height: 12),
                      const Text('Kas Tunai',
                          style:
                              TextStyle(color: Colors.black54, fontSize: 12)),
                      const SizedBox(height: 4),
                      Text(_fmtRp(tunai),
                          style: GoogleFonts.poppins(
                              color: Colors.black87,
                              fontSize: 15,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.credit_card_rounded,
                          color: Colors.blue, size: 20),
                      const SizedBox(height: 12),
                      const Text('Kas Non-Tunai',
                          style:
                              TextStyle(color: Colors.black54, fontSize: 12)),
                      const SizedBox(height: 4),
                      Text(_fmtRp(nonTunai),
                          style: GoogleFonts.poppins(
                              color: Colors.black87,
                              fontSize: 15,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Actions
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onPemasukanTap,
                  icon: const Icon(Icons.arrow_downward_rounded, size: 18),
                  label: const Text('Pemasukan',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF10B981),
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onPengeluaranTap,
                  icon: const Icon(Icons.arrow_upward_rounded, size: 18),
                  label: const Text('Pengeluaran',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFEF4444),
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const _WalletExplanationNote(
            message:
                'Catatan semua uang masuk dan keluar servis, berbeda dengan Kas Shift yang hanya uang tunai di laci saat sesi aktif.',
          ),
        ],
      ),
    );
  }

  Widget _buildSidePanel(int total, int tunai, int nonTunai) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          KasirStatCard(
            label: 'Total Saldo Buku Kas',
            value: _fmtRp(total),
            icon: Icons.account_balance_wallet_rounded,
          ),
          const SizedBox(height: 12),
          KasirStatCard(
            label: 'Kas Tunai',
            value: _fmtRp(tunai),
            icon: Icons.payments_rounded,
            color: Colors.teal,
          ),
          const SizedBox(height: 12),
          KasirStatCard(
            label: 'Kas Non-Tunai',
            value: _fmtRp(nonTunai),
            icon: Icons.credit_card_rounded,
            color: Colors.blue,
          ),
          const SizedBox(height: 32),
          ElevatedButton.icon(
            onPressed: onPemasukanTap,
            icon: const Icon(Icons.arrow_downward_rounded, size: 18),
            label: const Text('Pemasukan',
                style: TextStyle(fontWeight: FontWeight.bold)),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF10B981),
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: onPengeluaranTap,
            icon: const Icon(Icons.arrow_upward_rounded, size: 18),
            label: const Text('Pengeluaran',
                style: TextStyle(fontWeight: FontWeight.bold)),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFEF4444),
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
          ),
          const SizedBox(height: 12),
          const _WalletExplanationNote(
            message:
                'Catatan semua uang masuk dan keluar servis, berbeda dengan Kas Shift yang hanya uang tunai di laci saat sesi aktif.',
          ),
        ],
      ),
    );
  }

  String _fmtRp(int value) {
    final s = value.abs().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp${value < 0 ? '-' : ''}$buf';
  }
}

class _WalletExplanationNote extends StatelessWidget {
  final String message;

  const _WalletExplanationNote({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.infoBg,
        border: Border.all(color: const Color(0xFFD9E8FF)),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(
            Icons.info_outline_rounded,
            size: 17,
            color: AppColors.info,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                fontSize: 11.5,
                height: 1.35,
                color: AppColors.textBody,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ModernTransactionTile extends StatelessWidget {
  final WalletTransaction tx;
  const _ModernTransactionTile({required this.tx});

  @override
  Widget build(BuildContext context) {
    final isMasuk = tx.type == 'masuk';
    final activeColor =
        isMasuk ? const Color(0xFF10B981) : const Color(0xFFEF4444);

    return GestureDetector(
      onTap: () => _showWalletTransactionDetail(context, tx),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: activeColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.zero,
              ),
              child: Icon(
                isMasuk
                    ? Icons.arrow_downward_rounded
                    : Icons.arrow_upward_rounded,
                color: activeColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _walletDisplayTitle(tx),
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: Color(0xFF1E293B)),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _walletTileSubtitle(tx),
                    style:
                        const TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Text(
              '${isMasuk ? "+" : "-"} ${_fmtRp(tx.nominal)}',
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                color: activeColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showWalletTransactionDetail(
      BuildContext context, WalletTransaction tx) async {
    final isMasuk = tx.type == 'masuk';
    final activeColor =
        isMasuk ? const Color(0xFF10B981) : const Color(0xFFEF4444);
    final source = tx.source.trim().toLowerCase();
    final isManual = source == 'manual';

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      builder: (ctx) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 42,
                  height: 3,
                  color: const Color(0xFFE5E7EB),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    color: activeColor.withValues(alpha: 0.10),
                    child: Icon(
                      isMasuk
                          ? Icons.arrow_downward_rounded
                          : Icons.arrow_upward_rounded,
                      color: activeColor,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isMasuk ? 'Detail Pemasukan' : 'Detail Pengeluaran',
                          style: GoogleFonts.poppins(
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                            color: const Color(0xFF1E293B),
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          _walletSignedMoney(tx),
                          style: GoogleFonts.poppins(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: activeColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(ctx),
                    icon: const Icon(Icons.close_rounded),
                    color: const Color(0xFF64748B),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              _DetailRow('Jenis', _walletTypeLabel(tx)),
              _DetailRow('Sumber Dana', _walletDisplayLabel(tx.walletId)),
              _DetailRow('Tanggal', _formatWalletDate(tx.tanggal)),
              _DetailRow('Waktu', tx.waktu.isEmpty ? '-' : tx.waktu),
              if (_walletCategoryLabel(tx) != '-')
                _DetailRow('Kategori', _walletCategoryLabel(tx)),
              if (_walletNoteLabel(tx) != '-')
                _DetailRow('Keterangan', _walletNoteLabel(tx)),
              _DetailRow('Asal Data', _walletSourceLabel(tx)),
              if (tx.id != null) _DetailRow('ID Transaksi', '#${tx.id}'),
              const SizedBox(height: 14),
              if (isManual)
                _ManualWalletActions(
                  tx: tx,
                  onEdit: () => _editManualTransaction(context, tx),
                  onCancel: () => _cancelManualTransaction(context, tx),
                )
              else
                _WalletSystemNote(
                  text: source == 'adjustment'
                      ? 'Transaksi ini berasal dari Koreksi Saldo. Buat koreksi saldo baru jika saldo aktual perlu disesuaikan lagi.'
                      : 'Transaksi ini dibuat otomatis oleh sistem. Koreksi dari transaksi asal agar saldo dan laporan tetap sinkron.',
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _editManualTransaction(
    BuildContext context,
    WalletTransaction tx,
  ) async {
    final navigator = Navigator.of(context);
    navigator.pop();
    final changed = await navigator.push<bool>(
      MaterialPageRoute(
        builder: (_) => TambahTransaksiDompetScreen(
          initialType: tx.type,
          initialTransaction: tx,
        ),
      ),
    );
    if (changed == true && context.mounted) {
      final container = ProviderScope.containerOf(context, listen: false);
      container.invalidate(drawerCashProvider);
    }
  }

  Future<void> _cancelManualTransaction(
    BuildContext context,
    WalletTransaction tx,
  ) async {
    if (tx.id == null) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Text('Batalkan Transaksi?'),
        content: const Text(
          'Transaksi manual ini akan dibatalkan dari Buku Kas dan tidak ikut saldo aktif.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text(
              'Batalkan',
              style: TextStyle(color: AppColors.danger),
            ),
          ),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;

    final container = ProviderScope.containerOf(context, listen: false);
    final pinOk = await AdminPinDialog.show(
      context,
      verifyPin: (pin) {
        final profilNotifier = container.read(profilProvider.notifier);
        if (!profilNotifier.hasConfiguredAdminPin) {
          return 'PIN admin belum diatur. Buka Pengaturan Profil.';
        }
        return profilNotifier.verifyPin(pin) ? '' : 'PIN salah';
      },
      title: 'Konfirmasi Admin',
      subtitle: 'Masukkan PIN Admin untuk membatalkan transaksi',
    );
    if (!pinOk || !context.mounted) return;

    final staff = container.read(activeStaffProvider);
    final updated =
        await DBHelper.instance.cancelManualWalletTransaction(tx.id!);
    if (!context.mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    if (updated > 0) {
      await DBHelper.instance.insertAuditLog(AuditLog(
        action: 'wallet_transaction_canceled',
        entityType: 'wallet_transaction',
        entityId: tx.id,
        staffId: staff?.id,
        staffName: staff?.name ?? 'Sistem',
        staffRole: staff?.role ?? '',
        amount: tx.nominal,
        note: '${_walletTypeLabel(tx)} - ${_walletDisplayTitle(tx)}',
        createdAt: DateTime.now().toIso8601String(),
      ));
      container.invalidate(walletBalanceProvider);
      container.invalidate(walletTransactionsProvider);
      container.invalidate(walletBalanceByIdProvider('tunai'));
      container.invalidate(walletBalanceByIdProvider('non_tunai'));
      container.invalidate(drawerCashProvider);
      container.invalidate(auditLogsProvider);
      navigator.pop();
      messenger.showSnackBar(const SnackBar(
        content: Text('Transaksi berhasil dibatalkan'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
      ));
    } else {
      messenger.showSnackBar(const SnackBar(
        content: Text('Transaksi tidak bisa dibatalkan'),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
      ));
    }
  }

  String _fmtRp(int value) {
    return _fmtWalletRp(value);
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;

  const _DetailRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFFE2E8F0))),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 108,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: Color(0xFF64748B),
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w800,
                color: Color(0xFF1E293B),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ManualWalletActions extends StatelessWidget {
  final WalletTransaction tx;
  final VoidCallback onEdit;
  final VoidCallback onCancel;

  const _ManualWalletActions({
    required this.tx,
    required this.onEdit,
    required this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    final isMasuk = tx.type == 'masuk';
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: onEdit,
            icon: const Icon(Icons.edit_outlined, size: 17),
            label: const Text('Edit'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.primaryBrand,
              side: const BorderSide(color: AppColors.primaryBrand),
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: onCancel,
            icon: const Icon(Icons.delete_outline_rounded, size: 17),
            label: Text(isMasuk ? 'Batalkan' : 'Hapus'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.danger,
              side: const BorderSide(color: AppColors.danger),
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
          ),
        ),
      ],
    );
  }
}

class _WalletSystemNote extends StatelessWidget {
  final String text;

  const _WalletSystemNote({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.infoBg,
        border: Border.all(color: const Color(0xFFD9E8FF)),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline_rounded,
              size: 18, color: AppColors.info),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontSize: 12,
                height: 1.35,
                color: AppColors.textBody,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyTransactions extends StatelessWidget {
  const _EmptyTransactions();
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.history_toggle_off_rounded,
              size: 48, color: Colors.grey.shade300),
          const SizedBox(height: 12),
          const Text('Belum ada transaksi',
              style: TextStyle(color: Colors.black26, fontSize: 14)),
        ],
      ),
    );
  }
}

class _AdjustField extends StatelessWidget {
  final String label;
  final TextEditingController ctrl;
  final int current;

  const _AdjustField(
      {required this.label, required this.ctrl, required this.current});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(label,
                style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: Colors.black54)),
            const Spacer(),
            Text('Saat ini: ${_fmtRp(current)}',
                style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
          ],
        ),
        const SizedBox(height: 6),
        TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          inputFormatters: const [_WalletCurrencyInputFormatter()],
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
          decoration: const InputDecoration(
            prefixText: 'Rp ',
            border: OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFD0D5DD))),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFD0D5DD))),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: _kBrand, width: 1.5)),
            contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
      ],
    );
  }

  String _fmtRp(int value) {
    final s = value.abs().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp$buf';
  }
}

