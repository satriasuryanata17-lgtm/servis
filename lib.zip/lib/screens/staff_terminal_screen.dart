import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:google_fonts/google_fonts.dart';
import '../providers/providers.dart';
import '../models/db_models.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';

class StaffTerminalScreen extends ConsumerStatefulWidget {
  const StaffTerminalScreen({super.key});

  @override
  ConsumerState<StaffTerminalScreen> createState() =>
      _StaffTerminalScreenState();
}

class _StaffTerminalScreenState extends ConsumerState<StaffTerminalScreen> {
  String _pin = '';
  late Timer _timer;
  DateTime _now = DateTime.now();
  bool _isLoggingOut = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ScaffoldMessenger.of(context).hideCurrentSnackBar();
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  void _handleKeyPress(String key) {
    if (_pin.length >= 6 && key != 'back') return;

    setState(() {
      if (key == 'back') {
        if (_pin.isNotEmpty) _pin = _pin.substring(0, _pin.length - 1);
      } else {
        _pin += key;
      }
    });

    if (_pin.length == 6) {
      _verifyPin();
    }
  }

  void _selectStaff(Employee employee, Employee? selectedStaff) {
    final isSameStaff = selectedStaff?.id == employee.id;
    ref
        .read(selectedStaffForPinProvider.notifier)
        .set(isSameStaff ? null : employee);
    setState(() => _pin = '');
  }

  Future<void> _logoutAccount() async {
    if (_isLoggingOut) return;
    setState(() => _isLoggingOut = true);

    ref.read(selectedStaffForPinProvider.notifier).set(null);
    await ref.read(activeStaffProvider.notifier).logout();
    await ref.read(authProvider.notifier).logout();

    if (mounted) {
      setState(() {
        _pin = '';
        _isLoggingOut = false;
      });
    }
  }

  Future<void> _verifyPin() async {
    final selectedStaff = ref.read(selectedStaffForPinProvider);
    if (selectedStaff == null) {
      final profilNotifier = ref.read(profilProvider.notifier);
      if (!profilNotifier.hasConfiguredAdminPin) {
        _showError(
            'PIN admin wajib diatur sebelum Master Admin dapat digunakan');
        setState(() => _pin = '');
        return;
      }

      final isMaster = profilNotifier.verifyPin(_pin);

      if (isMaster) {
        await _loginAsMaster();
        return;
      }
      _showError('PIN admin salah atau pilih karyawan terlebih dahulu');
      setState(() => _pin = '');
      return;
    }

    final isValid = AuthService.verifyStaffPin(selectedStaff, _pin);
    if (isValid) {
      // 1. Set active staff (save to SharedPreferences)
      await ref.read(activeStaffProvider.notifier).set(selectedStaff);

      // 2. Clear PIN state for next time
      setState(() => _pin = '');
      ref.read(selectedStaffForPinProvider.notifier).set(null);
    } else {
      _showError('PIN yang Anda masukkan salah');
      setState(() => _pin = '');
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _loginAsMaster() async {
    setState(() => _pin = '');
    final profile = ref.read(profilProvider);
    final masterAdmin = Employee(
      id: -1,
      name: profile.nama.isNotEmpty ? profile.nama : 'Master Admin',
      role: 'Owner',
      phone: '',
      pin: null,
      createdAt: DateTime.now().toIso8601String(),
    );
    await ref.read(activeStaffProvider.notifier).set(masterAdmin);
  }

  @override
  Widget build(BuildContext context) {
    final employees = ref.watch(employeesProvider);
    final selectedStaff = ref.watch(selectedStaffForPinProvider);
    final screenWidth = MediaQuery.of(context).size.width;
    final isWide = screenWidth > 800;

    return Scaffold(
      backgroundColor: const Color(0xFF1E293B), // Slate 900
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: isWide
                  ? _buildWideLayout(employees, selectedStaff)
                  : _buildMobileLayout(employees, selectedStaff),
            ),
            Positioned(
              left: isWide ? 32 : 20,
              bottom: isWide ? 32 : 18,
              child: _TerminalLogoutButton(
                isLoading: _isLoggingOut,
                onTap: _logoutAccount,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWideLayout(List<Employee> employees, Employee? selected) {
    return Row(
      children: [
        // LEFT: Info & Staff Selection
        Expanded(
          flex: 4,
          child: Container(
            padding: const EdgeInsets.all(48),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(isWide: true),
                const Spacer(),
                Text(
                  'SIAPA YANG BERTUGAS?',
                  style: GoogleFonts.plusJakartaSans(
                    color: Colors.white60,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 24),
                _buildStaffGrid(employees, selected),
                const Spacer(),
              ],
            ),
          ),
        ),
        // RIGHT: PIN Pad
        Container(
          width: 450,
          color: const Color(0xFF0F172A), // Slate 950
          padding: const EdgeInsets.all(48),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildPinIndicator(),
              const SizedBox(height: 48),
              _buildPinPad(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMobileLayout(List<Employee> employees, Employee? selected) {
    return Column(
      children: [
        _buildHeader(isWide: false),
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 8),
                if (employees.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 20),
                    child: Text('Belum ada karyawan. Tambah di menu Karyawan.',
                        style: GoogleFonts.inter(
                            color: Colors.white38, fontSize: 12)),
                  )
                else
                  _buildStaffMobileList(employees, selected),
                const SizedBox(height: 16),
                _buildPinIndicator(),
                const SizedBox(height: 16),
                SizedBox(
                  width: 320,
                  child: _buildPinPad(),
                ),
                const SizedBox(height: 76),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHeader({required bool isWide}) {
    return Padding(
      padding: EdgeInsets.all(isWide ? 0 : 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(isWide ? 12 : 8),
                decoration: BoxDecoration(
                  color: AppColors.primaryBrand.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.zero,
                ),
                child: Icon(Icons.point_of_sale_rounded,
                    color: AppColors.primaryBrand, size: isWide ? 32 : 20),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Juragan Servis',
                    style: GoogleFonts.plusJakartaSans(
                      color: Colors.white,
                      fontSize: isWide ? 24 : 16,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.5,
                    ),
                  ),
                  Text(
                    'Staff Terminal',
                    style: GoogleFonts.plusJakartaSans(
                      color: Colors.white38,
                      fontSize: isWide ? 12 : 9,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              if (!isWide) ...[
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      DateFormat('HH:mm').format(_now),
                      style: GoogleFonts.plusJakartaSans(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      DateFormat('dd MMM').format(_now),
                      style: GoogleFonts.plusJakartaSans(
                        color: Colors.white38,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
          if (isWide) ...[
            const SizedBox(height: 32),
            Text(
              DateFormat('HH:mm').format(_now),
              style: GoogleFonts.plusJakartaSans(
                color: Colors.white,
                fontSize: 64,
                fontWeight: FontWeight.w800,
                letterSpacing: -2,
              ),
            ),
            Text(
              DateFormat('EEEE, d MMMM yyyy').format(_now),
              style: GoogleFonts.plusJakartaSans(
                color: Colors.white60,
                fontSize: 18,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStaffGrid(List<Employee> employees, Employee? selected) {
    return Wrap(
      spacing: 16,
      runSpacing: 16,
      children: employees
          .map((e) => _StaffCard(
                employee: e,
                isSelected: selected?.id == e.id,
                onTap: () => _selectStaff(e, selected),
              ))
          .toList(),
    );
  }

  Widget _buildStaffMobileList(List<Employee> employees, Employee? selected) {
    return SizedBox(
      height: 180,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        scrollDirection: Axis.horizontal,
        itemCount: employees.length,
        separatorBuilder: (_, __) => const SizedBox(width: 20),
        itemBuilder: (ctx, i) => _StaffCard(
          employee: employees[i],
          isSelected: selected?.id == employees[i].id,
          onTap: () => _selectStaff(employees[i], selected),
        ),
      ),
    );
  }

  Widget _buildPinIndicator() {
    return Column(
      children: [
        if (ref.watch(selectedStaffForPinProvider) != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(
              'LOGIN SEBAGAI: ${ref.watch(selectedStaffForPinProvider)!.name.toUpperCase()}',
              style: const TextStyle(
                  color: AppColors.primaryBrand,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  letterSpacing: 1),
            ),
          ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(6, (index) {
            bool isActive = index < _pin.length;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 20,
              height: 20,
              margin: const EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isActive ? AppColors.primaryBrand : Colors.white10,
                border: Border.all(
                  color: isActive ? AppColors.primaryBrand : Colors.white30,
                  width: 2,
                ),
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildPinPad() {
    return Column(
      children: [
        _buildPadRow(['1', '2', '3']),
        const SizedBox(height: 20),
        _buildPadRow(['4', '5', '6']),
        const SizedBox(height: 20),
        _buildPadRow(['7', '8', '9']),
        const SizedBox(height: 20),
        Row(
          children: [
            const Expanded(child: SizedBox()),
            const SizedBox(width: 20),
            Expanded(
                child: _PadBtn(label: '0', onTap: () => _handleKeyPress('0'))),
            const SizedBox(width: 20),
            Expanded(
                child: _PadBtn(
              icon: Icons.backspace_outlined,
              onTap: () => _handleKeyPress('back'),
              isSecondary: true,
            )),
          ],
        ),
      ],
    );
  }

  Widget _buildPadRow(List<String> keys) {
    return Row(
      children: keys
          .map((k) => Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: _PadBtn(label: k, onTap: () => _handleKeyPress(k)),
                ),
              ))
          .toList(),
    );
  }
}

class _TerminalLogoutButton extends StatelessWidget {
  final bool isLoading;
  final VoidCallback onTap;

  const _TerminalLogoutButton({
    required this.isLoading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: isLoading ? null : onTap,
        borderRadius: BorderRadius.zero,
        child: Container(
          height: 40,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.06),
            borderRadius: BorderRadius.zero,
            border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (isLoading)
                const SizedBox(
                  width: 15,
                  height: 15,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white70,
                  ),
                )
              else
                const Icon(Icons.logout_rounded,
                    color: Colors.white70, size: 16),
              const SizedBox(width: 8),
              Text(
                'Keluar Akun',
                style: GoogleFonts.plusJakartaSans(
                  color: Colors.white70,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StaffCard extends StatelessWidget {
  final Employee employee;
  final bool isSelected;
  final VoidCallback onTap;

  const _StaffCard({
    required this.employee,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 110,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.primaryBrand.withValues(alpha: 0.15)
              : Colors.white.withValues(alpha: 0.05),
          borderRadius: BorderRadius.zero,
          border: Border.all(
            color: isSelected ? AppColors.primaryBrand : Colors.transparent,
            width: 2,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: isSelected ? AppColors.primaryBrand : Colors.white10,
                borderRadius: BorderRadius.zero,
              ),
              child: Center(
                child: Text(
                  employee.name.substring(0, 1).toUpperCase(),
                  style: TextStyle(
                    color: isSelected ? Colors.white : Colors.white60,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              employee.name,
              style: GoogleFonts.plusJakartaSans(
                color: isSelected ? Colors.white : Colors.white60,
                fontSize: 13,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              employee.role,
              style: GoogleFonts.plusJakartaSans(
                color: isSelected ? AppColors.primaryBrand : Colors.white24,
                fontSize: 10,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PadBtn extends StatelessWidget {
  final String? label;
  final IconData? icon;
  final VoidCallback onTap;
  final bool isSecondary;

  const _PadBtn({
    this.label,
    this.icon,
    required this.onTap,
    this.isSecondary = false,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.zero,
        child: Container(
          height: 90,
          decoration: BoxDecoration(
            color: isSecondary
                ? Colors.white.withValues(alpha: 0.03)
                : Colors.white.withValues(alpha: 0.07),
            borderRadius: BorderRadius.zero,
          ),
          child: Center(
            child: label != null
                ? Text(
                    label!,
                    style: GoogleFonts.plusJakartaSans(
                      color: Colors.white,
                      fontSize: 38,
                      fontWeight: FontWeight.w600,
                    ),
                  )
                : Icon(icon, color: Colors.white70, size: 28),
          ),
        ),
      ),
    );
  }
}

