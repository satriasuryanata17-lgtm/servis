import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import '../providers/providers.dart';
import 'responsive_layout.dart';

class PengaturanHardwareScreen extends ConsumerWidget {
  const PengaturanHardwareScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(hardwarePricingSettingsProvider);

    Future<void> update(bool value) async {
      await ref
          .read(hardwarePricingSettingsProvider.notifier)
          .update(settings.copyWith(roundUpToKg: value));
      if (!context.mounted) return;
      ScaffoldMessenger.of(context)
        ..clearSnackBars()
        ..showSnackBar(
          SnackBar(
            content: Text(
              value
                  ? 'Harga layanan dibulatkan ke kg berikutnya.'
                  : 'Harga layanan kembali mengikuti berat aktual.',
            ),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
    }

    return KasirResponsiveScaffold(
      title: 'Harga Layanan',
      navIndex: 9,
      showNavRail: false,
      backgroundColor: AppColors.background,
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFEFF6FF),
              border: Border.all(color: const Color(0xFFBFDBFE)),
              borderRadius: BorderRadius.zero,
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.scale_outlined,
                    color: AppColors.primaryBrand, size: 20),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Pengaturan ini berlaku untuk semua layanan servis dengan software kg. Berat asli tetap tersimpan, tetapi harga bisa memakai berat tagih.',
                    style: TextStyle(
                      fontSize: 12.5,
                      height: 1.45,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF1E3A8A),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _SettingCard(
            title: 'Pembulatan Harga Per Kg',
            subtitle:
                'Jika aktif, berat pecahan akan ditagihkan ke kg berikutnya.',
            trailing: Switch(
              value: settings.roundUpToKg,
              activeThumbColor: AppColors.primaryBrand,
              onChanged: update,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12),
                _ExampleRow(
                  label: 'Berat 1 kg',
                  value: settings.roundUpToKg ? 'Tagih 1 kg' : 'Tagih 1 kg',
                ),
                _ExampleRow(
                  label: 'Berat 1,01 kg',
                  value: settings.roundUpToKg ? 'Tagih 2 kg' : 'Tagih 1,01 kg',
                ),
                _ExampleRow(
                  label: 'Berat 1,6 kg',
                  value: settings.roundUpToKg ? 'Tagih 2 kg' : 'Tagih 1,6 kg',
                ),
                _ExampleRow(
                  label: 'Berat 2,2 kg',
                  value: settings.roundUpToKg ? 'Tagih 3 kg' : 'Tagih 2,2 kg',
                  showDivider: false,
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _ModeOption(
            selected: !settings.roundUpToKg,
            title: 'Ikuti Berat Aktual',
            subtitle:
                'Contoh harga Rp10.000/kg, berat 1,6 kg menjadi Rp16.000.',
            onTap: () => update(false),
          ),
          const SizedBox(height: 10),
          _ModeOption(
            selected: settings.roundUpToKg,
            title: 'Bulatkan ke Kg Berikutnya',
            subtitle:
                'Contoh harga Rp10.000/kg, berat 1,6 kg menjadi Rp20.000.',
            onTap: () => update(true),
          ),
        ],
      ),
    );
  }
}

class _SettingCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget trailing;
  final Widget child;

  const _SettingCard({
    required this.title,
    required this.subtitle,
    required this.trailing,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 12,
                        height: 1.35,
                        color: Color(0xFF64748B),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              trailing,
            ],
          ),
          child,
        ],
      ),
    );
  }
}

class _ExampleRow extends StatelessWidget {
  final String label;
  final String value;
  final bool showDivider;

  const _ExampleRow({
    required this.label,
    required this.value,
    this.showDivider = true,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 9),
      decoration: BoxDecoration(
        border: Border(
          bottom: showDivider
              ? const BorderSide(color: Color(0xFFE2E8F0))
              : BorderSide.none,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 12.5,
                color: Color(0xFF475569),
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 12.5,
              color: Color(0xFF0F172A),
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _ModeOption extends StatelessWidget {
  final bool selected;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ModeOption({
    required this.selected,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFEFF6FF) : Colors.white,
          border: Border.all(
            color: selected ? AppColors.primaryBrand : const Color(0xFFE2E8F0),
          ),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          children: [
            Icon(
              selected
                  ? Icons.radio_button_checked_rounded
                  : Icons.radio_button_off_rounded,
              color:
                  selected ? AppColors.primaryBrand : const Color(0xFF94A3B8),
              size: 21,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w800,
                      color: selected
                          ? AppColors.primaryBrand
                          : const Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 11.5,
                      height: 1.35,
                      color: Color(0xFF64748B),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

