import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:shared_preferences/shared_preferences.dart';
// ignore_for_file: deprecated_member_use

import 'dart:io';
import 'dart:ui' as ui;
import 'package:barcode_widget/barcode_widget.dart' as import_barcode_widget;
import '../widgets/custom_icons.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:simple_barcode_scanner/simple_barcode_scanner.dart'
    as simple_barcode;
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../services/export_service.dart';
import '../services/import_service.dart';
import '../services/label_print_service.dart';
import '../widgets/label_preview_widget.dart';
import 'produk_terjual_screen.dart';
import 'cetak_label_screen.dart';

import '../widgets/kasir_drawer.dart';
import '../widgets/kasir_dialog.dart';
import '../widgets/supplier_form_sheet.dart';
import 'detail_stok_screen.dart';
import 'kategori_screen.dart';
import 'supplier_screen.dart';
import 'purchase_order_screen.dart';
import 'riwayat_stok_laporan_screen.dart';

import '../core/theme.dart';
import '../widgets/modern_picker.dart';

import 'responsive_layout.dart';

import '../utils/image_utils.dart';
import '../utils/currency_input_formatter.dart';

//  Warna Brand Slate Teal --
const Color _kBrand = AppColors.primaryBrand;
const Color _kGreen = Color(0xFF2E9D4F);
const Color _kInventoryCardSurface = Color(0xFFFDFEFF);
const Color _kInventoryCardBorder = Color(0xFFCBD5E1);
const Color _kInventoryMediaBorder = Color(0xFFE2E8F0);
// Keep desktop cards close to their real content height so grid rows do not
// leave large empty white bands between items.
const double _kWideProductCardExtent = 244;
const double _kWideGudangCardExtent = 262;
const int _kWideGridColumns = 5;
const String _customservisUnitsPrefsKey = 'servis_custom_units';
const String _productListLayoutGridPrefsKey = 'product_list_layout_grid';
const String _warehouseLayoutGridPrefsKey = 'warehouse_product_layout_grid';
final bool _kSupportsStandaloneBarcodeScanner =
    !Platform.isWindows && !Platform.isLinux;

int _responsiveWideGridColumns(double width) {
  if (width >= 1080) return _kWideGridColumns;
  return 4;
}

String _autoBarcodeForProductId(int id, {bool isMaterial = false}) =>
    '${isMaterial ? 'MAT' : 'SVC'}${id.toString().padLeft(6, '0')}';

String _resolvedBarcodeForProduct(Product product) {
  final raw = product.barcode?.trim() ?? '';
  if (raw.isNotEmpty) return raw;
  final id = product.id;
  return id == null
      ? ''
      : _autoBarcodeForProductId(id, isMaterial: product.isMaterial == 1);
}

bool get _isMobilePlatform => Platform.isAndroid || Platform.isIOS;

//  Format angka rupiah
String _fmtP(int n) {
  if (n == 0) return '0';
  String s = n.toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return r;
}

//  Format tanggal dari ISO string
String _fmtDate(String? iso) {
  if (iso == null || iso.isEmpty) return '-';
  try {
    final dt = DateTime.parse(iso);
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'Mei',
      'Jun',
      'Jul',
      'Ags',
      'Sep',
      'Okt',
      'Nov',
      'Des'
    ];
    return '${dt.day} ${months[dt.month - 1]} ${dt.year}';
  } catch (_) {
    return '-';
  }
}

class ProdukScreen extends StatelessWidget {
  const ProdukScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isWide = isTabletDevice(context) || isLandscape(context);
    final mq = MediaQuery.of(context);
    final isLandscapePhone =
        mq.orientation == Orientation.landscape && mq.size.shortestSide < 600;
    final int crossAxisCount = isWide ? (isTabletDevice(context) ? 3 : 2) : 1;
    final double childAspectRatio = isWide
        ? (isTabletDevice(context) ? 3.8 : (isLandscapePhone ? 7.5 : 4.0))
        : 4.8;

    return KasirResponsiveScaffold(
      title: 'Layanan & Inventori',
      navIndex: 2,
      drawer: const KasirDrawer(),
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          _sliverHeader('KATALOG & LAYANAN'),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            sliver: SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossAxisCount,
                childAspectRatio: childAspectRatio,
                mainAxisSpacing: 0,
                crossAxisSpacing: 0,
              ),
              delegate: SliverChildListDelegate([
                _MenuItemWidget(
                  title: 'Daftar Layanan',
                  subtitle: 'Lihat dan kelola semua layanan servis.',
                  icon: Icons.handyman_outlined,
                  screen: const DaftarProdukScreen(),
                  isGrid: isWide,
                ),
                _MenuItemWidget(
                  title: 'Layanan Tambahan',
                  subtitle: 'Kelola sparepart, opsi, atau layanan tambahan.',
                  icon: Icons.post_add_outlined,
                  screen: const ProdukEkstraScreen(),
                  isGrid: isWide,
                ),
                _MenuItemWidget(
                  title: 'Kelola Kategori',
                  subtitle: 'Tambah, edit, dan hapus kategori layanan.',
                  icon: Icons.category_outlined,
                  screen: const KategoriScreen(),
                  isGrid: isWide,
                ),
              ]),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 6)),

          //  HARGA & PROMOSI
          _sliverHeader('HARGA & PROMOSI'),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            sliver: SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossAxisCount,
                childAspectRatio: childAspectRatio,
                mainAxisSpacing: 0,
                crossAxisSpacing: 0,
              ),
              delegate: SliverChildListDelegate([
                _MenuItemWidget(
                  title: 'Diskon',
                  subtitle: 'Kelola diskon dan potongan harga layanan.',
                  icon: Icons.local_offer_outlined,
                  screen: const DiskonProdukScreen(),
                  isGrid: isWide,
                ),
                _MenuItemWidget(
                  title: 'Layanan Terjual',
                  subtitle: 'Statistik pergerakan dan penjualan layanan.',
                  icon: Icons.analytics_outlined,
                  screen: const ProdukTerjualScreen(),
                  isGrid: isWide,
                ),
              ]),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 16)),

          //  PENGADAAN & STOK
          _sliverHeader('PENGADAAN & STOK'),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            sliver: SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossAxisCount,
                childAspectRatio: childAspectRatio,
                mainAxisSpacing: 0,
                crossAxisSpacing: 0,
              ),
              delegate: SliverChildListDelegate([
                _MenuItemWidget(
                  title: 'Daftar Supplier',
                  subtitle: 'Kelola vendor dan pemasok bahan servis.',
                  icon: Icons.business_outlined,
                  screen: const SupplierScreen(),
                  isGrid: isWide,
                ),
                _MenuItemWidget(
                  title: 'Pembelian Supplier',
                  subtitle: 'Pesan, terima barang, dan bayar supplier.',
                  icon: Icons.receipt_long_outlined,
                  screen: const PurchaseOrderScreen(),
                  isGrid: isWide,
                ),
              ]),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 16)),

          //  MANAJEMEN INVENTORI
          _sliverHeader('MANAJEMEN INVENTORI'),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            sliver: SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossAxisCount,
                childAspectRatio: childAspectRatio,
                mainAxisSpacing: 0,
                crossAxisSpacing: 0,
              ),
              delegate: SliverChildListDelegate([
                _MenuItemWidget(
                  title: 'Bahan Baku',
                  subtitle:
                      'Kelola sparepart, bahan teknisi, dan stok internal.',
                  icon: Icons.science_outlined,
                  screen: const BahanBakuScreen(),
                  isGrid: isWide,
                ),
                _MenuItemWidget(
                  title: 'Informasi Gudang',
                  subtitle: 'Pantau stok produk jual dan bahan baku.',
                  icon: Icons.inventory_2_outlined,
                  screen: const GudangScreen(),
                  isGrid: isWide,
                ),
                _MenuItemWidget(
                  title: 'Riwayat Stok',
                  subtitle: 'Pantau riwayat mutasi stok masuk dan keluar.',
                  icon: Icons.history_rounded,
                  screen: const RiwayatStokLaporanScreen(),
                  isGrid: isWide,
                ),
                _MenuItemWidget(
                  title: 'Download Barcode',
                  subtitle:
                      'Unduh atau cetak barcode layanan untuk scanner fisik.',
                  icon: Icons.qr_code_scanner_outlined,
                  screen: const CetakLabelScreen(),
                  isGrid: isWide,
                ),
              ]),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
    );
  }

  Widget _sliverHeader(String title) {
    return SliverToBoxAdapter(child: _buildGroupHeader(title));
  }

  Widget _buildGroupHeader(String title) {
    return LayoutBuilder(builder: (ctx, _) {
      final mq = MediaQuery.of(ctx);
      final isLandscapePhone =
          mq.orientation == Orientation.landscape && mq.size.shortestSide < 600;
      return Padding(
        padding: isLandscapePhone
            ? const EdgeInsets.fromLTRB(16, 8, 16, 2)
            : const EdgeInsets.fromLTRB(16, 16, 16, 4),
        child: Text(
          title,
          style: TextStyle(
            fontSize: isLandscapePhone ? 10 : 12,
            fontWeight: FontWeight.w800,
            color: _kBrand,
            letterSpacing: 1.2,
          ),
        ),
      );
    });
  }
}

class _MenuItemWidget extends StatelessWidget {
  final String title, subtitle;
  final IconData icon;
  final Widget screen;
  final bool isGrid;
  const _MenuItemWidget({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.screen,
    this.isGrid = false,
  });

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final isLandscapePhone =
        mq.orientation == Orientation.landscape && mq.size.shortestSide < 600;

    return InkWell(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => screen),
      ),
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: isLandscapePhone ? 12 : 16,
          vertical: isGrid ? (isLandscapePhone ? 6 : 8) : 10,
        ),
        decoration: isGrid
            ? BoxDecoration(
                border: Border.all(color: const Color(0xFFF1F5F9), width: 0.5),
              )
            : null,
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(isLandscapePhone ? 7 : 10),
              decoration: BoxDecoration(
                color: _kBrand.withValues(alpha: 0.08),
                borderRadius: BorderRadius.zero,
              ),
              child:
                  Icon(icon, color: _kBrand, size: isLandscapePhone ? 18 : 22),
            ),
            SizedBox(width: isLandscapePhone ? 10 : 14),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: isGrid ? (isLandscapePhone ? 13 : 14) : 15,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  if (!isLandscapePhone) ...[
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style:
                          const TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ],
                ],
              ),
            ),
            Icon(Icons.chevron_right,
                color: Colors.black26, size: isLandscapePhone ? 18 : 24),
          ],
        ),
      ),
    );
  }
}

//
//  DAFTAR PRODUK SCREEN  (Image 2)
//
class DaftarProdukScreen extends ConsumerStatefulWidget {
  const DaftarProdukScreen({super.key});

  @override
  ConsumerState<DaftarProdukScreen> createState() => _DaftarProdukScreenState();
}

class _ServiceSortOption {
  final String value;
  final String title;
  final String subtitle;
  final IconData icon;

  const _ServiceSortOption({
    required this.value,
    required this.title,
    required this.subtitle,
    required this.icon,
  });
}

class _DaftarProdukScreenState extends ConsumerState<DaftarProdukScreen> {
  String _query = '';
  static const String _sortNameAsc = 'Nama Layanan A-Z';
  static const String _sortPriceAsc = 'Harga Termurah';
  static const String _sortPriceDesc = 'Harga Termahal';
  static const String _sortDurationAsc = 'Durasi Tercepat';
  static const String _sortDurationDesc = 'Durasi Terlama';
  static const String _sortStockDesc = 'Stok Item Terbanyak';

  String _sortMode = _sortNameAsc;
  int? _selectedCategoryId;
  bool _isGridMode = true;
  bool _isSelectMode = false;
  final Set<int> _selectedProductIds = {};
  final TextEditingController _searchCtrl = TextEditingController();
  final GlobalKey _barcodeDownloadPreviewKey = GlobalKey();

  static const List<_ServiceSortOption> _sortOptions = [
    _ServiceSortOption(
      value: _sortNameAsc,
      title: 'Nama Layanan A-Z',
      subtitle: 'Urutkan layanan berdasarkan nama.',
      icon: Icons.sort_by_alpha_rounded,
    ),
    _ServiceSortOption(
      value: _sortPriceAsc,
      title: 'Harga Termurah',
      subtitle: 'Cari layanan dengan harga paling rendah.',
      icon: Icons.south_rounded,
    ),
    _ServiceSortOption(
      value: _sortPriceDesc,
      title: 'Harga Termahal',
      subtitle: 'Tampilkan layanan bernilai tinggi lebih dulu.',
      icon: Icons.north_rounded,
    ),
    _ServiceSortOption(
      value: _sortDurationAsc,
      title: 'Pengerjaan Tercepat',
      subtitle: 'Prioritaskan layanan kilat atau cepat selesai.',
      icon: Icons.bolt_rounded,
    ),
    _ServiceSortOption(
      value: _sortDurationDesc,
      title: 'Pengerjaan Terlama',
      subtitle: 'Lihat layanan yang butuh waktu proses lebih lama.',
      icon: Icons.schedule_rounded,
    ),
    _ServiceSortOption(
      value: _sortStockDesc,
      title: 'Stok Item Terbanyak',
      subtitle: 'Untuk item fisik dengan manajemen stok aktif.',
      icon: Icons.inventory_2_outlined,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _loadLayoutPreference();
  }

  Future<void> _loadLayoutPreference() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _isGridMode = prefs.getBool(_productListLayoutGridPrefsKey) ?? true;
    });
  }

  void _setLayoutGrid(bool isGrid) {
    if (_isGridMode == isGrid) return;
    setState(() => _isGridMode = isGrid);
    SharedPreferences.getInstance().then(
      (prefs) => prefs.setBool(_productListLayoutGridPrefsKey, isGrid),
    );
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Widget _sidebarItem(
      String label, int? id, bool selected, void Function(int?) onTap) {
    return ListTile(
      title: Text(label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            color: selected ? _kBrand : Colors.black87,
          )),
      trailing: selected
          ? const Icon(Icons.check_circle, size: 18, color: _kBrand)
          : null,
      onTap: () => onTap(id),
      dense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      selected: selected,
      selectedTileColor: _kBrand.withValues(alpha: 0.05),
    );
  }

  List<Product> _sortedProducts(List<Product> products) {
    final list = [...products];
    int byName(Product a, Product b) =>
        a.name.toLowerCase().compareTo(b.name.toLowerCase());
    int durationForFastest(Product p) =>
        p.durationHours > 0 ? p.durationHours : 1 << 30;
    int durationForSlowest(Product p) =>
        p.durationHours > 0 ? p.durationHours : -1;
    int stockScore(Product p) => p.hasStockManagement == 1 ? p.stock : -1;

    switch (_sortMode) {
      case _sortStockDesc:
      case 'Stok Tertinggi':
        list.sort((a, b) {
          final stockCompare = stockScore(b).compareTo(stockScore(a));
          return stockCompare != 0 ? stockCompare : byName(a, b);
        });
        break;
      case _sortPriceDesc:
      case 'Harga Tertinggi':
        list.sort((a, b) {
          final priceCompare = b.sellPrice.compareTo(a.sellPrice);
          return priceCompare != 0 ? priceCompare : byName(a, b);
        });
        break;
      case _sortPriceAsc:
      case 'Harga Terendah':
        list.sort((a, b) {
          final priceCompare = a.sellPrice.compareTo(b.sellPrice);
          return priceCompare != 0 ? priceCompare : byName(a, b);
        });
        break;
      case _sortDurationAsc:
        list.sort((a, b) {
          final durationCompare =
              durationForFastest(a).compareTo(durationForFastest(b));
          return durationCompare != 0 ? durationCompare : byName(a, b);
        });
        break;
      case _sortDurationDesc:
        list.sort((a, b) {
          final durationCompare =
              durationForSlowest(b).compareTo(durationForSlowest(a));
          return durationCompare != 0 ? durationCompare : byName(a, b);
        });
        break;
      case _sortNameAsc:
      case 'Nama A-Z':
      default:
        list.sort(byName);
    }
    return list;
  }

  Future<void> _showSortSheet() async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 48,
                    height: 4,
                    color: const Color(0xFFE5E7EB),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Urutkan Layanan',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF0F172A),
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Pilih urutan yang paling membantu saat mengelola layanan servis.',
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    height: 1.35,
                  ),
                ),
                const SizedBox(height: 14),
                ..._sortOptions.map(
                  (opt) => _sortSheetTile(sheetContext, opt),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (selected != null) setState(() => _sortMode = selected);
  }

  Widget _sortSheetTile(BuildContext sheetContext, _ServiceSortOption opt) {
    final selected = _sortMode == opt.value ||
        (_sortMode == 'Nama A-Z' && opt.value == _sortNameAsc) ||
        (_sortMode == 'Stok Tertinggi' && opt.value == _sortStockDesc) ||
        (_sortMode == 'Harga Tertinggi' && opt.value == _sortPriceDesc) ||
        (_sortMode == 'Harga Terendah' && opt.value == _sortPriceAsc);
    return InkWell(
      onTap: () => Navigator.pop(sheetContext, opt.value),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFEFF6FF) : Colors.white,
          border: Border.all(
            color: selected ? _kBrand : const Color(0xFFE2E8F0),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 34,
              height: 34,
              color:
                  selected ? const Color(0xFFDBEAFE) : const Color(0xFFF1F5F9),
              child: Icon(
                opt.icon,
                size: 18,
                color: selected ? _kBrand : const Color(0xFF64748B),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    opt.title,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: selected ? _kBrand : const Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    opt.subtitle,
                    style: const TextStyle(
                      fontSize: 11,
                      height: 1.35,
                      color: Color(0xFF64748B),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Icon(
              selected ? Icons.check_circle_rounded : Icons.circle_outlined,
              size: 20,
              color: selected ? _kBrand : const Color(0xFFCBD5E1),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _scanAndSearch() async {
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const StandaloneScannerScreen()),
    );
    if (!mounted) return;

    final rawCode = result?.trim() ?? '';
    if (rawCode.isEmpty || rawCode == '-1') {
      _showScanSnack(
        'Scan dibatalkan atau barcode belum terbaca.',
        isError: true,
      );
      return;
    }

    final code = rawCode;
    final normalizedCode = _normalizeScanCode(code);
    final allMainProducts = ref
        .read(productsProvider)
        .where((p) => p.isExtra == 0 && p.isMaterial == 0)
        .toList();
    Product? foundProduct;
    for (final product in allMainProducts) {
      final barcode = _normalizeScanCode(product.barcode ?? '');
      final sku = _normalizeScanCode(product.sku ?? '');
      if ((barcode.isNotEmpty && barcode == normalizedCode) ||
          (sku.isNotEmpty && sku == normalizedCode)) {
        foundProduct = product;
        break;
      }
    }

    setState(() {
      _query = code;
      _selectedCategoryId = null;
      _searchCtrl.value = TextEditingValue(
        text: code,
        selection: TextSelection.collapsed(offset: code.length),
      );
    });

    if (foundProduct == null) {
      _showScanSnack(
        'Barcode "$code" tidak menemukan layanan. Cek kode/SKU layanan.',
        isError: true,
      );
      return;
    }

    _showScanSnack('Layanan ditemukan: ${foundProduct.name}');
  }

  String _normalizeScanCode(String value) {
    return value.trim().toUpperCase().replaceAll(RegExp(r'[\s\-_]'), '');
  }

  void _showScanSnack(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(
                isError ? Icons.error_outline_rounded : Icons.check_circle,
                color: isError ? AppColors.danger : AppColors.success,
                size: 18,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  message,
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          backgroundColor: const Color(0xFF1F2937),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(milliseconds: 2200),
          margin: const EdgeInsets.fromLTRB(14, 0, 14, 14),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
          ),
        ),
      );
  }

  Future<void> _showTemplatePicker() async {
    final templates = <_TemplatePaket>[
      _TemplatePaket(
        nama: 'Servis HP & Tablet',
        icon: Icons.phone_android_outlined,
        deskripsi: 'Layanan umum untuk perbaikan HP dan tablet',
        kategori: 'HP & Tablet',
        produk: [
          _tp('Diagnosa Kerusakan HP', 0, 50000, 'unit', 0, duration: 2),
          _tp('Ganti LCD / Touchscreen HP', 50000, 150000, 'unit', 0,
              duration: 4),
          _tp('Ganti Baterai HP', 30000, 75000, 'unit', 0, duration: 2),
          _tp('Perbaikan Port Charger', 40000, 100000, 'unit', 0, duration: 6),
          _tp('Instal Ulang / Flash HP', 20000, 75000, 'unit', 0, duration: 3),
          _tp('Perbaikan Mati Total HP', 75000, 250000, 'unit', 0,
              duration: 48),
        ],
      ),
      _TemplatePaket(
        nama: 'Servis Laptop & Komputer',
        icon: Icons.laptop_mac_outlined,
        deskripsi: 'Perbaikan perangkat kerja, software, dan hardware',
        kategori: 'Laptop & Komputer',
        produk: [
          _tp('Diagnosa Laptop / Komputer', 0, 75000, 'unit', 0, duration: 3),
          _tp('Instal Ulang Sistem Operasi', 20000, 100000, 'unit', 0,
              duration: 6),
          _tp('Pembersihan & Ganti Thermal Paste', 30000, 150000, 'unit', 0,
              duration: 6),
          _tp('Ganti Keyboard Laptop', 50000, 150000, 'unit', 0, duration: 24),
          _tp('Ganti LCD Laptop', 75000, 250000, 'unit', 0, duration: 24),
          _tp('Perbaikan Mainboard Laptop', 150000, 500000, 'unit', 0,
              duration: 72),
        ],
      ),
      _TemplatePaket(
        nama: 'Servis AC',
        icon: Icons.ac_unit_outlined,
        deskripsi: 'Perawatan dan perbaikan AC rumah maupun kantor',
        kategori: 'AC',
        produk: [
          _tp('Pengecekan AC 0.5 - 1 PK', 30000, 100000, 'unit', 0, duration: 2),
          _tp('Pengecekan AC 1.5 - 2 PK', 50000, 150000, 'unit', 0, duration: 3),
          _tp('Isi / Tambah Freon AC', 100000, 350000, 'unit', 0, duration: 3),
          _tp('Perbaikan AC Tidak Dingin', 100000, 400000, 'unit', 0,
              duration: 6),
          _tp('Bongkar Pasang AC', 200000, 600000, 'unit', 0, duration: 8),
          _tp('Instalasi AC Baru', 250000, 750000, 'unit', 0, duration: 8),
        ],
      ),
      _TemplatePaket(
        nama: 'Servis TV & Audio',
        icon: Icons.tv_outlined,
        deskripsi: 'Perbaikan televisi, speaker, dan perangkat audio',
        kategori: 'TV & Audio',
        produk: [
          _tp('Diagnosa TV / Audio', 0, 75000, 'unit', 0, duration: 3),
          _tp('Perbaikan TV Tidak Menyala', 100000, 400000, 'unit', 0,
              duration: 48),
          _tp('Perbaikan Backlight TV LED', 150000, 500000, 'unit', 0,
              duration: 48),
          _tp('Perbaikan Gambar / Suara TV', 100000, 350000, 'unit', 0,
              duration: 48),
          _tp('Perbaikan Speaker Aktif', 75000, 300000, 'unit', 0,
              duration: 48),
          _tp('Perbaikan Amplifier', 100000, 400000, 'unit', 0, duration: 72),
        ],
      ),
      _TemplatePaket(
        nama: 'Servis Kulkas',
        icon: Icons.kitchen_outlined,
        deskripsi: 'Perawatan dan perbaikan kulkas berbagai tipe',
        kategori: 'Kulkas',
        produk: [
          _tp('Diagnosa Kulkas', 0, 100000, 'unit', 0, duration: 3),
          _tp('Perbaikan Kulkas Tidak Dingin', 150000, 500000, 'unit', 0,
              duration: 48),
          _tp('Isi Freon Kulkas', 150000, 400000, 'unit', 0, duration: 6),
          _tp('Ganti Thermostat Kulkas', 100000, 300000, 'unit', 0,
              duration: 24),
          _tp('Perbaikan Kompresor Kulkas', 300000, 1000000, 'unit', 0,
              duration: 72),
        ],
      ),
      _TemplatePaket(
        nama: 'Servis Mesin Pengecekan',
        icon: Icons.handyman_outlined,
        deskripsi: 'Perbaikan mesin pengecekan top load dan front load',
        kategori: 'Mesin Pengecekan',
        produk: [
          _tp('Diagnosa Mesin Pengecekan', 0, 100000, 'unit', 0, duration: 3),
          _tp('Perbaikan Mesin Pengecekan Tidak Berputar', 150000, 500000, 'unit', 0,
              duration: 48),
          _tp('Perbaikan Pembuangan Air', 100000, 350000, 'unit', 0,
              duration: 24),
          _tp('Ganti Dinamo Mesin Pengecekan', 200000, 700000, 'unit', 0,
              duration: 72),
          _tp('Perawatan Mesin Pengecekan', 100000, 300000, 'unit', 0, duration: 24),
        ],
      ),
      _TemplatePaket(
        nama: 'Peralatan Rumah Tangga',
        icon: Icons.home_repair_service_outlined,
        deskripsi: 'Servis elektronik rumah tangga lainnya',
        kategori: 'Elektronik Rumah Tangga',
        produk: [
          _tp('Servis Kipas Angin', 30000, 150000, 'unit', 0, duration: 24),
          _tp('Servis Rice Cooker', 30000, 150000, 'unit', 0, duration: 24),
          _tp('Servis Blender / Mixer', 30000, 175000, 'unit', 0, duration: 24),
          _tp('Servis Dispenser', 50000, 250000, 'unit', 0, duration: 48),
          _tp('Servis Pompa Air', 75000, 350000, 'unit', 0, duration: 48),
        ],
      ),
      _TemplatePaket(
        nama: 'Biaya & Layanan Tambahan',
        icon: Icons.add_task_outlined,
        deskripsi: 'Biaya pemeriksaan, kunjungan, dan layanan tambahan',
        kategori: 'Tambahan',
        produk: [
          _tp('Biaya Pemeriksaan', 0, 50000, 'unit', 0, duration: 0),
          _tp('Biaya Kunjungan Teknisi', 25000, 100000, 'kunjungan', 0,
              duration: 0),
          _tp('Layanan Express / Prioritas', 25000, 100000, 'unit', 0,
              duration: 0),
          _tp('Antar Jemput Perangkat', 10000, 75000, 'trip', 0, duration: 0),
          _tp('Garansi Servis Tambahan', 25000, 150000, 'unit', 0, duration: 0),
        ],
      ),
    ];

    String priceRange(_TemplatePaket t) {
      final prices = t.produk.map((p) => p.sellPrice).where((p) => p > 0);
      if (prices.isEmpty) return 'Harga dapat disesuaikan';
      final min = prices.reduce((a, b) => a < b ? a : b);
      final max = prices.reduce((a, b) => a > b ? a : b);
      if (min == max) return 'Rp${_fmtP(min)}';
      return 'Rp${_fmtP(min)} - Rp${_fmtP(max)}';
    }

    await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.84,
        minChildSize: 0.5,
        maxChildSize: 0.93,
        expand: false,
        builder: (_, scrollCtrl) => Column(
          children: [
            const SizedBox(height: 12),
            Container(
              width: 36,
              height: 4,
              decoration: const BoxDecoration(
                color: Colors.black12,
                borderRadius: BorderRadius.zero,
              ),
            ),
            const SizedBox(height: 16),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Pilih Template Layanan',
                            style: TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.w900,
                                color: Color(0xFF111827))),
                        SizedBox(height: 4),
                        Text(
                            'Pilih paket layanan profesional. Harga dan durasi bisa diubah setelah template ditambahkan.',
                            style: TextStyle(
                                fontSize: 12.5,
                                height: 1.35,
                                color: Color(0xFF64748B))),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const Divider(height: 1, color: Color(0xFFEEEEEE)),
            Expanded(
              child: ListView.builder(
                controller: scrollCtrl,
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                itemCount: templates.length,
                itemBuilder: (_, i) {
                  final t = templates[i];
                  final preview = t.produk.take(3).map((p) => p.name).toList();
                  return GestureDetector(
                    onTap: () async {
                      Navigator.pop(ctx);
                      await _applyTemplate(t);
                    },
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.zero,
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF0F172A)
                                .withValues(alpha: 0.035),
                            blurRadius: 12,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: 48,
                                height: 48,
                                decoration: const BoxDecoration(
                                  color: Color(0xFFEFF6FF),
                                  borderRadius: BorderRadius.zero,
                                ),
                                child: Icon(t.icon,
                                    color: AppColors.primaryBrand, size: 23),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(t.nama,
                                        style: const TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w900,
                                            color: Color(0xFF111827))),
                                    const SizedBox(height: 3),
                                    Text(t.deskripsi,
                                        style: const TextStyle(
                                            fontSize: 12,
                                            height: 1.35,
                                            color: Color(0xFF64748B))),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 6),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF8FAFC),
                                  border: Border.all(
                                      color: const Color(0xFFE2E8F0)),
                                  borderRadius: BorderRadius.zero,
                                ),
                                child: Column(
                                  children: [
                                    Text('${t.produk.length}',
                                        style: const TextStyle(
                                            fontSize: 15,
                                            height: 1,
                                            fontWeight: FontWeight.w900,
                                            color: AppColors.primaryBrand)),
                                    const SizedBox(height: 2),
                                    const Text('layanan',
                                        style: TextStyle(
                                            fontSize: 9,
                                            color: Color(0xFF94A3B8))),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 4),
                              const Icon(Icons.chevron_right_rounded,
                                  color: Color(0xFF94A3B8), size: 20),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 6,
                            runSpacing: 6,
                            children: [
                              for (final name in preview)
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 5),
                                  decoration: const BoxDecoration(
                                    color: Color(0xFFF1F5F9),
                                    borderRadius: BorderRadius.zero,
                                  ),
                                  child: Text(
                                    name,
                                    style: const TextStyle(
                                      fontSize: 10.5,
                                      color: Color(0xFF475569),
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Icon(Icons.sell_outlined,
                                  size: 14, color: Color(0xFF64748B)),
                              const SizedBox(width: 5),
                              Expanded(
                                child: Text(
                                  priceRange(t),
                                  style: const TextStyle(
                                    fontSize: 11.5,
                                    color: Color(0xFF475569),
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              const Text(
                                'Siap pakai',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Color(0xFF059669),
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Product _tp(String name, int buyPrice, int sellPrice, String unit, int stock,
      {int categoryId = 1, int isHardware = 0, int duration = 0}) {
    return Product(
      name: name,
      categoryId: categoryId,
      stock: stock,
      buyPrice: buyPrice,
      sellPrice: sellPrice,
      unit: unit,
      minStock: stock > 0 ? (stock ~/ 4).clamp(1, 20) : 0,
      createdAt: DateTime.now().toIso8601String(),
      isHardware: isHardware,
      durationHours: duration,
    );
  }

  Future<void> _applyTemplate(_TemplatePaket template) async {
    // Tampilkan loading
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        content: Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: Row(
            children: [
              CircularProgressIndicator(strokeWidth: 2),
              SizedBox(width: 16),
              Text('Menambahkan template...'),
            ],
          ),
        ),
      ),
    );

    try {
      // 1. Pastikan kategori sudah terload sebelum menentukan targetCatId
      final categoriesCache = ref.read(categoriesProvider);
      if (categoriesCache.isEmpty) {
        await ref.read(categoriesProvider.notifier).loadCategories();
      }
      final categories = ref.read(categoriesProvider);

      // 2. Cari atau buat kategori berdasarkan nama kategori template
      int targetCatId = 1;
      final existingCategory = categories.firstWhere(
        (c) => c.name?.toLowerCase() == template.kategori.toLowerCase(),
        orElse: () => Category(),
      );

      if (existingCategory.id != null) {
        targetCatId = existingCategory.id!;
      } else {
        targetCatId = await ref
            .read(categoriesProvider.notifier)
            .addCategory(template.kategori);
      }

      // 3. Map produk dengan target category ID yang benar
      final productsToImport = template.produk.map((p) {
        return p.copyWith(
          categoryId: targetCatId,
          createdAt: DateTime.now().toIso8601String(),
        );
      }).toList();

      // 4. Simpan ke Database
      await ref.read(productsProvider.notifier).addProducts(productsToImport);

      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).pop(); // tutup loading

      // 5. Reset filter agar produk langsung tampil
      setState(() {
        _selectedCategoryId = null;
        _query = '';
        _searchCtrl.clear();
      });

      // 6. Paksa refresh provider
      ref.invalidate(productsProvider);
      Future.microtask(
          () => ref.read(productsProvider.notifier).loadProducts());

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              'Template "${template.nama}" berhasil ditambahkan (${productsToImport.length} layanan)'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
    } catch (e) {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Gagal menambahkan template: $e'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
      }
    }
  }

  // ignore: unused_element
  Future<void> _insertTemplateProducts() async {
    final notifier = ref.read(productsProvider.notifier);
    final now = DateTime.now().toIso8601String();
    final templates = <Product>[
      Product(
        name: 'Timah Solder 100g',
        categoryId: 1,
        stock: 10,
        buyPrice: 20000,
        sellPrice: 25000,
        unit: 'roll',
        minStock: 2,
        createdAt: now,
      ),
      Product(
        name: 'Kabel USB Universal',
        categoryId: 1,
        stock: 15,
        buyPrice: 15000,
        sellPrice: 18000,
        unit: 'pcs',
        minStock: 3,
        createdAt: now,
      ),
      Product(
        name: 'Isolasi Listrik',
        categoryId: 1,
        stock: 100,
        buyPrice: 500,
        sellPrice: 1000,
        unit: 'roll',
        minStock: 20,
        createdAt: now,
      ),
    ];

    for (final p in templates) {
      await notifier.addProduct(p);
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Template layanan berhasil ditambahkan.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
    );
  }

  //  Import .xlsx / .csv -

  Future<void> _deleteSelectedProducts() async {
    final count = _selectedProductIds.length;
    final proceed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Text('Hapus Terpilih',
            style: TextStyle(fontWeight: FontWeight.bold)),
        content: Text('Yakin ingin menghapus $count layanan terpilih?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: Colors.black54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.danger,
              foregroundColor: Colors.white,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Hapus',
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );

    if (proceed == true) {
      if (!mounted) return;
      try {
        await ref
            .read(productsProvider.notifier)
            .deleteProducts(_selectedProductIds.toList());
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$count layanan berhasil dihapus.'),
            backgroundColor: Colors.black87,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
        setState(() {
          _isSelectMode = false;
          _selectedProductIds.clear();
        });
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Gagal menghapus layanan: $e'),
            backgroundColor: AppColors.danger,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
      }
    }
  }

  Future<void> _showImportInfo() async {
    final isLandscapeMode =
        MediaQuery.of(context).orientation == Orientation.landscape;

    final proceed = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        backgroundColor: Colors.white,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: isLandscapeMode ? 640 : 400),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: isLandscapeMode
                ? _buildCompactImportRow(ctx)
                : _buildStandardImportColumn(ctx),
          ),
        ),
      ),
    );
    if (proceed == true) {
      _pickAndImportFile();
    }
  }

  Future<void> _downloadImportTemplate() async {
    const headers = [
      'Nama Layanan',
      'Harga Jual',
      'Harga Beli',
      'Stok',
      'Min Stok',
      'Software',
      'Kode Layanan',
      'Barcode',
      'Kategori',
      'Deskripsi',
    ];
    const rows = <List<Object?>>[
      [
        'Ganti LCD HP',
        350000,
        250000,
        0,
        0,
        'unit',
        'HP-LCD-001',
        '',
        'HP & Tablet',
        'Jasa penggantian LCD HP'
      ],
      [
        'Instal Ulang Laptop',
        100000,
        20000,
        0,
        0,
        'unit',
        'LPT-OS-001',
        '',
        'Laptop & Komputer',
        'Instal ulang sistem operasi dan driver'
      ],
      [
        'Pengecekan AC 1 PK',
        100000,
        30000,
        0,
        0,
        'unit',
        'AC-CLN-001',
        '899100000001',
        'AC',
        'Pembersihan AC kapasitas 0.5 sampai 1 PK'
      ],
      [
        'Perbaikan Backlight TV LED',
        500000,
        150000,
        0,
        0,
        'unit',
        'TV-BKL-001',
        '',
        'TV & Audio',
        'Perbaikan atau penggantian backlight TV LED'
      ],
      [
        'Perbaikan Kulkas Tidak Dingin',
        500000,
        150000,
        0,
        0,
        'unit',
        'KLK-DGN-001',
        '899100000002',
        'Kulkas',
        'Diagnosa dan perbaikan sistem pendingin'
      ],
      [
        'Perbaikan Mesin Pengecekan Tidak Berputar',
        500000,
        150000,
        0,
        0,
        'unit',
        'MC-DNM-001',
        '',
        'Mesin Pengecekan',
        'Diagnosa dan perbaikan sistem putaran'
      ],
      [
        'Biaya Kunjungan Teknisi',
        100000,
        25000,
        0,
        0,
        'kunjungan',
        'ADD-VST-001',
        '',
        'Tambahan',
        'Biaya pemeriksaan perangkat di lokasi pelanggan'
      ],
    ];

    try {
      final savedPath = await ExportService.saveCsvToDevice(
        filePrefix: 'template_import_layanan_servis',
        headers: headers,
        rows: rows,
        dialogTitle: 'Download Contoh Import Layanan Servis',
        askLocationFirst: true,
      );
      if (!mounted || savedPath == null) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Template contoh berhasil disimpan.'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Gagal membuat template contoh. Silakan coba lagi.'),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
      ));
    }
  }

  Widget _buildCompactImportRow(BuildContext ctx) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Left column: Icon & Title
        Expanded(
          flex: 2,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  shape: BoxShape.rectangle,
                ),
                child: Icon(Icons.upload_file_rounded,
                    color: Colors.green.shade600, size: 48),
              ),
              const SizedBox(height: 16),
              const Text(
                'Impor Layanan',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: Colors.black87),
              ),
              const SizedBox(height: 8),
              const Text(
                'Unggah inventori Anda\ndengan cepat.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Colors.black45),
              ),
            ],
          ),
        ),
        const SizedBox(width: 32),
        // Right column: Info & Buttons
        Expanded(
          flex: 3,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8F9FA),
                  borderRadius: BorderRadius.zero,
                  border: Border.all(color: const Color(0xFFEEEEEE)),
                ),
                child: const Text(
                  'Format kolom didukung:\n'
                  ' Nama Layanan (wajib), Harga Jual (wajib)\n'
                  ' Harga Beli, Stok, Min Stok, Software, SKU, Barcode\n'
                  ' Kategori, Deskripsi\n\n'
                  'Mendukung file .xlsx dan .csv.\n'
                  'Download template contoh untuk melihat struktur dan dummy data.',
                  style: TextStyle(
                      fontSize: 13, height: 1.5, color: Colors.black87),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('Batal',
                          style: TextStyle(
                              color: Colors.grey, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: OutlinedButton.icon(
                      onPressed: _downloadImportTemplate,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.green.shade700,
                        side: BorderSide(color: Colors.green.shade600),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      icon: const Icon(Icons.download_rounded, size: 18),
                      label: const Text('Download Contoh',
                          style: TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: ElevatedButton.icon(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green.shade600,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      icon: const Icon(Icons.folder_open_rounded, size: 18),
                      label: const Text('Pilih File',
                          style: TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStandardImportColumn(BuildContext ctx) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.green.shade50,
            shape: BoxShape.rectangle,
          ),
          child: Icon(Icons.upload_file_rounded,
              color: Colors.green.shade600, size: 36),
        ),
        const SizedBox(height: 18),
        const Text(
          'Impor Layanan',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: const BoxDecoration(
            color: Color(0xFFF5F5F5),
            borderRadius: BorderRadius.zero,
          ),
          child: const Text(
            'Format kolom yang didukung:\n'
            '- Nama Produk (wajib)\n'
            '- Harga Jual (wajib)\n'
            '- Harga Beli, Stok, Min Stok\n'
            '- Software, SKU, Barcode\n'
            '- Kategori, Deskripsi\n\n'
            'Mendukung file .xlsx dan .csv.\n'
            'Download template contoh untuk melihat struktur dan dummy data.',
            style: TextStyle(fontSize: 13, height: 1.6),
          ),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child:
                    const Text('Batal', style: TextStyle(color: Colors.grey)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _downloadImportTemplate,
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.green.shade700,
                  side: BorderSide(color: Colors.green.shade600),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                ),
                icon: const Icon(Icons.download_rounded, size: 18),
                label: const Text('Contoh',
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () => Navigator.pop(ctx, true),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade600,
                  foregroundColor: Colors.white,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                ),
                icon: const Icon(Icons.folder_open_rounded, size: 18),
                label: const Text('Pilih File',
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Future<void> _pickAndImportFile() async {
    var loadingDialogOpen = false;
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['xlsx', 'xls', 'csv'],
        allowMultiple: false,
      );

      if (result == null || result.files.isEmpty) return;
      final filePath = result.files.single.path;
      if (filePath == null) return;

      if (!mounted) return;

      // Show loading
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(
          child: Card(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 14),
                  Text('Membaca file...'),
                ],
              ),
            ),
          ),
        ),
      );
      loadingDialogOpen = true;

      final importResult = await ImportService.parseFile(filePath);

      if (!mounted) return;
      Navigator.pop(context); // close loading
      loadingDialogOpen = false;

      if (importResult.products.isEmpty) {
        await showKasirInfoDialog(
          context,
          title: 'Gagal Impor',
          message: importResult.errors.isNotEmpty
              ? importResult.errors.join('\n')
              : 'Tidak ada data layanan valid di file tersebut.',
          icon: Icons.error_outline_rounded,
          iconColor: Colors.red,
        );
        return;
      }

      // Confirm dialog
      if (!mounted) return;
      final confirm = await showDialog<bool>(
        context: context,
        builder: (ctx) => Dialog(
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          backgroundColor: Colors.white,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(28, 30, 28, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(
                      color: AppColors.primaryBrand.withValues(alpha: 0.08),
                      shape: BoxShape.rectangle,
                    ),
                    child: const Icon(Icons.inventory_2_rounded,
                        color: AppColors.primaryBrand, size: 34),
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'Konfirmasi Impor',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Ditemukan ${importResult.products.length} layanan siap diimpor.'
                    '${importResult.skippedRows > 0 ? '\n${importResult.skippedRows} baris dilewati.' : ''}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 14, height: 1.5),
                  ),
                  if (importResult.errors.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.orange.shade50,
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Text(
                        ' ${importResult.errors.length} baris bermasalah:\n${importResult.errors.take(3).join('\n')}${importResult.errors.length > 3 ? '\n...' : ''}',
                        style: TextStyle(
                            fontSize: 12, color: Colors.orange.shade800),
                      ),
                    ),
                  ],
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(ctx, false),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFF6B7280),
                            side: const BorderSide(color: Color(0xFFD6DEE8)),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: const Text('Batal',
                              style: TextStyle(fontWeight: FontWeight.w700)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primaryBrand,
                            foregroundColor: Colors.white,
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: const Text('Impor Sekarang',
                              style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      );

      if (confirm != true || !mounted) return;

      // Show loading for DB insert
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(
          child: Card(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 14),
                  Text('Menyimpan layanan...'),
                ],
              ),
            ),
          ),
        ),
      );
      loadingDialogOpen = true;

      await _saveImportedProducts(importResult.products);

      if (!mounted) return;
      Navigator.pop(context); // close loading
      loadingDialogOpen = false;

      ref.invalidate(productsProvider);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(
                ' ${importResult.products.length} layanan berhasil diimpor.'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
    } on PlatformException catch (e) {
      if (!mounted) return;
      if (loadingDialogOpen) {
        Navigator.pop(context);
        loadingDialogOpen = false;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Error: ${e.message}'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
    } catch (e) {
      if (!mounted) return;
      if (loadingDialogOpen) {
        Navigator.pop(context);
        loadingDialogOpen = false;
      }
      debugPrint('import services error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text(
                'Gagal mengimpor data layanan. Pastikan format file sudah benar.'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
    }
  }

  Future<void> _saveImportedProducts(List<ImportedProduct> importedList) async {
    final db = DBHelper.instance;

    // Load existing categories to avoid duplicates
    final existingCats = await db.getCategories();
    final catMap = <String, int>{
      for (final c in existingCats)
        if (c.name != null && c.id != null) c.name!.trim().toLowerCase(): c.id!,
    };
    final defaultCategoryId = await db.resolveProductCategoryId();

    for (final imp in importedList) {
      // Resolve or create category
      int categoryId = defaultCategoryId;
      if (imp.categoryName != null && imp.categoryName!.isNotEmpty) {
        final categoryName = imp.categoryName!.trim();
        final key = categoryName.toLowerCase();
        if (catMap.containsKey(key)) {
          categoryId = catMap[key]!;
        } else {
          final newId = await db.insertCategory(categoryName);
          catMap[key] = newId;
          categoryId = newId;
        }
      }

      final product = Product(
        name: imp.name,
        categoryId: categoryId,
        stock: imp.stock > 0 ? 0 : imp.stock,
        minStock: imp.minStock,
        buyPrice: imp.buyPrice,
        sellPrice: imp.sellPrice,
        unit: imp.unit,
        sku: imp.sku,
        barcode: imp.barcode,
        description: imp.description,
        createdAt: DateTime.now().toIso8601String(),
        hasStockManagement: imp.stock > 0 ? 1 : 0,
      );

      final productId = await db.insertProduct(product);
      if (imp.stock > 0) {
        final now = DateTime.now();
        await db.insertStockLog(StockLog(
          productId: productId,
          type: 'in',
          qty: imp.stock,
          date: now.toIso8601String(),
          stockName: 'Stok Awal',
          entryDate:
              '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}',
        ));
      }
    }
  }

  Widget _searchBar() {
    return Container(
      height: 38,
      decoration: const BoxDecoration(
        color: Color(0xFFF5F5F5),
        borderRadius: BorderRadius.zero,
      ),
      child: TextField(
        controller: _searchCtrl,
        textAlignVertical: TextAlignVertical.center,
        onChanged: (v) => setState(() => _query = v),
        style: const TextStyle(fontSize: 13),
        decoration: InputDecoration(
          isDense: true,
          hintText: 'Cari nama, SKU, atau barcode...',
          hintStyle: const TextStyle(fontSize: 12, color: Colors.grey),
          prefixIcon: const Icon(Icons.search, size: 18, color: Colors.grey),
          prefixIconConstraints:
              const BoxConstraints(minWidth: 36, minHeight: 36),
          suffixIcon: _query.isEmpty
              ? null
              : IconButton(
                  tooltip: 'Hapus pencarian',
                  icon: const Icon(Icons.close_rounded,
                      size: 18, color: Color(0xFF94A3B8)),
                  onPressed: () {
                    _searchCtrl.clear();
                    setState(() => _query = '');
                  },
                ),
          suffixIconConstraints:
              const BoxConstraints(minWidth: 36, minHeight: 36),
          border: InputBorder.none,
          contentPadding: EdgeInsets.zero,
        ),
      ),
    );
  }

  Widget _headerActions() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _iconBtn(Icons.upload_file_rounded, _showImportInfo,
            color: Colors.green.shade600, tooltip: 'Impor'),
        const SizedBox(width: 4),
        _iconBtn(Icons.auto_awesome_motion_rounded, _showTemplatePicker,
            color: Colors.amber.shade700, tooltip: 'Template'),
        const SizedBox(width: 4),
        _iconBtn(Icons.checklist_rtl_rounded, () {
          setState(() {
            _isSelectMode = true;
            _selectedProductIds.clear();
          });
        }, tooltip: 'Pilih Banyak'),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final isWide = isTabletDevice(context) || isLandscape(context);
    final allProducts = ref.watch(productsProvider);
    final allCategories = ref.watch(categoriesProvider);
    final defaultCategoryIds = allCategories
        .where((c) => DBHelper.isDefaultCategoryName(c.name))
        .map((c) => c.id)
        .whereType<int>()
        .toSet();
    final categories = allCategories
        .where((c) => !DBHelper.isDefaultCategoryName(c.name))
        .toList();
    final isAllCategory = _selectedCategoryId == null ||
        defaultCategoryIds.contains(_selectedCategoryId);

    final mainProducts =
        allProducts.where((p) => p.isExtra == 0 && p.isMaterial == 0).toList();

    // Filter by Category
    final catFiltered = isAllCategory
        ? mainProducts
        : mainProducts
            .where((p) => p.categoryId == _selectedCategoryId)
            .toList();

    final qLower = _query.toLowerCase();
    final qScan = _normalizeScanCode(_query);
    final filtered = _query.isEmpty
        ? catFiltered
        : catFiltered
            .where((p) =>
                p.name.toLowerCase().contains(qLower) ||
                (p.sku?.toLowerCase().contains(qLower) ?? false) ||
                (p.barcode?.toLowerCase().contains(qLower) ?? false) ||
                (qScan.isNotEmpty &&
                    (_normalizeScanCode(p.sku ?? '').contains(qScan) ||
                        _normalizeScanCode(p.barcode ?? '').contains(qScan))))
            .toList();

    final products = _sortedProducts(filtered);

    Widget sidebar() {
      return Container(
        width: 260,
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(right: BorderSide(color: Color(0xFFEEEEEE))),
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 20, 16, 12),
                child: Text('KATEGORI',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: Colors.grey,
                        letterSpacing: 1.2)),
              ),
              Column(
                children: [
                  _sidebarItem('Semua Kategori', null, isAllCategory, (id) {
                    setState(() => _selectedCategoryId = id);
                  }),
                  ...categories.map((c) => _sidebarItem(
                          c.name ?? 'Uncategorized',
                          c.id,
                          _selectedCategoryId == c.id, (id) {
                        setState(() => _selectedCategoryId = id);
                      })),
                ],
              ),
              const Divider(height: 1),
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 12),
                child: Text('URUTKAN',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: Colors.grey,
                        letterSpacing: 1.2)),
              ),
              RadioGroup<String>(
                groupValue: _sortMode,
                onChanged: (v) {
                  if (v != null) {
                    setState(() => _sortMode = v);
                  }
                },
                child: Column(
                  children: [
                    ..._sortOptions.map((opt) => RadioListTile<String>(
                          title: Text(opt.title,
                              style: const TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.w700)),
                          subtitle: Text(opt.subtitle,
                              style: const TextStyle(
                                  fontSize: 10.5,
                                  color: Color(0xFF64748B),
                                  height: 1.25)),
                          value: opt.value,
                          dense: true,
                          visualDensity: VisualDensity.compact,
                          activeColor: _kBrand,
                          contentPadding:
                              const EdgeInsets.symmetric(horizontal: 8),
                        )),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: _isSelectMode
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          OutlinedButton.icon(
                            icon: const Icon(Icons.select_all_rounded,
                                color: AppColors.primaryBrand),
                            label: const Text('Semua',
                                style: TextStyle(fontWeight: FontWeight.w600)),
                            onPressed: () {
                              setState(() {
                                final allIds =
                                    products.map((p) => p.id!).toList();
                                final allSelected = allIds.every(
                                    (id) => _selectedProductIds.contains(id));
                                if (allSelected) {
                                  for (final id in allIds) {
                                    _selectedProductIds.remove(id);
                                  }
                                } else {
                                  _selectedProductIds.addAll(allIds);
                                }
                              });
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: AppColors.primaryBrand,
                              side: const BorderSide(
                                  color: AppColors.primaryBrand),
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                          ),
                          const SizedBox(height: 8),
                          ElevatedButton.icon(
                            icon: const Icon(Icons.delete_sweep_rounded,
                                color: Colors.white),
                            label: Text('Hapus (${_selectedProductIds.length})',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold)),
                            onPressed: _selectedProductIds.isEmpty
                                ? null
                                : _deleteSelectedProducts,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.danger,
                              foregroundColor: Colors.white,
                              disabledBackgroundColor: Colors.grey.shade300,
                              disabledForegroundColor: Colors.grey.shade500,
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              elevation: 0,
                            ),
                          ),
                        ],
                      )
                    : _solidBtn('Tambah Layanan', _onAddProduct),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      );
    }

    Widget mainArea() {
      return Column(
        children: [
          if (!isWide)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
              child: Row(
                children: [
                  _InventoryLayoutSwitch(
                    isGridMode: _isGridMode,
                    onChanged: _setLayoutGrid,
                    compact: true,
                  ),
                  const SizedBox(width: 8),
                  Expanded(child: _searchBar()),
                  const SizedBox(width: 8),
                  _iconBtn(Icons.filter_list, _showSortSheet,
                      tooltip: 'Filter / Urutkan'),
                  const SizedBox(width: 8),
                  _iconBtn(const BarcodeIcon(height: 18), _scanAndSearch,
                      tooltip: 'Scan Barcode'),
                ],
              ),
            ),
          const Divider(height: 1),
          // Grid/List
          Expanded(
            child: _isGridMode
                ? (isWide)
                    ? LayoutBuilder(
                        builder: (context, constraints) {
                          final columns =
                              _responsiveWideGridColumns(constraints.maxWidth);
                          return GridView.builder(
                            padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: columns,
                              crossAxisSpacing: 14,
                              mainAxisSpacing: 14,
                              mainAxisExtent: _kWideProductCardExtent,
                            ),
                            itemCount: products.length,
                            itemBuilder: (ctx, i) {
                              final prod = products[i];
                              return _ProductCard(
                                product: prod,
                                isSelectMode: _isSelectMode,
                                isSelected:
                                    _selectedProductIds.contains(prod.id),
                                onSelect: () {
                                  setState(() {
                                    if (_selectedProductIds.contains(prod.id)) {
                                      _selectedProductIds.remove(prod.id);
                                    } else {
                                      _selectedProductIds.add(prod.id!);
                                    }
                                  });
                                },
                                onEdit: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => prod.isExtra == 1
                                          ? ExtraProductFormScreen(
                                              existing: prod)
                                          : ProductFormScreen(existing: prod)),
                                ).then((_) => ref
                                    .read(productsProvider.notifier)
                                    .loadProducts()),
                                onMore: () => _showMoreMenu(context, ref, prod),
                              );
                            },
                          );
                        },
                      )
                    : GridView.builder(
                        padding: const EdgeInsets.fromLTRB(12, 12, 12, 100),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 8,
                          mainAxisSpacing: 8,
                          mainAxisExtent: 240,
                        ),
                        itemCount: products.length,
                        itemBuilder: (ctx, i) {
                          final prod = products[i];
                          return _ProductCard(
                            product: prod,
                            isGrid: true,
                            isSelectMode: _isSelectMode,
                            isSelected: _selectedProductIds.contains(prod.id),
                            onSelect: () {
                              setState(() {
                                if (_selectedProductIds.contains(prod.id)) {
                                  _selectedProductIds.remove(prod.id);
                                } else {
                                  _selectedProductIds.add(prod.id!);
                                }
                              });
                            },
                            onEdit: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => prod.isExtra == 1
                                      ? ExtraProductFormScreen(existing: prod)
                                      : ProductFormScreen(existing: prod)),
                            ).then((_) => ref
                                .read(productsProvider.notifier)
                                .loadProducts()),
                            onMore: () => _confirmDelete(context, ref, prod),
                          );
                        },
                      )
                : LayoutBuilder(
                    builder: (context, constraints) {
                      final columns = constraints.maxWidth >= 1120
                          ? 3
                          : constraints.maxWidth >= 620
                              ? 2
                              : 1;
                      final padding = EdgeInsets.fromLTRB(
                        isWide ? 16 : 10,
                        isWide ? 16 : 10,
                        isWide ? 16 : 10,
                        100,
                      );

                      Widget itemBuilder(BuildContext ctx, int i) {
                        final prod = products[i];
                        return _ProductListTile(
                          product: prod,
                          isSelectMode: _isSelectMode,
                          isSelected: _selectedProductIds.contains(prod.id),
                          onSelect: () {
                            setState(() {
                              if (_selectedProductIds.contains(prod.id)) {
                                _selectedProductIds.remove(prod.id);
                              } else {
                                _selectedProductIds.add(prod.id!);
                              }
                            });
                          },
                          onEdit: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => prod.isExtra == 1
                                    ? ExtraProductFormScreen(existing: prod)
                                    : ProductFormScreen(existing: prod)),
                          ).then((_) => ref
                              .read(productsProvider.notifier)
                              .loadProducts()),
                          onMore: () => _showMoreMenu(context, ref, prod),
                        );
                      }

                      if (columns > 1) {
                        return GridView.builder(
                          padding: padding,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: columns,
                            crossAxisSpacing: 6,
                            mainAxisSpacing: 5,
                            mainAxisExtent: 62,
                          ),
                          itemCount: products.length,
                          itemBuilder: itemBuilder,
                        );
                      }

                      return ListView.separated(
                        padding: padding,
                        itemCount: products.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 4),
                        itemBuilder: itemBuilder,
                      );
                    },
                  ),
          ),
        ],
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(
        context,
        _isSelectMode
            ? 'Terpilih: ${_selectedProductIds.length}'
            : 'Daftar Layanan',
        trailing: _isSelectMode
            ? (isWide
                ? null
                : TextButton(
                    onPressed: () {
                      setState(() {
                        _isSelectMode = false;
                        _selectedProductIds.clear();
                      });
                    },
                    child: const Text(
                      'Batal',
                      style: TextStyle(
                        color: AppColors.danger,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ))
            : (isWide
                ? null
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _redButton('Impor', _showImportInfo),
                      const SizedBox(width: 4),
                      _iconBtn(Icons.checklist_rtl_rounded, () {
                        setState(() {
                          _isSelectMode = true;
                          _selectedProductIds.clear();
                        });
                      }, tooltip: 'Pilih Banyak'),
                    ],
                  )),
        titleWidget: _isSelectMode
            ? (isWide
                ? Row(
                    children: [
                      Text(
                        'Terpilih: ${_selectedProductIds.length}',
                        style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w700,
                            color: Colors.black87),
                      ),
                      const Spacer(),
                      TextButton.icon(
                        icon: const Icon(Icons.select_all_rounded,
                            color: AppColors.primaryBrand, size: 20),
                        label: const Text(
                          'Pilih Semua',
                          style: TextStyle(
                            color: AppColors.primaryBrand,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        onPressed: () {
                          setState(() {
                            final allIds = products.map((p) => p.id!).toList();
                            final allSelected = allIds.every(
                                (id) => _selectedProductIds.contains(id));
                            if (allSelected) {
                              for (final id in allIds) {
                                _selectedProductIds.remove(id);
                              }
                            } else {
                              _selectedProductIds.addAll(allIds);
                            }
                          });
                        },
                      ),
                      const SizedBox(width: 8),
                      TextButton(
                        onPressed: () {
                          setState(() {
                            _isSelectMode = false;
                            _selectedProductIds.clear();
                          });
                        },
                        child: const Text(
                          'Batal',
                          style: TextStyle(
                            color: AppColors.danger,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                    ],
                  )
                : null)
            : (isWide
                ? Row(
                    children: [
                      const Text('Daftar Layanan',
                          style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w700,
                              color: Colors.black87)),
                      const SizedBox(width: 24),
                      _InventoryLayoutSwitch(
                        isGridMode: _isGridMode,
                        onChanged: _setLayoutGrid,
                      ),
                      const SizedBox(width: 8),
                      Expanded(child: _searchBar()),
                      const SizedBox(width: 12),
                      _headerActions(),
                      const SizedBox(width: 16),
                    ],
                  )
                : null),
      ),
      body: isWide
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                sidebar(),
                Expanded(child: mainArea()),
              ],
            )
          : mainArea(),
      bottomNavigationBar: isWide
          ? null
          : (_isSelectMode
              ? _bottomBar(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            icon: const Icon(Icons.select_all_rounded,
                                color: AppColors.primaryBrand),
                            label: const Text('Semua',
                                style: TextStyle(fontWeight: FontWeight.w600)),
                            onPressed: () {
                              setState(() {
                                final allIds =
                                    products.map((p) => p.id!).toList();
                                final allSelected = allIds.every(
                                    (id) => _selectedProductIds.contains(id));
                                if (allSelected) {
                                  for (final id in allIds) {
                                    _selectedProductIds.remove(id);
                                  }
                                } else {
                                  _selectedProductIds.addAll(allIds);
                                }
                              });
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: AppColors.primaryBrand,
                              side: const BorderSide(
                                  color: AppColors.primaryBrand),
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton.icon(
                            icon: const Icon(Icons.delete_sweep_rounded,
                                color: Colors.white),
                            label: Text('Hapus (${_selectedProductIds.length})',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold)),
                            onPressed: _selectedProductIds.isEmpty
                                ? null
                                : _deleteSelectedProducts,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.danger,
                              foregroundColor: Colors.white,
                              disabledBackgroundColor: Colors.grey.shade300,
                              disabledForegroundColor: Colors.grey.shade500,
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              elevation: 0,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                )
              : _bottomBar(
                  children: [
                    _outlineBtn(
                        'Gunakan Template Layanan', _showTemplatePicker),
                    const SizedBox(height: 10),
                    _solidBtn('Tambah Layanan', _onAddProduct),
                  ],
                )),
    );
  }

  void _onAddProduct() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ProductFormScreen()),
    );
  }

  // _showAddTypePicker is now unused as requested by user

  void _showMoreMenu(BuildContext context, WidgetRef ref, Product p) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (_) => SafeArea(
        child: Padding(
          padding:
              const EdgeInsets.only(top: 16, bottom: 20, left: 20, right: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Opsi Layanan',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.close_rounded,
                        color: Colors.black45, size: 22),
                  )
                ],
              ),
              const SizedBox(height: 16),
              InkWell(
                borderRadius: BorderRadius.zero,
                onTap: () {
                  Navigator.pop(context);
                  _showDownloadBarcodeDialog(context, p);
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  decoration: BoxDecoration(
                    color: AppColors.primaryBrand.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.download_rounded,
                          color: AppColors.primaryBrand, size: 20),
                      SizedBox(width: 12),
                      Text(
                        'Download Barcode',
                        style: TextStyle(
                            color: AppColors.primaryBrand,
                            fontWeight: FontWeight.bold,
                            fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              InkWell(
                borderRadius: BorderRadius.zero,
                onTap: () {
                  Navigator.pop(context);
                  _confirmDelete(context, ref, p);
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  decoration: const BoxDecoration(
                    color: AppColors.dangerBg,
                    borderRadius: BorderRadius.zero,
                  ),
                  child: const Row(
                    children: [
                      Icon(AppIcons.recycleBin,
                          color: AppColors.danger, size: 20),
                      SizedBox(width: 12),
                      Text(
                        'Hapus Layanan',
                        style: TextStyle(
                            color: AppColors.danger,
                            fontWeight: FontWeight.bold,
                            fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context, WidgetRef ref, Product p) {
    showKasirConfirmDialog(
      context,
      title: 'Hapus Layanan?',
      message: '"${p.name}" akan dihapus permanen dari sistem.',
      confirmLabel: 'Ya, Hapus',
      icon: AppIcons.recycleBin,
    ).then((confirmed) {
      if (confirmed == true) {
        ref.read(productsProvider.notifier).deleteProduct(p.id!);
      }
    });
  }

  Future<void> _showDownloadBarcodeDialog(
      BuildContext context, Product p) async {
    final isMaterialItem = p.isMaterial == 1;
    final itemType = isMaterialItem ? 'bahan baku' : 'layanan';
    final itemTypeTitle = isMaterialItem ? 'Bahan Baku' : 'Layanan';
    final effectiveBarcode = _resolvedBarcodeForProduct(p);
    if (effectiveBarcode.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(
            '$itemTypeTitle belum memiliki ID barcode. Simpan $itemType dulu.'),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
      return;
    }

    final wasGenerated = (p.barcode ?? '').trim().isEmpty;
    if (wasGenerated && p.id != null) {
      await ref
          .read(productsProvider.notifier)
          .updateProduct(p.copyWith(barcode: effectiveBarcode));
      if (!mounted) return;
    }

    final effectiveProduct = p.copyWith(barcode: effectiveBarcode);
    final sizeOptions = [
      {
        'label': 'Kecil (200x90)',
        'w': 200.0,
        'h': 90.0,
        'thermalH': 48,
        'thermalW': 2,
      },
      {
        'label': 'Sedang (280x120)',
        'w': 280.0,
        'h': 120.0,
        'thermalH': 72,
        'thermalW': 2,
      },
      {
        'label': 'Besar (360x160)',
        'w': 360.0,
        'h': 160.0,
        'thermalH': 96,
        'thermalW': 3,
      },
    ];
    int selectedSize = 1;
    bool isDownloading = false;

    if (!context.mounted) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) {
          final sw = sizeOptions[selectedSize]['w'] as double;
          final sh = sizeOptions[selectedSize]['h'] as double;
          return Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.zero),
            ),
            padding: EdgeInsets.fromLTRB(
                20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 28),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.zero,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text('Download Barcode',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87)),
                  const SizedBox(height: 6),
                  Text(
                    effectiveProduct.name,
                    style: const TextStyle(fontSize: 13, color: Colors.black54),
                  ),
                  if (wasGenerated) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 7),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEFF8FF),
                        border: Border.all(color: const Color(0xFF93C5FD)),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.auto_awesome_rounded,
                              color: Color(0xFF2563EB), size: 15),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Barcode dibuat otomatis: $effectiveBarcode',
                              style: const TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF1D4ED8),
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                  Center(
                    child: RepaintBoundary(
                      key: _barcodeDownloadPreviewKey,
                      child: Container(
                        width: sw,
                        padding: const EdgeInsets.symmetric(
                            vertical: 12, horizontal: 10),
                        color: Colors.white,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              effectiveProduct.name,
                              style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87),
                              textAlign: TextAlign.center,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 8),
                            import_barcode_widget.BarcodeWidget(
                              barcode: import_barcode_widget.Barcode.code128(),
                              data: effectiveBarcode,
                              height: sh * 0.6,
                              width: sw * 0.88,
                              drawText: false,
                              errorBuilder: (_, __) => const Text(
                                'Barcode Invalid',
                                style:
                                    TextStyle(color: Colors.red, fontSize: 10),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              effectiveBarcode,
                              style: const TextStyle(
                                  fontSize: 10,
                                  letterSpacing: 2.5,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black87),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text('Ukuran Barcode',
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Colors.black54)),
                  const SizedBox(height: 8),
                  Row(
                    children: List.generate(sizeOptions.length, (i) {
                      final isSelected = selectedSize == i;
                      return Expanded(
                        child: GestureDetector(
                          onTap: () => setModalState(() => selectedSize = i),
                          child: Container(
                            margin: EdgeInsets.only(
                                right: i < sizeOptions.length - 1 ? 8 : 0),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? _kBrand.withValues(alpha: 0.1)
                                  : Colors.transparent,
                              border: Border.all(
                                  color: isSelected
                                      ? _kBrand
                                      : Colors.grey.shade300),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Text(
                              sizeOptions[i]['label'] as String,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: isSelected
                                      ? FontWeight.bold
                                      : FontWeight.normal,
                                  color: isSelected ? _kBrand : Colors.black87),
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton.icon(
                      icon: isDownloading
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Icon(Icons.download_rounded, size: 18),
                      label: Text(
                        isDownloading
                            ? 'Menyiapkan File...'
                            : 'Download Gambar Barcode',
                        style: const TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                      onPressed: isDownloading
                          ? null
                          : () async {
                              setModalState(() => isDownloading = true);
                              final saved = await _downloadBarcodeImage(
                                effectiveProduct.copyWith(
                                    barcode: effectiveBarcode),
                              );
                              if (!ctx.mounted) return;
                              if (saved) Navigator.pop(ctx);
                              setModalState(() => isDownloading = false);
                            },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Future<bool> _downloadBarcodeImage(Product p) async {
    try {
      await Future.delayed(const Duration(milliseconds: 80));
      final boundary = _barcodeDownloadPreviewKey.currentContext
          ?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Gagal menangkap gambar barcode. Coba buka lagi.'),
            backgroundColor: AppColors.danger,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ));
        }
        return false;
      }

      final image = await boundary.toImage(pixelRatio: 3.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) throw Exception('Gagal mengekspor gambar.');
      final pngBytes = byteData.buffer.asUint8List();
      final safeName =
          p.name.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_').toLowerCase();
      final fileName = 'barcode_$safeName.png';

      final tempDir = await getTemporaryDirectory();
      final tempFile = File('${tempDir.path}/$fileName');
      await tempFile.writeAsBytes(pngBytes);

      final outputPath = await FilePicker.platform.saveFile(
        dialogTitle: 'Simpan Barcode',
        fileName: fileName,
        type: FileType.image,
        bytes: _isMobilePlatform ? pngBytes : null,
      );

      if (outputPath != null && !_isMobilePlatform) {
        await tempFile.copy(outputPath);
      }

      if (!mounted || outputPath == null) return false;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Barcode disimpan ke: $outputPath',
            maxLines: 2, overflow: TextOverflow.ellipsis),
        backgroundColor: Colors.green.shade700,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
      return true;
    } catch (e) {
      if (!mounted) return false;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Gagal menyimpan barcode: ${e.toString()}'),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
      return false;
    }
  }

  // ignore: unused_element
  void _showCetakLabelDialog(BuildContext context, Product p) {
    int quantity = 1;
    int paperSizeMm = 58;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        final hasBarcode = p.barcode != null && p.barcode!.trim().isNotEmpty;
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            return Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.zero),
              ),
              padding: EdgeInsets.fromLTRB(
                  20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 24),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.zero,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text('Cetak Label Barcode',
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87)),
                    const SizedBox(height: 8),
                    Text('Cetak label untuk layanan "${p.name}".',
                        style: const TextStyle(
                            fontSize: 13, color: Colors.black54)),
                    const SizedBox(height: 20),
                    Center(
                      child: Consumer(builder: (context, ref, child) {
                        final labelSettings = ref.watch(labelSettingsProvider);
                        return LabelPreviewWidget(
                          settings:
                              labelSettings.copyWith(paperSizeMm: paperSizeMm),
                          sampleProduct: p,
                        );
                      }),
                    ),
                    if (!hasBarcode) ...[
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.orange.shade50,
                          border: Border.all(color: Colors.orange.shade200),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.warning_amber_rounded,
                                color: Colors.orange.shade800, size: 20),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Produk ini belum memiliki nomor barcode.',
                                    style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.orange,
                                        fontWeight: FontWeight.w600),
                                  ),
                                  const SizedBox(height: 4),
                                  InkWell(
                                    onTap: () {
                                      Navigator.pop(ctx);
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (_) => p.isExtra == 1
                                                ? ExtraProductFormScreen(
                                                    existing: p)
                                                : ProductFormScreen(
                                                    existing: p)),
                                      ).then((_) => ref
                                          .read(productsProvider.notifier)
                                          .loadProducts());
                                    },
                                    child: const Text(
                                      'Klik di sini untuk mengisi barcode ',
                                      style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.orange,
                                          fontWeight: FontWeight.w800,
                                          decoration: TextDecoration.underline),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),
                    const Text('Jumlah Cetak',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Colors.black54)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.remove_circle_outline,
                              color: _kBrand),
                          onPressed: () {
                            if (quantity > 1) {
                              setModalState(() => quantity--);
                            }
                          },
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 8),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey.shade300),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: Text('$quantity',
                              style: const TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold)),
                        ),
                        IconButton(
                          icon: const Icon(Icons.add_circle_outline,
                              color: _kBrand),
                          onPressed: () {
                            if (quantity < 100) {
                              setModalState(() => quantity++);
                            }
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    const Text('Ukuran Kertas',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Colors.black54)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () => setModalState(() => paperSizeMm = 58),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                color: paperSizeMm == 58
                                    ? _kBrand.withValues(alpha: 0.1)
                                    : Colors.transparent,
                                border: Border.all(
                                    color: paperSizeMm == 58
                                        ? _kBrand
                                        : Colors.grey.shade300),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: Center(
                                child: Text(
                                  '58mm',
                                  style: TextStyle(
                                    fontWeight: paperSizeMm == 58
                                        ? FontWeight.bold
                                        : FontWeight.normal,
                                    color: paperSizeMm == 58
                                        ? _kBrand
                                        : Colors.black87,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: InkWell(
                            onTap: () => setModalState(() => paperSizeMm = 80),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                color: paperSizeMm == 80
                                    ? _kBrand.withValues(alpha: 0.1)
                                    : Colors.transparent,
                                border: Border.all(
                                    color: paperSizeMm == 80
                                        ? _kBrand
                                        : Colors.grey.shade300),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: Center(
                                child: Text(
                                  '80mm',
                                  style: TextStyle(
                                    fontWeight: paperSizeMm == 80
                                        ? FontWeight.bold
                                        : FontWeight.normal,
                                    color: paperSizeMm == 80
                                        ? _kBrand
                                        : Colors.black87,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: !hasBarcode
                            ? null
                            : () async {
                                Navigator.pop(ctx);
                                _executePrint(p, quantity, paperSizeMm);
                              },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: hasBarcode ? _kBrand : Colors.grey,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                        ),
                        child: Text(
                            !hasBarcode ? 'Barcode Belum Ada' : 'Mulai Cetak',
                            style: const TextStyle(
                                fontSize: 15, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _executePrint(Product p, int quantity, int paperSizeMm) async {
    try {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(
          child: Card(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 14),
                  Text('Menyiapkan printer...'),
                ],
              ),
            ),
          ),
        ),
      );

      await LabelPrintService.printLabels(p, quantity, paperSizeMm);

      if (!mounted) return;
      Navigator.pop(context); // close dialog

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(' Berhasil mencetak label.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      Navigator.pop(context); // close dialog
      showKasirInfoDialog(
        context,
        title: 'Gagal Cetak',
        message: e.toString(),
        icon: Icons.error_outline_rounded,
        iconColor: Colors.red,
      );
    }
  }
}

class _InventoryLayoutSwitch extends StatelessWidget {
  final bool isGridMode;
  final ValueChanged<bool> onChanged;
  final bool compact;

  const _InventoryLayoutSwitch({
    required this.isGridMode,
    required this.onChanged,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final size = compact ? 36.0 : 38.0;
    final nextIsGrid = !isGridMode;
    final icon =
        isGridMode ? Icons.table_rows_rounded : Icons.grid_view_rounded;
    final tooltip =
        isGridMode ? 'Ubah ke tampilan list' : 'Ubah ke tampilan grid';

    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: () => onChanged(nextIsGrid),
        borderRadius: BorderRadius.zero,
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: _kBrand,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFD8E5E4)),
          ),
          child: Icon(
            icon,
            size: compact ? 17 : 18,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}

class _ProductListTile extends ConsumerWidget {
  final Product product;
  final VoidCallback? onEdit;
  final VoidCallback? onMore;
  final bool isSelectMode;
  final bool isSelected;
  final VoidCallback? onSelect;

  const _ProductListTile({
    required this.product,
    this.onEdit,
    this.onMore,
    this.isSelectMode = false,
    this.isSelected = false,
    this.onSelect,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = product;
    final hasImage = p.imagePath != null && File(p.imagePath!).existsSync();
    final unit = p.unit.trim().isEmpty ? 'unit' : p.unit.trim();
    final stockText = p.hasStockManagement == 1
        ? 'Stok: ${p.stock} $unit'
        : 'Durasi: ${_durationLabel(p.durationHours)}';

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 360;
        final thumbSize = compact ? 32.0 : 34.0;
        final actionSize = compact ? 28.0 : 30.0;

        return Container(
          padding: EdgeInsets.symmetric(
            horizontal: compact ? 8 : 9,
            vertical: compact ? 4 : 5,
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Row(
            children: [
              if (isSelectMode) ...[
                Checkbox(
                  value: isSelected,
                  activeColor: AppColors.primaryBrand,
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  visualDensity: VisualDensity.compact,
                  onChanged: (_) => onSelect?.call(),
                ),
                const SizedBox(width: 2),
              ],
              Container(
                width: thumbSize,
                height: thumbSize,
                color: const Color(0xFFF1F5F9),
                child: hasImage
                    ? Image.file(File(p.imagePath!), fit: BoxFit.cover)
                    : const Icon(
                        Icons.inventory_2_outlined,
                        size: 17,
                        color: Color(0xFF94A3B8),
                      ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            p.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: compact ? 12.5 : 13,
                              fontWeight: FontWeight.w800,
                              color: const Color(0xFF111827),
                              height: 1.12,
                            ),
                          ),
                        ),
                        if (p.isMaterial == 1) ...[
                          const SizedBox(width: 6),
                          _typeBadge('Bahan Baku'),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Text(
                          p.isMaterial == 1
                              ? 'Rp${_fmtP(p.buyPrice)}'
                              : 'Rp${_fmtP(p.sellPrice)}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: compact ? 12.5 : 13,
                            fontWeight: FontWeight.w900,
                            color: _kGreen,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Expanded(
                          child: Text(
                            '/ $unit  |  $stockText',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 10.5,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w600,
                              height: 1.15,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              if (onEdit != null)
                InkWell(
                  onTap: onEdit,
                  borderRadius: BorderRadius.zero,
                  child: Container(
                    height: actionSize,
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    color: _kBrand,
                    child: const Text(
                      'Ubah',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              if (onEdit != null && onMore != null) const SizedBox(width: 4),
              if (onMore != null)
                InkWell(
                  onTap: onMore,
                  borderRadius: BorderRadius.zero,
                  child: SizedBox(
                    width: actionSize,
                    height: actionSize,
                    child: const Icon(
                      Icons.more_vert_rounded,
                      size: 17,
                      color: Color(0xFF94A3B8),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

//  Kartu produk (dipakai di Daftar Produk & Gudang)
class _ProductCard extends ConsumerWidget {
  final Product product;
  final VoidCallback? onEdit;
  final VoidCallback? onMore;
  final bool isGrid;
  final bool isSelectMode;
  final bool isSelected;
  final VoidCallback? onSelect;

  const _ProductCard({
    required this.product,
    this.onEdit,
    this.onMore,
    this.isGrid = false,
    this.isSelectMode = false,
    this.isSelected = false,
    this.onSelect,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = product;
    final hasImage = p.imagePath != null && File(p.imagePath!).existsSync();

    final cats = ref.watch(categoriesProvider);
    final categoryName = cats
            .firstWhere((c) => c.id == p.categoryId,
                orElse: () => Category(name: 'Lainnya'))
            .name ??
        'Lainnya';
    final stockText = p.hasStockManagement == 1
        ? '${p.stock} ${p.unit.isNotEmpty ? p.unit : 'unit'}'
        : '${p.stock}';
    final primaryMetaLabel = p.hasStockManagement == 1 ? 'Stok' : 'Durasi';
    final primaryMetaValue =
        p.hasStockManagement == 1 ? stockText : _durationLabel(p.durationHours);

    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: isGrid ? 10 : 16, vertical: isGrid ? 10 : 8),
      decoration: BoxDecoration(
        color: _kInventoryCardSurface,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: _kInventoryCardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (isSelectMode) ...[
                Checkbox(
                  value: isSelected,
                  activeColor: AppColors.primaryBrand,
                  onChanged: (_) => onSelect?.call(),
                ),
                const SizedBox(width: 4),
              ],
              Container(
                width: isGrid ? 48 : 60,
                height: isGrid ? 48 : 60,
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.zero,
                  border: Border.all(color: _kInventoryMediaBorder),
                ),
                child: hasImage
                    ? Image.file(File(p.imagePath!), fit: BoxFit.cover)
                    : const Icon(Icons.inventory_2_outlined,
                        size: 20, color: Color(0xFFCBD5E1)),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height:
                          34, // Fixed height for 2 lines to ensure alignment
                      child: Text(
                        p.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: const Color(0xFF1E293B),
                            height: 1.25),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      p.unit.isNotEmpty ? p.unit : 'unit',
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                          color: const Color(0xFF94A3B8)),
                    ),
                    if (p.isMaterial == 1) ...[
                      const SizedBox(height: 4),
                      _typeBadge('Bahan Baku'),
                    ],
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Price Section
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.isMaterial == 1
                          ? 'Rp${_fmtP(p.buyPrice)}'
                          : 'Rp${_fmtP(p.sellPrice)}',
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          color: _kBrand,
                          letterSpacing: -0.5),
                    ),
                    Text(
                      p.isMaterial == 1
                          ? 'Harga beli / ${p.unit.isNotEmpty ? p.unit : 'unit'}'
                          : 'Modal: Rp${_fmtP(p.buyPrice)}',
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                          color: const Color(0xFF94A3B8)),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Meta Section
          _metaRowGrid(
              primaryMetaLabel, primaryMetaValue, 'Kategori', categoryName),
          const SizedBox(height: 14),
          if (!isSelectMode && (onEdit != null || onMore != null))
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: onEdit,
                    child: Container(
                      height: 38,
                      decoration: const BoxDecoration(
                        color: _kBrand,
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Center(
                        child: Text(
                          'Ubah',
                          style: GoogleFonts.plusJakartaSans(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: onMore,
                  child: Container(
                    height: 38,
                    width: 38,
                    decoration: const BoxDecoration(
                      color: AppColors.dangerBg,
                      borderRadius: BorderRadius.zero,
                    ),
                    child: const Icon(AppIcons.recycleBin,
                        size: 18, color: AppColors.danger),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}

//  Shared UI Helpers for Cards
Widget _mi(String k, String v, {Color? valColor}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        k.toUpperCase(),
        style: GoogleFonts.plusJakartaSans(
            fontSize: 9,
            fontWeight: FontWeight.w800,
            color: const Color(0xFF94A3B8),
            letterSpacing: 0.5),
      ),
      Text(
        v,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: GoogleFonts.plusJakartaSans(
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: valColor ?? const Color(0xFF334155)),
      ),
    ],
  );
}

Widget _typeBadge(String label) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
    decoration: BoxDecoration(
      color: const Color(0xFFFFF7ED),
      border: Border.all(color: const Color(0xFFFED7AA)),
      borderRadius: BorderRadius.zero,
    ),
    child: Text(
      label,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: GoogleFonts.plusJakartaSans(
        fontSize: 9,
        fontWeight: FontWeight.w800,
        color: const Color(0xFF9A3412),
      ),
    ),
  );
}

String _durationLabel(int hours) {
  if (hours <= 0) return '-';
  if (hours < 24) return '$hours jam';
  final days = hours ~/ 24;
  final remain = hours % 24;
  if (remain == 0) return '$days hari';
  return '$days hari $remain jam';
}

Widget _metaRowGrid(String k1, String v1, String k2, String v2,
    {Color? v1Color}) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 1),
    child: Row(
      children: [
        Expanded(child: _mi(k1, v1, valColor: v1Color)),
        Expanded(child: _mi(k2, v2)),
      ],
    ),
  );
}

//
//  GUDANG SCREEN  (Image 4)
//
class BahanBakuScreen extends ConsumerStatefulWidget {
  const BahanBakuScreen({super.key});

  @override
  ConsumerState<BahanBakuScreen> createState() => _BahanBakuScreenState();
}

class _BahanBakuScreenState extends ConsumerState<BahanBakuScreen> {
  String _query = '';

  void _addMaterial() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const ProductFormScreen(forceMaterial: true),
      ),
    );
  }

  void _editMaterial(Product product) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProductFormScreen(
          existing: product,
          forceMaterial: true,
        ),
      ),
    );
  }

  void _deleteMaterial(Product product) {
    showKasirConfirmDialog(
      context,
      title: 'Hapus Bahan Baku?',
      message:
          '"${product.name}" akan dihapus dari inventori dan resep layanan yang memakai bahan ini.',
      confirmLabel: 'Ya, Hapus',
      icon: AppIcons.recycleBin,
    ).then((confirmed) {
      if (confirmed == true && product.id != null) {
        ref.read(productsProvider.notifier).deleteProduct(product.id!);
      }
    });
  }

  Widget _searchBar() {
    return Container(
      height: 40,
      decoration: const BoxDecoration(
        color: Color(0xFFF5F5F5),
        borderRadius: BorderRadius.zero,
      ),
      child: TextField(
        onChanged: (v) => setState(() => _query = v),
        style: const TextStyle(fontSize: 13),
        decoration: const InputDecoration(
          isDense: true,
          hintText: 'Cari bahan baku...',
          hintStyle: TextStyle(fontSize: 12, color: Colors.grey),
          prefixIcon: Icon(Icons.search, size: 18, color: Colors.grey),
          prefixIconConstraints: BoxConstraints(minWidth: 36, minHeight: 36),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(vertical: 11),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isWide = isTabletDevice(context) || isLandscape(context);
    final query = _query.trim().toLowerCase();
    final all = ref
        .watch(productsProvider)
        .where((p) => p.hasStockManagement == 1)
        .toList();
    final materials = all.where((p) {
      if (p.isMaterial != 1) return false;
      if (query.isEmpty) return true;
      return p.name.toLowerCase().contains(query) ||
          (p.sku?.toLowerCase().contains(query) ?? false) ||
          (p.barcode?.toLowerCase().contains(query) ?? false);
    }).toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(
        context,
        'Bahan Baku',
        titleWidget: isWide
            ? Row(
                children: [
                  const Text(
                    'Bahan Baku',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(width: 24),
                  Expanded(child: _searchBar()),
                  const SizedBox(width: 16),
                ],
              )
            : null,
      ),
      body: Column(
        children: [
          if (!isWide)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
              child: _searchBar(),
            ),
          const Divider(height: 1),
          Expanded(
            child: materials.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 28),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 330),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.science_outlined,
                                size: 54, color: Colors.black26),
                            const SizedBox(height: 12),
                            const Text(
                              'Bahan Baku Belum Ada',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              query.isEmpty
                                  ? 'Bahan baku adalah stok yang dibeli dari supplier, seperti sparepart, kabel, konektor, atau bahan teknisi.'
                                  : 'Tidak ada bahan baku yang cocok.',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  fontSize: 13,
                                  color: Colors.black45,
                                  height: 1.4),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                : GridView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: isWide
                          ? _responsiveWideGridColumns(
                              MediaQuery.sizeOf(context).width - 260,
                            )
                          : 2,
                      crossAxisSpacing: isWide ? 14 : 8,
                      mainAxisSpacing: isWide ? 14 : 8,
                      mainAxisExtent: isWide ? 268 : 282,
                    ),
                    itemCount: materials.length,
                    itemBuilder: (context, index) {
                      final item = materials[index];
                      return _ProductCard(
                        product: item,
                        isGrid: true,
                        onEdit: () => _editMaterial(item),
                        onMore: () => _deleteMaterial(item),
                      );
                    },
                  ),
          ),
        ],
      ),
      bottomNavigationBar: _bottomBar(
        children: [
          _solidBtn('Tambah Bahan Baku', _addMaterial),
        ],
      ),
    );
  }
}

class GudangScreen extends ConsumerStatefulWidget {
  const GudangScreen({super.key});

  @override
  ConsumerState<GudangScreen> createState() => _GudangScreenState();
}

class _GudangScreenState extends ConsumerState<GudangScreen> {
  String _query = '';
  bool _lowStockOnly = false;
  bool _isGridMode = true;

  @override
  void initState() {
    super.initState();
    _loadWarehouseLayoutPreference();
  }

  Future<void> _loadWarehouseLayoutPreference() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _isGridMode = prefs.getBool(_warehouseLayoutGridPrefsKey) ?? true;
    });
  }

  void _setWarehouseLayoutGrid(bool isGrid) {
    if (_isGridMode == isGrid) return;
    setState(() => _isGridMode = isGrid);
    SharedPreferences.getInstance().then(
      (prefs) => prefs.setBool(_warehouseLayoutGridPrefsKey, isGrid),
    );
  }

  Future<void> _exportGudang(List<Product> products) async {
    if (products.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Belum ada data gudang untuk diekspor.'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
      return;
    }

    final rows = products
        .map(
          (p) => <Object?>[
            p.id,
            p.name,
            p.isMaterial == 1 ? 'Bahan Baku' : 'Produk Jual',
            p.stock,
            p.minStock,
            p.buyPrice,
            p.sellPrice,
            p.unit,
            p.createdAt ?? '',
          ],
        )
        .toList();

    await ExportService.exportAndShareCsv(
      filePrefix: 'gudang_produk',
      headers: const [
        'ID',
        'Nama Produk',
        'Tipe Item',
        'Stok',
        'Min Stok',
        'Harga Beli',
        'Harga Jual',
        'Software',
        'Tanggal Input',
      ],
      rows: rows,
      subject: 'Ekspor Data Gudang',
      message: 'Ekspor data gudang dari Juragan Servis.',
    );
  }

  Future<void> _showStockDetail(Product product) async {
    if (product.id == null) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DetailStokScreen(product: product),
      ),
    );
    // Refresh list after returning
    if (mounted) setState(() {});
  }

  Widget _searchBar() {
    return Container(
      height: 44,
      decoration: const BoxDecoration(
        color: Color(0xFFF5F5F5),
        borderRadius: BorderRadius.zero,
      ),
      child: TextField(
        textAlignVertical: TextAlignVertical.center,
        onChanged: (v) => setState(() => _query = v),
        style: const TextStyle(fontSize: 14),
        decoration: const InputDecoration(
          isDense: true,
          hintText: 'Cari nama layanan...',
          hintStyle: TextStyle(fontSize: 13, color: Colors.grey),
          prefixIcon: Icon(Icons.search, size: 20, color: Colors.grey),
          prefixIconConstraints: BoxConstraints(minWidth: 40, minHeight: 40),
          border: InputBorder.none,
          contentPadding: EdgeInsets.zero,
        ),
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.05),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: color.withValues(alpha: 0.1)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              shape: BoxShape.rectangle,
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        fontSize: 11,
                        color: Colors.black54,
                        fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(value,
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: color)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _stockManagementInfoBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: const BoxDecoration(
        color: Color(0xFFFFF7E8),
        border: Border(
          bottom: BorderSide(color: Color(0xFFFDE7C6)),
        ),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline_rounded, size: 18, color: Color(0xFFD97706)),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Informasi Gudang hanya tersedia untuk produk dengan manajemen stok aktif.',
              style: TextStyle(
                fontSize: 13,
                height: 1.35,
                fontWeight: FontWeight.w600,
                color: Color(0xFF4B5563),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isWide = isTabletDevice(context) || isLandscape(context);
    final all = ref
        .watch(productsProvider)
        .where((p) => p.hasStockManagement == 1 || p.isMaterial == 1)
        .toList();

    // Stats calculation
    final int totalItems = all.length;
    final int materialCount = all.where((p) => p.isMaterial == 1).length;
    final double totalValue =
        all.fold(0.0, (sum, p) => sum + (p.buyPrice * p.stock));
    final int lowStockCount = all.where((p) => p.stock <= p.minStock).length;

    final qLower2 = _query.toLowerCase();
    final filtered = all.where((p) {
      final nameLower = p.name.toLowerCase();
      final skuLower = p.sku?.toLowerCase() ?? '';
      final barcodeLower = p.barcode?.toLowerCase() ?? '';
      return nameLower.contains(qLower2) ||
          skuLower.contains(qLower2) ||
          barcodeLower.contains(qLower2);
    }).toList();

    final products = _lowStockOnly
        ? filtered.where((p) => p.stock <= p.minStock).toList()
        : filtered;

    Widget sidebar() {
      return Container(
        width: 260,
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(right: BorderSide(color: Color(0xFFEEEEEE))),
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Statistics in Sidebar
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Column(
                  children: [
                    _statCard('Total Produk', '$totalItems',
                        Icons.inventory_2_outlined, const Color(0xFF334155)),
                    const SizedBox(height: 8),
                    _statCard('Bahan Baku', '$materialCount',
                        Icons.science_outlined, const Color(0xFF9A3412)),
                    const SizedBox(height: 8),
                    _statCard('Nilai Modal', 'Rp${_fmtP(totalValue.toInt())}',
                        Icons.account_balance_wallet_outlined, _kBrand),
                    const SizedBox(height: 8),
                    _statCard('Stok Rendah', '$lowStockCount',
                        Icons.warning_amber_rounded, const Color(0xFFE11D48)),
                  ],
                ),
              ),
              const Divider(height: 1),
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 20, 16, 12),
                child: Text('FILTER STOK',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: Colors.grey,
                        letterSpacing: 1.2)),
              ),
              SwitchListTile(
                title: const Text('Hanya Stok Rendah',
                    style:
                        TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                subtitle: const Text('Tampilkan produk yang menipis',
                    style: TextStyle(fontSize: 11)),
                value: _lowStockOnly,
                onChanged: (v) => setState(() => _lowStockOnly = v),
                activeThumbColor: _kBrand,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16),
              ),
              const SizedBox(height: 24),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.zero,
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Tips Gudang',
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87)),
                      SizedBox(height: 6),
                      Text(
                          'Gunakan fitur ekspor untuk melakukan stock opname manual secara berkala.',
                          style: TextStyle(
                              fontSize: 11,
                              color: Colors.black54,
                              height: 1.4)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    Widget mainArea() {
      return Column(
        children: [
          _stockManagementInfoBanner(),
          // Search row
          if (!isWide)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              child: Row(
                children: [
                  _InventoryLayoutSwitch(
                    isGridMode: _isGridMode,
                    onChanged: _setWarehouseLayoutGrid,
                    compact: true,
                  ),
                  const SizedBox(width: 8),
                  Expanded(child: _searchBar()),
                  const SizedBox(width: 12),
                  _iconBtn(Icons.filter_list, () {
                    setState(() => _lowStockOnly = !_lowStockOnly);
                  }),
                ],
              ),
            ),
          const Divider(height: 1),
          // Content
          Expanded(
            child: _isGridMode
                ? isWide
                    ? LayoutBuilder(
                        builder: (context, constraints) {
                          final columns =
                              _responsiveWideGridColumns(constraints.maxWidth);
                          return GridView.builder(
                            padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: columns,
                              crossAxisSpacing: 14,
                              mainAxisSpacing: 14,
                              mainAxisExtent: _kWideGudangCardExtent,
                            ),
                            itemCount: products.length,
                            itemBuilder: (ctx, i) => _GudangCard(
                              product: products[i],
                              onDetail: () => _showStockDetail(products[i]),
                              isGrid: true,
                            ),
                          );
                        },
                      )
                    : GridView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 10, 16, 100),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          mainAxisExtent: 268,
                        ),
                        itemCount: products.length,
                        itemBuilder: (_, i) => _GudangCard(
                          product: products[i],
                          onDetail: () => _showStockDetail(products[i]),
                          isGrid: true,
                        ),
                      )
                : LayoutBuilder(
                    builder: (context, constraints) {
                      final columns =
                          isWide && constraints.maxWidth >= 980 ? 2 : 1;
                      final padding = EdgeInsets.fromLTRB(
                        isWide ? 16 : 12,
                        isWide ? 16 : 10,
                        isWide ? 16 : 12,
                        100,
                      );

                      if (columns > 1) {
                        return GridView.builder(
                          padding: padding,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 6,
                            mainAxisExtent: 82,
                          ),
                          itemCount: products.length,
                          itemBuilder: (_, i) => _GudangListTile(
                            product: products[i],
                            onDetail: () => _showStockDetail(products[i]),
                          ),
                        );
                      }

                      return ListView.separated(
                        padding: padding,
                        itemCount: products.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 5),
                        itemBuilder: (_, i) => _GudangListTile(
                          product: products[i],
                          onDetail: () => _showStockDetail(products[i]),
                        ),
                      );
                    },
                  ),
          ),
        ],
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(context, 'Gudang',
          trailing: _redProButton('Ekspor', () => _exportGudang(products)),
          titleWidget: isWide
              ? Row(
                  children: [
                    const Text('Gudang',
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w700,
                            color: Colors.black87)),
                    const SizedBox(width: 24),
                    _InventoryLayoutSwitch(
                      isGridMode: _isGridMode,
                      onChanged: _setWarehouseLayoutGrid,
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: _searchBar()),
                    const SizedBox(width: 16),
                  ],
                )
              : null),
      body: isWide
          ? Row(
              children: [
                sidebar(),
                Expanded(child: mainArea()),
              ],
            )
          : mainArea(),
      bottomNavigationBar: _bottomBar(
        children: [
          _solidBtn(
              'Lihat Riwayat Stok',
              () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const RiwayatStokLaporanScreen()),
                  ))
        ],
      ),
    );
  }
}

class _GudangListTile extends StatelessWidget {
  final Product product;
  final VoidCallback onDetail;

  const _GudangListTile({
    required this.product,
    required this.onDetail,
  });

  @override
  Widget build(BuildContext context) {
    final isLow = product.stock <= product.minStock;

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 720;
        return InkWell(
          onTap: onDetail,
          borderRadius: BorderRadius.zero,
          child: Container(
            padding: EdgeInsets.symmetric(
              horizontal: compact ? 10 : 12,
              vertical: compact ? 6 : 7,
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.zero,
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: compact ? _buildCompact(isLow) : _buildWide(isLow),
          ),
        );
      },
    );
  }

  Widget _buildWide(bool isLow) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        _thumb(36),
        const SizedBox(width: 10),
        Expanded(child: _productIdentity(isLow, maxNameLines: 1)),
        const SizedBox(width: 10),
        _metric(
          'Stok',
          '${product.stock} $_unit',
          isLow ? const Color(0xFFE11D48) : _kBrand,
        ),
        if (_isMaterial) ...[
          _metric('Min Stok', '${product.minStock} $_unit',
              const Color(0xFF64748B)),
          _metric('Tipe', 'Bahan Baku', _kBrand),
        ] else ...[
          _metric('Modal', _money(product.buyPrice), const Color(0xFF64748B)),
          _metric('Harga Jual', _money(product.sellPrice), _kBrand),
        ],
        const SizedBox(width: 6),
        _detailButton(width: 102, height: 32),
      ],
    );
  }

  Widget _buildCompact(bool isLow) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        _thumb(36),
        const SizedBox(width: 9),
        Expanded(
          child: _productIdentity(
            isLow,
            maxNameLines: 1,
            showPriceLine: true,
          ),
        ),
        const SizedBox(width: 8),
        _stockPill(isLow),
        const SizedBox(width: 2),
        SizedBox(
          width: 28,
          height: 28,
          child: Icon(
            Icons.chevron_right_rounded,
            size: 20,
            color: Colors.grey.shade400,
          ),
        ),
      ],
    );
  }

  Widget _productIdentity(bool isLow,
      {required int maxNameLines, bool showPriceLine = false}) {
    final sku = product.sku?.trim();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                product.name,
                maxLines: maxNameLines,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w800,
                  color: const Color(0xFF1E293B),
                  height: 1.2,
                ),
              ),
            ),
            if (_isMaterial) ...[
              const SizedBox(width: 6),
              _typeBadge('Bahan Baku'),
            ],
            if (isLow) ...[
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: const BoxDecoration(
                  color: Color(0xFFFFEEF2),
                  borderRadius: BorderRadius.zero,
                ),
                child: Text(
                  'Stok menipis',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFFE11D48),
                  ),
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 4),
        if (showPriceLine) ...[
          Text(
            _isMaterial
                ? '${product.stock} $_unit  |  Min: ${product.minStock} $_unit'
                : '${_money(product.sellPrice)}  |  Modal: ${_money(product.buyPrice)}',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: _kBrand,
            ),
          ),
          const SizedBox(height: 1),
        ],
        Text(
          _isMaterial
              ? 'Bahan Baku  -  $_unit'
              : '${sku == null || sku.isEmpty ? 'SKU -' : 'SKU $sku'}  -  $_unit',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 10.5,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF94A3B8),
          ),
        ),
      ],
    );
  }

  Widget _thumb(double size) {
    final imgPath = product.imagePath;
    final hasImage =
        imgPath != null && imgPath.isNotEmpty && File(imgPath).existsSync();
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: hasImage
          ? Image.file(File(imgPath), fit: BoxFit.cover)
          : Icon(
              _isMaterial ? Icons.science_outlined : Icons.inventory_2_rounded,
              size: 18,
              color: const Color(0xFFCBD5E1),
            ),
    );
  }

  Widget _metric(String label, String value, Color color) {
    return SizedBox(
      width: 78,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF94A3B8),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _stockPill(bool isLow) {
    return Container(
      width: 52,
      padding: const EdgeInsets.symmetric(vertical: 5),
      color: isLow ? const Color(0xFFFFEEF2) : const Color(0xFFF1F7F7),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Stok',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 9,
              fontWeight: FontWeight.w800,
              color: const Color(0xFF94A3B8),
            ),
          ),
          Text(
            '${product.stock}',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: isLow ? const Color(0xFFE11D48) : _kBrand,
            ),
          ),
        ],
      ),
    );
  }

  Widget _detailButton({required double width, required double height}) {
    return Container(
      width: width,
      height: height,
      alignment: Alignment.center,
      color: _kBrand,
      child: Text(
        'Detail Stok',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: GoogleFonts.plusJakartaSans(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          color: Colors.white,
        ),
      ),
    );
  }

  bool get _isMaterial => product.isMaterial == 1;
  String get _unit =>
      product.unit.trim().isEmpty ? 'unit' : product.unit.trim();
  String _money(int value) => 'Rp${_fmtP(value)}';
}

class _GudangCard extends StatelessWidget {
  final Product product;
  final VoidCallback onDetail;
  final bool isGrid;

  const _GudangCard(
      {required this.product, required this.onDetail, this.isGrid = false});

  @override
  Widget build(BuildContext context) {
    final p = product;
    final imgPath = p.imagePath;
    final hasImage =
        imgPath != null && imgPath.isNotEmpty && File(imgPath).existsSync();
    final isStokRendah = p.stock <= p.minStock;
    final stockText = '${p.stock} ${p.unit.isNotEmpty ? p.unit : 'unit'}';

    return Container(
      padding: EdgeInsets.all(isGrid ? 12 : 16),
      decoration: BoxDecoration(
        color: _kInventoryCardSurface,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: _kInventoryCardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.zero,
                  border: Border.all(color: _kInventoryMediaBorder),
                ),
                child: hasImage
                    ? Image.file(File(imgPath), fit: BoxFit.cover)
                    : const Icon(Icons.inventory_2_rounded,
                        size: 20, color: Color(0xFFCBD5E1)),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 34,
                      child: Text(
                        p.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: const Color(0xFF1E293B),
                            height: 1.25),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      p.unit.isNotEmpty ? p.unit : 'unit',
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                          color: const Color(0xFF94A3B8)),
                    ),
                    if (p.isMaterial == 1) ...[
                      const SizedBox(height: 4),
                      _typeBadge('Bahan Baku'),
                    ],
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Price Section
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.isMaterial == 1
                          ? 'Rp${_fmtP(p.buyPrice)}'
                          : 'Rp${_fmtP(p.sellPrice)}',
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          color: _kBrand,
                          letterSpacing: -0.5),
                    ),
                    Text(
                      p.isMaterial == 1
                          ? 'Harga beli'
                          : 'Modal: Rp${_fmtP(p.buyPrice)}',
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                          color: const Color(0xFF94A3B8)),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (!isGrid) ...[
            _gudangMeta('Terdaftar', _fmtDate(p.createdAt), 'SKU',
                (p.sku != null && p.sku!.isNotEmpty) ? p.sku! : '-'),
            _gudangMeta('Stok Sekarang', stockText, 'Manajemen Stok',
                p.hasStockManagement == 1 ? 'Aktif' : 'Tidak'),
          ] else ...[
            _metaRowGrid(
              'Stok',
              stockText,
              'SKU',
              (p.sku != null && p.sku!.isNotEmpty) ? p.sku! : '-',
              v1Color: isStokRendah ? const Color(0xFFE11D48) : null,
            ),
          ],
          const SizedBox(height: 14),
          GestureDetector(
            onTap: onDetail,
            child: Container(
              height: 36,
              width: double.infinity,
              decoration: BoxDecoration(
                color: _kBrand,
                borderRadius: BorderRadius.zero,
                border: Border.all(color: _kBrand),
              ),
              child: Center(
                child: Text(
                  'Detail Stok',
                  style: GoogleFonts.plusJakartaSans(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _gudangMeta(String k1, String v1, String k2, String v2,
      {Color? v1Color}) {
    return _metaRowGrid(k1, v1, k2, v2, v1Color: v1Color);
  }
}

//
//  PRODUK EKSTRA SCREEN
//
class ProdukEkstraScreen extends ConsumerStatefulWidget {
  const ProdukEkstraScreen({super.key});

  @override
  ConsumerState<ProdukEkstraScreen> createState() => _ProdukEkstraScreenState();
}

class _ProdukEkstraScreenState extends ConsumerState<ProdukEkstraScreen> {
  final TextEditingController _searchCtrl = TextEditingController();
  String _search = '';
  String _sortBy = 'Nama (A-Z)';

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Widget _sidebar(bool isWide) {
    return Container(
      width: 240,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(right: BorderSide(color: Color(0xFFEEEEEE))),
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 20, 16, 8),
              child: Text('URUTKAN',
                  style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: Colors.grey,
                      letterSpacing: 1.2)),
            ),
            ...['Nama (A-Z)', 'Nama (Z-A)', 'Terbaru']
                .map((s) => _sidebarItem(s, s == _sortBy, () {
                      setState(() => _sortBy = s);
                    })),
            const SizedBox(height: 32),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF6FF),
                  borderRadius: BorderRadius.zero,
                  border: Border.all(color: const Color(0xFFDBEAFE)),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.info_outline_rounded,
                            color: Color(0xFF2563EB), size: 18),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text('Info Layanan Tambahan',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF1E40AF))),
                        ),
                      ],
                    ),
                    SizedBox(height: 6),
                    Text(
                        'Layanan Tambahan adalah opsi atau add-on (seperti "Biaya Kunjungan", "Layanan Express") yang bisa ditambahkan ke layanan utama saat transaksi.',
                        style: TextStyle(
                            fontSize: 11,
                            color: Color(0xFF1E40AF),
                            height: 1.5)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sidebarItem(String label, bool selected, VoidCallback onTap) {
    return ListTile(
      title: Text(label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            color: selected ? _kBrand : Colors.black87,
          )),
      trailing: selected
          ? const Icon(Icons.check_circle, size: 18, color: _kBrand)
          : null,
      onTap: onTap,
      dense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      selected: selected,
      selectedTileColor: _kBrand.withValues(alpha: 0.05),
    );
  }

  Widget _searchTopBar(int total) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Color(0xFFE5E7EB))),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 44,
              decoration: const BoxDecoration(
                color: Color(0xFFF8FAFC),
                borderRadius: BorderRadius.zero,
              ),
              child: TextField(
                controller: _searchCtrl,
                onChanged: (v) => setState(() => _search = v),
                decoration: InputDecoration(
                  hintText: 'Cari layanan tambahan...',
                  hintStyle:
                      const TextStyle(fontSize: 13, color: Colors.black38),
                  prefixIcon: const Icon(Icons.search,
                      size: 20, color: Color(0xFF64748B)),
                  suffixIcon: _search.isEmpty
                      ? null
                      : IconButton(
                          tooltip: 'Hapus pencarian',
                          icon: const Icon(Icons.close_rounded,
                              size: 18, color: Color(0xFF64748B)),
                          onPressed: () {
                            _searchCtrl.clear();
                            setState(() => _search = '');
                          },
                        ),
                  filled: true,
                  fillColor: const Color(0xFFF8FAFC),
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 0, horizontal: 12),
                  enabledBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: Color(0xFFE2E8F0)),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: _kBrand, width: 1.3),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            height: 44,
            padding: const EdgeInsets.symmetric(horizontal: 14),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: const Color(0xFFEFF6FF),
              border: Border.all(color: const Color(0xFFDBEAFE)),
              borderRadius: BorderRadius.zero,
            ),
            child: Text(
              '$total add-on',
              style: const TextStyle(
                color: _kBrand,
                fontSize: 13,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _mainArea(bool isWide, List<Product> list) {
    return isWide
        ? Column(
            children: [
              _searchTopBar(list.length),
              Expanded(
                child: list.isEmpty
                    ? _emptyState('Layanan Tambahan Tidak Ditemukan')
                    : LayoutBuilder(
                        builder: (context, constraints) {
                          final columns =
                              _responsiveWideGridColumns(constraints.maxWidth);
                          return GridView.builder(
                            padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: columns,
                              crossAxisSpacing: 14,
                              mainAxisSpacing: 14,
                              mainAxisExtent: _kWideProductCardExtent,
                            ),
                            itemCount: list.length,
                            itemBuilder: (ctx, i) {
                              final prod = list[i];
                              return _ProductCard(
                                product: prod,
                                onEdit: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => ExtraProductFormScreen(
                                          existing: prod)),
                                ).then((_) => ref
                                    .read(productsProvider.notifier)
                                    .loadProducts()),
                                onMore: () => _showMoreMenu(context, ref, prod),
                              );
                            },
                          );
                        },
                      ),
              ),
            ],
          )
        : list.isEmpty
            ? _emptyState('Layanan Tambahan Tidak Ditemukan')
            : GridView.builder(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 120),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  mainAxisExtent: 240,
                ),
                itemCount: list.length,
                itemBuilder: (_, i) {
                  final prod = list[i];
                  return _ProductCard(
                    product: prod,
                    isGrid: true,
                    onEdit: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) =>
                              ExtraProductFormScreen(existing: prod)),
                    ),
                    onMore: () => _showMoreMenu(context, ref, prod),
                  );
                },
              );
  }

  @override
  Widget build(BuildContext context) {
    final isWide = isTabletDevice(context) || isLandscape(context);
    final allProducts = ref.watch(productsProvider);

    // Filtering and Sorting
    var list = allProducts.where((p) => p.isExtra == 1).toList();

    if (_search.isNotEmpty) {
      final q = _search.toLowerCase();
      list = list.where((p) => p.name.toLowerCase().contains(q)).toList();
    }

    if (_sortBy == 'Nama (A-Z)') {
      list.sort((a, b) => a.name.compareTo(b.name));
    } else if (_sortBy == 'Nama (Z-A)') {
      list.sort((a, b) => b.name.compareTo(a.name));
    } else if (_sortBy == 'Terbaru') {
      list.sort((a, b) => (b.createdAt ?? '').compareTo(a.createdAt ?? ''));
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(context, 'Layanan Tambahan'),
      body: isWide
          ? Row(
              children: [
                _sidebar(isWide),
                Expanded(child: _mainArea(isWide, list)),
              ],
            )
          : _mainArea(isWide, list),
      bottomNavigationBar: _bottomBar(
        children: [
          _solidBtn(
            'Tambah Layanan Tambahan',
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ExtraProductFormScreen()),
            ),
          ),
        ],
      ),
    );
  }

  void _showMoreMenu(BuildContext context, WidgetRef ref, Product p) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (_) => SafeArea(
        child: Padding(
          padding:
              const EdgeInsets.only(top: 16, bottom: 20, left: 20, right: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Opsi Layanan Tambahan',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.close_rounded,
                        color: Colors.black45, size: 22),
                  )
                ],
              ),
              const SizedBox(height: 16),
              InkWell(
                borderRadius: BorderRadius.zero,
                onTap: () {
                  Navigator.pop(context);
                  _confirmDelete(context, ref, p);
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  decoration: const BoxDecoration(
                    color: AppColors.dangerBg,
                    borderRadius: BorderRadius.zero,
                  ),
                  child: const Row(
                    children: [
                      Icon(AppIcons.recycleBin,
                          color: AppColors.danger, size: 20),
                      SizedBox(width: 12),
                      Text(
                        'Hapus Layanan Tambahan',
                        style: TextStyle(
                            color: AppColors.danger,
                            fontWeight: FontWeight.bold,
                            fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context, WidgetRef ref, Product p) {
    showKasirConfirmDialog(
      context,
      title: 'Hapus Layanan Tambahan?',
      message:
          'Apakah Anda yakin ingin menghapus layanan tambahan "${p.name}"?',
      confirmLabel: 'Ya, Hapus',
      icon: AppIcons.recycleBin,
    ).then((confirmed) {
      if (confirmed == true) {
        ref.read(productsProvider.notifier).deleteProduct(p.id!);
      }
    });
  }
}

//
//  DISKON PRODUK SCREEN  (Image 3)
//
class DiskonProdukScreen extends ConsumerStatefulWidget {
  const DiskonProdukScreen({super.key});

  @override
  ConsumerState<DiskonProdukScreen> createState() => _DiskonProdukScreenState();
}

class _DiskonProdukScreenState extends ConsumerState<DiskonProdukScreen> {
  String _statusFilter = 'Semua';

  Widget _sidebar(bool isWide) {
    return Container(
      width: 240,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(right: BorderSide(color: Color(0xFFEEEEEE))),
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 20, 16, 12),
              child: Text('STATUS DISKON',
                  style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: Colors.grey,
                      letterSpacing: 1.2)),
            ),
            ...['Semua', 'Aktif', 'Berakhir']
                .map((s) => _sidebarItem(s, s == _statusFilter, () {
                      setState(() => _statusFilter = s);
                    })),
            const SizedBox(height: 32),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF7ED),
                  borderRadius: BorderRadius.zero,
                  border: Border.all(color: const Color(0xFFFED7AA)),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Promo Tip',
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF9A3412))),
                    SizedBox(height: 4),
                    Text(
                        'Diskon yang berakhir tidak akan otomatis terpotong saat transaksi kasir.',
                        style: TextStyle(
                            fontSize: 11,
                            color: Color(0xFFC2410C),
                            height: 1.4)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sidebarItem(String label, bool selected, VoidCallback onTap) {
    return ListTile(
      title: Text(label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            color: selected ? _kBrand : Colors.black87,
          )),
      trailing: selected
          ? const Icon(Icons.check_circle, size: 18, color: _kBrand)
          : null,
      onTap: onTap,
      dense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      selected: selected,
      selectedTileColor: _kBrand.withValues(alpha: 0.05),
    );
  }

  Widget _mainArea(bool isWide, List<Discount> discounts) {
    if (discounts.isEmpty) return _emptyState('Diskon Tidak Ditemukan');

    return isWide
        ? GridView.builder(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 120),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount:
                  isLandscape(context) ? 2 : (isTabletDevice(context) ? 2 : 1),
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
              childAspectRatio: isLandscape(context)
                  ? 2.2
                  : (isTabletDevice(context) ? 2.5 : 3.2),
            ),
            itemCount: discounts.length,
            itemBuilder: (context, index) {
              final d = discounts[index];
              return _buildDiscountCard(context, ref, d);
            },
          )
        : ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
            itemCount: discounts.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, index) {
              final d = discounts[index];
              return _buildDiscountCard(context, ref, d);
            },
          );
  }

  @override
  Widget build(BuildContext context) {
    final isWide = isTabletDevice(context) || isLandscape(context);
    final allDiscounts = ref.watch(discountsProvider);

    final discounts = allDiscounts.where((d) {
      if (_statusFilter == 'Semua') return true;
      final isExpired = DateTime.parse(d.endDate).isBefore(DateTime.now());
      if (_statusFilter == 'Aktif') return !isExpired;
      if (_statusFilter == 'Berakhir') return isExpired;
      return true;
    }).toList();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(context, 'Diskon & Grosir'),
      body: isWide
          ? Row(
              children: [
                _sidebar(isWide),
                Expanded(child: _mainArea(isWide, discounts)),
              ],
            )
          : _mainArea(isWide, discounts),
      bottomNavigationBar: _bottomBar(
        children: [
          _solidBtn(
              'Tambah Diskon',
              () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const TambahDiskonScreen()),
                  )),
        ],
      ),
    );
  }

  Widget _buildDiscountCard(BuildContext context, WidgetRef ref, Discount d) {
    final endDate = DateTime.tryParse(d.endDate);
    final isExpired = endDate != null && endDate.isBefore(DateTime.now());
    final productCount =
        d.productIds.split(',').where((id) => id.trim().isNotEmpty).length;
    final nominalText =
        d.isPercentage == 1 ? '${d.nominal}%' : 'Rp${_fmtP(d.nominal)}';

    return Material(
      color: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
        side: BorderSide(color: Color(0xFFD9E2EF)),
      ),
      elevation: 0,
      child: InkWell(
        onTap: () => _openEditDiscount(context, d),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      d.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF111827),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  _discountStatusBadge(isExpired),
                  const SizedBox(width: 4),
                  IconButton(
                    icon: const Icon(
                      Icons.edit_outlined,
                      color: _kBrand,
                      size: 18,
                    ),
                    onPressed: () => _openEditDiscount(context, d),
                    tooltip: 'Ubah diskon',
                    visualDensity: VisualDensity.compact,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(
                      minWidth: 34,
                      minHeight: 34,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(
                      AppIcons.recycleBin,
                      color: Color(0xFFEF4444),
                      size: 18,
                    ),
                    onPressed: () => _confirmDeleteDiscount(context, ref, d),
                    tooltip: 'Hapus diskon',
                    visualDensity: VisualDensity.compact,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(
                      minWidth: 34,
                      minHeight: 34,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _discountDetailPanel(d, nominalText, productCount),
            ],
          ),
        ),
      ),
    );
  }

  Widget _discountStatusBadge(bool isExpired) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: isExpired ? const Color(0xFFF3F4F6) : const Color(0xFFEFF6FF),
        borderRadius: BorderRadius.zero,
        border: Border.all(
          color: isExpired ? const Color(0xFFE5E7EB) : const Color(0xFFBFDBFE),
        ),
      ),
      child: Text(
        isExpired ? 'Berakhir' : 'Aktif',
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w800,
          color: isExpired ? const Color(0xFF6B7280) : const Color(0xFF1D4ED8),
          letterSpacing: 0.2,
        ),
      ),
    );
  }

  Widget _discountDetailPanel(
    Discount d,
    String nominalText,
    int productCount,
  ) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final veryNarrow = constraints.maxWidth < 300;
          final nominal = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Nominal Diskon',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 11,
                  color: Color(0xFF64748B),
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                nominalText,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 19,
                  color: _kBrand,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          );
          final meta = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _discountMetaLine(
                Icons.calendar_today_outlined,
                '${_fmtDate(d.startDate)} - ${_fmtDate(d.endDate)}',
              ),
              const SizedBox(height: 7),
              _discountMetaLine(
                Icons.inventory_2_outlined,
                '$productCount produk dipilih',
              ),
            ],
          );

          if (veryNarrow) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                nominal,
                const Divider(height: 18),
                meta,
              ],
            );
          }

          return Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(width: 112, child: nominal),
              Container(
                width: 1,
                height: 42,
                margin: const EdgeInsets.symmetric(horizontal: 12),
                color: const Color(0xFFE2E8F0),
              ),
              Expanded(child: meta),
            ],
          );
        },
      ),
    );
  }

  Widget _discountMetaLine(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, size: 13, color: const Color(0xFF64748B)),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            text,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 12,
              color: Color(0xFF334155),
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }

  void _confirmDeleteDiscount(BuildContext context, WidgetRef ref, Discount d) {
    showKasirConfirmDialog(
      context,
      title: 'Hapus Diskon?',
      message: 'Diskon "${d.name}" akan dihapus permanen.',
      confirmLabel: 'Ya, Hapus',
      icon: AppIcons.recycleBin,
    ).then((confirmed) {
      if (confirmed == true) {
        ref.read(discountsProvider.notifier).deleteDiscount(d.id!);
      }
    });
  }

  void _openEditDiscount(BuildContext context, Discount discount) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TambahDiskonScreen(existing: discount),
      ),
    );
  }
}

//
//  RIWAYAT STOK SCREEN  (Image 7)
//
class RiwayatStokScreen extends StatefulWidget {
  const RiwayatStokScreen({super.key});

  @override
  State<RiwayatStokScreen> createState() => _RiwayatStokScreenState();
}

class _RiwayatStokScreenState extends State<RiwayatStokScreen> {
  String _period = 'Periode Harian';
  DateTime _selectedDate = DateTime.now();

  bool _isMatch(DateTime d) {
    switch (_period) {
      case 'Periode Bulanan':
        return d.year == _selectedDate.year && d.month == _selectedDate.month;
      case 'Periode Tahunan':
        return d.year == _selectedDate.year;
      default:
        return d.year == _selectedDate.year &&
            d.month == _selectedDate.month &&
            d.day == _selectedDate.day;
    }
  }

  String _periodDateLabel() {
    switch (_period) {
      case 'Periode Bulanan':
        return _fmtDate(DateTime(_selectedDate.year, _selectedDate.month, 1)
            .toIso8601String());
      case 'Periode Tahunan':
        return '${_selectedDate.year}';
      default:
        return _fmtDate(_selectedDate.toIso8601String());
    }
  }

  Future<void> _pickPeriod() async {
    final options = ['Periode Harian', 'Periode Bulanan', 'Periode Tahunan'];
    final selected = await showModalBottomSheet<String>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 12),
          ...options.map(
            (opt) => ListTile(
              title: Text(opt),
              trailing: opt == _period
                  ? const Icon(Icons.check, color: _kBrand)
                  : null,
              onTap: () => Navigator.pop(context, opt),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
    if (selected != null) setState(() => _period = selected);
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  Future<List<Map<String, dynamic>>> _loadHistory() async {
    final logs = await DBHelper.instance.getAllStockLogs(limit: 500);
    final products = await DBHelper.instance.getAllProducts();
    final nameMap = {for (final p in products) p.id: p.name};
    final imageMap = {for (final p in products) p.id: p.imagePath ?? ''};
    final materialMap = {for (final p in products) p.id: p.isMaterial};
    final unitMap = {for (final p in products) p.id: p.unit};

    final filtered = logs.where((l) {
      final dt = DateTime.tryParse(l.date);
      if (dt == null) return false;
      return _isMatch(dt);
    }).toList()
      ..sort((a, b) => b.date.compareTo(a.date));

    return filtered
        .map(
          (l) => {
            'tanggal': l.date,
            'produk': nameMap[l.productId] ?? 'Produk #${l.productId}',
            'image_path': imageMap[l.productId] ?? '',
            'is_material': materialMap[l.productId] ?? 0,
            'unit': unitMap[l.productId] ?? '',
            'type': l.type,
            'qty': l.qty,
            'old_qty': l.oldQty,
            'new_qty': l.newQty,
          },
        )
        .toList();
  }

  Future<void> _exportHistory() async {
    final rows = await _loadHistory();
    if (rows.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Belum ada riwayat stok untuk diekspor.'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
      return;
    }
    await ExportService.exportAndShareCsv(
      filePrefix: 'riwayat_stok',
      headers: const [
        'Tanggal',
        'Produk',
        'Tipe',
        'Qty',
        'Software',
        'Stok Awal',
        'Stok Akhir'
      ],
      rows: rows
          .map((r) => <Object?>[
                r['tanggal'],
                (r['is_material'] as int? ?? 0) == 1
                    ? '${r['produk']} (Bahan Baku)'
                    : r['produk'],
                r['type'],
                r['qty'],
                r['unit'],
                r['old_qty'] ?? '',
                r['new_qty'] ?? '',
              ])
          .toList(),
      subject: 'Ekspor Riwayat Stok',
      message: 'Filter: $_period  ${_periodDateLabel()}',
    );
  }

  @override
  Widget build(BuildContext context) {
    final isWide = isTabletDevice(context) || isLandscape(context);

    // Sidebar/Header for filters
    Widget filterSection = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Info banner
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          color: const Color(0xFFFFF8F8),
          child: const Text(
            'Riwayat stok hanya tersedia untuk produk dengan manajemen stok aktif.',
            style: TextStyle(fontSize: 13, color: Colors.black54),
          ),
        ),
        // Filter row
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('Filter Periode',
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey)),
              const SizedBox(height: 8),
              _periodChip(_period, _pickPeriod),
              const SizedBox(height: 10),
              _periodChip(_periodDateLabel(), _pickDate),
            ],
          ),
        ),
      ],
    );

    // Main content area
    Widget mainContent = FutureBuilder<List<Map<String, dynamic>>>(
      future: _loadHistory(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(color: _kBrand),
          );
        }
        final rows = snapshot.data ?? [];
        if (rows.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _exchangeIllustration(),
                const SizedBox(height: 20),
                const Text(
                  'Riwayat Stok Tidak Ditemukan',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Text(
                  'Belum ada riwayat stok di $_period',
                  style: const TextStyle(fontSize: 13, color: Colors.grey),
                ),
              ],
            ),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
          itemCount: rows.length,
          separatorBuilder: (_, __) =>
              const Divider(height: 1, color: Color(0xFFEEEEEE)),
          itemBuilder: (_, i) {
            final row = rows[i];
            final isIn = row['type'] == 'in';
            final qty = row['qty'];
            final productName = row['produk'];
            final imagePath = row['image_path'] as String;
            final isMaterial = (row['is_material'] as int? ?? 0) == 1;
            final unit = (row['unit'] as String?) ?? '';
            final oldQty = row['old_qty'] as int?;
            final newQty = row['new_qty'] as int?;
            final unitSuffix = unit.isEmpty ? '' : ' $unit';
            final qtyText = '${isIn ? '+' : '-'}$qty$unitSuffix';
            final stockAfterText =
                newQty == null ? null : 'Sisa: $newQty$unitSuffix';
            final stockFlowText = oldQty == null || newQty == null
                ? null
                : '$oldQty$unitSuffix -> $newQty$unitSuffix';

            String timeStr = '';
            try {
              final dt = DateTime.parse(row['tanggal']);
              timeStr =
                  '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
            } catch (_) {}

            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.zero,
                  border: Border.all(color: const Color(0xFFEEEEEE)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.02),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    )
                  ],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Thumbnail
                    ClipRRect(
                      borderRadius: BorderRadius.zero,
                      child: SizedBox(
                        width: 48,
                        height: 48,
                        child: imagePath.isNotEmpty
                            ? Image.file(
                                File(imagePath),
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => _buildPlaceholder(
                                  isMaterial: isMaterial,
                                  unit: unit,
                                  productName: productName,
                                ),
                              )
                            : _buildPlaceholder(
                                isMaterial: isMaterial,
                                unit: unit,
                                productName: productName,
                              ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    // Info
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            productName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87),
                          ),
                          if (isMaterial) ...[
                            const SizedBox(height: 4),
                            _typeBadge('Bahan Baku'),
                          ],
                          if (timeStr.isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Text(
                              timeStr,
                              style: const TextStyle(
                                  fontSize: 11.5, color: Colors.black45),
                            ),
                          ],
                          if (stockFlowText != null) ...[
                            const SizedBox(height: 4),
                            Text(
                              stockFlowText,
                              style: const TextStyle(
                                  fontSize: 11.5, color: Color(0xFF64748B)),
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Qty badge
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: isIn
                                ? Colors.green.withValues(alpha: 0.1)
                                : AppColors.danger.withValues(alpha: 0.08),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: Text(
                            qtyText,
                            style: TextStyle(
                              color: isIn ? Colors.green : AppColors.danger,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        if (stockAfterText != null) ...[
                          const SizedBox(height: 5),
                          Text(
                            stockAfterText,
                            style: const TextStyle(
                              fontSize: 11,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(context, 'Riwayat Stok',
          trailing: _redProButton('Ekspor', _exportHistory)),
      body: isWide
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: 280, // sidebar width
                  child: filterSection,
                ),
                const VerticalDivider(width: 1, color: Color(0xFFEEEEEE)),
                Expanded(child: mainContent),
              ],
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Info banner (compact for mobile)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  color: const Color(0xFFFFF8F8),
                  child: const Text(
                    'Riwayat stok hanya tersedia untuk produk dengan manajemen stok aktif.',
                    style: TextStyle(fontSize: 13, color: Colors.black54),
                  ),
                ),
                // Filter row (mobile)
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                  child: Row(
                    children: [
                      _periodChip(_period, _pickPeriod),
                      const SizedBox(width: 8),
                      _periodChip(_periodDateLabel(), _pickDate),
                    ],
                  ),
                ),
                const Divider(height: 1),
                Expanded(child: mainContent),
              ],
            ),
    );
  }

  Widget _buildPlaceholder({
    required bool isMaterial,
    required String unit,
    required String productName,
  }) {
    final lowerName = productName.toLowerCase();
    final lowerUnit = unit.toLowerCase();
    final IconData icon = isMaterial
        ? Icons.science_outlined
        : lowerName.contains('sepatu')
            ? Icons.directions_walk_outlined
            : lowerName.contains('karpet')
                ? Icons.chair_outlined
                : lowerUnit == 'kg'
                    ? Icons.handyman_outlined
                    : Icons.inventory_2_outlined;
    final Color color =
        isMaterial ? const Color(0xFF9A3412) : const Color(0xFF64748B);
    final Color bg =
        isMaterial ? const Color(0xFFFFF7ED) : const Color(0xFFF1F5F9);

    return Container(
      width: 48,
      height: 48,
      color: bg,
      child: Icon(icon, color: color, size: 24),
    );
  }
}

//
//  TAMBAH DISKON SCREEN  (Image 8)
//
class TambahDiskonScreen extends ConsumerStatefulWidget {
  final Discount? existing;

  const TambahDiskonScreen({super.key, this.existing});

  @override
  ConsumerState<TambahDiskonScreen> createState() => _TambahDiskonScreenState();
}

class _TambahDiskonScreenState extends ConsumerState<TambahDiskonScreen> {
  final _nameCtrl = TextEditingController();
  final _nominalCtrl = TextEditingController();
  bool _isRp = true;
  DateTime _startDate = DateTime.now();
  DateTime _endDate = DateTime.now();
  TimeOfDay _startTime = TimeOfDay.now();
  TimeOfDay _endTime = TimeOfDay.now();
  final List<Product> _selectedProducts = [];

  bool get _isEditing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final existing = widget.existing;
    if (existing == null) return;

    _nameCtrl.text = existing.name;
    _nominalCtrl.text =
        existing.nominal > 0 ? formatCurrencyInput(existing.nominal) : '';
    _isRp = existing.isPercentage == 0;

    final start = DateTime.tryParse(existing.startDate);
    if (start != null) {
      _startDate = start;
      _startTime = TimeOfDay(hour: start.hour, minute: start.minute);
    }

    final end = DateTime.tryParse(existing.endDate);
    if (end != null) {
      _endDate = end;
      _endTime = TimeOfDay(hour: end.hour, minute: end.minute);
    }

    _loadExistingSelectedProducts(existing);
  }

  Future<void> _loadExistingSelectedProducts(Discount existing) async {
    final ids = existing.productIds
        .split(',')
        .map((id) => int.tryParse(id.trim()))
        .whereType<int>()
        .toSet();
    if (ids.isEmpty) return;

    final products = await DBHelper.instance.getAllProducts();
    if (!mounted) return;
    setState(() {
      _selectedProducts
        ..clear()
        ..addAll(products.where((p) => p.id != null && ids.contains(p.id)));
    });
  }

  String _fmtD(DateTime d) {
    return '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';
  }

  String _fmtT(TimeOfDay t) {
    return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  }

  Future<void> _pickDiscountProducts() async {
    final products = await DBHelper.instance.getAllProducts();
    if (!mounted) return;
    if (products.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Belum ada produk yang bisa dipilih.'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
      return;
    }

    final productIds = products.map((p) => p.id).whereType<int>().toSet();
    final selected =
        _selectedProducts.map((p) => p.id).whereType<int>().toSet();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setLocal) {
            final selectedCount = selected.intersection(productIds).length;
            final allSelected =
                productIds.isNotEmpty && selectedCount == productIds.length;
            return SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 36,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.zero,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Pilih Produk Diskon',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '$selectedCount dari ${productIds.length} produk dipilih',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: Colors.grey.shade700,
                            ),
                          ),
                        ),
                        TextButton.icon(
                          onPressed: () {
                            setLocal(() {
                              if (allSelected) {
                                selected.clear();
                              } else {
                                selected
                                  ..clear()
                                  ..addAll(productIds);
                              }
                            });
                          },
                          style: TextButton.styleFrom(
                            foregroundColor: _kBrand,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 8,
                            ),
                            minimumSize: const Size(0, 36),
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                          icon: Icon(
                            allSelected
                                ? Icons.remove_done_outlined
                                : Icons.done_all_rounded,
                            size: 16,
                          ),
                          label: Text(
                            allSelected ? 'Batal Pilih Semua' : 'Pilih Semua',
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    SizedBox(
                      height: MediaQuery.of(ctx).size.height * 0.55,
                      child: ListView.separated(
                        itemCount: products.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (_, i) {
                          final p = products[i];
                          final id = p.id;
                          final checked = id != null && selected.contains(id);
                          return CheckboxListTile(
                            value: checked,
                            title: Text(p.name),
                            subtitle: Text('Rp${_fmtP(p.sellPrice)}'),
                            controlAffinity: ListTileControlAffinity.leading,
                            contentPadding: EdgeInsets.zero,
                            onChanged: (v) {
                              if (id == null) return;
                              setLocal(() {
                                if (v == true) {
                                  selected.add(id);
                                } else {
                                  selected.remove(id);
                                }
                              });
                            },
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          setState(() {
                            _selectedProducts
                              ..clear()
                              ..addAll(
                                products.where((p) => selected.contains(p.id)),
                              );
                          });
                          Navigator.pop(ctx);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _kBrand,
                          foregroundColor: Colors.white,
                        ),
                        child: const Text('Terapkan Produk'),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _nominalCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar:
          _buildAppBar(context, _isEditing ? 'Ubah Diskon' : 'Tambah Diskon'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _fieldLabel('Nama', required: true),
            const SizedBox(height: 6),
            TextField(
              controller: _nameCtrl,
              decoration: _inputDeco('Contoh: Promo Diskon 12/12'),
            ),
            const SizedBox(height: 16),
            _fieldLabel('Nominal Diskon', required: true),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _nominalCtrl,
                    keyboardType: TextInputType.number,
                    inputFormatters: _isRp
                        ? const [CurrencyInputFormatter()]
                        : [FilteringTextInputFormatter.digitsOnly],
                    decoration: _inputDeco('0'),
                  ),
                ),
                const SizedBox(width: 8),
                // Rp toggle
                GestureDetector(
                  onTap: () => setState(() {
                    _isRp = true;
                    _nominalCtrl.text = formatCurrencyInput(
                        parseCurrencyInput(_nominalCtrl.text));
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 18, vertical: 12),
                    decoration: BoxDecoration(
                      color: _isRp ? _kBrand : Colors.white,
                      borderRadius:
                          const BorderRadius.horizontal(left: Radius.zero),
                      border: Border.all(
                          color: _isRp ? _kBrand : Colors.grey.shade300),
                    ),
                    child: Text('Rp',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: _isRp ? Colors.white : Colors.black54)),
                  ),
                ),
                // % toggle
                GestureDetector(
                  onTap: () => setState(() {
                    _isRp = false;
                    final value = parseCurrencyInput(_nominalCtrl.text);
                    _nominalCtrl.text = value == 0 ? '' : value.toString();
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 18, vertical: 12),
                    decoration: BoxDecoration(
                      color: !_isRp ? _kBrand : Colors.white,
                      borderRadius:
                          const BorderRadius.horizontal(right: Radius.zero),
                      border: Border.all(
                          color: !_isRp ? _kBrand : Colors.grey.shade300),
                    ),
                    child: Text('%',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: !_isRp ? Colors.white : Colors.black54)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _fieldLabel('Tanggal Mulai', required: true),
                      const SizedBox(height: 6),
                      _dateField(_fmtD(_startDate), () async {
                        final d = await showDatePicker(
                          context: context,
                          initialDate: _startDate,
                          firstDate: DateTime(2020),
                          lastDate: DateTime(2100),
                        );
                        if (d != null) setState(() => _startDate = d);
                      }),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _fieldLabel('Waktu Mulai', required: true),
                      const SizedBox(height: 6),
                      _timeField(_fmtT(_startTime), () async {
                        final t = await showTimePicker(
                            context: context, initialTime: _startTime);
                        if (t != null) setState(() => _startTime = t);
                      }),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _fieldLabel('Tanggal Selesai', required: true),
                      const SizedBox(height: 6),
                      _dateField(_fmtD(_endDate), () async {
                        final d = await showDatePicker(
                          context: context,
                          initialDate: _endDate,
                          firstDate: DateTime(2020),
                          lastDate: DateTime(2100),
                        );
                        if (d != null) setState(() => _endDate = d);
                      }),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _fieldLabel('Waktu Selesai', required: true),
                      const SizedBox(height: 6),
                      _timeField(_fmtT(_endTime), () async {
                        final t = await showTimePicker(
                            context: context, initialTime: _endTime);
                        if (t != null) setState(() => _endTime = t);
                      }),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Text('Produk Diskon',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Center(child: _exchangeIllustration()),
            const SizedBox(height: 12),
            _outlineBtn('Atur Produk Diskon', _pickDiscountProducts),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.center,
              child: Text(
                _selectedProducts.isEmpty
                    ? 'Belum ada produk dipilih'
                    : '${_selectedProducts.length} produk dipilih',
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ),
            const SizedBox(height: 80),
          ],
        ),
      ),
      bottomNavigationBar: _bottomBar(
        children: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                if (_nameCtrl.text.trim().isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text('Nama diskon wajib diisi.'),
                        backgroundColor: Colors.black87,
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero)),
                  );
                  return;
                }
                if (parseCurrencyInput(_nominalCtrl.text) <= 0) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text('Nominal diskon harus > 0.'),
                        backgroundColor: Colors.black87,
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero)),
                  );
                  return;
                }
                if (_selectedProducts.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text('Pilih minimal 1 produk.'),
                        backgroundColor: Colors.black87,
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero)),
                  );
                  return;
                }

                final startDt = DateTime(
                  _startDate.year,
                  _startDate.month,
                  _startDate.day,
                  _startTime.hour,
                  _startTime.minute,
                );
                final endDt = DateTime(
                  _endDate.year,
                  _endDate.month,
                  _endDate.day,
                  _endTime.hour,
                  _endTime.minute,
                );

                final discount = Discount(
                  id: widget.existing?.id,
                  name: _nameCtrl.text.trim(),
                  nominal: parseCurrencyInput(_nominalCtrl.text),
                  isPercentage: _isRp ? 0 : 1,
                  startDate: startDt.toIso8601String(),
                  endDate: endDt.toIso8601String(),
                  productIds: _selectedProducts.map((p) => p.id).join(','),
                  createdAt: widget.existing?.createdAt ??
                      DateTime.now().toIso8601String(),
                );

                if (_isEditing) {
                  ref.read(discountsProvider.notifier).updateDiscount(discount);
                } else {
                  ref.read(discountsProvider.notifier).addDiscount(discount);
                }

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      content: Text(
                        _isEditing
                            ? 'Diskon "${_nameCtrl.text.trim()}" berhasil diperbarui.'
                            : 'Diskon "${_nameCtrl.text.trim()}" berhasil disimpan.',
                      ),
                      backgroundColor: Colors.black87,
                      behavior: SnackBarBehavior.floating,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero)),
                );
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(_isEditing ? 'Update Diskon' : 'Simpan',
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(width: 10),
                  // PRO badge removed
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dateField(String val, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey.shade300),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_today_outlined,
                size: 16, color: Colors.grey),
            const SizedBox(width: 6),
            Text(val, style: const TextStyle(fontSize: 13)),
          ],
        ),
      ),
    );
  }

  Widget _timeField(String val, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey.shade300),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          children: [
            const Icon(Icons.access_time_outlined,
                size: 16, color: Colors.grey),
            const SizedBox(width: 6),
            Text(val, style: const TextStyle(fontSize: 13)),
          ],
        ),
      ),
    );
  }
}

//  PRODUCT FORM SCREEN  (Tambah / Edit produk - tidak berubah)

class ProductFormScreen extends ConsumerStatefulWidget {
  final Product? existing;
  final bool forceMaterial;
  const ProductFormScreen(
      {super.key, this.existing, this.forceMaterial = false});

  @override
  ConsumerState<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _RecipeDraft {
  int? materialProductId;
  final TextEditingController qtyCtrl;

  _RecipeDraft({this.materialProductId, String qty = ''})
      : qtyCtrl = TextEditingController(text: qty);

  void dispose() => qtyCtrl.dispose();
}

class _ProductFormScreenState extends ConsumerState<ProductFormScreen> {
  final _fk = GlobalKey<FormState>();
  late TextEditingController _name,
      _sell,
      _buy,
      _stock,
      _minStock,
      _desc,
      _sku,
      _barcode,
      _durationCtrl;
  int _catId = 1;
  String _unit = 'pcs';
  bool _loading = false;
  bool _hasExtraPopup = false;
  bool _isHardware = false;
  bool _isMaterial = false;
  bool _trackStock = false;
  bool _recipesLoading = false;
  String _durationUnit = 'jam';
  int? _supplierId;
  DateTime? _expiryDate;
  List<Supplier> _suppliers = [];
  List<String> _customUnits = [];
  final List<_RecipeDraft> _recipeLines = [];
  final GlobalKey _barcodePreviewKey = GlobalKey();

  List<String> get _unitOptions {
    final base = _isMaterial
        ? const [
            'gram',
            'kg',
            'ml',
            'liter',
            'pcs',
            'meter',
            'm2',
            'roll',
            'pack',
            'botol',
          ]
        : const [
            'kg',
            'gram',
            'ml',
            'liter',
            'pcs',
            'm2',
            'pasang',
            'layanan',
          ];
    final options = [...base];
    for (final customUnit in _customUnits) {
      final unit = customUnit.trim();
      if (unit.isNotEmpty &&
          !options.any((item) => item.toLowerCase() == unit.toLowerCase())) {
        options.add(unit);
      }
    }
    for (final product in ref.watch(productsProvider)) {
      final unit = product.unit.trim();
      if (unit.isNotEmpty &&
          !options.any((item) => item.toLowerCase() == unit.toLowerCase())) {
        options.add(unit);
      }
    }
    final current = _unit.trim();
    if (current.isNotEmpty &&
        !options.any((unit) => unit.toLowerCase() == current.toLowerCase())) {
      options.add(current);
    }
    return options;
  }

  String get _stockCostLabel {
    return 'HPP / Modal Stok';
  }

  String? _imagePath;
  final _picker = ImagePicker();

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picked = await _picker.pickImage(source: source, imageQuality: 85);
      if (picked == null) return;
      if (Platform.isWindows) {
        final savedPath =
            await ImageUtils.saveImageToLocalDirectory(picked.path);
        setState(() => _imagePath = savedPath ?? picked.path);
        return;
      }
      final cropped = await ImageCropper().cropImage(
        sourcePath: picked.path,
        aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
        uiSettings: [
          AndroidUiSettings(
            toolbarTitle: 'Sesuaikan Foto Produk',
            toolbarColor: _kBrand,
            statusBarLight: false,
            toolbarWidgetColor: Colors.white,
            activeControlsWidgetColor: _kBrand,
            lockAspectRatio: true,
          ),
          IOSUiSettings(
            title: 'Sesuaikan Foto',
            aspectRatioLockEnabled: true,
          ),
        ],
      );
      if (cropped != null) setState(() => _imagePath = cropped.path);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Operasi gagal. Silakan coba lagi.'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      }
    }
  }

  void _showImageSourceDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero)),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
                child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.zero))),
            const SizedBox(height: 16),
            const Text('Pilih Sumber Gambar',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pop(ctx);
                      _pickImage(ImageSource.camera);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      decoration: const BoxDecoration(
                          color: Color(0xFFEEF2F7),
                          borderRadius: BorderRadius.zero),
                      child: const Column(children: [
                        Icon(Icons.camera_alt_rounded,
                            color: Color(0xFF1E465B), size: 36),
                        SizedBox(height: 8),
                        Text('Kamera',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1E465B))),
                      ]),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pop(ctx);
                      _pickImage(ImageSource.gallery);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      decoration: const BoxDecoration(
                          color: Color(0xFFEEF2F7),
                          borderRadius: BorderRadius.zero),
                      child: const Column(children: [
                        Icon(Icons.photo_library_rounded,
                            color: Color(0xFF1E465B), size: 36),
                        SizedBox(height: 8),
                        Text('Galeri',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1E465B))),
                      ]),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _sell = TextEditingController(
        text: e != null ? formatCurrencyInput(e.sellPrice) : '');
    _desc = TextEditingController(text: e?.description ?? '');
    _sku = TextEditingController(text: e?.sku ?? '');
    _barcode = TextEditingController(text: e?.barcode ?? '');
    if (e != null) {
      _catId = e.categoryId;
      _unit = e.unit;
      _imagePath = e.imagePath;
      _hasExtraPopup = e.hasExtraPopup == 1;
      _isHardware = e.isHardware == 1;
      _isMaterial = e.isMaterial == 1;
      _trackStock = e.hasStockManagement == 1 && e.isMaterial != 1;
      _supplierId = e.supplierId;
      final rawExpiry = e.expiryDate?.trim();
      if (rawExpiry != null && rawExpiry.isNotEmpty) {
        _expiryDate = DateTime.tryParse(rawExpiry);
      }
    } else if (widget.forceMaterial) {
      _isMaterial = true;
      _unit = 'ml';
    }
    final durationHours = widget.existing?.durationHours ?? 0;
    if (durationHours >= 24 && durationHours % 24 == 0) {
      _durationUnit = 'hari';
    }
    _durationCtrl = TextEditingController(
      text:
          _durationUnit == 'hari' ? '${durationHours ~/ 24}' : '$durationHours',
    );
    _stock = TextEditingController(
        text: widget.existing != null ? '${widget.existing!.stock}' : '0');
    _buy = TextEditingController(
        text: widget.existing != null
            ? formatCurrencyInput(_isMaterial
                ? widget.existing!.buyPrice * widget.existing!.stock
                : widget.existing!.buyPrice)
            : '');
    _minStock = TextEditingController(
        text: widget.existing != null ? '${widget.existing!.minStock}' : '5');
    _loadRecipes();
    _loadProductSuppliers();
    _loadCustomUnits();
  }

  @override
  void dispose() {
    _name.dispose();
    _sell.dispose();
    _buy.dispose();
    _stock.dispose();
    _minStock.dispose();
    _desc.dispose();
    _sku.dispose();
    _barcode.dispose();
    _durationCtrl.dispose();
    for (final line in _recipeLines) {
      line.dispose();
    }
    super.dispose();
  }

  bool _sameUnit(String a, String b) =>
      a.trim().toLowerCase() == b.trim().toLowerCase();

  bool _isDefaultUnitOption(String unit) {
    final normalized = unit.trim();
    if (normalized.isEmpty) return false;
    final base = _isMaterial
        ? const [
            'gram',
            'kg',
            'ml',
            'liter',
            'pcs',
            'meter',
            'm2',
            'roll',
            'pack',
            'botol',
          ]
        : const [
            'kg',
            'gram',
            'ml',
            'liter',
            'pcs',
            'm2',
            'pasang',
            'layanan',
          ];
    return base.any((item) => _sameUnit(item, normalized));
  }

  bool _containsUnit(Iterable<String> units, String unit) =>
      units.any((item) => _sameUnit(item, unit));

  List<String> _dedupeCustomUnits(Iterable<String> units) {
    final result = <String>[];
    for (final raw in units) {
      final unit = raw.trim();
      if (unit.isEmpty ||
          _isDefaultUnitOption(unit) ||
          _containsUnit(result, unit)) {
        continue;
      }
      result.add(unit);
    }
    return result;
  }

  Future<void> _loadCustomUnits() async {
    final prefs = await SharedPreferences.getInstance();
    final saved =
        prefs.getStringList(_customservisUnitsPrefsKey) ?? const <String>[];
    final units = _dedupeCustomUnits(saved);
    final current = _unit.trim();
    if (current.isNotEmpty &&
        !_isDefaultUnitOption(current) &&
        !_containsUnit(units, current)) {
      units.add(current);
      await prefs.setStringList(_customservisUnitsPrefsKey, units);
    }
    if (!mounted) return;
    setState(() => _customUnits = units);
  }

  Future<void> _saveCustomUnits() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_customservisUnitsPrefsKey, _customUnits);
  }

  void _selectUnit(String value) {
    final unit = value.trim();
    if (unit.isEmpty) return;
    var shouldSave = false;
    setState(() {
      _unit = unit;
      _isHardware = unit.toLowerCase() == 'kg';
      if (!_isDefaultUnitOption(unit) && !_containsUnit(_customUnits, unit)) {
        _customUnits = [..._customUnits, unit];
        shouldSave = true;
      }
    });
    if (shouldSave) {
      _saveCustomUnits();
    }
  }

  bool _canDeleteCustomUnit(String value) {
    final unit = value.trim();
    if (unit.isEmpty || _sameUnit(unit, _unit)) return false;
    return _containsUnit(_customUnits, unit);
  }

  void _deleteCustomUnit(String value) {
    final unit = value.trim();
    if (!_canDeleteCustomUnit(unit)) return;
    setState(() {
      _customUnits =
          _customUnits.where((item) => !_sameUnit(item, unit)).toList();
    });
    _saveCustomUnits();
  }

  int _resolvedCategoryId(List<Category> categories) {
    if (categories.any((c) => c.id == _catId)) return _catId;
    final defaultCategory = categories.where(
      (c) => DBHelper.isDefaultCategoryName(c.name),
    );
    if (defaultCategory.isNotEmpty) {
      return defaultCategory.first.id ?? _catId;
    }
    return categories.isNotEmpty ? (categories.first.id ?? _catId) : _catId;
  }

  Category? _selectedCategory(List<Category> categories) {
    if (categories.isEmpty) return null;
    final resolvedId = _resolvedCategoryId(categories);
    return categories.firstWhere(
      (c) => c.id == resolvedId,
      orElse: () => categories.first,
    );
  }

  void _syncCategoryId(List<Category> categories) {
    final resolvedId = _resolvedCategoryId(categories);
    if (_catId != resolvedId) _catId = resolvedId;
  }

  Future<void> _loadProductSuppliers() async {
    final data = await DBHelper.instance.getAllSuppliers();
    if (!mounted) return;
    setState(() {
      _suppliers = data;
      if (_supplierId != null &&
          !_suppliers.any((supplier) => supplier.id == _supplierId)) {
        _supplierId = null;
      }
    });
  }

  Supplier? get _selectedSupplier {
    final id = _supplierId;
    if (id == null) return null;
    for (final supplier in _suppliers) {
      if (supplier.id == id) return supplier;
    }
    return null;
  }

  bool get _usesStock => _isMaterial || _trackStock;

  bool get _wasStockManaged => widget.existing?.hasStockManagement == 1;

  bool get _canEditOpeningStock => widget.existing == null || !_wasStockManaged;

  String get _stockUnitLabel {
    final unit = _unit.trim();
    return unit.isEmpty ? 'unit' : unit;
  }

  String _dateOnly(DateTime value) {
    return '${value.year}-${value.month.toString().padLeft(2, '0')}-${value.day.toString().padLeft(2, '0')}';
  }

  void _showFormSnack(String message, {Color color = Colors.black87}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    ));
  }

  void _setStockTracking(bool value) {
    setState(() {
      _trackStock = value;
      if (!value) {
        _supplierId = null;
        _expiryDate = null;
      }
    });
  }

  Future<void> _openStockCorrection() async {
    final id = widget.existing?.id;
    if (id == null) {
      _showFormSnack('Simpan item terlebih dahulu sebelum koreksi stok.');
      return;
    }

    final latest = await DBHelper.instance.getProductById(id);
    if (!mounted) return;
    if (latest == null || latest.hasStockManagement != 1) {
      _showFormSnack(
          'Koreksi stok hanya tersedia untuk item dengan manajemen stok aktif.');
      return;
    }

    _dismissKeyboard();
    final actualStock = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _StockCorrectionSheet(
        product: latest,
        unitLabel:
            latest.unit.trim().isEmpty ? _stockUnitLabel : latest.unit.trim(),
      ),
    );
    if (!mounted || actualStock == null) return;

    final diff = actualStock - latest.stock;
    if (diff == 0) {
      _showFormSnack('Stok tidak berubah.');
      return;
    }

    final now = DateTime.now();
    final staff = ref.read(activeStaffProvider);
    await ref.read(productsProvider.notifier).recordStockLog(StockLog(
          productId: id,
          type: diff > 0 ? 'in' : 'out',
          qty: diff.abs(),
          date: now.toIso8601String(),
          stockName: 'Koreksi Stok',
          entryDate: _dateOnly(now),
          employeeName: staff?.name ?? 'Kasir',
        ));

    final updated = await DBHelper.instance.getProductById(id);
    if (!mounted) return;
    if (updated != null) {
      setState(() {
        _stock.text = '${updated.stock}';
        _minStock.text = '${updated.minStock}';
        _supplierId = updated.supplierId;
        final rawExpiry = updated.expiryDate?.trim();
        _expiryDate = rawExpiry == null || rawExpiry.isEmpty
            ? null
            : DateTime.tryParse(rawExpiry);
      });
    } else {
      setState(() => _stock.text = '$actualStock');
    }
    _showFormSnack('Koreksi stok berhasil dicatat.');
  }

  void _dismissKeyboard() {
    FocusManager.instance.primaryFocus?.unfocus();
    SystemChannels.textInput.invokeMethod<void>('TextInput.hide');
  }

  Future<void> _showSupplierPicker() async {
    _dismissKeyboard();
    if (_suppliers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content:
            Text('Belum ada supplier. Tambahkan supplier terlebih dahulu.'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
      ));
      return;
    }

    final selected = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _ProductSupplierPickerSheet(
        suppliers: _suppliers,
        selectedId: _supplierId,
      ),
    );
    if (!mounted || selected == null) return;
    _dismissKeyboard();
    setState(() => _supplierId = selected <= 0 ? null : selected);
  }

  Future<void> _showAddSupplierSheet() async {
    _dismissKeyboard();
    Supplier? createdSupplier;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => SupplierFormSheet(
        onSaved: (supplier) {
          createdSupplier = supplier;
          Navigator.of(sheetContext).pop();
        },
      ),
    );
    if (!mounted) return;

    await _loadProductSuppliers();
    final newId = createdSupplier?.id;
    if (!mounted || newId == null) return;
    _dismissKeyboard();
    setState(() => _supplierId = newId);
  }

  Future<void> _loadRecipes() async {
    final id = widget.existing?.id;
    if (id == null) return;
    setState(() => _recipesLoading = true);
    try {
      final recipes = await DBHelper.instance.getProductRecipes(id);
      if (!mounted) return;
      setState(() {
        _recipeLines
          ..clear()
          ..addAll(recipes.map(
            (r) => _RecipeDraft(
              materialProductId: r.materialProductId,
              qty: r.qtyPerUnit.toString().replaceAll(RegExp(r'\.0$'), ''),
            ),
          ));
      });
    } finally {
      if (mounted) setState(() => _recipesLoading = false);
    }
  }

  void _addRecipeLine() {
    setState(() => _recipeLines.add(_RecipeDraft()));
  }

  Future<void> _openAddMaterialFromRecipe() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const ProductFormScreen(forceMaterial: true),
      ),
    );
  }

  void _removeRecipeLine(int index) {
    setState(() {
      final removed = _recipeLines.removeAt(index);
      removed.dispose();
    });
  }

  void _save() async {
    if (!_fk.currentState!.validate()) return;
    setState(() => _loading = true);
    final categories = ref.read(categoriesProvider);
    final selectedCategory = _selectedCategory(categories);
    final categoryId = await DBHelper.instance.resolveProductCategoryId(
      categoryId: selectedCategory?.id ?? _catId,
      categoryName: selectedCategory?.name,
    );
    final usesStock = _usesStock;
    final requestedStock = usesStock ? (int.tryParse(_stock.text) ?? 0) : 0;
    final shouldRecordOpeningStock = widget.existing != null &&
        usesStock &&
        !_wasStockManaged &&
        requestedStock > 0;
    final stockForSave =
        !usesStock ? 0 : (shouldRecordOpeningStock ? 0 : requestedStock);
    final totalBuyPrice = usesStock ? parseCurrencyInput(_buy.text) : 0;
    final buyPrice = _isMaterial && requestedStock > 0
        ? (totalBuyPrice / requestedStock).round()
        : totalBuyPrice;
    final expiryDateValue = usesStock && _expiryDate != null
        ? _expiryDate!.toIso8601String().substring(0, 10)
        : null;
    final barcodeValue = _barcode.text.trim().isNotEmpty
        ? _barcode.text.trim()
        : (widget.existing?.barcode ?? '').trim();
    final p = Product(
      id: widget.existing?.id,
      name: _name.text.trim(),
      categoryId: categoryId,
      buyPrice: buyPrice,
      sellPrice: parseCurrencyInput(_sell.text),
      stock: stockForSave,
      unit: _unit,
      minStock: usesStock ? (int.tryParse(_minStock.text) ?? 0) : 0,
      createdAt: widget.existing?.createdAt ?? DateTime.now().toIso8601String(),
      imagePath: _imagePath,
      description: _desc.text.trim(),
      sku: _sku.text.trim(),
      barcode: barcodeValue,
      hasStockManagement: usesStock ? 1 : 0,
      hasWholesale: 0,
      wholesaleMinQty: 0,
      wholesalePrice: 0,
      hasExtraPopup: _hasExtraPopup ? 1 : 0,
      isHardware: _isHardware ? 1 : 0,
      durationHours: _durationHoursForSave,
      isExtra: 0,
      isMaterial: _isMaterial ? 1 : 0,
      supplierId: usesStock ? _supplierId : null,
      expiryDate: expiryDateValue,
    );
    final notifier = ref.read(productsProvider.notifier);
    final int savedProductId;
    Product savedProduct = p;
    if (widget.existing == null) {
      savedProductId = await notifier.addProduct(p);
      savedProduct = p.copyWith(id: savedProductId);
      if ((savedProduct.barcode ?? '').trim().isEmpty) {
        savedProduct = savedProduct.copyWith(
          barcode: _autoBarcodeForProductId(
            savedProductId,
            isMaterial: _isMaterial,
          ),
        );
        await notifier.updateProduct(savedProduct);
      }
    } else {
      savedProductId = widget.existing!.id!;
      savedProduct = p.copyWith(id: savedProductId);
      if ((savedProduct.barcode ?? '').trim().isEmpty) {
        savedProduct = savedProduct.copyWith(
          barcode: _autoBarcodeForProductId(
            savedProductId,
            isMaterial: _isMaterial,
          ),
        );
      }
      await notifier.updateProduct(savedProduct);
    }
    if (shouldRecordOpeningStock) {
      final now = DateTime.now();
      final staff = ref.read(activeStaffProvider);
      await notifier.recordStockLog(StockLog(
        productId: savedProductId,
        type: 'in',
        qty: requestedStock,
        date: now.toIso8601String(),
        stockName: 'Stok Awal',
        entryDate: _dateOnly(now),
        expiryDate: expiryDateValue,
        employeeName: staff?.name ?? 'Kasir',
      ));
    }
    _barcode.text = savedProduct.barcode ?? '';
    final recipes = (_isMaterial || _trackStock)
        ? <ProductRecipe>[]
        : _recipeLines
            .where((line) =>
                line.materialProductId != null &&
                (double.tryParse(line.qtyCtrl.text.replaceAll(',', '.')) ?? 0) >
                    0)
            .map((line) => ProductRecipe(
                  serviceProductId: savedProductId,
                  materialProductId: line.materialProductId!,
                  qtyPerUnit:
                      double.tryParse(line.qtyCtrl.text.replaceAll(',', '.')) ??
                          0,
                  createdAt: DateTime.now().toIso8601String(),
                ))
            .toList();
    await notifier.replaceProductRecipes(savedProductId, recipes);
    if (mounted) {
      setState(() => _loading = false);
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(widget.existing == null
            ? (_isMaterial
                ? 'Bahan baku berhasil ditambahkan!'
                : 'Layanan berhasil ditambahkan!')
            : (_isMaterial
                ? 'Bahan baku berhasil diperbarui!'
                : 'Layanan berhasil diperbarui!')),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
    }
  }

  Product _productForBarcodeAction() {
    final existing = widget.existing!;
    final parsedPrice = parseCurrencyInput(_sell.text);
    final barcode = _barcode.text.trim().isNotEmpty
        ? _barcode.text.trim()
        : (existing.barcode ?? '').trim();
    return existing.copyWith(
      name: _name.text.trim().isEmpty ? existing.name : _name.text.trim(),
      sellPrice: parsedPrice > 0 ? parsedPrice : existing.sellPrice,
      sku: _sku.text.trim().isEmpty ? existing.sku : _sku.text.trim(),
      barcode: barcode,
    );
  }

  Future<void> _showDownloadBarcodeDialog(
      BuildContext context, Product p) async {
    final isMaterialItem = p.isMaterial == 1;
    final itemType = isMaterialItem ? 'bahan baku' : 'layanan';
    final itemTypeTitle = isMaterialItem ? 'Bahan Baku' : 'Layanan';
    final effectiveBarcode = _resolvedBarcodeForProduct(p);
    if (effectiveBarcode.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(
            '$itemTypeTitle belum memiliki ID barcode. Simpan $itemType dulu.'),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
      return;
    }

    final wasGenerated = (p.barcode ?? '').trim().isEmpty;
    if (wasGenerated && p.id != null) {
      await ref
          .read(productsProvider.notifier)
          .updateProduct(p.copyWith(barcode: effectiveBarcode));
      if (!mounted) return;
      setState(() => _barcode.text = effectiveBarcode);
    }

    final effectiveProduct = p.copyWith(barcode: effectiveBarcode);
    final sizeOptions = [
      {
        'label': 'Kecil (200x90)',
        'w': 200.0,
        'h': 90.0,
        'thermalH': 48,
        'thermalW': 2,
      },
      {
        'label': 'Sedang (280x120)',
        'w': 280.0,
        'h': 120.0,
        'thermalH': 72,
        'thermalW': 2,
      },
      {
        'label': 'Besar (360x160)',
        'w': 360.0,
        'h': 160.0,
        'thermalH': 96,
        'thermalW': 3,
      },
    ];
    int selectedSize = 1;
    bool isPrinting = false;
    bool isDownloading = false;
    String? printStatus;

    if (!context.mounted) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) {
          final sw = sizeOptions[selectedSize]['w'] as double;
          final sh = sizeOptions[selectedSize]['h'] as double;
          return Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.zero),
            ),
            padding: EdgeInsets.fromLTRB(
                20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 28),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.zero,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text('Download Barcode $itemTypeTitle',
                      style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87)),
                  const SizedBox(height: 6),
                  Text(
                    'Barcode untuk $itemType "${effectiveProduct.name}" dapat diunduh atau dicetak untuk scanner fisik.',
                    style: const TextStyle(fontSize: 13, color: Colors.black54),
                  ),
                  if (wasGenerated) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 7),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEFF8FF),
                        border: Border.all(color: const Color(0xFF93C5FD)),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.auto_awesome_rounded,
                              color: Color(0xFF2563EB), size: 15),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Barcode dibuat otomatis: $effectiveBarcode',
                              style: const TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF1D4ED8),
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                  Center(
                    child: RepaintBoundary(
                      key: _barcodePreviewKey,
                      child: Container(
                        width: sw,
                        padding: const EdgeInsets.symmetric(
                            vertical: 12, horizontal: 10),
                        color: Colors.white,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              effectiveProduct.name,
                              style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87),
                              textAlign: TextAlign.center,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 8),
                            import_barcode_widget.BarcodeWidget(
                              barcode: import_barcode_widget.Barcode.code128(),
                              data: effectiveBarcode,
                              height: sh * 0.6,
                              width: sw * 0.88,
                              drawText: false,
                              errorBuilder: (_, __) => const Text(
                                'Barcode Invalid',
                                style:
                                    TextStyle(color: Colors.red, fontSize: 10),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              effectiveBarcode,
                              style: const TextStyle(
                                  fontSize: 10,
                                  letterSpacing: 2.5,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black87),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text('Ukuran Barcode',
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Colors.black54)),
                  const SizedBox(height: 8),
                  Row(
                    children: List.generate(sizeOptions.length, (i) {
                      final isSelected = selectedSize == i;
                      return Expanded(
                        child: GestureDetector(
                          onTap: () => setModalState(() => selectedSize = i),
                          child: Container(
                            margin: EdgeInsets.only(
                                right: i < sizeOptions.length - 1 ? 8 : 0),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? _kBrand.withValues(alpha: 0.1)
                                  : Colors.transparent,
                              border: Border.all(
                                  color: isSelected
                                      ? _kBrand
                                      : Colors.grey.shade300),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Text(
                              sizeOptions[i]['label'] as String,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: isSelected
                                      ? FontWeight.bold
                                      : FontWeight.normal,
                                  color: isSelected ? _kBrand : Colors.black87),
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                  const SizedBox(height: 20),
                  if (printStatus != null) ...[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: isPrinting
                            ? const Color(0xFFEFF6FF)
                            : const Color(0xFFF8FAFC),
                        border: Border.all(color: const Color(0xFFCBD5E1)),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Row(
                        children: [
                          if (isPrinting)
                            const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: _kBrand,
                              ),
                            )
                          else
                            const Icon(Icons.info_outline_rounded,
                                size: 17, color: Color(0xFF64748B)),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              printStatus!,
                              style: const TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF334155),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: OutlinedButton.icon(
                      icon: isPrinting
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: _kBrand,
                              ),
                            )
                          : const Icon(Icons.print_rounded, size: 18),
                      label: Text(
                        isPrinting
                            ? 'Memproses Cetak...'
                            : 'Cetak Barcode Thermal',
                        style: const TextStyle(
                            fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                      onPressed: isPrinting
                          ? null
                          : () async {
                              setModalState(() {
                                isPrinting = true;
                                printStatus = 'Mengecek printer thermal...';
                              });
                              await _printBarcodeThermal(
                                effectiveProduct.copyWith(
                                    barcode: effectiveBarcode),
                                thermalBarcodeHeight: sizeOptions[selectedSize]
                                    ['thermalH'] as int,
                                thermalBarcodeWidth: sizeOptions[selectedSize]
                                    ['thermalW'] as int,
                                onProgress: (message) {
                                  if (!ctx.mounted) return;
                                  setModalState(() => printStatus = message);
                                },
                              );
                              if (!ctx.mounted) return;
                              setModalState(() => isPrinting = false);
                            },
                      style: OutlinedButton.styleFrom(
                        foregroundColor: _kBrand,
                        side: const BorderSide(color: _kBrand),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton.icon(
                      icon: isDownloading
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Icon(Icons.download_rounded, size: 18),
                      label: Text(
                        isDownloading
                            ? 'Menyiapkan File...'
                            : 'Download Gambar Barcode',
                        style: const TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                      onPressed: isDownloading
                          ? null
                          : () async {
                              setModalState(() => isDownloading = true);
                              final saved = await _downloadBarcodeImage(
                                effectiveProduct.copyWith(
                                    barcode: effectiveBarcode),
                              );
                              if (!ctx.mounted) return;
                              if (saved) Navigator.pop(ctx);
                              setModalState(() => isDownloading = false);
                            },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _printBarcodeThermal(
    Product p, {
    required int thermalBarcodeHeight,
    required int thermalBarcodeWidth,
    LabelPrintProgress? onProgress,
  }) async {
    try {
      ScaffoldMessenger.of(context).clearSnackBars();
      final bluetoothMac = await _prepareBarcodeThermalPrinter(
        onProgress: onProgress,
      );
      if (_isMobilePlatform && bluetoothMac == null) {
        onProgress?.call('Printer thermal belum dipilih.');
        return;
      }

      final settings = ref.read(labelSettingsProvider).copyWith(
            showName: true,
            showPrice: false,
            showSku: false,
            showBarcode: true,
            showStoreName: false,
            showDate: false,
            priceAlign: 'center',
            fontSize: 'normal',
            thermalBarcodeHeight: thermalBarcodeHeight,
            thermalBarcodeWidth: thermalBarcodeWidth,
          );
      final ok = await LabelPrintService.printAdvancedLabels(
        [ProductPrintItem(product: p, qty: 1)],
        settings,
        onProgress: onProgress,
        bluetoothMacAddress: bluetoothMac,
      );
      if (!mounted) return;
      onProgress?.call(ok
          ? 'Barcode berhasil dikirim ke printer.'
          : 'Printer tidak merespon.');
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(ok
            ? 'Barcode dikirim ke printer thermal.'
            : 'Printer tidak merespon.'),
        backgroundColor: ok ? Colors.green.shade700 : AppColors.danger,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        duration: const Duration(seconds: 3),
      ));
    } catch (e) {
      if (!mounted) return;
      final message = LabelPrintService.errorMessage(e);
      onProgress?.call(message);
      if (LabelPrintService.isPrinterSetupError(e)) {
        ScaffoldMessenger.of(context).clearSnackBars();
        final picked = await _showBarcodeBluetoothPrinterPicker(
          title: 'Pilih Printer Thermal',
          message:
              'Printer belum siap untuk mencetak barcode. Pilih printer yang sudah dipasangkan dengan HP.',
        );
        if (!mounted) return;
        onProgress?.call(picked
            ? 'Printer dipilih. Tekan Cetak Barcode Thermal lagi.'
            : 'Printer belum dipilih.');
        return;
      }
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(message),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        duration: const Duration(seconds: 3),
      ));
    }
  }

  Future<String?> _prepareBarcodeThermalPrinter({
    LabelPrintProgress? onProgress,
  }) async {
    if (!_isMobilePlatform) return null;

    await [Permission.bluetoothScan, Permission.bluetoothConnect].request();
    final bluetoothOn = await PrintBluetoothThermal.bluetoothEnabled;
    if (!bluetoothOn) {
      onProgress?.call('Bluetooth belum aktif.');
      if (mounted) await _showBarcodeBluetoothRequiredSheet();
      return null;
    }

    final prefs = await SharedPreferences.getInstance();
    var mac = prefs.getString('struk_printerMac') ?? '';
    if (mac.isEmpty) {
      onProgress?.call('Pilih printer thermal...');
      final picked = await _showBarcodeBluetoothPrinterPicker(
        title: 'Pilih Printer Thermal',
        message:
            'Pilih printer bluetooth yang akan dipakai untuk mencetak barcode layanan.',
      );
      if (!picked) return null;
      mac = prefs.getString('struk_printerMac') ?? '';
    }

    try {
      await LabelPrintService.ensureBluetoothConnected(
        macPrinterAddress: mac,
        onProgress: onProgress,
      );
      return mac;
    } catch (_) {
      onProgress?.call('Printer belum siap. Pilih ulang printer thermal.');
      final picked = await _showBarcodeBluetoothPrinterPicker(
        title: 'Pilih Ulang Printer Thermal',
        message:
            'Printer tersimpan tidak merespon. Pilih printer yang sedang menyala dan berada dekat dengan kasir.',
      );
      if (!picked) return null;
      return prefs.getString('struk_printerMac') ?? '';
    }
  }

  Future<bool> _showBarcodeBluetoothPrinterPicker({
    required String title,
    required String message,
  }) async {
    if (!_isMobilePlatform || !mounted) return false;

    ScaffoldMessenger.of(context).clearSnackBars();
    await [Permission.bluetoothScan, Permission.bluetoothConnect].request();
    final bluetoothOn = await PrintBluetoothThermal.bluetoothEnabled;
    if (!bluetoothOn) {
      if (mounted) await _showBarcodeBluetoothRequiredSheet();
      return false;
    }

    if (!mounted) return false;
    final navigator = Navigator.of(context);
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(color: _kBrand),
      ),
    );

    List<BluetoothInfo> printers = [];
    try {
      printers = await PrintBluetoothThermal.pairedBluetooths;
    } catch (_) {}
    if (!mounted) return false;
    navigator.pop();

    if (printers.isEmpty) {
      if (!mounted) return false;
      await showModalBottomSheet<void>(
        context: context,
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        builder: (ctx) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 18, 22, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 44,
                    height: 4,
                    color: const Color(0xFFE5E7EB),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Printer Belum Dipasangkan',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Pasangkan printer thermal di pengaturan Bluetooth HP, lalu kembali ke aplikasi dan coba cetak lagi.',
                  style: TextStyle(
                    fontSize: 13.5,
                    color: Color(0xFF475569),
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  height: 46,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero,
                      ),
                    ),
                    child: const Text(
                      'Mengerti',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
      return false;
    }

    final prefs = await SharedPreferences.getInstance();
    final savedMac = prefs.getString('struk_printerMac') ?? '';
    if (!mounted) return false;
    final selected = await showModalBottomSheet<BluetoothInfo>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 4,
                  color: const Color(0xFFE5E7EB),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                title,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 6),
              Text(
                message,
                style: const TextStyle(
                  fontSize: 13.5,
                  color: Color(0xFF475569),
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 16),
              Flexible(
                child: SingleChildScrollView(
                  child: Column(
                    children: printers.map((printer) {
                      final isSaved = printer.macAdress == savedMac;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: InkWell(
                          onTap: () => Navigator.pop(ctx, printer),
                          child: Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: isSaved
                                  ? _kBrand.withValues(alpha: 0.08)
                                  : const Color(0xFFF8FAFC),
                              border: Border.all(
                                color:
                                    isSaved ? _kBrand : const Color(0xFFE2E8F0),
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 42,
                                  height: 42,
                                  color: _kBrand.withValues(alpha: 0.10),
                                  child: const Icon(
                                    Icons.print_rounded,
                                    color: _kBrand,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        printer.name,
                                        style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w800,
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        printer.macAdress,
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: Color(0xFF64748B),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (isSaved)
                                  const Padding(
                                    padding: EdgeInsets.only(right: 8),
                                    child: Text(
                                      'Terakhir',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: _kBrand,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ),
                                const Icon(Icons.chevron_right_rounded,
                                    color: Color(0xFF94A3B8)),
                              ],
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );

    if (selected == null) return false;
    await prefs.setString('struk_printerMac', selected.macAdress);
    await prefs.setString('struk_printerName', selected.name);
    return true;
  }

  Future<void> _showBarcodeBluetoothRequiredSheet() async {
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 4,
                  color: const Color(0xFFE5E7EB),
                ),
              ),
              const SizedBox(height: 18),
              const Row(
                children: [
                  Icon(Icons.bluetooth_disabled_rounded,
                      color: AppColors.danger),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Bluetooth Belum Aktif',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'Aktifkan Bluetooth di HP terlebih dahulu. Setelah aktif, tekan Cetak Barcode Thermal lagi untuk memilih printer.',
                style: TextStyle(
                  fontSize: 13.5,
                  color: Color(0xFF475569),
                  height: 1.45,
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                height: 46,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(ctx),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kBrand,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                  ),
                  child: const Text(
                    'Saya Aktifkan Dulu',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _downloadBarcodeImage(Product p) async {
    try {
      await Future.delayed(const Duration(milliseconds: 80));
      final boundary = _barcodePreviewKey.currentContext?.findRenderObject()
          as RenderRepaintBoundary?;
      if (boundary == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content:
                Text('Gagal menangkap gambar barcode. Coba buka dialog lagi.'),
            backgroundColor: AppColors.danger,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ));
        }
        return false;
      }

      final image = await boundary.toImage(pixelRatio: 3.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) throw Exception('Gagal mengekspor gambar.');
      final pngBytes = byteData.buffer.asUint8List();
      final safeName =
          p.name.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_').toLowerCase();
      final fileName = 'barcode_$safeName.png';

      final tempDir = await getTemporaryDirectory();
      final tempFile = File('${tempDir.path}/$fileName');
      await tempFile.writeAsBytes(pngBytes);

      final outputPath = await FilePicker.platform.saveFile(
        dialogTitle: 'Simpan Barcode',
        fileName: fileName,
        type: FileType.image,
        bytes: _isMobilePlatform ? pngBytes : null,
      );

      if (outputPath != null && !_isMobilePlatform) {
        await tempFile.copy(outputPath);
      }

      if (!mounted || outputPath == null) return false;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Barcode disimpan ke: $outputPath',
            maxLines: 2, overflow: TextOverflow.ellipsis),
        backgroundColor: Colors.green.shade700,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
      return true;
    } catch (e) {
      if (!mounted) return false;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Gagal menyimpan barcode: ${e.toString()}'),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final cats = ref.watch(categoriesProvider);
    _syncCategoryId(cats);
    final allProducts = ref.watch(productsProvider);
    final materialProducts = allProducts
        .where((p) =>
            p.hasStockManagement == 1 &&
            p.isMaterial == 1 &&
            p.id != null &&
            p.id != widget.existing?.id)
        .toList();
    final mq = MediaQuery.of(context);
    final isLandscapeMode = mq.orientation == Orientation.landscape;
    final useWideServiceLayout = isLandscapeMode && mq.size.width >= 900;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _kBrand, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isMaterial
              ? (widget.existing == null
                  ? 'Tambah Bahan Baku'
                  : 'Ubah Bahan Baku')
              : (widget.existing == null ? 'Tambah Layanan' : 'Ubah Layanan'),
          style: const TextStyle(
              fontSize: 17, fontWeight: FontWeight.w600, color: Colors.black87),
        ),
        actions: [
          if (widget.existing != null)
            IconButton(
              tooltip: 'Download Barcode',
              icon:
                  const Icon(Icons.qr_code_2_rounded, color: _kBrand, size: 24),
              onPressed: () => _showDownloadBarcodeDialog(
                context,
                _productForBarcodeAction(),
              ),
            ),
        ],
      ),
      body: Form(
        key: _fk,
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: useWideServiceLayout
              ? Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    //  Left Column
                    Expanded(
                      flex: 2,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GestureDetector(
                            onTap: () {
                              if (Platform.isWindows) {
                                _pickImage(ImageSource.gallery);
                              } else {
                                _showImageSourceDialog();
                              }
                            },
                            child: Container(
                              width: double.infinity,
                              height: 120, // Smaller in landscape
                              decoration: BoxDecoration(
                                color: const Color(0xFFEEF2F7),
                                borderRadius: BorderRadius.zero,
                                border: Border.all(
                                    color: _imagePath != null
                                        ? _kBrand
                                        : Colors.grey.shade300),
                              ),
                              clipBehavior: Clip.antiAlias,
                              child: _imagePath != null &&
                                      File(_imagePath!).existsSync()
                                  ? Stack(
                                      fit: StackFit.expand,
                                      children: [
                                        Image.file(File(_imagePath!),
                                            fit: BoxFit.cover),
                                        Positioned(
                                          bottom: 0,
                                          left: 0,
                                          right: 0,
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 4),
                                            color: Colors.black54,
                                            child: const Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Icon(Icons.edit_rounded,
                                                    color: Colors.white,
                                                    size: 12),
                                                SizedBox(width: 4),
                                                Text('Ganti Foto',
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 11,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    )
                                  : const Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.add_photo_alternate_outlined,
                                            color: Colors.grey, size: 28),
                                        Text('Unggah Foto',
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.grey)),
                                      ],
                                    ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          _formField(
                              _isMaterial
                                  ? 'Nama Bahan Baku *'
                                  : 'Nama Layanan *',
                              _name,
                              hint: _isMaterial
                                  ? 'Contoh: Timah Solder'
                                  : 'Contoh: Ganti LCD HP',
                              validator: (v) =>
                                  (v ?? '').isEmpty ? 'Wajib diisi' : null),
                          if (!_isMaterial) ...[
                            const SizedBox(height: 12),
                            ModernPicker<Category>(
                              label: 'Kategori',
                              value: _selectedCategory(cats),
                              items: cats,
                              itemLabel: (c) => c.name ?? '-',
                              onChanged: (v) =>
                                  setState(() => _catId = v.id ?? 1),
                            ),
                          ],
                          if (!_isMaterial) ...[
                            const SizedBox(height: 12),
                            _serviceSkuField(),
                          ],
                          const SizedBox(height: 12),
                          ModernPicker<String>(
                            label: 'Software',
                            value: _unit,
                            items: _unitOptions,
                            itemLabel: (u) => u,
                            searchable: true,
                            searchHint: 'Cari atau tambah software...',
                            allowCustomString: true,
                            customStringLabel: 'Tambah Software Manual',
                            customStringHint: 'Contoh: karung, dus, meter',
                            onChanged: _selectUnit,
                            canDeleteItem: _canDeleteCustomUnit,
                            onDeleteItem: _deleteCustomUnit,
                          ),
                          const SizedBox(height: 6),
                          _buildSoftwareHelper(_unit),
                          if (!_isMaterial) ...[
                            const SizedBox(height: 12),
                            _durationField(),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(width: 24),
                    //  Right Column
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (_isMaterial) _materialInfoBanner(),
                          const SizedBox(height: 12),
                          if (_isMaterial || !_trackStock) ...[
                            Row(
                              children: [
                                Expanded(
                                  child: _formField(
                                    _isMaterial
                                        ? 'Total Harga Beli'
                                        : 'Harga Layanan *',
                                    _isMaterial ? _buy : _sell,
                                    hint: _isMaterial ? 'Contoh: 100000' : '0',
                                    isNum: true,
                                    isMoney: true,
                                    helper: _isMaterial
                                        ? _materialTotalPriceHelper(_unit)
                                        : null,
                                    validator: !_isMaterial
                                        ? (v) {
                                            if ((v ?? '').isEmpty) {
                                              return 'Wajib';
                                            }
                                            return null;
                                          }
                                        : null,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                          ],
                          _formField(
                              _isMaterial ? 'Catatan' : 'Deskripsi', _desc,
                              hint: _isMaterial
                                  ? 'Contoh: beli jerigen 5 liter, simpan di rak belakang'
                                  : 'Keterangan tambahan layanan...'),
                          if (_isMaterial) ...[
                            const SizedBox(height: 12),
                            _stockFields(),
                            const SizedBox(height: 12),
                            _supplierPicker(),
                            const SizedBox(height: 12),
                            _expiryDateField(),
                            const SizedBox(height: 12),
                            _inventoryCodeFields(),
                          ],
                          if (!_isMaterial) ...[
                            const SizedBox(height: 12),
                            _desktopservisSettingsPanel(materialProducts),
                          ],
                        ],
                      ),
                    ),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Standard Portrait Layout
                    GestureDetector(
                      onTap: () {
                        if (Platform.isWindows) {
                          _pickImage(ImageSource.gallery);
                        } else {
                          _showImageSourceDialog();
                        }
                      },
                      child: Container(
                        width: double.infinity,
                        height: 140,
                        decoration: BoxDecoration(
                          color: const Color(0xFFEEF2F7),
                          borderRadius: BorderRadius.zero,
                          border: Border.all(
                              color: _imagePath != null
                                  ? _kBrand
                                  : Colors.grey.shade300),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: _imagePath != null &&
                                File(_imagePath!).existsSync()
                            ? Stack(
                                fit: StackFit.expand,
                                children: [
                                  Image.file(File(_imagePath!),
                                      fit: BoxFit.cover),
                                  Positioned(
                                    bottom: 0,
                                    left: 0,
                                    right: 0,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 6),
                                      color: Colors.black54,
                                      child: const Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.edit_rounded,
                                              color: Colors.white, size: 14),
                                          SizedBox(width: 4),
                                          Text('Ganti Gambar',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              )
                            : const Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.add_photo_alternate_outlined,
                                      color: Colors.grey, size: 36),
                                  SizedBox(height: 8),
                                  Text('Unggah Foto Produk',
                                      style: TextStyle(
                                          fontSize: 13, color: Colors.grey)),
                                  Text('Kamera atau Galeri',
                                      style: TextStyle(
                                          fontSize: 11, color: Colors.grey)),
                                ],
                              ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    _formField(
                        _isMaterial ? 'Nama Bahan Baku *' : 'Nama Layanan *',
                        _name,
                        hint: _isMaterial
                            ? 'Contoh: Timah Solder'
                            : 'Contoh: Ganti LCD HP',
                        validator: (v) =>
                            (v ?? '').isEmpty ? 'Wajib diisi' : null),
                    const SizedBox(height: 12),
                    _formField(_isMaterial ? 'Catatan' : 'Deskripsi', _desc,
                        hint: _isMaterial
                            ? 'Contoh: beli jerigen 5 liter, simpan di rak belakang'
                            : 'Deskripsi singkat layanan'),
                    if (!_isMaterial && !_trackStock) ...[
                      const SizedBox(height: 12),
                      _serviceSkuField(),
                    ],
                    if (!_isMaterial) ...[
                      const SizedBox(height: 12),
                      ModernPicker<Category>(
                        label: 'Kategori',
                        value: _selectedCategory(cats),
                        items: cats,
                        itemLabel: (c) => c.name ?? '-',
                        onChanged: (v) => setState(() => _catId = v.id ?? 1),
                      ),
                    ],
                    const SizedBox(height: 12),
                    ModernPicker<String>(
                      label: 'Software',
                      value: _unit,
                      items: _unitOptions,
                      itemLabel: (u) => u,
                      searchable: true,
                      searchHint: 'Cari atau tambah software...',
                      allowCustomString: true,
                      customStringLabel: 'Tambah Software Manual',
                      customStringHint: 'Contoh: karung, dus, meter',
                      onChanged: _selectUnit,
                      canDeleteItem: _canDeleteCustomUnit,
                      onDeleteItem: _deleteCustomUnit,
                    ),
                    const SizedBox(height: 6),
                    _buildSoftwareHelper(_unit),
                    const SizedBox(height: 12),
                    if (!_isMaterial) ...[
                      _stockToggleSection(),
                      const SizedBox(height: 8),
                      _trackStock
                          ? _stockCostExplanation()
                          : _stockManagementInfo(),
                      const SizedBox(height: 12),
                    ],
                    if (_isMaterial) ...[
                      _materialInfoBanner(),
                      const SizedBox(height: 12),
                    ],
                    if (_trackStock && !_isMaterial)
                      Row(
                        children: [
                          Expanded(
                            child: _formField(
                              _stockCostLabel,
                              _buy,
                              hint: '0',
                              isNum: true,
                              isMoney: true,
                              suffixIcon: _priceUnitSuffix(),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _formField(
                              'Harga Jual *',
                              _sell,
                              hint: '0',
                              isNum: true,
                              isMoney: true,
                              suffixIcon: _priceUnitSuffix(),
                              validator: (v) {
                                if ((v ?? '').isEmpty) return 'Wajib';
                                return null;
                              },
                            ),
                          ),
                        ],
                      )
                    else
                      Row(
                        children: [
                          Expanded(
                              child: _formField(
                                  _isMaterial
                                      ? 'Total Harga Beli'
                                      : 'Harga Layanan *',
                                  _isMaterial ? _buy : _sell,
                                  hint: _isMaterial ? 'Contoh: 100000' : '0',
                                  isNum: true,
                                  isMoney: true, validator: (v) {
                            if ((v ?? '').isEmpty) return 'Wajib';
                            return null;
                          },
                                  helper: _isMaterial
                                      ? _materialTotalPriceHelper(_unit)
                                      : null)),
                        ],
                      ),
                    const SizedBox(height: 12),
                    if (_isMaterial || _trackStock) ...[
                      _stockFields(),
                      const SizedBox(height: 12),
                      if (_isMaterial || _trackStock) ...[
                        _supplierPicker(),
                        const SizedBox(height: 12),
                      ],
                      _expiryDateField(),
                      const SizedBox(height: 12),
                      _inventoryCodeFields(),
                    ],
                    if (!_isMaterial && !_trackStock) ...[
                      const SizedBox(height: 12),
                      _durationField(),
                      const SizedBox(height: 12),
                      _buildRecipeSection(materialProducts),
                    ],
                    const SizedBox(height: 24),
                  ],
                ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: _saveservisProductButton(),
        ),
      ),
    );
  }

  Widget _saveservisProductButton() {
    return SizedBox(
      width: double.infinity,
      child: _loading
          ? const Center(child: CircularProgressIndicator(color: _kBrand))
          : ElevatedButton(
              onPressed: _save,
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                elevation: 0,
              ),
              child: Text(
                widget.existing == null
                    ? (_isMaterial ? 'Simpan Bahan Baku' : 'Simpan Layanan')
                    : (_isMaterial ? 'Update Bahan Baku' : 'Update Layanan'),
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
    );
  }

  Widget _desktopservisSettingsPanel(List<Product> materialProducts) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Pengaturan Layanan',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 12),
          _stockToggleSection(),
          if (_trackStock) ...[
            const SizedBox(height: 8),
            _stockCostExplanation(),
          ],
          const SizedBox(height: 12),
          if (_trackStock) ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: _formField(
                    _stockCostLabel,
                    _buy,
                    hint: '0',
                    isNum: true,
                    isMoney: true,
                    suffixIcon: _priceUnitSuffix(),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _formField(
                    'Harga Jual *',
                    _sell,
                    hint: '0',
                    isNum: true,
                    isMoney: true,
                    suffixIcon: _priceUnitSuffix(),
                    validator: (v) {
                      if ((v ?? '').isEmpty) return 'Wajib';
                      return null;
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _stockFields(),
            const SizedBox(height: 12),
            _supplierPicker(),
            const SizedBox(height: 12),
            _expiryDateField(),
            const SizedBox(height: 12),
            _inventoryCodeFields(includeSku: false),
          ] else ...[
            _stockManagementInfo(),
            const SizedBox(height: 12),
            _buildRecipeSection(materialProducts),
          ],
        ],
      ),
    );
  }

  Widget _supplierPicker() {
    final selected = _selectedSupplier;
    final title = _isMaterial
        ? 'Supplier Bahan Baku (Opsional)'
        : 'Supplier Produk (Opsional)';
    final hint = _isMaterial
        ? 'Pilih supplier bahan baku...'
        : 'Pilih supplier produk...';
    final helper = _isMaterial
        ? 'Opsional. Pilih supplier agar pembelian bahan baku terhubung ke pemasok dan riwayat stok.'
        : 'Opsional. Hubungkan item ke supplier agar pembelian dan stok lebih mudah dilacak.';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Text(title,
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.black54)),
            ),
            TextButton.icon(
              onPressed: _showAddSupplierSheet,
              icon: const Icon(Icons.add_business_rounded, size: 16),
              label: const Text('Tambah Supplier'),
              style: TextButton.styleFrom(
                foregroundColor: _kBrand,
                visualDensity: VisualDensity.compact,
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                textStyle:
                    const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        InkWell(
          onTap: _showSupplierPicker,
          borderRadius: BorderRadius.zero,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            decoration: BoxDecoration(
              color: const Color(0xFFF7F7F9),
              borderRadius: BorderRadius.zero,
              border: Border.all(color: const Color(0xFFE0E0E0)),
            ),
            child: Row(
              children: [
                Icon(
                  selected == null
                      ? Icons.local_shipping_outlined
                      : Icons.business_rounded,
                  color: selected == null ? Colors.black38 : _kBrand,
                  size: 19,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    selected?.name ?? hint,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14,
                      color: selected == null ? Colors.black38 : Colors.black87,
                      fontWeight:
                          selected == null ? FontWeight.w400 : FontWeight.w700,
                    ),
                  ),
                ),
                if (selected != null)
                  InkWell(
                    onTap: () {
                      _dismissKeyboard();
                      setState(() => _supplierId = null);
                    },
                    child: const Padding(
                      padding: EdgeInsets.all(4),
                      child: Icon(Icons.close_rounded,
                          size: 18, color: Colors.black38),
                    ),
                  )
                else
                  const Icon(Icons.keyboard_arrow_down_rounded,
                      color: Colors.black26, size: 20),
              ],
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          helper,
          style: const TextStyle(
            fontSize: 11,
            color: Color(0xFF64748B),
            height: 1.35,
          ),
        ),
      ],
    );
  }

  Widget _inventoryCodeFields({bool includeSku = true}) {
    final title = _isMaterial
        ? 'Kode Inventori'
        : (includeSku ? 'Kode Layanan & Barcode' : 'Barcode Layanan');
    final helper = _isMaterial
        ? 'Opsional. Dipakai untuk pencarian, label barcode, scanner fisik, dan pembelian supplier.'
        : (includeSku
            ? 'Opsional. Kode layanan dipakai untuk pencarian kasir, barcode dipakai jika item discan fisik.'
            : 'Opsional. Barcode dipakai jika item fisik discan di kasir atau ditempel label.');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.qr_code_2_rounded, size: 17, color: _kBrand),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            helper,
            style: const TextStyle(
              fontSize: 11,
              color: Color(0xFF64748B),
              height: 1.35,
            ),
          ),
          const SizedBox(height: 12),
          if (includeSku)
            Row(
              children: [
                Expanded(
                  child: _formField(
                    _isMaterial ? 'SKU / Kode Item' : 'Kode Layanan / SKU',
                    _sku,
                    hint: _isMaterial ? 'BB-DET-001' : 'CKL-001',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(child: _barcodeField()),
              ],
            )
          else
            _barcodeField(),
        ],
      ),
    );
  }

  Widget _barcodeField() {
    return _formField(
      'Barcode',
      _barcode,
      hint: 'Scan / input manual',
      suffixIcon: IconButton(
        tooltip: 'Scan Barcode',
        icon:
            const Icon(Icons.qr_code_scanner_rounded, size: 19, color: _kBrand),
        onPressed: _scanBarcodeForProduct,
      ),
    );
  }

  Widget _serviceSkuField() {
    return _formField(
      'Kode Layanan / SKU',
      _sku,
      hint: 'Contoh: CKL-001',
      helper:
          'Opsional. Dipakai agar layanan bisa dicari cepat lewat kode di order.',
    );
  }

  Future<void> _scanBarcodeForProduct() async {
    _dismissKeyboard();
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const StandaloneScannerScreen()),
    );
    if (!mounted || result == null || result.trim().isEmpty || result == '-1') {
      return;
    }
    _dismissKeyboard();
    setState(() => _barcode.text = result.trim());
  }

  Future<void> _pickExpiryDate() async {
    final initialDate =
        _expiryDate ?? DateTime.now().add(const Duration(days: 30));
    final picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked == null || !mounted) return;
    setState(() {
      _expiryDate = DateTime(picked.year, picked.month, picked.day);
    });
  }

  Widget _expiryDateField() {
    final selected = _expiryDate;
    final title = _isMaterial
        ? 'Masa Berlaku Bahan (Opsional)'
        : 'Masa Berlaku Item (Opsional)';
    final emptyLabel = _isMaterial
        ? 'Pilih tanggal jika bahan punya masa berlaku'
        : 'Pilih tanggal jika item punya masa berlaku';
    final helper = _isMaterial
        ? 'Opsional. Isi untuk bahan yang bisa kedaluwarsa, seperti Kelengkapan, parfum, atau chemical tertentu.'
        : 'Opsional. Isi hanya jika item punya masa berlaku. Kosongkan untuk layanan servis biasa.';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Colors.black54)),
        const SizedBox(height: 4),
        InkWell(
          onTap: _pickExpiryDate,
          borderRadius: BorderRadius.zero,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xFFF7F7F9),
              borderRadius: BorderRadius.zero,
              border: Border.all(
                color: selected == null ? const Color(0xFFE0E0E0) : _kBrand,
              ),
            ),
            child: Row(
              children: [
                Icon(Icons.event_available_rounded,
                    size: 19,
                    color: selected == null ? Colors.black38 : _kBrand),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    selected == null
                        ? emptyLabel
                        : _fmtDate(selected.toIso8601String()),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14,
                      color: selected == null ? Colors.black38 : Colors.black87,
                      fontWeight:
                          selected == null ? FontWeight.w400 : FontWeight.w700,
                    ),
                  ),
                ),
                if (selected != null)
                  IconButton(
                    tooltip: 'Kosongkan masa berlaku',
                    visualDensity: VisualDensity.compact,
                    padding: EdgeInsets.zero,
                    constraints:
                        const BoxConstraints.tightFor(width: 32, height: 32),
                    icon: const Icon(Icons.close_rounded,
                        size: 18, color: Colors.black38),
                    onPressed: () => setState(() => _expiryDate = null),
                  )
                else
                  const Icon(Icons.keyboard_arrow_down_rounded,
                      color: Colors.black26, size: 20),
              ],
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          helper,
          style: const TextStyle(
            fontSize: 11,
            color: Color(0xFF64748B),
            height: 1.35,
          ),
        ),
      ],
    );
  }

  Widget _stockManagementInfo() {
    final active = _usesStock;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: active ? const Color(0xFFEFF6FF) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.zero,
        border: Border.all(
          color: active ? const Color(0xFFBFDBFE) : const Color(0xFFE2E8F0),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            active
                ? Icons.warehouse_outlined
                : Icons.handyman_outlined,
            size: 17,
            color: active ? _kBrand : const Color(0xFF64748B),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              active
                  ? (_isMaterial
                      ? 'Stok bahan baku aktif. Pembelian, koreksi, dan pemakaian resep otomatis tercatat di Riwayat Stok.'
                      : 'Stok item fisik aktif. Cocok untuk barang yang jumlahnya dihitung dan perlu dilacak di Gudang.')
                  : 'Item tetap bisa dijual tanpa pembatasan stok. Aktifkan hanya jika jumlah fisiknya perlu dilacak.',
              style: TextStyle(
                fontSize: 11,
                color: active ? _kBrand : const Color(0xFF64748B),
                height: 1.45,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _stockReadOnlyCard() {
    return ValueListenableBuilder<TextEditingValue>(
      valueListenable: _stock,
      builder: (context, value, _) {
        final stockText = value.text.trim().isEmpty ? '0' : value.text.trim();
        final info = Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 38,
              height: 38,
              color: const Color(0xFFEFF6FF),
              child: const Icon(Icons.inventory_2_outlined,
                  size: 19, color: _kBrand),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Stok Saat Ini',
                    style: TextStyle(
                      fontSize: 11,
                      color: Color(0xFF64748B),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '$stockText $_stockUnitLabel',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 18,
                      color: Color(0xFF0F172A),
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 2),
                  const Text(
                    'Ubah stok lewat koreksi agar Gudang dan Riwayat Stok tetap akurat.',
                    style: TextStyle(
                      fontSize: 10.5,
                      color: Color(0xFF64748B),
                      height: 1.35,
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
        final action = OutlinedButton.icon(
          onPressed: _openStockCorrection,
          icon: const Icon(Icons.tune_rounded, size: 16),
          label: const Text('Koreksi Stok'),
          style: OutlinedButton.styleFrom(
            foregroundColor: _kBrand,
            side: const BorderSide(color: _kBrand),
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            textStyle: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          ),
        );
        return LayoutBuilder(
          builder: (context, constraints) {
            final isNarrow = constraints.maxWidth < 420;
            return Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                border: Border.all(color: const Color(0xFFE2E8F0)),
                borderRadius: BorderRadius.zero,
              ),
              child: isNarrow
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        info,
                        const SizedBox(height: 12),
                        action,
                      ],
                    )
                  : Row(
                      children: [
                        Expanded(child: info),
                        const SizedBox(width: 10),
                        action,
                      ],
                    ),
            );
          },
        );
      },
    );
  }

  Widget _stockFields() {
    if (!_usesStock) return _stockManagementInfo();

    final stockInput = _formField(
      _canEditOpeningStock ? 'Stok Awal' : 'Stok Saat Ini',
      _stock,
      hint: '0',
      isNum: true,
      suffixIcon: _unitFieldSuffix(),
    );
    final minStockInput = _formField(
      'Min Stok',
      _minStock,
      hint: '5',
      isNum: true,
      suffixIcon: _unitFieldSuffix(),
    );

    Widget stockContent;
    if (_canEditOpeningStock) {
      stockContent = LayoutBuilder(
        builder: (context, constraints) {
          final canUseTwoColumns = constraints.maxWidth >= 340;
          if (!canUseTwoColumns) {
            return Column(
              children: [
                stockInput,
                const SizedBox(height: 12),
                minStockInput,
              ],
            );
          }
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: stockInput),
              const SizedBox(width: 12),
              Expanded(child: minStockInput),
            ],
          );
        },
      );
    } else {
      stockContent = LayoutBuilder(
        builder: (context, constraints) {
          final isWide = constraints.maxWidth >= 560;
          if (!isWide) {
            return Column(
              children: [
                _stockReadOnlyCard(),
                const SizedBox(height: 12),
                minStockInput,
              ],
            );
          }
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(flex: 2, child: _stockReadOnlyCard()),
              const SizedBox(width: 12),
              Expanded(child: minStockInput),
            ],
          );
        },
      );
    }

    return Column(
      children: [
        stockContent,
      ],
    );
  }

  Widget _stockToggleSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            color: const Color(0xFFEFF6FF),
            child: const Icon(Icons.inventory_2_outlined,
                size: 18, color: _kBrand),
          ),
          const SizedBox(width: 10),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Manajemen Stok Item Fisik',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
                ),
                SizedBox(height: 2),
                Text(
                  'Aktifkan hanya untuk barang yang jumlah fisiknya dilacak, seperti sparepart, aksesori, atau produk jual.',
                  style: TextStyle(
                    fontSize: 11,
                    color: Color(0xFF64748B),
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
          Switch.adaptive(
            value: _trackStock,
            activeColor: _kBrand,
            onChanged: _setStockTracking,
          ),
        ],
      ),
    );
  }

  Widget _stockCostExplanation() {
    final unit = _unit.trim().isEmpty ? 'software' : _unit.trim();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFEFF6FF),
        border: Border.all(color: const Color(0xFFBFDBFE)),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline_rounded,
              size: 18, color: Color(0xFF2563EB)),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              'Stok aktif untuk item fisik. HPP/Modal mengikuti software stok ($unit) dan terhubung ke Gudang, Riwayat Stok, serta laporan laba.',
              style: const TextStyle(
                fontSize: 11,
                height: 1.45,
                color: Color(0xFF1E40AF),
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecipeSection(List<Product> materialProducts) {
    if (_isMaterial) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFF8FAFC),
          border: Border.all(color: const Color(0xFFE2E8F0)),
          borderRadius: BorderRadius.zero,
        ),
        child: const Text(
          'Item ini dipakai sebagai stok. Resep bahan hanya diatur pada layanan yang dijual ke pelanggan.',
          style: TextStyle(
            fontSize: 11,
            color: Color(0xFF64748B),
            height: 1.4,
          ),
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.science_outlined,
                  size: 18, color: Color(0xFF2563EB)),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'Resep Bahan Baku',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
                ),
              ),
              TextButton.icon(
                onPressed: materialProducts.isEmpty
                    ? _openAddMaterialFromRecipe
                    : _addRecipeLine,
                icon: const Icon(Icons.add_rounded, size: 16),
                label: const Text('Tambah'),
                style: TextButton.styleFrom(
                  foregroundColor: _kBrand,
                  textStyle: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          const Text(
            'Contoh: penggantian LCD memakai 1 unit LCD dan 1 lem layar. Simpan stok bahan dalam software terkecil agar pemotongan akurat.',
            style: TextStyle(
              fontSize: 11,
              color: Color(0xFF64748B),
              height: 1.4,
            ),
          ),
          if (_recipesLoading) ...[
            const SizedBox(height: 12),
            const LinearProgressIndicator(minHeight: 2),
          ] else if (materialProducts.isEmpty) ...[
            const SizedBox(height: 12),
            const Text(
              'Belum ada bahan baku. Tekan Tambah untuk membuat sparepart atau bahan teknisi.',
              style: TextStyle(fontSize: 11, color: Color(0xFFB45309)),
            ),
          ] else if (_recipeLines.isEmpty) ...[
            const SizedBox(height: 12),
            const Text(
              'Belum ada resep. Layanan tetap bisa dijual, tapi bahan baku tidak akan berkurang otomatis.',
              style: TextStyle(fontSize: 11, color: Color(0xFF64748B)),
            ),
          ] else ...[
            const SizedBox(height: 12),
            ...List.generate(_recipeLines.length, (index) {
              final line = _recipeLines[index];
              final selected = materialProducts.any(
                      (p) => p.id != null && p.id == line.materialProductId)
                  ? materialProducts.firstWhere(
                      (p) => p.id != null && p.id == line.materialProductId)
                  : null;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'Bahan ${index + 1}',
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF334155),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () => _removeRecipeLine(index),
                            child: const Padding(
                              padding: EdgeInsets.all(4),
                              child: Icon(AppIcons.recycleBin,
                                  color: AppColors.danger, size: 18),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      ModernPicker<Product>(
                        label: 'Pilih Bahan Baku',
                        value: selected,
                        items: materialProducts,
                        itemLabel: (p) =>
                            '${p.name} - stok ${p.stock} ${p.unit}',
                        onChanged: (p) =>
                            setState(() => line.materialProductId = p.id),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: TextField(
                              controller: line.qtyCtrl,
                              keyboardType:
                                  const TextInputType.numberWithOptions(
                                      decimal: true),
                              decoration: const InputDecoration(
                                labelText: 'Dipakai per 1 layanan',
                                hintText: 'Contoh: 25',
                                helperText:
                                    'Isi jumlah bahan yang terpakai setiap order layanan ini.',
                                helperMaxLines: 2,
                                isDense: true,
                                filled: true,
                                fillColor: Color(0xFFF8FAFC),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.zero,
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.zero,
                                  borderSide:
                                      BorderSide(color: Color(0xFFE2E8F0)),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.zero,
                                  borderSide:
                                      BorderSide(color: _kBrand, width: 1.4),
                                ),
                              ),
                            ),
                          ),
                          if (selected != null) ...[
                            const SizedBox(width: 8),
                            Container(
                              constraints: const BoxConstraints(minWidth: 58),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 14),
                              decoration: BoxDecoration(
                                color: const Color(0xFFEFF6FF),
                                border:
                                    Border.all(color: const Color(0xFFBFDBFE)),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: Text(
                                selected.unit,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: _kBrand,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              );
            }),
          ],
        ],
      ),
    );
  }

  Widget _materialInfoBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7ED),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFFED7AA)),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.science_outlined, size: 16, color: Color(0xFF9A3412)),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'Bahan baku adalah stok internal operasional servis. Tidak muncul di order pelanggan, tetapi bisa dipakai di resep layanan dan berkurang otomatis saat transaksi.',
              style: TextStyle(
                fontSize: 11,
                color: Color(0xFF9A3412),
                height: 1.45,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSoftwareHelper(String unit) {
    final Map<String, String> descriptions = {
      'kg':
          '⚖️  Layanan — harga dihitung per kg berat pengecekanan (pengecekan/perbaikan layanan)',
      'gram': 'Stok gram - cocok untuk bahan bubuk atau bahan timbang kecil',
      'ml': 'Stok ml - cocok untuk deterjen cair, Kelengkapan, parfum servis',
      'liter': 'Stok liter - cocok untuk pembelian bahan cair ukuran besar',
      'meter': 'Stok meter - cocok untuk tali, kain, atau plastik panjang',
      'roll': 'Stok roll - cocok untuk plastik roll, label, atau stiker',
      'pack': 'Stok pack - cocok untuk paket hanger, plastik, atau kemasan',
      'botol': 'Stok botol - cocok untuk cairan kemasan botol',
      'pcs':
          '👕  Software — per buah/item (bed cover, jas, boneka, sepatu, dll.)',
      'm2': '📐  Per m² — cocok untuk karpet, permadani, & kain luas',
      'pasang': '👟  Per pasang — cocok untuk sepatu, sandal, & alas kaki',
      'layanan': '🛎️  Per layanan — tanpa software spesifik / paket tetap',
    };
    final normalizedUnit = unit.trim();
    final desc = descriptions[normalizedUnit];
    final cleanDesc = switch (normalizedUnit) {
      'kg' => 'Harga dihitung per kg pengecekanan.',
      'gram' => 'Untuk bahan atau produk yang ditimbang dalam gram.',
      'ml' => 'Untuk cairan seperti deterjen, Kelengkapan, atau parfum.',
      'liter' => 'Untuk cairan dalam ukuran liter.',
      'meter' => 'Untuk item yang dihitung per meter.',
      'roll' => 'Untuk plastik roll, label, atau stiker.',
      'pack' => 'Untuk produk kemasan atau paket.',
      'botol' => 'Untuk cairan kemasan botol.',
      'pcs' => 'Untuk item software seperti bed cover, jas, boneka, atau sepatu.',
      'm2' => 'Untuk karpet, permadani, atau kain luas.',
      'pasang' => 'Untuk sepatu, sandal, atau item berpasangan.',
      'layanan' => 'Untuk paket layanan tanpa software khusus.',
      _ => desc ?? 'Harga dan stok akan mengikuti software "$normalizedUnit".',
    };
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 1),
            child: Icon(Icons.info_outline_rounded,
                size: 15, color: Color(0xFF64748B)),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              cleanDesc,
              style: const TextStyle(
                fontSize: 11.5,
                color: Color(0xFF64748B),
                height: 1.35,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _materialTotalPriceHelper(String unit) {
    switch (unit) {
      case 'ml':
        return 'Contoh: beli 5 liter Rp100.000, isi stok 5000 ml. HPP otomatis Rp20/ml.';
      case 'liter':
        return 'Contoh: total belanja Rp100.000 dengan stok 5 liter. HPP otomatis Rp20.000/liter.';
      case 'gram':
        return 'Contoh: beli 1 kg Rp25.000, isi stok 1000 gram. HPP otomatis Rp25/gram.';
      case 'kg':
        return 'Contoh: total belanja Rp125.000 dengan stok 5 kg. HPP otomatis Rp25.000/kg.';
      case 'pcs':
        return 'Contoh: total belanja Rp50.000 dengan stok 100 pcs. HPP otomatis Rp500/pcs.';
      default:
        return 'Isi total belanja. HPP per $unit dihitung otomatis dari jumlah stok.';
    }
  }

  Widget _unitFieldSuffix() {
    return Padding(
      padding: const EdgeInsets.only(right: 12),
      child: Center(
        widthFactor: 1,
        child: Text(
          _unit,
          style: const TextStyle(
            fontSize: 12,
            color: Color(0xFF64748B),
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _priceUnitSuffix() {
    final unit = _unit.trim().isEmpty ? 'software' : _unit.trim();
    return Padding(
      padding: const EdgeInsets.only(right: 12),
      child: Center(
        widthFactor: 1,
        child: Text(
          'per $unit',
          style: const TextStyle(
            fontSize: 11.5,
            color: Color(0xFF64748B),
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }

  int get _durationHoursForSave {
    final value = int.tryParse(_durationCtrl.text) ?? 0;
    return _durationUnit == 'hari' ? value * 24 : value;
  }

  Widget _durationField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Estimasi Proses',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: Colors.black54,
          ),
        ),
        const SizedBox(height: 4),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: TextFormField(
                controller: _durationCtrl,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                onChanged: (_) => setState(() {}),
                style: const TextStyle(fontSize: 14),
                decoration: _inputDeco('Contoh: 1'),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 112,
              child: DropdownButtonFormField<String>(
                initialValue: _durationUnit,
                isExpanded: true,
                decoration: _inputDeco(''),
                icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 20),
                items: const [
                  DropdownMenuItem(value: 'jam', child: Text('Jam')),
                  DropdownMenuItem(value: 'hari', child: Text('Hari')),
                ],
                onChanged: (value) {
                  if (value != null) {
                    setState(() => _durationUnit = value);
                  }
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 5),
        Text(
          _durationHoursForSave > 0
              ? 'Selesai dalam ${_durationLabel(_durationHoursForSave)}'
              : 'Waktu selesai otomatis dihitung saat checkout',
          style: const TextStyle(
            fontSize: 10.5,
            color: Color(0xFF64748B),
            height: 1.3,
          ),
        ),
      ],
    );
  }

  Widget _formField(String label, TextEditingController ctrl,
      {String hint = '',
      bool isNum = false,
      bool isMoney = false,
      String? helper,
      String? Function(String?)? validator,
      Widget? suffixIcon}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Colors.black54)),
        const SizedBox(height: 4),
        TextFormField(
          controller: ctrl,
          keyboardType: isNum ? TextInputType.number : TextInputType.text,
          inputFormatters: isMoney
              ? const [CurrencyInputFormatter()]
              : isNum
                  ? [FilteringTextInputFormatter.digitsOnly]
                  : null,
          validator: validator,
          style: const TextStyle(fontSize: 14),
          decoration: _inputDeco(hint).copyWith(
            suffixIcon: suffixIcon,
            helperText: helper,
            helperMaxLines: 3,
            errorMaxLines: 2,
            helperStyle: const TextStyle(
              fontSize: 10.5,
              color: Color(0xFF64748B),
              height: 1.3,
            ),
          ),
        ),
      ],
    );
  }
}

class _StockCorrectionSheet extends StatefulWidget {
  final Product product;
  final String unitLabel;

  const _StockCorrectionSheet({
    required this.product,
    required this.unitLabel,
  });

  @override
  State<_StockCorrectionSheet> createState() => _StockCorrectionSheetState();
}

class _StockCorrectionSheetState extends State<_StockCorrectionSheet> {
  late final TextEditingController _actualCtrl;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _actualCtrl = TextEditingController(text: '${widget.product.stock}');
  }

  @override
  void dispose() {
    _actualCtrl.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    final actual = int.tryParse(_actualCtrl.text) ?? 0;
    Navigator.of(context).pop(actual);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      padding: EdgeInsets.fromLTRB(
        20,
        10,
        20,
        MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SafeArea(
        top: false,
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 42,
                  height: 4,
                  color: const Color(0xFFE2E8F0),
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    color: const Color(0xFFEFF6FF),
                    child: const Icon(Icons.tune_rounded,
                        color: _kBrand, size: 20),
                  ),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Koreksi Stok',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF0F172A),
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Sesuaikan dengan hasil hitung fisik di gudang.',
                          style: TextStyle(
                            fontSize: 12,
                            color: Color(0xFF64748B),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                  borderRadius: BorderRadius.zero,
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Item',
                            style: TextStyle(
                              fontSize: 11,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            widget.product.name,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFF0F172A),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text(
                          'Stok Sistem',
                          style: TextStyle(
                            fontSize: 11,
                            color: Color(0xFF64748B),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${widget.product.stock} ${widget.unitLabel}',
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF0F172A),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              const Text(
                'Stok Fisik Sekarang',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF334155),
                ),
              ),
              const SizedBox(height: 5),
              TextFormField(
                controller: _actualCtrl,
                autofocus: true,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                validator: (value) {
                  final parsed = int.tryParse(value ?? '');
                  if (parsed == null || parsed < 0) {
                    return 'Masukkan stok fisik yang valid';
                  }
                  return null;
                },
                onChanged: (_) => setState(() {}),
                decoration: _inputDeco('0').copyWith(
                  suffixText: widget.unitLabel,
                  suffixStyle: const TextStyle(
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              _StockCorrectionPreview(
                systemStock: widget.product.stock,
                actualStock: int.tryParse(_actualCtrl.text) ?? 0,
                unitLabel: widget.unitLabel,
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF64748B),
                        side: const BorderSide(color: Color(0xFFCBD5E1)),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                      child: const Text(
                        'Batal',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _submit,
                      icon: const Icon(Icons.check_rounded, size: 18),
                      label: const Text('Simpan Koreksi'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        textStyle: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StockCorrectionPreview extends StatelessWidget {
  final int systemStock;
  final int actualStock;
  final String unitLabel;

  const _StockCorrectionPreview({
    required this.systemStock,
    required this.actualStock,
    required this.unitLabel,
  });

  @override
  Widget build(BuildContext context) {
    final diff = actualStock - systemStock;
    final Color color;
    final IconData icon;
    final String title;
    final String subtitle;
    if (diff > 0) {
      color = const Color(0xFF059669);
      icon = Icons.south_west_rounded;
      title = 'Stok bertambah $diff $unitLabel';
      subtitle = 'Akan dicatat sebagai koreksi masuk.';
    } else if (diff < 0) {
      color = const Color(0xFFDC2626);
      icon = Icons.north_east_rounded;
      title = 'Stok berkurang ${diff.abs()} $unitLabel';
      subtitle = 'Akan dicatat sebagai koreksi keluar.';
    } else {
      color = const Color(0xFF64748B);
      icon = Icons.check_circle_outline_rounded;
      title = 'Stok sudah sesuai';
      subtitle = 'Tidak ada perubahan yang perlu dicatat.';
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        border: Border.all(color: color.withOpacity(0.22)),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: color,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFF64748B),
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ProductSupplierPickerSheet extends StatefulWidget {
  final List<Supplier> suppliers;
  final int? selectedId;

  const _ProductSupplierPickerSheet({
    required this.suppliers,
    required this.selectedId,
  });

  @override
  State<_ProductSupplierPickerSheet> createState() =>
      _ProductSupplierPickerSheetState();
}

class _ProductSupplierPickerSheetState
    extends State<_ProductSupplierPickerSheet> {
  final _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  List<Supplier> get _filtered {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return widget.suppliers;
    return widget.suppliers.where((supplier) {
      return supplier.name.toLowerCase().contains(q) ||
          (supplier.phone?.toLowerCase().contains(q) ?? false);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;

    return DraggableScrollableSheet(
      initialChildSize: 0.72,
      minChildSize: 0.45,
      maxChildSize: 0.9,
      builder: (context, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero),
          ),
          child: Column(
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(top: 10, bottom: 14),
                color: const Color(0xFFE2E8F0),
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 0, 20, 12),
                child: Row(
                  children: [
                    Icon(Icons.local_shipping_outlined,
                        color: _kBrand, size: 22),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Pilih Supplier Produk',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFF1F5F9),
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: TextField(
                    controller: _searchCtrl,
                    autofocus: false,
                    onChanged: (value) => setState(() => _query = value),
                    decoration: const InputDecoration(
                      hintText: 'Cari supplier...',
                      hintStyle: TextStyle(fontSize: 13, color: Colors.black38),
                      prefixIcon:
                          Icon(Icons.search, color: Colors.black38, size: 20),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: ListView.separated(
                  controller: scrollController,
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 88),
                  itemCount: filtered.length + 1,
                  separatorBuilder: (_, __) =>
                      const Divider(height: 1, color: Color(0xFFF1F5F9)),
                  itemBuilder: (context, index) {
                    if (index == 0) {
                      return RadioListTile<int>(
                        value: 0,
                        groupValue: widget.selectedId ?? 0,
                        onChanged: (value) {
                          FocusManager.instance.primaryFocus?.unfocus();
                          SystemChannels.textInput
                              .invokeMethod<void>('TextInput.hide');
                          Navigator.pop(context, 0);
                        },
                        activeColor: _kBrand,
                        title: const Text(
                          'Tanpa Supplier',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                        subtitle: const Text('Produk tidak dikaitkan supplier'),
                      );
                    }

                    final supplier = filtered[index - 1];
                    final id = supplier.id ?? -1;
                    return RadioListTile<int>(
                      value: id,
                      groupValue: widget.selectedId ?? 0,
                      onChanged: (value) {
                        FocusManager.instance.primaryFocus?.unfocus();
                        SystemChannels.textInput
                            .invokeMethod<void>('TextInput.hide');
                        Navigator.pop(context, value);
                      },
                      activeColor: _kBrand,
                      title: Text(
                        supplier.name,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      subtitle: supplier.phone?.isNotEmpty == true
                          ? Text(supplier.phone!)
                          : null,
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

//
//  SHARED HELPERS
//

AppBar _buildAppBar(BuildContext context, String title,
    {Widget? trailing, Widget? titleWidget}) {
  return AppBar(
    backgroundColor: Colors.white,
    elevation: 0,
    surfaceTintColor: Colors.transparent,
    systemOverlayStyle: const SystemUiOverlayStyle(
      statusBarIconBrightness: Brightness.dark,
      statusBarColor: Colors.transparent,
    ),
    leading: IconButton(
      icon: const Icon(Icons.arrow_back_ios_new, color: _kBrand, size: 20),
      onPressed: () => Navigator.pop(context),
    ),
    title: titleWidget ??
        Text(
          title,
          style: const TextStyle(
              fontSize: 17, fontWeight: FontWeight.w600, color: Colors.black87),
        ),
    actions: trailing != null
        ? [Padding(padding: const EdgeInsets.only(right: 10), child: trailing)]
        : null,
  );
}

Widget _redButton(String label, VoidCallback onTap) {
  return TextButton(
    onPressed: onTap,
    style: TextButton.styleFrom(
      backgroundColor: _kBrand,
      foregroundColor: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    ),
    child: Text(label,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
  );
}

Widget _redProButton(String label, VoidCallback onTap) {
  return GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration:
          const BoxDecoration(color: _kBrand, borderRadius: BorderRadius.zero),
      child: Row(
        children: [
          Text(label,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    ),
  );
}

// ignore: unused_element
Widget _proBadge() => const SizedBox.shrink();

Widget _iconBtn(dynamic icon, VoidCallback onTap,
    {Color? color, String? tooltip}) {
  Widget child = InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.zero,
    child: Container(
      padding: const EdgeInsets.all(10),
      child: icon is IconData
          ? Icon(icon, color: color ?? _kBrand, size: 22)
          : icon,
    ),
  );
  if (tooltip != null) {
    return Tooltip(message: tooltip, child: child);
  }
  return child;
}

Widget _outlineBtn(String label, VoidCallback onTap) {
  return SizedBox(
    width: double.infinity,
    child: OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        foregroundColor: _kBrand,
        side: const BorderSide(color: _kBrand),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        padding: const EdgeInsets.symmetric(vertical: 14),
      ),
      child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
    ),
  );
}

Widget _solidBtn(String label, VoidCallback onTap) {
  return SizedBox(
    width: double.infinity,
    child: ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: _kBrand,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        elevation: 0,
      ),
      child: Text(label,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
    ),
  );
}

Widget _periodChip(String label, VoidCallback onTap) {
  return GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: const BoxDecoration(
        color: Color(0xFFF5F5F5),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label,
              style:
                  const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          const SizedBox(width: 4),
          const Icon(Icons.keyboard_arrow_down, size: 18, color: _kBrand),
        ],
      ),
    ),
  );
}

Widget _bottomBar({required List<Widget> children}) {
  return Container(
    color: Colors.white,
    padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
    child: SafeArea(
      bottom: false,
      top: false,
      child: Column(mainAxisSize: MainAxisSize.min, children: children),
    ),
  );
}

Widget _fieldLabel(String label, {bool required = false}) {
  return RichText(
    text: TextSpan(
      text: label,
      style: const TextStyle(
          fontSize: 13, fontWeight: FontWeight.w600, color: Colors.black87),
      children: required
          ? [const TextSpan(text: ' *', style: TextStyle(color: _kBrand))]
          : [],
    ),
  );
}

InputDecoration _inputDeco(String hint) {
  return InputDecoration(
    hintText: hint,
    hintStyle: const TextStyle(color: Colors.grey, fontSize: 13),
    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
    border: OutlineInputBorder(
        borderRadius: BorderRadius.zero,
        borderSide: BorderSide(color: Colors.grey.shade300)),
    enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.zero,
        borderSide: BorderSide(color: Colors.grey.shade300)),
    focusedBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.zero,
        borderSide: BorderSide(color: _kBrand)),
    errorBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.zero,
        borderSide: BorderSide(color: _kBrand)),
  );
}

//  Ilustrasi exchange (dua orang tukar kotak)
Widget _exchangeIllustration() {
  return SizedBox(
    height: 150,
    child: CustomPaint(painter: _ExchangePainter()),
  );
}

class _ExchangePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;
    final cx = size.width / 2;

    // Person 1 (left, white shirt)
    paint.color = const Color(0xFFF0F0F0);
    canvas.drawCircle(Offset(cx - 60, 30), 14, paint); // head
    paint.color = Colors.white;
    final bodyPath1 = Path()
      ..moveTo(cx - 80, 55)
      ..lineTo(cx - 40, 55)
      ..lineTo(cx - 35, 110)
      ..lineTo(cx - 85, 110)
      ..close();
    canvas.drawPath(bodyPath1, paint);
    paint.color = const Color(0xFF2D2D2D);
    final leg1 = Path()
      ..moveTo(cx - 80, 110)
      ..lineTo(cx - 60, 145)
      ..lineTo(cx - 52, 145)
      ..lineTo(cx - 70, 110)
      ..close();
    canvas.drawPath(leg1, paint);
    final leg2 = Path()
      ..moveTo(cx - 70, 110)
      ..lineTo(cx - 50, 145)
      ..lineTo(cx - 42, 145)
      ..lineTo(cx - 58, 110)
      ..close();
    canvas.drawPath(leg2, paint);

    // Person 2 (right, dark shirt)
    paint.color = const Color(0xFFF0F0F0);
    canvas.drawCircle(Offset(cx + 60, 30), 14, paint); // head
    paint.color = const Color(0xFF2D2D2D);
    final bodyPath2 = Path()
      ..moveTo(cx + 40, 55)
      ..lineTo(cx + 80, 55)
      ..lineTo(cx + 85, 110)
      ..lineTo(cx + 35, 110)
      ..close();
    canvas.drawPath(bodyPath2, paint);
    final leg3 = Path()
      ..moveTo(cx + 40, 110)
      ..lineTo(cx + 52, 145)
      ..lineTo(cx + 60, 145)
      ..lineTo(cx + 48, 110)
      ..close();
    canvas.drawPath(leg3, paint);
    final leg4 = Path()
      ..moveTo(cx + 52, 110)
      ..lineTo(cx + 58, 145)
      ..lineTo(cx + 66, 145)
      ..lineTo(cx + 60, 110)
      ..close();
    canvas.drawPath(leg4, paint);

    // Box (center, red lid)
    paint.color = const Color(0xFFE53935);
    canvas.drawRect(Rect.fromLTWH(cx - 18, 60, 36, 10), paint); // lid
    paint.color = const Color(0xFF1A1A2E);
    canvas.drawRect(Rect.fromLTWH(cx - 16, 70, 32, 28), paint); // box body
    paint.color = const Color(0xFFE53935);
    canvas.drawRect(Rect.fromLTWH(cx - 4, 70, 8, 28), paint); // ribbon
    canvas.drawRect(Rect.fromLTWH(cx - 16, 82, 32, 4), paint); // ribbon h
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

//  Empty state generic --
Widget _emptyState(String message) {
  return Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _exchangeIllustration(),
        const SizedBox(height: 20),
        Text(message,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ],
    ),
  );
}

//
//  STANDALONE SCANNER SCREEN (Khusus Linear Barcode)
//
class StandaloneScannerScreen extends StatefulWidget {
  const StandaloneScannerScreen({super.key});

  @override
  State<StandaloneScannerScreen> createState() =>
      _StandaloneScannerScreenState();
}

class _StandaloneScannerScreenState extends State<StandaloneScannerScreen> {
  MobileScannerController? controller;

  @override
  void initState() {
    super.initState();
    if (_kSupportsStandaloneBarcodeScanner) {
      controller = MobileScannerController(
        detectionSpeed: DetectionSpeed.noDuplicates,
        formats: [
          BarcodeFormat.ean13,
          BarcodeFormat.ean8,
          BarcodeFormat.upcA,
          BarcodeFormat.upcE,
          BarcodeFormat.code128,
          BarcodeFormat.code39,
          BarcodeFormat.code93,
        ],
      );
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (capture.barcodes.isNotEmpty) {
      final code = capture.barcodes.first.rawValue;
      if (code != null && code.isNotEmpty) {
        controller?.stop();
        Navigator.pop(context, code);
      }
    }
  }

  Future<void> _inputManualCode() async {
    final ctrl = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Input Barcode Manual'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'Masukkan barcode',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
            child: const Text('Pakai'),
          ),
        ],
      ),
    );

    Future.delayed(const Duration(milliseconds: 300), ctrl.dispose);

    if (!mounted || result == null || result.trim().isEmpty) {
      return;
    }

    Navigator.pop(context, result.trim());
  }

  @override
  Widget build(BuildContext context) {
    if (Platform.isWindows) {
      return const simple_barcode.SimpleBarcodeScannerPage(
        appBarTitle: 'Scan Barcode',
        centerTitle: false,
        scanType: simple_barcode.ScanType.barcode,
        delayMillis: 500,
      );
    }

    if (!_kSupportsStandaloneBarcodeScanner) {
      final platformName = Platform.isWindows
          ? 'Windows'
          : Platform.isLinux
              ? 'Linux'
              : 'desktop ini';

      return Scaffold(
        appBar: AppBar(
          title: const Text('Scan Barcode'),
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
        ),
        backgroundColor: Colors.black,
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Container(
              margin: const EdgeInsets.all(24),
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.zero,
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.videocam_off_rounded,
                      size: 44, color: _kBrand),
                  const SizedBox(height: 14),
                  Text(
                    'Scanner kamera belum tersedia di $platformName',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Untuk Windows desktop, barcode tetap bisa diisi manual atau memakai scanner USB. Live camera scanner hanya tersedia di platform yang didukung plugin.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 13,
                      height: 1.45,
                      color: Colors.black54,
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _inputManualCode,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero,
                        ),
                      ),
                      icon: const Icon(Icons.keyboard_outlined),
                      label: const Text('Input Barcode Manual'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan Barcode'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.flash_on),
            onPressed: () => controller?.toggleTorch(),
          ),
          IconButton(
            icon: const Icon(Icons.cameraswitch),
            onPressed: () => controller?.switchCamera(),
          ),
          IconButton(
            icon: const Icon(Icons.keyboard_alt_outlined),
            tooltip: 'Input manual',
            onPressed: _inputManualCode,
          ),
        ],
      ),
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          MobileScanner(
            controller: controller!,
            onDetect: _onDetect,
          ),
          Center(
            child: Container(
              width: 240,
              height: 240,
              decoration: BoxDecoration(
                border: Border.all(color: _kBrand, width: 3),
                borderRadius: BorderRadius.zero,
              ),
              child: Stack(
                children: [
                  Positioned(
                      top: 0,
                      left: 0,
                      right: 0,
                      child: Container(
                          height: 2, color: _kBrand.withValues(alpha: 0.5))),
                ],
              ),
            ),
          ),
          const Positioned(
            bottom: 40,
            left: 0,
            right: 0,
            child: Text(
              'Arahkan barcode ke dalam kotak',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  shadows: [Shadow(color: Colors.black, blurRadius: 4)]),
            ),
          )
        ],
      ),
    );
  }
}

//
//  EXTRA PRODUCT FORM SCREEN (Add-on Khusus)
//
class ExtraProductFormScreen extends ConsumerStatefulWidget {
  final Product? existing;
  const ExtraProductFormScreen({super.key, this.existing});

  @override
  ConsumerState<ExtraProductFormScreen> createState() =>
      _ExtraProductFormScreenState();
}

class _ExtraProductFormScreenState
    extends ConsumerState<ExtraProductFormScreen> {
  final _fk = GlobalKey<FormState>();
  late final TextEditingController _name, _buy, _sell;
  int _catId = 1;
  bool _loading = false;
  String? _imagePath;
  final _picker = ImagePicker();

  List<int> _targetCategories = [];
  List<int> _targetProducts = [];
  bool _showAdvancedTargeting = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _buy = TextEditingController(
        text: e != null ? formatCurrencyInput(e.buyPrice) : '');
    _sell = TextEditingController(
        text: e != null ? formatCurrencyInput(e.sellPrice) : '');

    if (e != null) {
      _catId = e.categoryId;
      _imagePath = e.imagePath;
      if (e.extraTargetCategories != null &&
          e.extraTargetCategories!.isNotEmpty) {
        _targetCategories = e.extraTargetCategories!
            .split(',')
            .map((x) => int.tryParse(x) ?? -1)
            .where((id) => id != -1)
            .toList();
      }
      if (e.extraTargetProducts != null && e.extraTargetProducts!.isNotEmpty) {
        _targetProducts = e.extraTargetProducts!
            .split(',')
            .map((x) => int.tryParse(x) ?? -1)
            .where((id) => id != -1)
            .toList();
      }
      _showAdvancedTargeting =
          _targetCategories.isNotEmpty || _targetProducts.isNotEmpty;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _buy.dispose();
    _sell.dispose();
    super.dispose();
  }

  int _resolvedCategoryId(List<Category> categories) {
    if (categories.any((c) => c.id == _catId)) return _catId;
    final defaultCategory = categories.where(
      (c) => DBHelper.isDefaultCategoryName(c.name),
    );
    if (defaultCategory.isNotEmpty) {
      return defaultCategory.first.id ?? _catId;
    }
    return categories.isNotEmpty ? (categories.first.id ?? _catId) : _catId;
  }

  Category? _selectedCategory(List<Category> categories) {
    if (categories.isEmpty) return null;
    final resolvedId = _resolvedCategoryId(categories);
    return categories.firstWhere(
      (c) => c.id == resolvedId,
      orElse: () => categories.first,
    );
  }

  void _syncCategoryId(List<Category> categories) {
    final resolvedId = _resolvedCategoryId(categories);
    if (_catId != resolvedId) _catId = resolvedId;
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picked = await _picker.pickImage(source: source, imageQuality: 85);
      if (picked == null) return;
      if (Platform.isWindows) {
        final savedPath =
            await ImageUtils.saveImageToLocalDirectory(picked.path);
        setState(() => _imagePath = savedPath ?? picked.path);
        return;
      }
      final cropped = await ImageCropper().cropImage(
        sourcePath: picked.path,
        aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
        uiSettings: [
          AndroidUiSettings(
            toolbarTitle: 'Sesuaikan Foto Produk',
            toolbarColor: _kBrand,
            statusBarLight: false,
            toolbarWidgetColor: Colors.white,
            activeControlsWidgetColor: _kBrand,
            lockAspectRatio: true,
          ),
          IOSUiSettings(
            title: 'Sesuaikan Foto',
            aspectRatioLockEnabled: true,
          ),
        ],
      );
      if (cropped != null) setState(() => _imagePath = cropped.path);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Operasi gagal. Silakan coba lagi.'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      }
    }
  }

  void _showImageSourceDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero)),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
                child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.zero))),
            const SizedBox(height: 16),
            const Text('Pilih Sumber Gambar',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pop(ctx);
                      _pickImage(ImageSource.camera);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      decoration: const BoxDecoration(
                          color: Color(0xFFEEF2F7),
                          borderRadius: BorderRadius.zero),
                      child: const Column(children: [
                        Icon(Icons.camera_alt_rounded,
                            color: Color(0xFF1E465B), size: 36),
                        SizedBox(height: 8),
                        Text('Kamera',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1E465B))),
                      ]),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pop(ctx);
                      _pickImage(ImageSource.gallery);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      decoration: const BoxDecoration(
                          color: Color(0xFFEEF2F7),
                          borderRadius: BorderRadius.zero),
                      child: const Column(children: [
                        Icon(Icons.photo_library_rounded,
                            color: Color(0xFF1E465B), size: 36),
                        SizedBox(height: 8),
                        Text('Galeri',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1E465B))),
                      ]),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _save() async {
    if (!_fk.currentState!.validate()) return;
    setState(() => _loading = true);
    final categories = ref.read(categoriesProvider);
    final selectedCategory = _selectedCategory(categories);
    final categoryId = await DBHelper.instance.resolveProductCategoryId(
      categoryId: selectedCategory?.id ?? _catId,
      categoryName: selectedCategory?.name,
    );
    final p = Product(
      id: widget.existing?.id,
      name: _name.text.trim(),
      categoryId: categoryId,
      buyPrice: parseCurrencyInput(_buy.text),
      sellPrice: parseCurrencyInput(_sell.text),
      stock: widget.existing?.stock ?? 9999,
      unit: 'pcs',
      minStock: widget.existing?.minStock ?? 0,
      createdAt: widget.existing?.createdAt ?? DateTime.now().toIso8601String(),
      imagePath: _imagePath,
      description: widget.existing?.description ?? '',
      sku: widget.existing?.sku ?? '',
      barcode: widget.existing?.barcode ?? '',
      hasStockManagement: 0,
      hasWholesale: 0,
      hasExtraPopup: 0,
      isExtra: 1, // Enforce Extra Product true
      extraTargetCategories:
          !_showAdvancedTargeting || _targetCategories.isEmpty
              ? null
              : _targetCategories.join(','),
      extraTargetProducts: !_showAdvancedTargeting || _targetProducts.isEmpty
          ? null
          : _targetProducts.join(','),
    );
    if (widget.existing == null) {
      await ref.read(productsProvider.notifier).addProduct(p);
    } else {
      await ref.read(productsProvider.notifier).updateProduct(p);
    }
    if (mounted) {
      setState(() => _loading = false);
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(widget.existing == null
            ? 'Layanan Tambahan berhasil ditambahkan!'
            : 'Layanan Tambahan berhasil diperbarui!'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
    }
  }

  Widget _buildTargetSelector(
      {required String label,
      required String value,
      required VoidCallback onTap,
      required bool isActive}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(
          color: isActive ? _kBrand.withValues(alpha: 0.05) : Colors.white,
          border: Border.all(color: isActive ? _kBrand : Colors.grey.shade300),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      fontSize: 11,
                      color: Color(0xFF64748B),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13,
                      color: isActive ? _kBrand : Colors.black87,
                      fontWeight: isActive ? FontWeight.w800 : FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Icon(
              Icons.keyboard_arrow_down_rounded,
              color: isActive ? _kBrand : Colors.grey,
            ),
          ],
        ),
      ),
    );
  }

  String _selectedTargetCategoryText(List<Category> cats) {
    final names = _targetCategories
        .map((id) =>
            cats
                .firstWhere(
                  (c) => c.id == id,
                  orElse: () => Category(id: -1, name: 'Unknown'),
                )
                .name ??
            '')
        .where((name) => name.isNotEmpty && name != 'Unknown')
        .toList();
    return names.isEmpty ? 'Pilih kategori layanan' : names.join(', ');
  }

  String _selectedTargetProductText(List<Product> products) {
    final names = _targetProducts
        .map((id) => products
            .firstWhere(
              (p) => p.id == id,
              orElse: () => Product(
                categoryId: 0,
                name: 'Unknown',
                stock: 0,
                buyPrice: 0,
                sellPrice: 0,
                unit: '',
                minStock: 0,
              ),
            )
            .name)
        .where((name) => name != 'Unknown')
        .toList();
    return names.isEmpty ? 'Pilih layanan tertentu' : names.join(', ');
  }

  Widget _scopeOption({
    required bool selected,
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.zero,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: selected ? _kBrand.withValues(alpha: 0.07) : Colors.white,
          border: Border.all(
            color: selected ? _kBrand : const Color(0xFFE2E8F0),
            width: selected ? 1.4 : 1,
          ),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          children: [
            Icon(
              selected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: selected ? _kBrand : const Color(0xFF94A3B8),
              size: 20,
            ),
            const SizedBox(width: 10),
            Icon(icon,
                color: selected ? _kBrand : const Color(0xFF64748B), size: 18),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w900,
                      color: selected ? _kBrand : const Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 11.5,
                      height: 1.3,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF64748B),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _targetingSection(List<Category> cats, List<Product> allProds) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Tampilkan Add-on',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: Color(0xFF0F172A),
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Atur apakah add-on muncul untuk semua layanan atau hanya layanan tertentu.',
            style: TextStyle(
              fontSize: 12,
              height: 1.35,
              fontWeight: FontWeight.w600,
              color: Color(0xFF64748B),
            ),
          ),
          const SizedBox(height: 12),
          _scopeOption(
            selected: !_showAdvancedTargeting,
            icon: Icons.apps_rounded,
            title: 'Semua layanan',
            subtitle: 'Paling sederhana. Add-on muncul di semua order servis.',
            onTap: () => setState(() => _showAdvancedTargeting = false),
          ),
          const SizedBox(height: 8),
          _scopeOption(
            selected: _showAdvancedTargeting,
            icon: Icons.tune_rounded,
            title: 'Batasi ke layanan tertentu',
            subtitle:
                'Gunakan jika add-on hanya cocok untuk kategori/layanan tertentu.',
            onTap: () => setState(() => _showAdvancedTargeting = true),
          ),
          if (_showAdvancedTargeting) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFFEFF6FF),
                border: Border.all(color: const Color(0xFFBFDBFE)),
                borderRadius: BorderRadius.zero,
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline_rounded, color: _kBrand, size: 16),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Pilih kategori, produk, atau keduanya. Jika kosong, add-on tetap tampil untuk semua layanan.',
                      style: TextStyle(
                        fontSize: 11.5,
                        height: 1.35,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF1E3A8A),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            _buildTargetSelector(
              label: 'Kategori layanan',
              value: _selectedTargetCategoryText(cats),
              onTap: () => _showTargetCategoriesSheet(cats),
              isActive: _targetCategories.isNotEmpty,
            ),
            const SizedBox(height: 8),
            _buildTargetSelector(
              label: 'Layanan spesifik',
              value: _selectedTargetProductText(allProds),
              onTap: () => _showTargetProductsSheet(allProds),
              isActive: _targetProducts.isNotEmpty,
            ),
          ],
        ],
      ),
    );
  }

  void _showTargetCategoriesSheet(List<Category> allCats) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) {
          return DraggableScrollableSheet(
            expand: false,
            initialChildSize: 0.6,
            minChildSize: 0.4,
            maxChildSize: 0.9,
            builder: (_, sc) => Column(
              children: [
                const SizedBox(height: 16),
                const Text('Pilih Target Kategori',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                const Divider(),
                Expanded(
                  child: ListView.builder(
                    controller: sc,
                    itemCount: allCats.length,
                    itemBuilder: (_, i) {
                      final c = allCats[i];
                      if (c.id == null) return const SizedBox();
                      final isSelected = _targetCategories.contains(c.id);
                      return CheckboxListTile(
                        value: isSelected,
                        activeColor: _kBrand,
                        title: Text(c.name ?? ''),
                        onChanged: (val) {
                          setSheetState(() {
                            if (val == true) {
                              _targetCategories.add(c.id!);
                            } else {
                              _targetCategories.remove(c.id);
                            }
                          });
                          setState(() {});
                        },
                      );
                    },
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      minimumSize: const Size.fromHeight(50),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    child: const Text('Selesai',
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }

  void _showTargetProductsSheet(List<Product> allProds) {
    // Exclude extra products themselves from the target list
    final filtered =
        allProds.where((p) => p.isExtra == 0 && p.isMaterial == 0).toList();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) {
          return DraggableScrollableSheet(
            expand: false,
            initialChildSize: 0.6,
            minChildSize: 0.4,
            maxChildSize: 0.9,
            builder: (_, sc) => Column(
              children: [
                const SizedBox(height: 16),
                const Text('Pilih Target Produk',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                const Divider(),
                Expanded(
                  child: ListView.builder(
                    controller: sc,
                    itemCount: filtered.length,
                    itemBuilder: (_, i) {
                      final p = filtered[i];
                      if (p.id == null) return const SizedBox();
                      final isSelected = _targetProducts.contains(p.id);
                      return CheckboxListTile(
                        value: isSelected,
                        activeColor: _kBrand,
                        title: Text(p.name),
                        subtitle: Text('Rp${p.sellPrice}'),
                        onChanged: (val) {
                          setSheetState(() {
                            if (val == true) {
                              _targetProducts.add(p.id!);
                            } else {
                              _targetProducts.remove(p.id);
                            }
                          });
                          setState(() {});
                        },
                      );
                    },
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      minimumSize: const Size.fromHeight(50),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    child: const Text('Selesai',
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cats = ref.watch(categoriesProvider);
    _syncCategoryId(cats);
    final allProds = ref.watch(productsProvider);
    final isLandscapeMode =
        MediaQuery.of(context).orientation == Orientation.landscape;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _kBrand, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          widget.existing == null
              ? 'Tambah Layanan Tambahan'
              : 'Ubah Layanan Tambahan',
          style: const TextStyle(
              fontSize: 17, fontWeight: FontWeight.w600, color: Colors.black87),
        ),
      ),
      body: Form(
        key: _fk,
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: isLandscapeMode
              ? Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    //  Left Column
                    Expanded(
                      flex: 2,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GestureDetector(
                            onTap: () {
                              if (Platform.isWindows) {
                                _pickImage(ImageSource.gallery);
                              } else {
                                _showImageSourceDialog();
                              }
                            },
                            child: Container(
                              width: double.infinity,
                              height: 120,
                              decoration: BoxDecoration(
                                color: const Color(0xFFEEF2F7),
                                borderRadius: BorderRadius.zero,
                                border: Border.all(
                                    color: _imagePath != null
                                        ? _kBrand
                                        : Colors.grey.shade300),
                              ),
                              clipBehavior: Clip.antiAlias,
                              child: _imagePath != null &&
                                      File(_imagePath!).existsSync()
                                  ? Stack(
                                      fit: StackFit.expand,
                                      children: [
                                        Image.file(File(_imagePath!),
                                            fit: BoxFit.cover),
                                        Positioned(
                                          bottom: 0,
                                          left: 0,
                                          right: 0,
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 4),
                                            color: Colors.black54,
                                            child: const Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Icon(Icons.edit_rounded,
                                                    color: Colors.white,
                                                    size: 12),
                                                SizedBox(width: 4),
                                                Text('Ganti Gambar',
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 11,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    )
                                  : const Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.add_photo_alternate_outlined,
                                            color: Colors.grey, size: 28),
                                        Text('Unggah Foto Pilihan',
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.grey)),
                                      ],
                                    ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          _formField('Nama Add-on *', _name,
                              hint: 'Contoh: Biaya Kunjungan, Layanan Express',
                              validator: (v) =>
                                  (v ?? '').isEmpty ? 'Wajib diisi' : null),
                          const SizedBox(height: 12),
                          ModernPicker<Category>(
                            label: 'Kelompok Add-on',
                            value: _selectedCategory(cats),
                            items: cats,
                            itemLabel: (c) => c.name ?? '-',
                            onChanged: (v) =>
                                setState(() => _catId = v.id ?? 1),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 24),
                    //  Right Column
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                  child: _formField('Modal', _buy,
                                      hint: '0', isNum: true, isMoney: true)),
                              const SizedBox(width: 12),
                              Expanded(
                                  child: _formField('Harga Jual *', _sell,
                                      hint: '0',
                                      isNum: true,
                                      isMoney: true, validator: (v) {
                                if ((v ?? '').isEmpty) return 'Wajib';
                                if (parseCurrencyInput(v!) <
                                    parseCurrencyInput(_buy.text)) {
                                  return '- modal';
                                }
                                return null;
                              })),
                            ],
                          ),
                          const SizedBox(height: 16),
                          _targetingSection(cats, allProds),
                          const SizedBox(height: 24),
                          SizedBox(
                            width: double.infinity,
                            child: _loading
                                ? const Center(
                                    child: CircularProgressIndicator(
                                        color: _kBrand))
                                : ElevatedButton(
                                    onPressed: _save,
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: _kBrand,
                                      foregroundColor: Colors.white,
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 16),
                                      shape: const RoundedRectangleBorder(
                                          borderRadius: BorderRadius.zero),
                                      elevation: 0,
                                    ),
                                    child: Text(
                                      widget.existing == null
                                          ? 'Simpan Layanan Tambahan'
                                          : 'Update Layanan Tambahan',
                                      style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Image upload
                    GestureDetector(
                      onTap: () {
                        if (Platform.isWindows) {
                          _pickImage(ImageSource.gallery);
                        } else {
                          _showImageSourceDialog();
                        }
                      },
                      child: Container(
                        width: double.infinity,
                        height: 140,
                        decoration: BoxDecoration(
                          color: const Color(0xFFEEF2F7),
                          borderRadius: BorderRadius.zero,
                          border: Border.all(
                              color: _imagePath != null
                                  ? _kBrand
                                  : Colors.grey.shade300),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: _imagePath != null &&
                                File(_imagePath!).existsSync()
                            ? Stack(
                                fit: StackFit.expand,
                                children: [
                                  Image.file(File(_imagePath!),
                                      fit: BoxFit.cover),
                                  Positioned(
                                    bottom: 0,
                                    left: 0,
                                    right: 0,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 6),
                                      color: Colors.black54,
                                      child: const Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.edit_rounded,
                                              color: Colors.white, size: 14),
                                          SizedBox(width: 4),
                                          Text('Ganti Gambar',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              )
                            : const Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.add_photo_alternate_outlined,
                                      color: Colors.grey, size: 36),
                                  SizedBox(height: 8),
                                  Text('Unggah Foto Pilihan',
                                      style: TextStyle(
                                          fontSize: 13, color: Colors.grey)),
                                  Text('Kamera atau Galeri',
                                      style: TextStyle(
                                          fontSize: 11, color: Colors.grey)),
                                ],
                              ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Form fields
                    _formField('Nama Add-on *', _name,
                        hint: 'Contoh: Biaya Kunjungan, Layanan Express',
                        validator: (v) =>
                            (v ?? '').isEmpty ? 'Wajib diisi' : null),
                    const SizedBox(height: 12),

                    ModernPicker<Category>(
                      label: 'Kelompok Add-on',
                      value: _selectedCategory(cats),
                      items: cats,
                      itemLabel: (c) => c.name ?? '-',
                      onChanged: (v) => setState(() => _catId = v.id ?? 1),
                    ),
                    const SizedBox(height: 12),

                    Row(
                      children: [
                        Expanded(
                            child: _formField('Modal', _buy,
                                hint: '0', isNum: true, isMoney: true)),
                        const SizedBox(width: 12),
                        Expanded(
                            child: _formField('Harga Jual *', _sell,
                                hint: '0',
                                isNum: true,
                                isMoney: true, validator: (v) {
                          if ((v ?? '').isEmpty) return 'Wajib';
                          if (parseCurrencyInput(v!) <
                              parseCurrencyInput(_buy.text)) {
                            return '- modal';
                          }
                          return null;
                        })),
                      ],
                    ),
                    const SizedBox(height: 24),
                    _targetingSection(cats, allProds),
                    const SizedBox(height: 32),

                    SizedBox(
                      width: double.infinity,
                      child: _loading
                          ? const Center(
                              child: CircularProgressIndicator(color: _kBrand))
                          : ElevatedButton(
                              onPressed: _save,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _kBrand,
                                foregroundColor: Colors.white,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 16),
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.zero),
                              ),
                              child: Text(
                                widget.existing == null
                                    ? 'Simpan Layanan Tambahan'
                                    : 'Update Layanan Tambahan',
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                            ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _formField(String label, TextEditingController ctrl,
      {String hint = '',
      bool isNum = false,
      bool isMoney = false,
      String? helper,
      String? Function(String?)? validator}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Colors.black54)),
        const SizedBox(height: 4),
        TextFormField(
          controller: ctrl,
          keyboardType: isNum ? TextInputType.number : TextInputType.text,
          inputFormatters: isMoney
              ? const [CurrencyInputFormatter()]
              : isNum
                  ? [FilteringTextInputFormatter.digitsOnly]
                  : null,
          validator: validator,
          style: const TextStyle(fontSize: 14),
          decoration: _inputDeco(hint).copyWith(
            helperText: helper,
            helperStyle: const TextStyle(fontSize: 10, color: Colors.black38),
          ),
        ),
      ],
    );
  }
}

class _TemplatePaket {
  final String nama;
  final IconData icon;
  final String deskripsi;
  final String kategori;
  final List<Product> produk;
  const _TemplatePaket({
    required this.nama,
    required this.icon,
    required this.deskripsi,
    required this.kategori,
    required this.produk,
  });
}

