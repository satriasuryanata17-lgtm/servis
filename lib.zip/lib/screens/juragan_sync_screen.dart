import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:barcode_widget/barcode_widget.dart' as bw;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../core/theme.dart';
import '../providers/providers.dart';
import '../services/juragan_sync_service.dart';
import '../widgets/kasir_drawer.dart';
import 'responsive_layout.dart';

class JuraganSyncScreen extends ConsumerStatefulWidget {
  const JuraganSyncScreen({super.key});

  @override
  ConsumerState<JuraganSyncScreen> createState() => _JuraganSyncScreenState();
}

class _JuraganSyncScreenState extends ConsumerState<JuraganSyncScreen> {
  final _connectionCodeCtrl = TextEditingController();
  final _portCtrl =
      TextEditingController(text: '${JuraganSyncService.preferredPort}');
  final _pinCtrl = TextEditingController();

  final _service = JuraganSyncService.instance;
  StreamSubscription<JuraganSyncSummary>? _appliedSub;

  JuraganSyncServerInfo? _serverInfo;
  JuraganSyncResult? _lastResult;
  bool _receiverStarting = false;
  String? _receiverError;
  bool _startedByThisScreen = false;
  List<JuraganSyncDiscoveredPeer> _discoveredPeers = const [];
  bool _discovering = false;
  bool _hasSearchedPeers = false;
  String? _discoveryError;
  bool _busy = false;
  String _busyLabel = '';

  @override
  void initState() {
    super.initState();
    _loadServerInfo();
    _appliedSub = _service.appliedStream.listen((summary) {
      _refreshAfterSync();
      if (!mounted) return;
      _showSnack(
        'Data baru diterima: ${summary.products} layanan, ${summary.transactions} transaksi.',
      );
      _loadServerInfo();
    });
  }

  @override
  void dispose() {
    _appliedSub?.cancel();
    if (_startedByThisScreen) {
      unawaited(_service.stopServer());
    }
    _connectionCodeCtrl.dispose();
    _portCtrl.dispose();
    _pinCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadServerInfo() async {
    final info = await _service.serverInfo();
    if (mounted) setState(() => _serverInfo = info);
  }

  Future<void> _run(String label, Future<void> Function() action) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _busyLabel = label;
    });
    try {
      await action();
    } on TimeoutException {
      _showSnack(
          'Koneksi terlalu lama. Pastikan QR masih menyala dan kedua perangkat satu Wi-Fi/hotspot.',
          error: true);
    } on SocketException {
      _showSnack(
          'Perangkat tidak ditemukan. Pastikan QR masih menyala dan kedua perangkat satu Wi-Fi/hotspot.',
          error: true);
    } on HttpException catch (e) {
      _showSnack(e.message, error: true);
    } on FormatException catch (e) {
      _showSnack(e.message, error: true);
    } catch (e) {
      _showSnack('Sinkron gagal: $e', error: true);
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _busyLabel = '';
        });
      }
    }
  }

  Future<void> _startServer() async {
    await _startReceiver(showBusyOverlay: true);
  }

  Future<void> _startReceiver({required bool showBusyOverlay}) async {
    Future<void> start() async {
      setState(() {
        _receiverStarting = true;
        _receiverError = null;
      });
      try {
        final info = await _service.startServer().timeout(
              const Duration(seconds: 6),
            );
        if (!mounted) return;
        setState(() {
          _serverInfo = info;
          _startedByThisScreen = true;
        });
        if (info.ip == null || info.ip!.trim().isEmpty) {
          setState(() {
            _receiverError =
                'Tidak menemukan IP Wi-Fi. Pastikan perangkat tersambung ke Wi-Fi atau hotspot.';
          });
        }
      } on TimeoutException {
        if (mounted) {
          setState(() {
            _receiverError =
                'Terlalu lama menyiapkan QR. Coba tekan Buat QR Saya.';
          });
        }
      } catch (e) {
        if (mounted) {
          setState(() {
            _receiverError = _isActiveCashierSyncError(e)
                ? 'Kasir masih terbuka. Harap tutup kasir dulu sebelum membuat QR sinkronisasi.'
                : 'QR belum bisa dibuat. Cek izin jaringan atau coba buka ulang aplikasi.';
          });
        }
        rethrow;
      } finally {
        if (mounted) setState(() => _receiverStarting = false);
      }
    }

    if (showBusyOverlay) {
      await _run('Membuat QR saya...', start);
    } else {
      await start();
    }
  }

  Future<void> _stopServer() async {
    await _run('Menghentikan penerimaan...', () async {
      await _service.stopServer();
      setState(() {
        _receiverError = null;
        _receiverStarting = false;
        _startedByThisScreen = false;
      });
      await _loadServerInfo();
    });
  }

  Future<void> _syncNow({bool confirm = true}) async {
    final code = _connectionCodeCtrl.text.trim();
    final pin = _pinCtrl.text.trim();

    if (code.isEmpty || pin.length < 4) {
      _showSnack('Isi Kode Sambungan dan PIN dari perangkat pertama.',
          error: true);
      return;
    }

    await _syncWithCandidates(
      codes: [code],
      pin: pin,
      confirm: confirm,
    );
  }

  Future<void> _syncWithCandidates({
    required List<String> codes,
    required String pin,
    required bool confirm,
  }) async {
    final cleanedCodes = codes
        .map((code) => code.trim())
        .where((code) => code.isNotEmpty)
        .toSet()
        .toList();
    if (cleanedCodes.isEmpty || pin.trim().length < 4) {
      _showSnack('QR sinkron tidak lengkap. Buat ulang QR lalu scan lagi.',
          error: true);
      return;
    }

    if (confirm) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          title: const Text('Gabungkan data sekarang?'),
          content: const Text(
            'Data dari dua perangkat akan dijadikan satu. Setelah selesai, isi data di kedua perangkat akan sama.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBrand,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
              child: const Text('Ya, Gabungkan',
                  style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      );
      if (confirmed != true) return;
      await _settleRouteTransition();
      if (!mounted) return;
    }

    await _run('Menghubungkan perangkat...', () async {
      Object? lastError;
      JuraganSyncResult? result;
      var cancelled = false;
      for (final code in cleanedCodes) {
        final parsed = _parseConnectionCode(code);
        final host = parsed.$1;
        final port = parsed.$2;
        if (host.isEmpty || port == null) continue;
        try {
          final preview = await _service.previewSyncWithPeer(
            host: host,
            port: port,
            pin: pin,
          );
          if (!mounted) return;

          await _settleRouteTransition();
          if (!mounted) return;
          final proceed = await _showSyncPreview(preview);
          if (proceed != true) {
            cancelled = true;
            break;
          }
          if (!mounted) return;

          await _settleRouteTransition();
          if (!mounted) return;
          final settingsResolution = await _resolveSettingsConflict(preview);
          if (settingsResolution == null && preview.settingsConflict != null) {
            cancelled = true;
            break;
          }
          if (!mounted) return;

          await _settleRouteTransition();
          if (!mounted) return;
          final productResolutions = await _resolveProductConflicts(
            preview.productConflicts,
          );
          if (productResolutions == null) {
            cancelled = true;
            break;
          }
          if (!mounted) return;

          await _settleRouteTransition();
          if (!mounted) return;
          final resolutions = await _resolveTransactionDeleteConflicts(
            preview.transactionDeleteConflicts,
          );
          if (resolutions == null) {
            cancelled = true;
            break;
          }
          if (!mounted) return;

          await _settleRouteTransition();
          if (!mounted) return;
          result = await _service.applyPreview(
            preview,
            productResolutions: productResolutions,
            transactionResolutions: resolutions,
            settingsResolution: settingsResolution,
          );
          break;
        } catch (e) {
          lastError = e;
          if (_isActiveCashierSyncError(e)) break;
        }
      }

      if (cancelled) return;
      if (result == null) {
        throw FormatException(_syncErrorMessage(lastError));
      }

      _refreshAfterSync();
      if (mounted) {
        setState(() => _lastResult = result);
        _showSnack('Selesai. Data di dua perangkat sekarang sama.');
      }
    });
  }

  Future<void> _discoverPeers() async {
    if (_discovering || _busy) return;
    final shouldStartReceiver = _serverInfo?.running != true;
    setState(() {
      _discovering = true;
      _hasSearchedPeers = true;
      _discoveryError = null;
      _discoveredPeers = const [];
      if (shouldStartReceiver) {
        _receiverStarting = true;
        _receiverError = null;
      }
    });

    JuraganSyncServerInfo? receiverInfo;
    String? receiverError;
    var peers = const <JuraganSyncDiscoveredPeer>[];
    String? discoveryError;

    try {
      if (shouldStartReceiver) {
        try {
          receiverInfo = await _service.startServer().timeout(
                const Duration(seconds: 6),
              );
        } on TimeoutException {
          receiverError = 'Terlalu lama menyiapkan perangkat penerima.';
        } catch (e) {
          receiverError = _isActiveCashierSyncError(e)
              ? 'Kasir masih terbuka. Harap tutup kasir dulu sebelum mencari perangkat sinkron.'
              : 'Perangkat ini belum bisa ditemukan. Coba buka ulang aplikasi atau cek izin jaringan.';
        }
      }
      peers = await _service.discoverPeers();
    } catch (_) {
      discoveryError =
          'Pencarian perangkat gagal. Pastikan perangkat tersambung Wi-Fi/hotspot dan izinkan akses jaringan.';
    }

    if (!mounted) return;
    setState(() {
      if (receiverInfo != null) {
        _serverInfo = receiverInfo;
        _startedByThisScreen = true;
      }
      if (shouldStartReceiver) {
        _receiverError = receiverError;
        _receiverStarting = false;
      }
      _discoveredPeers = peers;
      _discoveryError = discoveryError;
      _discovering = false;
    });

    final snackMessage = discoveryError ??
        receiverError ??
        (peers.isEmpty
            ? 'Belum menemukan perangkat. Pastikan perangkat penerima aktif di Wi-Fi yang sama.'
            : 'Perangkat ditemukan: ${peers.length}');
    _showSnack(
      snackMessage,
      error: discoveryError != null || receiverError != null,
    );
  }

  Future<void> _settleRouteTransition() async {
    await Future<void>.delayed(const Duration(milliseconds: 120));
    if (!mounted) return;
    await WidgetsBinding.instance.endOfFrame;
  }

  Future<void> _syncDiscoveredPeer(JuraganSyncDiscoveredPeer peer) async {
    final pin = await _promptPin(
      title: 'PIN dari ${_deviceName(peer.device)}',
      subtitle: 'Masukkan PIN 6 digit yang tampil di perangkat tersebut.',
    );
    if (pin == null || pin.trim().isEmpty) return;
    _connectionCodeCtrl.text = peer.code;
    _pinCtrl.text = pin.trim();
    await _syncWithCandidates(
      codes: [peer.code],
      pin: pin.trim(),
      confirm: false,
    );
  }

  Future<String?> _promptPin({
    required String title,
    required String subtitle,
  }) async {
    final ctrl = TextEditingController();
    try {
      return await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          title: Text(title),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                subtitle,
                style: const TextStyle(
                  fontSize: 12.5,
                  color: AppColors.textBody,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: ctrl,
                autofocus: true,
                keyboardType: TextInputType.number,
                maxLength: 6,
                decoration: const InputDecoration(
                  counterText: '',
                  labelText: 'PIN Sinkron',
                  border: OutlineInputBorder(borderRadius: BorderRadius.zero),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(
                      color: AppColors.primaryBrand,
                      width: 1.4,
                    ),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBrand,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: const Text(
                'Lanjut',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      );
    } finally {
      ctrl.dispose();
    }
  }

  Future<bool> _showSyncPreview(JuraganSyncPreview preview) async {
    final plan = preview.plan;
    final touchedTables = plan.tables
        .where((item) => item.touched > 0 || item.table == 'settings')
        .toList();

    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Text('Preview Sinkronisasi'),
        content: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620, maxHeight: 580),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Perangkat tujuan: ${_deviceName(preview.peerDevice)} (${_roleLabel(preview.peerDevice.role)})',
                  style: const TextStyle(
                    fontSize: 12.5,
                    height: 1.4,
                    color: AppColors.textBody,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _previewMetric('Masuk', plan.incomingCount,
                        Icons.call_received_rounded, AppColors.success),
                    _previewMetric('Keluar', plan.outgoingCount,
                        Icons.call_made_rounded, AppColors.primaryBrand),
                    _previewMetric('Berubah', plan.changedCount,
                        Icons.edit_note_rounded, AppColors.warning),
                    _previewMetric('Konflik', plan.conflictCount,
                        Icons.rule_rounded, AppColors.danger),
                  ],
                ),
                const SizedBox(height: 14),
                const Text(
                  'Rencana perubahan',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: AppColors.textTitle,
                  ),
                ),
                const SizedBox(height: 8),
                if (touchedTables.isEmpty)
                  const Text(
                    'Tidak ada data baru. Sinkron tetap bisa dilanjutkan untuk memastikan kedua perangkat sama.',
                    style: TextStyle(
                      fontSize: 12.2,
                      height: 1.35,
                      color: AppColors.textBody,
                    ),
                  )
                else
                  for (final item in touchedTables) _previewTableRow(item),
                if (plan.conflictCount > 0) ...[
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    color: AppColors.warning.withValues(alpha: 0.10),
                    child: Text(
                      'Ada ${plan.conflictCount} konflik. Setelah lanjut, aplikasi akan meminta pilihan untuk data yang berbeda.',
                      style: const TextStyle(
                        fontSize: 12,
                        height: 1.35,
                        color: AppColors.textBody,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBrand,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
            child: const Text(
              'Lanjut',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );

    return confirmed == true;
  }

  Future<JuraganSyncSettingsResolution?> _resolveSettingsConflict(
    JuraganSyncPreview preview,
  ) async {
    final conflict = preview.settingsConflict;
    if (conflict == null) return null;

    var choice = JuraganSyncSettingsResolution.keepLocal;
    return showDialog<JuraganSyncSettingsResolution>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocalState) {
          return AlertDialog(
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            title: const Text('Pilih Pengaturan Toko'),
            content: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 560, maxHeight: 520),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Pengaturan berbeda: ${conflict.changedLabels.join(', ')}. Pilih satu sumber agar profil, admin, bank, dan QRIS tidak bercampur.',
                      style: const TextStyle(
                        fontSize: 12.5,
                        height: 1.4,
                        color: AppColors.textBody,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _ConflictChoice<JuraganSyncSettingsResolution>(
                      title: 'Pakai pengaturan perangkat ini',
                      subtitle: _settingsSummary(conflict, peer: false),
                      value: JuraganSyncSettingsResolution.keepLocal,
                      groupValue: choice,
                      onChanged: (value) {
                        setLocalState(() => choice = value);
                      },
                    ),
                    const Divider(height: 16, color: AppColors.border),
                    _ConflictChoice<JuraganSyncSettingsResolution>(
                      title: 'Pakai pengaturan perangkat lain',
                      subtitle: _settingsSummary(conflict, peer: true),
                      value: JuraganSyncSettingsResolution.usePeer,
                      groupValue: choice,
                      onChanged: (value) {
                        setLocalState(() => choice = value);
                      },
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Batal'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(ctx, choice),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBrand,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero,
                  ),
                ),
                child: const Text(
                  'Pakai Pilihan Ini',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<Map<String, JuraganSyncProductResolution>?> _resolveProductConflicts(
    List<JuraganSyncProductConflict> conflicts,
  ) async {
    if (conflicts.isEmpty) {
      return const <String, JuraganSyncProductResolution>{};
    }

    final choices = <String, JuraganSyncProductResolution>{
      for (final conflict in conflicts)
        conflict.key: JuraganSyncProductResolution.keepLocal,
    };

    return showDialog<Map<String, JuraganSyncProductResolution>>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocalState) {
          return AlertDialog(
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            title: const Text('Konfirmasi Layanan Berbeda'),
            content: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 620, maxHeight: 560),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Layanan/produk dengan nama/kode sama punya harga, software, aturan layanan, atau stok berbeda. Default aman memakai data perangkat ini.',
                      style: TextStyle(
                        fontSize: 12.5,
                        height: 1.4,
                        color: AppColors.textBody,
                      ),
                    ),
                    const SizedBox(height: 12),
                    for (final conflict in conflicts) ...[
                      _productConflictCard(
                        conflict: conflict,
                        value: choices[conflict.key] ??
                            JuraganSyncProductResolution.keepLocal,
                        onChanged: (value) {
                          setLocalState(() {
                            choices[conflict.key] = value;
                          });
                        },
                      ),
                      const SizedBox(height: 10),
                    ],
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Batal'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(
                  ctx,
                  Map<String, JuraganSyncProductResolution>.from(choices),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBrand,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero,
                  ),
                ),
                child: const Text(
                  'Lanjutkan',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<Map<String, JuraganSyncTransactionResolution>?>
      _resolveTransactionDeleteConflicts(
    List<JuraganSyncTransactionDeleteConflict> conflicts,
  ) async {
    if (conflicts.isEmpty) {
      return const <String, JuraganSyncTransactionResolution>{};
    }

    final choices = <String, JuraganSyncTransactionResolution>{
      for (final conflict in conflicts)
        conflict.key: JuraganSyncTransactionResolution.keepDeleted,
    };

    return showDialog<Map<String, JuraganSyncTransactionResolution>>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocalState) {
          return AlertDialog(
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            title: const Text('Konfirmasi Transaksi Terhapus'),
            content: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 560, maxHeight: 520),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Ada transaksi yang aktif di satu perangkat, tetapi sudah dihapus di perangkat lain. Pilihan aman adalah tetap hapus. Pilih pulihkan hanya kalau transaksi memang harus masuk lagi.',
                      style: TextStyle(
                        fontSize: 12.5,
                        height: 1.4,
                        color: AppColors.textBody,
                      ),
                    ),
                    const SizedBox(height: 12),
                    for (final conflict in conflicts) ...[
                      _TransactionDeleteConflictCard(
                        conflict: conflict,
                        value: choices[conflict.key] ??
                            JuraganSyncTransactionResolution.keepDeleted,
                        onChanged: (value) {
                          setLocalState(() {
                            choices[conflict.key] = value;
                          });
                        },
                      ),
                      const SizedBox(height: 10),
                    ],
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Batal'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(
                  ctx,
                  Map<String, JuraganSyncTransactionResolution>.from(choices),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBrand,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
                child: const Text(
                  'Lanjutkan Sinkron',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  String _syncErrorMessage(Object? error) {
    final text = error?.toString().toLowerCase() ?? '';
    if (_isActiveCashierSyncError(error)) {
      if (text.contains('perangkat lawan') ||
          text.contains('perangkat tersebut')) {
        return 'Perangkat lawan masih punya kasir terbuka. Tutup kasir di laptop/HP tersebut dulu, lalu sinkron ulang.';
      }
      return 'Kasir masih terbuka di perangkat ini. Harap tutup kasir dulu sebelum sinkronisasi.';
    }
    if (text.contains('cleartext') || text.contains('insecure http')) {
      return 'Android memblokir koneksi HTTP lokal. Update aplikasi di HP, lalu coba sinkron ulang.';
    }
    if (text.contains('connection closed') ||
        text.contains('connection reset') ||
        text.contains('timed out') ||
        text.contains('connection refused') ||
        text.contains('network is unreachable') ||
        text.contains('no route to host') ||
        text.contains('host is down') ||
        text.contains('failed host lookup')) {
      return 'Koneksi antar perangkat terblokir. Pastikan QR masih menyala, kedua perangkat satu Wi-Fi/hotspot, dan firewall Windows mengizinkan Juragan Servis di port 8090.';
    }
    if (text.contains('pin')) {
      return 'PIN sinkron tidak cocok. Buat ulang QR lalu scan lagi.';
    }
    return 'Tidak bisa terhubung ke perangkat lain. Pastikan QR masih tampil dan kedua perangkat satu Wi-Fi/hotspot.';
  }

  bool _isActiveCashierSyncError(Object? error) {
    final text = error?.toString().toLowerCase() ?? '';
    return text.contains('sesi kasir aktif') ||
        text.contains('kasir masih') ||
        text.contains('kasir terbuka') ||
        text.contains('tutup kasir') ||
        (text.contains('perangkat lawan') && text.contains('kasir'));
  }

  Future<void> _scanQrAndSync() async {
    final raw = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => const _JuraganSyncQrScanner(),
      ),
    );
    if (!mounted) return;
    if (raw == null || raw.trim().isEmpty) return;

    await _settleRouteTransition();
    if (!mounted) return;

    final payload = _parseQrPayload(raw);
    if (payload == null) {
      _showSnack('QR tidak dikenali. Scan QR dari halaman Sinkronisasi.',
          error: true);
      return;
    }

    _connectionCodeCtrl.text = payload.codes.first;
    _pinCtrl.text = payload.pin;
    await _syncWithCandidates(
      codes: payload.codes,
      pin: payload.pin,
      confirm: false,
    );
  }

  _SyncConnectPayload? _parseQrPayload(String raw) {
    final text = raw.trim();
    try {
      final decoded = jsonDecode(text);
      if (decoded is Map) {
        final type = decoded['type']?.toString() ?? '';
        if (type != 'juragan_sync_v1') return null;
        final code = decoded['code']?.toString().trim() ?? '';
        final rawCodes = decoded['codes'];
        final codes = <String>[
          if (code.isNotEmpty) code,
          if (rawCodes is List)
            ...rawCodes.map((item) => item.toString().trim()),
        ].where((item) => item.isNotEmpty).toSet().toList();
        final pin = decoded['pin']?.toString().trim() ?? '';
        if (codes.isEmpty || pin.isEmpty) return null;
        return _SyncConnectPayload(codes: codes, pin: pin);
      }
    } catch (_) {
      // Fallback for future simple payload formats.
    }

    final uri = Uri.tryParse(text);
    if (uri != null && uri.scheme == 'juragan-sync') {
      final host = uri.queryParameters['host']?.trim() ?? '';
      final port = uri.queryParameters['port']?.trim() ?? '';
      final pin = uri.queryParameters['pin']?.trim() ?? '';
      if (host.isNotEmpty && port.isNotEmpty && pin.isNotEmpty) {
        return _SyncConnectPayload(codes: ['$host:$port'], pin: pin);
      }
    }
    return null;
  }

  String _qrPayload(List<String> codes, String pin) {
    return jsonEncode({
      'type': 'juragan_sync_v1',
      'code': codes.first,
      'codes': codes,
      'pin': pin,
    });
  }

  (String, int?) _parseConnectionCode(String raw) {
    var value = raw.trim();
    if (value.startsWith('http://')) {
      value = value.substring('http://'.length);
    }
    if (value.startsWith('https://')) {
      value = value.substring('https://'.length);
    }
    value = value.split('/').first.trim();
    if (value.isEmpty) return ('', null);

    final parts = value.split(':');
    if (parts.length >= 2) {
      return (parts.first.trim(), int.tryParse(parts[1].trim()));
    }

    return (value, int.tryParse(_portCtrl.text.trim()));
  }

  void _refreshAfterSync() {
    ref.invalidate(categoriesProvider);
    ref.invalidate(categoryProductCountsProvider);
    ref.invalidate(productsProvider);
    ref.invalidate(customersProvider);
    ref.invalidate(employeesProvider);
    ref.invalidate(transactionsProvider);
    ref.invalidate(walletBalanceProvider);
    ref.invalidate(walletTransactionsProvider);
    ref.invalidate(dashboardProvider);
    ref.invalidate(salesTrendProvider);
    ref.invalidate(weeklySalesProvider);
    ref.invalidate(categorySalesProvider);
    ref.invalidate(salesReportProvider);
    ref.invalidate(insightsProvider);
    ref.invalidate(aiBusinessSnapshotProvider);
    ref.invalidate(discountsProvider);
    ref.invalidate(kasirSessionsProvider);
    ref.invalidate(activeKasirSessionProvider);
    ref.invalidate(drawerCashProvider);
    ref.invalidate(auditLogsProvider);
    ref.invalidate(returnsProvider);
    ref.invalidate(servisStationsProvider);
    ref.invalidate(servisWorkshopTicketsProvider);
  }

  void _showSnack(String message, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: error ? AppColors.danger : Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ),
    );
  }

  String _deviceName(JuraganSyncDeviceProfile profile) {
    final name = profile.name.trim();
    if (name.isNotEmpty) return name;
    switch (profile.platform.toLowerCase()) {
      case 'windows':
        return 'Komputer Windows';
      case 'android':
        return 'Perangkat Android';
      case 'ios':
        return 'iPhone / iPad';
      case 'macos':
        return 'Mac';
      default:
        return 'Perangkat Juragan Servis';
    }
  }

  String _roleLabel(String role) {
    switch (role) {
      case JuraganSyncService.deviceRoleOwner:
        return 'Owner';
      case JuraganSyncService.deviceRoleAdmin:
        return 'Admin';
      default:
        return 'Kasir';
    }
  }

  String _settingsSummary(
    JuraganSyncSettingsConflict conflict, {
    required bool peer,
  }) {
    final parts = <String>[];
    final store = peer ? conflict.peerStoreName : conflict.localStoreName;
    final address = peer ? conflict.peerAddress : conflict.localAddress;
    final payment = peer ? conflict.peerPaymentName : conflict.localPaymentName;

    if (store.trim().isNotEmpty) parts.add('Servis: $store');
    if (address.trim().isNotEmpty) parts.add('Alamat: $address');
    if (payment.trim().isNotEmpty) parts.add('Pembayaran: $payment');
    if (parts.isEmpty) return 'Belum ada ringkasan pengaturan.';
    return parts.join('\n');
  }

  String _productSummary(Map<String, dynamic> row) {
    final unit = _syncText(row['unit']);
    final duration = _syncInt(row['duration_hours']);
    final isHardware = _syncInt(row['is_hardware']) == 1;
    final isMaterial = _syncInt(row['is_material']) == 1;
    final isExtra = _syncInt(row['is_extra']) == 1;
    final parts = <String>[
      'Jual ${_formatSyncMoney(_syncInt(row['sell_price']))}',
      if (_syncInt(row['buy_price']) > 0)
        'Modal ${_formatSyncMoney(_syncInt(row['buy_price']))}',
      if (unit.isNotEmpty) 'Software $unit',
      if (duration > 0) 'Durasi $duration jam',
      if (isHardware) 'Layanan',
      if (isMaterial) 'Bahan baku',
      if (isExtra) 'Add-on',
    ];
    return parts.join('  |  ');
  }

  String _productChangedLabels(List<String> fields) {
    String label(String field) {
      switch (field) {
        case 'name':
          return 'Nama';
        case 'buy_price':
          return 'Harga modal';
        case 'sell_price':
          return 'Harga jual';
        case 'unit':
          return 'Software';
        case 'min_stock':
          return 'Stok minimum';
        case 'has_stock_management':
          return 'Manajemen stok';
        case 'has_wholesale':
        case 'wholesale_min_qty':
        case 'wholesale_price':
          return 'Grosir';
        case 'has_extra_popup':
        case 'is_extra':
        case 'extra_target_categories':
        case 'extra_target_products':
          return 'Add-on';
        case 'expiry_date':
          return 'Masa berlaku';
        case 'is_hardware':
          return 'Layanan';
        case 'duration_hours':
          return 'Durasi servis';
        case 'is_material':
          return 'Bahan baku';
        case 'supplier_id':
          return 'Supplier';
        default:
          return field;
      }
    }

    return fields.map(label).toSet().join(', ');
  }

  Future<void> _showHelpDialog() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Row(
          children: [
            Icon(Icons.help_outline_rounded, color: AppColors.primaryBrand),
            SizedBox(width: 10),
            Expanded(child: Text('Instruksi Sinkronisasi')),
          ],
        ),
        content: const SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _HelpStep(
                number: '1',
                title: 'Pakai Wi-Fi yang sama',
                body:
                    'Laptop dan HP harus tersambung ke Wi-Fi atau hotspot yang sama.',
              ),
              _HelpStep(
                number: '2',
                title: 'Lihat QR di perangkat pertama',
                body: 'Halaman ini otomatis menampilkan QR Sinkronisasi.',
              ),
              _HelpStep(
                number: '3',
                title: 'Scan dari perangkat kedua',
                body:
                    'Tekan Scan QR & Gabungkan Data, lalu arahkan kamera ke QR perangkat pertama.',
              ),
              _HelpStep(
                number: '4',
                title: 'Tunggu selesai',
                body:
                    'Setelah QR terbaca, aplikasi langsung menggabungkan data. Laptop dan HP akan punya data yang sama.',
              ),
              _HelpStep(
                number: '5',
                title: 'Kalau gagal',
                body:
                    'Pastikan kedua perangkat masih satu Wi-Fi, aplikasi tetap terbuka, dan izinkan akses jaringan jika Windows menanyakan firewall. Cara manual tetap tersedia di bawah tombol scan.',
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Mengerti'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final canGoBack = Navigator.canPop(context);

    return KasirResponsiveScaffold(
      title: 'Sinkronisasi',
      leading: canGoBack
          ? IconButton(
              tooltip: MaterialLocalizations.of(context).backButtonTooltip,
              icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
              onPressed: () => Navigator.maybePop(context),
            )
          : null,
      actions: [
        IconButton(
          tooltip: 'Instruksi sinkron',
          onPressed: _showHelpDialog,
          icon: const Icon(Icons.help_outline_rounded),
          color: AppColors.primaryBrand,
        ),
      ],
      showNavRail: true,
      navIndex: 11,
      drawer: const KasirDrawer(),
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          RefreshIndicator(
            onRefresh: _loadServerInfo,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
              children: [
                _heroPanel(),
                const SizedBox(height: 14),
                LayoutBuilder(
                  builder: (context, c) {
                    final wide = c.maxWidth >= 760;
                    final panels = [
                      Expanded(child: _receivePanel()),
                      const SizedBox(width: 14, height: 14),
                      Expanded(child: _sendPanel()),
                    ];
                    if (wide) {
                      return Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: panels);
                    }
                    return Column(
                      children: [
                        _receivePanel(),
                        const SizedBox(height: 14),
                        _sendPanel(),
                      ],
                    );
                  },
                ),
                if (_lastResult != null) ...[
                  const SizedBox(height: 14),
                  _resultPanel(_lastResult!),
                ],
              ],
            ),
          ),
          if (_busy) _busyOverlay(),
        ],
      ),
    );
  }

  Widget _heroPanel() {
    return _panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                color: AppColors.brandLight,
                child: const Icon(Icons.sync_rounded,
                    color: AppColors.primaryBrand),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'Sinkron Semua Perangkat',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    color: AppColors.textTitle,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          const Text(
            'Bisa HP ke HP, HP ke laptop, dan laptop ke laptop selama berada di Wi-Fi atau hotspot yang sama. QR tidak menyala otomatis agar lebih hemat baterai.',
            style: TextStyle(
              fontSize: 12.5,
              height: 1.4,
              color: AppColors.textBody,
            ),
          ),
          const SizedBox(height: 12),
          const Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _SyncChip(icon: Icons.phone_android_rounded, label: 'HP ke HP'),
              _SyncChip(icon: Icons.devices_rounded, label: 'HP ke Laptop'),
              _SyncChip(
                  icon: Icons.laptop_mac_rounded, label: 'Laptop ke Laptop'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _receivePanel() {
    final info = _serverInfo;
    final running = info?.running == true;
    final ip = info?.ip ?? '-';
    final port =
        info?.port == 0 ? JuraganSyncService.preferredPort : info?.port;
    final pin = running ? info?.pin ?? '-' : '-';
    final codes = running && port != null
        ? (info?.ips ?? const <String>[])
            .map((item) => '$item:$port')
            .where((item) => item.trim().isNotEmpty)
            .toSet()
            .toList()
        : const <String>[];
    final code = codes.isNotEmpty ? codes.first : '-';
    final canShowQr = running && codes.isNotEmpty && ip != '-' && pin != '-';
    final expiresAt = info?.expiresAt;
    final expiresText = expiresAt == null
        ? null
        : 'QR aktif sampai ${expiresAt.hour.toString().padLeft(2, '0')}:${expiresAt.minute.toString().padLeft(2, '0')}';

    return _panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.qr_code_2_rounded, '1. Tampilkan QR Ini'),
          const SizedBox(height: 8),
          Text(
            canShowQr
                ? 'Biarkan QR ini terlihat. Scan dari perangkat satunya.'
                : 'Tekan Buat QR Saya hanya saat mau sinkron.',
            style: const TextStyle(
              fontSize: 12.5,
              height: 1.35,
              color: AppColors.textBody,
            ),
          ),
          const SizedBox(height: 14),
          _qrBox(
            data: canShowQr ? _qrPayload(codes, pin) : null,
            preparing: _receiverStarting,
            error: _receiverError,
          ),
          if (canShowQr && expiresText != null) ...[
            const SizedBox(height: 8),
            Text(
              expiresText,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 11.5,
                color: AppColors.textCaption,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
          const SizedBox(height: 12),
          _smallCodeRow(code: code, pin: pin, enabled: canShowQr),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _busy || _receiverStarting
                  ? null
                  : (running ? _stopServer : _startServer),
              icon: Icon(running ? Icons.stop_rounded : Icons.qr_code_rounded),
              label: Text(running ? 'Matikan QR Saya' : 'Buat QR Saya'),
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    running ? AppColors.danger : AppColors.primaryBrand,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sendPanel() {
    return _panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(
              Icons.qr_code_scanner_rounded, '2. Scan Perangkat Lain'),
          const SizedBox(height: 8),
          const Text(
            'Di perangkat satunya, tekan tombol ini lalu arahkan kamera ke QR.',
            style: TextStyle(
              fontSize: 12.5,
              height: 1.35,
              color: AppColors.textBody,
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _busy ? null : _scanQrAndSync,
              icon: const Icon(Icons.qr_code_scanner_rounded),
              label: const Text('Scan QR & Sinkronkan'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBrand,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                padding: const EdgeInsets.symmetric(vertical: 16),
                textStyle: const TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          _discoveryArea(),
          const SizedBox(height: 12),
          Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
              tilePadding: EdgeInsets.zero,
              childrenPadding: EdgeInsets.zero,
              title: const Text(
                'Cara manual jika kamera bermasalah',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textBody,
                ),
              ),
              children: [
                const SizedBox(height: 8),
                _input(
                  controller: _connectionCodeCtrl,
                  label: 'Kode Sambungan',
                  hint: 'Contoh: 192.168.1.8:8090',
                  keyboardType: TextInputType.text,
                ),
                const SizedBox(height: 10),
                _input(
                  controller: _pinCtrl,
                  label: 'PIN',
                  hint: '6 digit',
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _busy ? null : () => _syncNow(),
                    icon: const Icon(Icons.keyboard_rounded),
                    label: const Text('Gabungkan Manual'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primaryBrand,
                      side: const BorderSide(color: AppColors.primaryBrand),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _discoveryArea() {
    final showStatus = _discovering ||
        _hasSearchedPeers ||
        _discoveryError != null ||
        _discoveredPeers.isNotEmpty;
    final searchButton = ElevatedButton.icon(
      onPressed: _discovering || _busy ? null : _discoverPeers,
      icon: _discovering
          ? const SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white,
              ),
            )
          : const Icon(Icons.search_rounded, size: 17),
      label: Text(_discovering ? 'Mencari...' : 'Cari Perangkat'),
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primaryBrand,
        foregroundColor: Colors.white,
        disabledBackgroundColor: AppColors.primaryBrand.withValues(alpha: 0.45),
        disabledForegroundColor: Colors.white,
        elevation: 0,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        minimumSize: const Size(0, 36),
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
      ),
    );

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.background,
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 350;
              final title = _sectionTitle(Icons.radar_rounded, 'Cari Otomatis');
              if (compact) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    title,
                    const SizedBox(height: 8),
                    Align(alignment: Alignment.centerLeft, child: searchButton),
                  ],
                );
              }
              return Row(
                children: [
                  Expanded(child: title),
                  const SizedBox(width: 8),
                  searchButton,
                ],
              );
            },
          ),
          if (showStatus) ...[
            const SizedBox(height: 10),
            _discoveryStatusCard(),
          ],
          if (_discoveredPeers.isNotEmpty) ...[
            const SizedBox(height: 12),
            for (final peer in _discoveredPeers)
              _DiscoveredPeerTile(
                peer: peer,
                displayName: _deviceName(peer.device),
                roleLabel: _roleLabel(peer.device.role),
                onTap: () => _syncDiscoveredPeer(peer),
              ),
          ],
        ],
      ),
    );
  }

  Widget _discoveryStatusCard() {
    final hasReceiver = _serverInfo?.running == true;
    final hasPeers = _discoveredPeers.isNotEmpty;
    final statusColor = _discoveryError != null
        ? AppColors.danger
        : hasPeers
            ? AppColors.success
            : _hasSearchedPeers
                ? AppColors.warning
                : AppColors.primaryBrand;
    final title = _discovering
        ? 'Mencari perangkat di jaringan...'
        : _discoveryError != null
            ? 'Pencarian gagal'
            : hasPeers
                ? '${_discoveredPeers.length} perangkat ditemukan'
                : _hasSearchedPeers
                    ? 'Belum ada perangkat ditemukan'
                    : 'Siap mencari perangkat';
    final body = _discovering
        ? 'Memindai Wi-Fi/hotspot yang sama.'
        : _discoveryError ??
            (hasPeers
                ? 'Pilih perangkat, lalu masukkan PIN.'
                : _hasSearchedPeers
                    ? 'Cek Wi-Fi, hotspot, atau firewall Windows.'
                    : hasReceiver
                        ? 'Perangkat ini siap ditemukan.'
                        : 'Tekan Cari Perangkat di dua perangkat.');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
      decoration: BoxDecoration(
        color: statusColor.withValues(alpha: 0.08),
        border: Border.all(color: statusColor.withValues(alpha: 0.22)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 20,
            height: 20,
            child: _discovering
                ? CircularProgressIndicator(
                    strokeWidth: 2.2,
                    color: statusColor,
                  )
                : Icon(
                    _discoveryError != null
                        ? Icons.error_outline_rounded
                        : hasPeers
                            ? Icons.check_circle_outline_rounded
                            : _hasSearchedPeers
                                ? Icons.wifi_find_rounded
                                : Icons.info_outline_rounded,
                    size: 19,
                    color: statusColor,
                  ),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Wrap(
              spacing: 8,
              runSpacing: 2,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12.2,
                    height: 1.25,
                    color: statusColor,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  body,
                  style: const TextStyle(
                    fontSize: 11.8,
                    height: 1.35,
                    color: AppColors.textBody,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _resultPanel(JuraganSyncResult result) {
    final plan = result.plan;
    return _panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.verified_rounded, 'Hasil Sinkron Terakhir'),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _previewMetric('Masuk', plan.incomingCount,
                  Icons.call_received_rounded, AppColors.success),
              _previewMetric('Keluar', plan.outgoingCount,
                  Icons.call_made_rounded, AppColors.primaryBrand),
              _previewMetric('Berubah', plan.changedCount,
                  Icons.edit_note_rounded, AppColors.warning),
              _previewMetric('Konflik', plan.conflictCount, Icons.rule_rounded,
                  AppColors.danger),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _metric('Layanan', result.after.products)),
              Expanded(child: _metric('Transaksi', result.after.transactions)),
              Expanded(child: _metric('Pelanggan', result.after.customers)),
              Expanded(child: _metric('Supplier', result.after.suppliers)),
            ],
          ),
          if ((result.backupPath ?? '').isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              'Backup sebelum sinkron: ${result.backupPath}',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 11.5,
                height: 1.3,
                color: AppColors.textCaption,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _panel({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.border),
        boxShadow: Sh.xs,
      ),
      child: child,
    );
  }

  Widget _sectionTitle(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, size: 20, color: AppColors.primaryBrand),
        const SizedBox(width: 8),
        Text(
          text,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w800,
            color: AppColors.textTitle,
          ),
        ),
      ],
    );
  }

  Widget _qrBox({
    required String? data,
    required bool preparing,
    required String? error,
  }) {
    return Center(
      child: Container(
        width: 220,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: AppColors.border),
        ),
        child: data != null
            ? bw.BarcodeWidget(
                barcode: bw.Barcode.qrCode(),
                data: data,
                width: 180,
                height: 180,
              )
            : SizedBox(
                width: 180,
                height: 180,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (preparing) ...[
                      const SizedBox(
                        width: 28,
                        height: 28,
                        child: CircularProgressIndicator(strokeWidth: 2.6),
                      ),
                      const SizedBox(height: 14),
                      const Text(
                        'Menyiapkan QR...',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: AppColors.textTitle,
                        ),
                      ),
                    ] else ...[
                      const Icon(
                        Icons.qr_code_2_rounded,
                        size: 42,
                        color: AppColors.primaryBrand,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        error ?? 'QR belum aktif.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 12,
                          height: 1.35,
                          color: AppColors.textBody,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
      ),
    );
  }

  Widget _smallCodeRow({
    required String code,
    required String pin,
    required bool enabled,
  }) {
    return Container(
      padding: const EdgeInsets.all(10),
      color: AppColors.background,
      child: Row(
        children: [
          Expanded(
            child: Text(
              enabled ? 'Kode: $code  |  PIN: $pin' : 'Menyiapkan kode...',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.textBody,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          IconButton(
            tooltip: 'Salin kode manual',
            onPressed: enabled
                ? () {
                    Clipboard.setData(ClipboardData(text: '$code\nPIN: $pin'));
                    _showSnack('Kode manual disalin.');
                  }
                : null,
            icon: const Icon(Icons.copy_rounded, size: 18),
            color: AppColors.primaryBrand,
          ),
        ],
      ),
    );
  }

  Widget _input({
    required TextEditingController controller,
    required String label,
    required String hint,
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: AppColors.surface,
        border: const OutlineInputBorder(borderRadius: BorderRadius.zero),
        enabledBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: AppColors.border),
        ),
        focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: AppColors.primaryBrand, width: 1.4),
        ),
      ),
    );
  }

  Widget _metric(String label, int value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value.toString(),
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w900,
              color: AppColors.primaryBrand,
            ),
          ),
          Text(
            label,
            style: const TextStyle(
              fontSize: 11.5,
              color: AppColors.textCaption,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _previewMetric(
    String label,
    int value,
    IconData icon,
    Color color,
  ) {
    return Container(
      width: 132,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        border: Border.all(color: color.withValues(alpha: 0.20)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value.toString(),
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: color,
                  ),
                ),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textBody,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _previewTableRow(JuraganSyncTablePlan item) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: AppColors.background,
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              item.label,
              style: const TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w900,
                color: AppColors.textTitle,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Text(
            'Masuk ${item.peerOnly} | Keluar ${item.localOnly} | Ubah ${item.changed}',
            textAlign: TextAlign.right,
            style: const TextStyle(
              fontSize: 11.2,
              color: AppColors.textBody,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _productConflictCard({
    required JuraganSyncProductConflict conflict,
    required JuraganSyncProductResolution value,
    required ValueChanged<JuraganSyncProductResolution> onChanged,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.background,
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            conflict.name,
            style: const TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w900,
              color: AppColors.textTitle,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Berbeda: ${_productChangedLabels(conflict.changedFields)}',
            style: const TextStyle(
              fontSize: 11.5,
              height: 1.35,
              color: AppColors.textBody,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 10),
          _ConflictChoice<JuraganSyncProductResolution>(
            title: 'Pakai data perangkat ini',
            subtitle: _productSummary(conflict.localRow),
            value: JuraganSyncProductResolution.keepLocal,
            groupValue: value,
            onChanged: onChanged,
          ),
          _ConflictChoice<JuraganSyncProductResolution>(
            title: 'Pakai data perangkat lain',
            subtitle: _productSummary(conflict.peerRow),
            value: JuraganSyncProductResolution.usePeer,
            groupValue: value,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _busyOverlay() {
    return Container(
      color: Colors.black.withValues(alpha: 0.18),
      child: Center(
        child: Container(
          width: 280,
          padding: const EdgeInsets.all(18),
          color: AppColors.surface,
          child: Row(
            children: [
              const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(strokeWidth: 2.4),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  _busyLabel,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    color: AppColors.textTitle,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DiscoveredPeerTile extends StatelessWidget {
  final JuraganSyncDiscoveredPeer peer;
  final String displayName;
  final String roleLabel;
  final VoidCallback onTap;

  const _DiscoveredPeerTile({
    required this.peer,
    required this.displayName,
    required this.roleLabel,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: AppColors.background,
        border: Border.all(color: AppColors.border),
      ),
      child: ListTile(
        dense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        leading: Container(
          width: 34,
          height: 34,
          color: AppColors.brandLight,
          child: const Icon(
            Icons.devices_rounded,
            color: AppColors.primaryBrand,
            size: 18,
          ),
        ),
        title: Text(
          displayName,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontSize: 13.2,
            fontWeight: FontWeight.w900,
            color: AppColors.textTitle,
          ),
        ),
        subtitle: Text(
          '$roleLabel  |  ${peer.code}',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontSize: 11.5,
            color: AppColors.textBody,
          ),
        ),
        trailing: const Icon(
          Icons.chevron_right_rounded,
          color: AppColors.textCaption,
        ),
        onTap: onTap,
      ),
    );
  }
}

class _HelpStep extends StatelessWidget {
  final String number;
  final String title;
  final String body;

  const _HelpStep({
    required this.number,
    required this.title,
    required this.body,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 26,
            height: 26,
            alignment: Alignment.center,
            color: AppColors.brandLight,
            child: Text(
              number,
              style: const TextStyle(
                color: AppColors.primaryBrand,
                fontWeight: FontWeight.w900,
                fontSize: 12,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textTitle,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  body,
                  style: const TextStyle(
                    fontSize: 12.5,
                    height: 1.35,
                    color: AppColors.textBody,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TransactionDeleteConflictCard extends StatelessWidget {
  final JuraganSyncTransactionDeleteConflict conflict;
  final JuraganSyncTransactionResolution value;
  final ValueChanged<JuraganSyncTransactionResolution> onChanged;

  const _TransactionDeleteConflictCard({
    required this.conflict,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final customer = conflict.customerName.trim();
    final deletedSource = conflict.deletedOnPeer
        ? 'Dihapus di perangkat lain'
        : 'Dihapus di perangkat ini';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.background,
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      conflict.transactionCode,
                      style: const TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w900,
                        color: AppColors.textTitle,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      [
                        _formatSyncMoney(conflict.grandTotal),
                        _formatSyncDateTime(conflict.createdAt),
                        if (customer.isNotEmpty) customer,
                      ].join('  |  '),
                      style: const TextStyle(
                        fontSize: 11.5,
                        height: 1.35,
                        color: AppColors.textBody,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                color: AppColors.danger.withValues(alpha: 0.10),
                child: Text(
                  deletedSource,
                  style: const TextStyle(
                    fontSize: 10.5,
                    color: AppColors.danger,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _ConflictChoice(
            title: 'Tetap hapus',
            subtitle:
                'Transaksi tidak muncul lagi di kedua perangkat setelah sinkron.',
            value: JuraganSyncTransactionResolution.keepDeleted,
            groupValue: value,
            onChanged: onChanged,
          ),
          _ConflictChoice(
            title: 'Pulihkan transaksi',
            subtitle:
                'Transaksi masuk lagi ke kedua perangkat. Pilih hanya jika hapusnya keliru.',
            value: JuraganSyncTransactionResolution.restoreActive,
            groupValue: value,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class _ConflictChoice<T> extends StatelessWidget {
  final String title;
  final String subtitle;
  final T value;
  final T groupValue;
  final ValueChanged<T> onChanged;

  const _ConflictChoice({
    required this.title,
    required this.subtitle,
    required this.value,
    required this.groupValue,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final selected = value == groupValue;
    return InkWell(
      onTap: () => onChanged(value),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              selected
                  ? Icons.radio_button_checked_rounded
                  : Icons.radio_button_off_rounded,
              size: 20,
              color: selected ? AppColors.primaryBrand : AppColors.textCaption,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textTitle,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 11.5,
                      height: 1.25,
                      color: AppColors.textBody,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

String _formatSyncMoney(int value) {
  final digits = value.abs().toString();
  final buffer = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buffer.write('.');
    buffer.write(digits[i]);
  }
  return 'Rp${value < 0 ? '-' : ''}$buffer';
}

int _syncInt(Object? value) {
  if (value == null) return 0;
  if (value is int) return value;
  if (value is num) return value.round();
  return int.tryParse(value.toString().trim()) ?? 0;
}

String _syncText(Object? value) {
  if (value == null) return '';
  return value.toString().trim();
}

String _formatSyncDateTime(String raw) {
  final parsed = DateTime.tryParse(raw);
  if (parsed == null) return raw.isEmpty ? '-' : raw;
  String two(int value) => value.toString().padLeft(2, '0');
  return '${two(parsed.day)}/${two(parsed.month)}/${parsed.year} ${two(parsed.hour)}:${two(parsed.minute)}';
}

class _SyncConnectPayload {
  final List<String> codes;
  final String pin;

  const _SyncConnectPayload({
    required this.codes,
    required this.pin,
  });
}

class _SyncChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _SyncChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      color: AppColors.brandLight,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: AppColors.primaryBrand),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w800,
              color: AppColors.primaryBrand,
            ),
          ),
        ],
      ),
    );
  }
}

class _JuraganSyncQrScanner extends StatefulWidget {
  const _JuraganSyncQrScanner();

  @override
  State<_JuraganSyncQrScanner> createState() => _JuraganSyncQrScannerState();
}

class _JuraganSyncQrScannerState extends State<_JuraganSyncQrScanner> {
  late final MobileScannerController _controller;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _controller = MobileScannerController(
      detectionSpeed: DetectionSpeed.noDuplicates,
      facing: CameraFacing.back,
      formats: const [BarcodeFormat.qrCode],
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (_done || capture.barcodes.isEmpty) return;
    final raw =
        capture.barcodes.first.rawValue ?? capture.barcodes.first.displayValue;
    if (raw == null || raw.trim().isEmpty) return;
    _done = true;
    Navigator.pop(context, raw.trim());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Scan QR Sinkronisasi'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
      ),
      body: Stack(
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: _onDetect,
          ),
          Positioned.fill(
            child: IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.black.withValues(alpha: 0.25),
                    width: 28,
                  ),
                ),
                child: Center(
                  child: Container(
                    width: 250,
                    height: 250,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: AppColors.primaryBrand,
                        width: 3,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 18,
            right: 18,
            bottom: 28,
            child: Container(
              padding: const EdgeInsets.all(14),
              color: Colors.black.withValues(alpha: 0.72),
              child: const Text(
                'Arahkan kamera ke QR Sinkronisasi di perangkat satunya. Setelah terbaca, data langsung digabung.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  height: 1.35,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

