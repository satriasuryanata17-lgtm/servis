import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';
import '../widgets/export_dropdown.dart';
import '../services/export_service.dart';
import 'struk_screen.dart';

const Color _kBrand = AppColors.primaryBrand;

String _fK(int n) {
  if (n == 0) return '0';
  String s = n.toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return r;
}

//
//  RETUR SCREEN  -  Responsive (Phone + Tablet/Landscape)
//
class ReturScreen extends ConsumerStatefulWidget {
  const ReturScreen({super.key});

  @override
  ConsumerState<ReturScreen> createState() => _ReturScreenState();
}

class _ReturScreenState extends ConsumerState<ReturScreen> {
  bool _isWide(BuildContext context) =>
      MediaQuery.of(context).size.width >= 720;

  @override
  Widget build(BuildContext context) {
    final returns = ref.watch(returnsProvider);
    final wide = _isWide(context);

    final exportAction = Padding(
      padding: const EdgeInsets.only(right: 16),
      child: GestureDetector(
        onTap: () => _handleExport(returns),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: const BoxDecoration(
            color: AppColors.primaryBrand,
            borderRadius: BorderRadius.zero,
          ),
          child: const Row(
            children: [
              Icon(Icons.download_rounded, color: Colors.white, size: 15),
              SizedBox(width: 5),
              Text(
                'Ekspor',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );

    return KasirResponsiveScaffold(
      title: 'Laporan Komplain & Refund',
      navIndex: 4,
      showNavRail: false,
      actions: [exportAction],
      backgroundColor: wide ? const Color(0xFFF5F5F7) : Colors.white,
      body: Column(
        children: [
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          Expanded(
            child: wide ? _buildTabletBody(returns) : _buildPhoneBody(returns),
          ),
        ],
      ),
    );
  }

  Widget _buildPhoneBody(List<ReturnTransaction> returns) {
    return Column(
      children: [
        _ReturSummaryCard(returns: returns),
        Expanded(
          child: returns.isEmpty
              ? _EmptyReturView()
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  itemCount: returns.length,
                  itemBuilder: (_, i) => _ReturCard(ret: returns[i]),
                ),
        ),
      ],
    );
  }

  Widget _buildTabletBody(List<ReturnTransaction> returns) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 300,
          color: Colors.white,
          child: Column(
            children: [
              const SizedBox(height: 12),
              _ReturSummaryCard(returns: returns),
              const SizedBox(height: 12),
              _TabletStatsPanel(returns: returns),
              const Spacer(),
            ],
          ),
        ),
        const VerticalDivider(width: 1, color: Color(0xFFEEEEEE)),
        Expanded(
          child: returns.isEmpty
              ? _EmptyReturView()
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                  itemCount: returns.length,
                  itemBuilder: (_, i) => _ReturCard(ret: returns[i]),
                ),
        ),
      ],
    );
  }

  Future<void> _handleExport(List<ReturnTransaction> returns) async {
    if (returns.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Belum ada data komplain/refund untuk diekspor'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
      return;
    }

    final choice = await ExportDropdown.show(context);
    if (choice == null) return;

    final tunaiCount = returns.where((r) => r.isCashRefund).length;
    final totalRefund = returns.fold<int>(0, (s, r) => s + r.totalRefund);

    final Map<String, String> summaryData = {
      'Total Refund': 'Rp${_fK(totalRefund)}',
      'Total Kasus': '${returns.length}',
      'Refund Tunai': '$tunaiCount',
      'Refund Non Tunai': '${returns.length - tunaiCount}',
    };

    final headers = [
      'ID',
      'ID Transaksi',
      'Pelanggan',
      'Alasan',
      'Metode',
      'Total Refund',
      'Tanggal',
    ];

    final rows = returns
        .map((r) => [
              '#${r.id}',
              '#${r.transactionId}',
              r.customerName ?? '-',
              r.reasonLabel,
              r.refundMethodLabel,
              'Rp${_fK(r.totalRefund)}',
              _formatDate(r.createdAt),
            ])
        .toList();

    const title = 'Laporan Komplain & Refund Layanan';

    try {
      if (choice == 'csv') {
        await ExportService.exportAndShareCsv(
          filePrefix: 'laporan_retur',
          headers: [
            'ID',
            'ID Transaksi',
            'Pelanggan',
            'Alasan',
            'Metode Refund',
            'Total Refund',
            'Tanggal',
          ],
          rows: returns
              .map((r) => [
                    r.id,
                    r.transactionId,
                    r.customerName ?? '-',
                    r.reasonLabel,
                    r.refundMethodLabel,
                    r.totalRefund,
                    r.createdAt,
                  ])
              .toList(),
          subject: 'Laporan Komplain & Refund',
        );
      } else if (choice == 'pdf') {
        await ExportService.exportPdfLaporan(
          title: title,
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      } else if (choice == 'print') {
        await ExportService.printPdfLaporan(
          title: title,
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Gagal mengekspor data komplain/refund. Coba lagi.')),
      );
    }
  }

  String _formatDate(String iso) {
    final dt = DateTime.tryParse(iso);
    if (dt == null) return iso;
    return DateFormat('dd/MM/yyyy HH:mm', 'id').format(dt);
  }
}

class _TabletStatsPanel extends StatelessWidget {
  final List<ReturnTransaction> returns;
  const _TabletStatsPanel({required this.returns});

  @override
  Widget build(BuildContext context) {
    final tunaiCount = returns.where((r) => r.isCashRefund).length;
    final nonTunaiCount = returns.where((r) => !r.isCashRefund).length;

    final stats = [
      (
        label: 'Total Kasus',
        value: '${returns.length}',
        icon: Icons.assignment_return_outlined,
        color: _kBrand
      ),
      (
        label: 'Refund Tunai',
        value: '$tunaiCount',
        icon: Icons.money,
        color: const Color(0xFF059669)
      ),
      (
        label: 'Refund Non Tunai',
        value: '$nonTunaiCount',
        icon: Icons.credit_card,
        color: const Color(0xFF2563EB)
      ),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(
        children: stats.map((s) {
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: s.color.withValues(alpha: 0.06),
              borderRadius: BorderRadius.zero,
              border: Border.all(color: s.color.withValues(alpha: 0.18)),
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: s.color.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Icon(s.icon, color: s.color, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(s.label,
                      style:
                          const TextStyle(fontSize: 12, color: Colors.black54)),
                ),
                Text(
                  s.value,
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: s.color),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _ReturSummaryCard extends StatelessWidget {
  final List<ReturnTransaction> returns;
  const _ReturSummaryCard({required this.returns});

  @override
  Widget build(BuildContext context) {
    final totalRefund = returns.fold<int>(0, (s, r) => s + r.totalRefund);
    final totalCount = returns.length;
    final tunaiCount = returns.where((r) => r.isCashRefund).length;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _kBrand,
          borderRadius: BorderRadius.zero,
          boxShadow: [
            BoxShadow(
              color: _kBrand.withValues(alpha: 0.25),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Total Refund',
                      style: TextStyle(
                          fontSize: 10,
                          color: Colors.white.withValues(alpha: 0.8),
                          fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text('Rp${_fK(totalRefund)}',
                      style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: Colors.white)),
                ],
              ),
            ),
            Container(width: 1, height: 40, color: Colors.white24),
            const SizedBox(width: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('$totalCount kasus',
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: Colors.white)),
                const SizedBox(height: 2),
                Text('$tunaiCount tunai, ${totalCount - tunaiCount} non tunai',
                    style: TextStyle(
                        fontSize: 11,
                        color: Colors.white.withValues(alpha: 0.7))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ReturCard extends StatelessWidget {
  final ReturnTransaction ret;
  const _ReturCard({required this.ret});

  @override
  Widget build(BuildContext context) {
    final dt = DateTime.tryParse(ret.createdAt);
    final dateLabel = dt != null
        ? DateFormat('dd MMM yyyy HH:mm', 'id').format(dt)
        : ret.createdAt;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE8E8E8)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(
                  color: AppColors.brandLight,
                  borderRadius: BorderRadius.zero,
                ),
                child: const Icon(Icons.assignment_return_outlined,
                    color: _kBrand, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Kasus #${ret.id}  TX #${ret.transactionId}',
                      style: const TextStyle(
                          fontWeight: FontWeight.w600, fontSize: 13),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      ret.customerName ?? 'Pelanggan Umum',
                      style:
                          const TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ],
                ),
              ),
              Text(
                'Rp${_fK(ret.totalRefund)}',
                style: const TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 14, color: _kBrand),
              ),
            ],
          ),
          const SizedBox(height: 10),
          const Divider(height: 1, color: Color(0xFFF0F0F0)),
          const SizedBox(height: 10),
          Row(
            children: [
              _InfoChip(Icons.info_outline, ret.reasonLabel),
              const SizedBox(width: 8),
              _InfoChip(
                ret.isCashRefund ? Icons.money : Icons.credit_card,
                ret.refundMethodLabel,
              ),
              const Spacer(),
              Text(dateLabel,
                  style: const TextStyle(fontSize: 11, color: Colors.black38)),
            ],
          ),
          if (ret.note != null && ret.note!.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('Catatan: ${ret.note}',
                style: const TextStyle(fontSize: 12, color: Colors.black45)),
          ],
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 38,
            child: OutlinedButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => StrukScreen(transactionId: ret.transactionId),
                ),
              ),
              icon: const Icon(Icons.receipt_long_outlined, size: 17),
              label: const Text('Lihat Transaksi Sumber'),
              style: OutlinedButton.styleFrom(
                foregroundColor: _kBrand,
                side: BorderSide(color: _kBrand.withValues(alpha: 0.35)),
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
                textStyle: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _InfoChip(this.icon, this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: const BoxDecoration(
        color: Color(0xFFF6F7F9),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: Colors.black45),
          const SizedBox(width: 4),
          Text(label,
              style: const TextStyle(fontSize: 11, color: Colors.black54)),
        ],
      ),
    );
  }
}

class _EmptyReturView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: const BoxDecoration(
              color: AppColors.brandLight,
              shape: BoxShape.rectangle,
            ),
            child: const Icon(Icons.assignment_return_outlined,
                size: 48, color: _kBrand),
          ),
          const SizedBox(height: 18),
          const Text('Belum ada komplain atau refund',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87)),
          const SizedBox(height: 6),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 24),
            child: Text(
              'Komplain, refund, atau pembatalan layanan dibuat dari detail struk transaksi agar item, nominal, dan kas tercatat benar.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Colors.black45),
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: 220,
            height: 42,
            child: ElevatedButton.icon(
              onPressed: () => Navigator.pushNamed(context, '/riwayat'),
              icon: const Icon(Icons.receipt_long_outlined, size: 18),
              label: const Text('Buka Riwayat'),
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
                textStyle: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

