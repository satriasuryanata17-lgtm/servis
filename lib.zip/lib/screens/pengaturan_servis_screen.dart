import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import '../database/db_helper.dart';
import '../core/theme.dart';
import '../widgets/responsive_layout.dart';

const Color _kBrand = AppColors.primaryBrand;

//  PENGATURAN TOKO SCREEN | Responsive v2

class PengaturanservisScreen extends StatefulWidget {
  const PengaturanservisScreen({super.key});

  @override
  State<PengaturanservisScreen> createState() =>
      _PengaturanservisScreenState();
}

class _PengaturanservisScreenState extends State<PengaturanservisScreen> {
  final _formKey = GlobalKey<FormState>();
  final _namaCtrl = TextEditingController();
  final _alamatCtrl = TextEditingController();
  final _teleponCtrl = TextEditingController();
  final _catatanCtrl = TextEditingController();
  File? _logoFile;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  @override
  void dispose() {
    _namaCtrl.dispose();
    _alamatCtrl.dispose();
    _teleponCtrl.dispose();
    _catatanCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfile() async {
    final profile = await DBHelper.instance.getWarungProfile();
    if (!mounted) return;
    _namaCtrl.text = profile['nama'] ?? '';
    _alamatCtrl.text = profile['alamat'] ?? '';
    _teleponCtrl.text = profile['telepon'] ?? '';
    _catatanCtrl.text = profile['catatan'] ?? '';
    final logoPath = profile['logo_path'] ?? '';
    if (logoPath.isNotEmpty && File(logoPath).existsSync()) {
      _logoFile = File(logoPath);
    } else {
      _logoFile = null;
    }
    setState(() => _loading = false);
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(source: source, imageQuality: 80);
      if (picked != null) setState(() => _logoFile = File(picked.path));
    } catch (_) {}
  }

  Future<void> _simpan() async {
    if (!_formKey.currentState!.validate()) return;
    await DBHelper.instance.saveWarungProfile(
      nama: _namaCtrl.text.trim(),
      alamat: _alamatCtrl.text.trim(),
      telepon: _teleponCtrl.text.trim(),
      catatan: _catatanCtrl.text.trim(),
      logoPath: _logoFile?.path ?? '',
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Profil toko berhasil disimpan'),
        backgroundColor: AppColors.success,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ),
    );
  }

  void _lihatStruk() {
    final tel = _teleponCtrl.text.trim();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StrukPreviewScreen(
          namaWarung: _namaCtrl.text.isEmpty ? 'Nama Toko' : _namaCtrl.text,
          alamat: _alamatCtrl.text.isEmpty ? 'Alamat Toko' : _alamatCtrl.text,
          telepon: tel.isEmpty ? '' : (tel.startsWith('0') ? tel : '0$tel'),
          catatan: _catatanCtrl.text,
          logoFile: _logoFile,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
          backgroundColor: Colors.white,
          body: Center(child: CircularProgressIndicator(color: _kBrand)));
    }

    final isTablet = KasirLayout.isTablet(context);
    final isLandscape = KasirLayout.isLandscape(context);

    return KasirResponsiveScaffold(
      title: 'Pengaturan Toko',
      showNavRail: false,
      backgroundColor: Colors.white,
      body: Form(
        key: _formKey,
        child: (isTablet && isLandscape)
            ? _buildWideLayout()
            : _buildScrollLayout(),
      ),
    );
  }

  Widget _buildWideLayout() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Left: Logo + quick info
        SizedBox(
          width: 240,
          child: Container(
            color: const Color(0xFFF8FAFC),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text('Logo Servis',
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF64748B))),
                  const SizedBox(height: 12),
                  GestureDetector(
                    onTap: () => _showLogoOptions(),
                    child: Container(
                      width: 140,
                      height: 140,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF0F5F8),
                        borderRadius: BorderRadius.zero,
                        border: Border.all(
                            color: const Color(0xFFDDDDDD), width: 1.5),
                      ),
                      child: _logoFile != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.zero,
                              child: Image.file(_logoFile!, fit: BoxFit.cover))
                          : const Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                  Icon(Icons.add_photo_alternate_outlined,
                                      color: Colors.black38, size: 36),
                                  SizedBox(height: 8),
                                  Text('Tap untuk\nupload logo',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          fontSize: 12, color: Colors.black45)),
                                ]),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('Pastikan background\nlogo berwarna putih.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 11, color: AppColors.danger, height: 1.4)),
                  const SizedBox(height: 12),
                  Row(children: [
                    if (!Platform.isWindows) ...[
                      Expanded(
                          child: _OutlineBtn(
                              label: 'Kamera',
                              width: double.infinity,
                              onTap: () => _pickImage(ImageSource.camera))),
                      const SizedBox(width: 8),
                    ],
                    Expanded(
                        child: _OutlineBtn(
                            label:
                                Platform.isWindows ? 'Unggah Logo' : 'Galeri',
                            width: double.infinity,
                            onTap: () => _pickImage(ImageSource.gallery))),
                  ]),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _lihatStruk,
                      icon: const Icon(Icons.receipt_outlined, size: 18),
                      label: const Text('Preview Struk'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: _kBrand,
                        side: const BorderSide(color: _kBrand),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Container(width: 1, color: const Color(0xFFE2E8F0)),
        // Right: form fields
        Expanded(
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
                  child: _buildFormFields(showLogo: false),
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 16),
                decoration: const BoxDecoration(
                    border: Border(top: BorderSide(color: Color(0xFFEEEEEE)))),
                child: SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                    onPressed: _simpan,
                    style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero)),
                    child: const Text('Simpan Perubahan',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildScrollLayout() {
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
            children: [_buildFormFields(showLogo: true)],
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _simpan,
                style: ElevatedButton.styleFrom(
                    backgroundColor: _kBrand,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero)),
                child: const Text('Simpan',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _showLogoOptions() {
    if (Platform.isWindows) {
      _pickImage(ImageSource.gallery);
      return;
    }
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                  color: Colors.grey[300], borderRadius: BorderRadius.zero)),
          const SizedBox(height: 20),
          ListTile(
              leading: const Icon(Icons.camera_alt_outlined, color: _kBrand),
              title: const Text('Kamera'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              }),
          ListTile(
              leading: const Icon(Icons.photo_library_outlined, color: _kBrand),
              title: const Text('Galeri'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              }),
        ]),
      ),
    );
  }

  Widget _buildFormFields({required bool showLogo}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (showLogo) ...[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const _Label('Nama Toko', required: true),
                      const SizedBox(height: 6),
                      _InputField(
                          controller: _namaCtrl,
                          hint: 'Masukkan Nama Toko',
                          validator: (v) => (v == null || v.trim().isEmpty)
                              ? 'Nama toko wajib diisi'
                              : null),
                      const SizedBox(height: 16),
                      const _Label('Alamat Toko', required: true),
                      const SizedBox(height: 6),
                      _InputField(
                          controller: _alamatCtrl,
                          hint: 'Contoh: Jl. Jayagiri No. 10, Lembang.',
                          maxLines: 4,
                          validator: (v) => (v == null || v.trim().isEmpty)
                              ? 'Alamat wajib diisi'
                              : null),
                    ]),
              ),
              const SizedBox(width: 12),
              Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Container(
                  width: 110,
                  height: 100,
                  decoration: BoxDecoration(
                      color: const Color(0xFFF0F5F8),
                      borderRadius: BorderRadius.zero,
                      border: Border.all(color: const Color(0xFFDDDDDD))),
                  child: _logoFile != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.zero,
                          child: Image.file(_logoFile!, fit: BoxFit.cover))
                      : const Center(
                          child: Text('Logo Toko',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 12, color: Colors.black45))),
                ),
                const SizedBox(height: 6),
                const Text('Pastikan background\nlogo berwarna putih.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 11, color: AppColors.danger, height: 1.4)),
                const SizedBox(height: 8),
                if (!Platform.isWindows) ...[
                  _OutlineBtn(
                      label: 'Kamera',
                      width: 110,
                      onTap: () => _pickImage(ImageSource.camera)),
                  const SizedBox(height: 6),
                ],
                _OutlineBtn(
                    label: Platform.isWindows ? 'Unggah Logo' : 'Galeri',
                    width: 110,
                    onTap: () => _pickImage(ImageSource.gallery)),
              ]),
            ],
          ),
        ] else ...[
          const _Label('Nama Toko', required: true),
          const SizedBox(height: 6),
          _InputField(
              controller: _namaCtrl,
              hint: 'Masukkan Nama Toko',
              validator: (v) => (v == null || v.trim().isEmpty)
                  ? 'Nama toko wajib diisi'
                  : null),
          const SizedBox(height: 16),
          const _Label('Alamat Toko', required: true),
          const SizedBox(height: 6),
          _InputField(
              controller: _alamatCtrl,
              hint: 'Contoh: Jl. Jayagiri No. 10, Lembang.',
              maxLines: 3,
              validator: (v) => (v == null || v.trim().isEmpty)
                  ? 'Alamat wajib diisi'
                  : null),
        ],
        const SizedBox(height: 16),
        const _Label('Nomor Telepon', required: true),
        const SizedBox(height: 6),
        _PhoneField(controller: _teleponCtrl),
        const SizedBox(height: 16),
        const _Label('Catatan Struk', required: false),
        const SizedBox(height: 6),
        _InputField(
            controller: _catatanCtrl,
            hint:
                'Contoh: Terima kasih telah mempercayakan servis Anda pada kami',
            maxLines: 4),
        const SizedBox(height: 16),
        Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          const Expanded(
              child: Text(
                  'Semua informasi toko yang sudah kamu isi dan disimpan akan otomatis tercantum pada struk',
                  style: TextStyle(
                      fontSize: 12, color: Colors.black54, height: 1.4))),
          const SizedBox(width: 12),
          _OutlineBtn(label: 'Lihat Struk', width: 100, onTap: _lihatStruk),
        ]),
      ],
    );
  }
}

//  STRUK PREVIEW SCREEN

class StrukPreviewScreen extends StatelessWidget {
  final String namaWarung, alamat, telepon, catatan;
  final File? logoFile;

  const StrukPreviewScreen(
      {super.key,
      required this.namaWarung,
      required this.alamat,
      required this.telepon,
      this.catatan = '',
      this.logoFile});

  String _fmtNow() {
    final now = DateTime.now();
    return '${now.day.toString().padLeft(2, '0')}-${now.month.toString().padLeft(2, '0')}-${now.year} ${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
  }

  String _composeReceiptText() {
    final b = StringBuffer()
      ..writeln(namaWarung)
      ..writeln(alamat)
      ..writeln(telepon.isEmpty ? '-' : telepon)
      ..writeln('═════════════════════════════')
      ..writeln('No: INV-XXXXXX-XXXXX')
      ..writeln('Tanggal: ${_fmtNow()}')
      ..writeln('Petugas: Satria')
      ..writeln('Pembayaran: Tunai')
      ..writeln('═════════════════════════════')
      ..writeln('Layanan 1  Rp15.000 x 1  Rp15.000')
      ..writeln('Layanan 2  Rp5.000 x 4   Rp20.000')
      ..writeln('Layanan 3  Rp5.000 x 1   Rp5.000')
      ..writeln('═════════════════════════════')
      ..writeln('Total: Rp40.000')
      ..writeln('Bayar: Rp50.000')
      ..writeln('Kembali: Rp10.000');
    if (catatan.trim().isNotEmpty) {
      b
        ..writeln('═════════════════════════════')
        ..writeln(catatan.trim());
    }
    return b.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _kBrand, size: 20),
            onPressed: () => Navigator.pop(context)),
        title: const Text('Struk',
            style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w600,
                color: Colors.black87)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: OutlinedButton.icon(
              onPressed: () async {
                await SharePlus.instance.share(ShareParams(
                    text: _composeReceiptText(),
                    subject: 'Preview Struk $namaWarung'));
              },
              style: OutlinedButton.styleFrom(
                  foregroundColor: _kBrand,
                  side: const BorderSide(color: _kBrand),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6)),
              icon: const Icon(Icons.share_outlined, size: 16),
              label: const Text('Bagikan',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(
              color: Color(0xFFF7F7F7), borderRadius: BorderRadius.zero),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(
                child: Column(children: [
              if (logoFile != null)
                ClipRRect(
                    borderRadius: BorderRadius.zero,
                    child: Image.file(logoFile!,
                        width: 60, height: 60, fit: BoxFit.cover))
              else
                const SizedBox.shrink(),
              const SizedBox(height: 6),
              Text(namaWarung,
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.bold)),
              const SizedBox(height: 2),
              Text(alamat,
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                  textAlign: TextAlign.center),
              if (telepon.isNotEmpty) ...[
                const SizedBox(height: 2),
                Text(telepon,
                    style: const TextStyle(fontSize: 12, color: Colors.black54))
              ],
            ])),
            const Divider(height: 20),
            _row('No', 'INV-XXXXXX-XXXXX'),
            _row('Tanggal', _fmtNow()),
            _row('Petugas', 'Satria'),
            _row('Pembayaran', 'Tunai'),
            const Divider(height: 20),
            _itemRow('Layanan 1', 'Rp15.000 x 1', 'Rp15.000'),
            _itemRow('Layanan 2', 'Rp5.000 x 4', 'Rp20.000'),
            _itemRow('Layanan 3', 'Rp5.000 x 1', 'Rp5.000'),
            const Divider(height: 20),
            _row('Total Pesanan', 'Rp0'),
            _rowBold('Total', 'Rp40.000'),
            _row('Bayar', 'Rp50.000'),
            _row('Kembali', 'Rp10.000'),
            if (catatan.isNotEmpty) ...[
              const Divider(height: 20),
              Center(
                  child: Text(catatan,
                      style:
                          const TextStyle(fontSize: 13, color: Colors.black54),
                      textAlign: TextAlign.center)),
              const SizedBox(height: 12)
            ],
          ]),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: () async {
                await SharePlus.instance.share(ShareParams(
                    text:
                        '${_composeReceiptText()}\n\nKirim teks ini ke aplikasi printer thermal 58mm untuk dicetak.',
                    subject: 'Cetak Struk 58mm'));
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: _kBrand,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero)),
              child: const Text('Cetak Struk (58mm)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            ),
          ),
        ),
      ),
    );
  }

  Widget _row(String l, String v) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        Expanded(
            child: Text(l,
                style: const TextStyle(fontSize: 13, color: Colors.black54))),
        Text(v,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold))
      ]));
  Widget _rowBold(String l, String v) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        Expanded(
            child: Text(l,
                style: const TextStyle(
                    fontSize: 14, fontWeight: FontWeight.bold))),
        Text(v,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold))
      ]));
  Widget _itemRow(String name, String detail, String price) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name, style: const TextStyle(fontSize: 13)),
          Text(detail,
              style: const TextStyle(fontSize: 12, color: Colors.black54))
        ])),
        Text(price,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold))
      ]));
}

class _Label extends StatelessWidget {
  final String text;
  final bool required;
  const _Label(this.text, {this.required = false});
  @override
  Widget build(BuildContext context) => RichText(
        text: TextSpan(
            text: text,
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Colors.black87),
            children: required
                ? const [
                    TextSpan(
                        text: ' *', style: TextStyle(color: AppColors.danger))
                  ]
                : []),
      );
}

class _InputField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final int maxLines;
  final String? Function(String?)? validator;
  const _InputField(
      {required this.controller,
      required this.hint,
      this.maxLines = 1,
      this.validator});
  @override
  Widget build(BuildContext context) => TextFormField(
        controller: controller,
        maxLines: maxLines,
        style: const TextStyle(fontSize: 14, color: Colors.black87),
        validator: validator,
        decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(fontSize: 13, color: Colors.black38),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            enabledBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFDDDDDD))),
            focusedBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: _kBrand)),
            errorBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: _kBrand)),
            focusedErrorBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: _kBrand))),
      );
}

class _PhoneField extends StatelessWidget {
  final TextEditingController controller;
  const _PhoneField({required this.controller});
  @override
  Widget build(BuildContext context) => TextFormField(
        controller: controller,
        keyboardType: TextInputType.phone,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        style: const TextStyle(fontSize: 14, color: Colors.black87),
        validator: (v) => (v == null || v.trim().isEmpty)
            ? 'Nomor telepon wajib diisi'
            : null,
        decoration: InputDecoration(
            hintText: 'Contoh: 8989482384',
            hintStyle: const TextStyle(fontSize: 13, color: Colors.black38),
            prefixIcon: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                margin: const EdgeInsets.only(right: 8),
                decoration: const BoxDecoration(
                    border:
                        Border(right: BorderSide(color: Color(0xFFDDDDDD)))),
                child: const Text('+62',
                    style: TextStyle(
                        fontSize: 14,
                        color: Colors.black87,
                        fontWeight: FontWeight.w500))),
            prefixIconConstraints:
                const BoxConstraints(minWidth: 0, minHeight: 0),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            enabledBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFDDDDDD))),
            focusedBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: _kBrand)),
            errorBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: _kBrand)),
            focusedErrorBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: _kBrand))),
      );
}

class _OutlineBtn extends StatelessWidget {
  final String label;
  final double width;
  final VoidCallback onTap;
  const _OutlineBtn(
      {required this.label, required this.width, required this.onTap});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: width,
        height: 36,
        child: OutlinedButton(
            onPressed: onTap,
            style: OutlinedButton.styleFrom(
                side: const BorderSide(color: _kBrand),
                foregroundColor: _kBrand,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                padding: EdgeInsets.zero),
            child: Text(label,
                style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w600))),
      );
}

