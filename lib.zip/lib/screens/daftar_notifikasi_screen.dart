import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../providers/providers.dart';
import '../widgets/kasir_drawer.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';
import 'main_shell.dart';

class DaftarNotifikasiScreen extends ConsumerStatefulWidget {
  const DaftarNotifikasiScreen({super.key});

  @override
  ConsumerState<DaftarNotifikasiScreen> createState() =>
      _DaftarNotifikasiScreenState();
}

class _DaftarNotifikasiScreenState
    extends ConsumerState<DaftarNotifikasiScreen> {
  // Active category index for wide layout sidebar
  // 0=Semua, 1=Stok, 2=Keuangan, 3=Sistem
  int _sidebarTab = 0;

  static const _tabs = ['Semua', 'Stok', 'Tagihan', 'Sistem'];

  @override
  Widget build(BuildContext context) {
    final tablet = isTabletDevice(context);
    final landscape = isLandscape(context);
    final notificationsAsync = ref.watch(allNotificationsProvider);

    return KasirResponsiveScaffold(
      title: 'Notifikasi',
      showNavRail: false,
      navIndex: 8,
      drawer: const KasirDrawer(),
// bottomNavigationBar removed | MainShell handles it
      actions: [
        IconButton(
          icon: const Icon(Icons.done_all_rounded),
          tooltip: 'Tandai Semua Sebagai Sudah Dibaca',
          onPressed: () => _markAllAsRead(),
        ),
        IconButton(
          icon: const Icon(Icons.settings_outlined),
          tooltip: 'Pengaturan Notifikasi',
          onPressed: () =>
              Navigator.pushNamed(context, '/pengaturan_notifikasi'),
        ),
      ],
      backgroundColor: const Color(0xFFF8F9FA),
      body: (tablet || landscape)
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Left: category sidebar
                _buildSidebar(notificationsAsync),
                Container(width: 1, color: const Color(0xFFEEEEEE)),

                // Right: notification grid
                Expanded(
                  child: notificationsAsync.when(
                    skipLoadingOnRefresh: true,
                    skipLoadingOnReload: true,
                    data: (items) => _buildWideList(items),
                    loading: () => const Center(
                        child: CircularProgressIndicator(
                            color: AppColors.primaryBrand)),
                    error: (err, _) => const Center(
                        child: Text(
                            'Gagal memuat notifikasi. Silakan coba lagi.')),
                  ),
                ),
              ],
            )
          : notificationsAsync.when(
              skipLoadingOnRefresh: true,
              skipLoadingOnReload: true,
              data: (items) => DefaultTabController(
                length: 4,
                child: Column(
                  children: [
                    const TabBar(
                      isScrollable: true,
                      indicatorColor: AppColors.primaryBrand,
                      labelColor: AppColors.primaryBrand,
                      unselectedLabelColor: Colors.black54,
                      labelStyle:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                      tabs: [
                        Tab(text: 'Semua'),
                        Tab(text: 'Stok'),
                        Tab(text: 'Tagihan'),
                        Tab(text: 'Sistem'),
                      ],
                    ),
                    Expanded(
                      child: TabBarView(
                        children: [
                          _NotificationList(items: items),
                          _NotificationList(
                              items: items
                                  .where((i) =>
                                      i.category == NotificationCategory.stok)
                                  .toList()),
                          _NotificationList(
                              items: items
                                  .where((i) =>
                                      i.category ==
                                      NotificationCategory.keuangan)
                                  .toList()),
                          _NotificationList(
                              items: items
                                  .where((i) =>
                                      i.category == NotificationCategory.sistem)
                                  .toList()),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              loading: () => const Center(
                  child:
                      CircularProgressIndicator(color: AppColors.primaryBrand)),
              error: (err, _) => const Center(
                  child: Text('Gagal memuat notifikasi. Silakan coba lagi.')),
            ),
    );
  }

  Widget _buildSidebar(AsyncValue<List<NotificationItem>> notificationsAsync) {
    final allItems = notificationsAsync.asData?.value ?? [];

    final counts = [
      allItems.length,
      allItems.where((i) => i.category == NotificationCategory.stok).length,
      allItems.where((i) => i.category == NotificationCategory.keuangan).length,
      allItems.where((i) => i.category == NotificationCategory.sistem).length,
    ];

    final icons = [
      Icons.notifications_rounded,
      Icons.inventory_2_rounded,
      Icons.account_balance_wallet_rounded,
      Icons.settings_rounded,
    ];

    final colors = [
      AppColors.primaryBrand,
      const Color(0xFFE53935),
      const Color(0xFF2E7D32),
      const Color(0xFF1565C0),
    ];

    return Container(
      width: 220,
      color: Colors.white,
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Text(
                'FILTER KATEGORI',
                style: GoogleFonts.inter(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: Colors.black38,
                    letterSpacing: 1.0),
              ),
            ),

            // Category filter buttons
            ...List.generate(4, (i) {
              final isSelected = _sidebarTab == i;
              return GestureDetector(
                onTap: () => setState(() => _sidebarTab = i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  margin:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? colors[i].withValues(alpha: 0.10)
                        : Colors.transparent,
                    borderRadius: BorderRadius.zero,
                    border: isSelected
                        ? Border.all(color: colors[i].withValues(alpha: 0.25))
                        : null,
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? colors[i].withValues(alpha: 0.15)
                              : const Color(0xFFF1F5F9),
                          borderRadius: BorderRadius.zero,
                        ),
                        child: Icon(icons[i],
                            size: 16,
                            color: isSelected ? colors[i] : Colors.black38),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          _tabs[i],
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight:
                                isSelected ? FontWeight.w700 : FontWeight.w500,
                            color: isSelected ? colors[i] : Colors.black54,
                          ),
                        ),
                      ),
                      if (counts[i] > 0)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? colors[i]
                                : const Color(0xFFEEEEEE),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: Text(
                            '${counts[i]}',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: isSelected ? Colors.white : Colors.black45,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            }),

            const SizedBox(height: 20),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Divider(height: 1, color: Color(0xFFEEEEEE)),
            ),
            const SizedBox(height: 16),

            // Summary stats
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.zero,
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Ringkasan',
                        style: GoogleFonts.inter(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            color: Colors.black38,
                            letterSpacing: 0.5)),
                    const SizedBox(height: 10),
                    _SidebarStat(
                        label: 'Total',
                        value: '${counts[0]}',
                        color: AppColors.primaryBrand),
                    const SizedBox(height: 6),
                    _SidebarStat(
                        label: 'Stok',
                        value: '${counts[1]}',
                        color: const Color(0xFFE53935)),
                    const SizedBox(height: 6),
                    _SidebarStat(
                        label: 'Tagihan',
                        value: '${counts[2]}',
                        color: const Color(0xFF2E7D32)),
                    const SizedBox(height: 6),
                    _SidebarStat(
                        label: 'Sistem',
                        value: '${counts[3]}',
                        color: const Color(0xFF1565C0)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Future<void> _markAllAsRead() async {
    try {
      await ref.read(readNotificationsProvider.notifier).markAllAsRead();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Semua notifikasi ditandai sudah dibaca'),
            duration: Duration(seconds: 2),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Terjadi kesalahan. Silakan coba lagi.'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  Widget _buildWideList(List<NotificationItem> allItems) {
    final filtered = switch (_sidebarTab) {
      1 =>
        allItems.where((i) => i.category == NotificationCategory.stok).toList(),
      2 => allItems
          .where((i) => i.category == NotificationCategory.keuangan)
          .toList(),
      3 => allItems
          .where((i) => i.category == NotificationCategory.sistem)
          .toList(),
      _ => allItems,
    };

    if (filtered.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                color: Color(0xFFF1F5F9),
                shape: BoxShape.rectangle,
              ),
              child: const Icon(Icons.notifications_off_outlined,
                  size: 36, color: Colors.black26),
            ),
            const SizedBox(height: 16),
            const Text('Tidak ada notifikasi',
                style: TextStyle(
                    fontSize: 15,
                    color: Colors.black45,
                    fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              'Kategori "${_tabs[_sidebarTab]}" kosong',
              style: const TextStyle(fontSize: 12, color: Colors.black38),
            ),
          ],
        ),
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        mainAxisExtent: 170,
      ),
      itemCount: filtered.length,
      itemBuilder: (context, i) =>
          _NotificationCard(item: filtered[i], isCompact: true),
    );
  }
}

// NOTIFICATION LIST (portrait | scroll view)

class _NotificationList extends StatelessWidget {
  final List<NotificationItem> items;
  const _NotificationList({required this.items});

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.notifications_off_outlined,
                size: 40, color: Colors.black26),
            SizedBox(height: 12),
            Text(
              'Tidak ada notifikasi',
              style: TextStyle(
                  fontSize: 14,
                  color: Colors.black45,
                  fontWeight: FontWeight.w500),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      itemCount: items.length,
      itemBuilder: (context, i) => _NotificationCard(item: items[i]),
    );
  }
}

// NOTIFICATION CARD
// isCompact = true  2-col grid tile (tablet/landscape)
// isCompact = false full-width list item (portrait)

class _NotificationCard extends ConsumerWidget {
  final NotificationItem item;
  final bool isCompact;
  const _NotificationCard({required this.item, this.isCompact = false});

  Color _accent() {
    // Harmonious Teal palette for all categories
    return AppColors.primaryBrand;
  }

  String _categoryLabel() {
    switch (item.category) {
      case NotificationCategory.stok:
        return 'STOK';
      case NotificationCategory.keuangan:
        return 'TAGIHAN';
      case NotificationCategory.sistem:
        return 'SISTEM';
    }
  }

  IconData _icon() {
    final hi = item.urgency == 'high';
    if (item.category == NotificationCategory.stok) {
      return hi ? Icons.warning_amber_rounded : Icons.inventory_2_outlined;
    }
    if (item.category == NotificationCategory.keuangan) {
      return Icons.account_balance_wallet_outlined;
    }
    return Icons.info_outline_rounded;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ac = _accent();
    final ic = _icon();
    final readIds = ref.watch(readNotificationsProvider);
    final isRead = readIds.asData?.value.contains(item.id) ?? false;

    // Styling for unread vs read notifications
    final bgColor = isRead ? Colors.grey.withValues(alpha: 0.03) : Colors.white;
    final borderColor =
        isRead ? const Color(0xFFE0E0E0) : const Color(0xFFF1F5F9);
    final opacity = isRead ? 0.6 : 1.0;

    return Container(
      margin: isCompact ? EdgeInsets.zero : const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isRead ? 0.02 : 0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Opacity(
        opacity: opacity,
        child: Padding(
          padding:
              isCompact ? const EdgeInsets.all(10) : const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Modern Icon Badge
              Container(
                padding: EdgeInsets.all(isCompact ? 6 : 10),
                decoration: BoxDecoration(
                  color: ac.withValues(alpha: isRead ? 0.04 : 0.08),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(ic, color: ac, size: isCompact ? 16 : 20),
              ),
              SizedBox(width: isCompact ? 10 : 16),

              // Content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Category Tag
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: ac.withValues(alpha: isRead ? 0.04 : 0.08),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (isRead)
                                Padding(
                                  padding: const EdgeInsets.only(right: 4),
                                  child: Icon(
                                    Icons.check_circle,
                                    size: 12,
                                    color: Colors.green[600],
                                  ),
                                ),
                              Text(
                                _categoryLabel(),
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: isCompact ? 7 : 9,
                                  fontWeight: FontWeight.w800,
                                  color: ac,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          _formatDate(item.date),
                          style: GoogleFonts.inter(
                              fontSize: isCompact ? 8 : 10,
                              color: const Color(0xFF94A3B8),
                              fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      item.title,
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: isCompact ? 12 : 14,
                          fontWeight:
                              isRead ? FontWeight.w500 : FontWeight.w700,
                          color: isRead
                              ? const Color(0xFF94A3B8)
                              : const Color(0xFF0F172A),
                          decoration:
                              isRead ? TextDecoration.lineThrough : null),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item.subtitle,
                      style: GoogleFonts.inter(
                          fontSize: isCompact ? 10 : 12,
                          color: const Color(0xFF64748B),
                          height: 1.5),
                      maxLines: isCompact ? 1 : 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: isCompact ? 10 : 14),
                    _ActionBtn(item: item, color: ac, isCompact: isCompact),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDate(String dateStr) {
    try {
      final d = DateTime.tryParse(dateStr);
      if (d == null) return dateStr;
      final diff = DateTime.now().difference(d);
      if (diff.inMinutes < 60) return '${diff.inMinutes}m lalu';
      if (diff.inHours < 24) return '${diff.inHours}j lalu';
      return '${d.day}/${d.month}';
    } catch (_) {
      return dateStr;
    }
  }
}

// ACTION BUTTON inside notification card

class _ActionBtn extends ConsumerWidget {
  final NotificationItem item;
  final Color color;
  final bool isCompact;
  const _ActionBtn(
      {required this.item, required this.color, this.isCompact = false});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    String label = 'Detail';
    VoidCallback? onTap;
    final type = (item.metadata ?? {})['type'];

    if (type == 'low_stock' || type == 'expiry') {
      label = 'Manajemen Stok';
      onTap = () {
        Navigator.pushNamed(context, '/laporan/gudang');
      };
    } else if (type == 'piutang') {
      label = 'Cek Tagihan';
      onTap = () {
        final shell = ShellScope.of(context);
        if (shell != null) {
          ref
              .read(riwayatTabProvider.notifier)
              .set(1); // Set to "Belum Lunas" tab
          shell.onNavigate(4); // Riwayat tab
        } else {
          Navigator.pushNamed(context, '/riwayat');
        }
      };
    } else if (type == 'session') {
      label = 'Tutup Shift';
      onTap = () => Navigator.pushNamed(context, '/riwayat_tutup_kasir');
    }

    if (isCompact) {
      // Vertical layout for compact (grid) mode
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Action Button
          MouseRegion(
            cursor: SystemMouseCursors.click,
            child: GestureDetector(
              onTap: onTap,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: color.withValues(alpha: 0.12)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      label,
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          color: color),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(width: 3),
                    Icon(Icons.arrow_forward_rounded, size: 10, color: color),
                  ],
                ),
              ),
            ),
          ),
          SizedBox(height: isCompact ? 4 : 6),
          // Mark as Read Button
          MouseRegion(
            cursor: SystemMouseCursors.click,
            child: GestureDetector(
              onTap: () async {
                try {
                  await ref
                      .read(readNotificationsProvider.notifier)
                      .markAsRead(item.id);
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Notifikasi ditandai sudah dibaca'),
                        duration: Duration(seconds: 2),
                        backgroundColor: Colors.black87,
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  }
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Terjadi kesalahan. Silakan coba lagi.'),
                        backgroundColor: Colors.red,
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  }
                }
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.grey.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(6),
                  border:
                      Border.all(color: Colors.grey.withValues(alpha: 0.12)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Sudah Dibaca',
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          color: Colors.grey[600]),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(width: 3),
                    Icon(Icons.check_circle_outline,
                        size: 10, color: Colors.grey[600]),
                  ],
                ),
              ),
            ),
          ),
        ],
      );
    }

    // Horizontal layout for normal (list) mode
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Action Button
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: GestureDetector(
            onTap: onTap,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: color.withValues(alpha: 0.12)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    label,
                    style: GoogleFonts.plusJakartaSans(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: color),
                  ),
                  const SizedBox(width: 6),
                  Icon(Icons.arrow_forward_rounded, size: 14, color: color),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        // Mark as Read Button
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: GestureDetector(
            onTap: () async {
              try {
                await ref
                    .read(readNotificationsProvider.notifier)
                    .markAsRead(item.id);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Notifikasi ditandai sudah dibaca'),
                      duration: Duration(seconds: 2),
                      backgroundColor: Colors.black87,
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Terjadi kesalahan. Silakan coba lagi.'),
                      backgroundColor: Colors.red,
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              }
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.grey.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey.withValues(alpha: 0.12)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Sudah Dibaca',
                    style: GoogleFonts.plusJakartaSans(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: Colors.grey[600]),
                  ),
                  const SizedBox(width: 6),
                  Icon(Icons.check_circle_outline,
                      size: 14, color: Colors.grey[600]),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// SIDEBAR STAT ROW

class _SidebarStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _SidebarStat(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: const TextStyle(fontSize: 11, color: Colors.black45)),
        Text(value,
            style: TextStyle(
                fontSize: 12, fontWeight: FontWeight.bold, color: color)),
      ],
    );
  }
}

