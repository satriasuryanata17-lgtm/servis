import 'dart:io';
import 'package:flutter/material.dart';
import '../database/db_helper.dart';
import '../services/export_service.dart';
import '../core/theme.dart';
import '../widgets/export_dropdown.dart';
import 'responsive_layout.dart';

const Color _kBrand = AppColors.primaryBrand;

//
//  RIWAYAT STOK LAPORAN  --  Responsive (Phone + Tablet/Landscape)
//
class RiwayatStokLaporanScreen extends StatefulWidget {
  const RiwayatStokLaporanScreen({super.key});

  @override
  State<RiwayatStokLaporanScreen> createState() =>
      _RiwayatStokLaporanScreenState();
}

class _RiwayatStokLaporanScreenState extends State<RiwayatStokLaporanScreen> {
  String _periode = 'Periode Bulanan';
  DateTime _selectedDate = DateTime.now();

  final List<String> _periodeOptions = [
    'Periode Harian',
    'Periode Bulanan',
    'Periode Tahunan',
    'Kustom Tanggal',
  ];

  Map<String, List<Map<String, dynamic>>> _groupedLogs = {};
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _loadLogs();
  }

  bool _isWide(BuildContext context) =>
      MediaQuery.of(context).size.width >= 720;

  String _datePrefix() {
    final d = _selectedDate;
    if (_periode == 'Periode Harian' || _periode == 'Kustom Tanggal') {
      return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
    } else if (_periode == 'Periode Bulanan') {
      return '${d.year}-${d.month.toString().padLeft(2, '0')}';
    } else {
      return '${d.year}';
    }
  }

  Future<void> _loadLogs() async {
    setState(() => _loading = true);
    final rows = await DBHelper.instance
        .getStockLogsWithProduct(datePrefix: _datePrefix());

    final Map<String, List<Map<String, dynamic>>> grouped = {};
    for (final row in rows) {
      final dateStr = (row['date'] as String?) ?? '';
      String label = dateStr;
      try {
        final dt = DateTime.parse(dateStr);
        label = _formatDateLabel(dt);
      } catch (_) {}
      grouped.putIfAbsent(label, () => []).add(row);
    }
    if (mounted) {
      setState(() {
        _groupedLogs = grouped;
        _loading = false;
      });
    }
  }

  String _formatDateLabel(DateTime dt) {
    const months = [
      'Januari',
      'Februari',
      'Maret',
      'April',
      'Mei',
      'Juni',
      'Juli',
      'Agustus',
      'September',
      'Oktober',
      'November',
      'Desember'
    ];
    return '${dt.day} ${months[dt.month - 1]} ${dt.year}';
  }

  String _formatSelectedDate() {
    const months = [
      'Januari',
      'Februari',
      'Maret',
      'April',
      'Mei',
      'Juni',
      'Juli',
      'Agustus',
      'September',
      'Oktober',
      'November',
      'Desember'
    ];
    final d = _selectedDate;
    return '${d.day} ${months[d.month - 1]} ${d.year}';
  }

  Future<void> _exportRiwayatStok() async {
    final choice = await ExportDropdown.show(context);
    if (choice == null) return;

    final logs = await DBHelper.instance.getAllStockLogsWithProduct(limit: 500);
    if (!mounted) return;
    if (logs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Belum ada riwayat stok untuk diekspor.'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
      return;
    }

    final headers = [
      'Produk',
      'Tipe Item',
      'Batch',
      'Tipe',
      'Qty',
      'Tanggal',
      'Lama',
      'Baru',
      'Karyawan',
    ];

    final rows = logs
        .map((l) => [
              l['product_name'] ?? l['product_id'] ?? '-',
              (l['is_material'] as int? ?? 0) == 1
                  ? 'Bahan Baku'
                  : 'Produk/Layanan',
              l['stock_name'] ?? '-',
              l['type'] == 'in' ? 'Masuk' : 'Keluar',
              l['qty'] ?? 0,
              l['date']?.toString().split(' ')[0] ?? '-',
              l['old_qty'] ?? '-',
              l['new_qty'] ?? '-',
              l['employee_name'] ?? '-',
            ])
        .toList();

    final allLogs = _groupedLogs.values.expand((e) => e).toList();
    final totalIn = allLogs.where((r) => r['type'] == 'in').length;
    final totalOut = allLogs.where((r) => r['type'] != 'in').length;

    final summaryData = {
      'Stok Masuk': '$totalIn',
      'Stok Keluar': '$totalOut',
      'Total Log': '${allLogs.length}',
      'Periode': _periode,
    };

    const title = 'Riwayat Stok';
    final subtitle = 'Filter: $_periode  ${_formatSelectedDate()}';

    try {
      if (choice == 'csv') {
        await ExportService.exportAndShareCsv(
          filePrefix: 'riwayat_stok_laporan',
          headers: headers,
          rows: rows,
          subject: 'Ekspor Riwayat Stok',
          message: subtitle,
        );
      } else if (choice == 'pdf') {
        await ExportService.exportPdfLaporan(
          title: title,
          subtitle: subtitle,
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      } else if (choice == 'print') {
        await ExportService.printPdfLaporan(
          title: title,
          subtitle: subtitle,
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Gagal mengekspor laporan stok. Silakan coba lagi.')),
      );
    }
  }

  void _showPeriodeSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.zero)),
      builder: (_) {
        String temp = _periode;
        return StatefulBuilder(builder: (ctx, setSt) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(0, 16, 0, 24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ..._periodeOptions.map((opt) => ListTile(
                    title: Text(opt,
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: temp == opt ? _kBrand : Colors.black87)),
                    tileColor: temp == opt ? const Color(0xFFF5F5F5) : null,
                    onTap: () => setSt(() => temp = opt),
                  )),
              const Divider(height: 1),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Row(children: [
                  Expanded(
                      child: OutlinedButton(
                          onPressed: () => Navigator.pop(context),
                          style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: _kBrand),
                              foregroundColor: _kBrand,
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14)),
                          child: const Text('Batal',
                              style: TextStyle(fontWeight: FontWeight.w600)))),
                  const SizedBox(width: 12),
                  Expanded(
                      child: ElevatedButton(
                          onPressed: () {
                            setState(() => _periode = temp);
                            Navigator.pop(context);
                            _loadLogs();
                          },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: _kBrand,
                              foregroundColor: Colors.white,
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14)),
                          child: const Text('Pilih',
                              style: TextStyle(fontWeight: FontWeight.w600)))),
                ]),
              ),
            ]),
          );
        });
      },
    );
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
      _loadLogs();
    }
  }

  @override
  Widget build(BuildContext context) {
    final wide = _isWide(context);

    return KasirResponsiveScaffold(
      title: 'Riwayat Stok',
      navIndex: 4,
      showNavRail: false,
      backgroundColor: wide ? const Color(0xFFF5F5F7) : Colors.white,
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: _ProExportBtn(onTap: _exportRiwayatStok),
        ),
      ],
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: const Color(0xFFFFF3E0),
            child: const Text(
              'Riwayat stok hanya tersedia untuk produk dengan manajemen stok aktif.',
              style: TextStyle(fontSize: 12.5, color: Colors.black87),
            ),
          ),
          Expanded(
            child: wide ? _buildTabletLayout() : _buildPhoneLayout(),
          ),
        ],
      ),
    );
  }

  Widget _buildPhoneLayout() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
          child: _buildFilterRow(),
        ),
        const SizedBox(height: 16),
        Expanded(child: _buildLogContent()),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 280,
          color: Colors.white,
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 10),
                  child: Text(
                    'FILTER PERIODE',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Colors.black38,
                        letterSpacing: 1.0),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: _buildFilterColumn(),
                ),
                const Divider(height: 1, color: Color(0xFFEEEEEE)),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                  child: _buildStatsPanel(),
                ),
              ],
            ),
          ),
        ),
        const VerticalDivider(width: 1, color: Color(0xFFEEEEEE)),
        Expanded(
          child: Container(
            color: const Color(0xFFF5F5F7),
            child: _buildLogContent(),
          ),
        ),
      ],
    );
  }

  Widget _buildFilterRow() {
    return Row(children: [
      Expanded(child: _filterChip(_periode, _showPeriodeSheet)),
      const SizedBox(width: 12),
      Expanded(child: _filterChip(_formatSelectedDate(), _pickDate)),
    ]);
  }

  Widget _buildFilterColumn() {
    return Column(
      children: [
        _filterChip(_periode, _showPeriodeSheet),
        const SizedBox(height: 10),
        _filterChip(_formatSelectedDate(), _pickDate),
      ],
    );
  }

  Widget _filterChip(String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: const BoxDecoration(
            color: Color(0xFFF5F5F5), borderRadius: BorderRadius.zero),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Flexible(
            child: Text(label,
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          ),
          const Icon(Icons.keyboard_arrow_down_rounded,
              color: _kBrand, size: 22),
        ]),
      ),
    );
  }

  Widget _buildStatsPanel() {
    final allLogs = _groupedLogs.values.expand((e) => e).toList();
    final totalIn = allLogs.where((r) => r['type'] == 'in').length;
    final totalOut = allLogs.where((r) => r['type'] != 'in').length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'RINGKASAN',
          style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: Colors.black38,
              letterSpacing: 1.0),
        ),
        const SizedBox(height: 12),
        _statTile(Icons.add_circle_outline, 'Stok Masuk', '$totalIn',
            const Color(0xFF059669)),
        const SizedBox(height: 8),
        _statTile(Icons.remove_circle_outline, 'Stok Keluar', '$totalOut',
            const Color(0xFFDC2626)),
        const SizedBox(height: 8),
        _statTile(
            Icons.list_alt_rounded, 'Total Log', '${allLogs.length}', _kBrand),
      ],
    );
  }

  Widget _statTile(IconData icon, String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.07),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: color.withValues(alpha: 0.18)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 10),
          Expanded(
              child: Text(label,
                  style: const TextStyle(fontSize: 12, color: Colors.black54))),
          Text(value,
              style: TextStyle(
                  fontSize: 18, fontWeight: FontWeight.w800, color: color)),
        ],
      ),
    );
  }

  Widget _buildLogContent() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator(color: _kBrand));
    }
    if (_groupedLogs.isEmpty) {
      return _emptyState();
    }
    return ListView(
      children: _groupedLogs.entries.map((entry) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
              child: Row(
                children: [
                  Container(
                    width: 4,
                    height: 16,
                    decoration: const BoxDecoration(
                        color: _kBrand, borderRadius: BorderRadius.zero),
                  ),
                  const SizedBox(width: 10),
                  Text(entry.key,
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87)),
                  const Spacer(),
                  Text('${entry.value.length} log',
                      style:
                          TextStyle(fontSize: 12, color: Colors.grey.shade500)),
                ],
              ),
            ),
            ...entry.value.map((row) => _LogItem(row: row)),
            const Divider(height: 1, color: Color(0xFFEEEEEE)),
          ],
        );
      }).toList(),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 180,
            height: 150,
            child: CustomPaint(painter: _HandingBoxPainter()),
          ),
          const SizedBox(height: 16),
          const Text('Riwayat Stok Tidak Ditemukan',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87)),
          const SizedBox(height: 6),
          Text('Belum ada riwayat stok di $_periode',
              style: const TextStyle(fontSize: 13, color: Colors.black54)),
        ],
      ),
    );
  }
}

//  Log Item -
class _LogItem extends StatelessWidget {
  final Map<String, dynamic> row;
  const _LogItem({required this.row});

  @override
  Widget build(BuildContext context) {
    final dateStr = (row['date'] as String?) ?? '';
    String timeStr = '';
    try {
      final dt = DateTime.parse(dateStr);
      timeStr =
          '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {}

    final employee = (row['employee_name'] as String?) ?? '';
    final stockName = (row['stock_name'] as String?) ?? '';
    final type = (row['type'] as String?) ?? 'in';
    final isIn = type == 'in';
    final qty = (row['qty'] as int?) ?? 0;
    final oldQty = row['old_qty'] as int?;
    final newQty = row['new_qty'] as int?;
    final productName = (row['product_name'] as String?) ?? '';
    final imagePath = (row['image_path'] as String?) ?? '';
    final isMaterial = (row['is_material'] as int? ?? 0) == 1;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          border: Border.all(color: const Color(0xFFEEEEEE)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.02),
              blurRadius: 4,
              offset: const Offset(0, 2),
            )
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.zero,
              child: SizedBox(
                width: 48,
                height: 48,
                child: _buildThumb(imagePath),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (productName.isNotEmpty)
                    Text(
                      productName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87),
                    ),
                  if (isMaterial) ...[
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 3),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF7ED),
                        border: Border.all(color: const Color(0xFFFED7AA)),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Text(
                        'Bahan Baku',
                        style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFF9A3412),
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(height: 4),
                  if (stockName.isNotEmpty)
                    Text(
                      'Batch: $stockName',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style:
                          const TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  if (timeStr.isNotEmpty || employee.isNotEmpty) ...[
                    if (stockName.isEmpty) const SizedBox(height: 2),
                    Text(
                      [
                        if (timeStr.isNotEmpty) timeStr,
                        if (employee.isNotEmpty) employee,
                      ].join('  '),
                      style: const TextStyle(
                          fontSize: 11.5, color: Colors.black45),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: isIn
                        ? Colors.green.withValues(alpha: 0.1)
                        : AppColors.danger.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Text(
                    '${isIn ? '+' : '-'}$qty',
                    style: TextStyle(
                      color: isIn ? Colors.green : AppColors.danger,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
                if (oldQty != null && newQty != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    '$oldQty - $newQty',
                    style: const TextStyle(
                        fontSize: 11,
                        color: Colors.black45,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildThumb(String imagePath) {
    if (imagePath.isNotEmpty) {
      final file = File(imagePath);
      return Image.file(
        file,
        width: 50,
        height: 50,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _placeholder(),
      );
    }
    return _placeholder();
  }

  Widget _placeholder() {
    return Container(
      width: 50,
      height: 50,
      color: const Color(0xFFF0F0F0),
      child:
          const Icon(Icons.image_outlined, color: Color(0xFFBBBBBB), size: 26),
    );
  }
}

//  Empty state painter --
class _HandingBoxPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final bodyPaint = Paint()
      ..color = const Color(0xFFF5F5F5)
      ..style = PaintingStyle.fill;
    final darkPaint = Paint()
      ..color = const Color(0xFF333333)
      ..style = PaintingStyle.fill;

    canvas.drawCircle(Offset(w * 0.25, h * 0.18), 11, darkPaint);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
          Rect.fromLTWH(w * 0.17, h * 0.32, 32, 42), const Radius.circular(0)),
      bodyPaint,
    );
    canvas.drawRect(Rect.fromLTWH(w * 0.17, h * 0.68, 13, 26), darkPaint);
    canvas.drawRect(Rect.fromLTWH(w * 0.17 + 17, h * 0.68, 13, 26), darkPaint);

    canvas.drawCircle(Offset(w * 0.75, h * 0.18), 11, darkPaint);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
          Rect.fromLTWH(w * 0.67, h * 0.32, 32, 42), const Radius.circular(0)),
      darkPaint,
    );
    canvas.drawRect(Rect.fromLTWH(w * 0.67, h * 0.68, 13, 26), darkPaint);
    canvas.drawRect(Rect.fromLTWH(w * 0.67 + 17, h * 0.68, 13, 26), darkPaint);

    final boxPaint = Paint()
      ..color = _kBrand
      ..style = PaintingStyle.fill;
    canvas.drawRect(Rect.fromLTWH(w * 0.39, h * 0.36, 34, 28), boxPaint);
    canvas.drawRect(Rect.fromLTWH(w * 0.37, h * 0.33, 38, 7), darkPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

//  Export Button --
class _ProExportBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _ProExportBtn({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: const BoxDecoration(
          color: AppColors.primaryBrand,
          borderRadius: BorderRadius.zero,
        ),
        child: const Row(
          children: [
            Icon(Icons.download_rounded, color: Colors.white, size: 15),
            SizedBox(width: 5),
            Text(
              'Ekspor',
              style: TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

