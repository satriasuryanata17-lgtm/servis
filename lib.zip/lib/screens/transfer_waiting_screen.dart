import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import '../providers/providers.dart';
import '../services/auth_service.dart';

/// Layar menunggu konfirmasi transfer device dari perangkat aktif (HP1).
class TransferWaitingScreen extends ConsumerStatefulWidget {
  final String requestId;
  final String serial;
  final String password;

  const TransferWaitingScreen({
    required this.requestId,
    required this.serial,
    required this.password,
    super.key,
  });

  @override
  ConsumerState<TransferWaitingScreen> createState() =>
      _TransferWaitingScreenState();
}

class _TransferWaitingScreenState extends ConsumerState<TransferWaitingScreen>
    with SingleTickerProviderStateMixin {
  Timer? _pollTimer;
  Timer? _countdownTimer;
  int _remainingSeconds = 300;
  String _status = 'pending';
  bool _isActivating = false;

  late final AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _startPolling();
    _startCountdown();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _countdownTimer?.cancel();
    _pulseCtrl.dispose();
    super.dispose();
  }

  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      if (_status != 'pending') return;

      final result = await AuthService.checkTransferStatus(widget.requestId);
      if (result == null || !mounted) return;

      final status = result['status']?.toString() ?? 'pending';
      final remaining = (result['remaining_seconds'] as num?)?.toInt() ?? 0;

      setState(() {
        _status = status;
        if (remaining > 0) _remainingSeconds = remaining;
      });

      if (status == 'approved') {
        _pollTimer?.cancel();
        _countdownTimer?.cancel();
        await _activateAfterApproval();
      } else if (status == 'rejected' || status == 'expired') {
        _pollTimer?.cancel();
        _countdownTimer?.cancel();
      }
    });
  }

  void _startCountdown() {
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || _status != 'pending') return;
      setState(() {
        _remainingSeconds = (_remainingSeconds - 1).clamp(0, 300);
      });
      if (_remainingSeconds <= 0) {
        _countdownTimer?.cancel();
        _pollTimer?.cancel();
        setState(() => _status = 'expired');
      }
    });
  }

  Future<void> _activateAfterApproval() async {
    if (_isActivating) return;
    setState(() => _isActivating = true);

    try {
      final result = await ref.read(authProvider.notifier).login(
            widget.serial,
            widget.password,
          );
      if (!mounted) return;
      if (result == AuthStatus.licensee) {
        // Login berhasil  navigator otomatis rebuild ke MainShell
        return;
      }
      setState(() => _status = 'error');
    } catch (_) {
      if (mounted) setState(() => _status = 'error');
    } finally {
      if (mounted) setState(() => _isActivating = false);
    }
  }

  String get _formattedTime {
    final m = (_remainingSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (_remainingSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 48),
            child: Column(
              children: [
                const Spacer(),
                _buildStatusContent(),
                const Spacer(),
                if (_status == 'pending') ...[
                  _buildInfoBanner(),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.danger,
                        side: const BorderSide(color: AppColors.danger),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: const Text('Batal'),
                    ),
                  ),
                ],
                if (_status != 'pending') ...[
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child:
                          Text(_status == 'approved' ? 'Lanjutkan' : 'Kembali'),
                    ),
                  ),
                ],
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusContent() {
    switch (_status) {
      case 'pending':
        return _buildPendingContent();
      case 'approved':
        return _buildApprovedContent();
      case 'rejected':
        return _buildRejectedContent();
      case 'expired':
        return _buildExpiredContent();
      default:
        return _buildErrorContent();
    }
  }

  Widget _buildPendingContent() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, child) => Opacity(
            opacity: 0.5 + (_pulseCtrl.value * 0.5),
            child: child,
          ),
          child: Container(
            width: 96,
            height: 96,
            decoration: BoxDecoration(
              color: AppColors.primaryBrand.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.phone_android_rounded,
              size: 48,
              color: AppColors.primaryBrand,
            ),
          ),
        ),
        const SizedBox(height: 32),
        Text(
          'Menunggu Konfirmasi',
          style: AppText.h2.copyWith(
            fontWeight: FontWeight.w700,
            color: const Color(0xFF101828),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'Permintaan pindah perangkat telah dikirim.\nSilakan buka aplikasi di perangkat lama\ndan setujui perpindahan.',
          textAlign: TextAlign.center,
          style: AppText.body.copyWith(
            color: const Color(0xFF475467),
            height: 1.5,
          ),
        ),
        const SizedBox(height: 28),
        // Countdown
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          decoration: BoxDecoration(
            color: const Color(0xFFF9FAFB),
            border: Border.all(color: const Color(0xFFE5E7EB)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.timer_outlined,
                  color: Color(0xFF6B7280), size: 20),
              const SizedBox(width: 8),
              Text(
                'Sisa waktu: $_formattedTime',
                style: AppText.body.copyWith(
                  fontWeight: FontWeight.w600,
                  color: _remainingSeconds < 60
                      ? AppColors.danger
                      : const Color(0xFF374151),
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
            ],
          ),
        ),
        if (_isActivating) ...[
          const SizedBox(height: 24),
          const CircularProgressIndicator(
              color: AppColors.primaryBrand, strokeWidth: 2.5),
          const SizedBox(height: 8),
          Text('Mengaktifkan lisensi...',
              style: AppText.caption.copyWith(color: const Color(0xFF6B7280))),
        ],
      ],
    );
  }

  Widget _buildApprovedContent() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 96,
          height: 96,
          decoration: const BoxDecoration(
            color: Color(0xFFD1FAE5),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.check_circle_rounded,
              size: 52, color: Color(0xFF059669)),
        ),
        const SizedBox(height: 24),
        Text(
          'Transfer Disetujui!',
          style: AppText.h2.copyWith(
            fontWeight: FontWeight.w700,
            color: const Color(0xFF059669),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Perangkat lama telah menyetujui perpindahan.\nAkun siap digunakan di perangkat ini.',
          textAlign: TextAlign.center,
          style: AppText.body.copyWith(color: const Color(0xFF475467)),
        ),
      ],
    );
  }

  Widget _buildRejectedContent() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 96,
          height: 96,
          decoration: BoxDecoration(
            color: AppColors.danger.withValues(alpha: 0.1),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.block_rounded,
              size: 52, color: AppColors.danger),
        ),
        const SizedBox(height: 24),
        Text(
          'Ditolak',
          style: AppText.h2.copyWith(
            fontWeight: FontWeight.w700,
            color: AppColors.danger,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Perangkat aktif menolak permintaan perpindahan.\nSilakan coba lagi atau hubungi admin.',
          textAlign: TextAlign.center,
          style: AppText.body.copyWith(color: const Color(0xFF475467)),
        ),
      ],
    );
  }

  Widget _buildExpiredContent() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 96,
          height: 96,
          decoration: const BoxDecoration(
            color: Color(0xFFFEF3C7),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.access_time_rounded,
              size: 52, color: Color(0xFFD97706)),
        ),
        const SizedBox(height: 24),
        Text(
          'Waktu Habis',
          style: AppText.h2.copyWith(
            fontWeight: FontWeight.w700,
            color: const Color(0xFFD97706),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Perangkat aktif tidak merespon dalam 5 menit.\nPastikan perangkat aktif terhubung ke internet\ndan buka aplikasi Juragan Servis.',
          textAlign: TextAlign.center,
          style: AppText.body.copyWith(color: const Color(0xFF475467)),
        ),
      ],
    );
  }

  Widget _buildErrorContent() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 96,
          height: 96,
          decoration: BoxDecoration(
            color: AppColors.danger.withValues(alpha: 0.1),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.error_outline_rounded,
              size: 52, color: AppColors.danger),
        ),
        const SizedBox(height: 24),
        Text('Gagal Aktivasi',
            style: AppText.h2.copyWith(
                fontWeight: FontWeight.w700, color: AppColors.danger)),
        const SizedBox(height: 8),
        Text('Terjadi kesalahan saat mengaktifkan lisensi.\nSilakan coba lagi.',
            textAlign: TextAlign.center,
            style: AppText.body.copyWith(color: const Color(0xFF475467))),
      ],
    );
  }

  Widget _buildInfoBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7ED),
        border: Border.all(color: const Color(0xFFFDBA74)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.wifi_rounded, color: Color(0xFFEA580C), size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Kedua perangkat WAJIB terhubung ke internet.\nBuka aplikasi Juragan Servis di perangkat lama agar bisa menerima permintaan ini.',
              style: AppText.caption.copyWith(
                color: const Color(0xFF9A3412),
                fontSize: 12.5,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

