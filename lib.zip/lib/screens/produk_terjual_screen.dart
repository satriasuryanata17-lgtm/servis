import 'dart:io';
import 'package:flutter/material.dart';

import '../database/db_helper.dart';
import '../services/export_service.dart';
import '../core/theme.dart';
import '../widgets/kasir_dialog.dart';
import '../widgets/responsive_layout.dart';
import '../widgets/export_dropdown.dart';

const Color _kBrand = AppColors.primaryBrand;

String _fmtQty(dynamic value) {
  final qty = (value as num?)?.toDouble() ?? 0;
  return qty
      .toStringAsFixed(2)
      .replaceAll(RegExp(r'0+$'), '')
      .replaceAll(RegExp(r'\.$'), '')
      .replaceAll('.', ',');
}

class ProdukTerjualScreen extends StatefulWidget {
  const ProdukTerjualScreen({super.key});

  @override
  State<ProdukTerjualScreen> createState() => _ProdukTerjualScreenState();
}

class _ProdukTerjualScreenState extends State<ProdukTerjualScreen> {
  String _periode = 'Periode Tahunan';
  int _tahun = DateTime.now().year;
  int _bulan = DateTime.now().month;
  DateTime _hariTerpilih = DateTime.now();

  static const _bulanNama = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember'
  ];

  DateTime? _customStart;
  DateTime? _customEnd;

  List<Map<String, dynamic>>? _topProducts;
  bool _isLoading = false;

  final List<String> _periodeOptions = [
    'Periode Harian',
    'Periode Bulanan',
    'Periode Tahunan',
    'Kustom Tanggal',
  ];
  final List<int> _tahunOptions = [
    DateTime.now().year - 2,
    DateTime.now().year - 1,
    DateTime.now().year,
    DateTime.now().year + 1,
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    DateTime start, end;
    if (_periode == 'Periode Harian') {
      start =
          DateTime(_hariTerpilih.year, _hariTerpilih.month, _hariTerpilih.day);
      end = DateTime(_hariTerpilih.year, _hariTerpilih.month, _hariTerpilih.day,
          23, 59, 59);
    } else if (_periode == 'Periode Bulanan') {
      start = DateTime(_tahun, _bulan, 1);
      var nm = _bulan == 12 ? 1 : _bulan + 1;
      var ny = _bulan == 12 ? _tahun + 1 : _tahun;
      end = DateTime(ny, nm, 1).subtract(const Duration(seconds: 1));
    } else if (_periode == 'Kustom Tanggal') {
      final now = DateTime.now();
      start = _customStart ?? DateTime(now.year, now.month, now.day);
      end = _customEnd ?? DateTime(now.year, now.month, now.day, 23, 59, 59);
    } else {
      start = DateTime(_tahun, 1, 1);
      end = DateTime(_tahun, 12, 31, 23, 59, 59);
    }
    final data = await DBHelper.instance
        .getTopSellingProductsByDateRange(start, end, limit: 50);
    if (!mounted) return;
    setState(() {
      _topProducts = data;
      _isLoading = false;
    });
  }

  Future<void> _pickCustomDate() async {
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2050),
      initialDateRange: _customStart != null && _customEnd != null
          ? DateTimeRange(start: _customStart!, end: _customEnd!)
          : null,
      builder: (context, child) => Theme(
        data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
                primary: _kBrand,
                onPrimary: Colors.white,
                surface: Colors.white,
                onSurface: Colors.black)),
        child: child!,
      ),
    );
    if (range != null) {
      setState(() {
        _customStart = range.start;
        _customEnd = range.end;
      });
      _loadData();
    } else {
      setState(() => _periode = 'Periode Tahunan');
      _loadData();
    }
  }

  Future<void> _showBulanSheet() async {
    final selected = await showKasirOptionSheet<int>(context,
        title: 'Pilih Bulan',
        options: List.generate(12, (i) => i + 1),
        currentValue: _bulan,
        labelBuilder: (b) => _bulanNama[b - 1]);
    if (selected != null && selected != _bulan && mounted) {
      setState(() => _bulan = selected);
      _loadData();
    }
  }

  Future<void> _pickHariDate() async {
    final picked = await showDatePicker(
        context: context,
        initialDate: _hariTerpilih,
        firstDate: DateTime(2020),
        lastDate: DateTime(2050),
        builder: (context, child) => Theme(
            data: ThemeData.light().copyWith(
                colorScheme: const ColorScheme.light(
                    primary: _kBrand,
                    onPrimary: Colors.white,
                    surface: Colors.white,
                    onSurface: Colors.black)),
            child: child!));
    if (picked != null) {
      setState(() => _hariTerpilih = picked);
      _loadData();
    }
  }

  Future<void> _exportProdukTerjual() async {
    final choice = await ExportDropdown.show(context);
    if (choice == null) return;

    final top = _topProducts ?? [];
    if (!mounted) return;
    if (top.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Belum ada data layanan terjual.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      return;
    }

    String dateInfo = _periode;
    if (_periode == 'Periode Tahunan') {
      dateInfo = '$_periode $_tahun';
    } else if (_periode == 'Kustom Tanggal' && _customStart != null) {
      dateInfo =
          '${_customStart!.day}/${_customStart!.month}/${_customStart!.year} - ${_customEnd!.day}/${_customEnd!.month}/${_customEnd!.year}';
    }

    final headers = ['Nama Layanan', 'Software', 'Total Terjual'];
    final rows = top
        .map((row) => [
              row['name'] ?? '-',
              row['unit'] ?? '-',
              _fmtQty(row['total_sold']),
            ])
        .toList();

    final Map<String, String> summaryData = {
      'Total Layanan': '${top.length} Item',
      'Layanan Terlaris': (top.first['name'] ?? '-').toString(),
      'Periode': _periode,
      'Filter': dateInfo,
    };

    const title = 'Laporan Layanan Terjual';

    try {
      if (choice == 'csv') {
        await ExportService.exportAndShareCsv(
          filePrefix: 'layanan_terjual',
          headers: [
            'ID Layanan',
            'Nama Layanan',
            'Software',
            'Total Terjual',
            'Periode',
            'Tanggal Filter'
          ],
          rows: top
              .map((row) => [
                    row['id'] ?? '-',
                    row['name'] ?? '-',
                    row['unit'] ?? '-',
                    _fmtQty(row['total_sold']),
                    _periode,
                    dateInfo
                  ])
              .toList(),
          subject: 'Ekspor Layanan Terjual',
          message: 'Filter: $dateInfo',
        );
      } else if (choice == 'pdf') {
        await ExportService.exportPdfLaporan(
          title: title,
          subtitle: 'Filter: $dateInfo',
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      } else if (choice == 'print') {
        await ExportService.printPdfLaporan(
          title: title,
          subtitle: 'Filter: $dateInfo',
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Gagal mengekspor data. Silakan coba lagi.')),
      );
    }
  }

  Future<void> _showPeriodeSheet() async {
    final selected = await showKasirOptionSheet<String>(context,
        title: 'Pilih Periode',
        options: _periodeOptions,
        currentValue: _periode,
        labelBuilder: (v) => v);
    if (selected != null && selected != _periode && mounted) {
      setState(() => _periode = selected);
      if (selected == 'Kustom Tanggal') {
        _pickCustomDate();
      } else {
        _loadData();
      }
    }
  }

  Future<void> _showTahunSheet() async {
    final selected = await showKasirOptionSheet<int>(context,
        title: 'Pilih Tahun',
        options: _tahunOptions,
        currentValue: _tahun,
        labelBuilder: (y) => y.toString());
    if (selected != null && selected != _tahun && mounted) {
      setState(() => _tahun = selected);
      _loadData();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = KasirLayout.isTablet(context);
    final isLandscape = KasirLayout.isLandscape(context);

    final exportAction = GestureDetector(
      onTap: _exportProdukTerjual,
      child: Container(
        height: 38,
        padding: const EdgeInsets.symmetric(horizontal: 18),
        alignment: Alignment.center,
        decoration: const BoxDecoration(
            color: _kBrand, borderRadius: BorderRadius.zero),
        child: const Text('Export',
            style: TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w800)),
      ),
    );

    return KasirResponsiveScaffold(
      title: 'Layanan Terjual',
      showNavRail: false,
      navIndex: 4,
      backgroundColor: Colors.white,
      actions: [exportAction, const SizedBox(width: 8)],
      body: (isTablet || isLandscape)
          ? _buildWideLayout()
          : _buildPortraitLayout(),
    );
  }

  Widget _buildWideLayout() {
    return KasirLandscapeSplit(
      leftWidth: 240,
      leftPanel: _buildFilterPanel(),
      rightPanel: _buildWideProductPanel(),
    );
  }

  Widget _buildWideProductPanel() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: _kBrand));
    }

    final top = _topProducts ?? [];
    return Column(
      children: [
        Container(
          height: 48,
          padding: const EdgeInsets.symmetric(horizontal: 18),
          decoration: const BoxDecoration(
            color: Colors.white,
            border: Border(bottom: BorderSide(color: Color(0xFFE2E8F0))),
          ),
          child: Row(
            children: [
              const Text('Peringkat Layanan',
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF111827))),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: const BoxDecoration(
                    color: Color(0xFFEFF6FF), borderRadius: BorderRadius.zero),
                child: Text('${top.length} layanan',
                    style: const TextStyle(
                        color: _kBrand,
                        fontSize: 12,
                        fontWeight: FontWeight.w800)),
              ),
            ],
          ),
        ),
        Expanded(
          child: _buildProductList(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
            wide: true,
          ),
        ),
      ],
    );
  }

  Widget _buildPortraitLayout() {
    return Column(
      children: [
        const Divider(height: 1, color: Color(0xFFEEEEEE)),
        KasirPeriodBar(
          periode: _periode,
          tahun: _tahun,
          bulan: _bulan,
          hariTerpilih: _hariTerpilih,
          customStart: _customStart,
          customEnd: _customEnd,
          onPeriodeTap: _showPeriodeSheet,
          onTahunTap: _showTahunSheet,
          onBulanTap: _showBulanSheet,
          onHariTap: _pickHariDate,
        ),
        const SizedBox(height: 12),
        Expanded(
            child: _buildProductList(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 20))),
      ],
    );
  }

  Widget _buildFilterPanel() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Periode',
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF64748B))),
          const SizedBox(height: 8),
          ..._periodeOptions.map((opt) => _FilterOption(
                label: opt,
                selected: _periode == opt,
                onTap: () {
                  setState(() => _periode = opt);
                  if (opt == 'Kustom Tanggal') {
                    _pickCustomDate();
                  } else {
                    _loadData();
                  }
                },
              )),
          if (_periode == 'Periode Bulanan') ...[
            const SizedBox(height: 16),
            const Text('Bulan & Tahun',
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF64748B))),
            const SizedBox(height: 8),
            _DropdownChip(
                label: _bulanNama[_bulan - 1], onTap: _showBulanSheet),
            const SizedBox(height: 6),
            _DropdownChip(label: _tahun.toString(), onTap: _showTahunSheet),
          ] else if (_periode == 'Periode Harian') ...[
            const SizedBox(height: 16),
            const Text('Tanggal',
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF64748B))),
            const SizedBox(height: 8),
            _DropdownChip(
                label:
                    '${_hariTerpilih.day} ${_bulanNama[_hariTerpilih.month - 1]} ${_hariTerpilih.year}',
                onTap: _pickHariDate),
          ] else if (_periode == 'Periode Tahunan') ...[
            const SizedBox(height: 16),
            const Text('Tahun',
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF64748B))),
            const SizedBox(height: 8),
            _DropdownChip(label: _tahun.toString(), onTap: _showTahunSheet),
          ],
          if (_topProducts != null &&
              !_isLoading &&
              _topProducts!.isNotEmpty) ...[
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                    colors: [AppColors.primaryBrand, AppColors.primaryDark],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight),
                borderRadius: BorderRadius.zero,
              ),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Total Layanan',
                        style: TextStyle(color: Colors.white70, fontSize: 11)),
                    const SizedBox(height: 4),
                    Text('${_topProducts!.length} item',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    Text(_periode,
                        style: const TextStyle(
                            color: Colors.white60, fontSize: 11)),
                  ]),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildProductList({
    EdgeInsets padding = EdgeInsets.zero,
    bool wide = false,
  }) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: _kBrand));
    }
    if (_topProducts == null || _topProducts!.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
                width: 200,
                height: 160,
                child: CustomPaint(painter: _CardsPainter())),
            const SizedBox(height: 16),
            const Text('Layanan Terjual Tidak Ditemukan',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87)),
            const SizedBox(height: 6),
            const Text('Belum ada penjualan di periode ini',
                style: TextStyle(fontSize: 13, color: Colors.black54)),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: padding,
      itemCount: _topProducts!.length,
      itemBuilder: (_, i) {
        final row = _topProducts![i];
        final imagePath = (row['image_path'] as String?) ?? '';
        final rankColor = i == 0
            ? const Color(0xFFFFB300)
            : i == 1
                ? const Color(0xFF90A4AE)
                : i == 2
                    ? const Color(0xFF8D6E63)
                    : _kBrand;

        return Padding(
          padding: EdgeInsets.symmetric(vertical: wide ? 6 : 5),
          child: Container(
            constraints: BoxConstraints(minHeight: wide ? 82 : 0),
            padding: EdgeInsets.symmetric(
              horizontal: wide ? 16 : 12,
              vertical: wide ? 13 : 12,
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.zero,
              border: Border.all(
                  color:
                      wide ? const Color(0xFFD7E0EA) : const Color(0xFFEEEEEE),
                  width: wide ? 1.1 : 1),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withValues(alpha: wide ? 0.035 : 0.02),
                    blurRadius: wide ? 8 : 4,
                    offset: Offset(0, wide ? 3 : 2))
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: wide ? 34 : 22,
                  height: wide ? 34 : 22,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: rankColor.withValues(alpha: wide ? 0.14 : 1),
                    borderRadius: BorderRadius.zero,
                    border: Border.all(
                        color: wide ? rankColor : Colors.white,
                        width: wide ? 1 : 2),
                  ),
                  child: Text('${i + 1}',
                      style: TextStyle(
                          color: wide ? rankColor : Colors.white,
                          fontSize: wide ? 15 : 10,
                          fontWeight: FontWeight.w900)),
                ),
                SizedBox(width: wide ? 12 : 8),
                ClipRRect(
                  borderRadius: BorderRadius.zero,
                  child: SizedBox(
                    width: wide ? 56 : 52,
                    height: wide ? 56 : 52,
                    child: imagePath.isNotEmpty
                        ? Image.file(File(imagePath),
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                _placeholder(size: wide ? 56 : 52))
                        : _placeholder(size: wide ? 56 : 52),
                  ),
                ),
                SizedBox(width: wide ? 14 : 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(row['name'] ?? '-',
                          maxLines: wide ? 2 : 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: wide ? 15 : 14,
                              height: 1.15,
                              fontWeight: FontWeight.w800,
                              color: const Color(0xFF111827))),
                      const SizedBox(height: 7),
                      Row(
                        children: [
                          const Icon(Icons.tag,
                              size: 13, color: Color(0xFF94A3B8)),
                          const SizedBox(width: 4),
                          Text('ID: ${row['id']}',
                              style: TextStyle(
                                  color: const Color(0xFF64748B),
                                  fontSize: wide ? 12 : 12,
                                  fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(width: wide ? 16 : 8),
                Container(
                  width: wide ? 112 : null,
                  padding: EdgeInsets.symmetric(
                      horizontal: wide ? 12 : 10, vertical: wide ? 8 : 4),
                  decoration: BoxDecoration(
                    color: _kBrand.withValues(alpha: 0.09),
                    borderRadius: BorderRadius.zero,
                    border: Border.all(color: _kBrand.withValues(alpha: 0.16)),
                  ),
                  child: Column(
                    crossAxisAlignment: wide
                        ? CrossAxisAlignment.center
                        : CrossAxisAlignment.end,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('Terjual',
                          style: TextStyle(
                              fontSize: 10,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 2),
                      Text('${_fmtQty(row['total_sold'])} ${row['unit']}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: wide ? 15 : 14,
                              color: _kBrand)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _placeholder({double size = 52}) => Container(
      width: size,
      height: size,
      color: const Color(0xFFF0F0F0),
      child:
          const Icon(Icons.image_outlined, color: Color(0xFFBBBBBB), size: 24));
}

class _FilterOption extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _FilterOption(
      {required this.label, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.only(bottom: 6),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: selected
                ? AppColors.primaryBrand.withValues(alpha: 0.10)
                : Colors.transparent,
            borderRadius: BorderRadius.zero,
            border: Border.all(
                color: selected
                    ? AppColors.primaryBrand
                    : const Color(0xFFE2E8F0)),
          ),
          child: Row(children: [
            Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off,
                size: 16,
                color: selected ? AppColors.primaryBrand : Colors.grey),
            const SizedBox(width: 8),
            Text(label,
                style: TextStyle(
                    fontWeight: selected ? FontWeight.w700 : FontWeight.normal,
                    color: selected
                        ? AppColors.primaryBrand
                        : const Color(0xFF374151),
                    fontSize: 13)),
          ]),
        ),
      );
}

class _DropdownChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _DropdownChip({required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: const BoxDecoration(
              color: Color(0xFFF5F5F5), borderRadius: BorderRadius.zero),
          child: Row(children: [
            Expanded(
                child: Text(label,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 13))),
            const Icon(Icons.keyboard_arrow_down_rounded,
                color: AppColors.primaryBrand, size: 18),
          ]),
        ),
      );
}

class _CardsPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(w * 0.05, h * 0.05, w * 0.7, h * 0.65),
            const Radius.circular(0)),
        Paint()..color = const Color(0xFF3D4A6B));
    canvas.drawRect(Rect.fromLTWH(w * 0.05, h * 0.2, w * 0.7, h * 0.12),
        Paint()..color = const Color(0xFF1A1A2E));
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(w * 0.22, h * 0.28, w * 0.72, h * 0.65),
            const Radius.circular(0)),
        Paint()
          ..color = Colors.black12
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6));
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(w * 0.22, h * 0.28, w * 0.72, h * 0.65),
            const Radius.circular(0)),
        Paint()..color = Colors.white);
    canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(w * 0.28, h * 0.36, 18, 14),
            const Radius.circular(0)),
        Paint()..color = const Color(0xFF666666));
    final dp = Paint()..color = _kBrand;
    for (int g = 0; g < 4; g++) {
      for (int d = 0; d < 4; d++) {
        canvas.drawCircle(Offset(w * 0.3 + g * 30 + d * 5.5, h * 0.62), 3, dp);
      }
    }
    final lp = Paint()
      ..color = const Color(0xFFCCCCCC)
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(w * 0.3, h * 0.76), Offset(w * 0.6, h * 0.76), lp);
    canvas.drawLine(Offset(w * 0.3, h * 0.84), Offset(w * 0.5, h * 0.84), lp);
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

