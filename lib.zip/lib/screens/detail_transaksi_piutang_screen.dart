import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import 'struk_screen.dart';
import '../core/theme.dart';
import '../providers/providers.dart';
import '../utils/transaction_code_formatter.dart';
import '../utils/currency_input_formatter.dart';
import '../services/whatsapp_helper.dart';
import '../services/cash_drawer_service.dart';

const Color _kBrand = AppColors.primaryBrand;
const Color _kGreen = Color(0xFF2E7D32);

// ── Helpers ──────────────────────────────────────────────────────
String _fK(int n) {
  if (n == 0) return '0';
  String s = n.toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return r;
}

String _fmtQty(double n) {
  return n
      .toStringAsFixed(2)
      .replaceAll(RegExp(r'0+$'), '')
      .replaceAll(RegExp(r'\.$'), '')
      .replaceAll('.', ',');
}

String _itemUnit(TransactionItem item) {
  final unit = item.unit?.trim();
  if (unit != null && unit.isNotEmpty) return unit;
  return item.isHardware == 1 ? 'kg' : '';
}

double _itemBillableQty(TransactionItem item) {
  if (item.unitPrice <= 0 || item.subtotal <= 0) return item.qty;
  final billed = item.subtotal / item.unitPrice;
  return billed > 0 ? billed : item.qty;
}

bool _hasRoundedBilling(TransactionItem item) {
  final unit = _itemUnit(item).toLowerCase();
  if (unit != 'kg' && item.isHardware != 1) return false;
  return (_itemBillableQty(item) - item.qty).abs() > 0.001;
}

String _itemPriceLine(TransactionItem item) {
  final unit = _itemUnit(item);
  final unitSuffix = unit.isEmpty ? '' : '/$unit';
  final qtyLabel =
      unit.isEmpty ? _fmtQty(item.qty) : '${_fmtQty(item.qty)} $unit';
  final rounded = _hasRoundedBilling(item)
      ? ' (tagih ${_fmtQty(_itemBillableQty(item))} $unit)'
      : '';
  return '$qtyLabel$rounded x Rp${_fK(item.unitPrice)}$unitSuffix';
}

String _formatNoTransaksi(Transaction tx) {
  return TransactionCodeFormatter.format(
    id: tx.id ?? 0,
    createdAt: tx.createdAt,
    transactionCode: tx.transactionCode,
  );
}

String _formatTanggal(String createdAt) {
  try {
    final dt = DateTime.parse(createdAt).toLocal();
    final bulanMap = {
      1: 'Januari',
      2: 'Februari',
      3: 'Maret',
      4: 'April',
      5: 'Mei',
      6: 'Juni',
      7: 'Juli',
      8: 'Agustus',
      9: 'September',
      10: 'Oktober',
      11: 'November',
      12: 'Desember',
    };
    return '${dt.day} ${bulanMap[dt.month]} ${dt.year} '
        '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}:${dt.second.toString().padLeft(2, '0')}';
  } catch (_) {
    return createdAt;
  }
}

String _formatTanggalCicilan(String createdAt) {
  try {
    return DateFormat('dd MMM yyyy, HH:mm')
        .format(DateTime.parse(createdAt).toLocal());
  } catch (_) {
    return createdAt;
  }
}

String _formatTanggalPendek(String? createdAt) {
  if (createdAt == null || createdAt.isEmpty) return '-';
  try {
    return DateFormat('dd MMM yyyy', 'id_ID')
        .format(DateTime.parse(createdAt).toLocal());
  } catch (_) {
    return createdAt;
  }
}

bool _isWide(BuildContext ctx) {
  final mq = MediaQuery.of(ctx);
  return mq.size.width >= 720 ||
      (mq.orientation == Orientation.landscape && mq.size.width >= 600);
}

// ── Screen ────────────────────────────────────────────────────────
class DetailTransaksiPiutangScreen extends ConsumerStatefulWidget {
  final int transactionId;
  const DetailTransaksiPiutangScreen({super.key, required this.transactionId});

  @override
  ConsumerState<DetailTransaksiPiutangScreen> createState() =>
      _DetailTransaksiPiutangScreenState();
}

class _DetailTransaksiPiutangScreenState
    extends ConsumerState<DetailTransaksiPiutangScreen> {
  Transaction? _tx;
  List<TransactionItem> _items = [];
  List<Cicilan> _cicilans = [];
  String _kasirName = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final tx = await DBHelper.instance.getTransactionById(widget.transactionId);
    final items =
        await DBHelper.instance.getTransactionItems(widget.transactionId);
    final cicilans = await DBHelper.instance
        .getCicilansByTransactionId(widget.transactionId);
    final profil = await DBHelper.instance.getProfil();
    if (mounted) {
      setState(() {
        _tx = tx;
        _items = items;
        _cicilans = cicilans;
        _kasirName = profil['nama'] ?? '';
        _loading = false;
      });
    }
  }

  // ── Bayar cicilan sheet ────────────────────────────────────────
  void _showBayarCicilanSheet() {
    if (_tx == null) return;
    final sisaPiutang = _tx!.grandTotal - _tx!.amountPaid;
    if (sisaPiutang <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Piutang ini sudah lunas!'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      return;
    }

    final isPesanan =
        _tx!.paymentMethod == 'Pesanan' || _tx!.paymentMethod == 'buat_pesanan';
    final nominalCtrl =
        TextEditingController(text: formatCurrencyInput(sisaPiutang));
    String metodeBayar = 'tunai';

    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (_) => StatefulBuilder(
              builder: (ctx, setStateSheet) => Padding(
                padding: EdgeInsets.only(
                    bottom: MediaQuery.of(ctx).viewInsets.bottom),
                child: Container(
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.vertical(top: Radius.zero)),
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                          child: Container(
                              width: 40,
                              height: 4,
                              decoration: BoxDecoration(
                                  color: Colors.grey.shade300,
                                  borderRadius: BorderRadius.zero))),
                      const SizedBox(height: 16),
                      Center(child: _IlustrasiKartu()),
                      const SizedBox(height: 16),
                      Text(isPesanan ? 'Bayar Pesanan' : 'Bayar Cicilan',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 22)),
                      const SizedBox(height: 16),
                      const Row(children: [
                        Text('Nominal',
                            style: TextStyle(
                                fontWeight: FontWeight.w500, fontSize: 14)),
                        Text(' *',
                            style: TextStyle(
                                color: AppColors.danger, fontSize: 14)),
                      ]),
                      const SizedBox(height: 6),
                      TextField(
                          controller: nominalCtrl,
                          keyboardType: TextInputType.number,
                          inputFormatters: const [CurrencyInputFormatter()],
                          decoration: InputDecoration(
                              prefixText: 'Rp',
                              prefixStyle: const TextStyle(
                                  color: Colors.black87, fontSize: 14),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.zero,
                                  borderSide:
                                      BorderSide(color: Colors.grey.shade300)),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.zero,
                                  borderSide:
                                      BorderSide(color: Colors.grey.shade300)),
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 14))),
                      const SizedBox(height: 14),
                      const Text('Metode Pembayaran',
                          style: TextStyle(
                              fontWeight: FontWeight.w500, fontSize: 14)),
                      const SizedBox(height: 8),
                      Row(children: [
                        Expanded(
                            child: _MetodeBayarBtn(
                                label: 'Tunai',
                                selected: metodeBayar == 'tunai',
                                onTap: () => setStateSheet(
                                    () => metodeBayar = 'tunai'))),
                        const SizedBox(width: 10),
                        Expanded(
                            child: _MetodeBayarBtn(
                                label: 'Non Tunai',
                                selected: metodeBayar == 'non_tunai',
                                onTap: () => setStateSheet(
                                    () => metodeBayar = 'non_tunai'))),
                      ]),
                      const SizedBox(height: 24),
                      Row(children: [
                        Expanded(
                            child: OutlinedButton(
                                onPressed: () => Navigator.pop(ctx),
                                style: OutlinedButton.styleFrom(
                                    side: const BorderSide(color: _kBrand),
                                    foregroundColor: _kBrand,
                                    minimumSize: const Size.fromHeight(50),
                                    shape: const RoundedRectangleBorder(
                                        borderRadius: BorderRadius.zero)),
                                child: const Text('Batal',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 15)))),
                        const SizedBox(width: 12),
                        Expanded(
                            child: ElevatedButton(
                                onPressed: () {
                                  final nominal =
                                      parseCurrencyInput(nominalCtrl.text);
                                  if (nominal <= 0) {
                                    ScaffoldMessenger.of(ctx).showSnackBar(
                                        const SnackBar(
                                            content: Text(
                                                'Nominal harus lebih dari 0!'),
                                            backgroundColor: Colors.black87,
                                            behavior: SnackBarBehavior.floating,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.zero)));
                                    return;
                                  }
                                  Navigator.pop(ctx);
                                  WidgetsBinding.instance
                                      .addPostFrameCallback((_) {
                                    _prosesBayarCicilan(nominal, metodeBayar);
                                  });
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: _kBrand,
                                    elevation: 0,
                                    minimumSize: const Size.fromHeight(50),
                                    shape: const RoundedRectangleBorder(
                                        borderRadius: BorderRadius.zero)),
                                child: const Text('OK',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 15)))),
                      ]),
                    ],
                  ),
                ),
              ),
            )).then((_) => nominalCtrl.dispose());
  }

  Future<void> _prosesBayarCicilan(int nominal, String metode) async {
    if (_tx == null) return;
    final isPesanan =
        _tx!.paymentMethod == 'Pesanan' || _tx!.paymentMethod == 'buat_pesanan';
    try {
      final cicilan = Cicilan(
        transactionId: widget.transactionId,
        nominal: nominal,
        metodePembayaran: metode,
        createdAt: DateTime.now().toIso8601String(),
      );

      final newAmountPaid =
          (_tx!.amountPaid + nominal).clamp(0, _tx!.grandTotal + nominal);

      await ref.read(transactionsProvider.notifier).addCicilan(
            transactionId: widget.transactionId,
            cicilan: cicilan,
            newAmountPaid: newAmountPaid,
            grandTotal: _tx!.grandTotal,
          );
      unawaited(_openCashDrawerAfterPayment(metode));

      HapticFeedback.heavyImpact();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(isPesanan
              ? 'Pembayaran pesanan Rp${_fK(nominal)} berhasil!'
              : 'Cicilan Rp${_fK(nominal)} berhasil dicatat!'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ));
        await _load();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Terjadi kesalahan. Silakan coba lagi.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ));
      }
    }
  }

  // ── Build ──────────────────────────────────────────────────────
  Future<void> _openCashDrawerAfterPayment(String paymentMethod) async {
    try {
      await CashDrawerService.openAfterCashPayment(paymentMethod);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Gagal membuka laci otomatis: $e'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
    }
  }

  Future<void> _ubahJatuhTempo() async {
    if (_tx == null) return;
    final current = DateTime.tryParse(_tx!.dueDate ?? '') ?? DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: current.isBefore(DateTime.now()) ? DateTime.now() : current,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
    );
    if (picked == null) return;
    await DBHelper.instance.updatePiutangDueDate(
      widget.transactionId,
      picked.toIso8601String(),
    );
    await _load();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Jatuh tempo diperbarui'),
        behavior: SnackBarBehavior.floating,
      ));
    }
  }

  Future<void> _kirimReminderWhatsApp() async {
    if (_tx == null) return;
    Customer? customer;
    if (_tx!.customerId != null) {
      final customers = await DBHelper.instance.getAllCustomers();
      for (final c in customers) {
        if (c.id == _tx!.customerId) {
          customer = c;
          break;
        }
      }
    }

    final tx = _tx!;
    final sisa = (tx.grandTotal - tx.amountPaid).clamp(0, tx.grandTotal);
    final message = '''
Halo ${tx.customerName ?? customer?.name ?? 'Pelanggan'},

Kami ingin mengingatkan tagihan piutang:
No: ${_formatNoTransaksi(tx)}
Sisa tagihan: Rp${_fK(sisa)}
Jatuh tempo: ${_formatTanggalPendek(tx.dueDate)}

Mohon konfirmasi pembayaran saat sudah dilakukan. Terima kasih.
''';

    final ok = await WhatsAppHelper.sendMessage(
      message: message.trim(),
      phone: customer?.phone,
    );
    if (ok) {
      await DBHelper.instance.markPiutangReminderSent(widget.transactionId);
      await _load();
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(
            ok ? 'Reminder WhatsApp disiapkan' : 'Tidak bisa membuka WhatsApp'),
        behavior: SnackBarBehavior.floating,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
          backgroundColor: Colors.white,
          body: Center(child: CircularProgressIndicator(color: _kBrand)));
    }
    if (_tx == null) {
      return const Scaffold(
          backgroundColor: Colors.white,
          body: Center(child: Text('Transaksi tidak ditemukan')));
    }

    final tx = _tx!;
    final noTransaksi = _formatNoTransaksi(tx);
    final sisaPiutang = (tx.grandTotal - tx.amountPaid).clamp(0, tx.grandTotal);
    final isLunas = tx.amountPaid >= tx.grandTotal;

    return LayoutBuilder(builder: (ctx, _) {
      final wide = _isWide(ctx);
      return Scaffold(
        backgroundColor:
            wide ? const Color(0xFFF5F6FA) : const Color(0xFFF7F7F7),
        appBar: _buildAppBar(noTransaksi, wide),
        body: wide
            ? _buildWideBody(ctx, tx, noTransaksi, sisaPiutang, isLunas)
            : _buildNarrowBody(tx, noTransaksi, sisaPiutang, isLunas),
        bottomNavigationBar: _buildBottomBar(tx, isLunas),
      );
    });
  }

  // ── AppBar ─────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar(String noTransaksi, bool wide) {
    return AppBar(
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.white,
      elevation: 0,
      leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: const Padding(
              padding: EdgeInsets.only(left: 12),
              child: Icon(Icons.arrow_back_ios_rounded,
                  color: _kBrand, size: 20))),
      title: Row(mainAxisSize: MainAxisSize.min, children: [
        Text(noTransaksi,
            style: TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.bold,
                fontSize: wide ? 17 : 16)),
        const SizedBox(width: 6),
        GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: noTransaksi));
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Nomor transaksi disalin'),
                  behavior: SnackBarBehavior.floating,
                  duration: Duration(seconds: 1),
                  backgroundColor: Colors.black87,
                  shape:
                      RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
            },
            child: const Icon(Icons.copy_rounded, color: _kBrand, size: 18)),
      ]),
      centerTitle: false,
      bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: const Color(0xFFEEEEEE))),
    );
  }

  // ── Wide body ──────────────────────────────────────────────────
  Widget _buildWideBody(BuildContext ctx, Transaction tx, String noTransaksi,
      int sisaPiutang, bool isLunas) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // LEFT: transaction detail + customer
        SizedBox(
          width: 420,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              _buildStatusHeader(tx, isLunas, sisaPiutang, wide: true),
              const SizedBox(height: 14),
              _buildRincianCard(tx, noTransaksi, isLunas, sisaPiutang),
              const SizedBox(height: 14),
              _buildPelangganCard(tx),
            ]),
          ),
        ),

        const VerticalDivider(width: 1, color: Color(0xFFEEEEEE)),

        // RIGHT: cicilan history + actions
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              _buildCicilanCard(isLunas, wide: true),
            ]),
          ),
        ),
      ],
    );
  }

  // ── Narrow body ────────────────────────────────────────────────
  Widget _buildNarrowBody(
      Transaction tx, String noTransaksi, int sisaPiutang, bool isLunas) {
    return SingleChildScrollView(
      child: Column(children: [
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: _buildRincianCard(tx, noTransaksi, isLunas, sisaPiutang),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
          child: _buildPelangganCard(tx),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
          child: _buildCicilanCard(isLunas, wide: false),
        ),
      ]),
    );
  }

  // ── Status header (wide) ───────────────────────────────────────
  Widget _buildStatusHeader(Transaction tx, bool isLunas, int sisaPiutang,
      {required bool wide}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: isLunas
                  ? [_kGreen, const Color(0xFF1B5E20)]
                  : [AppColors.danger, const Color(0xFFB22038)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
          borderRadius: BorderRadius.zero),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(isLunas ? '✓  PIUTANG LUNAS' : 'SISA PIUTANG',
            style: const TextStyle(
                color: Colors.white70, fontSize: 12, letterSpacing: 1.2)),
        const SizedBox(height: 6),
        Text(isLunas ? 'Rp 0' : 'Rp ${_fK(sisaPiutang)}',
            style: const TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text(
            'Total: Rp ${_fK(tx.grandTotal)}  •  Terbayar: Rp ${_fK(tx.amountPaid)}',
            style: const TextStyle(color: Colors.white70, fontSize: 12)),
      ]),
    );
  }

  // ── Rincian card ───────────────────────────────────────────────
  Widget _buildRincianCard(
      Transaction tx, String noTransaksi, bool isLunas, int sisaPiutang) {
    return Container(
      decoration: const BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.zero),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Text('Rincian Transaksi',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(width: 6),
            Text(isLunas ? '(Lunas)' : '(Belum Lunas)',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: isLunas ? _kGreen : AppColors.danger)),
          ]),
          const SizedBox(height: 12),
          _InfoRow(
              label: 'Dibuat Oleh',
              value: _kasirName.isEmpty ? 'Admin' : _kasirName),
          const SizedBox(height: 6),
          const _InfoRow(label: 'Pembelian', value: 'Kredit'),
          const SizedBox(height: 6),
          _InfoRow(
              label: 'Tanggal Pencatatan', value: _formatTanggal(tx.createdAt)),
          const SizedBox(height: 6),
          _InfoRow(
              label: 'Jatuh Tempo', value: _formatTanggalPendek(tx.dueDate)),
          const SizedBox(height: 6),
          _InfoRow(
              label: 'Reminder',
              value: tx.reminderCount == 0
                  ? 'Belum pernah dikirim'
                  : '${tx.reminderCount}x, terakhir ${_formatTanggalPendek(tx.lastReminderAt)}'),
          const SizedBox(height: 16),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          const SizedBox(height: 16),
          const Text('Pesanan',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 10),
          const Row(children: [
            Expanded(
                child: Text('Nama Barang',
                    style:
                        TextStyle(fontWeight: FontWeight.w600, fontSize: 13))),
            SizedBox(width: 8),
            Text('Jumlah',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
            SizedBox(width: 24),
            Text('Harga',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
          ]),
          const SizedBox(height: 8),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          const SizedBox(height: 8),
          ..._items.map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                        child: Text(item.productName,
                            style: const TextStyle(fontSize: 14))),
                    const SizedBox(width: 8),
                    Text(_itemPriceLine(item),
                        style: const TextStyle(
                            fontSize: 13, color: Colors.black54)),
                    const SizedBox(width: 8),
                    Text('Rp${_fK(item.subtotal)}',
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14)),
                  ],
                ),
              )),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          const SizedBox(height: 10),
          _TotalRow(label: 'Total Pesanan', value: 'Rp${_fK(tx.totalAmount)}'),
          if (tx.discountAmount > 0) ...[
            const SizedBox(height: 6),
            _TotalRow(
                label: 'Diskon',
                value: '- Rp${_fK(tx.discountAmount)}',
                color: const Color(0xFFE65100)),
          ],
          ...tx.chargesList.map((c) => Padding(
                padding: const EdgeInsets.only(top: 6),
                child: _TotalRow(
                  label: c['label']?.toString() ?? 'Biaya Tambahan',
                  value: 'Rp${_fK(c['value'] as int? ?? 0)}',
                ),
              )),
          const SizedBox(height: 6),
          _TotalRow(label: 'Total', value: 'Rp${_fK(tx.grandTotal)}'),
          const SizedBox(height: 6),
          _TotalRow(label: 'Total Terbayar', value: 'Rp${_fK(tx.amountPaid)}'),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Sisa Piutang',
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                      color: AppColors.danger)),
              Text('Rp${_fK(sisaPiutang)}',
                  style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      color: AppColors.danger)),
            ],
          ),
        ],
      ),
    );
  }

  // ── Pelanggan card ─────────────────────────────────────────────
  Widget _buildPelangganCard(Transaction tx) {
    return Container(
      decoration: const BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.zero),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Pelanggan',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.zero),
            child: Row(children: [
              Expanded(
                  child: Text(
                      tx.customerName?.isNotEmpty == true
                          ? tx.customerName!
                          : 'Pelanggan Umum',
                      style: const TextStyle(
                          fontWeight: FontWeight.w500, fontSize: 14))),
              GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(
                        text: tx.customerName?.isNotEmpty == true
                            ? tx.customerName!
                            : 'Pelanggan Umum'));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Nama pelanggan disalin'),
                        behavior: SnackBarBehavior.floating,
                        duration: Duration(seconds: 1),
                        backgroundColor: Colors.black87,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero)));
                  },
                  child: const Icon(Icons.copy_rounded,
                      color: Colors.black45, size: 18)),
            ]),
          ),
        ],
      ),
    );
  }

  // ── Cicilan card ───────────────────────────────────────────────
  Widget _buildCicilanCard(bool isLunas, {required bool wide}) {
    return Container(
      decoration: const BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.zero),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Riwayat Cicilan',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              if (wide && !isLunas)
                ElevatedButton.icon(
                    onPressed: _showBayarCicilanSheet,
                    icon: const Icon(Icons.add_rounded, size: 16),
                    label: const Text('Bayar'),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 8),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        textStyle: const TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w700))),
            ],
          ),
          const SizedBox(height: 12),

          // Progress bar
          if (_tx != null) ...[
            _buildPaymentProgress(_tx!),
            const SizedBox(height: 16),
            const Divider(height: 1, color: Color(0xFFEEEEEE)),
            const SizedBox(height: 12),
          ],

          // Cicilan list
          if (_cicilans.isEmpty)
            const Padding(
                padding: EdgeInsets.symmetric(vertical: 4),
                child: Text('Belum ada pembayaran cicilan.',
                    style: TextStyle(color: Colors.black45, fontSize: 13)))
          else
            ..._cicilans.asMap().entries.map((entry) {
              final idx = entry.key + 1;
              final c = entry.value;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(children: [
                  Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                          color: _kBrand.withValues(alpha: 0.1),
                          shape: BoxShape.rectangle),
                      alignment: Alignment.center,
                      child: Text('$idx',
                          style: const TextStyle(
                              color: _kBrand,
                              fontWeight: FontWeight.bold,
                              fontSize: 12))),
                  const SizedBox(width: 10),
                  Expanded(
                      child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Rp${_fK(c.nominal)}',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14)),
                      Text(
                          '${c.metodePembayaran == 'tunai' ? 'Tunai' : 'Non Tunai'} • ${_formatTanggalCicilan(c.createdAt)}',
                          style: const TextStyle(
                              fontSize: 12, color: Colors.black54)),
                    ],
                  )),
                ]),
              );
            }),

          const SizedBox(height: 8),
          if (!wide) ...[
            if (!isLunas)
              Column(
                children: [
                  SizedBox(
                      width: double.infinity,
                      child: OutlinedButton(
                          onPressed: _showBayarCicilanSheet,
                          style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: _kBrand),
                              foregroundColor: _kBrand,
                              minimumSize: const Size.fromHeight(48),
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero)),
                          child: const Text('Bayar Cicilan',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 15)))),
                  const SizedBox(height: 8),
                  SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                          onPressed: _kirimReminderWhatsApp,
                          icon: const Icon(Icons.chat_outlined, size: 18),
                          label: const Text('Kirim Reminder WhatsApp'),
                          style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Color(0xFF25D366)),
                              foregroundColor: const Color(0xFF128C4A),
                              minimumSize: const Size.fromHeight(48),
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero)))),
                ],
              )
            else
              Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                      color: _kGreen.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.zero),
                  alignment: Alignment.center,
                  child: const Text('✓ Piutang Lunas',
                      style: TextStyle(
                          color: _kGreen,
                          fontWeight: FontWeight.bold,
                          fontSize: 14))),
          ],
        ],
      ),
    );
  }

  // ── Payment progress bar ───────────────────────────────────────
  Widget _buildPaymentProgress(Transaction tx) {
    final progress = tx.grandTotal > 0
        ? (tx.amountPaid / tx.grandTotal).clamp(0.0, 1.0)
        : 0.0;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('Progres Pembayaran',
              style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
          Text('${(progress * 100).toStringAsFixed(0)}%',
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: progress >= 1 ? _kGreen : _kBrand)),
        ],
      ),
      const SizedBox(height: 6),
      ClipRRect(
          borderRadius: BorderRadius.zero,
          child: LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              backgroundColor: Colors.grey.shade100,
              valueColor: AlwaysStoppedAnimation<Color>(
                  progress >= 1 ? _kGreen : _kBrand))),
      const SizedBox(height: 4),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('Terbayar: Rp${_fK(tx.amountPaid)}',
              style: const TextStyle(fontSize: 11, color: Colors.black45)),
          Text('Total: Rp${_fK(tx.grandTotal)}',
              style: const TextStyle(fontSize: 11, color: Colors.black45)),
        ],
      ),
    ]);
  }

  // ── Bottom bar ─────────────────────────────────────────────────
  Widget _buildBottomBar(Transaction tx, bool isLunas) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
      decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Color(0xFFEEEEEE)))),
      child: SafeArea(
        child: Row(children: [
          SizedBox(
              height: 52,
              width: 52,
              child: OutlinedButton(
                  onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => StrukScreen(
                              transactionId: widget.transactionId))),
                  style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: _kBrand),
                      foregroundColor: _kBrand,
                      padding: EdgeInsets.zero,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero)),
                  child: const Icon(Icons.receipt_long_rounded, size: 24))),
          const SizedBox(width: 10),
          Expanded(
              child: SizedBox(
                  height: 52,
                  child: ElevatedButton(
                      onPressed: () {
                        if (!isLunas) {
                          _showBayarCicilanSheet();
                        } else {
                          Navigator.pop(context);
                        }
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: _kBrand,
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero)),
                      child: Text(
                          !isLunas
                              ? ((tx.paymentMethod == 'Pesanan' ||
                                      tx.paymentMethod == 'buat_pesanan')
                                  ? 'Selesaikan Pesanan'
                                  : 'Bayar Piutang')
                              : 'Tutup & Kembali',
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 15))))),
          const SizedBox(width: 10),
          SizedBox(
              height: 52,
              width: 52,
              child: OutlinedButton(
                  onPressed: () => _showMenuSheet(),
                  style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFFEEEEEE)),
                      foregroundColor: Colors.black54,
                      padding: EdgeInsets.zero,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero)),
                  child: const Icon(Icons.more_vert_rounded, size: 24))),
        ]),
      ),
    );
  }

  void _showMenuSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero)),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
                child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.zero))),
            const SizedBox(height: 16),
            ListTile(
                leading: const Icon(Icons.event_available_outlined,
                    color: Colors.black54),
                title: const Text('Ubah Jatuh Tempo'),
                onTap: () {
                  Navigator.pop(context);
                  _ubahJatuhTempo();
                }),
            if (_tx != null && _tx!.amountPaid < _tx!.grandTotal)
              ListTile(
                  leading:
                      const Icon(Icons.chat_outlined, color: Colors.black54),
                  title: const Text('Kirim Reminder WhatsApp'),
                  onTap: () {
                    Navigator.pop(context);
                    _kirimReminderWhatsApp();
                  }),
            ListTile(
                leading: const Icon(Icons.content_copy_rounded,
                    color: Colors.black54),
                title: const Text('Salin Nomor Transaksi'),
                onTap: () {
                  Navigator.pop(context);
                  if (_tx != null) {
                    final no = _formatNoTransaksi(_tx!);
                    Clipboard.setData(ClipboardData(text: no));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Nomor transaksi disalin'),
                        behavior: SnackBarBehavior.floating,
                        backgroundColor: Colors.black87,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero)));
                  }
                }),
          ],
        ),
      ),
    );
  }
}

// ── Widgets ──────────────────────────────────────────────────────
class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(color: Colors.black54, fontSize: 13)),
        const SizedBox(width: 16),
        Expanded(
          child: Text(value,
              textAlign: TextAlign.right,
              style:
                  const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
        ),
      ],
    );
  }
}

class _TotalRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? color;
  const _TotalRow({required this.label, required this.value, this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
                color: color ?? Colors.black87)),
        Text(value,
            style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
                color: color ?? Colors.black87)),
      ],
    );
  }
}

class _MetodeBayarBtn extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _MetodeBayarBtn(
      {required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
            color: selected ? _kBrand : Colors.white,
            border: Border.all(
                color: selected ? _kBrand : Colors.grey.shade300,
                width: selected ? 1.5 : 1.0),
            borderRadius: BorderRadius.zero),
        alignment: Alignment.center,
        child: Text(label,
            style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
                color: selected ? Colors.white : Colors.black87)),
      ),
    );
  }
}

class _IlustrasiKartu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Transform.rotate(
            angle: -0.15,
            child: Container(
                width: 120,
                height: 78,
                decoration: const BoxDecoration(
                    color: Color(0xFF37474F),
                    borderRadius: BorderRadius.zero))),
        Container(
          width: 120,
          height: 78,
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.zero,
              border: Border.all(color: Colors.grey.shade200),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 8,
                    offset: const Offset(0, 4))
              ]),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Dots sequence reduced to fit 120px container
              Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                      4,
                      (_) => Container(
                          margin: const EdgeInsets.symmetric(horizontal: 2),
                          child: Row(
                              children: List.generate(
                                  4,
                                  (_) => Container(
                                      width: 4,
                                      height: 4,
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 0.8),
                                      decoration: const BoxDecoration(
                                          color: _kBrand,
                                          shape: BoxShape.rectangle))))))),
              const SizedBox(height: 8),
              Container(
                  width: 80,
                  height: 6,
                  decoration: BoxDecoration(
                      color: Colors.grey.shade200,
                      borderRadius: BorderRadius.zero)),
            ],
          ),
        ),
      ],
    );
  }
}

