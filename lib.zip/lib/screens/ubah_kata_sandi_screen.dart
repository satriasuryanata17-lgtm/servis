import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme.dart';
import '../database/db_helper.dart';
import '../providers/providers.dart';
import '../services/auth_service.dart';
import 'responsive_layout.dart';

const Color _kBrand = AppColors.primaryBrand;

class UbahKataSandiScreen extends ConsumerStatefulWidget {
  const UbahKataSandiScreen({super.key});

  @override
  ConsumerState<UbahKataSandiScreen> createState() =>
      _UbahKataSandiScreenState();
}

class _UbahKataSandiScreenState extends ConsumerState<UbahKataSandiScreen> {
  final _formKey = GlobalKey<FormState>();
  final _oldCtrl = TextEditingController();
  final _newCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();

  bool _hideOld = true;
  bool _hideNew = true;
  bool _hideConfirm = true;
  bool _isSaving = false;

  late final Future<bool> _trialFuture = _checkIsTrial();

  Future<bool> _checkIsTrial() async {
    final license = await DBHelper.instance.getLicense();
    return (license?.isTrial ?? 0) == 1;
  }

  @override
  void dispose() {
    _oldCtrl.dispose();
    _newCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_isSaving) return;
    if (!_formKey.currentState!.validate()) return;

    final status = ref.read(authProvider);
    if (status == AuthStatus.unauthorized) {
      _showSnack('Sesi tidak valid. Silakan login ulang.');
      return;
    }

    setState(() => _isSaving = true);
    try {
      if (status == AuthStatus.admin) {
        await AuthService.changeAdminPassword(
          currentPassword: _oldCtrl.text,
          newPassword: _newCtrl.text,
        );
      } else {
        await AuthService.changeLicensePassword(
          currentPassword: _oldCtrl.text,
          newPassword: _newCtrl.text,
        );
      }
      if (!mounted) return;
      _showSnack(status == AuthStatus.admin
          ? 'Kata sandi admin berhasil diubah'
          : 'Kata sandi lisensi berhasil diubah');
      Navigator.pop(context);
    } on FormatException catch (e) {
      if (!mounted) return;
      _showSnack(e.message.toString());
    } on StateError catch (e) {
      if (!mounted) return;
      _showSnack(e.message.toString());
    } on AuthBackendRequiredException catch (e) {
      if (!mounted) return;
      _showSnack(e.toString());
    } catch (e) {
      if (!mounted) return;
      _showSnack('Gagal mengubah kata sandi. Silakan coba beberapa saat lagi.');
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ),
    );
  }

  bool _hasUppercase(String value) => RegExp(r'[A-Z]').hasMatch(value);
  bool _hasLowercase(String value) => RegExp(r'[a-z]').hasMatch(value);
  bool _hasDigit(String value) => RegExp(r'[0-9]').hasMatch(value);

  String? _validateNewPassword(String? value) {
    final text = (value ?? '').trim();
    if (text.isEmpty) return 'Wajib diisi';

    final isLicense = ref.read(authProvider) == AuthStatus.licensee;
    final minLen = isLicense ? 8 : 10;

    if (text.length < minLen) return 'Minimal $minLen karakter';

    if (!isLicense) {
      if (!_hasUppercase(text)) return 'Minimal 1 huruf besar';
      if (!_hasLowercase(text)) return 'Minimal 1 huruf kecil';
      if (!_hasDigit(text)) return 'Minimal 1 angka';
    }

    if (text == _oldCtrl.text.trim()) {
      return 'Kata sandi baru harus berbeda';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final status = ref.watch(authProvider);

    const sidePanel = Center(
      child: SizedBox(
        height: 260,
        width: 260,
        child: CustomPaint(painter: _LockIllustrationPainter()),
      ),
    );

    final formContent = Form(
      key: _formKey,
      child: SingleChildScrollView(
        padding: responsivePadding(context).copyWith(bottom: 24),
        child: FutureBuilder<bool>(
          future: _trialFuture,
          builder: (context, snapshot) {
            final isTrial = snapshot.data ?? false;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (status == AuthStatus.unauthorized) ...[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.dangerBg,
                      borderRadius: BorderRadius.zero,
                      border: Border.all(
                        color: AppColors.danger.withValues(alpha: 0.18),
                      ),
                    ),
                    child: const Text(
                      'Sesi login tidak ditemukan. Harap login terlebih dahulu.',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.danger,
                        height: 1.4,
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
                if (isTrial) ...[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.orange.shade50,
                      borderRadius: BorderRadius.zero,
                      border: Border.all(color: Colors.orange.shade200),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.block_rounded,
                            size: 18, color: Colors.orange.shade700),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Akun trial tidak dapat mengubah kata sandi.',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.orange.shade900,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.zero,
                    border: Border.all(color: Colors.blue.shade100),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline_rounded,
                          size: 18, color: Colors.blue.shade700),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Wajib terkoneksi internet untuk mengubah kata sandi.',
                          style: TextStyle(
                              fontSize: 12,
                              color: Colors.blue.shade900,
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                _fieldLabel('Kata Sandi Lama'),
                const SizedBox(height: 8),
                _passwordField(
                  controller: _oldCtrl,
                  hint: 'Masukkan Kata Sandi Lama',
                  obscureText: _hideOld,
                  enabled: !_isSaving && !isTrial,
                  onToggle: () => setState(() => _hideOld = !_hideOld),
                  validator: (value) {
                    if ((value ?? '').trim().isEmpty) return 'Wajib diisi';
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                _fieldLabel('Kata Sandi Baru'),
                const SizedBox(height: 8),
                _passwordField(
                  controller: _newCtrl,
                  hint: 'Masukkan Kata Sandi Baru',
                  obscureText: _hideNew,
                  enabled: !_isSaving && !isTrial,
                  onToggle: () => setState(() => _hideNew = !_hideNew),
                  validator: _validateNewPassword,
                ),
                const SizedBox(height: 16),
                _fieldLabel('Konfirmasi Kata Sandi Baru'),
                const SizedBox(height: 8),
                _passwordField(
                  controller: _confirmCtrl,
                  hint: 'Masukkan Konfirmasi Kata Sandi Baru',
                  obscureText: _hideConfirm,
                  enabled: !_isSaving && !isTrial,
                  onToggle: () => setState(() => _hideConfirm = !_hideConfirm),
                  validator: (value) {
                    if ((value ?? '').trim().isEmpty) return 'Wajib diisi';
                    if (value!.trim() != _newCtrl.text.trim()) {
                      return 'Kata sandi tidak cocok';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 18),
                Text(
                  'Gunakan minimal 10 karakter dengan kombinasi huruf besar, huruf kecil, dan angka.',
                  style: AppText.caption.copyWith(
                    color: Colors.black54,
                    fontSize: 12,
                  ),
                ),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                    onPressed: (!isTrial &&
                            status != AuthStatus.unauthorized &&
                            !_isSaving)
                        ? _save
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: _kBrand.withValues(alpha: 0.45),
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero,
                      ),
                    ),
                    child: _isSaving
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.2,
                              valueColor:
                                  AlwaysStoppedAnimation<Color>(Colors.white),
                            ),
                          )
                        : const Text(
                            'Simpan',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );

    final title = status == AuthStatus.admin
        ? 'Ubah Kata Sandi Admin'
        : 'Ubah Kata Sandi Lisensi';

    return KasirResponsiveScaffold(
      title: title,
      showNavRail: false,
      backgroundColor: Colors.white,
      body: ResponsiveFormLayout(
        sidePanel: sidePanel,
        formContent: formContent,
      ),
    );
  }

  Widget _fieldLabel(String label) {
    return RichText(
      text: TextSpan(
        text: label,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Colors.black87,
        ),
        children: const [
          TextSpan(
            text: ' *',
            style: TextStyle(color: AppColors.danger),
          ),
        ],
      ),
    );
  }

  Widget _passwordField({
    required TextEditingController controller,
    required String hint,
    required bool obscureText,
    required bool enabled,
    required VoidCallback onToggle,
    required String? Function(String?) validator,
  }) {
    return TextFormField(
      controller: controller,
      enabled: enabled,
      obscureText: obscureText,
      validator: validator,
      style: const TextStyle(fontSize: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(fontSize: 13, color: Colors.black38),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 14,
        ),
        suffixIcon: IconButton(
          onPressed: enabled ? onToggle : null,
          icon: Icon(
            obscureText
                ? Icons.visibility_off_outlined
                : Icons.visibility_outlined,
            color: Colors.black45,
            size: 20,
          ),
        ),
        enabledBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: Color(0xFFDDDDDD)),
        ),
        focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: _kBrand),
        ),
        errorBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: AppColors.danger),
        ),
        focusedErrorBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: AppColors.danger),
        ),
      ),
    );
  }
}

class _LockIllustrationPainter extends CustomPainter {
  const _LockIllustrationPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;
    final cx = size.width / 2;

    paint.color = const Color(0xFF2D2D4E);
    final phonePath = Path()
      ..addRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(cx, size.height * 0.45),
            width: 100,
            height: 160,
          ),
          const Radius.circular(0),
        ),
      );
    canvas.drawPath(phonePath, paint);

    paint.color = Colors.white;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(cx, size.height * 0.45),
          width: 84,
          height: 140,
        ),
        const Radius.circular(0),
      ),
      paint,
    );

    paint.color = const Color(0xFF2D2D4E);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(cx, size.height * 0.45 - 68),
          width: 30,
          height: 10,
        ),
        const Radius.circular(0),
      ),
      paint,
    );

    paint.color = const Color(0xFFFFD6C8);
    canvas.drawCircle(Offset(cx + 14, size.height * 0.45 - 50), 18, paint);

    paint.color = Colors.white;
    final bodyPath = Path()
      ..moveTo(cx - 4, size.height * 0.45 - 30)
      ..lineTo(cx + 32, size.height * 0.45 - 30)
      ..lineTo(cx + 40, size.height * 0.45 + 40)
      ..lineTo(cx - 12, size.height * 0.45 + 40)
      ..close();
    canvas.drawPath(bodyPath, paint);

    paint.color = const Color(0xFF2D2D4E);
    canvas.drawRect(
      Rect.fromLTWH(cx - 10, size.height * 0.45 + 38, 18, 40),
      paint,
    );
    canvas.drawRect(
      Rect.fromLTWH(cx + 12, size.height * 0.45 + 38, 18, 40),
      paint,
    );

    paint.color = Colors.black87;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(cx - 1, size.height * 0.45 + 82),
        width: 24,
        height: 10,
      ),
      paint,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(cx + 21, size.height * 0.45 + 82),
        width: 24,
        height: 10,
      ),
      paint,
    );

    paint.color = AppColors.danger;
    final lineY = size.height * 0.45 + 10.0;
    canvas.drawRect(Rect.fromLTWH(cx - 30, lineY, 60, 5), paint);
    canvas.drawRect(Rect.fromLTWH(cx - 30, lineY + 12, 44, 5), paint);
    paint.color = AppColors.danger.withValues(alpha: 0.4);
    canvas.drawRect(Rect.fromLTWH(cx - 30, lineY + 24, 50, 5), paint);

    _drawLock(canvas, Offset(cx - 68, size.height * 0.35));
    _drawLock(canvas, Offset(cx + 42, size.height * 0.28));
  }

  void _drawLock(Canvas canvas, Offset center) {
    final paint = Paint()..style = PaintingStyle.fill;

    paint.color = _kBrand;
    canvas.drawCircle(center, 22, paint);

    paint.color = Colors.white;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(center.dx, center.dy + 4),
          width: 20,
          height: 16,
        ),
        const Radius.circular(0),
      ),
      paint,
    );

    final shacklePaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    final shacklePath = Path()
      ..moveTo(center.dx - 6, center.dy - 2)
      ..lineTo(center.dx - 6, center.dy - 10)
      ..arcToPoint(
        Offset(center.dx + 6, center.dy - 10),
        radius: const Radius.circular(0),
        clockwise: false,
      )
      ..lineTo(center.dx + 6, center.dy - 2);
    canvas.drawPath(shacklePath, shacklePaint);

    paint
      ..color = _kBrand
      ..style = PaintingStyle.fill;
    canvas.drawCircle(Offset(center.dx, center.dy + 4), 3, paint);
    canvas.drawRect(
      Rect.fromLTWH(center.dx - 1.5, center.dy + 4, 3, 5),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

