import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/kasir_drawer.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';
import '../widgets/export_dropdown.dart';
import '../services/master_report_service.dart';
import 'package:intl/intl.dart';

const Color _kBrand = AppColors.primaryBrand;

class LaporanScreen extends ConsumerStatefulWidget {
  const LaporanScreen({super.key});

  @override
  ConsumerState<LaporanScreen> createState() => _LaporanScreenState();
}

class _LaporanScreenState extends ConsumerState<LaporanScreen> {
  bool _isExporting = false;

  @override
  Widget build(BuildContext context) {
    final tablet = isTabletDevice(context);
    final landscape = isLandscape(context);

    final items = _buildItems(context);

    return Stack(
      children: [
        KasirResponsiveScaffold(
          title: 'Laporan Servis',
          showNavRail: true,
          navIndex: 4,
          drawer: const KasirDrawer(),
          actions: [
            _buildExportButton(context),
          ],
          body: _LaporanContent(
            items: items,
            crossAxisCount: tablet ? (landscape ? 6 : 5) : (landscape ? 6 : 3),
            childAspectRatio:
                tablet ? (landscape ? 0.85 : 0.78) : (landscape ? 0.85 : 0.82),
            showHeader: false,
            showDrawer: false,
          ),
        ),
        if (_isExporting)
          Container(
            color: Colors.black26,
            child: const Center(
              child: CircularProgressIndicator(color: _kBrand),
            ),
          ),
      ],
    );
  }

  Widget _buildExportButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 16),
      child: GestureDetector(
        onTap: () => _handleExport(context),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: const BoxDecoration(
            color: AppColors.primaryBrand,
            borderRadius: BorderRadius.zero,
          ),
          child: const Row(
            children: [
              Icon(Icons.download_rounded, color: Colors.white, size: 15),
              SizedBox(width: 5),
              Text(
                'Ekspor',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleExport(BuildContext context) async {
    final choice = await ExportDropdown.show(context);
    if (choice == null) {
      return;
    }
    if (!mounted || !context.mounted) {
      return;
    }

    int year = DateTime.now().year;
    int month = DateTime.now().month;

    final result = await showModalBottomSheet<Map<String, int>>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (ctx) {
          int tempYear = year;
          int tempMonth = month;
          return StatefulBuilder(builder: (context, setS) {
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.zero),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      margin: const EdgeInsets.only(bottom: 20),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.zero,
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Pilih Periode Laporan',
                          style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87)),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          shape: BoxShape.rectangle,
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.close_rounded,
                              color: Colors.black54, size: 20),
                          onPressed: () => Navigator.pop(ctx),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Text('Tahun',
                      style: GoogleFonts.inter(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: Colors.black45,
                          letterSpacing: 0.5)),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 48,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: 5,
                      separatorBuilder: (_, __) => const SizedBox(width: 10),
                      itemBuilder: (context, i) {
                        final y = DateTime.now().year - i;
                        final isActive = tempYear == y;
                        return GestureDetector(
                          onTap: () => setS(() => tempYear = y),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 0),
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: isActive ? _kBrand : Colors.grey.shade50,
                              borderRadius: BorderRadius.zero,
                              border: Border.all(
                                  color: isActive
                                      ? _kBrand
                                      : Colors.grey.shade200),
                            ),
                            child: Text('$y',
                                style: GoogleFonts.inter(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: isActive
                                        ? Colors.white
                                        : Colors.black87)),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 28),
                  Text('Bulan',
                      style: GoogleFonts.inter(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: Colors.black45,
                          letterSpacing: 0.5)),
                  const SizedBox(height: 12),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      childAspectRatio: 2.2,
                    ),
                    itemCount: 12,
                    itemBuilder: (context, i) {
                      final m = i + 1;
                      final isActive = tempMonth == m;
                      return GestureDetector(
                        onTap: () => setS(() => tempMonth = m),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: isActive
                                ? _kBrand.withValues(alpha: 0.1)
                                : Colors.white,
                            borderRadius: BorderRadius.zero,
                            border: Border.all(
                                color:
                                    isActive ? _kBrand : Colors.grey.shade200,
                                width: isActive ? 1.5 : 1),
                          ),
                          child: Text(
                            DateFormat('MMM', 'id').format(DateTime(2024, m)),
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                fontWeight: isActive
                                    ? FontWeight.w800
                                    : FontWeight.w600,
                                color: isActive ? _kBrand : Colors.black87),
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 32),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      onPressed: () => Navigator.pop(
                          ctx, {'year': tempYear, 'month': tempMonth}),
                      child: Text('Lanjutkan Export',
                          style: GoogleFonts.poppins(
                              fontSize: 16, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            );
          });
        });

    if (result == null) {
      return;
    }
    if (!mounted || !context.mounted) {
      return;
    }
    final messenger = ScaffoldMessenger.of(context);

    setState(() => _isExporting = true);
    try {
      await MasterReportService.generateAndShare(
        year: result['year']!,
        month: result['month']!,
        isPrint: choice == 'print',
      );
    } catch (e) {
      if (!mounted) {
        return;
      }
      messenger.showSnackBar(
        const SnackBar(
            content: Text('Gagal mengekspor laporan. Silakan coba lagi.')),
      );
    } finally {
      if (mounted) {
        setState(() => _isExporting = false);
      }
    }
  }

  List<_LaporanItem> _buildItems(BuildContext context) => [
        _LaporanItem(
          icon: Icons.analytics_outlined,
          title: 'Analisis Keuntungan',
          route: '/laporan/laba_rugi',
        ),
        _LaporanItem(
          icon: Icons.receipt_long_outlined,
          title: 'Layanan Servis',
          route: '/laporan/transaksi_penjualan',
        ),
        _LaporanItem(
          icon: Icons.history_edu_outlined,
          title: 'Riwayat Stok',
          route: '/laporan/riwayat_stok',
        ),
        _LaporanItem(
          icon: Icons.trending_up_outlined,
          title: 'Omzet Bulanan',
          route: '/laporan/omzet_per_bulan',
        ),
        _LaporanItem(
          icon: Icons.account_balance_wallet_outlined,
          title: 'Arus Kas',
          route: '/laporan/arus_kas',
        ),
        _LaporanItem(
          icon: Icons.bar_chart_outlined,
          title: 'Laporan Keuangan',
          route: '/laporan/keuangan',
        ),
        _LaporanItem(
          icon: Icons.group_outlined,
          title: 'Transaksi Pelanggan',
          route: '/transaksi_pelanggan',
        ),
        _LaporanItem(
          icon: Icons.assignment_return_outlined,
          title: 'Komplain & Refund',
          route: '/retur',
        ),
        _LaporanItem(
          icon: Icons.timer_outlined,
          title: 'Masa Berlaku Item',
          route: '/laporan/masa_berlaku_produk',
        ),
        _LaporanItem(
          icon: Icons.leaderboard_outlined,
          title: 'Layanan Terlaris',
          route: '/laporan/produk_terlaris',
        ),
      ];
}

class _LaporanContent extends StatelessWidget {
  final List<_LaporanItem> items;
  final int crossAxisCount;
  final double childAspectRatio;
  final bool showHeader;
  final bool showDrawer;

  const _LaporanContent({
    required this.items,
    required this.crossAxisCount,
    required this.childAspectRatio,
    required this.showHeader,
    required this.showDrawer,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      drawer: showDrawer ? const KasirDrawer(selectedRoute: '/laporan') : null,
      appBar: !showHeader
          ? null
          : AppBar(
              backgroundColor: Colors.white,
              elevation: 0,
              iconTheme: const IconThemeData(color: Colors.black87),
              centerTitle: true,
              title: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: Text(
                      'Laporan',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                  ),
                  SizedBox(width: 26),
                ],
              ),
            ),
      body: SafeArea(
        child: Column(
          children: [
            if (showHeader) const Divider(height: 1),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: crossAxisCount,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: childAspectRatio,
                ),
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final item = items[index];
                  return _buildCard(context, item);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(BuildContext context, _LaporanItem item) {
    return InkWell(
      onTap: () => Navigator.pushNamed(context, item.route),
      borderRadius: BorderRadius.zero,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          border: Border.all(color: Colors.grey.shade200),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 48,
                height: 48,
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: _kBrand.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.zero,
                ),
                child: Icon(
                  item.icon,
                  color: _kBrand,
                  size: 24,
                ),
              ),
              SizedBox(
                height: 32, // Fixed height for 2 lines of text
                child: Center(
                  child: Text(
                    item.title,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.inter(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87,
                      height: 1.2,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LaporanItem {
  final IconData icon;
  final String title;
  final String route;

  _LaporanItem({
    required this.icon,
    required this.title,
    required this.route,
  });
}

