import 'dart:io' show Platform;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/app_runtime_config.dart';
import '../core/theme.dart';
import '../services/update_service.dart';
import '../widgets/kasir_drawer.dart';
import 'backup_restore_screen.dart';
import 'responsive_layout.dart';

class PengaturanUpdateScreen extends ConsumerStatefulWidget {
  const PengaturanUpdateScreen({super.key});

  @override
  ConsumerState<PengaturanUpdateScreen> createState() =>
      _PengaturanUpdateScreenState();
}

class _PengaturanUpdateScreenState
    extends ConsumerState<PengaturanUpdateScreen> {
  bool _checking = false;

  @override
  Widget build(BuildContext context) {
    final enabled = ref.watch(updateAutoCheckEnabledProvider);
    final update = ref.watch(updateProvider);

    return KasirResponsiveScaffold(
      title: 'Pembaruan Aplikasi',
      showNavRail: true,
      navIndex: 9,
      drawer: const KasirDrawer(),
      backgroundColor: AppColors.background,
      body: ListView(
        padding: EdgeInsets.fromLTRB(
          16,
          16,
          16,
          24 + MediaQuery.paddingOf(context).bottom,
        ),
        children: [
          const _UpdateHeader(
            title: 'Kontrol Pembaruan',
            subtitle:
                'Cek update dari server resmi tanpa menunggu Play Store. Cocok untuk perangkat kasir offline.',
          ),
          const SizedBox(height: 14),
          _SettingCard(
            child: enabled.when(
              data: (isEnabled) => _AutoUpdateToggle(
                enabled: isEnabled,
                onChanged: (value) async {
                  await ref
                      .read(updateAutoCheckEnabledProvider.notifier)
                      .setEnabled(value);
                  if (context.mounted) {
                    _showFlatSnack(
                      value
                          ? 'Pengecekan otomatis diaktifkan.'
                          : 'Pengecekan otomatis dimatikan.',
                    );
                  }
                },
              ),
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: 6),
                child: LinearProgressIndicator(minHeight: 2),
              ),
              error: (_, __) => _AutoUpdateToggle(
                enabled: true,
                onChanged: (value) => ref
                    .read(updateAutoCheckEnabledProvider.notifier)
                    .setEnabled(value),
              ),
            ),
          ),
          const SizedBox(height: 12),
          _SettingCard(
            child: Column(
              children: [
                _InfoRow(
                  label: 'Versi aplikasi',
                  value:
                      '${AppRuntimeConfig.appVersion} build ${AppRuntimeConfig.appBuildNumber}',
                ),
                const Divider(height: 24, color: Color(0xFFE5E7EB)),
                _InfoRow(
                  label: 'Sumber update',
                  value: _sourceLabel(),
                ),
                const Divider(height: 24, color: Color(0xFFE5E7EB)),
                _InfoRow(
                  label: 'Status terakhir',
                  value: _checking
                      ? 'Sedang mengecek update'
                      : _statusLabel(update),
                  valueColor:
                      _checking ? AppColors.primaryBrand : _statusColor(update),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          const _SettingCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Backup sebelum update',
                  style: TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF111827),
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  'Update dikunci sampai ada backup data terbaru. Ini penting jika update membawa perubahan struktur database.',
                  style: TextStyle(
                    fontSize: 12.5,
                    height: 1.45,
                    color: Color(0xFF667085),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 52,
            child: ElevatedButton.icon(
              onPressed: _checking ? null : _checkUpdateNow,
              icon: _checking
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.system_update_alt_rounded, size: 18),
              label: Text(
                _checking ? 'Mengecek update...' : 'Cek Update Sekarang',
              ),
              style: ElevatedButton.styleFrom(
                elevation: 0,
                backgroundColor: AppColors.primaryBrand,
                foregroundColor: Colors.white,
                disabledBackgroundColor: const Color(0xFFE5E7EB),
                disabledForegroundColor: const Color(0xFF98A2B3),
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
                textStyle: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _checkUpdateNow() async {
    FocusScope.of(context).unfocus();
    setState(() => _checking = true);
    _showFlatSnack('Sedang mengecek pembaruan...');

    try {
      await ref.read(updateProvider.notifier).checkForUpdate(force: true);
    } finally {
      if (mounted) setState(() => _checking = false);
    }

    if (!mounted) return;
    await _showCheckResult(ref.read(updateProvider));
  }

  Future<void> _showCheckResult(UpdateState update) async {
    switch (update.status) {
      case UpdateStatus.available:
      case UpdateStatus.required:
        final proceed = await _showResultDialog(
          title: update.status == UpdateStatus.required
              ? 'Update wajib tersedia'
              : 'Update tersedia',
          message: _availableMessage(update),
          icon: update.status == UpdateStatus.required
              ? Icons.priority_high_rounded
              : Icons.system_update_alt_rounded,
          color: update.status == UpdateStatus.required
              ? AppColors.danger
              : AppColors.primaryBrand,
          primaryLabel: 'Update Sekarang',
          secondaryLabel: 'Nanti',
        );
        if (!mounted || proceed != true) return;
        if (update.status == UpdateStatus.required) {
          await ref.read(updateProvider.notifier).performImmediateUpdate();
        } else {
          await ref.read(updateProvider.notifier).startFlexibleUpdate();
        }
        if (mounted) await _showCheckResult(ref.read(updateProvider));
        return;
      case UpdateStatus.backupRequired:
        final openBackup = await _showResultDialog(
          title: 'Backup diperlukan',
          message:
              'Buat backup data terbaru dulu agar data tetap aman sebelum update dipasang.',
          icon: Icons.backup_rounded,
          color: const Color(0xFFB45309),
          primaryLabel: 'Buka Backup',
          secondaryLabel: 'Nanti',
        );
        if (!mounted || openBackup != true) return;
        await Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const BackupRestoreScreen()),
        );
        if (mounted) {
          await ref.read(updateProvider.notifier).checkForUpdate(force: true);
        }
        return;
      case UpdateStatus.readyToInstall:
        final install = await _showResultDialog(
          title: 'Update siap dipasang',
          message: Platform.isWindows
              ? 'File update sudah siap. Aplikasi akan ditutup saat pemasangan dimulai.'
              : 'File update sudah siap. Ikuti konfirmasi sistem untuk memasang pembaruan.',
          icon: Icons.install_desktop_rounded,
          color: AppColors.primaryBrand,
          primaryLabel: 'Pasang Sekarang',
          secondaryLabel: 'Nanti',
        );
        if (!mounted || install != true) return;
        await ref.read(updateProvider.notifier).completeUpdate();
        return;
      case UpdateStatus.downloading:
        _showFlatSnack('Update sedang diunduh. Mohon tunggu...');
        return;
      case UpdateStatus.notAvailable:
        if ((update.errorMessage ?? '').trim().isNotEmpty) {
          await _showResultDialog(
            title: 'Cek update gagal',
            message:
                '${update.errorMessage!.trim()}\n\nPerangkat tidak dianggap sudah terbaru sampai server update berhasil dicek.',
            icon: Icons.wifi_off_rounded,
            color: AppColors.danger,
            primaryLabel: 'Mengerti',
          );
          return;
        }
        await _showResultDialog(
          title: 'Aplikasi sudah terbaru',
          message:
              'Perangkat ini sudah memakai versi terbaru yang tersedia dari sumber update resmi.',
          icon: Icons.verified_rounded,
          color: AppColors.primaryBrand,
          primaryLabel: 'Mengerti',
        );
        return;
      case UpdateStatus.idle:
        await _showResultDialog(
          title: 'Pemeriksaan belum tersedia',
          message:
              'Fitur cek update berjalan pada aplikasi rilis Android atau Windows. Mode debug tidak mengecek update otomatis.',
          icon: Icons.info_outline_rounded,
          color: const Color(0xFF475467),
          primaryLabel: 'Mengerti',
        );
        return;
    }
  }

  String _availableMessage(UpdateState update) {
    final version = update.latestVersion?.trim();
    final build = update.latestBuildNumber;
    final lines = [
      if (version != null && version.isNotEmpty)
        'Versi terbaru: $version${build == null ? '' : ' build $build'}',
      if ((update.releaseNotes ?? '').trim().isNotEmpty)
        'Catatan: ${update.releaseNotes!.trim()}',
      if ((update.errorMessage ?? '').trim().isNotEmpty)
        'Info: ${update.errorMessage!.trim()}',
      if (update.sizeBytes != null && update.sizeBytes! > 0)
        'Ukuran file: ${_formatBytes(update.sizeBytes!)}',
      'Backup data tetap dicek sebelum proses update dimulai.',
    ];
    return lines.join('\n');
  }

  String _formatBytes(int bytes) {
    if (bytes >= 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '$bytes B';
  }

  Future<bool?> _showResultDialog({
    required String title,
    required String message,
    required IconData icon,
    required Color color,
    required String primaryLabel,
    String? secondaryLabel,
  }) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.white,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    alignment: Alignment.center,
                    color: color.withValues(alpha: 0.10),
                    child: Icon(icon, color: color, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF111827),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          message,
                          style: const TextStyle(
                            fontSize: 12.5,
                            height: 1.45,
                            color: Color(0xFF667085),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  if (secondaryLabel != null) ...[
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.of(ctx).pop(false),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: const Color(0xFF475467),
                          side: const BorderSide(color: Color(0xFFD0D5DD)),
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero,
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 13),
                        ),
                        child: Text(secondaryLabel),
                      ),
                    ),
                    const SizedBox(width: 10),
                  ],
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(ctx).pop(true),
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: color,
                        foregroundColor: Colors.white,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero,
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                      ),
                      child: Text(
                        primaryLabel,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _sourceLabel() {
    if (Platform.isAndroid) {
      return AppRuntimeConfig.useAndroidR2Updates
          ? 'Server resmi Juragan Servis'
          : 'Google Play';
    }
    if (Platform.isWindows) return 'Server resmi Juragan Servis';
    return 'Tidak tersedia di perangkat ini';
  }

  String _statusLabel(UpdateState update) {
    if ((update.errorMessage ?? '').trim().isNotEmpty &&
        update.status == UpdateStatus.notAvailable) {
      return 'Gagal cek update';
    }
    switch (update.status) {
      case UpdateStatus.available:
        return 'Update tersedia';
      case UpdateStatus.downloading:
        return 'Mengunduh update';
      case UpdateStatus.readyToInstall:
        return 'Siap dipasang';
      case UpdateStatus.required:
        return 'Update wajib tersedia';
      case UpdateStatus.backupRequired:
        return 'Menunggu backup data';
      case UpdateStatus.notAvailable:
        return 'Sudah terbaru';
      case UpdateStatus.idle:
        return 'Belum dicek';
    }
  }

  Color _statusColor(UpdateState update) {
    if ((update.errorMessage ?? '').trim().isNotEmpty &&
        update.status == UpdateStatus.notAvailable) {
      return AppColors.danger;
    }
    switch (update.status) {
      case UpdateStatus.available:
      case UpdateStatus.readyToInstall:
        return AppColors.primaryBrand;
      case UpdateStatus.required:
        return AppColors.danger;
      case UpdateStatus.backupRequired:
        return const Color(0xFFB45309);
      default:
        return const Color(0xFF475467);
    }
  }

  void _showFlatSnack(String message) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xEE111827),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ),
    );
  }
}

class _UpdateHeader extends StatelessWidget {
  final String title;
  final String subtitle;

  const _UpdateHeader({
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.primaryBrand,
        border: Border.all(color: AppColors.primaryBrand),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            color: Colors.white.withValues(alpha: 0.14),
            child: const Icon(
              Icons.system_update_alt_rounded,
              color: Colors.white,
              size: 22,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12.5,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingCard extends StatelessWidget {
  final Widget child;

  const _SettingCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE4E7EC)),
        borderRadius: BorderRadius.zero,
      ),
      child: child,
    );
  }
}

class _AutoUpdateToggle extends StatelessWidget {
  final bool enabled;
  final ValueChanged<bool> onChanged;

  const _AutoUpdateToggle({
    required this.enabled,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 38,
          height: 38,
          alignment: Alignment.center,
          color: AppColors.primaryBrand.withValues(alpha: 0.08),
          child: const Icon(
            Icons.notifications_active_outlined,
            color: AppColors.primaryBrand,
            size: 20,
          ),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Cek update saat aplikasi dibuka',
                style: TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF111827),
                ),
              ),
              SizedBox(height: 3),
              Text(
                'Matikan jika perangkat ini hanya ingin update lewat tombol cek manual.',
                style: TextStyle(
                  fontSize: 12,
                  height: 1.35,
                  color: Color(0xFF667085),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Switch(
          value: enabled,
          onChanged: onChanged,
          activeThumbColor: AppColors.primaryBrand,
        ),
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;

  const _InfoRow({
    required this.label,
    required this.value,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 12.5,
              color: Color(0xFF667085),
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontSize: 12.8,
              color: valueColor ?? const Color(0xFF111827),
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ],
    );
  }
}

