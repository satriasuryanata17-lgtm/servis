import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:io' show Platform;
import '../core/theme.dart';
import '../providers/providers.dart';
import '../utils/staff_access.dart';
import 'main_shell.dart';

//
//  KASIR RESPONSIVE LAYOUT TOOLKIT
//  - Mirrors the dashboard's NavigationRail & split-panel patterns
//  - Usage: wrap any Scaffold body with KasirResponsiveScaffold
//

const Color _kTealDeep = AppColors.primaryDark;
const String _kResponsiveAccessDeniedMessage =
    'Akses Dibatasi: Admin/Owner dapat mengubah izin di menu Karyawan.';

void _showResponsiveAccessDenied(BuildContext context) {
  ScaffoldMessenger.of(context)
    ..clearSnackBars()
    ..showSnackBar(
      const SnackBar(
        content: Text(_kResponsiveAccessDeniedMessage),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
        duration: Duration(milliseconds: 1500),
      ),
    );
}

//
// RESPONSIVE BREAKPOINTS
//
class KasirLayout {
  static bool isTablet(BuildContext context) =>
      MediaQuery.of(context).size.shortestSide >= 600;

  static bool isLandscape(BuildContext context) =>
      MediaQuery.of(context).orientation == Orientation.landscape;

  static bool isWide(BuildContext context) =>
      MediaQuery.of(context).size.width >= 800;

  static bool isMobile(BuildContext context) =>
      !isTablet(context) && (Platform.isAndroid || Platform.isIOS);

  /// Returns grid column count for product/menu grids
  static int gridColumns(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    if (w >= 1400) return 6;
    if (w >= 1150) return 5;
    if (w >= 900) return 4;
    if (w >= 600) return 3;
    if (isLandscape(context)) return 4;
    return 3;
  }
}

//
// KASIR RESPONSIVE SCAFFOLD
//
// Drop-in replacement for Scaffold that automatically adds:
//    NavigationRail sidebar on tablet (600 shortest side)
//    Wider content area, proper padding
//    Consistent AppBar style matching dashboard
//
//
// TOP-LEVEL RESPONSIVE HELPERS
// These free functions are used across many screens.
//

/// Returns true on tablet (shortestSide >= 600)
bool isTabletDevice(BuildContext context) => KasirLayout.isTablet(context);

/// Returns true when orientation is landscape
bool isLandscape(BuildContext context) => KasirLayout.isLandscape(context);

/// Standard responsive padding  more on tablet/landscape
EdgeInsets responsivePadding(BuildContext context) {
  if (KasirLayout.isTablet(context)) {
    return const EdgeInsets.symmetric(horizontal: 32, vertical: 20);
  }
  if (KasirLayout.isLandscape(context)) {
    return const EdgeInsets.symmetric(horizontal: 24, vertical: 16);
  }
  return const EdgeInsets.symmetric(horizontal: 16, vertical: 16);
}

/// Grid column count for stat/summary grids
int responsiveGridCount(BuildContext context) {
  final w = MediaQuery.of(context).size.width;
  if (w >= 900) return 4;
  if (w >= 600) return 3;
  if (KasirLayout.isLandscape(context)) return 3;
  return 2;
}

//
// RESPONSIVE REPORT LAYOUT
// Left: filter panel (fixed width on wide screens)
// Right: main content (expanded)
// On narrow screens both panels stack vertically.
//
class ResponsiveReportLayout extends StatelessWidget {
  final Widget filterPanel;
  final Widget content;
  final double filterWidth;

  const ResponsiveReportLayout({
    super.key,
    required this.filterPanel,
    required this.content,
    this.filterWidth = 260,
  });

  @override
  Widget build(BuildContext context) {
    final isTablet = KasirLayout.isTablet(context);
    final isLandscape = KasirLayout.isLandscape(context);
    final wide = isTablet && isLandscape;
    final phoneLandscape = !isTablet && isLandscape;

    if (wide || phoneLandscape) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: phoneLandscape ? 220 : filterWidth,
            child: SingleChildScrollView(child: filterPanel),
          ),
          Container(width: 1, color: const Color(0xFFE2E8F0)),
          Expanded(child: content),
        ],
      );
    }
    return Column(
      children: [
        filterPanel,
        const Divider(height: 1, color: Color(0xFFE2E8F0)),
        Expanded(child: content),
      ],
    );
  }
}

//
// RESPONSIVE FORM LAYOUT
// On wide screens: left side panel + right form content
// On narrow screens: stacked vertically
//
class ResponsiveFormLayout extends StatelessWidget {
  final Widget sidePanel;
  final Widget formContent;
  final double sidePanelWidth;

  const ResponsiveFormLayout({
    super.key,
    required this.sidePanel,
    required this.formContent,
    this.sidePanelWidth = 280,
  });

  @override
  Widget build(BuildContext context) {
    final isTablet = KasirLayout.isTablet(context);
    final isLandscape = KasirLayout.isLandscape(context);
    final wide = isTablet && isLandscape;

    // On phone landscape, we also want a side-by-side look if possible,
    // but maybe with a smaller side panel.
    final phoneLandscape = !isTablet && isLandscape;

    if (wide || phoneLandscape) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: phoneLandscape ? 200 : sidePanelWidth,
            color: const Color(0xFFF8FAFC),
            child: SingleChildScrollView(child: sidePanel),
          ),
          Container(width: 1, color: const Color(0xFFE2E8F0)),
          Expanded(child: formContent),
        ],
      );
    }
    return SingleChildScrollView(
      child: Column(
        children: [sidePanel, formContent],
      ),
    );
  }
}

class KasirResponsiveScaffold extends ConsumerWidget {
  final String title;
  final Widget body;
  final List<Widget>? actions;
  final Widget? floatingActionButton;
  final FloatingActionButtonLocation? fabLocation;
  final int navIndex;
  // Alias accepted by some screens
  final int? selectedNavIndex;
  // Ignored  nav rail is always shown on tablet; kept for API compat
  final bool showNavRail;
  final Color backgroundColor;
  final PreferredSizeWidget? bottom; // for TabBar
  final Widget? leading;
  final Widget? drawer;
  final Widget? bottomNavigationBar;
  final bool showAppBar;
  final Widget? titleWidget;

  const KasirResponsiveScaffold({
    super.key,
    required this.title,
    required this.body,
    this.actions,
    this.floatingActionButton,
    this.fabLocation,
    this.navIndex = 0,
    this.selectedNavIndex,
    this.showNavRail = true,
    this.backgroundColor = const Color(0xFFF5F7FA),
    this.bottom,
    this.leading,
    this.drawer,
    this.bottomNavigationBar,
    this.showAppBar = true,
    this.titleWidget,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isTablet = KasirLayout.isTablet(context);
    final isLandscape = KasirLayout.isLandscape(context);
    final effectiveNavIndex = selectedNavIndex ?? navIndex;
    // If inside MainShell, the shell provides the nav rail  never show ours
    final inShell = ShellScope.of(context) != null;
    final effectiveShowNavRail = inShell ? false : showNavRail;

    if (isTablet) {
      final canPop = Navigator.canPop(context);

      return Scaffold(
        backgroundColor: backgroundColor,
        floatingActionButton: floatingActionButton,
        floatingActionButtonLocation: fabLocation,
        bottomNavigationBar: bottomNavigationBar,
        body: SafeArea(
          top: true,
          bottom: false,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              //  Navigation Rail
              if (effectiveShowNavRail) ...[
                KasirNavigationRail(currentIndex: effectiveNavIndex),
                // Divider removed for seamless look
              ],
              //  Main Content Area
              Expanded(
                child: Column(
                  children: [
                    if (showAppBar)
                      _TabletTopBar(
                        title: title,
                        actions: actions,
                        bottom: bottom,
                        leading: leading ??
                            (canPop && !inShell
                                ? IconButton(
                                    icon: const Icon(
                                        Icons.arrow_back_ios_new_rounded,
                                        size: 20,
                                        color: Color(0xFF1E293B)),
                                    onPressed: () => Navigator.pop(context),
                                  )
                                : null),
                      ),
                    Expanded(child: body),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    }

    // Phone layout
    return Scaffold(
      backgroundColor: backgroundColor,
      floatingActionButton: floatingActionButton,
      floatingActionButtonLocation: fabLocation,
      appBar: showAppBar
          ? AppBar(
              leading: leading ??
                  (inShell && (!isTablet && !isLandscape)
                      ? Builder(builder: (context) {
                          final shell = ShellScope.of(context);
                          // Primary tabs: Dashboard, Kasir, Produk, Pesanan, Riwayat, Laporan, Pengaturan, Status
                          final isPrimaryTab = shell == null ||
                              [0, 1, 2, 3, 4, 5, 9, 10]
                                  .contains(shell.currentIndex);

                          if (isPrimaryTab) {
                            return IconButton(
                              icon: const Icon(Icons.menu),
                              tooltip: MaterialLocalizations.of(context)
                                  .openAppDrawerTooltip,
                              onPressed: () => shell?.openDrawer?.call(),
                            );
                          } else {
                            return IconButton(
                              icon: const Icon(Icons.arrow_back_ios_new_rounded,
                                  size: 20),
                              onPressed: () => shell.onNavigate(
                                  shell.homeIndex), // Back to safe home
                            );
                          }
                        })
                      : null),
              toolbarHeight: (!isTablet && isLandscape) ? 44 : 56,
              title: titleWidget ??
                  Text(
                    title,
                    style: TextStyle(
                        fontSize: (!isTablet && isLandscape) ? 16 : 18,
                        fontWeight: FontWeight.w600),
                  ),
              titleSpacing: titleWidget == null ? null : 0,
              backgroundColor: Colors.white,
              surfaceTintColor: Colors.transparent,
              elevation: 0,
              actions: actions,
              bottom: bottom,
            )
          : null,
      drawer: inShell ? null : drawer,
      bottomNavigationBar: bottomNavigationBar,
      body: body,
    );
  }
}

//
// NAVIGATION RAIL  exact mirror of dashboard's rail
//
class KasirNavigationRail extends ConsumerWidget {
  final int currentIndex;

  const KasirNavigationRail({super.key, required this.currentIndex});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeStaff = ref.watch(activeStaffProvider);

    VoidCallback guarded(String permission, VoidCallback action) {
      return StaffAccess.can(activeStaff, permission)
          ? action
          : () => _showResponsiveAccessDenied(context);
    }

    return Container(
      width: 80,
      color: _kTealDeep,
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            const SizedBox(height: 12),
            const Divider(
                height: 1, color: Colors.white12, indent: 16, endIndent: 16),
            const SizedBox(height: 8),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  children: [
                    _KasirRailItem(
                      icon: Icons.dashboard_outlined,
                      selectedIcon: Icons.dashboard_rounded,
                      label: 'Dashboard',
                      isSelected: currentIndex == 0,
                      locked: !StaffAccess.can(
                          activeStaff, StaffPermissionKey.dashboard),
                      onTap: guarded(
                        StaffPermissionKey.dashboard,
                        () => Navigator.pushNamedAndRemoveUntil(
                            context, '/dashboard', (_) => false),
                      ),
                    ),
                    _KasirRailItem(
                      icon: Icons.point_of_sale_outlined,
                      selectedIcon: Icons.point_of_sale_rounded,
                      label: 'Kasir',
                      isSelected: currentIndex == 1,
                      locked: !StaffAccess.can(
                          activeStaff, StaffPermissionKey.order),
                      onTap: guarded(
                        StaffPermissionKey.order,
                        () => Navigator.pushNamed(context, '/transaksi'),
                      ),
                    ),
                    _KasirRailItem(
                      icon: Icons.dry_cleaning_outlined,
                      selectedIcon: Icons.dry_cleaning_rounded,
                      label: 'Produk',
                      isSelected: currentIndex == 2,
                      locked: !StaffAccess.can(
                          activeStaff, StaffPermissionKey.products),
                      onTap: guarded(
                        StaffPermissionKey.products,
                        () => Navigator.pushNamed(context, '/produk'),
                      ),
                    ),
                    _KasirRailItem(
                      icon: Icons.list_alt_outlined,
                      selectedIcon: Icons.list_alt_rounded,
                      label: 'Pesanan',
                      isSelected: currentIndex == 3,
                      locked: !StaffAccess.can(
                          activeStaff, StaffPermissionKey.order),
                      onTap: guarded(
                        StaffPermissionKey.order,
                        () => Navigator.pushNamed(context, '/pesanan'),
                      ),
                    ),
                    _KasirRailItem(
                      icon: Icons.handyman_outlined,
                      selectedIcon: Icons.handyman_rounded,
                      label: 'Status',
                      isSelected: currentIndex == 10,
                      locked: !StaffAccess.can(
                          activeStaff, StaffPermissionKey.servisStatus),
                      onTap: guarded(
                        StaffPermissionKey.servisStatus,
                        () => Navigator.pushNamed(context, '/servis_ops'),
                      ),
                    ),
                    _KasirRailItem(
                      icon: Icons.insert_chart_outlined,
                      selectedIcon: Icons.insert_chart_rounded,
                      label: 'Laporan',
                      isSelected: currentIndex == 4,
                      locked: !StaffAccess.can(
                          activeStaff, StaffPermissionKey.reports),
                      onTap: guarded(
                        StaffPermissionKey.reports,
                        () => Navigator.pushNamed(context, '/laporan'),
                      ),
                    ),
                    _KasirRailItem(
                      icon: Icons.people_outline_rounded,
                      selectedIcon: Icons.people_rounded,
                      label: 'Pelanggan',
                      isSelected: currentIndex == 5,
                      locked: !StaffAccess.can(
                          activeStaff, StaffPermissionKey.customers),
                      onTap: guarded(
                        StaffPermissionKey.customers,
                        () => Navigator.pushNamed(context, '/pelanggan'),
                      ),
                    ),
                    _KasirRailItem(
                      icon: Icons.badge_outlined,
                      selectedIcon: Icons.badge_rounded,
                      label: 'Karyawan',
                      isSelected: currentIndex == 6,
                      locked: !StaffAccess.can(
                          activeStaff, StaffPermissionKey.employees),
                      onTap: guarded(
                        StaffPermissionKey.employees,
                        () => Navigator.pushNamed(context, '/karyawan'),
                      ),
                    ),
                    _KasirRailItem(
                      icon: Icons.notifications_outlined,
                      selectedIcon: Icons.notifications_rounded,
                      label: 'Notifikasi',
                      isSelected: currentIndex == 8,
                      locked: !StaffAccess.can(
                          activeStaff, StaffPermissionKey.notifications),
                      onTap: () {
                        guarded(
                          StaffPermissionKey.notifications,
                          () {
                            final shell = ShellScope.of(context);
                            if (shell != null) {
                              shell.onNavigate(8);
                            } else {
                              Navigator.pushNamed(context, '/notifikasi');
                            }
                          },
                        )();
                      },
                    ),
                    _KasirRailItem(
                      icon: Icons.sync_rounded,
                      selectedIcon: Icons.sync_rounded,
                      label: 'Sinkron',
                      isSelected: currentIndex == 11,
                      locked: !StaffAccess.can(
                          activeStaff, StaffPermissionKey.sync),
                      onTap: () {
                        guarded(
                          StaffPermissionKey.sync,
                          () {
                            final shell = ShellScope.of(context);
                            if (shell != null) {
                              shell.onNavigate(11);
                            } else {
                              Navigator.pushNamed(context, '/juragan_sync');
                            }
                          },
                        )();
                      },
                    ),
                    _KasirRailItem(
                      icon: Icons.settings_outlined,
                      selectedIcon: Icons.settings_rounded,
                      label: 'Pengaturan',
                      isSelected: currentIndex == 9,
                      locked: !StaffAccess.can(
                          activeStaff, StaffPermissionKey.settings),
                      onTap: () {
                        guarded(
                          StaffPermissionKey.settings,
                          () {
                            final shell = ShellScope.of(context);
                            if (shell != null) {
                              shell.onNavigate(9);
                            } else {
                              Navigator.pushNamed(context, '/setting');
                            }
                          },
                        )();
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}

//
// TABLET TOP BAR  clean header for content area
//
class _TabletTopBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;
  final PreferredSizeWidget? bottom;
  final Widget? leading;

  const _TabletTopBar({
    required this.title,
    this.actions,
    this.bottom,
    this.leading,
  });

  @override
  Size get preferredSize {
    return Size.fromHeight(bottom == null ? 60 : 112);
  }

  @override
  Widget build(BuildContext context) {
    final isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;
    final isShort = MediaQuery.of(context).size.height < 500;
    final h = (isLandscape && isShort) ? 46.0 : 60.0;

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Color(0xFFEEEEEE))),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            height: h,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  if (leading != null) ...[
                    leading!,
                    const SizedBox(width: 8),
                  ],
                  Text(
                    title,
                    style: GoogleFonts.poppins(
                      fontSize: (isLandscape && isShort) ? 17 : 20,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF1E293B),
                    ),
                  ),
                  const Spacer(),
                  if (actions != null) ...actions!,
                ],
              ),
            ),
          ),
          if (bottom != null) bottom!,
        ],
      ),
    );
  }
}

//
// LANDSCAPE SPLIT LAYOUT
// Utility widget: fixed-width left panel + expanded right
//
class KasirLandscapeSplit extends StatelessWidget {
  final Widget leftPanel;
  final Widget rightPanel;
  final double leftWidth;
  final Color leftBackground;

  const KasirLandscapeSplit({
    super.key,
    required this.leftPanel,
    required this.rightPanel,
    this.leftWidth = 240,
    this.leftBackground = const Color(0xFFF8FAFC),
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: leftWidth,
          color: leftBackground,
          child: leftPanel,
        ),
        Container(width: 1, color: const Color(0xFFE2E8F0)),
        Expanded(child: rightPanel),
      ],
    );
  }
}

//
// STAT CARD  reusable summary stat for tablet headers
//
class KasirStatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color? color;
  final VoidCallback? onTap;

  const KasirStatCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.primaryBrand;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          border: Border.all(color: const Color(0xFFE2E8F0)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: c.withValues(alpha: 0.10),
                borderRadius: BorderRadius.zero,
              ),
              child: Icon(icon, color: c, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          fontSize: 11,
                          color: Color(0xFF64748B),
                          fontWeight: FontWeight.w500)),
                  const SizedBox(height: 3),
                  Text(value,
                      style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFF1E293B))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//
// PERIOD SELECTOR BAR  shared across report screens
//
class KasirPeriodBar extends StatelessWidget {
  final String periode;
  final int tahun;
  final int bulan;
  final DateTime hariTerpilih;
  final DateTime? customStart;
  final DateTime? customEnd;
  final VoidCallback onPeriodeTap;
  final VoidCallback onTahunTap;
  final VoidCallback onBulanTap;
  final VoidCallback onHariTap;

  static const _bulanNama = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'Mei',
    'Jun',
    'Jul',
    'Agt',
    'Sep',
    'Okt',
    'Nov',
    'Des'
  ];

  const KasirPeriodBar({
    super.key,
    required this.periode,
    required this.tahun,
    required this.bulan,
    required this.hariTerpilih,
    this.customStart,
    this.customEnd,
    required this.onPeriodeTap,
    required this.onTahunTap,
    required this.onBulanTap,
    required this.onHariTap,
  });

  String get _subtitle {
    if (periode == 'Kustom Tanggal' &&
        customStart != null &&
        customEnd != null) {
      return '${customStart!.day}/${customStart!.month}  ${customEnd!.day}/${customEnd!.month}';
    }
    return periode;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(children: [
        Expanded(
          flex: 3,
          child: _PeriodChip(label: _subtitle, onTap: onPeriodeTap),
        ),
        if (periode != 'Kustom Tanggal') const SizedBox(width: 8),
        if (periode == 'Periode Bulanan') ...[
          Expanded(
              flex: 2,
              child:
                  _PeriodChip(label: _bulanNama[bulan - 1], onTap: onBulanTap)),
          const SizedBox(width: 6),
          Expanded(
              flex: 2,
              child: _PeriodChip(label: tahun.toString(), onTap: onTahunTap)),
        ] else if (periode == 'Periode Harian')
          Expanded(
            flex: 2,
            child: _PeriodChip(
              label:
                  '${hariTerpilih.day} ${_bulanNama[hariTerpilih.month - 1]}',
              onTap: onHariTap,
            ),
          )
        else if (periode == 'Periode Tahunan')
          Expanded(
              flex: 2,
              child: _PeriodChip(label: tahun.toString(), onTap: onTahunTap)),
      ]),
    );
  }
}

class _PeriodChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _PeriodChip({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
        decoration: const BoxDecoration(
          color: Color(0xFFF5F5F5),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 13)),
            ),
            const Icon(Icons.keyboard_arrow_down_rounded,
                color: AppColors.primaryBrand, size: 20),
          ],
        ),
      ),
    );
  }
}

class _KasirRailItem extends StatefulWidget {
  final IconData icon;
  final IconData selectedIcon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final bool locked;

  const _KasirRailItem({
    required this.icon,
    required this.selectedIcon,
    required this.label,
    required this.isSelected,
    required this.onTap,
    this.locked = false,
  });

  @override
  State<_KasirRailItem> createState() => _KasirRailItemState();
}

class _KasirRailItemState extends State<_KasirRailItem> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: double.infinity,
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: widget.isSelected
                ? Colors.white.withValues(alpha: 0.15)
                : (_isHovered
                    ? Colors.white.withValues(alpha: 0.08)
                    : Colors.transparent),
            borderRadius: BorderRadius.zero,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Icon(
                    widget.isSelected ? widget.selectedIcon : widget.icon,
                    color: widget.locked
                        ? Colors.white30
                        : (widget.isSelected || _isHovered)
                            ? Colors.white
                            : Colors.white54,
                    size: 22,
                  ),
                  if (widget.locked)
                    Positioned(
                      right: -9,
                      bottom: -6,
                      child: Container(
                        width: 15,
                        height: 15,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppColors.danger,
                          shape: BoxShape.circle,
                          border: Border.all(color: _kTealDeep, width: 1.5),
                        ),
                        child: const Icon(
                          Icons.lock_rounded,
                          color: Colors.white,
                          size: 8.5,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                widget.label,
                style: GoogleFonts.inter(
                  color: widget.locked
                      ? Colors.white30
                      : (widget.isSelected || _isHovered)
                          ? Colors.white
                          : Colors.white54,
                  fontSize: 10,
                  fontWeight:
                      widget.isSelected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

