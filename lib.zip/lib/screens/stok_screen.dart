import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../database/db_helper.dart';
import '../widgets/kasir_drawer.dart';
import '../widgets/modern_picker.dart';

//
// CONSTANTS
//
const Color _kBrand = AppColors.primaryBrand;
const Color _kTealDark = Color(0xFF1E40AF);
const Color _kBg = Color(0xFFF5F7FA);

class StokScreen extends ConsumerStatefulWidget {
  const StokScreen({super.key});

  @override
  ConsumerState<StokScreen> createState() => _StokScreenState();
}

class _StokScreenState extends ConsumerState<StokScreen> {
  String _query = '';
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  void _showAdjustDialog(BuildContext context, List<Product> products) {
    final ref = this.ref;
    if (products.isEmpty) {
      _snack(context, 'Tambahkan produk terlebih dahulu');
      return;
    }

    Product? selected = products.first;
    final qtyCtrl = TextEditingController();
    String type = 'in';
    String? expiryDate;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero),
          ),
          padding: EdgeInsets.fromLTRB(
              20, 16, 20, MediaQuery.of(ctx).viewInsets.bottom + 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: const BoxDecoration(
                    color: AppColors.divider,
                    borderRadius: BorderRadius.zero,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text('Penyesuaian Stok Manual', style: AppText.h2),
              const SizedBox(height: 16),
              Text('Barang / Item', style: AppText.h3.copyWith(fontSize: 13)),
              const SizedBox(height: 6),
              ModernPicker<Product>(
                value: selected,
                items: products,
                itemLabel: (p) => '${p.name} (Stok: ${p.stock} ${p.unit})',
                onChanged: (p) => set(() => selected = p),
              ),
              const SizedBox(height: 14),
              Text('Jenis', style: AppText.h3.copyWith(fontSize: 13)),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => set(() => type = 'in'),
                      child: Container(
                        height: 44,
                        decoration: BoxDecoration(
                          color: type == 'in'
                              ? const Color(0xFFE8F6F4)
                              : AppColors.background,
                          borderRadius: BorderRadius.zero,
                          border: Border.all(
                            color: type == 'in'
                                ? const Color(0xFF33CDB1)
                                : AppColors.divider,
                            width: type == 'in' ? 2 : 1,
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.arrow_downward_rounded,
                                size: 16,
                                color: type == 'in'
                                    ? const Color(0xFF279B7C)
                                    : AppColors.textCaption),
                            const SizedBox(width: 6),
                            Text(
                              'Stok Masuk',
                              style: AppText.body.copyWith(
                                color: type == 'in'
                                    ? const Color(0xFF279B7C)
                                    : AppColors.textCaption,
                                fontWeight: type == 'in'
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => set(() => type = 'out'),
                      child: Container(
                        height: 44,
                        decoration: BoxDecoration(
                          color: type == 'out'
                              ? const Color(0xFFFBECEC)
                              : AppColors.background,
                          borderRadius: BorderRadius.zero,
                          border: Border.all(
                            color: type == 'out'
                                ? AppColors.danger
                                : AppColors.divider,
                            width: type == 'out' ? 2 : 1,
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.arrow_upward_rounded,
                                size: 16,
                                color: type == 'out'
                                    ? AppColors.danger
                                    : AppColors.textCaption),
                            const SizedBox(width: 6),
                            Text(
                              'Stok Keluar',
                              style: AppText.body.copyWith(
                                color: type == 'out'
                                    ? AppColors.danger
                                    : AppColors.textCaption,
                                fontWeight: type == 'out'
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text('Jumlah', style: AppText.h3.copyWith(fontSize: 13)),
              const SizedBox(height: 6),
              TextField(
                controller: qtyCtrl,
                keyboardType: TextInputType.number,
                style: AppText.body.copyWith(
                    color: AppColors.textPrimary, fontWeight: FontWeight.w600),
                decoration: const InputDecoration(
                  hintText: 'Masukkan jumlah...',
                  filled: true,
                  fillColor: AppColors.background,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: AppColors.divider),
                  ),
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
              ),
              const SizedBox(height: 16),
              if (type == 'in') ...[
                Text('Tanggal Kedaluwarsa (Opsional)',
                    style: AppText.h3.copyWith(fontSize: 13)),
                const SizedBox(height: 6),
                _ExpiryPicker(
                    onDateSelected: (date) => set(() => expiryDate = date)),
                const SizedBox(height: 20),
              ],
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                  onPressed: () async {
                    final qty = int.tryParse(qtyCtrl.text) ?? 0;
                    if (qty <= 0) {
                      _snack(context, 'Masukkan jumlah yang valid');
                      return;
                    }
                    if (selected?.id == null) {
                      _snack(context, 'Produk tidak valid');
                      return;
                    }
                    await ref.read(productsProvider.notifier).recordStockLog(
                          StockLog(
                            productId: selected!.id!,
                            type: type,
                            qty: qty,
                            date: DateTime.now().toIso8601String(),
                            expiryDate: expiryDate,
                          ),
                        );
                    if (context.mounted) {
                      Navigator.pop(ctx);
                      _snack(
                        context,
                        'Stok ${type == 'in' ? 'masuk' : 'keluar'} berhasil dicatat',
                      );
                    }
                  },
                  child: Text('Simpan Perubahan Stok',
                      style: AppText.h3.copyWith(color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _snack(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: Colors.black87,
      behavior: SnackBarBehavior.floating,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    ));
  }

  void _showHistory(BuildContext context, Product product) async {
    if (product.id == null) return;
    final logs = await DBHelper.instance.getStockLogsForProduct(product.id!);
    if (!context.mounted) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        height: MediaQuery.of(ctx).size.height * 0.65,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        child: Column(
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: const BoxDecoration(
                  color: AppColors.divider,
                  borderRadius: BorderRadius.zero,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Text('Riwayat: ${product.name}', style: AppText.h2),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
            ),
            const Divider(height: 1, color: AppColors.divider),
            Expanded(
              child: logs.isEmpty
                  ? Center(
                      child: Text('Belum ada riwayat pergerakan',
                          style: AppText.body
                              .copyWith(color: AppColors.textCaption)))
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: logs.length,
                      separatorBuilder: (_, __) =>
                          const Divider(height: 1, color: AppColors.divider),
                      itemBuilder: (_, i) {
                        final log = logs[i];
                        final isIn = log.type == 'in';
                        final date = DateTime.parse(log.date);
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: isIn
                                      ? const Color(0xFFE8F6F4)
                                      : const Color(0xFFFBECEC),
                                  shape: BoxShape.rectangle,
                                ),
                                child: Icon(
                                  isIn
                                      ? Icons.arrow_downward_rounded
                                      : Icons.arrow_upward_rounded,
                                  size: 16,
                                  color: isIn
                                      ? const Color(0xFF279B7C)
                                      : AppColors.danger,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(isIn ? 'Stok Masuk' : 'Stok Keluar',
                                        style: AppText.body.copyWith(
                                            fontWeight: FontWeight.w600)),
                                    Text(
                                      '${date.day}/${date.month}/${date.year} '
                                      '${date.hour}:${date.minute.toString().padLeft(2, '0')}',
                                      style: AppText.caption,
                                    ),
                                  ],
                                ),
                              ),
                              Text(
                                '${isIn ? '+' : '-'}${log.qty} ${product.unit}',
                                style: AppText.h3.copyWith(
                                  color: isIn
                                      ? const Color(0xFF279B7C)
                                      : AppColors.danger,
                                  fontSize: 15,
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final isTablet = mq.size.shortestSide >= 600;
    final isLandscape =
        mq.orientation == Orientation.landscape && mq.size.width >= 480;

    final allProducts = ref.watch(productsProvider);
    final qLower = _query.toLowerCase();
    final products = _query.isEmpty
        ? allProducts
        : allProducts
            .where((p) =>
                p.name.toLowerCase().contains(qLower) ||
                (p.sku?.toLowerCase().contains(qLower) ?? false) ||
                (p.barcode?.toLowerCase().contains(qLower) ?? false))
            .toList();

    final lowCount = allProducts.where((p) => p.stock <= p.minStock).length;

    if (isTablet || isLandscape) {
      return _buildWideLayout(
        context,
        products: products,
        allProducts: allProducts,
        lowCount: lowCount,
        isTablet: isTablet,
      );
    }
    return _buildPortraitLayout(context, products, allProducts, lowCount);
  }

  //
  // LAYOUT: PORTRAIT (original)
  //
  Widget _buildPortraitLayout(
    BuildContext context,
    List<Product> products,
    List<Product> allProducts,
    int lowCount,
  ) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      drawer: const KasirDrawer(),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon:
                const Icon(Icons.menu, color: AppColors.primaryBrand, size: 26),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: Text('Inventori & Stok',
            style:
                AppText.h1.copyWith(fontSize: 18, fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            _buildSearchField(horizontal: 20),
            const SizedBox(height: 12),
            _buildTableHeader(horizontal: 20),
            const SizedBox(height: 8),
            const Divider(height: 1, color: AppColors.divider),
            Expanded(
              child: Stack(
                children: [
                  _buildProductList(
                    context,
                    products,
                    allProducts,
                    bottomPad: 100,
                  ),
                  _buildBottomButtons(context, products, allProducts),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  //
  // LAYOUT: LANDSCAPE / TABLET -- Professional split-panel
  // Left: Teal gradient sidebar with stats + actions
  // Right: Search + table
  //
  Widget _buildWideLayout(
    BuildContext context, {
    required List<Product> products,
    required List<Product> allProducts,
    required int lowCount,
    required bool isTablet,
  }) {
    final mq = MediaQuery.of(context);
    final isLandscapePhone =
        mq.orientation == Orientation.landscape && mq.size.shortestSide < 600;
    // Landscape phone: sidebar lebih kecil, sembunyikan decorative icon
    final sideWidth = isTablet ? 300.0 : (isLandscapePhone ? 220.0 : 260.0);
    final sideVPad = isLandscapePhone ? 10.0 : 16.0;
    final sideHPad = isLandscapePhone ? 14.0 : 20.0;

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: _kBg,
      drawer: const KasirDrawer(),
      body: Row(
        children: [
          SizedBox(
            width: sideWidth,
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [_kBrand, _kTealDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.only(
                  topRight: Radius.zero,
                  bottomRight: Radius.zero,
                ),
              ),
              child: SafeArea(
                right: false,
                bottom: false,
                child: Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: sideHPad, vertical: sideVPad),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Top row: menu + title
                      Row(
                        children: [
                          Builder(
                            builder: (ctx) => GestureDetector(
                              onTap: () => Scaffold.of(ctx).openDrawer(),
                              child: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.zero,
                                ),
                                child: const Icon(Icons.menu,
                                    color: Colors.white, size: 20),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          const Expanded(
                            child: Text(
                              'Inventori & Stok',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.3,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      if (!isLandscapePhone) ...[
                        const SizedBox(height: 24),
                        // Decorative icon -- disembunyikan di landscape phone
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: const Icon(Icons.inventory_2_rounded,
                              color: Colors.white, size: 28),
                        ),
                      ],
                      SizedBox(height: isLandscapePhone ? 10 : 18),

                      // Stat cards -- scrollable di landscape phone agar tidak overflow
                      if (isLandscapePhone)
                        Expanded(
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                _SideStatCard(
                                  label: 'Total Item',
                                  value: '${allProducts.length}',
                                  icon: Icons.category_rounded,
                                  compact: true,
                                ),
                                const SizedBox(height: 8),
                                _SideStatCard(
                                  label: 'Stok Menipis',
                                  value: '$lowCount',
                                  icon: Icons.warning_amber_rounded,
                                  danger: lowCount > 0,
                                  compact: true,
                                ),
                                const SizedBox(height: 8),
                                _SideStatCard(
                                  label: 'Stok Aman',
                                  value: '${allProducts.length - lowCount}',
                                  icon: Icons.check_circle_outline_rounded,
                                  compact: true,
                                ),
                                const SizedBox(height: 12),
                                _SideActionButton(
                                  icon: Icons.history_rounded,
                                  label: 'Lacak',
                                  onTap: () {
                                    if (products.isNotEmpty) {
                                      _showHistory(context, products.first);
                                    }
                                  },
                                  outlined: true,
                                  compact: true,
                                ),
                                const SizedBox(height: 8),
                                _SideActionButton(
                                  icon: Icons.tune_rounded,
                                  label: 'Sesuaikan',
                                  onTap: () =>
                                      _showAdjustDialog(context, allProducts),
                                  compact: true,
                                ),
                              ],
                            ),
                          ),
                        )
                      else ...[
                        _SideStatCard(
                          label: 'Total Item',
                          value: '${allProducts.length}',
                          icon: Icons.category_rounded,
                        ),
                        const SizedBox(height: 10),
                        _SideStatCard(
                          label: 'Stok Menipis',
                          value: '$lowCount',
                          icon: Icons.warning_amber_rounded,
                          danger: lowCount > 0,
                        ),
                        const SizedBox(height: 10),
                        _SideStatCard(
                          label: 'Stok Aman',
                          value: '${allProducts.length - lowCount}',
                          icon: Icons.check_circle_outline_rounded,
                        ),
                        const Spacer(),
                        _SideActionButton(
                          icon: Icons.history_rounded,
                          label: 'Lacak Pergerakan',
                          onTap: () {
                            if (products.isNotEmpty) {
                              _showHistory(context, products.first);
                            }
                          },
                          outlined: true,
                        ),
                        const SizedBox(height: 10),
                        _SideActionButton(
                          icon: Icons.tune_rounded,
                          label: 'Penyesuaian Stok',
                          onTap: () => _showAdjustDialog(context, allProducts),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),

          Expanded(
            child: SafeArea(
              left: false,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top bar
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.fromLTRB(
                        20, isLandscapePhone ? 10 : 16, 20, 12),
                    child: Row(
                      children: [
                        Expanded(child: _buildSearchField(horizontal: 0)),
                        if (lowCount > 0) ...[
                          const SizedBox(width: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8),
                            decoration: const BoxDecoration(
                              color: Color(0xFFFBECEC),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.warning_amber_rounded,
                                    size: 15, color: AppColors.danger),
                                const SizedBox(width: 6),
                                Text(
                                  '$lowCount stok menipis',
                                  style: const TextStyle(
                                    color: AppColors.danger,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const Divider(height: 1, color: AppColors.divider),

                  // Table header
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
                    child: _buildTableHeader(horizontal: 0),
                  ),
                  const Divider(height: 1, color: AppColors.divider),

                  // List
                  Expanded(
                    child: _buildProductList(
                      context,
                      products,
                      allProducts,
                      bottomPad: 20,
                      bgColor: _kBg,
                    ),
                  ),
                ],
              ),
            ),
          ), // SafeArea (right panel)
        ],
      ),
    );
  }

  Widget _buildSearchField({required double horizontal}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: Colors.grey.withValues(alpha: 0.3)),
      ),
      child: TextField(
        style: AppText.body.copyWith(color: AppColors.textTitle),
        onChanged: (v) => setState(() => _query = v),
        decoration: InputDecoration(
          hintText: 'Cari Barang / SKU / Barcode...',
          hintStyle: AppText.body.copyWith(color: AppColors.textCaption),
          prefixIcon: const Icon(Icons.search_rounded,
              color: AppColors.textCaption, size: 22),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 13),
        ),
      ),
    );
  }

  Widget _buildTableHeader({required double horizontal}) {
    return const DefaultTextStyle(
      style: TextStyle(
          fontWeight: FontWeight.w800, color: Colors.black87, fontSize: 13),
      child: Row(
        children: [
          SizedBox(width: 48 + 12),
          Expanded(flex: 2, child: Text('Nama Barang')),
          Expanded(
              flex: 1, child: Text('Min. Stok', textAlign: TextAlign.right)),
          SizedBox(width: 16),
          Expanded(flex: 1, child: Text('Status', textAlign: TextAlign.center)),
        ],
      ),
    );
  }

  Widget _buildProductList(
    BuildContext context,
    List<Product> products,
    List<Product> allProducts, {
    required double bottomPad,
    Color bgColor = Colors.white,
  }) {
    if (products.isEmpty) {
      return Center(
        child: Text(
          _query.isEmpty ? 'Belum ada produk' : 'Produk tidak ditemukan',
          style: AppText.body.copyWith(color: AppColors.textCaption),
        ),
      );
    }
    return ListView.separated(
      padding: EdgeInsets.fromLTRB(20, 12, 20, bottomPad),
      itemCount: products.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) {
        final p = products[i];
        final isLow = p.stock <= p.minStock;
        return GestureDetector(
          onTap: () => _showHistory(context, p),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.zero,
              border: Border.all(
                color: isLow
                    ? AppColors.danger.withValues(alpha: 0.25)
                    : AppColors.divider,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.02),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: isLow ? const Color(0xFFFBECEC) : AppColors.qaStok,
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Center(
                      child: Icon(
                        Icons.inventory_2_rounded,
                        color: isLow ? AppColors.danger : AppColors.iconOutline,
                        size: 26,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          p.name,
                          style: AppText.h3.copyWith(
                              fontSize: 14, fontWeight: FontWeight.bold),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${p.stock} ${p.unit}',
                          style: const TextStyle(
                              fontSize: 13,
                              color: Colors.grey,
                              fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Text(
                      '${p.minStock} ${p.unit}',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 13),
                      textAlign: TextAlign.right,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    flex: 1,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      decoration: BoxDecoration(
                        color: isLow
                            ? const Color(0xFFFBECEC)
                            : const Color(0xFFE8F6F4),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Text(
                        isLow ? 'Hampir Habis' : 'Stok Aman',
                        style: TextStyle(
                          color: isLow
                              ? AppColors.danger
                              : const Color(0xFF279B7C),
                          fontWeight: FontWeight.bold,
                          fontSize: 11,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildBottomButtons(
    BuildContext context,
    List<Product> products,
    List<Product> allProducts,
  ) {
    return Positioned(
      bottom: 24,
      left: 20,
      right: 20,
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(
                side:
                    const BorderSide(color: AppColors.primaryBrand, width: 1.5),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: () {
                if (products.isNotEmpty) _showHistory(context, products.first);
              },
              child: const Text('Lacak Pergerakan',
                  style: TextStyle(
                      color: AppColors.primaryBrand,
                      fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBrand,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: () => _showAdjustDialog(context, allProducts),
              child: const Text('Penyesuaian',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }
}

//
// SIDEBAR STAT CARD
//
class _SideStatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final bool danger;
  final bool compact;

  const _SideStatCard({
    required this.label,
    required this.value,
    required this.icon,
    this.danger = false,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final vPad = compact ? 8.0 : 12.0;
    final hPad = compact ? 10.0 : 14.0;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: hPad, vertical: vPad),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: danger ? 0.18 : 0.12),
        borderRadius: BorderRadius.zero,
        border: danger
            ? Border.all(
                color: const Color(0xFFFFCDD2).withValues(alpha: 0.6), width: 1)
            : null,
      ),
      child: Row(
        children: [
          Icon(icon,
              color: danger
                  ? const Color(0xFFFFCDD2)
                  : Colors.white.withValues(alpha: 0.85),
              size: compact ? 15 : 18),
          SizedBox(width: compact ? 7 : 10),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.8),
                fontSize: compact ? 11 : 12,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              color: Colors.white,
              fontSize: compact ? 15 : 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

//
// SIDEBAR ACTION BUTTON
//
class _SideActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool outlined;
  final bool compact;

  const _SideActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.outlined = false,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final vPad = compact ? 9.0 : 13.0;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: vPad),
        decoration: BoxDecoration(
          color: outlined ? Colors.transparent : Colors.white,
          borderRadius: BorderRadius.zero,
          border: Border.all(
            color: Colors.white.withValues(alpha: outlined ? 0.5 : 1),
            width: outlined ? 1.5 : 0,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                size: compact ? 15 : 18,
                color: outlined ? Colors.white : AppColors.primaryBrand),
            SizedBox(width: compact ? 6 : 8),
            Text(
              label,
              style: TextStyle(
                fontSize: compact ? 11 : 13,
                fontWeight: FontWeight.w700,
                color: outlined ? Colors.white : AppColors.primaryBrand,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//
// EXPIRY PICKER
//
class _ExpiryPicker extends StatefulWidget {
  final ValueChanged<String?> onDateSelected;
  const _ExpiryPicker({required this.onDateSelected});

  @override
  State<_ExpiryPicker> createState() => _ExpiryPickerState();
}

class _ExpiryPickerState extends State<_ExpiryPicker> {
  DateTime? _selected;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () async {
        final d = await showDatePicker(
          context: context,
          initialDate: DateTime.now().add(const Duration(days: 365)),
          firstDate: DateTime.now(),
          lastDate: DateTime.now().add(const Duration(days: 365 * 10)),
        );
        if (d != null) {
          setState(() => _selected = d);
          widget.onDateSelected(d.toIso8601String().substring(0, 10));
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.background,
          borderRadius: BorderRadius.zero,
          border: Border.all(color: AppColors.divider),
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_month_rounded,
                size: 20, color: AppColors.textCaption),
            const SizedBox(width: 12),
            Text(
              _selected == null
                  ? 'Pilih Tanggal (Opsional)'
                  : '${_selected!.day}/${_selected!.month}/${_selected!.year}',
              style: TextStyle(
                color: _selected == null
                    ? AppColors.textCaption
                    : AppColors.textPrimary,
                fontSize: 14,
              ),
            ),
            if (_selected != null) ...[
              const Spacer(),
              GestureDetector(
                onTap: () {
                  setState(() => _selected = null);
                  widget.onDateSelected(null);
                },
                child:
                    const Icon(Icons.close, size: 18, color: AppColors.danger),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

