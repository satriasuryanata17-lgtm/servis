import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/finance_category_ui.dart';
import '../core/theme.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../services/export_service.dart';
import '../widgets/export_dropdown.dart';
import 'responsive_layout.dart';

// ─── helpers ───────────────────────────────────────────────────────────────

String _fmtRp(int value) {
  final digits = value.abs().toString();
  final buf = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buf.write('.');
    buf.write(digits[i]);
  }
  return 'Rp${value < 0 ? '-' : ''}$buf';
}

String _fmtDate(String v) {
  final d = DateTime.tryParse(v);
  if (d == null) return v;
  return '${d.day.toString().padLeft(2, '0')}/'
      '${d.month.toString().padLeft(2, '0')}/'
      '${d.year}';
}

String _monthName(int m) => const [
      'Januari',
      'Februari',
      'Maret',
      'April',
      'Mei',
      'Juni',
      'Juli',
      'Agustus',
      'September',
      'Oktober',
      'November',
      'Desember',
    ][(m - 1).clamp(0, 11)];

String _walletLabel(String id) {
  final w = id.trim().toLowerCase();
  if (w == 'non_tunai' ||
      w == 'nontunai' ||
      w == 'transfer' ||
      w == 'bank' ||
      w == 'qris') {
    return 'Non Tunai';
  }
  return 'Tunai';
}

// ─── main screen ──────────────────────────────────────────────────────────

class LaporanKeuanganScreen extends ConsumerStatefulWidget {
  const LaporanKeuanganScreen({super.key});

  @override
  ConsumerState<LaporanKeuanganScreen> createState() =>
      _LaporanKeuanganScreenState();
}

class _LaporanKeuanganScreenState extends ConsumerState<LaporanKeuanganScreen> {
  static const _allCat = '__all__';

  late int _month;
  late int _year;
  String _type = 'keluar';
  String _category = _allCat;

  bool get _isIncome => _type == 'masuk';

  // Accent color for amount/category badges
  Color get _accentAmount =>
      _isIncome ? const Color(0xFF059669) : AppColors.danger;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _month = now.month;
    _year = now.year;
  }

  // ── filter helpers ──────────────────────────────────────────────────────

  String _catLabel(WalletTransaction tx) {
    final raw = (tx.kategori ?? '').trim();
    if (raw.isEmpty || raw == 'Manual' || raw == 'Pemasukan Manual') {
      return _isIncome ? 'Pemasukan Lain' : 'Lainnya';
    }
    return raw;
  }

  String _noteLabel(WalletTransaction tx) {
    final note = tx.keterangan.trim();
    if (note.isEmpty) return '-';
    if (note.toLowerCase() == _catLabel(tx).toLowerCase()) return '-';
    return note;
  }

  List<WalletTransaction> _filtered(List<WalletTransaction> all) {
    return all.where((tx) {
      if (tx.type != _type) return false;
      final d = DateTime.tryParse(tx.tanggal);
      if (d == null || d.month != _month || d.year != _year) return false;
      if (_category != _allCat &&
          _catLabel(tx).trim().toLowerCase() !=
              _category.trim().toLowerCase()) {
        return false;
      }
      return true;
    }).toList()
      ..sort((a, b) {
        final da = DateTime.tryParse(a.createdAt) ?? DateTime(1970);
        final db = DateTime.tryParse(b.createdAt) ?? DateTime(1970);
        return db.compareTo(da);
      });
  }

  Map<String, int> _catTotals(List<WalletTransaction> all) {
    final map = <String, int>{};
    for (final tx in all) {
      if (tx.type != _type) continue;
      final d = DateTime.tryParse(tx.tanggal);
      if (d == null || d.month != _month || d.year != _year) continue;
      final c = _catLabel(tx);
      map[c] = (map[c] ?? 0) + tx.nominal.abs();
    }
    final entries = map.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return Map.fromEntries(entries);
  }

  // ── actions ─────────────────────────────────────────────────────────────

  Future<void> _pickPeriod() async {
    final result = await showModalBottomSheet<Map<String, int>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _PeriodPickerSheet(
        initialMonth: _month,
        initialYear: _year,
      ),
    );
    if (result == null) return;
    setState(() {
      _month = result['month'] ?? _month;
      _year = result['year'] ?? _year;
      _category = _allCat;
    });
  }

  Future<void> _export(List<WalletTransaction> txs, int total) async {
    final choice = await ExportDropdown.show(context);
    if (choice == null) return;

    final title = _isIncome ? 'Laporan Pemasukan' : 'Laporan Pengeluaran';
    final subtitle =
        '${_monthName(_month)} $_year - ${_category == _allCat ? 'Semua Kategori' : _category}';
    final headers = [
      'Tanggal',
      'Waktu',
      'Kategori',
      'Sumber Dana',
      'Keterangan',
      'Nominal'
    ];
    final rows = txs
        .map((tx) => [
              _fmtDate(tx.tanggal),
              tx.waktu,
              _catLabel(tx),
              _walletLabel(tx.walletId),
              _noteLabel(tx) == '-' ? '' : _noteLabel(tx),
              _fmtRp(tx.nominal.abs()),
            ])
        .toList();
    final summary = {
      'Periode': subtitle,
      _isIncome ? 'Total Pemasukan' : 'Total Pengeluaran': _fmtRp(total),
      'Jumlah Transaksi': '${txs.length}',
    };

    try {
      if (choice == 'csv') {
        await ExportService.exportAndShareCsv(
          filePrefix: _isIncome ? 'laporan_pemasukan' : 'laporan_pengeluaran',
          headers: headers,
          rows: rows,
        );
      } else if (choice == 'pdf') {
        await ExportService.exportPdfLaporan(
            title: title,
            subtitle: subtitle,
            headers: headers,
            rows: rows,
            summaryData: summary);
      } else if (choice == 'print') {
        await ExportService.printPdfLaporan(
            title: title,
            subtitle: subtitle,
            headers: headers,
            rows: rows,
            summaryData: summary);
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Gagal mengekspor laporan.')),
      );
    }
  }

  // ── build ────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final txAsync = ref.watch(walletTransactionsProvider);
    final financeCategories = ref.watch(financeCategoriesProvider);

    // ── Stale-while-revalidate: show previous data while refreshing,
    //    only block on first load (no cached value yet).
    final cachedData = txAsync.asData?.value;
    final isFirstLoad = cachedData == null && !txAsync.hasError;

    return KasirResponsiveScaffold(
      title: 'Laporan Keuangan',
      showNavRail: false,
      backgroundColor: const Color(0xFFF0F4F8),
      body: isFirstLoad
          ? const Center(
              child: CircularProgressIndicator(color: AppColors.primaryBrand))
          : txAsync.hasError && cachedData == null
              ? const Center(child: Text('Gagal memuat laporan.'))
              : Stack(
                  children: [
                    _Body(
                      all: cachedData ?? [],
                      month: _month,
                      year: _year,
                      type: _type,
                      category: _category,
                      categories: financeCategories,
                      accentAmount: _accentAmount,
                      filtered: _filtered(cachedData ?? []),
                      catTotals: _catTotals(cachedData ?? []),
                      catLabel: _catLabel,
                      noteLabel: _noteLabel,
                      onTypeChanged: (t) => setState(() {
                        _type = t;
                        _category = _allCat;
                      }),
                      onCategoryChanged: (c) => setState(() => _category = c),
                      onPickPeriod: _pickPeriod,
                      onExport: _export,
                    ),
                    // Thin refresh bar — visible while provider is refreshing
                    if (txAsync.isLoading)
                      const Positioned(
                        top: 0,
                        left: 0,
                        right: 0,
                        child: LinearProgressIndicator(
                          backgroundColor: Colors.transparent,
                          valueColor:
                              AlwaysStoppedAnimation(AppColors.primaryBrand),
                          minHeight: 2,
                        ),
                      ),
                  ],
                ),
    );
  }
}

// ── body widget ────────────────────────────────────────────────────────────

class _Body extends StatelessWidget {
  static const _allCat = '__all__';

  final List<WalletTransaction> all;
  final List<WalletTransaction> filtered;
  final Map<String, int> catTotals;
  final int month;
  final int year;
  final String type;
  final String category;
  final List<FinanceCategory> categories;
  final Color accentAmount;
  final String Function(WalletTransaction) catLabel;
  final String Function(WalletTransaction) noteLabel;
  final ValueChanged<String> onTypeChanged;
  final ValueChanged<String> onCategoryChanged;
  final VoidCallback onPickPeriod;
  final Future<void> Function(List<WalletTransaction>, int) onExport;

  const _Body({
    required this.all,
    required this.filtered,
    required this.catTotals,
    required this.month,
    required this.year,
    required this.type,
    required this.category,
    required this.categories,
    required this.accentAmount,
    required this.catLabel,
    required this.noteLabel,
    required this.onTypeChanged,
    required this.onCategoryChanged,
    required this.onPickPeriod,
    required this.onExport,
  });

  bool get _isIncome => type == 'masuk';
  int get _periodTotal => catTotals.values.fold(0, (a, b) => a + b);
  int get _filteredTotal => filtered.fold(0, (s, tx) => s + tx.nominal.abs());

  int _categoryTotalFor(String name) {
    final normalized = name.trim().toLowerCase();
    for (final entry in catTotals.entries) {
      if (entry.key.trim().toLowerCase() == normalized) return entry.value;
    }
    return 0;
  }

  List<_ReportCategoryOption> get _categoryOptions {
    final options = <_ReportCategoryOption>[];
    final seen = <String>{};
    final activeCategories = categories
        .where((category) =>
            category.type == type &&
            category.active &&
            isManualFinanceCategory(category))
        .toList()
      ..sort((a, b) {
        final sortCompare = a.sortOrder.compareTo(b.sortOrder);
        if (sortCompare != 0) return sortCompare;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

    for (final category in activeCategories) {
      final name = category.name.trim();
      if (name.isEmpty) continue;
      final key = name.toLowerCase();
      if (!seen.add(key)) continue;
      options.add(_ReportCategoryOption(
        name: name,
        total: _categoryTotalFor(name),
        category: category,
      ));
    }

    for (final entry in catTotals.entries) {
      final name = entry.key.trim();
      if (name.isEmpty) continue;
      final key = name.toLowerCase();
      if (!seen.add(key)) continue;
      options.add(_ReportCategoryOption(
        name: name,
        total: entry.value,
      ));
    }

    return options;
  }

  String _resolvedCategoryValue(List<_ReportCategoryOption> options) {
    if (category == _allCat) return _allCat;
    final selectedExists = options.any((option) => option.name == category);
    return selectedExists ? category : _allCat;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      final wide = constraints.maxWidth >= 720;
      if (wide) return _buildWide(context);
      return _buildNarrow(context);
    });
  }

  // ── wide (tablet landscape) ─────────────────────────────────────────────

  Widget _buildWide(BuildContext context) {
    final categoryOptions = _categoryOptions;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 288,
          child: Container(
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Blue gradient header for side panel
                Container(
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AppColors.primaryBrand, AppColors.primaryDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _isIncome ? 'Total Pemasukan' : 'Total Pengeluaran',
                        style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                            fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      Text(_fmtRp(_periodTotal),
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Text('${_monthName(month)} $year',
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 12)),
                    ],
                  ),
                ),
                // Type toggle
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                  child: _TypeToggle(type: type, onChanged: onTypeChanged),
                ),
                // Period button
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: OutlinedButton.icon(
                    onPressed: onPickPeriod,
                    icon: const Icon(Icons.calendar_month_outlined, size: 16),
                    label: Text('${_monthName(month)} $year',
                        style: const TextStyle(fontSize: 13)),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primaryBrand,
                      side: const BorderSide(color: AppColors.border),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      padding: const EdgeInsets.symmetric(vertical: 11),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                // Category label
                const Padding(
                  padding: EdgeInsets.fromLTRB(12, 0, 12, 6),
                  child: Text('KATEGORI',
                      style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textCaption,
                          letterSpacing: 1.2)),
                ),
                // Category list
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: _CatRow(
                    label: 'Semua Kategori',
                    value: _fmtRp(_periodTotal),
                    selected: category == _allCat,
                    onTap: () => onCategoryChanged(_allCat),
                  ),
                ),
                const SizedBox(height: 4),
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 16),
                    itemCount: categoryOptions.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 4),
                    itemBuilder: (_, i) {
                      final option = categoryOptions[i];
                      return _CatRow(
                        label: option.name,
                        value: _fmtRp(option.total),
                        icon: option.icon,
                        color: option.color,
                        selected: category == option.name,
                        onTap: () => onCategoryChanged(option.name),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
        Container(width: 1, color: AppColors.border),
        Expanded(
          child: Column(
            children: [
              _ListHeader(
                category: category == _allCat ? 'Semua Kategori' : category,
                period: '${_monthName(month)} $year',
                total: _filteredTotal,
                count: filtered.length,
                isIncome: _isIncome,
                onExport: () => onExport(filtered, _filteredTotal),
              ),
              Expanded(
                  child: _TxList(
                transactions: filtered,
                catLabel: catLabel,
                noteLabel: noteLabel,
                accentAmount: accentAmount,
              )),
            ],
          ),
        ),
      ],
    );
  }

  // ── narrow (phone) ───────────────────────────────────────────────────────

  Widget _buildNarrow(BuildContext context) {
    final categoryOptions = _categoryOptions;
    final selectedCategory = _resolvedCategoryValue(categoryOptions);
    final avgVal = filtered.isEmpty ? 0 : _filteredTotal ~/ filtered.length;

    return Column(
      children: [
        // ── TYPE TOGGLE ──────────────────────────────────────────────────
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          child: _TypeToggle(type: type, onChanged: onTypeChanged),
        ),

        // ── BLUE STATS HEADER ────────────────────────────────────────────
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.primaryBrand, AppColors.primaryDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Period row
              Row(children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Periode laporan',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${_monthName(month)} $year',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                OutlinedButton.icon(
                  onPressed: onPickPeriod,
                  icon: const Icon(Icons.calendar_month_outlined, size: 15),
                  label: const Text('Ubah periode'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: Colors.white.withValues(alpha: 0.12),
                    side: BorderSide(
                      color: Colors.white.withValues(alpha: 0.35),
                    ),
                    minimumSize: const Size(0, 38),
                    padding: const EdgeInsets.symmetric(horizontal: 11),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6),
                    ),
                    textStyle: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              // Total amount
              Text(
                _isIncome ? 'Total Pemasukan' : 'Total Pengeluaran',
                style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 11,
                    fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.centerLeft,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    _fmtRp(_filteredTotal),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              // Stats row
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _StatPill(
                    icon: Icons.receipt_outlined,
                    label: '${filtered.length} Transaksi',
                  ),
                  _StatPill(
                    icon: Icons.calculate_outlined,
                    label: 'Rata-rata ${_fmtRp(avgVal)}',
                  ),
                ],
              ),
            ],
          ),
        ),

        // ── CATEGORY DROPDOWN + EXPORT ───────────────────────────────────
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Filter transaksi',
                          style: TextStyle(
                            color: AppColors.textTitle,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Pilih kategori laporan',
                          style: TextStyle(
                            color: AppColors.textCaption,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: () => onExport(filtered, _filteredTotal),
                    icon: const Icon(Icons.download_rounded, size: 16),
                    label: const Text('Ekspor'),
                    style: ElevatedButton.styleFrom(
                      elevation: 0,
                      backgroundColor: AppColors.primaryBrand,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(0, 40),
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(6)),
                      ),
                      textStyle: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _CategoryDropdown(
                selectedValue: selectedCategory,
                allValue: _allCat,
                allAmount: _periodTotal,
                options: categoryOptions,
                onChanged: onCategoryChanged,
              ),
            ],
          ),
        ),

        const Divider(height: 1, color: AppColors.border),

        // ── TRANSACTION LIST ─────────────────────────────────────────────
        Expanded(
          child: _TxList(
            transactions: filtered,
            catLabel: catLabel,
            noteLabel: noteLabel,
            accentAmount: accentAmount,
          ),
        ),
      ],
    );
  }
}

// ── sub-widgets ────────────────────────────────────────────────────────────

class _ReportCategoryOption {
  final String name;
  final int total;
  final FinanceCategory? category;

  const _ReportCategoryOption({
    required this.name,
    required this.total,
    this.category,
  });

  IconData get icon => category == null
      ? Icons.receipt_long_outlined
      : financeCategoryIcon(
          category!.iconKey,
          name: name,
        );

  Color get color => category == null
      ? AppColors.primaryBrand
      : financeCategoryColor(category!.colorHex);
}

class _PeriodPickerSheet extends StatefulWidget {
  final int initialMonth;
  final int initialYear;

  const _PeriodPickerSheet({
    required this.initialMonth,
    required this.initialYear,
  });

  @override
  State<_PeriodPickerSheet> createState() => _PeriodPickerSheetState();
}

class _PeriodPickerSheetState extends State<_PeriodPickerSheet> {
  late int _month;
  late int _year;

  @override
  void initState() {
    super.initState();
    _month = widget.initialMonth;
    _year = widget.initialYear;
  }

  @override
  Widget build(BuildContext context) {
    final currentYear = DateTime.now().year;
    final years = List.generate(7, (index) => currentYear - index);

    return SafeArea(
      top: false,
      child: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Pilih periode laporan',
                          style: TextStyle(
                            color: AppColors.textTitle,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text(
                          'Tentukan bulan dan tahun transaksi',
                          style: TextStyle(
                            color: AppColors.textCaption,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    tooltip: 'Tutup',
                    icon: const Icon(Icons.close_rounded),
                    color: AppColors.textCaption,
                  ),
                ],
              ),
              const SizedBox(height: 18),
              const Text(
                'TAHUN',
                style: TextStyle(
                  color: AppColors.textCaption,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                height: 42,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: years.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final year = years[index];
                    final selected = year == _year;
                    return InkWell(
                      onTap: () => setState(() => _year = year),
                      borderRadius: BorderRadius.circular(6),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 160),
                        width: 78,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: selected
                              ? AppColors.primaryBrand
                              : const Color(0xFFF8FAFF),
                          border: Border.all(
                            color: selected
                                ? AppColors.primaryBrand
                                : AppColors.border,
                          ),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          '$year',
                          style: TextStyle(
                            color:
                                selected ? Colors.white : AppColors.textTitle,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'BULAN',
                style: TextStyle(
                  color: AppColors.textCaption,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 8),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  childAspectRatio: 2.35,
                ),
                itemCount: 12,
                itemBuilder: (context, index) {
                  final month = index + 1;
                  final selected = month == _month;
                  return InkWell(
                    onTap: () => setState(() => _month = month),
                    borderRadius: BorderRadius.circular(6),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 160),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: selected
                            ? AppColors.primaryBrand
                            : const Color(0xFFF8FAFF),
                        border: Border.all(
                          color: selected
                              ? AppColors.primaryBrand
                              : AppColors.border,
                        ),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        _monthName(month),
                        style: TextStyle(
                          color: selected ? Colors.white : AppColors.textTitle,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 20),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 11,
                ),
                decoration: BoxDecoration(
                  color: AppColors.primaryBrand.withValues(alpha: 0.06),
                  border: Border.all(
                    color: AppColors.primaryBrand.withValues(alpha: 0.16),
                  ),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  children: [
                    const Text(
                      'Periode dipilih',
                      style: TextStyle(
                        color: AppColors.textCaption,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '${_monthName(_month)} $_year',
                      style: const TextStyle(
                        color: AppColors.primaryBrand,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.textTitle,
                        side: const BorderSide(color: AppColors.border),
                        minimumSize: const Size(0, 48),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                      child: const Text(
                        'Batal',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    flex: 2,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(
                        context,
                        {'month': _month, 'year': _year},
                      ),
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: AppColors.primaryBrand,
                        foregroundColor: Colors.white,
                        minimumSize: const Size(0, 48),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                      child: const Text(
                        'Terapkan periode',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatPill extends StatelessWidget {
  final IconData icon;
  final String label;

  const _StatPill({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.18),
        border: Border.all(color: Colors.white.withValues(alpha: 0.25)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: Colors.white70, size: 12),
        const SizedBox(width: 5),
        Text(label,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w700)),
      ]),
    );
  }
}

class _CategoryDropdown extends StatelessWidget {
  final String selectedValue;
  final String allValue;
  final int allAmount;
  final List<_ReportCategoryOption> options;
  final ValueChanged<String> onChanged;

  const _CategoryDropdown({
    required this.selectedValue,
    required this.allValue,
    required this.allAmount,
    required this.options,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isAll = selectedValue == allValue;
    _ReportCategoryOption? selectedOption;
    for (final option in options) {
      if (option.name == selectedValue) {
        selectedOption = option;
        break;
      }
    }

    final selectedLabel =
        isAll ? 'Semua Kategori' : selectedOption?.name ?? 'Semua Kategori';
    final selectedAmount =
        isAll ? allAmount : selectedOption?.total ?? allAmount;
    return LayoutBuilder(
      builder: (context, constraints) {
        return PopupMenuButton<String>(
          position: PopupMenuPosition.under,
          offset: const Offset(0, 6),
          elevation: 10,
          color: Colors.white,
          tooltip: 'Pilih kategori',
          constraints: BoxConstraints(
            minWidth: constraints.maxWidth,
            maxWidth: constraints.maxWidth,
            maxHeight: 360,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(6),
            side: const BorderSide(color: AppColors.border),
          ),
          onSelected: onChanged,
          itemBuilder: (context) => [
            _categoryMenuItem(
              value: allValue,
              label: 'Semua Kategori',
              amount: allAmount,
              selected: isAll,
            ),
            ...options.map(
              (option) => _categoryMenuItem(
                value: option.name,
                label: option.name,
                amount: option.total,
                selected: selectedValue == option.name,
              ),
            ),
          ],
          child: Container(
            height: 54,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFF),
              border: Border.all(color: AppColors.border),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        selectedLabel,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: AppColors.textTitle,
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _fmtRp(selectedAmount),
                        style: const TextStyle(
                          color: AppColors.textCaption,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(
                  Icons.keyboard_arrow_down_rounded,
                  size: 20,
                  color: AppColors.primaryBrand,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  PopupMenuItem<String> _categoryMenuItem({
    required String value,
    required String label,
    required int amount,
    required bool selected,
  }) {
    return PopupMenuItem<String>(
      value: value,
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        decoration: BoxDecoration(
          color: selected
              ? AppColors.primaryBrand.withValues(alpha: 0.08)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(5),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color:
                      selected ? AppColors.primaryBrand : AppColors.textTitle,
                  fontSize: 13,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              _fmtRp(amount),
              style: const TextStyle(
                color: AppColors.textCaption,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
            if (selected) ...[
              const SizedBox(width: 8),
              const Icon(
                Icons.check_circle_rounded,
                color: AppColors.primaryBrand,
                size: 17,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _TypeToggle extends StatelessWidget {
  final String type;
  final ValueChanged<String> onChanged;

  const _TypeToggle({required this.type, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 42,
      decoration: BoxDecoration(
        color: const Color(0xFFF0F4F8),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
              child: _Tab(
            label: 'Pengeluaran',
            icon: Icons.trending_down_outlined,
            active: type == 'keluar',
            activeColor: AppColors.danger,
            onTap: () => onChanged('keluar'),
          )),
          Container(width: 1, color: AppColors.border),
          Expanded(
              child: _Tab(
            label: 'Pemasukan',
            icon: Icons.trending_up_outlined,
            active: type == 'masuk',
            activeColor: const Color(0xFF059669),
            onTap: () => onChanged('masuk'),
          )),
        ],
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool active;
  final Color activeColor;
  final VoidCallback onTap;

  const _Tab({
    required this.label,
    required this.icon,
    required this.active,
    required this.activeColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        alignment: Alignment.center,
        color: active ? activeColor : Colors.transparent,
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon,
              size: 15, color: active ? Colors.white : AppColors.textCaption),
          const SizedBox(width: 6),
          Text(label,
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: active ? Colors.white : AppColors.textCaption)),
        ]),
      ),
    );
  }
}

class _CatRow extends StatelessWidget {
  final String label;
  final String value;
  final IconData? icon;
  final Color? color;
  final bool selected;
  final VoidCallback onTap;

  const _CatRow({
    required this.label,
    required this.value,
    this.icon,
    this.color,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: selected
              ? AppColors.primaryBrand.withValues(alpha: 0.08)
              : Colors.white,
          border: Border.all(
              color: selected ? AppColors.primaryBrand : AppColors.border),
        ),
        child: Row(children: [
          if (selected)
            Container(
              width: 3,
              height: 14,
              color: color ?? AppColors.primaryBrand,
              margin: const EdgeInsets.only(right: 8),
            ),
          if (icon != null) ...[
            Icon(icon, size: 15, color: color ?? AppColors.primaryBrand),
            const SizedBox(width: 7),
          ],
          Expanded(
            child: Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                    color: selected
                        ? AppColors.primaryBrand
                        : AppColors.textTitle)),
          ),
          Text(value,
              style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textCaption)),
        ]),
      ),
    );
  }
}

class _ListHeader extends StatelessWidget {
  final String category;
  final String period;
  final int total;
  final int count;
  final bool isIncome;
  final VoidCallback onExport;

  const _ListHeader({
    required this.category,
    required this.period,
    required this.total,
    required this.count,
    required this.isIncome,
    required this.onExport,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.primaryBrand, AppColors.primaryDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
      child: Row(children: [
        Expanded(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(category,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w900)),
            const SizedBox(height: 2),
            Text('$period • $count transaksi',
                style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    fontWeight: FontWeight.w600)),
          ]),
        ),
        const SizedBox(width: 12),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(_fmtRp(total),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          GestureDetector(
            onTap: onExport,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.18),
              ),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.download_rounded, color: Colors.white, size: 13),
                SizedBox(width: 4),
                Text('Ekspor',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w700)),
              ]),
            ),
          ),
        ]),
      ]),
    );
  }
}

class _TxList extends StatelessWidget {
  final List<WalletTransaction> transactions;
  final String Function(WalletTransaction) catLabel;
  final String Function(WalletTransaction) noteLabel;
  final Color accentAmount;

  const _TxList({
    required this.transactions,
    required this.catLabel,
    required this.noteLabel,
    required this.accentAmount,
  });

  @override
  Widget build(BuildContext context) {
    if (transactions.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: AppColors.primaryBrand.withValues(alpha: 0.06),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.receipt_long_outlined,
                size: 30, color: AppColors.textCaption),
          ),
          const SizedBox(height: 14),
          const Text('Belum ada transaksi',
              style: TextStyle(
                  color: AppColors.textCaption,
                  fontWeight: FontWeight.w700,
                  fontSize: 14)),
          const SizedBox(height: 4),
          const Text('Transaksi akan muncul di sini',
              style: TextStyle(color: AppColors.textCaption, fontSize: 12)),
        ]),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      itemCount: transactions.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, i) {
        final tx = transactions[i];
        final cat = catLabel(tx);
        final note = noteLabel(tx);
        final isIncome = tx.type == 'masuk';

        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: AppColors.border),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.03),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(children: [
            // Left accent bar
            Container(
              width: 4,
              height: 76,
              color: accentAmount,
            ),
            // Icon
            Container(
              width: 40,
              height: 40,
              margin: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: accentAmount.withValues(alpha: 0.08),
              ),
              child: Icon(
                isIncome
                    ? Icons.arrow_downward_rounded
                    : Icons.arrow_upward_rounded,
                size: 18,
                color: accentAmount,
              ),
            ),
            // Content
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(note == '-' ? cat : note,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textTitle)),
                    const SizedBox(height: 3),
                    Text(
                      '${_fmtDate(tx.tanggal)} • '
                      '${tx.waktu.isNotEmpty ? tx.waktu : '-'} • '
                      '${_walletLabel(tx.walletId)}',
                      style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          color: AppColors.textCaption),
                    ),
                    if (note != '-') ...[
                      const SizedBox(height: 5),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppColors.primaryBrand.withValues(alpha: 0.07),
                        ),
                        child: Text(cat,
                            style: const TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w700,
                                color: AppColors.primaryBrand)),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            // Amount
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 12, 14, 12),
              child: Text(_fmtRp(tx.nominal.abs()),
                  style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w900,
                      color: accentAmount)),
            ),
          ]),
        );
      },
    );
  }
}

