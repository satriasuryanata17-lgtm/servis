import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../core/theme.dart';

// SHARED KASIR NAVIGATION RAIL
// Used by all screens on tablet & landscape mode
// Mirrors the dashboard NavigationRail style exactly.

class KasirNavRail extends StatelessWidget {
  /// 0=Dashboard, 1=Kasir, 2=Produk, 3=Laporan, 4=Setting
  /// -1 means no item is selected (sub-page)
  final int selectedIndex;
  final bool showBackButton;

  const KasirNavRail({
    super.key,
    this.selectedIndex = -1,
    this.showBackButton = true,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.primaryDark,
      child: SafeArea(
        child: NavigationRail(
          backgroundColor: Colors.transparent,
          selectedIndex: selectedIndex < 0 ? null : selectedIndex,
          extended: false,
          minWidth: 72,
          labelType: NavigationRailLabelType.selected,
          selectedLabelTextStyle: GoogleFonts.inter(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
          unselectedLabelTextStyle: GoogleFonts.inter(
            color: Colors.white54,
            fontSize: 11,
          ),
          selectedIconTheme: const IconThemeData(color: Colors.white, size: 24),
          unselectedIconTheme:
              const IconThemeData(color: Colors.white54, size: 22),
          indicatorColor: Colors.white.withValues(alpha: 0.15),
          leading: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Column(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.15),
                    shape: BoxShape.rectangle,
                  ),
                  child: const Icon(Icons.storefront_rounded,
                      color: Colors.white, size: 22),
                ),
                if (showBackButton) ...[
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Icon(Icons.arrow_back_ios_new_rounded,
                          color: Colors.white54, size: 14),
                    ),
                  ),
                ],
              ],
            ),
          ),
          destinations: const [
            NavigationRailDestination(
              icon: Icon(Icons.dashboard_outlined),
              selectedIcon: Icon(Icons.dashboard_rounded),
              label: Text('Dashboard'),
            ),
            NavigationRailDestination(
              icon: Icon(Icons.point_of_sale_outlined),
              selectedIcon: Icon(Icons.point_of_sale_rounded),
              label: Text('Transaksi'),
            ),
            NavigationRailDestination(
              icon: Icon(Icons.dry_cleaning_outlined),
              selectedIcon: Icon(Icons.dry_cleaning_rounded),
              label: Text('Layanan'),
            ),
            NavigationRailDestination(
              icon: Icon(Icons.list_alt_outlined),
              selectedIcon: Icon(Icons.list_alt_rounded),
              label: Text('Pesanan'),
            ),
            NavigationRailDestination(
              icon: Icon(Icons.assignment_outlined),
              selectedIcon: Icon(Icons.assignment_rounded),
              label: Text('Riwayat'),
            ),
            NavigationRailDestination(
              icon: Icon(Icons.insert_chart_outlined),
              selectedIcon: Icon(Icons.insert_chart_rounded),
              label: Text('Laporan'),
            ),
            NavigationRailDestination(
              icon: Icon(Icons.people_outline_rounded),
              selectedIcon: Icon(Icons.people_rounded),
              label: Text('Pelanggan'),
            ),
            NavigationRailDestination(
              icon: Icon(Icons.sync_rounded),
              selectedIcon: Icon(Icons.sync_rounded),
              label: Text('Sinkron'),
            ),
            NavigationRailDestination(
              icon: Icon(Icons.settings_outlined),
              selectedIcon: Icon(Icons.settings_rounded),
              label: Text('Pengaturan'),
            ),
          ],
          onDestinationSelected: (index) {
            switch (index) {
              case 0:
                Navigator.pushNamedAndRemoveUntil(
                    context, '/dashboard', (_) => false);
                break;
              case 1:
                Navigator.pushNamed(context, '/transaksi');
                break;
              case 2:
                Navigator.pushNamed(context, '/produk');
                break;
              case 3:
                Navigator.pushNamed(context, '/pesanan');
                break;
              case 4:
                Navigator.pushNamed(context, '/riwayat');
                break;
              case 5:
                Navigator.pushNamed(context, '/laporan');
                break;
              case 6:
                Navigator.pushNamed(context, '/pelanggan');
                break;
              case 7:
                Navigator.pushNamed(context, '/juragan_sync');
                break;
              case 8:
                Navigator.pushNamed(context, '/setting');
                break;
            }
          },
        ),
      ),
    );
  }
}

// RESPONSIVE HELPERS

bool isTabletScreen(BuildContext context) =>
    MediaQuery.of(context).size.shortestSide >= 600;

bool isLandscapeScreen(BuildContext context) =>
    MediaQuery.of(context).orientation == Orientation.landscape;

/// Wraps any screen body with NavigationRail on tablet/landscape.
/// [body] is the main screen content.
/// [selectedIndex] is which rail item is active (-1 for sub-pages).
/// [backgroundColor] defaults to the standard bg.
Widget buildResponsiveScaffold({
  required BuildContext context,
  required Widget body,
  int selectedIndex = -1,
  bool showBackButton = true,
  Color backgroundColor = const Color(0xFFF6F7F9),
  PreferredSizeWidget? appBar,
  Widget? bottomNavigationBar,
  Widget? floatingActionButton,
}) {
  final isTablet = isTabletScreen(context);
  final isLandscape = isLandscapeScreen(context);

  if (isTablet || isLandscape) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: appBar,
      bottomNavigationBar: bottomNavigationBar,
      floatingActionButton: floatingActionButton,
      body: SafeArea(
        child: Row(
          children: [
            KasirNavRail(
              selectedIndex: selectedIndex,
              showBackButton: showBackButton,
            ),
            // Removed divider for seamless transition
            Expanded(child: body),
          ],
        ),
      ),
    );
  }

  return Scaffold(
    backgroundColor: backgroundColor,
    appBar: appBar,
    body: body,
    bottomNavigationBar: bottomNavigationBar,
    floatingActionButton: floatingActionButton,
  );
}

