import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../widgets/kasir_drawer.dart';
import 'pengaturan_servis_screen.dart';
import 'riwayat_pesanan_terhapus_screen.dart';
import 'struk_screen.dart';
import 'detail_transaksi_piutang_screen.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';
import 'main_shell.dart';
import '../widgets/kasir_dialog.dart';
import '../utils/transaction_code_formatter.dart';

const Color _kBrand = AppColors.primaryBrand;

String _formatNoPesanan(Transaction tx) {
  return TransactionCodeFormatter.format(
    id: tx.id ?? 0,
    createdAt: tx.createdAt,
    transactionCode: tx.transactionCode,
  );
}

String _fmtRp(int n) {
  final s = n.toString();
  final buf = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
    buf.write(s[i]);
  }
  return 'Rp$buf';
}

String? _extractJenis(String? note) {
  if (note == null || note.isEmpty) return null;
  final match = RegExp(r'Jenis:\s*([^.]+)').firstMatch(note);
  return match?.group(1)?.trim();
}

// SCREEN

class PesananScreen extends ConsumerStatefulWidget {
  const PesananScreen({super.key});

  @override
  ConsumerState<PesananScreen> createState() => _PesananScreenState();
}

class _PesananScreenState extends ConsumerState<PesananScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchCtrl = TextEditingController();

  bool _isWarungProfileComplete = false;
  bool _loadingProfile = true;
  String _search = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _checkWarungProfile();
  }

  Future<void> _checkWarungProfile() async {
    final complete = await DBHelper.instance.isWarungProfileComplete();
    if (!mounted) return;
    setState(() {
      _isWarungProfileComplete = complete;
      _loadingProfile = false;
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final transactions = ref.watch(transactionsProvider);
    final wide = isTabletDevice(context) || isLandscape(context);

    return KasirResponsiveScaffold(
      showAppBar: false,
      title: 'Daftar Pesanan Servis',
      navIndex: 3,
      drawer: const KasirDrawer(),
      backgroundColor: Colors.white,
      body: wide
          ? Row(
              children: [
                _sidebar(transactions),
                Expanded(child: _mainArea(transactions)),
              ],
            )
          : SafeArea(
              bottom: false,
              child: Column(
                children: [
                  _TopBar(
                    searchCtrl: _searchCtrl,
                    tabController: _tabController,
                    onSearchChanged: (v) => setState(() => _search = v),
                    onTrash: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const RiwayatPesananTerhapusScreen()),
                    ),
                    transactions: transactions,
                  ),
                  _buildContent(transactions, false),
                ],
              ),
            ),
    );
  }

  Widget _mainArea(List<Transaction> transactions) {
    if (_loadingProfile) {
      return const Center(child: CircularProgressIndicator(color: _kBrand));
    }
    final activeStaff = ref.watch(activeStaffProvider);
    final isStaffAdmin = activeStaff == null ||
        activeStaff.role.toLowerCase().contains('admin') ||
        activeStaff.role.toLowerCase().contains('owner');

    if (!_isWarungProfileComplete) {
      return _BukaFiturPesananView(
        isStaffAdmin: isStaffAdmin,
        onTap: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const PengaturanservisScreen()),
          );
          _checkWarungProfile();
        },
      );
    }

    final status = _tabController.index == 0
        ? 'semua'
        : (_tabController.index == 1 ? 'baru' : 'selesai');

    return Column(
      children: [
        // Top row: Title + Search
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
          child: Row(
            children: [
              const Flexible(
                child: Text('Daftar Pesanan Servis',
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF1E293B))),
              ),
              const Spacer(),
              Container(
                width: 320,
                height: 44,
                decoration: const BoxDecoration(
                  color: Color(0xFFF1F5F9),
                  borderRadius: BorderRadius.zero,
                ),
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (v) => setState(() => _search = v),
                  decoration: const InputDecoration(
                    hintText: 'Cari Pesanan...',
                    hintStyle: TextStyle(fontSize: 13, color: Colors.black38),
                    prefixIcon:
                        Icon(Icons.search, color: Colors.black38, size: 20),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 11),
                  ),
                ),
              ),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: _PesananListTab(
            status: status,
            search: _search,
            transactions: transactions,
          ),
        ),
      ],
    );
  }

  Widget _sidebar(List<Transaction> transactions) {
    final orders = transactions
        .where((t) =>
            t.paymentMethod == 'Pesanan' ||
            t.paymentMethod == 'buat_pesanan' ||
            (t.orderType != null && t.orderType!.isNotEmpty))
        .toList();
    final newOrders = orders.where((t) => t.amountPaid < t.grandTotal).length;
    final totalSales = orders.fold<int>(0, (sum, t) => sum + t.grandTotal);

    return Container(
      width: 260,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(right: BorderSide(color: Color(0xFFEEEEEE))),
      ),
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.only(bottom: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 8, 16, 12),
                    child: Text('STATUS PESANAN',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: Colors.grey,
                            letterSpacing: 1.2)),
                  ),
                  _sidebarItem('Semua Pesanan', _tabController.index == 0, () {
                    setState(() => _tabController.index = 0);
                  }, badgeCount: newOrders),
                  _sidebarItem('Pesanan Masuk', _tabController.index == 1, () {
                    setState(() => _tabController.index = 1);
                  }, badgeCount: newOrders),
                  _sidebarItem('Pesanan Selesai', _tabController.index == 2,
                      () {
                    setState(() => _tabController.index = 2);
                  }),
                  const SizedBox(height: 24),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 0, 16, 12),
                    child: Text('RINGKASAN',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: Colors.grey,
                            letterSpacing: 1.2)),
                  ),
                  _miniStatCard('Total Pesanan', '${orders.length}',
                      Icons.receipt_long_rounded, Colors.blue),
                  _miniStatCard('Pesanan Baru', '$newOrders',
                      Icons.pending_actions_rounded, Colors.orange),
                  _miniStatCard('Total Omzet', _fmtRp(totalSales),
                      Icons.payments_rounded, const Color(0xFF059669)),
                ],
              ),
            ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                borderRadius: BorderRadius.zero,
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const RiwayatPesananTerhapusScreen()),
                  ),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.inventory_2_outlined,
                            size: 18, color: Color(0xFF64748B)),
                        SizedBox(width: 12),
                        Text('Riwayat Terhapus',
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF64748B))),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sidebarItem(String label, bool selected, VoidCallback onTap,
      {int badgeCount = 0}) {
    return ListTile(
      title: Row(
        children: [
          Expanded(
            child: Text(label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                  color: selected ? _kBrand : Colors.black87,
                )),
          ),
          if (badgeCount > 0)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: const BoxDecoration(
                color: Colors.red,
                shape: BoxShape.circle,
              ),
              child: Text(
                '$badgeCount',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 9,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
      trailing: selected
          ? const Icon(Icons.check_circle, size: 18, color: _kBrand)
          : null,
      onTap: onTap,
      dense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      selected: selected,
      selectedTileColor: _kBrand.withValues(alpha: 0.05),
    );
  }

  Widget _miniStatCard(String label, String value, IconData icon, Color color) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.05),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          children: [
            Icon(icon, size: 18, color: color),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          fontSize: 10,
                          color: Colors.grey,
                          fontWeight: FontWeight.w500)),
                  Text(value,
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: color)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(List<Transaction> transactions, bool isWide) {
    if (_loadingProfile) {
      return const Expanded(
          child: Center(child: CircularProgressIndicator(color: _kBrand)));
    }
    final activeStaff = ref.watch(activeStaffProvider);
    final isStaffAdmin = activeStaff == null ||
        activeStaff.role.toLowerCase().contains('admin') ||
        activeStaff.role.toLowerCase().contains('owner');

    if (!_isWarungProfileComplete) {
      return Expanded(
        child: _BukaFiturPesananView(
          isStaffAdmin: isStaffAdmin,
          onTap: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => const PengaturanservisScreen()),
            );
            _checkWarungProfile();
          },
        ),
      );
    }

    if (isWide) {
      final status = _tabController.index == 0
          ? 'semua'
          : (_tabController.index == 1 ? 'baru' : 'selesai');
      return Expanded(
        child: _PesananListTab(
          status: status,
          search: _search,
          transactions: transactions,
        ),
      );
    }

    return Expanded(
      child: TabBarView(
        controller: _tabController,
        children: [
          _PesananListTab(
              status: 'semua', search: _search, transactions: transactions),
          _PesananListTab(
              status: 'baru', search: _search, transactions: transactions),
          _PesananListTab(
              status: 'selesai', search: _search, transactions: transactions),
        ],
      ),
    );
  }
}

// ORIGINAL TOP BAR (phone)

class _TopBar extends StatelessWidget {
  final TextEditingController searchCtrl;
  final TabController tabController;
  final ValueChanged<String> onSearchChanged;
  final VoidCallback onTrash;
  final List<Transaction> transactions;

  const _TopBar({
    required this.searchCtrl,
    required this.tabController,
    required this.onSearchChanged,
    required this.onTrash,
    required this.transactions,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 10, 12, 8),
          child: Row(
            children: [
              Builder(
                builder: (ctx) => IconButton(
                  icon: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(height: 2, width: 20, color: _kBrand),
                      const SizedBox(height: 4),
                      Container(height: 2, width: 14, color: _kBrand),
                      const SizedBox(height: 4),
                      Container(height: 2, width: 20, color: _kBrand),
                    ],
                  ),
                  onPressed: () {
                    final shell = ShellScope.of(ctx);
                    if (shell != null) {
                      shell.openDrawer?.call();
                    } else {
                      Scaffold.of(ctx).openDrawer();
                    }
                  },
                  padding: const EdgeInsets.all(8),
                  constraints:
                      const BoxConstraints(minWidth: 36, minHeight: 36),
                ),
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Container(
                  height: 44,
                  decoration: const BoxDecoration(
                    color: Color(0xFFF2F2F4),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: TextField(
                    controller: searchCtrl,
                    onChanged: onSearchChanged,
                    style: const TextStyle(fontSize: 14, color: Colors.black87),
                    decoration: const InputDecoration(
                      hintText: 'Cari No. Transaksi/Nama Pelanggan',
                      hintStyle: TextStyle(fontSize: 13, color: Colors.black38),
                      prefixIcon:
                          Icon(Icons.search, color: Colors.black38, size: 20),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 12),
                      isDense: true,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: onTrash,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: const BoxDecoration(
                      color: _kBrand, borderRadius: BorderRadius.zero),
                  child: const Icon(Icons.inventory_2_outlined,
                      color: Colors.white, size: 22),
                ),
              ),
            ],
          ),
        ),
        TabBar(
          controller: tabController,
          indicatorColor: _kBrand,
          indicatorWeight: 2.5,
          indicatorSize: TabBarIndicatorSize.tab,
          dividerColor: Colors.grey.shade200,
          labelColor: _kBrand,
          unselectedLabelColor: Colors.black45,
          labelStyle:
              const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
          unselectedLabelStyle:
              const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
          tabs: [
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('Semua'),
                  if (transactions
                      .where((t) =>
                          (t.paymentMethod == 'Pesanan' ||
                              t.paymentMethod == 'buat_pesanan' ||
                              (t.orderType != null &&
                                  t.orderType!.isNotEmpty)) &&
                          t.amountPaid < t.grandTotal)
                      .isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(left: 6),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                            color: Colors.red, shape: BoxShape.circle),
                        child: Text(
                          '${transactions.where((t) => (t.paymentMethod == 'Pesanan' || t.paymentMethod == 'buat_pesanan' || (t.orderType != null && t.orderType!.isNotEmpty)) && t.amountPaid < t.grandTotal).length}',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('Pesanan Masuk'),
                  if (transactions
                      .where((t) =>
                          (t.paymentMethod == 'Pesanan' ||
                              t.paymentMethod == 'buat_pesanan' ||
                              (t.orderType != null &&
                                  t.orderType!.isNotEmpty)) &&
                          t.amountPaid < t.grandTotal)
                      .isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(left: 6),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                            color: Colors.red, shape: BoxShape.circle),
                        child: Text(
                          '${transactions.where((t) => (t.paymentMethod == 'Pesanan' || t.paymentMethod == 'buat_pesanan' || (t.orderType != null && t.orderType!.isNotEmpty)) && t.amountPaid < t.grandTotal).length}',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const Tab(text: 'Pesanan Selesai'),
          ],
        ),
      ],
    );
  }
}

// BUKA FITUR VIEW

class _BukaFiturPesananView extends StatelessWidget {
  final VoidCallback onTap;
  final bool isStaffAdmin;
  const _BukaFiturPesananView(
      {required this.onTap, required this.isStaffAdmin});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.storefront_outlined,
                size: 72, color: Colors.black26),
            const SizedBox(height: 18),
            const Text('Buka Layanan Servis',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87)),
            const SizedBox(height: 10),
            Text(
              isStaffAdmin
                  ? 'Lengkapi profil servis terlebih dahulu agar fitur pesanan aktif.'
                  : 'Silakan hubungi Owner untuk melengkapi profil servis agar fitur pesanan aktif.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 13, color: Colors.black54, height: 1.5),
            ),
            if (isStaffAdmin) ...[
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: onTap,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kBrand,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                    padding: const EdgeInsets.symmetric(vertical: 15),
                  ),
                  child: const Text('Pengaturan Toko',
                      style:
                          TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// PESANAN LIST TAB

class _PesananListTab extends StatelessWidget {
  final String status;
  final String search;
  final List<Transaction> transactions;

  const _PesananListTab({
    required this.status,
    required this.search,
    required this.transactions,
  });

  List<Transaction> _applyFilter() {
    final lowerSearch = search.trim().toLowerCase();
    return transactions.where((t) {
      final isPesanan = t.paymentMethod == 'Pesanan' ||
          t.paymentMethod == 'buat_pesanan' ||
          (t.orderType != null && t.orderType!.isNotEmpty);
      if (!isPesanan) return false;
      final isSelesai = t.amountPaid >= t.grandTotal;
      if (status == 'baru' && isSelesai) return false;
      if (status == 'selesai' && !isSelesai) return false;
      if (lowerSearch.isEmpty) return true;
      final name = t.customerName?.toLowerCase() ?? '';
      final id = t.id.toString();
      final noPesanan = _formatNoPesanan(t).toLowerCase();
      if (!name.contains(lowerSearch) &&
          !id.contains(lowerSearch) &&
          !noPesanan.contains(lowerSearch)) {
        return false;
      }
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final list = _applyFilter();
    if (list.isEmpty) {
      return const Center(
        child: Text('Belum ada pesanan',
            style: TextStyle(color: Colors.black38, fontSize: 14)),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      itemCount: list.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) => _PesananCard(tx: list[i]),
    );
  }
}

// PESANAN CARD

class _PesananCard extends ConsumerStatefulWidget {
  final Transaction tx;
  const _PesananCard({required this.tx});

  @override
  ConsumerState<_PesananCard> createState() => _PesananCardState();
}

class _PesananCardState extends ConsumerState<_PesananCard> {
  bool _expanded = false;
  bool _loadingItems = false;
  List<TransactionItem> _items = [];

  Future<void> _loadItems() async {
    if (_items.isNotEmpty) return;
    setState(() => _loadingItems = true);
    try {
      final items = await DBHelper.instance.getTransactionItems(widget.tx.id!);
      if (mounted) setState(() => _items = items);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Gagal memuat detail item. Silakan coba lagi.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ));
      }
    } finally {
      if (mounted) setState(() => _loadingItems = false);
    }
  }

  void _toggleExpand() {
    setState(() => _expanded = !_expanded);
    if (_expanded) _loadItems();
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final confirmed = await showKasirDeleteConfirmDialog(
      context,
      title: 'Hapus Pesanan?',
      message:
          'Pesanan akan dipindahkan ke riwayat terhapus. Stok barang akan dikembalikan otomatis.',
    );

    if (confirmed == true) {
      if (!mounted || !context.mounted) return;
      final messenger = ScaffoldMessenger.of(context);
      await ref
          .read(transactionsProvider.notifier)
          .deleteTransaction(widget.tx.id!);
      if (!mounted) return;
      messenger.showSnackBar(
        const SnackBar(
            content: Text('Pesanan telah dihapus'),
            backgroundColor: Colors.black87),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final activeStaff = ref.watch(activeStaffProvider);
    final isStaffAdmin = activeStaff == null ||
        activeStaff.role.toLowerCase().contains('admin') ||
        activeStaff.role.toLowerCase().contains('owner');

    final tx = widget.tx;
    final isSelesai = tx.amountPaid >= tx.grandTotal;
    final noPesanan = _formatNoPesanan(tx);
    final jenis = (tx.orderType != null && tx.orderType != 'Pesanan')
        ? tx.orderType
        : _extractJenis(tx.note);
    final pickup = tx.pickupSchedule;
    final dt = DateTime.tryParse(tx.createdAt);
    final dateLabel = dt == null
        ? tx.createdAt
        : DateFormat('dd MMM yyyy HH:mm', 'id').format(dt);

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFEEEEEE)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 4,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                      child: Wrap(
                        spacing: 6,
                        runSpacing: 4,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: isSelesai
                                  ? const Color(0xFFE8F5E9)
                                  : const Color(0xFFFFF8E1),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Text(
                              isSelesai
                                  ? 'Pesanan Selesai'
                                  : 'Pesanan Diproses',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: isSelesai
                                    ? Colors.green.shade700
                                    : Colors.orange.shade700,
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: isSelesai
                                  ? const Color(0xFFE8F5E9)
                                  : const Color(0xFFFFEBEE),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Text(
                              isSelesai ? 'Sudah Dibayar' : 'Belum Dibayar',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: isSelesai
                                    ? Colors.green.shade700
                                    : Colors.red.shade700,
                              ),
                            ),
                          ),
                          if (jenis != null)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: const Color(0xFFF1F5F9),
                                border:
                                    Border.all(color: const Color(0xFFE2E8F0)),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: Text(
                                jenis,
                                style: const TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF475569)),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ),
                          if (tx.servisStatus.isNotEmpty)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: _statusColor(tx.servisStatus)
                                    .withValues(alpha: 0.1),
                                borderRadius: BorderRadius.zero,
                                border: Border.all(
                                    color: _statusColor(tx.servisStatus)
                                        .withValues(alpha: 0.2)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(_statusIcon(tx.servisStatus),
                                      size: 12,
                                      color: _statusColor(tx.servisStatus)),
                                  const SizedBox(width: 4),
                                  Text(
                                    tx.servisStatus,
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                      color: _statusColor(tx.servisStatus),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          if (tx.kelengkapan != null &&
                              tx.kelengkapan!.isNotEmpty &&
                              tx.kelengkapan != 'None')
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFDF2F8),
                                border:
                                    Border.all(color: const Color(0xFFFBCFE8)),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.auto_awesome_rounded,
                                      size: 12, color: Color(0xFFDB2777)),
                                  const SizedBox(width: 4),
                                  Text(
                                    tx.kelengkapan!,
                                    style: const TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFFDB2777)),
                                  ),
                                ],
                              ),
                            ),
                          if (pickup != null && pickup.isNotEmpty)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: const Color(0xFFEFF6FF),
                                border:
                                    Border.all(color: const Color(0xFFDBEAFE)),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.access_time_rounded,
                                      size: 12, color: Color(0xFF2563EB)),
                                  const SizedBox(width: 4),
                                  Text(
                                    'Ambil: $pickup',
                                    style: const TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFF2563EB)),
                                  ),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.receipt_long_rounded,
                          color: Color(0xFF64748B), size: 20),
                      onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                                  StrukScreen(transactionId: tx.id!))),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      tooltip: 'Lihat Struk',
                    ),
                    const SizedBox(width: 16),
                    if (isStaffAdmin) ...[
                      IconButton(
                        icon: const Icon(AppIcons.recycleBin,
                            color: Colors.black26, size: 20),
                        onPressed: () => _confirmDelete(context),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        tooltip: 'Hapus Pesanan',
                      ),
                      const SizedBox(width: 12),
                    ],
                    GestureDetector(
                      onTap: _toggleExpand,
                      behavior: HitTestBehavior.opaque,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 4),
                        child: Icon(
                          _expanded
                              ? Icons.keyboard_arrow_up_rounded
                              : Icons.keyboard_arrow_down_rounded,
                          color: _kBrand,
                          size: 26,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                GestureDetector(
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => StrukScreen(transactionId: tx.id!))),
                  child: Text(
                    tx.customerName?.isNotEmpty == true
                        ? tx.customerName!
                        : 'Pelanggan Umum',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: Colors.black87),
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text('No. $noPesanan',
                        style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: _kBrand)),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: noPesanan));
                        ScaffoldMessenger.of(context)
                            .showSnackBar(const SnackBar(
                          content: Text('No. pesanan disalin'),
                          behavior: SnackBarBehavior.floating,
                          duration: Duration(seconds: 1),
                          backgroundColor: Colors.black87,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                        ));
                      },
                      child: const Icon(Icons.copy_rounded,
                          size: 15, color: _kBrand),
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                    '$dateLabel | Antrian ${tx.queueNumber > 0 ? tx.queueNumber : tx.id}',
                    style:
                        const TextStyle(fontSize: 12, color: Colors.black45)),
                if (!isSelesai) ...[
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => DetailTransaksiPiutangScreen(
                                  transactionId: tx.id!),
                            ));
                        ref.invalidate(transactionsProvider);
                        ref.invalidate(dashboardProvider);
                        ref.invalidate(walletBalanceProvider);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.check_circle_outline, size: 20),
                          SizedBox(width: 8),
                          Text('Selesaikan Pesanan',
                              style: TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          if (_expanded) ...[
            const Divider(height: 1, color: Color(0xFFEEEEEE)),
            if (_loadingItems)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                    child: SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: _kBrand))),
              )
            else if (_items.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                child: Text('Tidak ada item',
                    style: TextStyle(fontSize: 12, color: Colors.black38)),
              )
            else
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Expanded(
                            child: Text('Produk',
                                style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.black45))),
                        Text('Qty',
                            style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: Colors.black45)),
                        SizedBox(width: 20),
                        Text('Subtotal',
                            style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: Colors.black45)),
                      ],
                    ),
                    const SizedBox(height: 6),
                    const Divider(height: 1, color: Color(0xFFEEEEEE)),
                    const SizedBox(height: 4),
                    ..._items.map((item) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5),
                          child: Row(
                            children: [
                              Expanded(
                                  child: Text(item.productName,
                                      style: const TextStyle(
                                          fontSize: 13,
                                          color: Colors.black87))),
                              Text('x${item.qty}',
                                  style: const TextStyle(
                                      fontSize: 13, color: Colors.black54)),
                              const SizedBox(width: 20),
                              Text(_fmtRp(item.subtotal),
                                  style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.black87)),
                            ],
                          ),
                        )),
                    const Padding(
                        padding: EdgeInsets.only(top: 6),
                        child: Divider(height: 1, color: Color(0xFFEEEEEE))),
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Total',
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black54)),
                          Text(_fmtRp(tx.grandTotal),
                              style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: _kBrand)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ],
      ),
    );
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'pengecekan':
        return const Color(0xFF3B82F6);
      case 'kering':
        return const Color(0xFFF59E0B);
      case 'perbaikan':
        return const Color(0xFF8B5CF6);
      case 'siap':
      case 'selesai':
        return const Color(0xFF10B981);
      default:
        return const Color(0xFF64748B);
    }
  }

  IconData _statusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'pengecekan':
        return Icons.water_drop_outlined;
      case 'kering':
        return Icons.wb_sunny_outlined;
      case 'perbaikan':
        return Icons.iron_outlined;
      case 'siap':
      case 'selesai':
        return Icons.check_circle_outline;
      default:
        return Icons.handyman_outlined;
    }
  }
}

