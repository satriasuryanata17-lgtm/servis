import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'pengaturan_profil_screen.dart';
import 'pengaturan_servis_screen.dart';
import 'pengaturan_struk_screen.dart';
import 'pengaturan_hardware_screen.dart';
import 'pengaturan_pembayaran_screen.dart';
import 'kategori_keuangan_screen.dart';
import 'ubah_kata_sandi_screen.dart';
import 'notifikasi_screen.dart';
import 'target_penjualan_screen.dart';
import 'backup_restore_screen.dart';
import 'juragan_sync_screen.dart';
import 'pengaturan_update_screen.dart';
import 'pengaturan_shortcut_screen.dart';
import 'hukum_privasi_screen.dart';
import 'pusat_bantuan_screen.dart';
import 'kritik_saran_screen.dart';
// import 'admin/sync_settings_screen.dart';
import '../services/backup_service.dart';
import '../widgets/kasir_drawer.dart';
import '../widgets/admin_pin_dialog.dart';
import '../providers/providers.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';
import '../database/db_helper.dart';

import 'dart:io';

const Color _kBrand = AppColors.primaryBrand;

//
//  PENGATURAN SCREEN  --  Responsive (Phone + Tablet/Landscape)
//
class SettingScreen extends ConsumerStatefulWidget {
  const SettingScreen({super.key});

  @override
  ConsumerState<SettingScreen> createState() => _SettingScreenState();
}

class _SettingScreenState extends ConsumerState<SettingScreen> {
  // Tracks the selected item on tablet for a "master-detail" feel
  int? _selectedIndex;

  @override
  void initState() {
    super.initState();
    _checkBackupReminder();
  }

  Future<void> _checkBackupReminder() async {
    if (await BackupService.shouldRemindBackup()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content:
                const Text(' Sudah waktunya backup data! Tap untuk backup.'),
            action: SnackBarAction(
              label: 'Backup',
              onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const BackupRestoreScreen())),
            ),
            duration: const Duration(seconds: 6),
          ),
        );
      }
    }
  }

  List<
      ({
        IconData icon,
        String label,
        String subtitle,
        Widget? route,
        bool isPassword,
        bool isPin
      })> get _menuItems {
    final items = <({
      IconData icon,
      String label,
      String subtitle,
      Widget? route,
      bool isPassword,
      bool isPin
    })>[
      (
        icon: Icons.person_outline_rounded,
        label: 'Profil',
        subtitle: 'Atur data diri & foto profil',
        route: const PengaturanProfilScreen(),
        isPassword: false,
        isPin: false
      ),
      (
        icon: Icons.handyman_outlined,
        label: 'Usaha Servis',
        subtitle: 'Atur nama, alamat, logo, dan identitas usaha',
        route: const PengaturanservisScreen(),
        isPassword: false,
        isPin: false
      ),
      (
        icon: Icons.receipt_long_outlined,
        label: 'Struk & Buka Laci',
        subtitle: 'Format struk cetak dan laci otomatis',
        route: const PengaturanStrukScreen(),
        isPassword: false,
        isPin: false
      ),
      (
        icon: Icons.scale_outlined,
        label: 'Harga Layanan',
        subtitle: 'Atur pembulatan kuantitas layanan berbasis berat',
        route: const PengaturanHardwareScreen(),
        isPassword: false,
        isPin: false
      ),
      (
        icon: Icons.account_balance_wallet_outlined,
        label: 'Bank & QRIS',
        subtitle: 'Metode pembayaran',
        route: const PengaturanPembayaranScreen(),
        isPassword: false,
        isPin: false
      ),
      (
        icon: Icons.account_tree_outlined,
        label: 'Kategori Keuangan',
        subtitle: 'Atur kategori pemasukan dan pengeluaran',
        route: const KategoriKeuanganScreen(),
        isPassword: false,
        isPin: false
      ),
      (
        icon: Icons.notifications_outlined,
        label: 'Notifikasi',
        subtitle: 'Atur notifikasi',
        route: const NotifikasiScreen(),
        isPassword: false,
        isPin: false
      ),
      (
        icon: Icons.flag_outlined,
        label: 'Target Penjualan',
        subtitle: 'Target omzet harian',
        route: const TargetPenjualanScreen(),
        isPassword: false,
        isPin: false
      ),
      /*
      (
        icon: Icons.sync_alt_rounded,
        label: 'Juragan Sync',
        subtitle: 'Sinkronisasi Frontdesk & Workshop (LAN)',
        route: const SyncSettingsScreen(),
        isPassword: false,
        isPin: false
      ),
      */
      (
        icon: Icons.backup_outlined,
        label: 'Backup & Restore',
        subtitle: 'Cadangkan data',
        route: const BackupRestoreScreen(),
        isPassword: false,
        isPin: false
      ),
      (
        icon: Icons.sync_rounded,
        label: 'Sinkronisasi',
        subtitle: 'Sinkronisasi data HP dan laptop lewat Wi-Fi',
        route: const JuraganSyncScreen(),
        isPassword: false,
        isPin: false
      ),
      (
        icon: Icons.system_update_alt_rounded,
        label: 'Pembaruan Aplikasi',
        subtitle: 'Cek versi, update manual, dan cek otomatis',
        route: const PengaturanUpdateScreen(),
        isPassword: false,
        isPin: false
      ),
    ];

    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      items.add((
        icon: Icons.keyboard_outlined,
        label: 'Shortcut Keyboard',
        subtitle: 'Atur tombol cepat dekstop',
        route: const PengaturanShortcutScreen(),
        isPassword: false,
        isPin: false
      ));
    }

    items.add((
      icon: Icons.lock_outline_rounded,
      label: 'Ubah Kata Sandi',
      subtitle: 'Amankan akun & lisensi Anda',
      route: const UbahKataSandiScreen(),
      isPassword: true,
      isPin: false
    ));

    items.add((
      icon: Icons.lock_person_outlined,
      label: 'PIN Admin',
      subtitle: 'Atur PIN pengunci layar',
      route: null,
      isPassword: false,
      isPin: true
    ));

    items.add((
      icon: Icons.headset_mic_outlined,
      label: 'Pusat Bantuan',
      subtitle: 'FAQ & hubungi tim support',
      route: const PusatBantuanScreen(),
      isPassword: false,
      isPin: false
    ));

    items.add((
      icon: Icons.rate_review_outlined,
      label: 'Kritik & Saran',
      subtitle: 'Bantu kami terus berkembang',
      route: const KritikSaranScreen(),
      isPassword: false,
      isPin: false
    ));

    items.add((
      icon: Icons.balance_rounded,
      label: 'Hukum & Privasi',
      subtitle: 'Kebijakan privasi & syarat ketentuan',
      route: const HukumPrivasiScreen(),
      isPassword: false,
      isPin: false
    ));

    items.add((
      icon: Icons.delete_forever_outlined,
      label: 'Hapus Data',
      subtitle: 'Reset semua data transaksi & produk',
      route: null,
      isPassword: false,
      isPin: false
    ));

    items.add((
      icon: Icons.logout_rounded,
      label: 'Keluar Akun',
      subtitle: 'Hapus lisensi dari perangkat ini',
      route: null,
      isPassword: false,
      isPin: false
    ));

    return items;
  }

  void _navigateTo(int index) async {
    final item = _menuItems[index];

    if (item.label == 'Keluar Akun') {
      _confirmLogout();
      return;
    }

    if (item.label == 'Hapus Data') {
      _confirmResetData();
      return;
    }

    if (item.isPin) {
      _gantiPin();
      return;
    }

    if (item.route != null) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => item.route!));
    }
  }

  Future<void> _confirmResetData() async {
    final shouldContinue = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              color: const Color(0xFFFEF2F2),
              child: const Icon(Icons.warning_amber_rounded,
                  color: Color(0xFFDC2626), size: 22),
            ),
            const SizedBox(width: 10),
            const Text('Hapus Data',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Tindakan ini akan MENGHAPUS SEMUA data berikut secara permanen:',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              color: const Color(0xFFFEF2F2),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('\u2022 Semua transaksi & riwayat pesanan',
                      style:
                          TextStyle(fontSize: 12.5, color: Color(0xFF991B1B))),
                  SizedBox(height: 4),
                  Text('\u2022 Semua produk & layanan servis',
                      style:
                          TextStyle(fontSize: 12.5, color: Color(0xFF991B1B))),
                  SizedBox(height: 4),
                  Text('\u2022 Semua data pelanggan & karyawan',
                      style:
                          TextStyle(fontSize: 12.5, color: Color(0xFF991B1B))),
                  SizedBox(height: 4),
                  Text('\u2022 Laporan keuangan & riwayat stok',
                      style:
                          TextStyle(fontSize: 12.5, color: Color(0xFF991B1B))),
                ],
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Lisensi Anda TIDAK akan terhapus.',
              style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF166534)),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal', style: TextStyle(color: Colors.black54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFDC2626),
              foregroundColor: Colors.white,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            onPressed: () {
              Navigator.pop(ctx, true);
            },
            child: const Text('Lanjutkan'),
          ),
        ],
      ),
    );

    if (shouldContinue == true && mounted) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      await _confirmResetDataStep2();
    }
  }

  Future<void> _confirmResetDataStep2() async {
    final controller = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setStateDialog) => AlertDialog(
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          title: const Text('Konfirmasi Penghapusan',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          content: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Ketik  HAPUS DATA  untuk mengonfirmasi.',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: controller,
                  autofocus: true,
                  decoration: InputDecoration(
                    hintText: 'HAPUS DATA',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide(color: Colors.grey.shade300)),
                    focusedBorder: const OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide:
                            BorderSide(color: Color(0xFFDC2626), width: 1.5)),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                  ),
                  inputFormatters: [
                    TextInputFormatter.withFunction((old, newVal) =>
                        newVal.copyWith(
                            text: newVal.text.toUpperCase(),
                            selection: newVal.selection)),
                  ],
                  validator: (v) {
                    if ((v ?? '').trim() != 'HAPUS DATA') {
                      return 'Teks tidak sesuai';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child:
                  const Text('Batal', style: TextStyle(color: Colors.black54)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFDC2626),
                foregroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
              onPressed: () {
                if (!formKey.currentState!.validate()) return;
                FocusManager.instance.primaryFocus?.unfocus();
                Navigator.pop(ctx, true);
              },
              child: const Text('Hapus Semua Data'),
            ),
          ],
        ),
      ),
    );

    await Future<void>.delayed(const Duration(milliseconds: 250));
    controller.dispose();
    if (confirmed == true && mounted) {
      await _executeResetData();
    }
  }

  Future<void> _executeResetData() async {
    final rootNavigator = Navigator.of(context, rootNavigator: true);
    var loadingVisible = true;

    // Show loading
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const PopScope(
        canPop: false,
        child: AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          content: Row(
            children: [
              SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(strokeWidth: 2.5),
              ),
              SizedBox(width: 20),
              Expanded(
                child: Text('Menghapus semua data...'),
              ),
            ],
          ),
        ),
      ),
    );
    await WidgetsBinding.instance.endOfFrame;

    try {
      await DBHelper.instance.resetToFactory();

      if (mounted) {
        // Dismiss loading
        rootNavigator.pop();
        loadingVisible = false;
        await Future<void>.delayed(const Duration(milliseconds: 250));
        if (!mounted) return;

        // Show success & navigate to login
        await showDialog(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            title: const Row(
              children: [
                Icon(Icons.check_circle_rounded,
                    color: Color(0xFF16A34A), size: 26),
                SizedBox(width: 10),
                Expanded(
                  child: Text('Data Berhasil Dihapus',
                      style:
                          TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                ),
              ],
            ),
            content: const Text(
                'Semua data telah direset. Aplikasi akan kembali ke halaman login.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('OK',
                    style: TextStyle(
                        color: AppColors.primaryBrand,
                        fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        );

        if (mounted) {
          await Future<void>.delayed(const Duration(milliseconds: 250));
          rootNavigator.popUntil((route) => route.isFirst);
          await Future<void>.delayed(const Duration(milliseconds: 300));
          await ref.read(authProvider.notifier).logoutAndReset();
        }
      }
    } catch (e) {
      if (mounted) {
        if (loadingVisible && rootNavigator.canPop()) {
          rootNavigator.pop();
        }
        _snack('Gagal menghapus data: $e');
      }
    }
  }

  void _confirmLogout() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Keluar Akun'),
        content: const Text(
            'Apakah Anda yakin ingin menghapus lisensi dan keluar dari akun ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () async {
              // Tutup dialog
              Navigator.pop(ctx);

              // Reset status auth
              await ref.read(authProvider.notifier).logout();

              // Penting: Bersihkan seluruh tumpukan navigasi agar kembali ke root (Login/Splash)
              if (mounted) {
                Navigator.of(context, rootNavigator: true)
                    .pushNamedAndRemoveUntil('/', (route) => false);
              }
            },
            child: const Text('Ya, Keluar',
                style: TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
  }

  Future<void> _gantiPin() async {
    final profile = ref.read(profilProvider);
    final hadAdminPin = profile.hasAdminPin;
    final newPin = await ChangePinDialog.show(
      context,
      requiresCurrentPin: hadAdminPin,
      verifyCurrentPin: (pin) =>
          ref.read(profilProvider.notifier).verifyPin(pin),
      hint:
          hadAdminPin ? null : 'PIN admin belum diatur. Buat PIN 6 digit baru.',
    );
    if (newPin == null || !mounted) return;
    try {
      await ref.read(profilProvider.notifier).updateAdminPin(newPin);
      if (mounted) {
        _snack(
          hadAdminPin
              ? 'PIN Admin berhasil diubah'
              : 'PIN Admin berhasil diatur',
        );
      }
    } catch (e) {
      if (mounted) {
        _snack(
          hadAdminPin
              ? 'Gagal mengubah PIN. Pastikan PIN lama sudah benar.'
              : 'Gagal mengatur PIN. Silakan coba lagi.',
        );
      }
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: Colors.black87,
      behavior: SnackBarBehavior.floating,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return KasirResponsiveScaffold(
      title: 'Pengaturan',
      showNavRail: true,
      navIndex: 9,
      drawer: const KasirDrawer(),
      backgroundColor: AppColors.background,
      body: isTabletDevice(context) || isLandscape(context)
          ? _buildTablet()
          : _buildPhone(),
    );
  }

  Widget _buildPhone() {
    final sections = <_SettingSection>[
      _SettingSection(
        title: 'Akun & Usaha',
        items: _menuItems
            .where((item) => {
                  'Profil',
                  'Usaha Servis',
                  'Ubah Kata Sandi',
                  'PIN Admin',
                }.contains(item.label))
            .toList(),
      ),
      _SettingSection(
        title: 'Operasional',
        items: _menuItems
            .where((item) => {
                  'Struk & Buka Laci',
                  'Harga Layanan',
                  'Bank & QRIS',
                  'Kategori Keuangan',
                  'Notifikasi',
                  'Target Penjualan',
                  'Shortcut Keyboard',
                }.contains(item.label))
            .toList(),
      ),
      _SettingSection(
        title: 'Data & Sinkronisasi',
        items: _menuItems
            .where((item) => {
                  'Backup & Restore',
                  'Sinkronisasi',
                  'Pembaruan Aplikasi',
                  'Hapus Data',
                }.contains(item.label))
            .toList(),
      ),
      _SettingSection(
        title: 'Bantuan',
        items: _menuItems
            .where((item) => {
                  'Pusat Bantuan',
                  'Kritik & Saran',
                  'Hukum & Privasi',
                  'Keluar Akun',
                }.contains(item.label))
            .toList(),
      ),
    ].where((section) => section.items.isNotEmpty).toList();

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      itemCount: sections.length,
      itemBuilder: (context, sectionIndex) {
        final section = sections[sectionIndex];
        return Padding(
          padding: EdgeInsets.only(
              bottom: sectionIndex == sections.length - 1 ? 0 : 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(2, 0, 2, 8),
                child: Text(
                  section.title,
                  style: const TextStyle(
                    color: Color(0xFF667085),
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              DecoratedBox(
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: const Color(0xFFE5E7EB)),
                ),
                child: Column(
                  children: [
                    for (var i = 0; i < section.items.length; i++) ...[
                      _buildPhoneSettingItem(section.items[i]),
                      if (i != section.items.length - 1)
                        const Divider(
                          height: 1,
                          thickness: 1,
                          indent: 58,
                          color: Color(0xFFE5E7EB),
                        ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPhoneSettingItem(
    ({
      IconData icon,
      String label,
      String subtitle,
      Widget? route,
      bool isPassword,
      bool isPin,
    }) item,
  ) {
    final index =
        _menuItems.indexWhere((menuItem) => menuItem.label == item.label);

    return InkWell(
      onTap: index < 0 ? null : () => _navigateTo(index),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            SizedBox(
              width: 32,
              height: 32,
              child: Icon(item.icon, color: _kBrand, size: 21),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                item.label,
                style: const TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF101828),
                ),
              ),
            ),
            const SizedBox(width: 12),
            const Icon(Icons.chevron_right_rounded, color: _kBrand, size: 22),
          ],
        ),
      ),
    );
  }

  Widget _buildTablet() {
    final isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;
    final isShort = MediaQuery.of(context).size.height < 500;

    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 900),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(
                  24,
                  (isLandscape && isShort) ? 10 : 20,
                  24,
                  (isLandscape && isShort) ? 6 : 12),
              child: const Text(
                'Menu Pengaturan',
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: Colors.black45,
                    letterSpacing: 0.8),
              ),
            ),
            Expanded(
              child: GridView.builder(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: (isLandscape && isShort) ? 4.2 : 3.6,
                ),
                itemCount: _menuItems.length,
                itemBuilder: (_, i) {
                  final item = _menuItems[i];
                  final selected = _selectedIndex == i;
                  return Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.zero,
                      onTap: () {
                        setState(() => _selectedIndex = i);
                        _navigateTo(i);
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 160),
                        padding: EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: (isLandscape && isShort) ? 8 : 12),
                        decoration: BoxDecoration(
                          color: selected
                              ? _kBrand.withValues(alpha: 0.08)
                              : const Color(0xFFF8F8F8),
                          borderRadius: BorderRadius.zero,
                          border: Border.all(
                            color: selected
                                ? _kBrand.withValues(alpha: 0.35)
                                : const Color(0xFFEEEEEE),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: (isLandscape && isShort) ? 34 : 40,
                              height: (isLandscape && isShort) ? 34 : 40,
                              decoration: BoxDecoration(
                                color: _kBrand.withValues(alpha: 0.10),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: Icon(item.icon,
                                  color: _kBrand,
                                  size: (isLandscape && isShort) ? 18 : 20),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    item.label,
                                    style: TextStyle(
                                        fontSize:
                                            (isLandscape && isShort) ? 13 : 14,
                                        fontWeight: FontWeight.w600,
                                        color: selected
                                            ? _kBrand
                                            : Colors.black87),
                                  ),
                                  if (!isShort)
                                    Text(
                                      item.subtitle,
                                      style: const TextStyle(
                                          fontSize: 11.5,
                                          color: Colors.black45),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                ],
                              ),
                            ),
                            Icon(Icons.chevron_right,
                                color: selected ? _kBrand : Colors.black26,
                                size: 20),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SettingSection {
  const _SettingSection({
    required this.title,
    required this.items,
  });

  final String title;
  final List<
      ({
        IconData icon,
        String label,
        String subtitle,
        Widget? route,
        bool isPassword,
        bool isPin,
      })> items;
}

