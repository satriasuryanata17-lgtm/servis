import 'package:flutter/material.dart';
import 'daftar_pelanggan_screen.dart';
import 'transaksi_pelanggan_screen.dart';
import '../core/theme.dart';
import '../widgets/kasir_drawer.dart';
import 'responsive_layout.dart';

const Color _kBrand = AppColors.primaryBrand;

class PelangganMenuScreen extends StatelessWidget {
  const PelangganMenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tablet = KasirLayout.isTablet(context);
    final landscape = KasirLayout.isLandscape(context);

    return KasirResponsiveScaffold(
      title: 'Pelanggan',
      navIndex: 5,
      drawer: const KasirDrawer(),
      body: _PelangganContent(
        useGrid: tablet,
        crossAxisCount: tablet ? (landscape ? 3 : 2) : 1,
      ),
    );
  }
}

class _PelangganContent extends StatelessWidget {
  final bool useGrid;
  final int crossAxisCount;

  const _PelangganContent({
    required this.useGrid,
    required this.crossAxisCount,
  });

  @override
  Widget build(BuildContext context) {
    final menuItems = [
      _MenuData(
        title: 'Daftar Pelanggan',
        subtitle: 'Lihat dan kelola semua data pelanggan.',
        icon: Icons.people_alt_outlined,
        color: const Color(0xFF1E4A8E),
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const DaftarPelangganScreen())),
      ),
      _MenuData(
        title: 'Transaksi Pelanggan',
        subtitle: 'Lihat jumlah dan riwayat transaksi pelanggan.',
        icon: Icons.receipt_long_outlined,
        color: const Color(0xFF1E4A8E),
        onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => const TransaksiPelangganScreen())),
      ),
    ];

    return useGrid ? _buildGrid(context, menuItems) : _buildList(menuItems);
  }

  Widget _buildList(List<_MenuData> items) {
    return ListView.separated(
      itemCount: items.length,
      separatorBuilder: (_, __) =>
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
      itemBuilder: (ctx, i) => _ListMenuItem(data: items[i]),
    );
  }

  Widget _buildGrid(BuildContext context, List<_MenuData> items) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: GridView.count(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 1.6,
        shrinkWrap: true,
        children: items.map((d) => _GridMenuCard(data: d)).toList(),
      ),
    );
  }
}

class _MenuData {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _MenuData({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
  });
}

class _ListMenuItem extends StatelessWidget {
  final _MenuData data;
  const _ListMenuItem({required this.data});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: data.onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: data.color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.zero,
              ),
              child: Icon(data.icon, color: data.color, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(data.title,
                      style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87)),
                  const SizedBox(height: 3),
                  Text(data.subtitle,
                      style:
                          const TextStyle(fontSize: 13, color: Colors.black45)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: _kBrand, size: 24),
          ],
        ),
      ),
    );
  }
}

class _GridMenuCard extends StatelessWidget {
  final _MenuData data;
  const _GridMenuCard({required this.data});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: data.onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          border: Border.all(color: const Color(0xFFE8E8E8)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: data.color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.zero,
              ),
              child: Icon(data.icon, color: data.color, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(data.title,
                      style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: Colors.black87)),
                  const SizedBox(height: 4),
                  Text(data.subtitle,
                      style:
                          const TextStyle(fontSize: 12, color: Colors.black45),
                      maxLines: 2),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios_rounded, size: 16, color: data.color),
          ],
        ),
      ),
    );
  }
}

