import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';

import 'package:share_plus/share_plus.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:printing/printing.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../services/whatsapp_helper.dart';
import '../widgets/kasir_dialog.dart';
import 'pengaturan_struk_screen.dart';
import '../core/theme.dart';
import '../services/cash_drawer_service.dart';
import '../services/receipt_print_service.dart';
import '../services/remote_print_service.dart';
import '../utils/transaction_code_formatter.dart';
import 'package:barcode_widget/barcode_widget.dart';

// HELPERS
const Color _kBrand = AppColors.primaryBrand;
const Color _kTealDark = Color(0xFF1E40AF);
const Color _kBg = Color(0xFFF5F7FA);
const String _poweredWatermarkText = 'Powered Juragan Kasir Servis';

String _f(int n) {
  if (n == 0) return '0';
  String s = n.toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return r;
}

String _fmtD(double n) {
  return n
      .toStringAsFixed(2)
      .replaceAll(RegExp(r'0+$'), '')
      .replaceAll(RegExp(r'\.$'), '')
      .replaceAll('.', ',');
}

String _itemUnit(TransactionItem item) {
  final unit = item.unit?.trim();
  if (unit != null && unit.isNotEmpty) return unit;
  return item.isHardware == 1 ? 'kg' : '';
}

double _itemBillableQty(TransactionItem item) {
  if (item.unitPrice <= 0 || item.subtotal <= 0) return item.qty;
  final billed = item.subtotal / item.unitPrice;
  return billed > 0 ? billed : item.qty;
}

bool _hasRoundedBilling(TransactionItem item) {
  final unit = _itemUnit(item).toLowerCase();
  if (unit != 'kg' && item.isHardware != 1) return false;
  return (_itemBillableQty(item) - item.qty).abs() > 0.001;
}

String _itemQtyLabel(TransactionItem item, {bool includeUnit = true}) {
  final unit = _itemUnit(item);
  final qty = _fmtD(item.qty);
  if (!includeUnit || unit.isEmpty) return qty;
  return '$qty $unit';
}

String _itemPriceLine(TransactionItem item) {
  final unit = _itemUnit(item);
  final rounded = _hasRoundedBilling(item)
      ? ' (tagih ${_fmtD(_itemBillableQty(item))} $unit)'
      : '';
  return '${_itemQtyLabel(item)}$rounded x Rp${_f(item.unitPrice)}';
}

String _formatNoTransaksi(Transaction tx, {String? storeName}) {
  return TransactionCodeFormatter.format(
    id: tx.id ?? 0,
    createdAt: tx.createdAt,
    transactionCode: tx.transactionCode,
    storeName: storeName,
  );
}

/// Normalisasi nomor telepon dari DB agar selalu tampil dengan awalan 0.
/// DB menyimpan angka tanpa prefix (misal 895123456) karena UI input
/// menggunakan prefix +62. Fungsi ini memastikan hasil tampil: 0895123456.
String _normalizePhone(String raw) {
  final t = raw.trim();
  if (t.isEmpty) return '';
  if (t.startsWith('0') || t.startsWith('+')) return t;
  return '0$t';
}

//
// SCREEN
//
class StrukScreen extends ConsumerStatefulWidget {
  final int transactionId;
  final bool isAfterPayment;
  const StrukScreen(
      {super.key, required this.transactionId, this.isAfterPayment = false});

  @override
  ConsumerState<StrukScreen> createState() => _StrukScreenState();
}

class _StrukScreenState extends ConsumerState<StrukScreen> {
  Transaction? _tx;
  Customer? _customer;
  List<Map<String, dynamic>> _itemsWithExtra = [];
  Map<int, double> _returnedQtyMap = {}; // productId -> total qty returned
  Map<int, int> _returnedSubtotalMap = {}; // productId -> total refund value
  bool _loading = true;
  bool _printing = false;
  bool _showWatermark = true;
  bool _transactionNoteEnabled = true;
  DateTime?
      _estimasiPengambilan; // computed from pickupSchedule or durationHours

  final GlobalKey _shareKey = GlobalKey();
  final GlobalKey _printKey =
      GlobalKey(); // untuk cetak desktop (thermal-style)

  String _namaservis = '';
  String _alamat = '';
  String _telepon = '';
  String _footer = '';
  String _instagram = '';
  String _facebook = '';
  String _tiktok = '';
  String _kasirName = ''; // nama petugas (legacy key di DB)
  String _logoPath = '';
  int _sharedColor = 0xFF2563EB;
  String _logoPosition = 'top';
  double _logoWidth = 40.0;
  double _storeNameFontSize = 18.0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final tx = await DBHelper.instance.getTransactionById(widget.transactionId);
    final items =
        await DBHelper.instance.getTransactionItems(widget.transactionId);
    final servis = await DBHelper.instance.getWarungProfile();
    final profil = await DBHelper.instance.getProfil();

    // Load returns to check status
    final returns =
        await DBHelper.instance.getReturnsByTransactionId(widget.transactionId);
    final Map<int, double> retMap = {};
    final Map<int, int> retSubtotalMap = {};
    for (final ret in returns) {
      final retItems = await DBHelper.instance.getReturnItems(ret.id!);
      for (final ri in retItems) {
        retMap[ri.productId] = (retMap[ri.productId] ?? 0.0) + ri.qty;
        retSubtotalMap[ri.productId] =
            (retSubtotalMap[ri.productId] ?? 0) + ri.subtotal;
      }
    }

    final List<Map<String, dynamic>> itemsWithExtra = [];
    int maxDurationHours = 0;
    final categories = await DBHelper.instance.getCategories();
    for (final item in items) {
      final p = await DBHelper.instance.getProductById(item.productId);
      itemsWithExtra.add({'item': item, 'isExtra': p?.isExtra ?? 0});
      if (p != null) {
        int dur = p.durationHours;
        if (dur <= 0) {
          final cat = categories.where((c) => c.id == p.categoryId);
          if (cat.isNotEmpty) dur = cat.first.durationHours;
        }
        if (dur > maxDurationHours) maxDurationHours = dur;
      }
    }

    // Resolve estimated pickup datetime from pickupSchedule or durationHours fallback
    DateTime? estimasiPengambilan;
    if (tx != null) {
      if (tx.pickupSchedule != null && tx.pickupSchedule!.isNotEmpty) {
        estimasiPengambilan = DateTime.tryParse(tx.pickupSchedule!);
      }
      if (estimasiPengambilan == null && maxDurationHours > 0) {
        final created = DateTime.tryParse(tx.createdAt);
        if (created != null) {
          estimasiPengambilan = created.add(Duration(hours: maxDurationHours));
        }
      }
    }

    Customer? customer;
    if (tx?.customerId != null) {
      customer = await DBHelper.instance.getCustomerById(tx!.customerId!);
    }

    setState(() {
      _tx = tx;
      _customer = customer;
      _itemsWithExtra = itemsWithExtra;
      _returnedQtyMap = retMap;
      _returnedSubtotalMap = retSubtotalMap;
      _estimasiPengambilan = estimasiPengambilan;
      _namaservis = servis['nama'] ?? '';
      _alamat = servis['alamat'] ?? '';
      _telepon = _normalizePhone(servis['telepon'] ?? '');
      _footer = servis['catatan'] ?? '';
      _instagram = servis['instagram'] ?? '';
      _facebook = servis['facebook'] ?? '';
      _tiktok = servis['tiktok'] ?? '';
      _kasirName = profil['nama'] ?? '';
      _logoPath = servis['logo_path'] ?? '';
      _loading = false;
    });

    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _sharedColor = prefs.getInt('struk_sharedColor') ?? 0xFF2563EB;
      _logoPosition = prefs.getString('struk_logoPosition') ?? 'top';
      _logoWidth = prefs.getDouble('struk_logoWidth') ?? 40.0;
      _storeNameFontSize = prefs.getDouble('struk_storeNameFontSize') ?? 18.0;
      _showWatermark = prefs.getBool('struk_showWatermark') ?? true;
      _transactionNoteEnabled =
          prefs.getBool('struk_enableTransactionNote') ?? true;
    });

    final bool autoPrintLdr = prefs.getBool('struk_printLdr') ?? false;

    // Otomatis cetak LDR jika baru selesai bayar
    if (widget.isAfterPayment && autoPrintLdr) {
      Future.delayed(const Duration(milliseconds: 500), () => _cetakStruk());
    }

    if (widget.isAfterPayment && tx != null) {
      final delay = autoPrintLdr
          ? const Duration(milliseconds: 1300)
          : const Duration(milliseconds: 450);
      Future.delayed(
        delay,
        () => _openCashDrawerAfterPayment(tx.paymentMethod),
      );
    }
  }

  Future<void> _openCashDrawerAfterPayment(String paymentMethod) async {
    if (!mounted) return;
    try {
      await CashDrawerService.openAfterCashPayment(paymentMethod);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text(
            'Gagal membuka laci. Pastikan printer dan laci kasir terhubung.'),
        backgroundColor: Colors.red.shade800,
        behavior: SnackBarBehavior.floating,
      ));
    }
  }

  void _showProfileWarning() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        backgroundColor: Colors.white,
        title: const Text('Profil Servis Belum Lengkap',
            style: TextStyle(fontWeight: FontWeight.bold)),
        content: const Text(
            'Silakan lengkapi nama dan alamat servis Anda di menu Pengaturan Toko sebelum mencetak struk.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Nanti', style: TextStyle(color: Colors.black54)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pushNamed(context, '/pengaturan_servis');
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero)),
            child: const Text('Atur Sekarang',
                style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  String _methodLabel(String m) {
    final low = m.toLowerCase();
    if (low == 'qris') return 'QRIS';
    if (low == 'bank' || low == 'transfer') return 'Non Tunai';
    if (low.startsWith('campuran')) return m; // Return full breakdown string
    return 'Tunai';
  }

  String _transactionNoteText(Transaction tx) {
    if (!_transactionNoteEnabled) return '';
    final note = tx.note?.trim() ?? '';
    if (note.isEmpty) return '';

    final lower = note.toLowerCase();
    if (lower == 'quick pay (shortcut)' || lower == 'hold (shortcut)') {
      return '';
    }
    if (RegExp(r'^Jenis:\s*[^.]+\.?$', caseSensitive: false).hasMatch(note)) {
      return '';
    }
    return note;
  }

  String _itemNoteText(TransactionItem item) {
    if (!_transactionNoteEnabled) return '';
    return item.note?.trim() ?? '';
  }

  double _receiptStoreNameFontSize({bool compact = false}) {
    final base = _storeNameFontSize.clamp(14.0, 32.0).toDouble();
    final adjusted = compact ? base - 2.0 : base + 4.0;
    return adjusted
        .clamp(compact ? 14.0 : 18.0, compact ? 22.0 : 32.0)
        .toDouble();
  }

  double _thermalStoreNameFontSize({bool compact = false}) {
    final base = _storeNameFontSize.clamp(14.0, 32.0).toDouble();
    final adjusted = compact ? base - 2.0 : base;
    return adjusted
        .clamp(compact ? 12.0 : 14.0, compact ? 20.0 : 24.0)
        .toDouble();
  }

  Future<ReceiptPrintDocument> _buildReceiptPrintDocument() async {
    final tx = _tx;
    if (tx == null) throw 'Data transaksi tidak ditemukan.';

    final prefs = await SharedPreferences.getInstance();
    final String ukuranKertas = prefs.getString('struk_ukuranKertas') ?? '58mm';

    String tanggalStr = '';
    try {
      final dt = DateTime.parse(tx.createdAt);
      tanggalStr = DateFormat('dd-MM-yyyy HH:mm').format(dt);
    } catch (_) {
      tanggalStr = tx.createdAt;
    }

    final List<ReceiptPrintItem> receiptItems = _itemsWithExtra.map((data) {
      final item = data['item'] as TransactionItem;
      final bool isExtra = data['isExtra'] == 1;
      return ReceiptPrintItem(
        name: isExtra ? '${item.productName} (Add-on)' : item.productName,
        qty: item.qty,
        unitPrice: item.unitPrice,
        subtotal: item.subtotal,
        unit: item.unit ?? '',
        isHardware: item.isHardware,
        note: _itemNoteText(item),
        originalUnitPrice: item.effectiveOriginalUnitPrice,
        originalSubtotal: item.effectiveOriginalSubtotal,
        priceOverrideAmount: item.effectivePriceOverrideAmount,
        appliedDiscountName: item.appliedDiscountName ?? '',
        appliedDiscountIsPercentage: item.appliedDiscountIsPercentage,
        appliedDiscountValue: item.appliedDiscountValue,
        isPriceOverride: item.hasPriceOverride,
      );
    }).toList();

    final List<ReceiptPrintCharge> charges = [];
    for (final dynamic charge in tx.chargesList) {
      if (charge is Map) {
        charges.add(
          ReceiptPrintCharge(
            label: charge['label']?.toString() ?? 'Biaya',
            value: charge['value'] as int? ?? 0,
          ),
        );
      }
    }

    final pickupScheduleText = _estimasiPengambilan != null
        ? DateFormat(
            ukuranKertas == '80mm'
                ? 'EEE, dd MMM yyyy HH:mm'
                : 'dd MMM yyyy HH:mm',
            'id',
          ).format(_estimasiPengambilan!)
        : tx.pickupSchedule;

    return ReceiptPrintService.buildDocument(
      ukuranKertas: ukuranKertas,
      namaWarung: _namaservis,
      alamat: _alamat,
      telepon: _telepon,
      footer: _footer,
      instagram: _instagram,
      facebook: _facebook,
      tiktok: _tiktok,
      logoPosition: _logoPosition,
      logoWidth: _logoWidth,
      storeNameFontSize: _storeNameFontSize,
      showAlamat: prefs.getBool('struk_showAlamat') ?? true,
      showTelepon: prefs.getBool('struk_showTelepon') ?? true,
      showTotalPesanan: prefs.getBool('struk_showTotalPesanan') ?? true,
      showWatermark: _showWatermark,
      noTransaksi: _formatNoTransaksi(tx, storeName: _namaservis),
      tanggal: tanggalStr,
      kasirName: _kasirName,
      paymentMethod: _methodLabel(tx.paymentMethod),
      items: receiptItems,
      subtotal: tx.totalAmount,
      discountAmount: tx.discountAmount,
      charges: charges,
      additionalCharges: tx.additionalCharges,
      grandTotal: tx.grandTotal,
      amountPaid: tx.amountPaid,
      changeAmount: tx.changeAmount,
      customerName: tx.customerName,
      orderType: tx.orderType,
      pickupSchedule: pickupScheduleText,
      paymentStatus: tx.paymentStatus,
      kelengkapan: tx.kelengkapan,
      note: _transactionNoteText(tx),
      queueNumber: tx.queueNumber,
    );
  }

  Future<void> _cetakDesktopRaw() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String savedName = prefs.getString('desktop_printerName') ?? '';

      // Fallback: pick printer if not saved
      if (savedName.isEmpty) {
        if (!mounted) return;
        final target = await Printing.pickPrinter(context: context);
        if (target != null) {
          savedName = target.name;
          await prefs.setString('desktop_printerName', savedName);
        } else {
          return;
        }
      }

      final document = await _buildReceiptPrintDocument();
      final bytes = await ReceiptPrintService.buildEscPosBytes(
        document: document,
        logoPath: _logoPath,
      );

      await ReceiptPrintService.printRawEscPosDesktop(
        bytes: bytes,
        printerName: savedName,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Struk berhasil dicetak (Direct Text Mode)'),
          backgroundColor: Color(0xFF2E7D32),
          behavior: SnackBarBehavior.floating,
        ));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text(
            'Gagal mencetak struk. Pastikan printer terhubung dan coba lagi.'),
        backgroundColor: Colors.red.shade800,
        behavior: SnackBarBehavior.floating,
      ));
    }
  }

  Future<void> _cetakStruk() async {
    if (_printing) return;

    if (_namaservis.trim().isEmpty ||
        _namaservis.trim().toLowerCase() == 'nama servis' ||
        _alamat.trim().isEmpty) {
      _showProfileWarning();
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final bool isLdr = prefs.getBool('struk_printLdr') ?? false;

    if (isLdr) {
      setState(() => _printing = true);
      try {
        final document = await _buildReceiptPrintDocument();
        await RemotePrintService.sendPrintRequest(document);
        if (mounted) {
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              backgroundColor: Colors.white,
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 16),
                  const Icon(Icons.cloud_done_rounded,
                      color: Color(0xFF2E7D32), size: 64),
                  const SizedBox(height: 24),
                  const Text(
                    'Cetak LDR Terkirim',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Data struk telah berhasil dikirim ke antrean live.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.black54, fontSize: 14),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF2E7D32),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: const Text('OK',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          );
        }
      } catch (e) {
        if (mounted) {
          final msg = e
              .toString()
              .replaceAll('StateError: ', '')
              .replaceAll('Exception: ', '');
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(msg),
            backgroundColor: Colors.red.shade800,
            behavior: SnackBarBehavior.floating,
          ));
        }
      } finally {
        if (mounted) setState(() => _printing = false);
      }
      return;
    }

    setState(() => _printing = true);

    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      // PRO-GRADE: Force use Raw ESC/POS on Windows for Hardware Font consistency
      await _cetakDesktopRaw();
      if (mounted) setState(() => _printing = false);
      return;
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      String mac = prefs.getString('struk_printerMac') ?? '';
      if (mac.isEmpty) {
        setState(() => _printing = false);
        await _showPickPrinterDialog();
        return;
      }

      await [Permission.bluetoothScan, Permission.bluetoothConnect]
          .request()
          .timeout(const Duration(seconds: 8));
      final bluetoothOn = await PrintBluetoothThermal.bluetoothEnabled
          .timeout(const Duration(seconds: 4));
      if (!bluetoothOn) {
        if (!mounted) return;
        setState(() => _printing = false);
        await _showBluetoothDisabledDialog();
        return;
      }

      bool connected = false;
      for (var attempt = 0; attempt < 2 && !connected; attempt++) {
        connected =
            await PrintBluetoothThermal.connect(macPrinterAddress: mac).timeout(
          const Duration(seconds: 5),
          onTimeout: () => false,
        );
        if (!connected && attempt == 0) {
          await Future<void>.delayed(const Duration(milliseconds: 500));
        }
      }

      if (!connected) {
        if (!mounted) return;
        setState(() => _printing = false);
        await _showPrinterUnavailableDialog(
          reason:
              'Printer tidak merespons dalam 10 detik. Kemungkinan printer sedang mati, terlalu jauh, atau koneksi Bluetooth terputus.',
        );
        return;
      }

      final document = await _buildReceiptPrintDocument()
          .timeout(const Duration(seconds: 8));
      final bytes = await ReceiptPrintService.buildEscPosBytes(
        document: document,
        logoPath: _logoPath,
      ).timeout(const Duration(seconds: 10));
      final printed = await PrintBluetoothThermal.writeBytes(bytes).timeout(
        const Duration(seconds: 12),
        onTimeout: () => false,
      );
      await PrintBluetoothThermal.disconnect.timeout(
        const Duration(seconds: 3),
        onTimeout: () => false,
      );
      if (!printed && mounted) {
        setState(() => _printing = false);
        await _showPrinterUnavailableDialog(
          reason:
              'Printer terhubung tetapi tidak merespons saat data struk dikirim. Periksa daya printer dan kertas, lalu coba lagi.',
        );
      } else if (printed && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Struk berhasil dikirim ke printer.'),
          backgroundColor: Color(0xFF15803D),
          behavior: SnackBarBehavior.floating,
        ));
      }
    } on TimeoutException {
      if (!mounted) return;
      setState(() => _printing = false);
      await _showPrinterUnavailableDialog(
        reason:
            'Waktu koneksi habis karena printer tidak merespons. Pastikan printer menyala dan Bluetooth terhubung.',
      );
    } catch (e) {
      if (!mounted) return;
      final bluetoothOn = await PrintBluetoothThermal.bluetoothEnabled.timeout(
        const Duration(seconds: 3),
        onTimeout: () => false,
      );
      if (!mounted) return;
      setState(() => _printing = false);
      if (!bluetoothOn) {
        await _showBluetoothDisabledDialog();
      } else {
        await _showPrinterUnavailableDialog(
          reason:
              'Koneksi ke printer gagal. Pastikan printer menyala, memiliki kertas, dan tidak sedang digunakan perangkat lain.',
        );
      }
    } finally {
      if (!Platform.isWindows && !Platform.isLinux && !Platform.isMacOS) {
        try {
          await PrintBluetoothThermal.disconnect.timeout(
            const Duration(seconds: 3),
            onTimeout: () => false,
          );
        } catch (_) {
          // Connection cleanup must never keep the print button loading.
        }
      }
      if (mounted) setState(() => _printing = false);
    }
  }

  Future<void> _showBluetoothDisabledDialog() async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Row(
          children: [
            Icon(Icons.bluetooth_disabled_rounded,
                color: AppColors.danger, size: 28),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                'Bluetooth Belum Aktif',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: const Text(
          'Aktifkan Bluetooth di HP terlebih dahulu, lalu coba cetak ulang struk. Printer thermal hanya bisa terhubung jika Bluetooth dalam keadaan aktif.',
          style: TextStyle(fontSize: 14, color: Colors.black87, height: 1.45),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text(
              'NANTI',
              style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _cetakStruk();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              elevation: 0,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
            child: const Text(
              'SUDAH DINYALAKAN',
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showPrinterUnavailableDialog({String? reason}) async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Row(
          children: [
            Icon(Icons.print_disabled_rounded,
                color: AppColors.danger, size: 28),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                'Printer Belum Terhubung',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: Text(
          reason ??
              'Pastikan printer thermal menyala, sudah dipasangkan dengan HP, dan berada dekat dengan kasir. Setelah siap, coba cetak ulang struk.',
          style: const TextStyle(
              fontSize: 14, color: Colors.black87, height: 1.45),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove('struk_printerMac');
              await prefs.remove('struk_printerName');
              if (mounted) _showPickPrinterDialog();
            },
            child: const Text(
              'PILIH PRINTER',
              style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _cetakStruk();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              elevation: 0,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
            child: const Text(
              'COBA LAGI',
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showPickPrinterDialog() async {
    if (Platform.isWindows || Platform.isMacOS || Platform.isLinux) {
      final prefs = await SharedPreferences.getInstance();
      if (!mounted) return;
      final targetPrinter = await Printing.pickPrinter(context: context);
      if (targetPrinter != null) {
        await prefs.setString('desktop_printerName', targetPrinter.name);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Printer Desktop tersimpan: ${targetPrinter.name}'),
            backgroundColor: const Color(0xFF2E7D32),
            behavior: SnackBarBehavior.floating,
          ));
        }
      }
      return;
    }

    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    await [Permission.bluetoothScan, Permission.bluetoothConnect].request();
    final bool permitted = await PrintBluetoothThermal.bluetoothEnabled;
    if (!permitted) {
      if (!mounted) return;
      await _showBluetoothDisabledDialog();
      return;
    }
    if (!mounted) return;
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) =>
            const Center(child: CircularProgressIndicator(color: _kBrand)));
    List<BluetoothInfo> list = [];
    try {
      list = await PrintBluetoothThermal.pairedBluetooths;
    } catch (_) {}
    if (!mounted) return;
    navigator.pop();
    if (list.isEmpty) {
      messenger.showSnackBar(const SnackBar(
          content: Text('Tidak ada printer terpasang di Bluetooth HP ini.')));
      return;
    }
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.zero)),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Center(
                child: Container(
                  width: 48,
                  height: 5,
                  decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.zero),
                ),
              ),
              const SizedBox(height: 24),
              const Center(
                child: Text('Pilih Printer Thermal',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              ),
              const SizedBox(height: 8),
              Text(
                'Pilih printer bluetooth Anda untuk mencetak struk secara instan.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
              ),
              const SizedBox(height: 24),
              Flexible(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: list
                        .map((p) => Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: InkWell(
                                onTap: () async {
                                  Navigator.pop(ctx);
                                  final prefs =
                                      await SharedPreferences.getInstance();
                                  await prefs.setString(
                                      'struk_printerMac', p.macAdress);
                                  await prefs.setString(
                                      'struk_printerName', p.name);
                                  _cetakStruk();
                                },
                                borderRadius: BorderRadius.zero,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFF8F9FA),
                                    borderRadius: BorderRadius.zero,
                                    border: Border.all(
                                        color: Colors.grey.shade200,
                                        width: 1.2),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 16),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 44,
                                        height: 44,
                                        decoration: BoxDecoration(
                                          color: _kBrand.withValues(alpha: 0.1),
                                          borderRadius: BorderRadius.zero,
                                        ),
                                        child: const Icon(Icons.print_rounded,
                                            color: _kBrand, size: 22),
                                      ),
                                      const SizedBox(width: 16),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(p.name,
                                                style: const TextStyle(
                                                    fontSize: 14,
                                                    fontWeight:
                                                        FontWeight.w600)),
                                            const SizedBox(height: 4),
                                            Text('MAC: ${p.macAdress}',
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color:
                                                        Colors.grey.shade500)),
                                          ],
                                        ),
                                      ),
                                      Icon(Icons.arrow_forward_ios_rounded,
                                          size: 16,
                                          color: Colors.grey.shade400),
                                    ],
                                  ),
                                ),
                              ),
                            ))
                        .toList(),
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  double _sharePixelRatioFor(Size size, double preferredPixelRatio) {
    if (size.width <= 0 || size.height <= 0) return preferredPixelRatio;

    const maxDimension = 12000.0;
    const maxPixels = 14000000.0;
    final byWidth = maxDimension / size.width;
    final byHeight = maxDimension / size.height;
    final byPixels = math.sqrt(maxPixels / (size.width * size.height));
    final safeRatio = math.min(
      preferredPixelRatio,
      math.min(byPixels, math.min(byWidth, byHeight)),
    );

    return safeRatio.clamp(0.75, preferredPixelRatio).toDouble();
  }

  Future<Uint8List?> _captureShareImage({
    double preferredPixelRatio = 2.6,
  }) async {
    try {
      await WidgetsBinding.instance.endOfFrame;
      await Future.delayed(const Duration(milliseconds: 80));

      final captureContext = _shareKey.currentContext;
      if (captureContext == null || !captureContext.mounted) {
        debugPrint('Error share: Context global key is null');
        return null;
      }

      final boundary =
          captureContext.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null || !boundary.attached || !boundary.hasSize) {
        debugPrint('Error share: RenderRepaintBoundary is not ready');
        return null;
      }

      for (var i = 0; i < 10 && boundary.debugNeedsPaint; i++) {
        await WidgetsBinding.instance.endOfFrame;
        await Future.delayed(const Duration(milliseconds: 60));
      }
      if (boundary.debugNeedsPaint) {
        debugPrint('Error share: Boundary still needs paint after retry');
        return null;
      }

      final pixelRatio =
          _sharePixelRatioFor(boundary.size, preferredPixelRatio);
      final image = await boundary.toImage(pixelRatio: pixelRatio);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      return byteData?.buffer.asUint8List();
    } catch (e) {
      debugPrint('Error capturing share image: $e');
      return null;
    }
  }

  String _cleanStoreName(String? value) {
    final name = value?.trim() ?? '';
    if (name.isEmpty) return '';
    final lower = name.toLowerCase();
    if (lower == 'nama servis' || lower == 'servis kami') return '';
    return name;
  }

  Future<String> _resolveStoreNameForReceipt() async {
    final fromState = _cleanStoreName(_namaservis);
    if (fromState.isNotEmpty) return fromState;

    final profile = await DBHelper.instance.getWarungProfile();
    final fromDb = _cleanStoreName(profile['nama']);
    if (fromDb.isNotEmpty) {
      _namaservis = fromDb;
      return fromDb;
    }

    return 'Juragan Servis';
  }

  String _buildWhatsappReceiptText({
    required String namaservis,
    required String noTx,
    required String tanggal,
  }) {
    final sb = StringBuffer()
      ..writeln('STRUK servis')
      ..writeln(namaservis);
    if (_alamat.trim().isNotEmpty) sb.writeln(_alamat.trim());
    if (_telepon.trim().isNotEmpty) sb.writeln('Telp: ${_telepon.trim()}');
    sb
      ..writeln('------------------------------')
      ..writeln('No. Struk : $noTx')
      ..writeln('Tanggal   : $tanggal');
    if (_kasirName.trim().isNotEmpty) sb.writeln('Server    : $_kasirName');
    sb.writeln('Bayar     : ${_methodLabel(_tx!.paymentMethod)}');
    if (_tx!.customerName?.trim().isNotEmpty ?? false) {
      sb.writeln('Pelanggan : ${_tx!.customerName!.trim()}');
    }
    if (_tx!.orderType?.trim().isNotEmpty ?? false) {
      sb.writeln('Jenis     : ${_tx!.orderType!.trim()}');
    }
    if (_estimasiPengambilan != null) {
      sb.writeln(
          'Estimasi  : ${DateFormat('dd-MM-yyyy HH:mm').format(_estimasiPengambilan!)}');
    }
    if (_tx!.servisStatus.trim().isNotEmpty) {
      sb.writeln('Status    : ${_tx!.servisStatus}');
    }
    if (_tx!.kelengkapan?.trim().isNotEmpty ?? false) {
      if (_tx!.kelengkapan != 'None') {
        sb.writeln('Parfum    : ${_tx!.kelengkapan!.trim()}');
      }
    }
    if (_tx!.paymentStatus?.trim().isNotEmpty ?? false) {
      sb.writeln('Status Bayar: ${_tx!.paymentStatus}');
    }
    sb.writeln('------------------------------');

    for (final data in _itemsWithExtra) {
      final item = data['item'] as TransactionItem;
      final isExtra = data['isExtra'] == 1;
      final itemNote = _itemNoteText(item);
      sb.writeln('${isExtra ? '+ ' : ''}${item.productName}');
      sb.writeln('  ${_itemPriceLine(item)} = Rp${_f(item.subtotal)}');
      if (itemNote.isNotEmpty) {
        sb.writeln('  Catatan: $itemNote');
      }
    }

    sb.writeln('------------------------------');
    if (_tx!.discountAmount > 0 ||
        _tx!.additionalCharges > 0 ||
        _tx!.chargesList.isNotEmpty) {
      sb.writeln('Subtotal : Rp${_f(_tx!.totalAmount)}');
      if (_tx!.discountAmount > 0) {
        sb.writeln('${_getDiskonLabel(_tx!)} : -Rp${_f(_tx!.discountAmount)}');
      }
      if (_tx!.chargesList.isNotEmpty) {
        for (final charge in _tx!.chargesList) {
          final value = (charge['value'] as num?)?.toInt() ?? 0;
          sb.writeln(
              '${charge['label']?.toString() ?? 'Biaya Tambahan'} : Rp${_f(value)}');
        }
      } else if (_tx!.additionalCharges > 0) {
        sb.writeln('Biaya Tambahan : Rp${_f(_tx!.additionalCharges)}');
      }
    }
    sb.writeln('TOTAL    : Rp${_f(_tx!.grandTotal)}');
    sb.writeln('Bayar    : Rp${_f(_tx!.amountPaid)}');
    if (_tx!.changeAmount > 0) {
      sb.writeln('Kembali  : Rp${_f(_tx!.changeAmount)}');
    }
    sb.writeln('------------------------------');
    sb.write(_footer.trim().isNotEmpty
        ? _footer.trim()
        : 'Terima kasih telah menggunakan layanan kami.');
    return sb.toString();
  }

  Future<Uint8List?> _buildWhatsappReceiptImage({
    required String namaservis,
    required String noTx,
    required String tanggal,
  }) async {
    ui.Image? logoImage;
    try {
      final tx = _tx;
      if (tx == null) return null;

      final logoPath = _logoPath.trim();
      if (logoPath.isNotEmpty) {
        final logoFile = File(logoPath);
        if (await logoFile.exists()) {
          final completer = Completer<ui.Image>();
          ui.decodeImageFromList(
            await logoFile.readAsBytes(),
            completer.complete,
          );
          logoImage = await completer.future;
        }
      }

      const imageWidth = 720;
      const margin = 44.0;
      const contentWidth = imageWidth - (margin * 2);
      const ink = Color(0xFF111827);
      const muted = Color(0xFF667085);
      const divider = Color(0xFFE5E7EB);
      const surface = Color(0xFFF8FAFC);
      final brand = Color(_sharedColor);
      final brandSoft = brand.withValues(alpha: 0.05);

      TextStyle style(
        double size,
        FontWeight weight,
        Color color, {
        double height = 1.25,
      }) {
        return TextStyle(
          fontFamily: 'PlusJakartaSans',
          fontSize: size,
          fontWeight: weight,
          color: color,
          height: height,
        );
      }

      final titleStyle = style(32, FontWeight.w900, ink, height: 1.12);
      final bodyStyle = style(23, FontWeight.w600, ink);
      final bodyBoldStyle = style(23, FontWeight.w800, ink);
      final smallStyle = style(19, FontWeight.w500, muted);
      final smallBoldStyle = style(19, FontWeight.w800, ink);
      final totalStyle = style(30, FontWeight.w900, ink);

      TextPainter painter(
        String text,
        TextStyle textStyle, {
        TextAlign align = TextAlign.left,
        double maxWidth = contentWidth,
      }) {
        return TextPainter(
          text: TextSpan(text: text, style: textStyle),
          textAlign: align,
          textDirection: ui.TextDirection.ltr,
          maxLines: null,
        )..layout(maxWidth: maxWidth);
      }

      double render(Canvas? canvas) {
        var y = 56.0;

        void drawText(
          String text,
          TextStyle textStyle, {
          double x = margin,
          double maxWidth = contentWidth,
          TextAlign align = TextAlign.left,
          double bottom = 8,
        }) {
          if (text.trim().isEmpty) return;
          final tp = painter(text, textStyle, align: align, maxWidth: maxWidth);
          if (canvas != null) tp.paint(canvas, Offset(x, y));
          y += tp.height + bottom;
        }

        void paintTextAt(
          String text,
          TextStyle textStyle,
          Offset offset, {
          double maxWidth = contentWidth,
          TextAlign align = TextAlign.left,
        }) {
          if (text.trim().isEmpty || canvas == null) return;
          final tp = painter(text, textStyle, align: align, maxWidth: maxWidth);
          tp.paint(canvas, offset);
        }

        void drawBarcodeCanvas(
          Barcode barcode,
          String data,
          Rect rect,
          Color color,
        ) {
          if (canvas == null || data.trim().isEmpty) return;
          try {
            final paint = Paint()..color = color;
            final recipe = barcode.make(
              data,
              width: rect.width,
              height: rect.height,
              drawText: false,
            );
            for (final element in recipe) {
              if (element is BarcodeBar && element.black) {
                canvas.drawRect(
                  Rect.fromLTWH(
                    rect.left + element.left,
                    rect.top + element.top,
                    element.width,
                    element.height,
                  ),
                  paint,
                );
              }
            }
          } catch (e) {
            debugPrint('Gagal menggambar barcode struk: $e');
          }
        }

        void drawStoreHeader() {
          final headerTop = y;
          final logo = logoImage;
          final hasLogo = logo != null;
          final logoAspect =
              hasLogo ? logo.width / math.max(1, logo.height) : 1.0;
          final isHorizontalLogo = logoAspect >= 1.8;

          Rect fittedLogoRect(ui.Image image, Rect box) {
            final source = Rect.fromLTWH(
              0,
              0,
              image.width.toDouble(),
              image.height.toDouble(),
            );
            final scale = math.min(
              box.width / source.width,
              box.height / source.height,
            );
            final drawWidth = source.width * scale;
            final drawHeight = source.height * scale;
            return Rect.fromLTWH(
              box.left + (box.width - drawWidth) / 2,
              box.top + (box.height - drawHeight) / 2,
              drawWidth,
              drawHeight,
            );
          }

          void paintLogo(ui.Image image, Rect destination) {
            if (canvas == null) return;
            canvas.drawImageRect(
              image,
              Rect.fromLTWH(
                0,
                0,
                image.width.toDouble(),
                image.height.toDouble(),
              ),
              destination,
              Paint()
                ..isAntiAlias = true
                ..filterQuality = FilterQuality.high,
            );
          }

          void drawCenteredTextBlock({
            required double top,
            double bottom = 22,
          }) {
            var textY = top;
            if (canvas != null) {
              paintTextAt(
                namaservis,
                titleStyle,
                Offset(margin, textY),
                maxWidth: contentWidth,
                align: TextAlign.center,
              );
            }
            final nameTp = painter(
              namaservis,
              titleStyle,
              maxWidth: contentWidth,
              align: TextAlign.center,
            );
            textY += nameTp.height + 8;

            final address = _alamat.trim();
            if (address.isNotEmpty) {
              if (canvas != null) {
                paintTextAt(
                  address,
                  smallStyle,
                  Offset(margin, textY),
                  maxWidth: contentWidth,
                  align: TextAlign.center,
                );
              }
              textY += painter(
                    address,
                    smallStyle,
                    maxWidth: contentWidth,
                    align: TextAlign.center,
                  ).height +
                  4;
            }

            final phone = _telepon.trim();
            if (phone.isNotEmpty) {
              final phoneText = 'Telp: $phone';
              if (canvas != null) {
                paintTextAt(
                  phoneText,
                  smallBoldStyle,
                  Offset(margin, textY),
                  maxWidth: contentWidth,
                  align: TextAlign.center,
                );
              }
              textY += painter(
                phoneText,
                smallBoldStyle,
                maxWidth: contentWidth,
                align: TextAlign.center,
              ).height;
            }

            y = textY + bottom;
          }

          if (!hasLogo) {
            drawCenteredTextBlock(top: headerTop);
            return;
          }

          if (isHorizontalLogo) {
            final logoBox = Rect.fromLTWH(
              margin,
              headerTop,
              contentWidth,
              70,
            );
            final maxLogoRect = Rect.fromCenter(
              center: logoBox.center,
              width: math.min(contentWidth * 0.46, 230.0),
              height: logoBox.height,
            );
            final destination = fittedLogoRect(logo, maxLogoRect);
            paintLogo(logo, destination);
            drawCenteredTextBlock(top: destination.bottom + 14);
            return;
          }

          const logoBoxWidth = 78.0;
          const logoBoxHeight = 78.0;
          const textX = margin + logoBoxWidth + 18;
          const textWidth = imageWidth - margin - textX;
          var textY = headerTop + 3;

          if (canvas != null) {
            final logoRect = Rect.fromLTWH(
              margin,
              headerTop,
              logoBoxWidth,
              logoBoxHeight,
            );
            canvas.drawRRect(
              RRect.fromRectAndRadius(
                logoRect,
                const Radius.circular(10),
              ),
              Paint()..color = surface,
            );
            canvas.drawRRect(
              RRect.fromRectAndRadius(
                logoRect,
                const Radius.circular(10),
              ),
              Paint()
                ..style = PaintingStyle.stroke
                ..strokeWidth = 1.4
                ..color = divider,
            );
            paintLogo(logo, fittedLogoRect(logo, logoRect.deflate(8)));

            paintTextAt(
              namaservis,
              titleStyle,
              Offset(textX, textY),
              maxWidth: textWidth,
            );
          }

          final nameTp = painter(namaservis, titleStyle, maxWidth: textWidth);
          textY += nameTp.height + 8;

          final address = _alamat.trim();
          if (address.isNotEmpty) {
            if (canvas != null) {
              paintTextAt(
                address,
                smallStyle,
                Offset(textX, textY),
                maxWidth: textWidth,
              );
            }
            textY +=
                painter(address, smallStyle, maxWidth: textWidth).height + 4;
          }

          final phone = _telepon.trim();
          if (phone.isNotEmpty) {
            final phoneText = 'Telp: $phone';
            if (canvas != null) {
              paintTextAt(
                phoneText,
                smallBoldStyle,
                Offset(textX, textY),
                maxWidth: textWidth,
              );
            }
            textY +=
                painter(phoneText, smallBoldStyle, maxWidth: textWidth).height;
          }

          y = math.max(textY, headerTop + logoBoxHeight) + 22;
        }

        void drawScanCodeBlock() {
          const blockHeight = 132.0;
          y += 12;
          final blockRect = Rect.fromLTWH(margin, y, contentWidth, blockHeight);
          final qrRect = Rect.fromLTWH(margin + 18, y + 20, 86, 86);
          final barcodeRect = Rect.fromLTWH(
            margin + 126,
            y + 54,
            contentWidth - 152,
            42,
          );

          if (canvas != null) {
            canvas.drawRRect(
              RRect.fromRectAndRadius(blockRect, const Radius.circular(10)),
              Paint()..color = surface,
            );
            canvas.drawRRect(
              RRect.fromRectAndRadius(blockRect, const Radius.circular(10)),
              Paint()
                ..style = PaintingStyle.stroke
                ..strokeWidth = 1.2
                ..color = divider,
            );
            canvas.drawRRect(
              RRect.fromRectAndRadius(
                qrRect.inflate(8),
                const Radius.circular(8),
              ),
              Paint()..color = Colors.white,
            );
            drawBarcodeCanvas(Barcode.qrCode(), noTx, qrRect, brand);
            paintTextAt(
              'Kode Struk',
              smallBoldStyle.copyWith(color: ink),
              Offset(margin + 126, y + 22),
              maxWidth: contentWidth - 152,
            );
            drawBarcodeCanvas(Barcode.code128(), noTx, barcodeRect, ink);
            paintTextAt(
              noTx,
              smallBoldStyle.copyWith(fontSize: 16, color: muted),
              Offset(margin + 126, y + 102),
              maxWidth: contentWidth - 152,
            );
          }

          y += blockHeight + 10;
        }

        void drawRule({double top = 12, double bottom = 16}) {
          y += top;
          if (canvas != null) {
            canvas.drawLine(
              Offset(margin, y),
              Offset(imageWidth - margin, y),
              Paint()
                ..color = divider
                ..strokeWidth = 2,
            );
          }
          y += bottom;
        }

        void drawRow(
          String left,
          String right, {
          TextStyle? leftStyle,
          TextStyle? rightStyle,
          double bottom = 9,
        }) {
          const rightWidth = 270.0;
          final leftTp = painter(
            left,
            leftStyle ?? bodyStyle,
            maxWidth: contentWidth - rightWidth - 18,
          );
          final rightTp = painter(
            right,
            rightStyle ?? bodyBoldStyle,
            align: TextAlign.right,
            maxWidth: rightWidth,
          );
          final rowHeight = math.max(leftTp.height, rightTp.height);
          if (canvas != null) {
            leftTp.paint(canvas, Offset(margin, y));
            rightTp.paint(
              canvas,
              Offset(imageWidth - margin - rightWidth, y),
            );
          }
          y += rowHeight + bottom;
        }

        void drawInfoBox(List<MapEntry<String, String>> rows) {
          final validRows = rows
              .where((row) =>
                  row.key.trim().isNotEmpty && row.value.trim().isNotEmpty)
              .toList();
          if (validRows.isEmpty) return;

          var boxHeight = 16.0;
          for (final row in validRows) {
            const rightWidth = 270.0;
            final leftTp = painter(
              row.key,
              smallStyle,
              maxWidth: contentWidth - rightWidth - 18,
            );
            final rightTp = painter(
              row.value,
              bodyBoldStyle,
              align: TextAlign.right,
              maxWidth: rightWidth,
            );
            boxHeight += math.max(leftTp.height, rightTp.height) + 9;
          }
          if (canvas != null) {
            canvas.drawRRect(
              RRect.fromRectAndRadius(
                Rect.fromLTWH(
                    margin - 10, y - 4, contentWidth + 20, boxHeight + 2),
                const Radius.circular(10),
              ),
              Paint()..color = surface,
            );
            canvas.drawRRect(
              RRect.fromRectAndRadius(
                Rect.fromLTWH(
                    margin - 10, y - 4, contentWidth + 20, boxHeight + 2),
                const Radius.circular(10),
              ),
              Paint()
                ..style = PaintingStyle.stroke
                ..strokeWidth = 1.2
                ..color = divider,
            );
            canvas.drawRRect(
              RRect.fromRectAndRadius(
                Rect.fromLTWH(margin - 10, y - 4, 5, boxHeight + 2),
                const Radius.circular(10),
              ),
              Paint()..color = brandSoft,
            );
          }
          y += 8;
          for (final row in validRows) {
            drawRow(row.key, row.value, leftStyle: smallStyle);
          }
          y += 2;
        }

        drawStoreHeader();
        drawRule(top: 4, bottom: 14);

        drawInfoBox([
          MapEntry('No', noTx),
          MapEntry('Tanggal', tanggal),
          if (_kasirName.trim().isNotEmpty) MapEntry('Server', _kasirName),
          MapEntry('Pembayaran', _methodLabel(tx.paymentMethod)),
          if (tx.customerName?.trim().isNotEmpty ?? false)
            MapEntry('Pelanggan', tx.customerName!.trim()),
          if (tx.orderType?.trim().isNotEmpty ?? false)
            MapEntry('Jenis', tx.orderType!.trim()),
          if (_estimasiPengambilan != null)
            MapEntry(
              'Estimasi',
              DateFormat('dd-MM-yyyy HH:mm').format(_estimasiPengambilan!),
            ),
          if (tx.servisStatus.trim().isNotEmpty)
            MapEntry('Status', tx.servisStatus),
          if (tx.kelengkapan?.trim().isNotEmpty ?? false)
            if (tx.kelengkapan != 'None')
              MapEntry('Parfum', tx.kelengkapan!.trim()),
          if (tx.paymentStatus?.trim().isNotEmpty ?? false)
            MapEntry('Status Bayar', tx.paymentStatus!),
        ]);

        drawRule();

        for (final data in _itemsWithExtra) {
          final item = data['item'] as TransactionItem;
          final isExtra = data['isExtra'] == 1;
          final name = isExtra ? '+ ${item.productName}' : item.productName;
          final itemNote = _itemNoteText(item);
          drawText(name, bodyBoldStyle, bottom: 3);
          if (itemNote.isNotEmpty) {
            drawText(
              'Catatan: $itemNote',
              smallStyle,
              bottom: 3,
            );
          }
          drawRow(
            _itemPriceLine(item),
            'Rp${_f(item.subtotal)}',
            leftStyle: smallStyle,
            rightStyle: bodyBoldStyle,
            bottom: 14,
          );
        }

        drawRule(top: 6, bottom: 14);

        if (tx.discountAmount > 0 ||
            tx.chargesList.isNotEmpty ||
            tx.additionalCharges > 0) {
          drawRow(
            'Subtotal',
            'Rp${_f(tx.totalAmount)}',
            leftStyle: smallStyle,
          );
          if (tx.discountAmount > 0) {
            drawRow(
              _getDiskonLabel(tx),
              '-Rp${_f(tx.discountAmount)}',
              leftStyle: smallStyle,
              rightStyle: smallBoldStyle.copyWith(color: brand),
            );
          }
          if (tx.chargesList.isNotEmpty) {
            for (final charge in tx.chargesList) {
              final value = (charge['value'] as num?)?.toInt() ?? 0;
              drawRow(
                charge['label']?.toString() ?? 'Biaya Tambahan',
                'Rp${_f(value)}',
                leftStyle: smallStyle,
              );
            }
          } else if (tx.additionalCharges > 0) {
            drawRow(
              'Biaya Tambahan',
              'Rp${_f(tx.additionalCharges)}',
              leftStyle: smallStyle,
            );
          }
          drawRule(top: 4, bottom: 12);
        }

        drawRow(
          'TOTAL',
          'Rp${_f(tx.grandTotal)}',
          leftStyle: totalStyle,
          rightStyle: totalStyle.copyWith(color: brand),
          bottom: 12,
        );
        drawRow(
          'Bayar',
          'Rp${_f(tx.amountPaid)}',
          leftStyle: smallStyle,
        );
        if (tx.changeAmount > 0) {
          drawRow(
            'Kembali',
            'Rp${_f(tx.changeAmount)}',
            leftStyle: smallStyle,
          );
        }

        drawRule(top: 8, bottom: 14);

        drawText(
          _footer.trim().isNotEmpty
              ? _footer.trim()
              : 'Terima kasih telah menggunakan layanan kami.',
          smallStyle,
          align: TextAlign.center,
          bottom: 10,
        );
        if (_showWatermark) {
          drawText(
            _poweredWatermarkText,
            smallBoldStyle.copyWith(color: brand),
            align: TextAlign.center,
            bottom: 8,
          );
        }
        drawScanCodeBlock();

        return y + 34;
      }

      final height = render(null).ceil();
      if (height <= 0) return null;

      final recorder = ui.PictureRecorder();
      final canvas = Canvas(recorder);
      canvas.drawRect(
        Rect.fromLTWH(0, 0, imageWidth.toDouble(), height.toDouble()),
        Paint()..color = const Color(0xFFF3F7F7),
      );
      final cardPath = Path()
        ..addRRect(
          RRect.fromRectAndRadius(
            Rect.fromLTWH(24, 24, imageWidth - 48, height - 48),
            const Radius.circular(6),
          ),
        );
      canvas.drawShadow(
        cardPath,
        Colors.black.withValues(alpha: 0.16),
        12,
        false,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(24, 24, imageWidth - 48, height - 48),
          const Radius.circular(6),
        ),
        Paint()..color = Colors.white,
      );
      render(canvas);
      final picture = recorder.endRecording();
      final image = await picture.toImage(imageWidth, height);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      picture.dispose();
      return byteData?.buffer.asUint8List();
    } catch (e) {
      debugPrint('Gagal generate PNG struk WhatsApp: $e');
      return null;
    } finally {
      logoImage?.dispose();
    }
  }

  String _buildWhatsappImageCaption({
    required String namaservis,
    required String noTx,
    required String tanggal,
    required String total,
  }) {
    return '''
Terima kasih telah menggunakan layanan $namaservis.

Berikut struk transaksi Anda.
No. Struk: $noTx
Tanggal: $tanggal
Total: $total

Silakan hubungi kami jika ada pertanyaan.
'''
        .trim();
  }

  String _buildWhatsappTextCaption({
    required String namaservis,
    required String receiptText,
  }) {
    return '''
Terima kasih telah menggunakan layanan $namaservis.

Berikut struk transaksi Anda:

$receiptText

Silakan hubungi kami jika ada pertanyaan.
'''
        .trim();
  }

  Future<void> _sendWhatsappTextFallback(
    String message,
    String? phone,
  ) async {
    final success =
        await WhatsAppHelper.sendMessage(message: message, phone: phone);
    if (!success) {
      throw 'Gagal membuka WhatsApp. Pastikan WhatsApp terinstal atau WhatsApp Web bisa dibuka.';
    }
  }

  // ignore: unused_element
  Future<void> _bagikan() async {
    if (_tx == null) return;
    setState(() => _printing = true);
    try {
      final imageBytes = await _captureShareImage();
      if (imageBytes == null) throw 'Gagal mengambil gambar struk';
      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/struk_${_tx!.id ?? 0}.png');
      await file.writeAsBytes(imageBytes, flush: true);
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path, mimeType: 'image/png')],
          text: 'Struk Servis - $_namaservis',
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Gagal berbagi struk. Silakan coba lagi.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
    } finally {
      if (mounted) setState(() => _printing = false);
    }
  }

  Future<void> _shareWhatsappImage({
    required String namaservis,
    required String noTx,
    required String tanggal,
    required String total,
  }) async {
    final generatedImage = await _buildWhatsappReceiptImage(
      namaservis: namaservis,
      noTx: noTx,
      tanggal: tanggal,
    );
    final imageBytes = generatedImage ??
        await _captureShareImage(preferredPixelRatio: 2.1) ??
        await _captureShareImage(preferredPixelRatio: 1.2);
    if (imageBytes == null) {
      throw 'Gagal membuat gambar struk. Coba buka ulang halaman struk lalu kirim lagi.';
    }

    final tempDir = await getTemporaryDirectory();
    final file = File('${tempDir.path}/struk_wa_${_tx!.id ?? 0}.png');
    await file.writeAsBytes(imageBytes, flush: true);
    final safeNoTx = noTx.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    await SharePlus.instance.share(
      ShareParams(
        files: [
          XFile(
            file.path,
            mimeType: 'image/png',
            name: 'struk_$safeNoTx.png',
          ),
        ],
        text: _buildWhatsappImageCaption(
          namaservis: namaservis,
          noTx: noTx,
          tanggal: tanggal,
          total: total,
        ),
        subject: 'Struk $noTx',
      ),
    );
  }

  Future<void> _shareToWhatsapp() async {
    if (_tx == null) return;
    setState(() => _printing = true);
    try {
      String? phone;
      if (_tx!.customerId != null) {
        final customers = await DBHelper.instance.getAllCustomers();
        final found = customers.where((c) => c.id == _tx!.customerId).toList();
        if (found.isNotEmpty) phone = found.first.phone;
      }

      final namaservis = await _resolveStoreNameForReceipt();
      final noTx = _formatNoTransaksi(_tx!, storeName: namaservis);
      final tanggal = DateFormat('dd-MM-yyyy HH:mm').format(
        DateTime.tryParse(_tx!.createdAt) ?? DateTime.now(),
      );
      final total = 'Rp${_f(_tx!.grandTotal)}';
      final textReceipt = _buildWhatsappReceiptText(
        namaservis: namaservis,
        noTx: noTx,
        tanggal: tanggal,
      );
      final textCaption = _buildWhatsappTextCaption(
        namaservis: namaservis,
        receiptText: textReceipt,
      );

      if (Platform.isAndroid || Platform.isIOS) {
        try {
          await _shareWhatsappImage(
            namaservis: namaservis,
            noTx: noTx,
            tanggal: tanggal,
            total: total,
          );
        } catch (e) {
          debugPrint('Kirim struk gambar gagal, fallback ke teks WA: $e');
          await _sendWhatsappTextFallback(textCaption, phone);
        }
        return;
      }

      await _sendWhatsappTextFallback(textCaption, phone);
    } catch (e) {
      if (!mounted) return;
      final msg = e.toString().replaceAll('Exception: ', '');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(msg),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape:
              const RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
    } finally {
      if (mounted) setState(() => _printing = false);
    }
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final navigator = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final confirmed = await showKasirDeleteConfirmDialog(
      context,
      title: 'Hapus Transaksi?',
      message:
          'Transaksi akan dipindahkan ke riwayat terhapus. Stok barang dan saldo akan dikembalikan secara otomatis.',
    );

    if (confirmed == true) {
      await ref
          .read(transactionsProvider.notifier)
          .deleteTransaction(widget.transactionId);

      if (!mounted || !context.mounted) return;

      // Close the StrukScreen first
      navigator.pop();

      // Then show the success message on the parent screen
      messenger.showSnackBar(
        const SnackBar(
          content: Text('Transaksi Berhasil Dihapus'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: Colors.white,
        body: Center(child: CircularProgressIndicator(color: _kBrand)),
      );
    }

    final tx = _tx!;
    String tanggalStr = '';
    try {
      final dt = DateTime.parse(tx.createdAt);
      tanggalStr = DateFormat('dd-MM-yyyy HH:mm').format(dt);
    } catch (_) {
      tanggalStr = tx.createdAt;
    }

    final mq = MediaQuery.of(context);
    final isTablet = mq.size.shortestSide >= 600;
    final isLandscape = mq.orientation == Orientation.landscape;

    final content = isTablet || isLandscape
        ? _buildWideLayout(context, tx, tanggalStr, isTablet: isTablet)
        : _buildPortraitLayout(context, tx, tanggalStr);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        Navigator.pushNamedAndRemoveUntil(
          context,
          '/dashboard',
          (_) => false,
        );
      },
      child: content,
    );
  }

  //
  // LAYOUT: PORTRAIT (original)
  //
  Widget _buildPortraitLayout(
      BuildContext context, Transaction tx, String tanggalStr) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        leading: widget.isAfterPayment
            ? null
            : GestureDetector(
                onTap: () => Navigator.pop(context),
                child: const Padding(
                  padding: EdgeInsets.only(left: 12),
                  child: Icon(Icons.arrow_back_ios_rounded,
                      color: _kBrand, size: 20),
                ),
              ),
        title: const Text('Struk',
            style: TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.bold,
                fontSize: 20)),
        centerTitle: false,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: _printing
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        color: _kBrand, strokeWidth: 2))
                : IconButton(
                    icon: const Icon(AppIcons.recycleBin,
                        color: Colors.redAccent),
                    onPressed: () => _confirmDelete(context),
                  ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: IconButton(
              icon: const Icon(Icons.settings_rounded, color: _kBrand),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const PengaturanStrukScreen()),
              ),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: const Color(0xFFEEEEEE)),
        ),
      ),
      body: Stack(
        children: [
          Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: _buildReceiptContent(tx, tanggalStr,
                      showReturButtons: true, showActionButtons: false),
                ),
              ),
              _buildActionBar(context, tx),
            ],
          ),
          Positioned(
            left: -9999,
            child: _buildReceiptCard(tx, tanggalStr),
          ),
          // Off-screen: thermal receipt widget untuk cetak desktop
          Positioned(
            left: -9999,
            child: RepaintBoundary(
              key: _printKey,
              child: _buildThermalReceiptWidget(tx, tanggalStr),
            ),
          ),
        ],
      ),
    );
  }

  //
  // LAYOUT: LANDSCAPE / TABLET
  // Left: Gradient sidebar -- transaction info + action buttons
  // Right: Scrollable receipt content
  //
  Widget _buildWideLayout(
    BuildContext context,
    Transaction tx,
    String tanggalStr, {
    required bool isTablet,
  }) {
    final sideWidth = isTablet ? 300.0 : 260.0;

    return Scaffold(
      backgroundColor: _kBg,
      body: Stack(
        children: [
          Row(
            children: [
              SizedBox(
                width: sideWidth,
                child: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_kBrand, _kTealDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.zero,
                      bottomRight: Radius.zero,
                    ),
                  ),
                  child: SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Title + Settings
                          Row(
                            children: [
                              if (!widget.isAfterPayment) ...[
                                GestureDetector(
                                  onTap: () => Navigator.pop(context),
                                  child: Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color:
                                          Colors.white.withValues(alpha: 0.15),
                                      borderRadius: BorderRadius.zero,
                                    ),
                                    child: const Icon(
                                        Icons.arrow_back_ios_rounded,
                                        color: Colors.white,
                                        size: 18),
                                  ),
                                ),
                                const SizedBox(width: 12),
                              ],
                              const Icon(Icons.receipt_long_rounded,
                                  color: Colors.white, size: 24),
                              const SizedBox(width: 12),
                              const Text(
                                'Struk',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const Spacer(),
                              GestureDetector(
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        const PengaturanStrukScreen(),
                                  ),
                                ),
                                child: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withValues(alpha: 0.15),
                                    borderRadius: BorderRadius.zero,
                                  ),
                                  child: const Icon(Icons.settings_rounded,
                                      color: Colors.white, size: 18),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 24),

                          // Receipt icon
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: const Icon(Icons.receipt_long_rounded,
                                color: Colors.white, size: 30),
                          ),
                          const SizedBox(height: 20),

                          // Transaction summary
                          Text(
                            'RINGKASAN TRANSAKSI',
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.6),
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.5,
                            ),
                          ),
                          // Summary items
                          Expanded(
                            child: SingleChildScrollView(
                              padding: EdgeInsets.zero,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _SideTxRow(
                                    icon: Icons.tag_rounded,
                                    label: 'No Struk',
                                    value: _formatNoTransaksi(
                                      tx,
                                      storeName: _namaservis,
                                    ),
                                    small: true,
                                  ),
                                  const SizedBox(height: 8),
                                  _SideTxRow(
                                    icon: Icons.calendar_today_rounded,
                                    label: 'Tanggal',
                                    value: tanggalStr,
                                    small: true,
                                  ),
                                  const SizedBox(height: 8),
                                  _SideTxRow(
                                    icon: Icons.payment_rounded,
                                    label: 'Metode',
                                    value: _methodLabel(tx.paymentMethod),
                                  ),
                                  if (tx.customerName?.isNotEmpty ?? false)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 8),
                                      child: Column(
                                        children: [
                                          _SideTxRow(
                                            icon: Icons.person_outline_rounded,
                                            label: 'Pelanggan',
                                            value: tx.customerName!,
                                            small: true,
                                          ),
                                          if (_customer?.phone != null &&
                                              _customer!.phone!.isNotEmpty)
                                            _SideTxRow(
                                              icon: Icons.phone_android_rounded,
                                              label: 'Telepon',
                                              value: _customer!.phone!,
                                              small: true,
                                            ),
                                        ],
                                      ),
                                    ),
                                  if (tx.orderType?.isNotEmpty ?? false)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 8),
                                      child: _SideTxRow(
                                        icon: Icons.shopping_bag_outlined,
                                        label: 'Pesanan',
                                        value: tx.orderType!,
                                        small: true,
                                      ),
                                    ),
                                  if (tx.paymentStatus?.isNotEmpty ?? false)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 8),
                                      child: _SideTxRow(
                                        icon: Icons.info_outline_rounded,
                                        label: 'Status',
                                        value: tx.paymentStatus!,
                                        small: true,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),

                          const SizedBox(height: 16),

                          // Grand total card
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 12),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('TOTAL',
                                    style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 1,
                                    )),
                                Text(
                                  'Rp ${_f(tx.grandTotal)}',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 12),

                          // Action buttons are now moved to the bottom of receipt content
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 112),
                  child: _buildReceiptContent(tx, tanggalStr,
                      showReturButtons: true, showActionButtons: false),
                ),
              ),
            ],
          ),
          Positioned(
            left: sideWidth,
            right: 0,
            bottom: 0,
            child: _buildWideActionBar(context, tx),
          ),

          // Offstage receipt for sharing
          Positioned(
            left: -9999,
            child: _buildReceiptCard(tx, tanggalStr),
          ),

          // Off-screen: thermal receipt widget untuk cetak desktop
          Positioned(
            left: -9999,
            child: RepaintBoundary(
              key: _printKey,
              child: _buildThermalReceiptWidget(tx, tanggalStr),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWideActionBar(BuildContext context, Transaction tx) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 14,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () {
                  final station = ref.read(selectedservisOrderStationProvider);
                  if (station != null) {
                    ref.read(shellIndexProvider.notifier).set(10);
                  } else {
                    ref.read(shellIndexProvider.notifier).set(1);
                  }
                  Navigator.pushNamedAndRemoveUntil(
                      context, '/dashboard', (_) => false);
                },
                icon: const Icon(Icons.home_rounded,
                    color: Colors.white, size: 20),
                label: const Text('SELESAI / BERANDA',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.4,
                        fontSize: 13)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF334155),
                  minimumSize: const Size.fromHeight(58),
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: _printing ? null : _cetakStruk,
                icon: _printing
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2))
                    : const Icon(Icons.print_rounded,
                        color: Colors.white, size: 18),
                label: Text(
                  _printing ? 'Mencetak...' : 'Cetak Struk',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.3,
                      fontSize: 13),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _kBrand,
                  disabledBackgroundColor: Colors.grey.shade400,
                  elevation: 0,
                  minimumSize: const Size.fromHeight(58),
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _tx == null ? null : _shareToWhatsapp,
                icon: const Icon(Icons.chat_bubble_outline_rounded,
                    color: Color(0xFF2E7D32), size: 18),
                label: const Text('Kirim WhatsApp',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: Color(0xFF2E7D32),
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.3,
                        fontSize: 13)),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Color(0xFF2E7D32), width: 1.5),
                  minimumSize: const Size.fromHeight(58),
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  backgroundColor: Colors.white,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReceiptContent(
    Transaction tx,
    String tanggalStr, {
    required bool showReturButtons,
    bool showActionButtons = true,
  }) {
    final transactionNote = _transactionNoteText(tx);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Store header
        if (_namaservis.isNotEmpty) ...[
          Text(
            _namaservis,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            softWrap: true,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: _receiptStoreNameFontSize(),
              letterSpacing: 1.0,
              height: 1.08,
            ),
          ),
          if (_alamat.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(_alamat,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 13, color: Colors.black54)),
            ),
          if (_telepon.isNotEmpty)
            Text(_telepon,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 13, color: Colors.black54)),
          const SizedBox(height: 12),
          const Divider(height: 1, color: Color(0xFFDDDDDD)),
          const SizedBox(height: 12),
        ],

        // Info rows
        _InfoRow(
            label: 'No',
            value: _formatNoTransaksi(tx, storeName: _namaservis),
            valueBold: true),
        _InfoRow(label: 'Tanggal', value: tanggalStr, valueBold: true),
        if (_kasirName.isNotEmpty)
          _InfoRow(label: 'Server', value: _kasirName, valueBold: true),
        _InfoRow(
            label: 'Metode Bayar',
            value: _methodLabel(tx.paymentMethod),
            valueBold: true),
        if (tx.customerName?.isNotEmpty ?? false)
          _InfoRow(
              label: 'Pelanggan', value: tx.customerName!, valueBold: true),
        if (tx.orderType?.isNotEmpty ?? false)
          _InfoRow(label: 'Jenis', value: tx.orderType!, valueBold: true),
        if (_estimasiPengambilan != null)
          _InfoRow(
              label: 'Estimasi Pengambilan',
              value: DateFormat('EEE, dd MMM yyyy HH:mm', 'id')
                  .format(_estimasiPengambilan!),
              valueBold: true),
        if (tx.servisStatus.isNotEmpty)
          _InfoRow(label: 'Status', value: tx.servisStatus, valueBold: true),
        if (tx.kelengkapan != null &&
            tx.kelengkapan!.isNotEmpty &&
            tx.kelengkapan != 'None')
          _InfoRow(label: 'Parfum', value: tx.kelengkapan!, valueBold: true),
        if (tx.paymentStatus?.isNotEmpty ?? false)
          _InfoRow(
              label: 'Status Bayar', value: tx.paymentStatus!, valueBold: true),

        const SizedBox(height: 12),
        const Divider(height: 1, color: Color(0xFFDDDDDD)),
        const SizedBox(height: 12),

        // Items
        ..._itemsWithExtra.map((data) {
          final item = data['item'] as TransactionItem;
          final isExtra = data['isExtra'] == 1;
          final itemNote = _itemNoteText(item);
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              if (isExtra)
                                Container(
                                  margin: const EdgeInsets.only(right: 6),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 4, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: _kBrand.withValues(alpha: 0.1),
                                    borderRadius: BorderRadius.zero,
                                  ),
                                  child: const Text('ADD ON',
                                      style: TextStyle(
                                          color: _kBrand,
                                          fontSize: 8,
                                          fontWeight: FontWeight.bold)),
                                ),
                              if (item.hasPriceOverride)
                                Container(
                                  margin: const EdgeInsets.only(right: 6),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 4, vertical: 2),
                                  decoration: const BoxDecoration(
                                    color: Color(0xFF0F766E),
                                    borderRadius: BorderRadius.zero,
                                  ),
                                  child: const Text('HARGA DIUBAH',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 8,
                                          fontWeight: FontWeight.bold)),
                                ),
                              Expanded(
                                child: Text(item.productName,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w500,
                                        fontSize: 14)),
                              ),
                            ],
                          ),
                          Text(_itemPriceLine(item),
                              style: const TextStyle(
                                  fontSize: 13, color: Colors.black54)),
                          if (item.hasAppliedPromo)
                            Text(
                              _getItemOriginalPriceLine(item),
                              style: const TextStyle(
                                  fontSize: 11.5, color: Colors.black45),
                            ),
                          if (item.hasAppliedPromo)
                            Text(
                              _getItemPromoPriceLine(item),
                              style: const TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w600,
                                color: _kBrand,
                              ),
                            ),
                          if (item.hasPriceOverride)
                            Text(
                              _getItemPriceOverrideLine(item),
                              style: const TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF0F766E),
                              ),
                            ),
                          if (itemNote.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 2),
                              child: Text(itemNote,
                                  style: const TextStyle(
                                      fontSize: 10,
                                      color: Colors.black54,
                                      fontStyle: FontStyle.italic)),
                            ),
                        ],
                      ),
                    ),
                    Text('Rp${_f(item.subtotal)}',
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14)),
                  ],
                ),
                if (showReturButtons) ...[
                  // Return status & quantity
                  Builder(builder: (context) {
                    final returnedQty = _returnedQtyMap[item.productId] ?? 0.0;
                    final remainingQty = item.qty - returnedQty;
                    final isFullRetur = remainingQty <= 0;

                    return Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          if (returnedQty > 0)
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Icon(
                                  isFullRetur
                                      ? Icons.check_circle_rounded
                                      : Icons.info_outline_rounded,
                                  size: 14,
                                  color: isFullRetur
                                      ? const Color(0xFF2E7D32)
                                      : const Color(0xFFE65100),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  isFullRetur
                                      ? 'Berhasil Refund'
                                      : 'Telah diretur ${_fmtD(returnedQty)} item',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: isFullRetur
                                        ? const Color(0xFF2E7D32)
                                        : const Color(0xFFE65100),
                                  ),
                                ),
                              ],
                            ),
                          if (!isFullRetur)
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: OutlinedButton.icon(
                                onPressed: () => _showReturDialog(item,
                                    remaining: remainingQty.toDouble()),
                                icon: const Icon(Icons.turn_left_rounded,
                                    size: 15),
                                label: const Text('Refund Layanan'),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: const Color(0xFFE65100),
                                  side: const BorderSide(
                                      color: Color(0xFFE65100), width: 1.2),
                                  minimumSize: const Size(100, 32),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12),
                                  shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.zero),
                                  textStyle: const TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700),
                                ),
                              ),
                            ),
                        ],
                      ),
                    );
                  }),
                ],
              ],
            ),
          );
        }),

        const Divider(height: 1, color: Color(0xFFDDDDDD)),
        const SizedBox(height: 10),

        // Totals
        _InfoRow(label: 'Total Pesanan', value: 'Rp${_f(tx.totalAmount)}'),
        if (tx.discountAmount > 0)
          _InfoRow(
              label: _getDiskonLabel(tx),
              value: '- Rp${_f(tx.discountAmount)}',
              valueColor: _kBrand),
        if (tx.chargesList.isNotEmpty)
          ...tx.chargesList.map((c) {
            final catatan = c['catatan']?.toString() ?? '';
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _InfoRow(
                    label: c['label']?.toString() ?? 'Biaya Tambahan',
                    value: 'Rp${_f(c['value'] as int? ?? 0)}'),
                if (catatan.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(left: 4, bottom: 2),
                    child: Text(catatan,
                        style: const TextStyle(
                            fontSize: 11,
                            color: Colors.black45,
                            fontStyle: FontStyle.italic)),
                  ),
              ],
            );
          })
        else if (tx.additionalCharges > 0)
          _InfoRow(
              label: 'Biaya Tambahan', value: 'Rp${_f(tx.additionalCharges)}'),

        const SizedBox(height: 4),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Total',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            Text('Rp${_f(tx.grandTotal)}',
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          ],
        ),
        const SizedBox(height: 6),
        _InfoRow(label: 'Bayar', value: 'Rp${_f(tx.amountPaid)}'),
        if (tx.changeAmount > 0)
          _InfoRow(label: 'Kembali', value: 'Rp${_f(tx.changeAmount)}'),

        const SizedBox(height: 12),
        const Divider(height: 1, color: Color(0xFFDDDDDD)),
        const SizedBox(height: 12),

        if (_instagram.isNotEmpty ||
            _facebook.isNotEmpty ||
            _tiktok.isNotEmpty) ...[
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 8,
            runSpacing: 4,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              if (_instagram.isNotEmpty)
                _sosmedRow(Icons.camera_alt_outlined, _instagram),
              if (_facebook.isNotEmpty)
                _sosmedRow(Icons.facebook_outlined, _facebook),
              if (_tiktok.isNotEmpty)
                _sosmedRow(Icons.music_note_outlined, _tiktok),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(height: 1, color: Color(0xFFDDDDDD)),
          const SizedBox(height: 12),
        ],

        // Footer
        if (transactionNote.isNotEmpty) ...[
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              border: Border.all(color: const Color(0xFFE2E8F0)),
              borderRadius: BorderRadius.zero,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Catatan Tambahan',
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF64748B),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  transactionNote,
                  textAlign: TextAlign.left,
                  style: const TextStyle(
                    fontSize: 12,
                    height: 1.35,
                    color: Color(0xFF334155),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],
        Text(
          _footer.isNotEmpty ? _footer : 'Terima kasih telah berbelanja!',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 16),
        // Barcode Preview
        Center(
          child: Column(
            children: [
              SizedBox(
                width: 100,
                height: 100,
                child: BarcodeWidget(
                  barcode: Barcode.qrCode(),
                  data: _formatNoTransaksi(_tx!, storeName: _namaservis),
                  drawText: false,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                _formatNoTransaksi(_tx!, storeName: _namaservis),
                style: const TextStyle(fontSize: 10, color: Colors.black45),
              ),
            ],
          ),
        ),

        //  Tombol Cetak & WhatsApp
        if (showActionButtons) ...[
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _printing ? null : _cetakStruk,
                  icon: _printing
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2))
                      : const Icon(Icons.print_rounded,
                          color: Colors.white, size: 18),
                  label: Text(
                    _printing ? 'Mencetak...' : 'Cetak Struk',
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.3,
                        fontSize: 13),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kBrand,
                    disabledBackgroundColor: Colors.grey.shade400,
                    elevation: 0,
                    minimumSize: const Size.fromHeight(56),
                    padding: const EdgeInsets.symmetric(vertical: 20),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _tx == null ? null : _shareToWhatsapp,
                  icon: const Icon(Icons.chat_bubble_outline_rounded,
                      color: Color(0xFF2E7D32), size: 18),
                  label: const Text('Kirim WhatsApp',
                      style: TextStyle(
                          color: Color(0xFF2E7D32),
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.3,
                          fontSize: 13)),
                  style: OutlinedButton.styleFrom(
                    side:
                        const BorderSide(color: Color(0xFF2E7D32), width: 1.5),
                    minimumSize: const Size.fromHeight(56),
                    padding: const EdgeInsets.symmetric(vertical: 20),
                    backgroundColor: Colors.white,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          //  Tombol Selesai (Desktop/Main)
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                final station = ref.read(selectedservisOrderStationProvider);
                if (station != null) {
                  ref
                      .read(shellIndexProvider.notifier)
                      .set(10); // Servis Status
                } else {
                  ref.read(shellIndexProvider.notifier).set(1); // Kasir
                }
                Navigator.pushNamedAndRemoveUntil(
                    context, '/dashboard', (_) => false);
              },
              icon:
                  const Icon(Icons.home_rounded, color: Colors.white, size: 24),
              label: const Text('SELESAI / BERANDA',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.8,
                      fontSize: 16)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF334155), // Professional slate
                padding: const EdgeInsets.symmetric(vertical: 24),
                elevation: 0,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
            ),
          ),
        ],
        const SizedBox(height: 12),
      ],
    );
  }

  Widget _buildActionBar(BuildContext context, Transaction tx) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 26),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: Color(0xFFEEEEEE))),
        color: Colors.white,
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            //  Baris 1: Cetak Struk + Kirim WA
            Row(
              children: [
                // Cetak Struk
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _printing ? null : _cetakStruk,
                    icon: _printing
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2))
                        : const Icon(Icons.print_rounded,
                            color: Colors.white, size: 18),
                    label: Text(
                      _printing ? 'Mencetak...' : 'Cetak Struk',
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.3,
                          fontSize: 13),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      disabledBackgroundColor: Colors.grey.shade400,
                      elevation: 0,
                      minimumSize: const Size.fromHeight(56),
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                // Kirim WhatsApp
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _tx == null ? null : _shareToWhatsapp,
                    icon: const Icon(Icons.send_rounded,
                        color: Color(0xFF2E7D32), size: 18),
                    label: const Text('Kirim WA',
                        style: TextStyle(
                            color: Color(0xFF2E7D32),
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.3,
                            fontSize: 13)),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(
                          color: Color(0xFF2E7D32), width: 1.5),
                      minimumSize: const Size.fromHeight(56),
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      backgroundColor: Colors.white,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            //  Baris 2: Selesai / Beranda (full width)
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.pushNamedAndRemoveUntil(
                  context,
                  '/dashboard',
                  (_) => false,
                ),
                icon: const Icon(Icons.home_rounded,
                    color: Colors.white, size: 22),
                label: const Text('SELESAI / BERANDA',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                        fontSize: 15)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF334155),
                  minimumSize: const Size.fromHeight(58),
                  padding: const EdgeInsets.symmetric(vertical: 22),
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  //
  // THERMAL RECEIPT WIDGET  untuk cetak desktop (mirip ESC/POS)
  // Hitam putih bersih, layout monospace, tidak ada gradient.
  // Di-render off-screen lalu di-capture sebagai PNG resolusi tinggi
  // sebelum di-embed ke PDF  tidak ada font rendering issue.
  //
  Widget _buildThermalReceiptWidget(Transaction tx, String tanggalStr) {
    // Ambil ukuran kertas dari prefs tidak bisa async di sini,
    // jadi kita pakai lebar fixed yang cukup representatif (58mm = 360px).
    // Saat cetak, PDF di-scale ke lebar kertas yang sebenarnya.
    const double cardWidth = 360.0;
    const TextStyle mono = TextStyle(
      fontFamily: 'Courier',
      color: Colors.black,
      fontSize: 13,
      height: 1.35,
    );
    const TextStyle monoBold = TextStyle(
      fontFamily: 'Courier',
      color: Colors.black,
      fontSize: 13,
      fontWeight: FontWeight.bold,
      height: 1.35,
    );
    const TextStyle monoSmall = TextStyle(
      fontFamily: 'Courier',
      color: Colors.black,
      fontSize: 11,
      height: 1.3,
    );
    final TextStyle monoTitle = TextStyle(
      fontFamily: 'Courier',
      color: Colors.black,
      fontSize: _thermalStoreNameFontSize(),
      fontWeight: FontWeight.bold,
      height: 1.18,
    );
    final TextStyle monoTitleCompact = TextStyle(
      fontFamily: 'Courier',
      color: Colors.black,
      fontSize: _thermalStoreNameFontSize(compact: true),
      fontWeight: FontWeight.bold,
      height: 1.12,
    );

    Widget hr() => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Text('-' * 38,
              style: mono.copyWith(fontSize: 11),
              overflow: TextOverflow.clip,
              maxLines: 1),
        );

    Widget row2(String left, String right,
        {TextStyle? leftStyle, TextStyle? rightStyle}) {
      return Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(left,
                style: leftStyle ?? mono, overflow: TextOverflow.clip),
          ),
          const SizedBox(width: 4),
          Text(right, style: rightStyle ?? mono, textAlign: TextAlign.right),
        ],
      );
    }

    final noTx = _formatNoTransaksi(tx, storeName: _namaservis);

    return Material(
      color: Colors.white,
      child: SizedBox(
        width: cardWidth,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              // 1. Logo TOP
              if (_logoPath.isNotEmpty && _logoPosition == 'top') ...[
                Center(
                    child: Image.file(File(_logoPath),
                        height: _logoWidth * 1.5, fit: BoxFit.contain)),
                const SizedBox(height: 12),
              ],

              //  HEADER
              if (_namaservis.isNotEmpty) ...[
                if (_logoPosition == 'left' && _logoPath.isNotEmpty)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.file(File(_logoPath),
                          height: _logoWidth, width: _logoWidth),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          _namaservis.toUpperCase(),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          softWrap: true,
                          style: monoTitleCompact,
                        ),
                      ),
                    ],
                  )
                else
                  Text(
                    _namaservis.toUpperCase(),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    softWrap: true,
                    textAlign: TextAlign.center,
                    style: monoTitle,
                  ),
                if (_alamat.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(_alamat,
                        textAlign: TextAlign.center, style: monoSmall),
                  ),
                if (_telepon.isNotEmpty)
                  Text('Telp: $_telepon',
                      textAlign: TextAlign.center, style: monoSmall),
                const SizedBox(height: 4),
              ],

              hr(),

              //  INFO TRANSAKSI
              const SizedBox(height: 2),
              Align(
                alignment: Alignment.centerLeft,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    row2('No  : $noTx', '', leftStyle: monoSmall),
                    row2('Tgl : $tanggalStr', '', leftStyle: monoSmall),
                    if (_kasirName.isNotEmpty)
                      row2('Petugas: $_kasirName', '', leftStyle: monoSmall),
                    row2('Metode: ${_methodLabel(tx.paymentMethod)}', '',
                        leftStyle: monoSmall),
                    if (tx.customerName?.isNotEmpty ?? false)
                      row2('Cust : ${tx.customerName}', '',
                          leftStyle: monoSmall),
                    if (_customer?.phone != null &&
                        _customer!.phone!.isNotEmpty)
                      row2('Telp : ${_customer!.phone}', '',
                          leftStyle: monoSmall),
                    if (tx.orderType?.isNotEmpty ?? false)
                      row2('Jenis: ${tx.orderType}', '', leftStyle: monoSmall),
                    if (_estimasiPengambilan != null)
                      row2(
                          'Est.Ambil: ${DateFormat('EEE, dd MMM yyyy HH:mm', 'id').format(_estimasiPengambilan!)}',
                          '',
                          leftStyle: monoSmall),
                    if (tx.paymentStatus?.isNotEmpty ?? false)
                      row2('Status Bayar: ${tx.paymentStatus}', '',
                          leftStyle: monoSmall),
                  ],
                ),
              ),
              const SizedBox(height: 2),

              hr(),
              const SizedBox(height: 2),

              //  ITEMS
              ..._itemsWithExtra.map((data) {
                final item = data['item'] as TransactionItem;
                final bool isExtra = data['isExtra'] == 1;
                final itemNote = _itemNoteText(item);
                final String name =
                    isExtra ? '${item.productName} (Add-on)' : item.productName;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name,
                          style: monoBold,
                          overflow: TextOverflow.clip,
                          maxLines: 2),
                      if (item.hasAppliedPromo)
                        Text(
                          '  ${_getItemOriginalPriceLine(item)}',
                          style: monoSmall,
                        ),
                      if (item.hasAppliedPromo)
                        Text(
                          '  ${_getItemPromoPriceLine(item)}',
                          style:
                              monoSmall.copyWith(fontWeight: FontWeight.w700),
                        ),
                      if (item.hasPriceOverride)
                        Text(
                          '  ${_getItemPriceOverrideLine(item)}',
                          style:
                              monoSmall.copyWith(fontWeight: FontWeight.w700),
                        ),
                      row2(
                        '  ${_itemPriceLine(item)}',
                        'Rp${_f(item.subtotal)}',
                      ),
                      if (itemNote.isNotEmpty)
                        Text('  *$itemNote*', style: monoSmall),
                    ],
                  ),
                );
              }),

              const SizedBox(height: 2),
              hr(),
              const SizedBox(height: 4),

              //  TOTALS
              row2('Subtotal', 'Rp${_f(tx.totalAmount)}'),
              if (tx.discountAmount > 0)
                row2(_getDiskonLabel(tx), '- Rp${_f(tx.discountAmount)}'),
              if (tx.chargesList.isNotEmpty)
                ...tx.chargesList.expand((c) {
                  final catatan = c['catatan']?.toString() ?? '';
                  return [
                    row2(c['label']?.toString() ?? 'Biaya',
                        'Rp${_f(c['value'] as int? ?? 0)}'),
                    if (catatan.isNotEmpty)
                      Text('  *$catatan*', style: monoSmall),
                  ];
                })
              else if (tx.additionalCharges > 0)
                row2('Biaya Tambahan', 'Rp${_f(tx.additionalCharges)}'),

              const SizedBox(height: 2),
              const Divider(height: 1, color: Colors.black),
              const SizedBox(height: 4),

              row2(
                'TOTAL',
                'Rp${_f(tx.grandTotal)}',
                leftStyle: monoBold.copyWith(fontSize: 14),
                rightStyle: monoBold.copyWith(fontSize: 14),
              ),

              const SizedBox(height: 2),
              const Divider(height: 1, color: Colors.black),
              const SizedBox(height: 4),

              row2('Bayar', 'Rp${_f(tx.amountPaid)}'),
              if (tx.changeAmount > 0)
                row2('Kembalian', 'Rp${_f(tx.changeAmount)}'),

              const SizedBox(height: 6),
              hr(),
              const SizedBox(height: 4),

              //  SOSMED
              if (_instagram.isNotEmpty ||
                  _facebook.isNotEmpty ||
                  _tiktok.isNotEmpty) ...[
                Text(
                  [
                    if (_instagram.isNotEmpty) 'IG:@$_instagram',
                    if (_facebook.isNotEmpty) 'FB:@$_facebook',
                    if (_tiktok.isNotEmpty) 'TT:@$_tiktok',
                  ].join('  '),
                  textAlign: TextAlign.center,
                  style: monoSmall,
                ),
                const SizedBox(height: 4),
                hr(),
                const SizedBox(height: 4),
              ],

              //  FOOTER
              if (_transactionNoteText(tx).isNotEmpty) ...[
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Catatan Tambahan',
                    textAlign: TextAlign.left,
                    style: monoSmall.copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 2),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    _transactionNoteText(tx),
                    textAlign: TextAlign.left,
                    style: monoSmall,
                  ),
                ),
                const SizedBox(height: 4),
                hr(),
                const SizedBox(height: 4),
              ],
              Text(
                _footer.isNotEmpty ? _footer : 'Terima kasih telah berbelanja!',
                textAlign: TextAlign.center,
                style: mono,
              ),
              const SizedBox(height: 4),
              if (_showWatermark)
                Text(
                  '* $_poweredWatermarkText *',
                  textAlign: TextAlign.center,
                  style: monoSmall.copyWith(fontSize: 10),
                ),

              const SizedBox(height: 12),
              // Barcode for Thermal Preview
              Center(
                child: Column(
                  children: [
                    SizedBox(
                      width: 80,
                      height: 80,
                      child: BarcodeWidget(
                        barcode: Barcode.qrCode(),
                        data: noTx,
                        drawText: false,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(noTx, style: monoSmall.copyWith(fontSize: 9)),
                  ],
                ),
              ),

              // 3. Logo BOTTOM
              if (_logoPath.isNotEmpty && _logoPosition == 'bottom') ...[
                const SizedBox(height: 16),
                Center(
                    child: Image.file(File(_logoPath),
                        height: 60, fit: BoxFit.contain)),
              ],

              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildReceiptCard(Transaction tx, String tanggalStr) {
    final noTx = _formatNoTransaksi(tx, storeName: _namaservis);
    const double cardWidth = 360.0;

    return RepaintBoundary(
      key: _shareKey,
      child: SizedBox(
        width: cardWidth,
        child: Material(
          color: Colors.white,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header gradient
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(_sharedColor),
                      Color(_sharedColor).withValues(alpha: 0.8),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Column(
                  children: [
                    Text(
                      _namaservis.isNotEmpty
                          ? _namaservis.toUpperCase()
                          : 'STRUK BELANJA',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'PlusJakartaSans',
                        fontSize: _receiptStoreNameFontSize(),
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 1.2,
                        height: 1.05,
                      ),
                    ),
                    if (_alamat.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(_alamat,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontFamily: 'PlusJakartaSans',
                              fontSize: 12,
                              color: Colors.white70)),
                    ],
                    if (_telepon.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(_telepon,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontFamily: 'PlusJakartaSans',
                              fontSize: 12,
                              color: Colors.white70)),
                    ],
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.zero,
                        border: Border.all(
                            color: Colors.white.withValues(alpha: 0.3)),
                      ),
                      child: Text(noTx,
                          style: const TextStyle(
                            fontFamily: 'PlusJakartaSans',
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                            letterSpacing: 0.5,
                          )),
                    ),
                  ],
                ),
              ),

              _PerforationDivider(),

              // Body
              Container(
                color: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _receiptRow(
                        icon: Icons.calendar_today_rounded,
                        label: 'Tanggal',
                        value: tanggalStr),
                    if (_kasirName.isNotEmpty)
                      _receiptRow(
                          icon: Icons.person_outline_rounded,
                          label: 'Server',
                          value: _kasirName),
                    _receiptRow(
                        icon: Icons.payment_rounded,
                        label: 'Metode Bayar',
                        value: _methodLabel(tx.paymentMethod)),
                    if (tx.customerName?.isNotEmpty ?? false)
                      _receiptRow(
                          icon: Icons.person_outline_rounded,
                          label: 'Pelanggan',
                          value: tx.customerName!),
                    if (tx.orderType?.isNotEmpty ?? false)
                      _receiptRow(
                          icon: Icons.shopping_bag_outlined,
                          label: 'Jenis',
                          value: tx.orderType!),
                    if (_estimasiPengambilan != null)
                      _receiptRow(
                          icon: Icons.calendar_today_rounded,
                          label: 'Estimasi Pengambilan',
                          value: DateFormat('EEE, dd MMM yyyy HH:mm', 'id')
                              .format(_estimasiPengambilan!)),
                    if (tx.paymentStatus?.isNotEmpty ?? false)
                      _receiptRow(
                          icon: Icons.info_outline_rounded,
                          label: 'Status Bayar',
                          value: tx.paymentStatus!),
                    const SizedBox(height: 16),

                    // Items header
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Color(_sharedColor).withValues(alpha: 0.07),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text('Item',
                                style: TextStyle(
                                  fontFamily: 'PlusJakartaSans',
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: Color(_sharedColor),
                                  letterSpacing: 0.5,
                                )),
                          ),
                          Text('Qty',
                              style: TextStyle(
                                fontFamily: 'PlusJakartaSans',
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: Color(_sharedColor),
                              )),
                          const SizedBox(width: 12),
                          SizedBox(
                            width: 80,
                            child: Text('Subtotal',
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  fontFamily: 'PlusJakartaSans',
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: Color(_sharedColor),
                                )),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),

                    ..._itemsWithExtra.map((data) {
                      final item = data['item'] as TransactionItem;
                      final isExtra = data['isExtra'] == 1;
                      final itemNote = _itemNoteText(item);
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  if (isExtra)
                                    Container(
                                      margin: const EdgeInsets.only(bottom: 3),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: Color(_sharedColor)
                                            .withValues(alpha: 0.1),
                                        borderRadius: BorderRadius.zero,
                                      ),
                                      child: Text('ADD ON',
                                          style: TextStyle(
                                            fontFamily: 'PlusJakartaSans',
                                            color: Color(_sharedColor),
                                            fontSize: 9,
                                            fontWeight: FontWeight.w700,
                                          )),
                                    ),
                                  if (item.hasPriceOverride)
                                    Container(
                                      margin: const EdgeInsets.only(bottom: 3),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 6, vertical: 2),
                                      decoration: const BoxDecoration(
                                        color: Color(0xFF0F766E),
                                        borderRadius: BorderRadius.zero,
                                      ),
                                      child: const Text('HARGA DIUBAH',
                                          style: TextStyle(
                                            fontFamily: 'PlusJakartaSans',
                                            color: Colors.white,
                                            fontSize: 9,
                                            fontWeight: FontWeight.w700,
                                          )),
                                    ),
                                  Text(item.productName,
                                      style: const TextStyle(
                                        fontFamily: 'PlusJakartaSans',
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                        color: Color(0xFF0A0F1E),
                                      )),
                                  Builder(builder: (context) {
                                    final retQty =
                                        _returnedQtyMap[item.productId] ?? 0;
                                    if (retQty <= 0) {
                                      return const SizedBox.shrink();
                                    }
                                    final isFull = retQty >= item.qty;
                                    return Container(
                                      margin: const EdgeInsets.only(top: 2),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: isFull
                                            ? const Color(0xFFE8F5E9)
                                            : const Color(0xFFFFF3E0),
                                        borderRadius: BorderRadius.zero,
                                      ),
                                      child: Text(
                                        isFull
                                            ? 'BERHASIL REFUND'
                                            : 'REFUND $retQty ITEM',
                                        style: TextStyle(
                                          fontFamily: 'PlusJakartaSans',
                                          fontSize: 9,
                                          fontWeight: FontWeight.w800,
                                          color: isFull
                                              ? const Color(0xFF2E7D32)
                                              : const Color(0xFFE65100),
                                        ),
                                      ),
                                    );
                                  }),
                                  Text(
                                    'Rp ${_f(item.unitPrice)}${_itemUnit(item).isEmpty ? '' : ' / ${_itemUnit(item)}'}${_getItemSimpleDiscountInfo(item)}',
                                    style: const TextStyle(
                                        fontFamily: 'PlusJakartaSans',
                                        fontSize: 11,
                                        color: Color(0xFF8B95A5)),
                                  ),
                                  if (item.hasPriceOverride)
                                    Text(
                                      _getItemPriceOverrideLine(item),
                                      style: const TextStyle(
                                        fontFamily: 'PlusJakartaSans',
                                        fontSize: 10,
                                        fontWeight: FontWeight.w700,
                                        color: Color(0xFF0F766E),
                                      ),
                                    ),
                                  if (_hasRoundedBilling(item))
                                    Text(
                                        'Tagih ${_fmtD(_itemBillableQty(item))} ${_itemUnit(item)}',
                                        style: const TextStyle(
                                            fontFamily: 'PlusJakartaSans',
                                            fontSize: 10,
                                            fontWeight: FontWeight.w700,
                                            color: Color(0xFF2563EB))),
                                  if (itemNote.isNotEmpty)
                                    Text(' $itemNote',
                                        style: const TextStyle(
                                            fontFamily: 'PlusJakartaSans',
                                            fontSize: 10,
                                            color: Color(0xFF8B95A5),
                                            fontStyle: FontStyle.italic)),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 30,
                              child: Text(
                                  _itemQtyLabel(item,
                                      includeUnit: _itemUnit(item).isEmpty),
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    fontFamily: 'PlusJakartaSans',
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF0A0F1E),
                                  )),
                            ),
                            SizedBox(
                              width: 80,
                              child: Text('Rp ${_f(item.subtotal)}',
                                  textAlign: TextAlign.right,
                                  style: const TextStyle(
                                    fontFamily: 'PlusJakartaSans',
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    color: Color(0xFF0A0F1E),
                                  )),
                            ),
                          ],
                        ),
                      );
                    }),

                    Container(height: 1, color: const Color(0xFFE2E4E8)),
                    const SizedBox(height: 12),

                    if (tx.discountAmount > 0 ||
                        tx.chargesList.isNotEmpty ||
                        tx.additionalCharges > 0) ...[
                      _subtotalRow('Total Pesanan', 'Rp ${_f(tx.totalAmount)}'),
                      if (tx.discountAmount > 0)
                        _subtotalRow(_getDiskonLabel(tx),
                            '- Rp ${_f(tx.discountAmount)}',
                            valueColor: const Color(0xFF00A86B)),
                      if (tx.chargesList.isNotEmpty)
                        ...tx.chargesList.expand((c) {
                          final catatan = c['catatan']?.toString() ?? '';
                          return [
                            _subtotalRow(
                                c['label']?.toString() ?? 'Biaya Tambahan',
                                'Rp ${_f(c['value'] as int? ?? 0)}'),
                            if (catatan.isNotEmpty)
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: 4, bottom: 4),
                                child: Text(catatan,
                                    style: const TextStyle(
                                        fontFamily: 'PlusJakartaSans',
                                        fontSize: 10,
                                        color: Color(0xFF8B95A5),
                                        fontStyle: FontStyle.italic)),
                              ),
                          ];
                        })
                      else if (tx.additionalCharges > 0)
                        _subtotalRow(
                            'Biaya Tambahan', 'Rp ${_f(tx.additionalCharges)}'),
                      const SizedBox(height: 4),
                    ],

                    // Grand total prominent
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Color(_sharedColor),
                            Color(_sharedColor).withValues(alpha: 0.8)
                          ],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('TOTAL',
                              style: TextStyle(
                                fontFamily: 'PlusJakartaSans',
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                                letterSpacing: 1,
                              )),
                          Text('Rp ${_f(tx.grandTotal)}',
                              style: const TextStyle(
                                fontFamily: 'PlusJakartaSans',
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                              )),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    _subtotalRow('Bayar', 'Rp ${_f(tx.amountPaid)}'),
                    if (tx.changeAmount > 0)
                      _subtotalRow('Kembali', 'Rp ${_f(tx.changeAmount)}',
                          valueColor: const Color(0xFF00A86B)),
                  ],
                ),
              ),

              _PerforationDivider(),

              // Footer
              Container(
                width: double.infinity,
                color: const Color(0xFFF7F8FA),
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: Column(
                  children: [
                    if (_instagram.isNotEmpty ||
                        _facebook.isNotEmpty ||
                        _tiktok.isNotEmpty) ...[
                      Wrap(
                        alignment: WrapAlignment.center,
                        spacing: 12,
                        runSpacing: 6,
                        children: [
                          if (_instagram.isNotEmpty)
                            _sharesSosmedBadge(
                                Icons.camera_alt_outlined, _instagram),
                          if (_facebook.isNotEmpty)
                            _sharesSosmedBadge(
                                Icons.facebook_outlined, _facebook),
                          if (_tiktok.isNotEmpty)
                            _sharesSosmedBadge(
                                Icons.music_note_outlined, _tiktok),
                        ],
                      ),
                      const SizedBox(height: 12),
                    ],
                    if (_transactionNoteText(tx).isNotEmpty) ...[
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(color: const Color(0xFFE2E8F0)),
                          borderRadius: BorderRadius.zero,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Catatan Tambahan',
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontFamily: 'PlusJakartaSans',
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF64748B),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _transactionNoteText(tx),
                              textAlign: TextAlign.left,
                              style: const TextStyle(
                                fontFamily: 'PlusJakartaSans',
                                fontSize: 11,
                                height: 1.35,
                                color: Color(0xFF334155),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                    Text(
                      _footer.isNotEmpty
                          ? _footer
                          : 'Terima kasih telah berbelanja! ',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          fontFamily: 'PlusJakartaSans',
                          fontSize: 12,
                          color: Color(0xFF8B95A5)),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                              color: Color(_sharedColor),
                              shape: BoxShape.rectangle),
                        ),
                        const SizedBox(width: 4),
                        Text('Juragan Servis',
                            style: TextStyle(
                              fontFamily: 'PlusJakartaSans',
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              color: Color(_sharedColor),
                            )),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _receiptRow(
      {required IconData icon, required String label, required String value}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: Color(_sharedColor).withValues(alpha: 0.08),
              borderRadius: BorderRadius.zero,
            ),
            child: Icon(icon, size: 14, color: Color(_sharedColor)),
          ),
          const SizedBox(width: 10),
          Text(label,
              style: const TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontSize: 12,
                  color: Color(0xFF8B95A5))),
          const Spacer(),
          Text(value,
              style: const TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF0A0F1E))),
        ],
      ),
    );
  }

  Widget _subtotalRow(String label, String value, {Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: const TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontSize: 12,
                  color: Color(0xFF8B95A5))),
          Text(value,
              style: TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: valueColor ?? const Color(0xFF0A0F1E))),
        ],
      ),
    );
  }

  Widget _sharesSosmedBadge(IconData icon, String handle) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: Color(_sharedColor).withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: Color(_sharedColor)),
          const SizedBox(width: 4),
          Text('@$handle',
              style: const TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontSize: 10,
                  color: Color(0xFF3D4350))),
        ],
      ),
    );
  }

  Widget _sosmedRow(IconData icon, String text) => Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(icon, size: 12, color: Colors.black45),
          const SizedBox(width: 3),
          Text(text,
              style: const TextStyle(fontSize: 11, color: Colors.black45)),
        ],
      );

  int _remainingRefundValue(TransactionItem item) {
    final alreadyRefunded = _returnedSubtotalMap[item.productId] ?? 0;
    return math.max(0, item.subtotal - alreadyRefunded);
  }

  int _refundAmountForItem(TransactionItem item, double qty) {
    if (item.qty <= 0 || qty <= 0) return 0;
    final returnedQty = _returnedQtyMap[item.productId] ?? 0.0;
    final remainingQty = math.max(0.0, item.qty - returnedQty);
    final remainingValue = _remainingRefundValue(item);
    if (remainingValue <= 0 || remainingQty <= 0) return 0;
    if (qty >= remainingQty - 0.0001) return remainingValue;
    final amount = (item.subtotal * (qty / item.qty)).round();
    return amount.clamp(0, remainingValue).toInt();
  }

  void _showReturDialog(TransactionItem item, {double? remaining}) {
    final maxQty = remaining ?? item.qty;
    if (maxQty <= 0) return;
    final step = item.qty % 1 == 0 ? 1.0 : 0.1;
    double qtyRetur = math.min(step, maxQty);
    String alasan = 'hasil_kurang_baik';
    final alasanList = [
      ('hasil_kurang_baik', 'Hasil Kurang Baik'),
      ('cacat', 'Barang Rusak / Cacat'),
      ('hilang_tertukar', 'Hilang / Tertukar'),
      ('salah_item', 'Salah Layanan / Item'),
      ('batal_layanan', 'Batal Layanan'),
      ('lainnya', 'Lainnya'),
    ];
    String refundTo = 'tunai';
    final noteCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) {
          final refundAmount = _refundAmountForItem(item, qtyRetur);
          final unit = _itemUnit(item).isEmpty ? 'item' : _itemUnit(item);
          return Dialog(
            backgroundColor: Colors.white,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Refund Layanan',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text(
                    'Gunakan hanya untuk pembatalan layanan, komplain hasil perbaikan, unit tertukar, atau pengembalian dana.',
                    style: TextStyle(
                        fontSize: 12.5, height: 1.35, color: Colors.black54),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8FAFC),
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.productName,
                            style:
                                const TextStyle(fontWeight: FontWeight.w800)),
                        const SizedBox(height: 4),
                        Text(
                          'Sisa bisa refund: ${_fmtD(maxQty)} $unit | Nominal tersisa Rp${_f(_remainingRefundValue(item))}',
                          style: const TextStyle(
                              fontSize: 12, color: Colors.black54),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Qty
                  Row(
                    children: [
                      const Text('Jumlah Refund:',
                          style: TextStyle(fontSize: 13)),
                      const Spacer(),
                      IconButton(
                        onPressed: qtyRetur > step
                            ? () => setLocal(() => qtyRetur =
                                (qtyRetur - step).clamp(step, maxQty))
                            : null,
                        icon: const Icon(Icons.remove_circle_outline,
                            color: _kBrand),
                      ),
                      Text(_fmtD(qtyRetur),
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16)),
                      IconButton(
                        onPressed: qtyRetur < maxQty
                            ? () => setLocal(() => qtyRetur =
                                (qtyRetur + step).clamp(step, maxQty))
                            : null,
                        icon: const Icon(Icons.add_circle_outline,
                            color: _kBrand),
                      ),
                    ],
                  ),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF7ED),
                      border: Border.all(color: const Color(0xFFFED7AA)),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.payments_outlined,
                            color: Color(0xFFC2410C), size: 18),
                        const SizedBox(width: 8),
                        const Expanded(
                          child: Text('Nominal refund',
                              style: TextStyle(
                                  fontSize: 12.5,
                                  color: Color(0xFF7C2D12),
                                  fontWeight: FontWeight.w700)),
                        ),
                        Text('Rp${_f(refundAmount)}',
                            style: const TextStyle(
                                color: Color(0xFFC2410C),
                                fontSize: 15,
                                fontWeight: FontWeight.w900)),
                      ],
                    ),
                  ),

                  // Alasan
                  const SizedBox(height: 12),
                  const Text('Alasan Komplain / Refund:',
                      style: TextStyle(fontSize: 13)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        isExpanded: true,
                        value: alasan,
                        items: alasanList
                            .map((a) => DropdownMenuItem(
                                value: a.$1,
                                child: Text(a.$2,
                                    style: const TextStyle(fontSize: 14))))
                            .toList(),
                        onChanged: (v) => setLocal(() => alasan = v!),
                      ),
                    ),
                  ),

                  // Refund
                  const SizedBox(height: 12),
                  const Text('Metode Pengembalian Dana:',
                      style: TextStyle(fontSize: 13)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        isExpanded: true,
                        value: refundTo,
                        items: const [
                          DropdownMenuItem(
                              value: 'tunai',
                              child: Text('Tunai - uang keluar dari laci kas',
                                  style: TextStyle(fontSize: 14))),
                          DropdownMenuItem(
                              value: 'non_tunai',
                              child: Text('Non Tunai - transfer/QRIS refund',
                                  style: TextStyle(fontSize: 14))),
                        ],
                        onChanged: (v) => setLocal(() => refundTo = v!),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: noteCtrl,
                    minLines: 2,
                    maxLines: 3,
                    decoration: InputDecoration(
                      hintText:
                          'Catatan opsional, contoh: noda belum hilang atau pelanggan minta refund sebagian',
                      hintStyle:
                          const TextStyle(fontSize: 12, color: Colors.black38),
                      contentPadding: const EdgeInsets.all(12),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      focusedBorder: const OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide(color: _kBrand),
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('Batal',
                              style: TextStyle(color: Colors.black54)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFE65100),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                          ),
                          onPressed: () {
                            Navigator.pop(ctx);
                            _prosesRetur(
                              item,
                              qtyRetur,
                              alasan,
                              refundTo,
                              noteCtrl.text.trim(),
                            );
                          },
                          child: const Text('Proses',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    ).whenComplete(noteCtrl.dispose);
  }

  Future<void> _prosesRetur(
    TransactionItem item,
    double qty,
    String reason,
    String refundTo,
    String note,
  ) async {
    final subtotalRetur = _refundAmountForItem(item, qty);
    if (subtotalRetur <= 0 || _tx?.id == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Nominal refund tidak valid atau sudah habis.')));
      }
      return;
    }
    final returItem = ReturnItem(
      returnId: 0,
      productId: item.productId,
      productName: item.productName,
      qty: qty,
      unitPrice: item.unitPrice,
      subtotal: subtotalRetur,
    );
    try {
      await ref.read(returnsProvider.notifier).createReturn(
        transactionId: _tx!.id!,
        customerName: _tx!.customerName ?? 'Pelanggan Umum',
        reason: reason,
        refundMethod: refundTo,
        totalRefund: subtotalRetur,
        note: note.isEmpty ? null : note,
        items: [returItem],
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Refund Rp${_f(subtotalRetur)} berhasil dicatat.')));
        _load(); // Refresh statuses
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Proses refund gagal. Silakan coba lagi.')));
      }
    }
  }
}

//
// SIDEBAR TX ROW
//
class _SideTxRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final bool small;

  const _SideTxRow({
    required this.icon,
    required this.label,
    required this.value,
    this.small = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.1),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white70, size: 15),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.6),
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5)),
                Text(
                  value,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: small ? 11 : 13,
                    fontWeight: FontWeight.bold,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
// SIDEBAR ACTION BUTTON
//

//
// PERFORASI DIVIDER
//
class _PerforationDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 20,
      child: CustomPaint(
        painter: _PerforationPainter(),
        size: const Size(double.infinity, 20),
      ),
    );
  }
}

class _PerforationPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paintBg = Paint()..color = const Color(0xFFF7F8FA);
    final paintWhite = Paint()..color = Colors.white;

    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), paintBg);
    const double r = 10.0;
    canvas.drawCircle(Offset(-r, size.height / 2), r, paintWhite);
    canvas.drawCircle(Offset(size.width + r, size.height / 2), r, paintWhite);

    final paintDash = Paint()
      ..color = const Color(0xFFD0D5DD)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    const dashWidth = 8.0;
    const dashSpace = 5.0;
    double startX = 0;
    final y = size.height / 2;
    while (startX < size.width) {
      canvas.drawLine(
          Offset(startX, y), Offset(startX + dashWidth, y), paintDash);
      startX += dashWidth + dashSpace;
    }
  }

  @override
  bool shouldRepaint(_PerforationPainter old) => false;
}

//
// INFO ROW
//
class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final bool valueBold;
  final Color? valueColor;

  const _InfoRow({
    required this.label,
    required this.value,
    this.valueBold = false,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(fontSize: 13, color: Colors.black54)),
          const SizedBox(width: 16),
          Expanded(
            child: Text(value,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: valueBold ? FontWeight.bold : FontWeight.w500,
                  color: valueColor ?? Colors.black87,
                )),
          ),
        ],
      ),
    );
  }
}

String _getDiskonLabel(Transaction tx) {
  if (tx.discountAmount <= 0 || tx.totalAmount <= 0) return 'Diskon';
  final pct = (tx.discountAmount / tx.totalAmount * 100);
  if (pct > 0 && pct <= 100) {
    if (pct == pct.toInt().toDouble()) {
      return 'Diskon (${pct.toInt()}%)';
    } else {
      return 'Diskon (${pct.toStringAsFixed(1).replaceAll(RegExp(r'\.0$'), '')}%)';
    }
  }
  return 'Diskon';
}

String _getItemOriginalPriceLine(TransactionItem item) {
  return 'Harga asli: Rp${_f(item.effectiveOriginalUnitPrice)} / item';
}

String _getItemPromoPriceLine(TransactionItem item) {
  return '${_getItemPromoLabel(item)} -> Rp${_f(item.unitPrice)} / item';
}

String _getItemPriceOverrideLine(TransactionItem item) {
  final amount = item.effectivePriceOverrideAmount;
  final suffix = amount == 0
      ? ''
      : amount > 0
          ? ' (selisih -Rp${_f(amount)})'
          : ' (selisih +Rp${_f(amount.abs())})';
  return 'Harga awal Rp${_f(item.effectiveOriginalUnitPrice)} -> Rp${_f(item.unitPrice)} / item$suffix';
}

String _getItemPromoLabel(TransactionItem item) {
  final name = item.appliedDiscountName?.trim() ?? '';
  final value = item.appliedDiscountValue;
  final isPercentage = item.appliedDiscountIsPercentage == 1;

  if (name.isNotEmpty) {
    if (isPercentage && value > 0) {
      return '$name ($value%)';
    }
    if (!isPercentage && value > 0) {
      return '$name (-Rp${_f(value)})';
    }
    return name;
  }

  if (isPercentage && value > 0) {
    return 'Promo $value%';
  }
  if (value > 0) {
    return 'Promo -Rp${_f(value)}';
  }
  return 'Promo';
}

String _getItemSimpleDiscountInfo(TransactionItem item) {
  if (item.hasPriceOverride) return ' (nego)';
  if (!item.hasAppliedPromo) return '';
  final value = item.appliedDiscountValue;
  final isPercentage = item.appliedDiscountIsPercentage == 1;
  if (isPercentage && value > 0) return ' (disc. $value%)';
  if (!isPercentage && value > 0) return ' (disc. -Rp${_f(value)})';
  return ' (promo)';
}

