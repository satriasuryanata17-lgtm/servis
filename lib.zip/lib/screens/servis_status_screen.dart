import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:share_plus/share_plus.dart';
import '../core/theme.dart';
import '../services/whatsapp_helper.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../utils/transaction_code_formatter.dart';
import '../widgets/kasir_drawer.dart';
import 'main_shell.dart';
import 'responsive_layout.dart';
import '../database/db_helper.dart';
import '../utils/modern_ui_helpers.dart';

// HELPERS

const _kBrand = AppColors.primaryBrand;

enum _ReminderConfirmAction { sent, openAgain, shareManually, cancel }

enum _ReminderLaunchResult { opened, confirmedManually, failed }

String _fRp(int n) {
  if (n == 0) return 'Rp0';
  String s = n.toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return 'Rp$r';
}

String _formatQtyLabel(double qty) {
  return qty
      .toStringAsFixed(2)
      .replaceAll(RegExp(r'0+$'), '')
      .replaceAll(RegExp(r'\.$'), '')
      .replaceAll('.', ',');
}

String _itemQtyWithUnit(TransactionItem item) {
  final unit = item.unit?.trim();
  final qty = _formatQtyLabel(item.qty);
  if (unit != null && unit.isNotEmpty) return '$qty $unit';
  return '$qty item';
}

String _itemQtyCompactLabel(TransactionItem item) {
  final unit = item.unit?.trim();
  final qty = _formatQtyLabel(item.qty);
  if (unit != null && unit.isNotEmpty) return '$qty $unit';
  return '${qty}x';
}

String _pickupLineForWhatsApp(String? pickupText, String status) {
  final value = pickupText?.trim() ?? '';
  final normalizedStatus = status.trim().toLowerCase();
  if (value.isEmpty ||
      normalizedStatus == 'siap' ||
      normalizedStatus == 'siap ambil') {
    return '';
  }
  return '\u{1F4C5} *Estimasi Pengambilan:* $value\n';
}

String _totalTagihanLineForWhatsApp({
  required bool isPaid,
  required int grandTotal,
}) {
  if (isPaid) return '';
  return '\u{1F4B0} *Total Tagihan:* ${_fRp(grandTotal)}\n';
}

const _statusFlow = [
  'Diterima',
  'Proses',
  'Siap',
  'Selesai',
];

const _operationFilters = [
  'Semua',
  'Prioritas',
  'Jatuh Tempo',
  'Terlambat',
  'Belum Lunas',
];

const _dueSoonThreshold = Duration(hours: 2);
const _paidBadgeColor = Color(0xFF0F766E);
const _priorityBadgeColor = Color(0xFFEA580C);
const _fulfillmentBadgeColor = Color(0xFF1D4ED8);

enum _SiapConfirmAction {
  confirm,
  confirmAndNotify,
}

bool _isDangerPriorityLabel(String label) =>
    label == 'Terlambat' || label == 'Belum Lunas';

Color _statusColor(String status) {
  return _kBrand;
}

IconData _statusIcon(String status) {
  switch (status) {
    case 'Diterima':
      return Icons.inbox_rounded;
    case 'Proses':
      return Icons.sync_rounded;
    case 'Siap':
      return Icons.check_circle_rounded;
    case 'Selesai':
      return Icons.done_all_rounded;
    default:
      return Icons.help_outline_rounded;
  }
}

bool _isPriorityservisTransaction(Transaction tx) {
  if (_hasPriorityServiceLevel(tx)) return true;

  final type = (tx.orderType ?? '').toLowerCase();
  if (type.contains('express') ||
      type.contains('kilat') ||
      type.contains('cepat') ||
      type.contains('prioritas')) {
    return true;
  }

  final createdAt = DateTime.tryParse(tx.createdAt);
  final pickupAt = _effectivePickupAt(tx);
  if (createdAt == null || pickupAt == null) return false;

  final hours = pickupAt.difference(createdAt).inHours;
  return hours > 0 && hours <= 8;
}

bool _hasPriorityServiceLevel(Transaction tx) {
  final level = (tx.serviceLevel ?? '').trim().toLowerCase();
  if (level.isEmpty || level == 'regular') return false;
  return true;
}

String? _transactionServiceBadgeLabel(Transaction tx, {String? fallbackLabel}) {
  final level = (tx.serviceLevel ?? '').trim();
  final hasStoredLevel = level.isNotEmpty && level.toLowerCase() != 'regular';
  if (hasStoredLevel) return _formatServiceLevel(level, tx.slaHours);

  final fallback = fallbackLabel?.trim();
  if (fallback != null && fallback.isNotEmpty) return fallback;

  final orderLevel = _serviceLevelFromText(tx.orderType, tx.slaHours);
  if (orderLevel != null) return orderLevel;

  if (_isPriorityservisTransaction(tx)) {
    return _formatServiceLevel('Prioritas', tx.slaHours);
  }
  return null;
}

String? _serviceLevelFromText(String? value, int slaHours) {
  final text = value?.trim();
  if (text == null || text.isEmpty) return null;
  final lower = text.toLowerCase();
  if (lower.contains('express')) {
    return _formatServiceLevel('Express', slaHours);
  }
  if (lower.contains('kilat')) return _formatServiceLevel('Kilat', slaHours);
  if (lower.contains('cepat')) return _formatServiceLevel('Cepat', slaHours);
  if (lower.contains('prioritas')) {
    return _formatServiceLevel('Prioritas', slaHours);
  }
  return null;
}

String _formatServiceLevel(String level, int slaHours) {
  final title = _titleCase(level);
  if (slaHours <= 0) return title;
  return '$title $slaHours jam';
}

String _titleCase(String value) {
  final cleaned = value.trim();
  if (cleaned.isEmpty) return cleaned;
  return cleaned
      .split(RegExp(r'\s+'))
      .map((part) => part.isEmpty
          ? part
          : part[0].toUpperCase() + part.substring(1).toLowerCase())
      .join(' ');
}

String _formatTransactionDateTime(String value) {
  final dt = DateTime.tryParse(value);
  if (dt == null) return value;
  return DateFormat('dd MMM yyyy, HH:mm', 'id').format(dt);
}

int? _slaHoursFromText(String? value) {
  final text = value?.trim();
  if (text == null || text.isEmpty) return null;
  final match = RegExp(r'(\d+)\s*(?:jam|hour|hours|h)\b', caseSensitive: false)
      .firstMatch(text);
  if (match == null) return null;
  return int.tryParse(match.group(1) ?? '');
}

Duration _fallbackPickupDuration(
  Transaction tx, {
  String? priorityServiceLabel,
}) {
  final explicitHours = tx.slaHours > 0
      ? tx.slaHours
      : _slaHoursFromText(tx.serviceLevel) ??
          _slaHoursFromText(tx.orderType) ??
          _slaHoursFromText(priorityServiceLabel);
  if (explicitHours != null && explicitHours > 0) {
    return Duration(hours: explicitHours);
  }
  return const Duration(hours: 24);
}

DateTime? _effectivePickupAt(
  Transaction tx, {
  String? priorityServiceLabel,
}) {
  final rawPickup = tx.pickupSchedule?.trim();
  if (rawPickup != null && rawPickup.isNotEmpty) {
    final parsed = DateTime.tryParse(rawPickup);
    if (parsed != null) return parsed;
  }

  final created = DateTime.tryParse(tx.createdAt);
  if (created == null) return null;
  return created.add(
    _fallbackPickupDuration(tx, priorityServiceLabel: priorityServiceLabel),
  );
}

String? _resolveFulfillmentBadge(String? fulfillmentType, String? orderType) {
  final source =
      (fulfillmentType?.trim().isNotEmpty == true ? fulfillmentType : orderType)
          ?.trim();
  if (source == null || source.isEmpty) return null;

  final lower = source.toLowerCase();
  if (lower.contains('express') ||
      lower.contains('kilat') ||
      lower.contains('cepat') ||
      lower.contains('prioritas')) {
    return null;
  }
  if (lower.contains('antar') ||
      lower.contains('jemput') ||
      lower.contains('delivery') ||
      lower.contains('pickup')) {
    return 'Antar/Jemput';
  }
  return _titleCase(source);
}

// SCREEN

class servisStatusScreen extends ConsumerStatefulWidget {
  final bool isEmbedded;
  const servisStatusScreen({super.key, this.isEmbedded = false});

  @override
  ConsumerState<servisStatusScreen> createState() =>
      _servisStatusScreenState();
}

class _servisStatusScreenState extends ConsumerState<servisStatusScreen>
    with TickerProviderStateMixin {
  String _filter = 'Diterima';
  String _operationFilter = 'Semua';
  String _query = '';
  DateTimeRange? _filterDateRange;
  String _dateFilterMode = 'Semua Waktu';
  DateTime _selectedDate = DateTime.now();
  final TextEditingController _searchCtrl = TextEditingController();
  final ScrollController _quickFilterScrollCtrl = ScrollController();
  bool _showQuickFilterLeftHint = false;
  bool _showQuickFilterRightHint = false;
  Map<int, String> _priorityServiceLabels = {};
  String _priorityServiceKey = '';
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _statusFlow.length, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) return;
      _setStatusFilter(_tabController.index);
    });
    _quickFilterScrollCtrl.addListener(_updateQuickFilterScrollHints);
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => _updateQuickFilterScrollHints(),
    );
  }

  void _onTabChanged(int index) {
    _setStatusFilter(index);
    _tabController.animateTo(index);
  }

  void _setStatusFilter(int index) {
    final next = _statusFlow[index];
    final shouldResetOperationFilter =
        next != _filter || _isCompletedStatus(next);

    if (_filter == next && !shouldResetOperationFilter) return;

    setState(() {
      _filter = next;
      if (shouldResetOperationFilter) {
        _operationFilter = 'Semua';
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _quickFilterScrollCtrl.removeListener(_updateQuickFilterScrollHints);
    _quickFilterScrollCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final transactions = ref.watch(transactionsProvider);
    _syncPriorityServiceLabels(transactions);

    // Summary stats (legacy for reference if needed, but not showing bar)
    final dateFilteredTransactions = transactions
        .where((tx) => tx.isDeleted == 0)
        .where(_isInSelectedDateRange)
        .toList();
    final workQueueTransactions = dateFilteredTransactions
        .where(_isActiveWorkTransaction)
        .where(_passesOperationFilter)
        .toList();

    final content = LayoutBuilder(builder: (context, constraints) {
      final bool isDesktop =
          constraints.maxWidth > 900 || KasirLayout.isTablet(context);

      return Column(
        children: [
          _buildTopSearchBar(isDesktop: isDesktop),
          _buildTopBar(
            isDesktop,
            workQueueTransactions,
            dateFilteredTransactions,
          ),
          Expanded(
            child: isDesktop
                ? _buildDesktopListWorkspace(
                    workQueueTransactions,
                    dateFilteredTransactions,
                  )
                : TabBarView(
                    controller: _tabController,
                    physics: const PageScrollPhysics(
                        parent: ClampingScrollPhysics()),
                    dragStartBehavior: DragStartBehavior.down,
                    children: _statusFlow.map((status) {
                      final list = _isCompletedStatus(status)
                          ? dateFilteredTransactions
                              .where(_isCompletedTransaction)
                              .toList()
                          : workQueueTransactions
                              .where((t) => _normalizedStatus(t) == status)
                              .toList();

                      final filtered = _query.isEmpty
                          ? list
                          : list
                              .where((t) => _matchesQuery(t, _query))
                              .toList();

                      return _buildMobileListView(filtered, status);
                    }).toList(),
                  ),
          ),
        ],
      );
    });

    if (widget.isEmbedded) return content;

    return KasirResponsiveScaffold(
      title: 'Status Servis',
      navIndex: 10,
      drawer: const KasirDrawer(),
      backgroundColor: const Color(0xFFF1F5F9),
      showAppBar: false,
      body: content,
    );
  }

  void _syncPriorityServiceLabels(List<Transaction> transactions) {
    final ids = transactions
        .where((tx) => tx.isDeleted == 0 && tx.id != null)
        .map((tx) => tx.id!)
        .toList()
      ..sort();
    final key = ids.join(',');
    if (key == _priorityServiceKey) return;
    _priorityServiceKey = key;

    DBHelper.instance.getPriorityServiceLabelsByTransactionIds(ids).then((map) {
      if (!mounted || _priorityServiceKey != key) return;
      setState(() => _priorityServiceLabels = map);
    });
  }

  Widget _buildTopSearchBar({required bool isDesktop}) {
    return Material(
      color: Colors.white,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: EdgeInsets.fromLTRB(isDesktop ? 16 : 8, 8, 8, 8),
          child: Row(
            children: [
              if (!isDesktop)
                Builder(builder: (ctx) {
                  return SizedBox(
                    width: 42,
                    height: 38,
                    child: IconButton(
                      padding: EdgeInsets.zero,
                      icon: const Icon(
                        Icons.menu_rounded,
                        color: Color(0xFF1E293B),
                        size: 22,
                      ),
                      onPressed: () {
                        final shell = ShellScope.of(context);
                        if (shell?.openDrawer != null) {
                          shell!.openDrawer!();
                        } else {
                          Scaffold.maybeOf(ctx)?.openDrawer();
                        }
                      },
                      tooltip: MaterialLocalizations.of(context)
                          .openAppDrawerTooltip,
                    ),
                  );
                }),
              Expanded(
                child: SizedBox(
                  height: 38,
                  child: TextField(
                    controller: _searchCtrl,
                    onChanged: (v) => setState(() => _query = v),
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF1E293B),
                    ),
                    decoration: InputDecoration(
                      hintText: 'Cari nama / No. invoice...',
                      hintStyle: const TextStyle(
                        color: Color(0xFF94A3B8),
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                      ),
                      prefixIcon: const Icon(
                        Icons.search_rounded,
                        size: 18,
                        color: Color(0xFF64748B),
                      ),
                      suffixIcon: _query.trim().isEmpty
                          ? null
                          : IconButton(
                              tooltip: 'Hapus pencarian',
                              padding: EdgeInsets.zero,
                              icon: const Icon(Icons.close_rounded,
                                  size: 18, color: Color(0xFF94A3B8)),
                              onPressed: () {
                                _searchCtrl.clear();
                                setState(() => _query = '');
                              },
                            ),
                      prefixIconConstraints:
                          const BoxConstraints(minWidth: 40, minHeight: 38),
                      suffixIconConstraints:
                          const BoxConstraints(minWidth: 36, minHeight: 38),
                      filled: true,
                      fillColor: const Color(0xFFF3F6FA),
                      contentPadding: EdgeInsets.zero,
                      border: const OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: const OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide(color: _kBrand, width: 1.2),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                width: 42,
                height: 38,
                child: OutlinedButton(
                  onPressed: _showStatusGuide,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF0F172A),
                    backgroundColor: Colors.white,
                    side: const BorderSide(color: AppColors.divider),
                    elevation: 0,
                    padding: EdgeInsets.zero,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                  ),
                  child: const Icon(Icons.help_outline_rounded, size: 18),
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                width: 84,
                height: 38,
                child: ElevatedButton(
                  onPressed: _pickDateFilter,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _filterDateRange == null
                        ? const Color(0xFF0F172A)
                        : _kBrand,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.calendar_month_rounded, size: 16),
                      const SizedBox(width: 5),
                      Text(
                        'Tanggal',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar(
    bool isDesktop,
    List<Transaction> filteredTransactions,
    List<Transaction> baseTransactions,
  ) {
    final filterCounts = _operationFilterCountsForStatus(
      baseTransactions,
      _filter,
    );

    final header = Column(
      children: [
        Container(
          padding: EdgeInsets.only(
            left: isDesktop ? 16 : 0,
            right: isDesktop ? 16 : 0,
          ),
          decoration: const BoxDecoration(
            color: Colors.white,
            border: Border(bottom: BorderSide(color: Color(0xFFE2E8F0))),
          ),
          child: _buildStatusTabRow(
            filteredTransactions,
            baseTransactions,
          ),
        ),
        if (!isDesktop) _buildOperationFilters(baseTransactions, filterCounts),
        if (!isDesktop && _filterDateRange != null) _buildActiveDateFilterBar(),
        if (isDesktop && _shouldShowActiveFilterBanner(isDesktop))
          _buildActiveFilterBanner(),
      ],
    );

    return Container(
      color: Colors.white,
      padding: EdgeInsets.only(bottom: isDesktop ? 8 : 0),
      child: header,
    );
  }

  DateTime _dateOnly(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  DateTimeRange _weekRangeFor(DateTime date) {
    final dayStart = _dateOnly(date);
    final weekdayOffset = dayStart.weekday - DateTime.monday;
    final start = dayStart.subtract(Duration(days: weekdayOffset));
    return DateTimeRange(
      start: start,
      end: start.add(const Duration(days: 6)),
    );
  }

  String _dateFilterLabel() {
    if (_filterDateRange == null) return '';
    final fmt = DateFormat('d MMMM yyyy', 'id');
    final shortFmt = DateFormat('d MMM', 'id');
    switch (_dateFilterMode) {
      case 'Periode Harian':
        return 'Tanggal: ${fmt.format(_selectedDate)}';
      case 'Periode Mingguan':
        return 'Mingguan: ${shortFmt.format(_filterDateRange!.start)} - ${fmt.format(_filterDateRange!.end)}';
      case 'Periode Bulanan':
        return 'Bulan: ${DateFormat('MMMM yyyy', 'id').format(_selectedDate)}';
      case 'Periode Tahunan':
        return 'Tahun: ${DateFormat('yyyy', 'id').format(_selectedDate)}';
      case 'Rentang Tanggal':
        return 'Periode: ${fmt.format(_filterDateRange!.start)} - ${fmt.format(_filterDateRange!.end)}';
      default:
        return fmt.format(_filterDateRange!.start);
    }
  }

  void _applyDateFilter(
    String mode,
    DateTime start,
    DateTime end, {
    DateTime? selectedDate,
  }) {
    setState(() {
      _dateFilterMode = mode;
      _selectedDate = selectedDate ?? start;
      _filterDateRange =
          DateTimeRange(start: _dateOnly(start), end: _dateOnly(end));
    });
  }

  void _clearDateFilter() {
    setState(() {
      _dateFilterMode = 'Semua Waktu';
      _filterDateRange = null;
    });
  }

  Future<DateTime?> _showThemedDatePicker({DateTime? initialDate}) {
    final now = DateTime.now();
    return showDatePicker(
      context: context,
      initialDate: initialDate ?? now,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: _kBrand,
              onPrimary: Colors.white,
              onSurface: Color(0xFF1E293B),
            ),
          ),
          child: child!,
        );
      },
    );
  }

  Future<void> _pickDateFilter() async {
    final option = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(0, 14, 0, 14),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Filter Tanggal',
                textAlign: TextAlign.center,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  color: AppColors.textTitle,
                ),
              ),
              const SizedBox(height: 10),
              _DateFilterTile(
                icon: Icons.today_outlined,
                label: 'Hari Ini',
                selected: _dateFilterMode == 'Periode Harian' &&
                    _dateOnly(_selectedDate) == _dateOnly(DateTime.now()),
                onTap: () => Navigator.pop(ctx, 'today'),
              ),
              _DateFilterTile(
                icon: Icons.date_range_outlined,
                label: 'Periode',
                selected: _dateFilterMode == 'Rentang Tanggal',
                onTap: () => Navigator.pop(ctx, 'range'),
              ),
              _DateFilterTile(
                icon: Icons.event_outlined,
                label: 'Harian',
                selected: _dateFilterMode == 'Periode Harian' &&
                    _dateOnly(_selectedDate) != _dateOnly(DateTime.now()),
                onTap: () => Navigator.pop(ctx, 'daily'),
              ),
              _DateFilterTile(
                icon: Icons.calendar_view_week_outlined,
                label: 'Mingguan',
                selected: _dateFilterMode == 'Periode Mingguan',
                onTap: () => Navigator.pop(ctx, 'weekly'),
              ),
              _DateFilterTile(
                icon: Icons.calendar_view_month_outlined,
                label: 'Bulanan',
                selected: _dateFilterMode == 'Periode Bulanan',
                onTap: () => Navigator.pop(ctx, 'monthly'),
              ),
              _DateFilterTile(
                icon: Icons.calendar_month_outlined,
                label: 'Tahunan',
                selected: _dateFilterMode == 'Periode Tahunan',
                onTap: () => Navigator.pop(ctx, 'yearly'),
              ),
              if (_filterDateRange != null) ...[
                const SizedBox(height: 4),
                _DateFilterTile(
                  icon: Icons.close_rounded,
                  label: 'Hapus Filter',
                  danger: true,
                  selected: false,
                  onTap: () => Navigator.pop(ctx, 'clear'),
                ),
              ],
            ],
          ),
        ),
      ),
    );

    if (option == null || !mounted) return;

    switch (option) {
      case 'today':
        final today = _dateOnly(DateTime.now());
        _applyDateFilter('Periode Harian', today, today, selectedDate: today);
        break;
      case 'range':
        await _pickDateRangeFilter();
        break;
      case 'daily':
        await _pickSingleDateFilter();
        break;
      case 'weekly':
        await _pickWeekFilter();
        break;
      case 'monthly':
        await _pickMonthFilter();
        break;
      case 'yearly':
        await _pickYearFilter();
        break;
      case 'clear':
        _clearDateFilter();
        break;
    }
  }

  Future<void> _pickDateRangeFilter() async {
    final picked = await showDateRangePicker(
      context: context,
      initialDateRange: _filterDateRange,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: _kBrand,
              onPrimary: Colors.white,
              onSurface: Color(0xFF1E293B),
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      _applyDateFilter(
        'Rentang Tanggal',
        picked.start,
        picked.end,
        selectedDate: picked.start,
      );
    }
  }

  Future<void> _pickSingleDateFilter() async {
    final picked = await _showThemedDatePicker(initialDate: _selectedDate);
    if (picked == null) return;
    _applyDateFilter('Periode Harian', picked, picked, selectedDate: picked);
  }

  Future<void> _pickWeekFilter() async {
    final option = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(0, 14, 0, 14),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Filter Mingguan',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  color: AppColors.textTitle,
                ),
              ),
              const SizedBox(height: 10),
              _DateFilterTile(
                icon: Icons.calendar_view_week_outlined,
                label: 'Minggu Ini',
                selected: false,
                onTap: () => Navigator.pop(ctx, 'this_week'),
              ),
              _DateFilterTile(
                icon: Icons.history_rounded,
                label: 'Minggu Lalu',
                selected: false,
                onTap: () => Navigator.pop(ctx, 'last_week'),
              ),
              _DateFilterTile(
                icon: Icons.keyboard_double_arrow_left_rounded,
                label: '2 Minggu Lalu',
                selected: false,
                onTap: () => Navigator.pop(ctx, 'two_weeks_ago'),
              ),
              _DateFilterTile(
                icon: Icons.edit_calendar_outlined,
                label: 'Pilih Minggu Lain',
                selected: false,
                onTap: () => Navigator.pop(ctx, 'custom_week'),
              ),
            ],
          ),
        ),
      ),
    );

    if (option == null || !mounted) return;
    final now = DateTime.now();
    DateTime selected = now;
    if (option == 'last_week') {
      selected = now.subtract(const Duration(days: 7));
    } else if (option == 'two_weeks_ago') {
      selected = now.subtract(const Duration(days: 14));
    } else if (option == 'custom_week') {
      final picked = await _showThemedDatePicker(initialDate: _selectedDate);
      if (picked == null) return;
      selected = picked;
    }
    final week = _weekRangeFor(selected);
    _applyDateFilter(
      'Periode Mingguan',
      week.start,
      week.end,
      selectedDate: selected,
    );
  }

  Future<void> _pickMonthFilter() async {
    final picked = await _showThemedDatePicker(initialDate: _selectedDate);
    if (picked == null) return;
    final start = DateTime(picked.year, picked.month, 1);
    final end = DateTime(picked.year, picked.month + 1, 0);
    _applyDateFilter('Periode Bulanan', start, end, selectedDate: picked);
  }

  Future<void> _pickYearFilter() async {
    final picked = await _showThemedDatePicker(initialDate: _selectedDate);
    if (picked == null) return;
    final start = DateTime(picked.year);
    final end = DateTime(picked.year, 12, 31);
    _applyDateFilter('Periode Tahunan', start, end, selectedDate: picked);
  }

  Widget _buildStatusTabRow(
    List<Transaction> filteredTransactions,
    List<Transaction> baseTransactions,
  ) {
    final animation = _tabController.animation;
    if (animation == null) {
      return _buildStatusTabRowAt(
        _tabController.index.toDouble(),
        filteredTransactions,
        baseTransactions,
      );
    }

    return AnimatedBuilder(
      animation: animation,
      builder: (context, _) => _buildStatusTabRowAt(
        animation.value,
        filteredTransactions,
        baseTransactions,
      ),
    );
  }

  Widget _buildStatusTabRowAt(
    double tabPosition,
    List<Transaction> filteredTransactions,
    List<Transaction> baseTransactions,
  ) {
    final activeIndex =
        tabPosition.round().clamp(0, _statusFlow.length - 1).toInt();
    return Row(
      children: List.generate(_statusFlow.length, (index) {
        final status = _statusFlow[index];
        final count = _isCompletedStatus(status)
            ? baseTransactions.where(_isCompletedTransaction).length
            : filteredTransactions
                .where((t) => _normalizedStatus(t) == status)
                .length;
        final alertCount = _isCompletedStatus(status)
            ? 0
            : _quickFilterStatusCount(
                baseTransactions,
                _operationFilter,
                status,
              );
        return _StatusFilterChip(
          label: status,
          count: count,
          alertCount: alertCount,
          showCount: !_isCompletedStatus(status) || _filterDateRange != null,
          isSelected: activeIndex == index,
          onTap: () => _onTabChanged(index),
          color: _statusColor(status),
        );
      }),
    );
  }

  bool get _hasActiveFilter =>
      _operationFilter != 'Semua' ||
      _filterDateRange != null ||
      _query.trim().isNotEmpty;

  bool _shouldShowActiveFilterBanner(bool isDesktop) {
    final mobileQuickFilter =
        !KasirLayout.isTablet(context) && !isDesktop && !widget.isEmbedded;
    if (mobileQuickFilter) {
      return _filterDateRange != null || _query.trim().isNotEmpty;
    }
    if (isDesktop) {
      return _filterDateRange != null || _query.trim().isNotEmpty;
    }
    return _hasActiveFilter;
  }

  String _activeFilterLabel() {
    final parts = <String>[];
    if (_operationFilter != 'Semua') {
      parts.add(_operationFilterLabel(_operationFilter));
    }
    if (_filterDateRange != null) {
      parts.add(_dateFilterLabel());
    }
    if (_query.trim().isNotEmpty) {
      parts.add('Cari: ${_query.trim()}');
    }
    return parts.join('  •  ');
  }

  String _operationFilterLabel(String filter) {
    switch (filter) {
      case 'Semua':
        return _isCompletedArchiveTab ? 'Semua Selesai' : 'Semua $_filter';
      case 'Prioritas':
        return 'Express/Prioritas';
      case 'Jatuh Tempo':
        return 'Deadline Dekat';
      default:
        return filter;
    }
  }

  String _mobileOperationFilterLabel(String filter) {
    switch (filter) {
      case 'Semua':
        return 'Semua';
      case 'Prioritas':
        return 'Kilat';
      case 'Jatuh Tempo':
        return 'Dekat';
      case 'Terlambat':
        return 'Telat';
      case 'Belum Lunas':
        return 'Piutang';
      default:
        return filter;
    }
  }

  void _resetActiveFilters() {
    setState(() {
      _operationFilter = 'Semua';
      _dateFilterMode = 'Semua Waktu';
      _filterDateRange = null;
      _query = '';
      _searchCtrl.clear();
    });
  }

  Widget _buildActiveFilterBanner() {
    return Container(
      height: 36,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: const BoxDecoration(
        color: Color(0xFFF8FAFC),
        border: Border(
          top: BorderSide(color: Color(0xFFE2E8F0)),
          bottom: BorderSide(color: Color(0xFFE2E8F0)),
        ),
      ),
      child: Row(
        children: [
          const Icon(Icons.filter_alt_rounded, size: 16, color: _kBrand),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              _activeFilterLabel(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: const Color(0xFF334155),
              ),
            ),
          ),
          const SizedBox(width: 8),
          InkWell(
            onTap: _resetActiveFilters,
            child: const Padding(
              padding: EdgeInsets.all(4),
              child:
                  Icon(Icons.close_rounded, size: 18, color: Color(0xFF64748B)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActiveDateFilterBar() {
    return Container(
      width: double.infinity,
      height: 30,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: const BoxDecoration(
        color: Color(0xFFF8FAFC),
        border: Border(bottom: BorderSide(color: Color(0xFFE2E8F0))),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.calendar_today_outlined,
            size: 14,
            color: _kBrand,
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              _dateFilterLabel(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: const Color(0xFF334155),
              ),
            ),
          ),
          InkWell(
            onTap: _clearDateFilter,
            child: Container(
              width: 22,
              height: 22,
              alignment: Alignment.center,
              child: const Icon(
                Icons.cancel_rounded,
                size: 16,
                color: Color(0xFF94A3B8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOperationFilters(
    List<Transaction> baseTransactions,
    Map<String, int> counts,
  ) {
    final isMobile = !KasirLayout.isTablet(context);
    final isLocked = _isCompletedArchiveTab;
    if (isMobile) {
      return _buildQuickFilterBar(baseTransactions, counts);
    }

    return IgnorePointer(
      ignoring: isLocked,
      child: Opacity(
        opacity: isLocked ? 0.52 : 1,
        child: SizedBox(
          height: 34,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: _operationFilters.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              final filter = _operationFilters[index];
              final label = _operationFilterLabel(filter);
              final selected =
                  isLocked ? filter == 'Semua' : _operationFilter == filter;
              final count = counts[filter] ?? 0;
              return InkWell(
                onTap: () => _selectQuickFilter(filter, baseTransactions),
                child: Container(
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: selected ? _kBrand : const Color(0xFFF8FAFC),
                    border: Border.all(
                      color: selected ? _kBrand : const Color(0xFFE2E8F0),
                    ),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        label,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color:
                              selected ? Colors.white : const Color(0xFF475569),
                        ),
                      ),
                      const SizedBox(width: 7),
                      Container(
                        constraints: const BoxConstraints(minWidth: 20),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color:
                              selected ? Colors.white : const Color(0xFFE2E8F0),
                          borderRadius: BorderRadius.zero,
                        ),
                        child: Text(
                          count.toString(),
                          textAlign: TextAlign.center,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            color: selected ? _kBrand : const Color(0xFF475569),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildQuickFilterBar(
    List<Transaction> baseTransactions,
    Map<String, int> counts,
  ) {
    final isLocked = _isCompletedArchiveTab;
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => _updateQuickFilterScrollHints(),
    );

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: AppColors.divider)),
      ),
      child: IgnorePointer(
        ignoring: isLocked,
        child: Opacity(
          opacity: isLocked ? 0.52 : 1,
          child: Stack(
            alignment: Alignment.center,
            children: [
              SingleChildScrollView(
                controller: _quickFilterScrollCtrl,
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      for (final filter in _operationFilters)
                        _QuickFilterChip(
                          label: _mobileOperationFilterLabel(filter),
                          count: counts[filter] ?? 0,
                          isDanger: _isDangerPriorityLabel(filter),
                          showAlertBadge: filter != 'Semua',
                          isSelected: isLocked
                              ? filter == 'Semua'
                              : _operationFilter == filter,
                          onTap: () =>
                              _selectQuickFilter(filter, baseTransactions),
                        ),
                    ],
                  ),
                ),
              ),
              if (!isLocked && _showQuickFilterLeftHint)
                const Positioned(
                  left: 0,
                  top: 0,
                  bottom: 0,
                  child: _QuickFilterEdgeHint(isRight: false),
                ),
              if (!isLocked && _showQuickFilterRightHint)
                const Positioned(
                  right: 0,
                  top: 0,
                  bottom: 0,
                  child: _QuickFilterEdgeHint(isRight: true),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMobileListView(List<Transaction> shown, String status) {
    final sorted = _sortTransactions(shown);
    const showAmount = true;
    return sorted.isEmpty
        ? _EmptyState(filter: status)
        : ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            itemCount: sorted.length,
            itemBuilder: (ctx, i) => _OrderCard(
              tx: sorted[i],
              isCompact: false,
              showAmount: showAmount,
              priorityServiceLabel: _priorityServiceLabels[sorted[i].id],
              onStatusUpdate: (newStatus) =>
                  _updateStatus(sorted[i], newStatus),
            ),
          );
  }

  Widget _buildDesktopListWorkspace(
    List<Transaction> activeWork,
    List<Transaction> baseTransactions,
  ) {
    final source = _isCompletedArchiveTab
        ? baseTransactions.where(_isCompletedTransaction)
        : activeWork
            .where((t) => t.isDeleted == 0 && _normalizedStatus(t) == _filter);
    final filtered = source
        .where((t) => _query.isEmpty || _matchesQuery(t, _query))
        .toList();
    final sorted = _sortTransactions(filtered);
    const showAmount = true;
    final filterCounts = _operationFilterCountsForStatus(
      baseTransactions,
      _filter,
    );

    return ColoredBox(
      color: const Color(0xFFF1F5F9),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final sidebarWidth = constraints.maxWidth >= 1200 ? 260.0 : 224.0;
          final listHorizontal = constraints.maxWidth >= 1200 ? 18.0 : 14.0;
          final vertical = constraints.maxWidth >= 1200 ? 18.0 : 14.0;
          final remainingWidth =
              constraints.maxWidth - sidebarWidth - (listHorizontal * 2);
          final useTwoColumns = remainingWidth >= 760;
          final gridGap = constraints.maxWidth >= 1200 ? 16.0 : 12.0;
          final maxGridWidth = remainingWidth >= 1740 ? 1640.0 : remainingWidth;
          final rowCount =
              useTwoColumns ? (sorted.length / 2).ceil() : sorted.length;

          return Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                width: sidebarWidth,
                child: _buildDesktopWorkFilterSidebar(
                  baseTransactions,
                  filterCounts,
                  sorted.length,
                ),
              ),
              Expanded(
                child: sorted.isEmpty
                    ? _EmptyState(filter: _filter)
                    : ListView.builder(
                        padding: EdgeInsets.fromLTRB(
                          listHorizontal,
                          vertical,
                          listHorizontal,
                          34,
                        ),
                        itemCount: rowCount,
                        itemBuilder: (context, rowIndex) {
                          if (!useTwoColumns) {
                            final tx = sorted[rowIndex];
                            return _OrderCard(
                              tx: tx,
                              queueNumber: rowIndex + 1,
                              isCompact: false,
                              showAmount: showAmount,
                              priorityServiceLabel:
                                  _priorityServiceLabels[tx.id],
                              onStatusUpdate: (newStatus) =>
                                  _updateStatus(tx, newStatus),
                            );
                          }

                          final leftIndex = rowIndex * 2;
                          final rightIndex = leftIndex + 1;
                          final leftTx = sorted[leftIndex];
                          final rightTx = rightIndex < sorted.length
                              ? sorted[rightIndex]
                              : null;

                          return Align(
                            alignment: Alignment.topLeft,
                            child: ConstrainedBox(
                              constraints: BoxConstraints(
                                maxWidth: maxGridWidth,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: _OrderCard(
                                      tx: leftTx,
                                      queueNumber: leftIndex + 1,
                                      isCompact: false,
                                      showAmount: showAmount,
                                      priorityServiceLabel:
                                          _priorityServiceLabels[leftTx.id],
                                      onStatusUpdate: (newStatus) =>
                                          _updateStatus(leftTx, newStatus),
                                    ),
                                  ),
                                  SizedBox(width: gridGap),
                                  Expanded(
                                    child: rightTx == null
                                        ? const SizedBox.shrink()
                                        : _OrderCard(
                                            tx: rightTx,
                                            queueNumber: rightIndex + 1,
                                            isCompact: false,
                                            showAmount: showAmount,
                                            priorityServiceLabel:
                                                _priorityServiceLabels[
                                                    rightTx.id],
                                            onStatusUpdate: (newStatus) =>
                                                _updateStatus(
                                                    rightTx, newStatus),
                                          ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildDesktopWorkFilterSidebar(
    List<Transaction> baseTransactions,
    Map<String, int> counts,
    int visibleCount,
  ) {
    final isLocked = _isCompletedArchiveTab;
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(right: BorderSide(color: Color(0xFFE2E8F0))),
      ),
      child: SafeArea(
        top: false,
        bottom: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(14, 16, 14, 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Prioritas Kerja',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  color: const Color(0xFF0F172A),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Pilih antrean yang perlu ditangani lebih dulu.',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 11.5,
                  height: 1.35,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF64748B),
                ),
              ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                  borderRadius: BorderRadius.zero,
                ),
                child: Row(
                  children: [
                    const Icon(Icons.view_list_rounded,
                        size: 17, color: _kBrand),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Tampil',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w800,
                          color: const Color(0xFF64748B),
                        ),
                      ),
                    ),
                    Text(
                      '$visibleCount',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                        color: _kBrand,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              IgnorePointer(
                ignoring: isLocked,
                child: Opacity(
                  opacity: isLocked ? 0.52 : 1,
                  child: Column(
                    children: [
                      for (final filter in _operationFilters) ...[
                        _DesktopWorkFilterTile(
                          label: _operationFilterLabel(filter),
                          description: _desktopWorkFilterDescription(filter),
                          count: counts[filter] ?? 0,
                          isDanger: _isDangerPriorityLabel(filter),
                          isSelected: isLocked
                              ? filter == 'Semua'
                              : _operationFilter == filter,
                          onTap: () =>
                              _selectQuickFilter(filter, baseTransactions),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _desktopWorkFilterDescription(String filter) {
    switch (filter) {
      case 'Semua':
        return _isCompletedArchiveTab
            ? 'Semua pesanan selesai'
            : 'Semua pesanan status $_filter';
      case 'Prioritas':
        return 'Express, kilat, atau SLA cepat';
      case 'Jatuh Tempo':
        return 'Estimasi ambil dekat';
      case 'Terlambat':
        return 'Sudah melewati estimasi';
      case 'Belum Lunas':
        return 'Masih perlu pembayaran';
      default:
        return 'Filter antrean kerja';
    }
  }

  bool get _isCompletedArchiveTab => _isCompletedStatus(_filter);

  bool _isCompletedStatus(String status) => status == 'Selesai';

  bool _isCompletedTransaction(Transaction tx) =>
      _normalizedStatus(tx) == 'Selesai';

  bool _isActiveWorkTransaction(Transaction tx) =>
      tx.isDeleted == 0 && !_isCompletedTransaction(tx);

  String _normalizedStatus(Transaction tx) {
    final status = tx.servisStatus.trim();
    if (status == 'Siap Ambil') return 'Siap';
    if (status.toLowerCase().startsWith('selesai')) return 'Selesai';
    return status.isEmpty ? 'Diterima' : status;
  }

  bool _matchesQuery(Transaction tx, String rawQuery) {
    final q = rawQuery.trim().toLowerCase();
    if (q.isEmpty) return true;
    return (tx.customerName?.toLowerCase().contains(q) ?? false) ||
        (tx.transactionCode?.toLowerCase().contains(q) ?? false) ||
        (tx.note?.toLowerCase().contains(q) ?? false) ||
        (tx.id?.toString().contains(q) ?? false);
  }

  bool _passesOperationFilter(Transaction tx) =>
      _isActiveWorkTransaction(tx) &&
      _matchesOperationFilter(tx, _operationFilter);

  int _quickFilterStatusCount(
    List<Transaction> transactions,
    String filter,
    String status,
  ) {
    if (_isCompletedStatus(status)) return 0;
    if (filter == 'Semua') return 0;
    return transactions
        .where((tx) =>
            _isActiveWorkTransaction(tx) &&
            _normalizedStatus(tx) == status &&
            _matchesOperationFilter(tx, filter))
        .length;
  }

  void _selectQuickFilter(
    String filter,
    List<Transaction> baseTransactions,
  ) {
    if (_isCompletedArchiveTab) return;

    setState(() => _operationFilter = filter);
    _animateQuickFilterHint(filter);
  }

  void _updateQuickFilterScrollHints() {
    if (!mounted || !_quickFilterScrollCtrl.hasClients) return;

    final position = _quickFilterScrollCtrl.position;
    final hasOverflow = position.maxScrollExtent > 2;
    final showLeft = hasOverflow && position.pixels > 6;
    final showRight =
        hasOverflow && position.pixels < position.maxScrollExtent - 6;

    if (_showQuickFilterLeftHint == showLeft &&
        _showQuickFilterRightHint == showRight) {
      return;
    }

    setState(() {
      _showQuickFilterLeftHint = showLeft;
      _showQuickFilterRightHint = showRight;
    });
  }

  void _animateQuickFilterHint(String filter) {
    final index = _operationFilters.indexOf(filter);
    if (index < 0) return;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_quickFilterScrollCtrl.hasClients) return;
      final position = _quickFilterScrollCtrl.position;
      final maxOffset = position.maxScrollExtent;
      if (maxOffset <= 0) return;

      final target =
          filter == 'Semua' ? 0.0 : (index * 42.0).clamp(0.0, maxOffset);
      _quickFilterScrollCtrl.animateTo(
        target,
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
      );
    });
  }

  List<Transaction> _sortTransactions(List<Transaction> transactions) {
    final list = List<Transaction>.from(transactions);
    final now = DateTime.now();
    list.sort((a, b) {
      final aIsCompleted = _isCompletedTransaction(a);
      final bIsCompleted = _isCompletedTransaction(b);
      if (aIsCompleted && bIsCompleted) {
        return b.createdAt.compareTo(a.createdAt);
      }
      if (aIsCompleted != bIsCompleted) {
        return aIsCompleted ? 1 : -1;
      }

      // 1. Overdue checks
      final aDt = _effectivePickupAt(
        a,
        priorityServiceLabel:
            a.id == null ? null : _priorityServiceLabels[a.id],
      );
      final bDt = _effectivePickupAt(
        b,
        priorityServiceLabel:
            b.id == null ? null : _priorityServiceLabels[b.id],
      );

      final aIsOverdue = aDt != null && aDt.isBefore(now);
      final bIsOverdue = bDt != null && bDt.isBefore(now);

      if (aIsOverdue && !bIsOverdue) return -1;
      if (!aIsOverdue && bIsOverdue) return 1;

      // 2. Priority checks (Express / Kilat / Cepat / Prioritas)
      bool checkExpress(Transaction tx) {
        return _isPriorityTransaction(tx);
      }

      final aIsExpress = checkExpress(a);
      final bIsExpress = checkExpress(b);

      if (aIsExpress && !bIsExpress) return -1;
      if (!aIsExpress && bIsExpress) return 1;

      // 3. Pickup Schedule Ascending
      if (aDt != null && bDt != null) {
        return aDt.compareTo(bDt);
      } else if (aDt != null) {
        return -1;
      } else if (bDt != null) {
        return 1;
      }

      // 4. Fallback to Created At Descending
      return b.createdAt.compareTo(a.createdAt);
    });
    return list;
  }

  bool _isInSelectedDateRange(Transaction tx) {
    if (_filterDateRange == null) return true;
    final createdAt = DateTime.tryParse(tx.createdAt);
    if (createdAt == null) return true;

    final endDay = _filterDateRange!.end.add(const Duration(days: 1));
    return !createdAt.isBefore(_filterDateRange!.start) &&
        createdAt.isBefore(endDay);
  }

  bool _matchesOperationFilter(Transaction tx, String filter) {
    final now = DateTime.now();
    bool sameDay(DateTime a, DateTime b) =>
        a.year == b.year && a.month == b.month && a.day == b.day;

    final createdAt = DateTime.tryParse(tx.createdAt);
    final pickupAt = _effectivePickupAt(
      tx,
      priorityServiceLabel:
          tx.id == null ? null : _priorityServiceLabels[tx.id],
    );
    final isCompleted = _isCompletedTransaction(tx);
    if (isCompleted) return false;

    final isUnpaid = tx.amountPaid < tx.grandTotal;
    final isOverdue = pickupAt != null && pickupAt.isBefore(now);
    final isDueToday = pickupAt != null && !isOverdue && sameDay(pickupAt, now);
    final isDueSoon = pickupAt != null &&
        !pickupAt.isBefore(now) &&
        pickupAt.difference(now) <= _dueSoonThreshold;
    final isToday = (createdAt != null && sameDay(createdAt, now)) ||
        (pickupAt != null && sameDay(pickupAt, now));

    switch (filter) {
      case 'Hari Ini':
        return isToday;
      case 'Jatuh Tempo':
        return isDueToday || isDueSoon;
      case 'Terlambat':
        return isOverdue;
      case 'Prioritas':
        return _isPriorityTransaction(tx);
      case 'Belum Lunas':
        return isUnpaid;
      case 'Semua':
      default:
        return true;
    }
  }

  List<Transaction> _transactionsForStatusScope(
    List<Transaction> transactions,
    String status,
  ) {
    if (_isCompletedStatus(status)) {
      return transactions.where(_isCompletedTransaction).toList();
    }
    return transactions
        .where(_isActiveWorkTransaction)
        .where((tx) => _normalizedStatus(tx) == status)
        .toList();
  }

  Map<String, int> _operationFilterCountsForStatus(
    List<Transaction> transactions,
    String status,
  ) {
    final scoped = _transactionsForStatusScope(transactions, status);
    return {
      for (final filter in _operationFilters)
        filter: filter == 'Semua'
            ? scoped.length
            : scoped.where((tx) => _matchesOperationFilter(tx, filter)).length,
    };
  }

  bool _isPriorityTransaction(Transaction tx) {
    if (!_isActiveWorkTransaction(tx)) return false;
    return _isPriorityservisTransaction(tx) ||
        (tx.id != null && _priorityServiceLabels.containsKey(tx.id));
  }

  void _showStatusGuide() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        titlePadding: const EdgeInsets.fromLTRB(20, 18, 12, 0),
        contentPadding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
        actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
        title: Row(
          children: [
            const Icon(Icons.help_outline_rounded, color: _kBrand),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'Panduan Status Servis',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: const Color(0xFF0F172A),
                ),
              ),
            ),
            IconButton(
              onPressed: () => Navigator.pop(ctx),
              icon: const Icon(Icons.close_rounded),
            ),
          ],
        ),
        content: const SizedBox(
          width: 440,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _GuideRow(
                icon: Icons.inbox_rounded,
                title: 'Diterima',
                desc: 'Pesanan baru masuk dan belum mulai dikerjakan.',
              ),
              _GuideRow(
                icon: Icons.sync_rounded,
                title: 'Proses',
                desc: 'Unit sedang didiagnosa atau dikerjakan oleh teknisi.',
              ),
              _GuideRow(
                icon: Icons.check_circle_rounded,
                title: 'Siap',
                desc: 'Pesanan sudah selesai diproses dan siap diambil.',
              ),
              _GuideRow(
                icon: Icons.timer_off_rounded,
                title: 'Terlambat',
                desc:
                    'Estimasi selesai sudah lewat, tetapi status belum selesai.',
              ),
              _GuideRow(
                icon: Icons.event_available_rounded,
                title: 'Deadline Dekat',
                desc:
                    'Pesanan yang estimasi pengambilannya hari ini atau kurang dari 2 jam lagi.',
              ),
              _GuideRow(
                icon: Icons.bolt_rounded,
                title: 'Express/Prioritas',
                desc:
                    'Pesanan dengan nama layanan express/kilat/cepat/prioritas, atau estimasi maksimal 8 jam.',
              ),
              _GuideRow(
                icon: Icons.payments_outlined,
                title: 'Belum Lunas',
                desc:
                    'Total pembayaran pelanggan masih kurang dari total tagihan.',
              ),
            ],
          ),
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(ctx),
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                padding: const EdgeInsets.symmetric(vertical: 13),
              ),
              child: const Text('Mengerti',
                  style: TextStyle(fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _updateStatus(Transaction tx, String newStatus) async {
    await ref
        .read(transactionsProvider.notifier)
        .updateservisStatus(tx.id!, newStatus, tx.kelengkapan);
    try {
      await SystemSound.play(SystemSoundType.click);
    } catch (_) {
      // Some platforms or silent profiles do not expose a system click sound.
    }
    if (mounted) {
      ModernSnackBar.success(
        context: context,
        message: 'Pesanan ${tx.customerName ?? 'Pelanggan'} kini: $newStatus',
      );
    }
  }
}

// SUMMARY BAR

class _DateFilterTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final bool danger;
  final VoidCallback onTap;

  const _DateFilterTile({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = danger ? AppColors.danger : AppColors.textTitle;
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
        child: Row(
          children: [
            Icon(icon, size: 18, color: color),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: color,
                ),
              ),
            ),
            if (selected)
              const Icon(
                Icons.check_circle_rounded,
                size: 18,
                color: _kBrand,
              ),
          ],
        ),
      ),
    );
  }
}

class _StatusFilterChip extends StatelessWidget {
  final String label;
  final int count;
  final int alertCount;
  final bool showCount;
  final bool isSelected;
  final VoidCallback onTap;
  final Color color;

  const _StatusFilterChip({
    required this.label,
    required this.count,
    required this.alertCount,
    this.showCount = true,
    required this.isSelected,
    required this.onTap,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final hasAlertOverlay = alertCount > 0;
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          height: 58,
          padding: const EdgeInsets.fromLTRB(3, 7, 3, 6),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(
              bottom: BorderSide(
                color: isSelected ? color : const Color(0xFFE2E8F0),
                width: isSelected ? 2.5 : 1,
              ),
            ),
          ),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 5),
            decoration: BoxDecoration(
              color: isSelected
                  ? color.withValues(alpha: 0.08)
                  : Colors.transparent,
              borderRadius: BorderRadius.zero,
              border: Border.all(
                color: isSelected
                    ? color.withValues(alpha: 0.28)
                    : Colors.transparent,
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      fontWeight:
                          isSelected ? FontWeight.w900 : FontWeight.w700,
                      color: isSelected ? color : const Color(0xFF475569),
                    ),
                  ),
                ),
                if (showCount) ...[
                  const SizedBox(width: 5),
                  if (hasAlertOverlay)
                    _TabCountBadge(count: alertCount)
                  else
                    _TabCountText(
                      count: count,
                      isSelected: isSelected,
                      activeColor: color,
                    ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _QuickFilterEdgeHint extends StatelessWidget {
  final bool isRight;

  const _QuickFilterEdgeHint({required this.isRight});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: 34,
        alignment: isRight ? Alignment.centerRight : Alignment.centerLeft,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: isRight ? Alignment.centerLeft : Alignment.centerRight,
            end: isRight ? Alignment.centerRight : Alignment.centerLeft,
            colors: const [
              Color(0x00FFFFFF),
              Colors.white,
            ],
          ),
        ),
        child: Container(
          width: 20,
          height: 28,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: const Color(0xFFF8FAFC),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: const Color(0xFFD8E2EF)),
          ),
          child: Icon(
            isRight ? Icons.chevron_right_rounded : Icons.chevron_left_rounded,
            size: 18,
            color: _kBrand,
          ),
        ),
      ),
    );
  }
}

class _QuickFilterChip extends StatelessWidget {
  final String label;
  final int count;
  final bool isDanger;
  final bool showAlertBadge;
  final bool isSelected;
  final VoidCallback onTap;

  const _QuickFilterChip({
    required this.label,
    required this.count,
    required this.isDanger,
    required this.showAlertBadge,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final activeColor = isDanger ? AppColors.danger : AppColors.primaryBrand;
    const inactiveText = Color(0xFF475569);

    return InkWell(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        height: 42,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: isSelected ? activeColor : Colors.transparent,
              width: 2.5,
            ),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: isSelected ? activeColor : inactiveText,
              ),
            ),
            const SizedBox(width: 5),
            if (showAlertBadge && count > 0)
              _TabCountBadge(count: count, compact: true)
            else
              _TabCountText(
                count: count,
                isSelected: isSelected,
                activeColor: activeColor,
                compact: true,
              ),
          ],
        ),
      ),
    );
  }
}

class _DesktopWorkFilterTile extends StatelessWidget {
  final String label;
  final String description;
  final int count;
  final bool isDanger;
  final bool isSelected;
  final VoidCallback onTap;

  const _DesktopWorkFilterTile({
    required this.label,
    required this.description,
    required this.count,
    required this.isDanger,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = isDanger ? AppColors.danger : _kBrand;
    return Material(
      color: isSelected ? color.withValues(alpha: 0.08) : Colors.white,
      child: InkWell(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.zero,
            border: Border.all(
              color: isSelected
                  ? color.withValues(alpha: 0.45)
                  : const Color(0xFFE2E8F0),
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 4,
                height: 42,
                color: isSelected ? color : const Color(0xFFE2E8F0),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        color: isSelected ? color : const Color(0xFF0F172A),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 10.5,
                        height: 1.25,
                        fontWeight: FontWeight.w700,
                        color: const Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                constraints: const BoxConstraints(minWidth: 26),
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: isSelected ? color : const Color(0xFFF1F5F9),
                  borderRadius: BorderRadius.zero,
                ),
                child: Text(
                  count > 99 ? '99+' : count.toString(),
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 11,
                    height: 1,
                    fontWeight: FontWeight.w900,
                    color: isSelected ? Colors.white : const Color(0xFF475569),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TabCountText extends StatelessWidget {
  final int count;
  final bool isSelected;
  final Color activeColor;
  final bool compact;

  const _TabCountText({
    required this.count,
    required this.isSelected,
    required this.activeColor,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final text = count > 99 ? '99+' : count.toString();
    final hasItems = count > 0;
    final height = compact ? 18.0 : 22.0;
    final minWidth = compact ? 22.0 : 27.0;
    final backgroundColor = isSelected
        ? activeColor
        : (hasItems
            ? activeColor.withValues(alpha: 0.16)
            : const Color(0xFFEFF4FA));
    final borderColor = isSelected
        ? activeColor
        : (hasItems
            ? activeColor.withValues(alpha: 0.42)
            : const Color(0xFFD8E2EF));
    final textColor = isSelected
        ? Colors.white
        : (hasItems ? activeColor : const Color(0xFF64748B));

    return Semantics(
      label: '$count transaksi',
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        height: height,
        constraints: BoxConstraints(minWidth: minWidth),
        alignment: Alignment.center,
        padding: EdgeInsets.symmetric(horizontal: compact ? 5 : 6),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: borderColor),
        ),
        child: Text(
          text,
          maxLines: 1,
          style: GoogleFonts.plusJakartaSans(
            fontSize: compact ? 9.5 : 11,
            height: 1,
            fontWeight: FontWeight.w900,
            color: textColor,
          ),
        ),
      ),
    );
  }
}

class _TabCountBadge extends StatelessWidget {
  final int count;
  final bool compact;

  const _TabCountBadge({
    required this.count,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final height = compact ? 18.0 : 22.0;
    return Semantics(
      label: '$count transaksi perlu perhatian',
      child: Container(
        height: height,
        constraints: BoxConstraints(minWidth: height),
        alignment: Alignment.center,
        padding: EdgeInsets.symmetric(horizontal: compact ? 5 : 6),
        decoration: const BoxDecoration(
          color: AppColors.danger,
          borderRadius: BorderRadius.all(Radius.circular(99)),
        ),
        child: Text(
          count > 99 ? '99+' : count.toString(),
          maxLines: 1,
          style: GoogleFonts.plusJakartaSans(
            fontSize: compact ? 9.5 : 11,
            height: 1,
            fontWeight: FontWeight.w900,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}

// --- ORDER CARD ---

// SIDEBAR ITEM

class _GuideRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String desc;

  const _GuideRow({
    required this.icon,
    required this.title,
    required this.desc,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: const BoxDecoration(
              color: Color(0xFFF1F5F9),
              borderRadius: BorderRadius.zero,
            ),
            child: Icon(icon, size: 18, color: _kBrand),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: const Color(0xFF0F172A),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  desc,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    height: 1.35,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF64748B),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ORDER CARD

class _OrderCard extends ConsumerWidget {
  final Transaction tx;
  final Function(String) onStatusUpdate;
  final bool isCompact;
  final bool showAmount;
  final String? priorityServiceLabel;
  final int? queueNumber;

  const _OrderCard({
    required this.tx,
    required this.onStatusUpdate,
    this.isCompact = false,
    this.showAmount = true,
    this.priorityServiceLabel,
    this.queueNumber,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDesktopQueueCard = queueNumber != null;
    final color = _statusColor(
        tx.servisStatus == 'Siap Ambil' ? 'Siap' : tx.servisStatus);
    final icon = _statusIcon(
        tx.servisStatus == 'Siap Ambil' ? 'Siap' : tx.servisStatus);
    final isPaid = tx.amountPaid >= tx.grandTotal;
    final effectivePickupAt =
        _effectivePickupAt(tx, priorityServiceLabel: priorityServiceLabel);

    bool isOverdue = false;
    if (tx.servisStatus != 'Selesai' &&
        effectivePickupAt != null &&
        effectivePickupAt.isBefore(DateTime.now())) {
      isOverdue = true;
    }

    String? pickupText;
    if (effectivePickupAt != null) {
      pickupText =
          DateFormat('EEE, dd MMM HH:mm', 'id').format(effectivePickupAt);
    } else if (tx.pickupSchedule != null && tx.pickupSchedule!.isNotEmpty) {
      pickupText = tx.pickupSchedule;
    }

    // COUNTDOWN BADGE
    Widget? countdownBadge;
    if (tx.servisStatus != 'Selesai' && effectivePickupAt != null) {
      final now = DateTime.now();
      final diff = effectivePickupAt.difference(now);
      final bool isOverdue = now.isAfter(effectivePickupAt);

      Color badgeFgColor;
      IconData badgeIcon;
      String badgeText;

      if (isOverdue) {
        final overdueDiff = now.difference(effectivePickupAt);
        badgeFgColor = const Color(0xFFE73A53);
        badgeIcon = Icons.timer_off_rounded;

        if (overdueDiff.inDays > 0) {
          badgeText =
              'TERLAMBAT ${overdueDiff.inDays} Hari ${overdueDiff.inHours % 24} Jam';
        } else if (overdueDiff.inHours > 0) {
          badgeText =
              'TERLAMBAT ${overdueDiff.inHours} Jam ${overdueDiff.inMinutes % 60} Menit';
        } else {
          badgeText = 'TERLAMBAT ${overdueDiff.inMinutes} Menit';
        }
      } else {
        // Remaining time
        if (diff.inHours < 3) {
          // Urgent (< 3 hours remaining)
          badgeFgColor = const Color(0xFFEA580C);
          badgeIcon = Icons.error_outline_rounded;
          if (diff.inHours > 0) {
            badgeText = 'SISA ${diff.inHours} Jam ${diff.inMinutes % 60} Menit';
          } else {
            badgeText = 'SISA ${diff.inMinutes} Menit';
          }
        } else if (diff.inHours < 24) {
          // Under 24h (Blue theme)
          badgeFgColor = const Color(0xFF2563EB);
          badgeIcon = Icons.schedule_rounded;
          badgeText = 'SISA ${diff.inHours} Jam ${diff.inMinutes % 60} Menit';
        } else {
          // More than 24h (Cool grey theme)
          badgeFgColor = const Color(0xFF475569);
          badgeIcon = Icons.schedule_rounded;
          badgeText = 'SISA ${diff.inDays} Hari ${diff.inHours % 24} Jam';
        }
      }

      countdownBadge = Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
        decoration: BoxDecoration(
          color: badgeFgColor,
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(badgeIcon, size: 11, color: Colors.white),
            const SizedBox(width: 4),
            Text(
              badgeText,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 9.5,
                fontWeight: FontWeight.w900,
                color: Colors.white,
              ),
            ),
          ],
        ),
      );
    }

    final noTrx = TransactionCodeFormatter.format(
      id: tx.id ?? 0,
      createdAt: tx.createdAt,
      transactionCode: tx.transactionCode,
    );
    final createdText = _formatTransactionDateTime(tx.createdAt);

    final normalizedStatus =
        tx.servisStatus == 'Siap Ambil' ? 'Siap' : tx.servisStatus;
    final currentIdx = _statusFlow.indexOf(normalizedStatus);
    final nextStatus = currentIdx < _statusFlow.length - 1
        ? _statusFlow[currentIdx + 1]
        : null;
    final explicitType = tx.orderType?.trim();
    final servicePriorityLabel = priorityServiceLabel?.trim();
    final hasServicePriority =
        servicePriorityLabel != null && servicePriorityLabel.isNotEmpty;
    final serviceBadgeLabel = _transactionServiceBadgeLabel(
      tx,
      fallbackLabel: hasServicePriority ? servicePriorityLabel : null,
    );
    final isPrioritySla = serviceBadgeLabel != null;
    final fulfillmentBadgeLabel =
        _resolveFulfillmentBadge(tx.fulfillmentType, explicitType);

    String buildReminderMessage({String? statusOverride}) {
      final statusBayar = isPaid ? 'LUNAS' : 'BELUM LUNAS';
      final servisStatusText = statusOverride ?? tx.servisStatus;
      final pickupLine = _pickupLineForWhatsApp(pickupText, servisStatusText);
      return '''Halo Kak ${tx.customerName ?? ''} 👋,

Terima kasih telah mempercayakan perbaikan perangkat Anda kepada kami.
Berikut ini adalah rincian pesanan servis Anda:

🧾 *No. Invoice:* $noTrx
🏷️ *Status Servis:* $servisStatusText
💳 *Status Pembayaran:* $statusBayar
${_totalTagihanLineForWhatsApp(isPaid: isPaid, grandTotal: tx.grandTotal)}${tx.kelengkapan != null && tx.kelengkapan!.isNotEmpty ? '🌸 *Parfum:* ${tx.kelengkapan}\n' : ''}$pickupLine
Untuk mengecek status pesanan atau jika ada pertanyaan lebih lanjut, jangan ragu untuk membalas pesan ini. Kami akan dengan senang hati membantu Anda.

Terima kasih dan semoga hari Kakak menyenangkan! ✨''';
    }

    Future<_ReminderLaunchResult> launchWhatsApp(
      BuildContext context, {
      String? statusOverride,
    }) async {
      final customers = ref.read(customersProvider);
      final customer = tx.customerId != null
          ? customers.firstWhere((c) => c.id == tx.customerId,
              orElse: () => Customer(name: tx.customerName ?? ''))
          : null;

      var phone = customer?.phone?.trim() ?? '';
      if (phone.isEmpty && tx.customerId != null) {
        final savedCustomer =
            await DBHelper.instance.getCustomerById(tx.customerId!);
        phone = savedCustomer?.phone?.trim() ?? '';
      }
      if (!context.mounted) return _ReminderLaunchResult.failed;
      final outgoingMsg = buildReminderMessage(statusOverride: statusOverride);
      if (phone.isEmpty) {
        final confirmed = await _showWhatsAppFallbackDialog(
          context,
          message: outgoingMsg,
          reason: 'Nomor WhatsApp pelanggan belum tersedia.',
        );
        return confirmed
            ? _ReminderLaunchResult.confirmedManually
            : _ReminderLaunchResult.failed;
      }

      final opened = await WhatsAppHelper.sendMessage(
        message: outgoingMsg,
        phone: phone,
      );
      if (!opened && context.mounted) {
        final confirmed = await _showWhatsAppFallbackDialog(
          context,
          message: outgoingMsg,
          reason: 'WhatsApp belum berhasil dibuka pada perangkat ini.',
        );
        return confirmed
            ? _ReminderLaunchResult.confirmedManually
            : _ReminderLaunchResult.failed;
      }
      return opened
          ? _ReminderLaunchResult.opened
          : _ReminderLaunchResult.failed;
    }

    Future<bool> remindCustomerBeforeReady(BuildContext context) async {
      final message = buildReminderMessage(statusOverride: 'Siap Ambil');
      while (context.mounted) {
        if (!context.mounted) return false;
        final result =
            await launchWhatsApp(context, statusOverride: 'Siap Ambil');
        if (result == _ReminderLaunchResult.confirmedManually) return true;
        if (result != _ReminderLaunchResult.opened || !context.mounted) {
          return false;
        }

        await Future<void>.delayed(const Duration(milliseconds: 500));
        if (!context.mounted) return false;
        final action = await showDialog<_ReminderConfirmAction>(
          context: context,
          barrierDismissible: false,
          builder: (_) => const _ReminderSentConfirmDialog(),
        );
        if (action == _ReminderConfirmAction.sent) return true;
        if (action == _ReminderConfirmAction.openAgain) continue;
        if (action == _ReminderConfirmAction.shareManually) {
          await SharePlus.instance.share(ShareParams(text: message));
          continue;
        }
        return false;
      }
      return false;
    }

    Future<void> handleNextStatus(BuildContext context) async {
      if (nextStatus == null) return;
      if (nextStatus == 'Selesai') {
        if (!isPaid) {
          _showPaymentFlow(context, ref, tx,
              nextStatus: nextStatus, onStatusUpdate: onStatusUpdate);
          return;
        }
        final pickupDt = effectivePickupAt;
        final now = DateTime.now();
        final bool isTooEarly = pickupDt != null && now.isBefore(pickupDt);
        final bool? proceed = await showDialog<bool>(
          context: context,
          builder: (ctx) => _SelesaiConfirmDialog(
            tx: tx,
            pickupDt: pickupDt,
            isTooEarly: isTooEarly,
          ),
        );
        if (proceed != true) return;
        onStatusUpdate(nextStatus);
        return;
      }

      if (nextStatus == 'Proses') {
        final bool? proceed = await showDialog<bool>(
          context: context,
          builder: (ctx) => _ProsesConfirmDialog(
            tx: tx,
          ),
        );
        if (proceed != true) return;
        onStatusUpdate(nextStatus);
        return;
      }

      if (nextStatus == 'Siap') {
        final pickupDt = effectivePickupAt;
        Duration? remaining;
        if (pickupDt != null && DateTime.now().isBefore(pickupDt)) {
          remaining = pickupDt.difference(DateTime.now());
        }

        final action = await showDialog<_SiapConfirmAction>(
          context: context,
          builder: (ctx) => _SiapConfirmDialog(
            tx: tx,
            pickupDt: pickupDt,
            remaining: remaining,
          ),
        );
        if (action == null) return;

        if (action == _SiapConfirmAction.confirmAndNotify) {
          if (!context.mounted) return;
          final reminded = await remindCustomerBeforeReady(context);
          if (!reminded) return;
        }
        onStatusUpdate(nextStatus);
        return;
      }

      onStatusUpdate(nextStatus);
    }

    Future<void> handlePreviousStatus(BuildContext context) async {
      if (currentIdx <= 0) return;
      final previousStatus = _statusFlow[currentIdx - 1];
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (ctx) => _PreviousStatusConfirmDialog(
          tx: tx,
          currentStatus: normalizedStatus,
          previousStatus: previousStatus,
        ),
      );
      if (confirmed != true) return;
      onStatusUpdate(previousStatus);
    }

    if (isCompact) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: InkWell(
          onTap: () => _showOrderDetails(context, ref, tx),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: isPrioritySla ? const Color(0xFFFFFBF7) : Colors.white,
              borderRadius: BorderRadius.zero,
              border: Border.all(
                color: isOverdue
                    ? const Color(0xFFFCA5A5)
                    : isPrioritySla
                        ? const Color(0xFFFDBA74)
                        : const Color(0xFFE2E8F0),
                width: isOverdue || isPrioritySla ? 1.4 : 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        tx.customerName ?? 'Pelanggan Umum',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          color: const Color(0xFF0F172A),
                        ),
                      ),
                    ),
                    if (showAmount) ...[
                      const SizedBox(width: 8),
                      Text(
                        _fRp(tx.grandTotal),
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          color: const Color(0xFF0F172A),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        noTrx,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.jetBrainsMono(
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFF94A3B8),
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    _CompactBadge(
                      label: isPaid ? 'Lunas' : 'Belum Lunas',
                      color: isPaid ? _paidBadgeColor : AppColors.danger,
                    ),
                    if (serviceBadgeLabel != null) ...[
                      const SizedBox(width: 4),
                      _CompactBadge(
                        label: serviceBadgeLabel,
                        color: _priorityBadgeColor,
                        icon: Icons.bolt_rounded,
                        solid: true,
                      ),
                    ],
                    if (fulfillmentBadgeLabel != null) ...[
                      const SizedBox(width: 4),
                      _CompactBadge(
                        label: fulfillmentBadgeLabel,
                        color: _fulfillmentBadgeColor,
                        icon: Icons.handyman_rounded,
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(Icons.calendar_month_rounded,
                        size: 12, color: Color(0xFF94A3B8)),
                    const SizedBox(width: 5),
                    Expanded(
                      child: Text(
                        createdText,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          color: const Color(0xFF64748B),
                        ),
                      ),
                    ),
                  ],
                ),
                if (pickupText != null) ...[
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
                    decoration: BoxDecoration(
                      color: isOverdue
                          ? const Color(0xFFFFF1F2)
                          : const Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.zero,
                      border: Border.all(
                        color: isOverdue
                            ? const Color(0xFFFECACA)
                            : const Color(0xFFE2E8F0),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          isOverdue
                              ? Icons.timer_off_rounded
                              : Icons.schedule_rounded,
                          size: 15,
                          color: isOverdue
                              ? const Color(0xFFE11D48)
                              : const Color(0xFF475569),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            'Est Pengambilan: $pickupText',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w900,
                              color: isOverdue
                                  ? const Color(0xFFE11D48)
                                  : const Color(0xFF334155),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (countdownBadge != null) ...[
                    const SizedBox(height: 6),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: countdownBadge,
                    ),
                  ],
                ],
                const SizedBox(height: 8),
                FutureBuilder<List<TransactionItem>>(
                  future: DBHelper.instance.getTransactionItems(tx.id ?? 0),
                  builder: (context, snapshot) {
                    final items = snapshot.data ?? const <TransactionItem>[];
                    if (items.isEmpty) return const SizedBox.shrink();
                    final first = items.first;
                    final details = _itemQtyWithUnit(first);
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Text(
                                first.productName,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 12,
                                  height: 1.25,
                                  fontWeight: FontWeight.w900,
                                  color: const Color(0xFF334155),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: _kBrand.withValues(alpha: 0.08),
                                border:
                                    Border.all(color: const Color(0xFFDBEAFE)),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: Text(
                                details,
                                maxLines: 1,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w900,
                                  color: _kBrand,
                                ),
                              ),
                            ),
                          ],
                        ),
                        if (items.length > 1) ...[
                          const SizedBox(height: 4),
                          Text(
                            '+${items.length - 1} layanan lain',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w800,
                              color: const Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ],
                    );
                  },
                ),
                if (normalizedStatus != 'Selesai' && nextStatus != null) ...[
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 34,
                          child: ElevatedButton.icon(
                            onPressed: () => handleNextStatus(context),
                            icon: Icon(_statusIcon(nextStatus), size: 13),
                            label: Text(
                              nextStatus,
                              style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _statusColor(nextStatus),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8),
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      _ActionBtn(
                        icon: const FaIcon(FontAwesomeIcons.whatsapp, size: 16),
                        color: const Color(0xFF22C55E),
                        onTap: () => launchWhatsApp(context),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: EdgeInsets.only(
        bottom: isDesktopQueueCard ? 16 : (isCompact ? 10 : 12),
      ),
      child: InkWell(
        onTap: () => _showOrderDetails(context, ref, tx),
        borderRadius: BorderRadius.zero,
        child: Container(
          constraints: BoxConstraints(
            minHeight: isDesktopQueueCard ? 246 : 0,
          ),
          padding: EdgeInsets.all(
            isDesktopQueueCard ? 18 : (isCompact ? 10 : 14),
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(
              color: const Color(0xFFE2E8F0),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF0F172A).withValues(alpha: 0.035),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (queueNumber != null) ...[
                    Container(
                      width: 36,
                      height: 36,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: _kBrand.withValues(alpha: 0.1),
                        border: Border.all(
                          color: _kBrand.withValues(alpha: 0.2),
                        ),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Text(
                        queueNumber! > 99 ? '99+' : queueNumber!.toString(),
                        maxLines: 1,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: queueNumber! > 99 ? 11 : 14,
                          height: 1,
                          fontWeight: FontWeight.w900,
                          color: _kBrand,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                  ],
                  Expanded(
                    child: Text(
                      tx.customerName ?? 'Pelanggan Umum',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: const Color(0xFF0F172A),
                      ),
                    ),
                  ),
                  if (showAmount) ...[
                    const SizedBox(width: 10),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 138),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            'Total',
                            maxLines: 1,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 10,
                              height: 1,
                              fontWeight: FontWeight.w900,
                              color: const Color(0xFF64748B),
                            ),
                          ),
                          const SizedBox(height: 4),
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: Alignment.centerRight,
                            child: Text(
                              _fRp(tx.grandTotal),
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 18,
                                height: 1.1,
                                fontWeight: FontWeight.w900,
                                color: const Color(0xFF0F172A),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
              SizedBox(height: isDesktopQueueCard ? 8 : 5),
              Wrap(
                spacing: 12,
                runSpacing: 5,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.receipt_long_rounded,
                          size: 13, color: Color(0xFF94A3B8)),
                      const SizedBox(width: 5),
                      Text(
                        noTrx,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.jetBrainsMono(
                          fontSize: 9.5,
                          color: const Color(0xFF94A3B8),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.calendar_month_rounded,
                          size: 13, color: Color(0xFF94A3B8)),
                      const SizedBox(width: 5),
                      Text(
                        createdText,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 11,
                          color: const Color(0xFF64748B),
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: isDesktopQueueCard ? 12 : 9),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  _StatusBadge(
                    label: normalizedStatus,
                    color: color,
                    icon: icon,
                  ),
                  InkWell(
                    onTap: isPaid
                        ? null
                        : () =>
                            _showPaymentFlow(context, ref, tx, isOnlyPay: true),
                    child: _StatusBadge(
                      label: isPaid ? 'Lunas' : 'Belum Lunas',
                      color: isPaid ? _paidBadgeColor : AppColors.danger,
                      icon: isPaid
                          ? Icons.verified_rounded
                          : Icons.payments_outlined,
                    ),
                  ),
                  if (serviceBadgeLabel != null)
                    _StatusBadge(
                      label: serviceBadgeLabel,
                      color: _priorityBadgeColor,
                      icon: Icons.bolt_rounded,
                      solid: true,
                    ),
                  if (fulfillmentBadgeLabel != null)
                    _StatusBadge(
                      label: fulfillmentBadgeLabel,
                      color: _fulfillmentBadgeColor,
                      icon: Icons.handyman_rounded,
                    ),
                  if (isOverdue)
                    const _StatusBadge(
                      label: 'Terlambat',
                      color: Color(0xFFE73A53),
                      icon: Icons.timer_off_rounded,
                    ),
                ],
              ),
              if (tx.kelengkapan != null &&
                  tx.kelengkapan!.isNotEmpty &&
                  !isCompact) ...[
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.spa_rounded,
                        size: 14, color: Color(0xFF8B5CF6)),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        tx.kelengkapan!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 12,
                          color: const Color(0xFF8B5CF6),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
              if (isCompact) const SizedBox(height: 6),
              if (isCompact && !isOverdue && showAmount)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _fRp(tx.grandTotal),
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          color: const Color(0xFF0F172A)),
                    ),
                    if (countdownBadge != null) countdownBadge,
                  ],
                ),
              SizedBox(height: isDesktopQueueCard ? 12 : 8),
              FutureBuilder<List<TransactionItem>>(
                future: DBHelper.instance.getTransactionItems(tx.id ?? 0),
                builder: (context, snapshot) {
                  final items = snapshot.data ?? const <TransactionItem>[];
                  if (items.isEmpty) return const SizedBox.shrink();

                  return Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(
                      horizontal: isDesktopQueueCard ? 14 : 12,
                      vertical: isDesktopQueueCard ? 12 : 10,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.zero,
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                items.length > 1
                                    ? 'Layanan (${items.length})'
                                    : 'Layanan',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 15,
                                  height: 1.1,
                                  fontWeight: FontWeight.w900,
                                  color: const Color(0xFF64748B),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'Berat',
                              maxLines: 1,
                              textAlign: TextAlign.right,
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 15,
                                height: 1.1,
                                fontWeight: FontWeight.w900,
                                color: const Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        const Divider(height: 1, color: Color(0xFFE2E8F0)),
                        const SizedBox(height: 8),
                        ...items.map((item) {
                          final details = _itemQtyWithUnit(item);
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 6),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        item.productName,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: GoogleFonts.plusJakartaSans(
                                          fontSize: 13,
                                          height: 1.2,
                                          fontWeight: FontWeight.w900,
                                          color: const Color(0xFF334155),
                                        ),
                                      ),
                                      if (item.note != null &&
                                          item.note!.trim().isNotEmpty)
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 2),
                                          child: Text(
                                            item.note!.trim(),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: GoogleFonts.plusJakartaSans(
                                              fontSize: 10.5,
                                              fontWeight: FontWeight.w700,
                                              color: const Color(0xFF64748B),
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 10),
                                SizedBox(
                                  width: 86,
                                  child: Text(
                                    details,
                                    maxLines: 1,
                                    textAlign: TextAlign.right,
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.plusJakartaSans(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w900,
                                      color: const Color(0xFF334155),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
                  );
                },
              ),
              if (normalizedStatus != 'Selesai') ...[
                SizedBox(height: isDesktopQueueCard ? 12 : 8),
                Row(
                  children: [
                    if (currentIdx > 0 && !isCompact)
                      IconButton(
                        onPressed: () => handlePreviousStatus(context),
                        icon: const Icon(Icons.arrow_back_ios_new_rounded,
                            size: 14),
                        color: const Color(0xFF94A3B8),
                        style: IconButton.styleFrom(
                          backgroundColor: const Color(0xFFF8FAFC),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                        ),
                      ),
                    if (nextStatus != null)
                      Expanded(
                        child: SizedBox(
                          height: isDesktopQueueCard ? 46 : null,
                          child: ElevatedButton.icon(
                            onPressed: () async {
                              // ── SELESAI: always require confirmation ──────────────
                              if (nextStatus == 'Selesai') {
                                if (!isPaid) {
                                  _showPaymentFlow(context, ref, tx,
                                      nextStatus: nextStatus,
                                      onStatusUpdate: onStatusUpdate);
                                  return;
                                }
                                final pickupDt = effectivePickupAt;
                                final now = DateTime.now();
                                final bool isTooEarly =
                                    pickupDt != null && now.isBefore(pickupDt);
                                final bool? proceed = await showDialog<bool>(
                                  context: context,
                                  builder: (ctx) => _SelesaiConfirmDialog(
                                    tx: tx,
                                    pickupDt: pickupDt,
                                    isTooEarly: isTooEarly,
                                  ),
                                );
                                if (proceed != true) return;
                                onStatusUpdate(nextStatus);
                                return;
                              }

                              // ── SIAP: warn if completing very early (>60 min remaining) ──
                              if (nextStatus == 'Siap') {
                                final pickupDt = effectivePickupAt;
                                Duration? remaining;
                                if (pickupDt != null &&
                                    DateTime.now().isBefore(pickupDt)) {
                                  remaining =
                                      pickupDt.difference(DateTime.now());
                                }

                                final action =
                                    await showDialog<_SiapConfirmAction>(
                                  context: context,
                                  builder: (ctx) => _SiapConfirmDialog(
                                    tx: tx,
                                    pickupDt: pickupDt,
                                    remaining: remaining,
                                  ),
                                );
                                if (action == null) return;
                                if (action ==
                                    _SiapConfirmAction.confirmAndNotify) {
                                  if (!context.mounted) return;
                                  final reminded =
                                      await remindCustomerBeforeReady(context);
                                  if (!reminded) return;
                                }
                                onStatusUpdate(nextStatus);
                                return;
                              }

                              // ── PROSES: confirm before processing ───────────────
                              if (nextStatus == 'Proses') {
                                final bool? proceed = await showDialog<bool>(
                                  context: context,
                                  builder: (ctx) => _ProsesConfirmDialog(
                                    tx: tx,
                                  ),
                                );
                                if (proceed != true) return;
                                onStatusUpdate(nextStatus);
                                return;
                              }

                              // ── Other transitions: proceed directly ───────────────
                              onStatusUpdate(nextStatus);
                            },
                            icon: Icon(_statusIcon(nextStatus),
                                size: isDesktopQueueCard ? 15 : 14),
                            label: Text(nextStatus.toUpperCase(),
                                style: TextStyle(
                                    letterSpacing: 0.5,
                                    fontSize: isDesktopQueueCard ? 12 : 11,
                                    fontWeight: FontWeight.w900)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _statusColor(nextStatus),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              padding: EdgeInsets.symmetric(
                                vertical: isDesktopQueueCard ? 12 : 8,
                              ),
                              minimumSize:
                                  Size.fromHeight(isDesktopQueueCard ? 46 : 36),
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero),
                            ),
                          ),
                        ),
                      ),
                    const SizedBox(width: 8),
                    _ActionBtn(
                      icon: const FaIcon(FontAwesomeIcons.whatsapp, size: 16),
                      color: const Color(0xFF22C55E),
                      onTap: () => launchWhatsApp(context),
                    ),
                  ],
                ),
                if (pickupText != null) ...[
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: isOverdue
                          ? const Color(0xFFFFF1F2)
                          : const Color(0xFFF8FAFC),
                      border: Border.all(
                        color: isOverdue
                            ? const Color(0xFFFECACA)
                            : const Color(0xFFE2E8F0),
                      ),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Row(
                      children: [
                        Icon(
                          isOverdue
                              ? Icons.timer_off_rounded
                              : Icons.calendar_month_outlined,
                          size: 15,
                          color: isOverdue
                              ? const Color(0xFFE11D48)
                              : const Color(0xFF475569),
                        ),
                        const SizedBox(width: 7),
                        Expanded(
                          child: Text(
                            'Est Pengambilan: $pickupText',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 12.5,
                              color: isOverdue
                                  ? const Color(0xFFE11D48)
                                  : const Color(0xFF334155),
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ],
          ),
        ),
      ),
    );
  }

  void _showPaymentFlow(BuildContext context, WidgetRef ref, Transaction tx,
      {String? nextStatus, Function? onStatusUpdate, bool isOnlyPay = false}) {
    final isDesktop = MediaQuery.of(context).size.width > 900;

    final dialog = _UnpaidPaymentDialog(
      tx: tx,
      isOnlyPay: isOnlyPay,
      onPayAndFinish: (paymentMethod) async {
        if (isOnlyPay) {
          await ref.read(transactionsProvider.notifier).markAsPaidOnly(
                txId: tx.id!,
                grandTotal: tx.grandTotal,
                paymentMethod: paymentMethod,
              );
        } else {
          await ref.read(transactionsProvider.notifier).markAsPaidAndFinish(
                txId: tx.id!,
                grandTotal: tx.grandTotal,
                paymentMethod: paymentMethod,
                kelengkapan: tx.kelengkapan,
              );
        }
      },
    );

    if (isDesktop) {
      showDialog(
        context: context,
        builder: (ctx) => Dialog(
          backgroundColor: Colors.white,
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 40, vertical: 24),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: dialog,
          ),
        ),
      );
    } else {
      showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: true,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.zero)),
        builder: (_) => dialog,
      );
    }
  }
}

class _ActionBtn extends StatelessWidget {
  final Widget icon;
  final Color color;
  final VoidCallback onTap;

  const _ActionBtn(
      {required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 36,
      width: 36,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color.withValues(alpha: 0.1),
          foregroundColor: color,
          elevation: 0,
          padding: EdgeInsets.zero,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
        child: icon,
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  final IconData icon;
  final bool solid;

  const _StatusBadge({
    required this.label,
    required this.color,
    required this.icon,
    this.solid = false,
  });

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 136),
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: solid ? 9 : 8,
          vertical: solid ? 6 : 5,
        ),
        decoration: BoxDecoration(
          color: solid ? color : color.withValues(alpha: 0.045),
          borderRadius: BorderRadius.circular(4),
          border: Border.all(
            color: solid ? color : color.withValues(alpha: 0.13),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: solid ? 13 : 12,
              color: solid ? Colors.white : color.withValues(alpha: 0.92),
            ),
            const SizedBox(width: 5),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w900,
                  color: solid ? Colors.white : color,
                  letterSpacing: 0,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CompactBadge extends StatelessWidget {
  final String label;
  final Color color;
  final IconData? icon;
  final bool solid;

  const _CompactBadge({
    required this.label,
    required this.color,
    this.icon,
    this.solid = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: solid ? 8 : 7,
        vertical: solid ? 5 : 4,
      ),
      decoration: BoxDecoration(
        color: solid ? color : color.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(
          color: solid ? color : color.withValues(alpha: 0.12),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon,
                size: solid ? 12 : 11, color: solid ? Colors.white : color),
            const SizedBox(width: 4),
          ],
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 86),
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 10,
                fontWeight: FontWeight.w900,
                color: solid ? Colors.white : color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// UNPAID PAYMENT DIALOG

class _UnpaidPaymentDialog extends StatefulWidget {
  final Transaction tx;
  final Function(String paymentMethod) onPayAndFinish;
  final bool isOnlyPay;

  const _UnpaidPaymentDialog({
    required this.tx,
    required this.onPayAndFinish,
    this.isOnlyPay = false,
  });

  @override
  State<_UnpaidPaymentDialog> createState() => _UnpaidPaymentDialogState();
}

class _UnpaidPaymentDialogState extends State<_UnpaidPaymentDialog> {
  String _selectedMethod = 'cash';
  String _selectedNonCash = 'qris';
  bool _loading = false;
  bool _loadingSettings = true;
  Map<String, dynamic>? _paymentSettings;
  late final TextEditingController _cashCtrl;

  int get _remainingAmount => (widget.tx.grandTotal - widget.tx.amountPaid)
      .clamp(0, widget.tx.grandTotal)
      .toInt();

  int get _cashReceived =>
      int.tryParse(_cashCtrl.text.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;

  int get _change =>
      (_cashReceived - _remainingAmount).clamp(0, 1 << 31).toInt();

  @override
  void initState() {
    super.initState();
    _cashCtrl = TextEditingController();
    _loadPaymentSettings();
  }

  @override
  void dispose() {
    _cashCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadPaymentSettings() async {
    final settings = await DBHelper.instance.getPaymentSettings();
    if (!mounted) return;
    setState(() {
      _paymentSettings = settings;
      _loadingSettings = false;
    });
  }

  String _fRp(int n) {
    if (n == 0) return 'Rp0';
    String s = n.toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return 'Rp$r';
  }

  Future<void> _handlePayAndFinish() async {
    if (_selectedMethod == 'cash' && _cashReceived < _remainingAmount) {
      ModernSnackBar.error(
        context: context,
        message: 'Nominal tunai masih kurang dari sisa tagihan.',
      );
      return;
    }
    if (_selectedMethod != 'cash' &&
        ((_selectedNonCash == 'qris' && _qrisFile == null) ||
            (_selectedNonCash == 'transfer' && _banks.isEmpty))) {
      ModernSnackBar.error(
        context: context,
        message: 'Pilih metode non-tunai yang sudah dikonfigurasi.',
      );
      return;
    }
    setState(() => _loading = true);
    try {
      await widget.onPayAndFinish(
        _selectedMethod == 'cash' ? 'cash' : _selectedNonCash,
      );
      if (mounted) {
        Navigator.pop(context);
        ModernSnackBar.success(
          context: context,
          message: widget.isOnlyPay
              ? 'Pembayaran berhasil disimpan.'
              : 'Pembayaran berhasil. Pesanan selesai!',
        );
      }
    } catch (e) {
      if (mounted) {
        ModernSnackBar.error(
          context: context,
          message: 'Gagal memproses pembayaran.',
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _handleCancel() {
    Navigator.pop(context);
  }

  int _roundUp(int value, int denomination) =>
      ((value + denomination - 1) ~/ denomination) * denomination;

  List<Map<String, String>> get _banks {
    final settings = _paymentSettings;
    if (settings == null) return const [];
    final result = <Map<String, String>>[];
    final raw = settings['banks_json']?.toString() ?? '';
    if (raw.isNotEmpty) {
      try {
        final decoded = jsonDecode(raw) as List;
        for (final item in decoded) {
          final bank = Map<String, dynamic>.from(item as Map);
          result.add({
            'name': bank['name']?.toString() ?? '',
            'account_name': bank['account_name']?.toString() ?? '',
            'account_number': bank['account_number']?.toString() ?? '',
          });
        }
      } catch (_) {}
    }
    if (result.isEmpty) {
      final number = settings['account_number']?.toString() ?? '';
      if (number.isNotEmpty) {
        result.add({
          'name': settings['bank_name']?.toString() ?? '',
          'account_name': settings['account_name']?.toString() ?? '',
          'account_number': number,
        });
      }
    }
    return result;
  }

  File? get _qrisFile {
    final path = _paymentSettings?['qris_path']?.toString() ?? '';
    if (path.isEmpty) return null;
    final file = File(path);
    return file.existsSync() ? file : null;
  }

  Widget _buildCashDetails(int amount) {
    final suggestions = <int>{
      amount,
      _roundUp(amount, 10000),
      _roundUp(amount, 50000),
      _roundUp(amount, 100000),
    }.toList()
      ..sort();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _cashCtrl,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(
            labelText: 'Uang Diterima',
            prefixText: 'Rp ',
            border: OutlineInputBorder(borderRadius: BorderRadius.zero),
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: suggestions.map((value) {
            final exact = value == amount;
            return ActionChip(
              label: Text(exact ? 'Uang Pas' : _fRp(value)),
              avatar: exact ? const Icon(Icons.check_rounded, size: 16) : null,
              onPressed: () {
                _cashCtrl.text = '$value';
                setState(() {});
              },
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            );
          }).toList(),
        ),
        if (_cashReceived >= amount) ...[
          const SizedBox(height: 10),
          _PaymentInfoRow(label: 'Kembalian', value: _fRp(_change)),
        ],
      ],
    );
  }

  Widget _buildNonCashDetails(int amount) {
    if (_loadingSettings) {
      return const Center(child: CircularProgressIndicator(strokeWidth: 2));
    }
    final hasQris = _qrisFile != null;
    final hasBanks = _banks.isNotEmpty;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: _NonCashOption(
                label: 'QRIS',
                icon: Icons.qr_code_rounded,
                selected: _selectedNonCash == 'qris',
                enabled: hasQris,
                onTap: () => setState(() => _selectedNonCash = 'qris'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _NonCashOption(
                label: 'Transfer Bank',
                icon: Icons.account_balance_rounded,
                selected: _selectedNonCash == 'transfer',
                enabled: hasBanks,
                onTap: () => setState(() => _selectedNonCash = 'transfer'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: (_selectedNonCash == 'qris' ? hasQris : hasBanks)
                ? () => _showNonCashDetails(amount)
                : null,
            icon: Icon(_selectedNonCash == 'qris'
                ? Icons.qr_code_2_rounded
                : Icons.account_balance_rounded),
            label: Text(_selectedNonCash == 'qris'
                ? 'Lihat QRIS Pembayaran'
                : 'Lihat Rekening Bank'),
            style: OutlinedButton.styleFrom(
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              padding: const EdgeInsets.symmetric(vertical: 13),
            ),
          ),
        ),
        if (!hasQris && !hasBanks)
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text(
              'QRIS dan rekening bank belum diatur di Pengaturan Pembayaran.',
              style: TextStyle(fontSize: 11, color: AppColors.danger),
            ),
          ),
      ],
    );
  }

  Future<void> _showNonCashDetails(int amount) async {
    final showQris = _selectedNonCash == 'qris';
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: Text(showQris ? 'Scan QRIS' : 'Transfer Bank'),
        content: SizedBox(
          width: 420,
          child: SingleChildScrollView(
            child: Column(
              children: [
                _PaymentInfoRow(label: 'Total Pembayaran', value: _fRp(amount)),
                const SizedBox(height: 14),
                if (showQris)
                  Image.file(_qrisFile!, height: 260, fit: BoxFit.contain)
                else
                  ..._banks.map((bank) => _BankPaymentCard(bank: bank)),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final grandTotal = _remainingAmount;
    final customerName = widget.tx.customerName ?? 'Pelanggan';

    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle bar
            const SizedBox(height: 12),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                  color: Colors.grey[300], borderRadius: BorderRadius.zero),
            ),
            const SizedBox(height: 20),
            // Warning header
            Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF7ED),
                border: Border.all(color: const Color(0xFFFED7AA)),
                borderRadius: BorderRadius.zero,
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: const BoxDecoration(
                      color: Color(0xFFF97316),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.warning_amber_rounded,
                        color: Colors.white, size: 20),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                            widget.isOnlyPay
                                ? 'Bayar Tagihan'
                                : 'Bayar Sebelum Selesai',
                            style: GoogleFonts.plusJakartaSans(
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                color: const Color(0xFF92400E))),
                        const SizedBox(height: 2),
                        Text(
                            widget.isOnlyPay
                                ? '$customerName belum membayar ${_fRp(grandTotal)}'
                                : 'Pilih pembayaran untuk menandai selesai.',
                            style: GoogleFonts.plusJakartaSans(
                                fontSize: 12, color: const Color(0xFFB45309))),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Total tagihan
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Total Tagihan',
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 13,
                          color: const Color(0xFF64748B),
                          fontWeight: FontWeight.w600)),
                  Text(_fRp(grandTotal),
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          color: AppColors.primaryBrand)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Divider(height: 1),
            ),
            const SizedBox(height: 16),
            // Payment method
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Pilih Metode Pembayaran',
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: const Color(0xFF64748B),
                          letterSpacing: 0.5)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      _PayMethodChip(
                        label: 'Tunai',
                        icon: Icons.money_rounded,
                        value: 'cash',
                        selected: _selectedMethod == 'cash',
                        onTap: () => setState(() => _selectedMethod = 'cash'),
                      ),
                      const SizedBox(width: 10),
                      _PayMethodChip(
                        label: 'Non Tunai',
                        icon: Icons.account_balance_wallet_rounded,
                        value: 'transfer',
                        selected: _selectedMethod == 'transfer',
                        onTap: () => setState(() {
                          _selectedMethod = 'transfer';
                          if (_qrisFile == null && _banks.isNotEmpty) {
                            _selectedNonCash = 'transfer';
                          }
                        }),
                      ),
                    ],
                  ),
                  if (_selectedMethod == 'cash') ...[
                    const SizedBox(height: 14),
                    _buildCashDetails(grandTotal),
                  ] else ...[
                    const SizedBox(height: 14),
                    _buildNonCashDetails(grandTotal),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Buttons
            Padding(
              padding: EdgeInsets.fromLTRB(
                  20, 0, 20, MediaQuery.of(context).padding.bottom + 16),
              child: Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _loading ? null : _handlePayAndFinish,
                      icon: _loading
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : const Icon(Icons.payments_rounded, size: 18),
                      label: Text(
                        _loading
                            ? 'Memproses...'
                            : (widget.isOnlyPay
                                ? 'SIMPAN PEMBAYARAN - ${_fRp(grandTotal)}'
                                : 'BAYAR & TANDAI SELESAI - ${_fRp(grandTotal)}'),
                        style: GoogleFonts.plusJakartaSans(
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            letterSpacing: 0.3),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: _loading ? null : _handleCancel,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF64748B),
                        side: const BorderSide(color: Color(0xFFE2E8F0)),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: Text('Batalkan',
                          style: GoogleFonts.plusJakartaSans(
                              fontWeight: FontWeight.w700, fontSize: 12)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PayMethodChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final String value;
  final bool selected;
  final VoidCallback onTap;

  const _PayMethodChip({
    required this.label,
    required this.icon,
    required this.value,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected
                ? AppColors.primaryBrand
                : AppColors.primaryBrand.withValues(alpha: 0.05),
            borderRadius: BorderRadius.zero,
            border: Border.all(
              color: selected
                  ? AppColors.primaryBrand
                  : AppColors.primaryBrand.withValues(alpha: 0.15),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon,
                  color: selected ? Colors.white : AppColors.primaryBrand,
                  size: 20),
              const SizedBox(height: 4),
              Text(label,
                  style: GoogleFonts.plusJakartaSans(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: selected ? Colors.white : AppColors.primaryBrand)),
            ],
          ),
        ),
      ),
    );
  }
}

class _NonCashOption extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final bool enabled;
  final VoidCallback onTap;

  const _NonCashOption({
    required this.label,
    required this.icon,
    required this.selected,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: enabled ? onTap : null,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFEFF6FF) : Colors.white,
          border: Border.all(
            color: selected ? AppColors.primaryBrand : const Color(0xFFE2E8F0),
          ),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                size: 17,
                color:
                    enabled ? AppColors.primaryBrand : const Color(0xFFCBD5E1)),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  color: enabled
                      ? const Color(0xFF334155)
                      : const Color(0xFF94A3B8),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PaymentInfoRow extends StatelessWidget {
  final String label;
  final String value;

  const _PaymentInfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      color: const Color(0xFFF8FAFC),
      child: Row(
        children: [
          Expanded(
            child: Text(label,
                style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF64748B))),
          ),
          Text(value,
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  color: AppColors.primaryBrand)),
        ],
      ),
    );
  }
}

class _BankPaymentCard extends StatelessWidget {
  final Map<String, String> bank;

  const _BankPaymentCard({required this.bank});

  @override
  Widget build(BuildContext context) {
    final number = bank['account_number'] ?? '-';
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(bank['name'] ?? '-',
              style:
                  const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          const SizedBox(height: 6),
          SelectableText(number,
              style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 19,
                  color: AppColors.primaryBrand)),
          Text('a.n. ${bank['account_name'] ?? '-'}',
              style: const TextStyle(fontSize: 12, color: Color(0xFF64748B))),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: number == '-'
                ? null
                : () {
                    Clipboard.setData(ClipboardData(text: number));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Nomor rekening disalin')),
                    );
                  },
            icon: const Icon(Icons.copy_rounded, size: 15),
            label: const Text('Salin Nomor Rekening'),
          ),
        ],
      ),
    );
  }
}

void _showOrderDetails(BuildContext context, WidgetRef ref, Transaction tx) {
  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.white,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.zero),
    ),
    builder: (context) => _OrderDetailSheet(tx: tx),
  );
}

class _OrderDetailSheet extends ConsumerWidget {
  final Transaction tx;
  const _OrderDetailSheet({required this.tx});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final noTrx = TransactionCodeFormatter.format(
      id: tx.id ?? 0,
      createdAt: tx.createdAt,
      transactionCode: tx.transactionCode,
    );

    void launchWhatsApp(BuildContext context) async {
      final customers = ref.read(customersProvider);
      final customer = tx.customerId != null
          ? customers.firstWhere((c) => c.id == tx.customerId,
              orElse: () => Customer(name: tx.customerName ?? ''))
          : null;

      String phone = customer?.phone?.trim() ?? '';
      if (phone.isEmpty && tx.customerId != null) {
        final savedCustomer =
            await DBHelper.instance.getCustomerById(tx.customerId!);
        phone = savedCustomer?.phone?.trim() ?? '';
      }
      if (!context.mounted) return;
      if (phone.isEmpty) {
        ModernSnackBar.error(
          context: context,
          message: 'Nomor HP pelanggan tidak ditemukan',
        );
        return;
      }

      final isPaid = tx.amountPaid >= tx.grandTotal;
      final statusBayar = isPaid ? 'LUNAS' : 'BELUM LUNAS';

      String? pickupText;
      final effectivePickupAt = _effectivePickupAt(tx);
      if (effectivePickupAt != null) {
        pickupText =
            DateFormat('EEE, dd MMM HH:mm', 'id').format(effectivePickupAt);
      } else if (tx.pickupSchedule != null && tx.pickupSchedule!.isNotEmpty) {
        pickupText = tx.pickupSchedule;
      }

      final pickupLine = _pickupLineForWhatsApp(pickupText, tx.servisStatus);
      final msg = '''Halo Kak ${tx.customerName ?? ''} 👋,

Terima kasih telah mempercayakan perbaikan perangkat Anda kepada kami.
Berikut ini adalah rincian pesanan servis Anda:

🧾 *No. Invoice:* $noTrx
🏷️ *Status Servis:* ${tx.servisStatus}
💳 *Status Pembayaran:* $statusBayar
${_totalTagihanLineForWhatsApp(isPaid: isPaid, grandTotal: tx.grandTotal)}${tx.kelengkapan != null && tx.kelengkapan!.isNotEmpty ? '🌸 *Parfum:* ${tx.kelengkapan}\n' : ''}$pickupLine
Untuk mengecek status pesanan atau jika ada pertanyaan lebih lanjut, jangan ragu untuk membalas pesan ini. Kami akan dengan senang hati membantu Anda.

Terima kasih dan semoga hari Kakak menyenangkan! ✨''';
      final opened = await WhatsAppHelper.sendMessage(
        message: msg,
        phone: phone,
      );
      if (!opened && context.mounted) {
        ModernSnackBar.error(
          context: context,
          message: 'WhatsApp tidak bisa dibuka',
        );
      }
    }

    return DraggableScrollableSheet(
      initialChildSize: 0.75,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        final serviceBadgeLabel = _transactionServiceBadgeLabel(tx);
        final fulfillmentBadgeLabel =
            _resolveFulfillmentBadge(tx.fulfillmentType, tx.orderType);
        final bool isPriority = serviceBadgeLabel != null;
        final Color priorityColor =
            isPriority ? _priorityBadgeColor : _fulfillmentBadgeColor;

        return Column(
          children: [
            const SizedBox(height: 12),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.zero,
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Detail Pesanan',
                            style: GoogleFonts.inter(
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                                color: const Color(0xFF1E293B))),
                        const SizedBox(height: 3),
                        Text(noTrx,
                            style: GoogleFonts.jetBrainsMono(
                                fontSize: 13.5,
                                fontWeight: FontWeight.w700,
                                color: const Color(0xFF94A3B8))),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => launchWhatsApp(context),
                    icon: const FaIcon(FontAwesomeIcons.whatsapp),
                    iconSize: 26,
                    color: const Color(0xFF25D366),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close_rounded),
                    iconSize: 30,
                    color: const Color(0xFF64748B),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        tx.customerName ?? 'Pelanggan Umum',
                        style: GoogleFonts.inter(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: const Color(0xFF0F172A)),
                      ),
                      if (serviceBadgeLabel != null ||
                          fulfillmentBadgeLabel != null)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: isPriority
                                ? priorityColor
                                : priorityColor.withValues(alpha: 0.05),
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(
                              color: isPriority
                                  ? priorityColor
                                  : priorityColor.withValues(alpha: 0.12),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (isPriority) ...[
                                const Icon(Icons.bolt_rounded,
                                    size: 14, color: Colors.white),
                                const SizedBox(width: 4),
                              ],
                              Text(
                                serviceBadgeLabel ?? fulfillmentBadgeLabel!,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w900,
                                  color:
                                      isPriority ? Colors.white : priorityColor,
                                  letterSpacing: 0,
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                  if (tx.address != null && tx.address!.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.location_on_outlined,
                            size: 14, color: Color(0xFF64748B)),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            tx.address!,
                            style: GoogleFonts.inter(
                              fontSize: 14.5,
                              fontWeight: FontWeight.w600,
                              color: const Color(0xFF64748B),
                              height: 1.35,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
            const Divider(height: 1),
            const SizedBox(height: 4),
            Expanded(
              child: FutureBuilder<List<TransactionItem>>(
                future: DBHelper.instance.getTransactionItems(tx.id ?? 0),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  }
                  final items = snapshot.data ?? [];
                  if (items.isEmpty) {
                    return const Center(
                        child: Text('Tidak ada item ditemukan'));
                  }

                  return ListView.separated(
                    controller: scrollController,
                    padding: const EdgeInsets.fromLTRB(22, 22, 22, 24),
                    itemCount: items.length,
                    separatorBuilder: (context, index) =>
                        const Divider(height: 28),
                    itemBuilder: (context, index) {
                      final item = items[index];
                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 46,
                            height: 42,
                            decoration: BoxDecoration(
                              color: _kBrand.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Center(
                              child: Text(
                                _itemQtyCompactLabel(item),
                                style: GoogleFonts.inter(
                                  fontSize:
                                      item.unit != null && item.unit!.isNotEmpty
                                          ? 12
                                          : 14,
                                  fontWeight: FontWeight.w900,
                                  color: _kBrand,
                                  height: 1.1,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item.productName,
                                  style: GoogleFonts.inter(
                                    fontSize: 16.5,
                                    fontWeight: FontWeight.w800,
                                    color: const Color(0xFF1E293B),
                                    height: 1.25,
                                  ),
                                ),
                                if (item.note != null && item.note!.isNotEmpty)
                                  Text(
                                    item.note!,
                                    style: GoogleFonts.inter(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: const Color(0xFF64748B),
                                      height: 1.35,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            _fRp(item.subtotal),
                            style: GoogleFonts.inter(
                              fontSize: 17,
                              fontWeight: FontWeight.w900,
                              color: const Color(0xFF1E293B),
                            ),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 22),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Total Tagihan',
                      style: GoogleFonts.inter(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: const Color(0xFF64748B))),
                  Text(_fRp(tx.grandTotal),
                      style: GoogleFonts.inter(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: _kBrand)),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

// EMPTY STATE

class _EmptyState extends StatelessWidget {
  final String filter;
  const _EmptyState({required this.filter});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _kBrand.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.handyman_outlined,
                size: 48, color: _kBrand.withValues(alpha: 0.5)),
          ),
          const SizedBox(height: 16),
          Text(
            filter == 'Semua'
                ? 'Belum Ada Pesanan'
                : 'Tidak ada pesanan "$filter"',
            textAlign: TextAlign.center,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF334155)),
          ),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Text(
              filter == 'Semua'
                  ? 'Pesanan servis akan tampil di sini'
                  : 'Semua pesanan di status ini sudah selesai',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 13, color: Color(0xFF94A3B8), height: 1.4),
            ),
          ),
        ],
      ),
    );
  }
}

// EARLY COMPLETION DIALOG HELPER
String _formatDuration(Duration d) {
  if (d.inDays > 0) {
    return '${d.inDays} Hari ${d.inHours % 24} Jam';
  } else if (d.inHours > 0) {
    return '${d.inHours} Jam ${d.inMinutes % 60} Menit';
  } else {
    return '${d.inMinutes} Menit';
  }
}

class _ProsesConfirmDialog extends StatelessWidget {
  final Transaction tx;

  const _ProsesConfirmDialog({
    required this.tx,
  });

  @override
  Widget build(BuildContext context) {
    final isWideDialog = MediaQuery.sizeOf(context).width >= 700;
    final customerName = tx.customerName ?? 'Pelanggan Umum';
    final isUnpaid = tx.amountPaid < tx.grandTotal;
    final fulfillment =
        _resolveFulfillmentBadge(tx.fulfillmentType, tx.orderType);
    final requiresPickupConfirmation =
        isUnpaid && fulfillment == 'Antar/Jemput';
    final invoice = TransactionCodeFormatter.format(
      id: tx.id ?? 0,
      createdAt: tx.createdAt,
      transactionCode: tx.transactionCode,
    );

    return Dialog(
      insetPadding: EdgeInsets.symmetric(
        horizontal: isWideDialog ? 40 : 18,
        vertical: 24,
      ),
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: isWideDialog ? 600 : 480),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              color: const Color(0xFFEFF6FF),
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(11),
                    decoration: const BoxDecoration(
                      color: _kBrand,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.handyman_outlined,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          requiresPickupConfirmation
                              ? 'Konfirmasi servis telah dijemput'
                              : 'Mulai proses servis?',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                            color: const Color(0xFF1E40AF),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          requiresPickupConfirmation
                              ? 'Pastikan pesanan sudah diterima sebelum diproses'
                              : 'Pesanan akan pindah ke tab Proses',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFF2563EB),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    requiresPickupConfirmation
                        ? 'Apakah servis milik "$customerName" sudah dijemput, diterima di tempat usaha, dan siap masuk proses?'
                        : 'Apakah Anda yakin ingin memproses servis milik "$customerName"?',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF475569),
                      height: 1.45,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8FAFC),
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Column(
                      children: [
                        _buildGridRow('Pelanggan', customerName),
                        const Divider(height: 1, color: Color(0xFFE2E8F0)),
                        _buildGridRow('No. Invoice', invoice),
                        const Divider(height: 1, color: Color(0xFFE2E8F0)),
                        if (requiresPickupConfirmation) ...[
                          _buildGridRow('Penyerahan', 'Antar/Jemput'),
                          const Divider(height: 1, color: Color(0xFFE2E8F0)),
                          _buildGridRow('Pembayaran', 'Belum Lunas'),
                          const Divider(height: 1, color: Color(0xFFE2E8F0)),
                        ],
                        _buildGridRow(
                          'Estimasi Selesai',
                          tx.pickupSchedule != null &&
                                  tx.pickupSchedule!.isNotEmpty
                              ? tx.pickupSchedule!
                              : '-',
                        ),
                      ],
                    ),
                  ),
                  if (requiresPickupConfirmation) ...[
                    const SizedBox(height: 14),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFFBEB),
                        border: Border.all(color: const Color(0xFFFDE68A)),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            Icons.info_outline_rounded,
                            size: 18,
                            color: Color(0xFFB45309),
                          ),
                          const SizedBox(width: 9),
                          Expanded(
                            child: Text(
                              'Jangan mulai proses jika servis belum selesai dijemput atau belum diterima oleh petugas.',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 12,
                                height: 1.4,
                                fontWeight: FontWeight.w700,
                                color: const Color(0xFF92400E),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(context, false),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFF64748B),
                            side: const BorderSide(color: Color(0xFFCBD5E1)),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: Text(
                            'Batal',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        flex: 2,
                        child: ElevatedButton.icon(
                          onPressed: () => Navigator.pop(context, true),
                          icon: const Icon(Icons.play_arrow_rounded, size: 18),
                          label: Text(
                            requiresPickupConfirmation
                                ? 'Sudah Dijemput'
                                : 'Ya, Proses',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _kBrand,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGridRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF64748B),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                fontWeight: FontWeight.w800,
                color: const Color(0xFF1E293B),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

Future<bool> _showWhatsAppFallbackDialog(
  BuildContext context, {
  required String message,
  required String reason,
}) async {
  final shareManually = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (ctx) => AlertDialog(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      title: const Row(
        children: [
          Icon(Icons.warning_amber_rounded, color: Color(0xFFD97706)),
          SizedBox(width: 10),
          Expanded(child: Text('WhatsApp Tidak Terhubung')),
        ],
      ),
      content: Text(
        '$reason\n\nBagikan pesan secara manual, lalu pilih kontak pelanggan di WhatsApp.',
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('Batal'),
        ),
        ElevatedButton.icon(
          onPressed: () => Navigator.pop(ctx, true),
          icon: const Icon(Icons.share_rounded, size: 18),
          label: const Text('Bagikan Manual'),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF16A34A),
            foregroundColor: Colors.white,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        ),
      ],
    ),
  );
  if (shareManually != true || !context.mounted) return false;

  await SharePlus.instance.share(ShareParams(text: message));
  if (!context.mounted) return false;
  final result = await showDialog<_ReminderConfirmAction>(
    context: context,
    barrierDismissible: false,
    builder: (_) => const _ReminderSentConfirmDialog(manualMode: true),
  );
  return result == _ReminderConfirmAction.sent;
}

class _ReminderSentConfirmDialog extends StatelessWidget {
  final bool manualMode;

  const _ReminderSentConfirmDialog({this.manualMode = false});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      title: const Row(
        children: [
          FaIcon(FontAwesomeIcons.whatsapp, size: 22, color: Color(0xFF16A34A)),
          SizedBox(width: 12),
          Expanded(child: Text('Pengingat Sudah Dikirim?')),
        ],
      ),
      content: Text(
        manualMode
            ? 'Pastikan pesan sudah dibagikan dan dikirim ke pelanggan sebelum memindahkan pesanan ke tab Siap.'
            : 'Pastikan pesan WhatsApp benar-benar sudah dikirim ke pelanggan. Pesanan baru akan dipindahkan ke tab Siap setelah dikonfirmasi.',
      ),
      actions: [
        TextButton(
          onPressed: () =>
              Navigator.pop(context, _ReminderConfirmAction.cancel),
          child: const Text('Belum'),
        ),
        if (!manualMode)
          TextButton(
            onPressed: () =>
                Navigator.pop(context, _ReminderConfirmAction.shareManually),
            child: const Text('Nomor Salah / Bagikan Manual'),
          ),
        if (!manualMode)
          OutlinedButton(
            onPressed: () =>
                Navigator.pop(context, _ReminderConfirmAction.openAgain),
            child: const Text('Buka WhatsApp Lagi'),
          ),
        ElevatedButton.icon(
          onPressed: () => Navigator.pop(context, _ReminderConfirmAction.sent),
          icon: const Icon(Icons.check_rounded, size: 18),
          label: const Text('Sudah Dikirim'),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF16A34A),
            foregroundColor: Colors.white,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        ),
      ],
    );
  }
}

// ─── SELESAI CONFIRMATION DIALOG ───────────────────────────────────────────

class _SiapConfirmDialog extends StatelessWidget {
  final Transaction tx;
  final DateTime? pickupDt;
  final Duration? remaining;

  const _SiapConfirmDialog({
    required this.tx,
    required this.pickupDt,
    required this.remaining,
  });

  @override
  Widget build(BuildContext context) {
    final isWideDialog = MediaQuery.sizeOf(context).width >= 700;
    final customerName = tx.customerName ?? 'Pelanggan Umum';
    final invoice = TransactionCodeFormatter.format(
      id: tx.id ?? 0,
      createdAt: tx.createdAt,
      transactionCode: tx.transactionCode,
    );
    final pickupFormatted = pickupDt != null
        ? DateFormat('EEEE, dd MMMM yyyy HH:mm', 'id').format(pickupDt!)
        : null;
    final remainingText = remaining != null && remaining!.inMinutes > 0
        ? _formatDuration(remaining!)
        : null;

    return Dialog(
      insetPadding: EdgeInsets.symmetric(
        horizontal: isWideDialog ? 40 : 18,
        vertical: 24,
      ),
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: isWideDialog ? 780 : 520),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                color: const Color(0xFFEFF6FF),
                padding:
                    const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(11),
                      decoration: const BoxDecoration(
                        color: _kBrand,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.inventory_2_outlined,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Servis sudah siap diambil?',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: const Color(0xFF1E40AF),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Pesanan akan pindah ke tab Siap',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w700,
                              color: const Color(0xFF2563EB),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              if (isWideDialog)
                _buildDesktopContent(
                  context,
                  customerName,
                  invoice,
                  pickupFormatted,
                  remainingText,
                )
              else
                _buildMobileContent(
                  context,
                  customerName,
                  invoice,
                  pickupFormatted,
                  remainingText,
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDesktopContent(
    BuildContext context,
    String customerName,
    String invoice,
    String? pickupFormatted,
    String? remainingText,
  ) {
    return Padding(
      padding: const EdgeInsets.all(28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 5,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Pastikan servis milik $customerName sudah selesai diproses, dikemas, dan siap diserahkan ke pelanggan.',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 15,
                        height: 1.55,
                        fontWeight: FontWeight.w800,
                        color: const Color(0xFF334155),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Container(
                      padding: const EdgeInsets.all(16),
                      color: const Color(0xFFECFDF5),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const FaIcon(FontAwesomeIcons.whatsapp,
                              size: 18, color: Color(0xFF16A34A)),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'Gunakan tombol hijau jika ingin langsung membuka WhatsApp untuk memberi tahu pelanggan.',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 13.5,
                                height: 1.45,
                                fontWeight: FontWeight.w800,
                                color: const Color(0xFF166534),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 24),
              Expanded(
                flex: 6,
                child: _buildSummaryBox(
                  customerName,
                  invoice,
                  pickupFormatted,
                  remainingText,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              SizedBox(
                width: 150,
                height: 48,
                child: _buildCancelButton(context),
              ),
              const Spacer(),
              SizedBox(
                width: 150,
                height: 48,
                child: _buildReadyButton(context),
              ),
              const SizedBox(width: 10),
              SizedBox(
                width: 260,
                height: 48,
                child: _buildReadyAndNotifyButton(context),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMobileContent(
    BuildContext context,
    String customerName,
    String invoice,
    String? pickupFormatted,
    String? remainingText,
  ) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Pastikan servis milik $customerName sudah selesai diproses, dikemas, dan siap diserahkan ke pelanggan.',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14.5,
              height: 1.5,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF334155),
            ),
          ),
          const SizedBox(height: 16),
          _buildSummaryBox(
              customerName, invoice, pickupFormatted, remainingText),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            color: const Color(0xFFECFDF5),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const FaIcon(FontAwesomeIcons.whatsapp,
                    size: 17, color: Color(0xFF16A34A)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Pilih "Siap + Ingatkan" untuk membuka WhatsApp dan memberi tahu pelanggan bahwa servis sudah siap diambil.',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      height: 1.45,
                      fontWeight: FontWeight.w800,
                      color: const Color(0xFF166534),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(child: _buildCancelButton(context)),
              const SizedBox(width: 8),
              Expanded(child: _buildReadyButton(context)),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: _buildReadyAndNotifyButton(context),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryBox(
    String customerName,
    String invoice,
    String? pickupFormatted,
    String? remainingText,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        children: [
          _buildGridRow('Pelanggan', customerName),
          const Divider(height: 1, color: Color(0xFFE2E8F0)),
          _buildGridRow('No. Invoice', invoice),
          if (pickupFormatted != null) ...[
            const Divider(height: 1, color: Color(0xFFE2E8F0)),
            _buildGridRow('Estimasi Ambil', pickupFormatted),
          ],
          if (remainingText != null) ...[
            const Divider(height: 1, color: Color(0xFFE2E8F0)),
            _buildGridRow(
              'Lebih Cepat',
              remainingText,
              fgColor: const Color(0xFFEA580C),
              isBold: true,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildCancelButton(BuildContext context) {
    return OutlinedButton(
      onPressed: () => Navigator.pop(context),
      style: OutlinedButton.styleFrom(
        foregroundColor: const Color(0xFF64748B),
        side: const BorderSide(color: Color(0xFFCBD5E1)),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        padding: const EdgeInsets.symmetric(vertical: 14),
      ),
      child: Text(
        'Batal',
        style: GoogleFonts.plusJakartaSans(
            fontSize: 14, fontWeight: FontWeight.w800),
      ),
    );
  }

  Widget _buildReadyButton(BuildContext context) {
    return ElevatedButton(
      onPressed: () => Navigator.pop(context, _SiapConfirmAction.confirm),
      style: ElevatedButton.styleFrom(
        backgroundColor: _kBrand,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        padding: const EdgeInsets.symmetric(vertical: 14),
      ),
      child: Text(
        'Siap',
        style: GoogleFonts.plusJakartaSans(
            fontSize: 14, fontWeight: FontWeight.w900),
      ),
    );
  }

  Widget _buildReadyAndNotifyButton(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: () =>
          Navigator.pop(context, _SiapConfirmAction.confirmAndNotify),
      icon: const FaIcon(FontAwesomeIcons.whatsapp, size: 17),
      label: Text(
        'Siap + Ingatkan Pelanggan',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: GoogleFonts.plusJakartaSans(
            fontSize: 14, fontWeight: FontWeight.w900),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF16A34A),
        foregroundColor: Colors.white,
        elevation: 0,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 14),
      ),
    );
  }

  Widget _buildGridRow(String label, String value,
      {Color? fgColor, bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF64748B),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13.5,
                fontWeight: isBold ? FontWeight.w900 : FontWeight.w800,
                color: fgColor ?? const Color(0xFF0F172A),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SelesaiConfirmDialog extends StatelessWidget {
  final Transaction tx;
  final DateTime? pickupDt;
  final bool isTooEarly;

  const _SelesaiConfirmDialog({
    required this.tx,
    required this.pickupDt,
    required this.isTooEarly,
  });

  @override
  Widget build(BuildContext context) {
    final pickupFormatted = pickupDt != null
        ? DateFormat('EEEE, dd MMMM yyyy HH:mm', 'id').format(pickupDt!)
        : null;
    final now = DateTime.now();
    final Duration? remaining =
        (isTooEarly && pickupDt != null) ? pickupDt!.difference(now) : null;
    final String? sisaStr =
        remaining != null ? _formatDuration(remaining) : null;
    final serviceBadgeLabel = _transactionServiceBadgeLabel(tx);
    final fulfillmentBadgeLabel =
        _resolveFulfillmentBadge(tx.fulfillmentType, tx.orderType);
    final isWideDialog = MediaQuery.sizeOf(context).width >= 700;

    final earlyWarningBox = isTooEarly
        ? Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF7F7),
              border: Border.all(color: const Color(0xFFFECACA)),
              borderRadius: BorderRadius.zero,
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.info_outline_rounded,
                    size: 19, color: Color(0xFFE73A53)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Estimasi pengambilan belum sampai. Lanjutkan hanya jika servis benar-benar sudah diserahkan ke pelanggan.',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: isWideDialog ? 14 : 13.5,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFFBE123C),
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          )
        : null;

    final summaryBox = Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        children: [
          _buildGridRow('Pelanggan', tx.customerName ?? 'Pelanggan Umum'),
          const Divider(height: 1, color: Color(0xFFE2E8F0)),
          _buildGridRow(
            'No. Invoice',
            TransactionCodeFormatter.format(
              id: tx.id ?? 0,
              createdAt: tx.createdAt,
              transactionCode: tx.transactionCode,
            ),
          ),
          if (serviceBadgeLabel != null) ...[
            const Divider(height: 1, color: Color(0xFFE2E8F0)),
            _buildGridRow('Level Layanan', serviceBadgeLabel),
          ],
          if (fulfillmentBadgeLabel != null) ...[
            const Divider(height: 1, color: Color(0xFFE2E8F0)),
            _buildGridRow('Penyerahan', fulfillmentBadgeLabel),
          ],
          if (pickupFormatted != null) ...[
            const Divider(height: 1, color: Color(0xFFE2E8F0)),
            _buildGridRow(
              'Pengambilan',
              pickupFormatted,
              fgColor: isTooEarly
                  ? const Color(0xFFE73A53)
                  : const Color(0xFF16A34A),
              isBold: true,
            ),
          ],
          if (sisaStr != null) ...[
            const Divider(height: 1, color: Color(0xFFE2E8F0)),
            _buildGridRow(
              'Sisa Estimasi',
              sisaStr,
              fgColor: const Color(0xFFE73A53),
              isBold: true,
            ),
          ],
        ],
      ),
    );

    final guardBox = Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFEFF6FF),
        border: Border.all(color: const Color(0xFFBFDBFE)),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.verified_user_outlined,
              size: 19, color: Color(0xFF2563EB)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'Pastikan servis sudah diterima oleh ${tx.customerName ?? 'pelanggan'} sebelum menekan Selesai. Status ini mengeluarkan pesanan dari antrean kerja.',
              style: GoogleFonts.plusJakartaSans(
                fontSize: isWideDialog ? 13.5 : 13,
                fontWeight: FontWeight.w800,
                color: const Color(0xFF1E40AF),
                height: 1.45,
              ),
            ),
          ),
        ],
      ),
    );

    final actionButtons = Row(
      children: [
        if (isWideDialog) const Spacer(),
        SizedBox(
          width: isWideDialog ? 160 : null,
          child: OutlinedButton(
            onPressed: () => Navigator.pop(context, false),
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFF64748B),
              side: const BorderSide(color: Color(0xFFCBD5E1)),
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              padding: const EdgeInsets.symmetric(vertical: 15),
            ),
            child: Text(
              'Batalkan',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 14,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        SizedBox(
          width: isWideDialog ? 230 : null,
          child: ElevatedButton.icon(
            onPressed: () => Navigator.pop(context, true),
            icon: const Icon(Icons.done_all_rounded, size: 18),
            label: Text(
              isTooEarly ? 'Tetap Selesaikan' : 'Sudah Diambil',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 14,
                fontWeight: FontWeight.w900,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: isTooEarly
                  ? const Color(0xFFE73A53)
                  : const Color(0xFF16A34A),
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(vertical: 15),
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
          ),
        ),
      ].map((child) {
        if (isWideDialog) return child;
        if (child is SizedBox && child.width == null) {
          return Expanded(child: child);
        }
        return child;
      }).toList(),
    );

    return Dialog(
      insetPadding: EdgeInsets.symmetric(
        horizontal: isWideDialog ? 32 : 18,
        vertical: 24,
      ),
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: isWideDialog ? 820 : 520),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                color: isTooEarly
                    ? const Color(0xFFFFF2F2)
                    : const Color(0xFFECFDF5),
                padding: EdgeInsets.symmetric(
                  horizontal: isWideDialog ? 26 : 22,
                  vertical: isWideDialog ? 22 : 20,
                ),
                child: Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(isWideDialog ? 12 : 11),
                      decoration: BoxDecoration(
                        color: isTooEarly
                            ? const Color(0xFFE73A53)
                            : const Color(0xFF16A34A),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        isTooEarly
                            ? Icons.warning_amber_rounded
                            : Icons.check_circle_rounded,
                        color: Colors.white,
                        size: isWideDialog ? 25 : 24,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isTooEarly
                                ? 'Konfirmasi Pengambilan Lebih Awal?'
                                : 'Servis sudah diambil pelanggan?',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: isWideDialog ? 19 : 17,
                              fontWeight: FontWeight.w900,
                              color: isTooEarly
                                  ? const Color(0xFFBE123C)
                                  : const Color(0xFF14532D),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            isTooEarly
                                ? 'Jadwal pengambilan belum sampai'
                                : 'Pesanan akan dipindahkan ke Selesai',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: isWideDialog ? 13.5 : 13,
                              fontWeight: FontWeight.w700,
                              color: isTooEarly
                                  ? const Color(0xFFE11D48)
                                  : const Color(0xFF16A34A),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.all(isWideDialog ? 26 : 24),
                child: isWideDialog
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                flex: 9,
                                child: Column(
                                  children: [
                                    if (earlyWarningBox != null) ...[
                                      earlyWarningBox,
                                      const SizedBox(height: 14),
                                    ],
                                    guardBox,
                                  ],
                                ),
                              ),
                              const SizedBox(width: 18),
                              Expanded(flex: 11, child: summaryBox),
                            ],
                          ),
                          const SizedBox(height: 20),
                          actionButtons,
                        ],
                      )
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (earlyWarningBox != null) ...[
                            earlyWarningBox,
                            const SizedBox(height: 12),
                          ],
                          summaryBox,
                          const SizedBox(height: 16),
                          guardBox,
                          const SizedBox(height: 16),
                          actionButtons,
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGridRow(String label, String value,
      {Color? fgColor, bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF64748B),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13.5,
                fontWeight: isBold ? FontWeight.w800 : FontWeight.w700,
                color: fgColor ?? const Color(0xFF0F172A),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PreviousStatusConfirmDialog extends StatelessWidget {
  final Transaction tx;
  final String currentStatus;
  final String previousStatus;

  const _PreviousStatusConfirmDialog({
    required this.tx,
    required this.currentStatus,
    required this.previousStatus,
  });

  @override
  Widget build(BuildContext context) {
    final noTrx = TransactionCodeFormatter.format(
      id: tx.id ?? 0,
      createdAt: tx.createdAt,
      transactionCode: tx.transactionCode,
    );

    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 24),
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 480),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              color: const Color(0xFFFFF7ED),
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(11),
                    decoration: const BoxDecoration(
                      color: Color(0xFFEA580C),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.undo_rounded,
                        color: Colors.white, size: 24),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Kembalikan status pesanan?',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                            color: const Color(0xFF9A3412),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '$currentStatus akan kembali ke $previousStatus',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFFEA580C),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Gunakan aksi ini hanya jika status sebelumnya tidak sengaja ditekan atau perlu dikoreksi.',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF475569),
                      height: 1.45,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8FAFC),
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Column(
                      children: [
                        _buildGridRow(
                            'Pelanggan', tx.customerName ?? 'Pelanggan Umum'),
                        const Divider(height: 1, color: Color(0xFFE2E8F0)),
                        _buildGridRow('No. Invoice', noTrx),
                        const Divider(height: 1, color: Color(0xFFE2E8F0)),
                        _buildGridRow('Status Saat Ini', currentStatus,
                            fgColor: _kBrand, isBold: true),
                        const Divider(height: 1, color: Color(0xFFE2E8F0)),
                        _buildGridRow('Dikembalikan Ke', previousStatus,
                            fgColor: const Color(0xFFEA580C), isBold: true),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(context, false),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFF64748B),
                            side: const BorderSide(color: Color(0xFFCBD5E1)),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: Text(
                            'Batal',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        flex: 2,
                        child: ElevatedButton.icon(
                          onPressed: () => Navigator.pop(context, true),
                          icon: const Icon(Icons.undo_rounded, size: 18),
                          label: Text(
                            'Ya, Kembalikan',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFEA580C),
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGridRow(String label, String value,
      {Color? fgColor, bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF64748B),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13.5,
                fontWeight: isBold ? FontWeight.w900 : FontWeight.w800,
                color: fgColor ?? const Color(0xFF0F172A),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ignore: unused_element
class _EarlyCompletionDialog extends StatelessWidget {
  final Transaction tx;
  final String nextStatus;
  final DateTime pickupDt;
  final Duration diff;

  const _EarlyCompletionDialog({
    required this.tx,
    required this.nextStatus,
    required this.pickupDt,
    required this.diff,
  });

  @override
  Widget build(BuildContext context) {
    final createdDt = DateTime.tryParse(tx.createdAt);
    final now = DateTime.now();
    final elapsed = createdDt != null ? now.difference(createdDt) : null;

    final estimasiSelesaiFormatted =
        DateFormat('EEEE, dd MMMM yyyy HH:mm', 'id').format(pickupDt);
    final createdFormatted = createdDt != null
        ? DateFormat('dd MMM yyyy HH:mm', 'id').format(createdDt)
        : tx.createdAt;

    final String sisaWaktuStr = _formatDuration(diff);
    final String elapsedStr = elapsed != null ? _formatDuration(elapsed) : '-';

    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 24),
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
      ),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 480),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Header
              Container(
                color: const Color(0xFFFFF7ED),
                padding:
                    const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(11),
                      decoration: const BoxDecoration(
                        color: Color(0xFFF97316),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.timer_outlined,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Penyelesaian Lebih Cepat?',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 17,
                              fontWeight: FontWeight.w900,
                              color: const Color(0xFF92400E),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Status pesanan akan diubah ke $nextStatus',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: const Color(0xFFB45309),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Warning Text
                    Text(
                      'Pengerjaan servis ini selesai lebih cepat dari estimasi waktu yang dijadwalkan. Menyelesaikan transaksi sebelum estimasi pengerjaan sangat bagus untuk kepuasan pelanggan, namun mohon pastikan kembali kualitas servis.',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 13.5,
                        color: const Color(0xFF334155),
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Stats Grid
                    Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Column(
                        children: [
                          _buildGridRow('Layanan',
                              tx.orderType?.toUpperCase() ?? 'REGULAR'),
                          const Divider(height: 1, color: Color(0xFFE2E8F0)),
                          _buildGridRow('Tanggal Buat', createdFormatted),
                          const Divider(height: 1, color: Color(0xFFE2E8F0)),
                          _buildGridRow(
                              'Jadwal Estimasi', estimasiSelesaiFormatted),
                          const Divider(height: 1, color: Color(0xFFE2E8F0)),
                          _buildGridRow('Waktu Berjalan', elapsedStr,
                              fgColor: const Color(0xFF2563EB)),
                          const Divider(height: 1, color: Color(0xFFE2E8F0)),
                          _buildGridRow(
                              'Sisa Waktu', '$sisaWaktuStr Lebih Cepat',
                              fgColor: const Color(0xFFEA580C), isBold: true),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Professional QC Note
                    Container(
                      padding: const EdgeInsets.all(14),
                      color: const Color(0xFFEFF6FF),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            Icons.verified_user_outlined,
                            size: 18,
                            color: Color(0xFF2563EB),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'KOMITMEN KUALITAS: Pastikan unit dan aksesori telah melalui Quality Control (QC), berfungsi baik, lengkap, dan sesuai catatan sebelum diserahkan.',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                color: const Color(0xFF1E40AF),
                                height: 1.4,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const Divider(height: 1),

              // Buttons Row
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    OutlinedButton(
                      onPressed: () => Navigator.pop(context, false),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF64748B),
                        side: const BorderSide(color: Color(0xFFE2E8F0)),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 18, vertical: 15),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: Text(
                        'BATAL',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton.icon(
                      onPressed: () => Navigator.pop(context, true),
                      icon: const Icon(Icons.check_circle_rounded, size: 17),
                      label: Text(
                        'SELESAIKAN SEKARANG',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFEA580C),
                        foregroundColor: Colors.white,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 18, vertical: 15),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGridRow(String label, String value,
      {Color? fgColor, bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF64748B),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13.5,
                fontWeight: isBold ? FontWeight.w800 : FontWeight.w700,
                color: fgColor ?? const Color(0xFF0F172A),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

