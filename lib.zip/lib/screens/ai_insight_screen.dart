import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../core/theme.dart';
import '../providers/providers.dart';
import '../services/ai_simple_service.dart';

class AIInsightScreen extends ConsumerStatefulWidget {
  final VoidCallback? onBack;

  const AIInsightScreen({super.key, this.onBack});

  @override
  ConsumerState<AIInsightScreen> createState() => _AIInsightScreenState();
}

class _AIInsightScreenState extends ConsumerState<AIInsightScreen> {
  String? _selectedQuestionId;
  int _answerVersion = 0;
  String _activeDateKey = _dayKey(DateTime.now());
  final List<_ConversationEntry> _conversation = [];
  final ScrollController _scrollController = ScrollController();
  final GlobalKey _answerAnchorKey = GlobalKey();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _selectQuestion(String id) {
    setState(() {
      _selectedQuestionId = id;
      _answerVersion++;
      _conversation.add(_ConversationEntry(
        questionId: id,
        version: _answerVersion,
      ));
    });
    _scrollToAnswer();
  }

  void _scrollToAnswer() {
    void animateToAnswerStart() {
      final context = _answerAnchorKey.currentContext;
      if (context == null) return;
      Scrollable.ensureVisible(
        context,
        duration: const Duration(milliseconds: 560),
        curve: Curves.easeOutCubic,
        alignment: 0.02,
      );
    }

    WidgetsBinding.instance.addPostFrameCallback((_) => animateToAnswerStart());
    Future.delayed(const Duration(milliseconds: 120), animateToAnswerStart);
  }

  @override
  Widget build(BuildContext context) {
    final todayKey = _dayKey(DateTime.now());
    if (_activeDateKey != todayKey) {
      _activeDateKey = todayKey;
      _selectedQuestionId = null;
      _answerVersion = 0;
      _conversation.clear();
    }

    final snapshotAsync = ref.watch(aiBusinessSnapshotProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      bottomNavigationBar: _conversation.isEmpty
          ? null
          : _FollowUpQuestions(
              templates: _templates,
              selectedQuestionId: _selectedQuestionId,
              onSelect: _selectQuestion,
            ),
      body: SafeArea(
        child: snapshotAsync.when(
          loading: () => const Center(
            child: CircularProgressIndicator(color: AppColors.primaryBrand),
          ),
          error: (error, _) => _ErrorState(
            detail: error.toString(),
            onRetry: () => ref.invalidate(aiBusinessSnapshotProvider),
          ),
          data: (snapshot) => RefreshIndicator(
            color: AppColors.primaryBrand,
            onRefresh: () async => ref.invalidate(aiBusinessSnapshotProvider),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final wide = constraints.maxWidth >= 920;
                const templates = _templates;
                final conversations = _conversation
                    .map((entry) {
                      final template = templates
                          .where((q) => q.id == entry.questionId)
                          .cast<_QuestionTemplate?>()
                          .firstOrNull;
                      if (template == null) return null;
                      return _ConversationViewData(
                        entry: entry,
                        template: template,
                        answer: _buildAnswer(snapshot, template.id),
                      );
                    })
                    .whereType<_ConversationViewData>()
                    .toList();

                return CustomScrollView(
                  controller: _scrollController,
                  physics: const AlwaysScrollableScrollPhysics(),
                  slivers: [
                    SliverPersistentHeader(
                      pinned: true,
                      delegate: _AiHeaderDelegate(
                        minExtentValue: 58,
                        maxExtentValue: 58,
                        child: _StickyHeaderShell(
                          horizontalPadding: wide ? 32 : 16,
                          child: _Header(
                            snapshot: snapshot,
                            onBack: widget.onBack,
                          ),
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(
                          wide ? 32 : 16,
                          12,
                          wide ? 32 : 16,
                          _conversation.isEmpty ? 28 : 104,
                        ),
                        child: Center(
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 1120),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _RecommendationDashboard(
                                  snapshot: snapshot,
                                  onSelect: _selectQuestion,
                                ),
                                const SizedBox(height: 14),
                                _AskBox(
                                  templates: _primaryTemplates,
                                  selectedQuestionId: _selectedQuestionId,
                                  onSelect: _selectQuestion,
                                ),
                                if (conversations.isNotEmpty) ...[
                                  const SizedBox(height: 14),
                                  for (int i = 0;
                                      i < conversations.length;
                                      i++) ...[
                                    if (i == conversations.length - 1)
                                      SizedBox(
                                        key: _answerAnchorKey,
                                        height: 1,
                                      ),
                                    _AnswerView(
                                      key: ValueKey(
                                        '${conversations[i].entry.questionId}-${conversations[i].entry.version}',
                                      ),
                                      template: conversations[i].template,
                                      answer: conversations[i].answer,
                                      wide: wide,
                                    ),
                                    if (i != conversations.length - 1)
                                      const SizedBox(height: 16),
                                  ],
                                ],
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}

class _QuestionTemplate {
  final String id;
  final String text;
  final IconData icon;
  final String category;
  final bool primary;

  const _QuestionTemplate({
    required this.id,
    required this.text,
    required this.icon,
    this.category = 'Umum',
    this.primary = false,
  });
}

class _ConversationEntry {
  final String questionId;
  final int version;

  const _ConversationEntry({
    required this.questionId,
    required this.version,
  });
}

class _ConversationViewData {
  final _ConversationEntry entry;
  final _QuestionTemplate template;
  final _AiAnswer answer;

  const _ConversationViewData({
    required this.entry,
    required this.template,
    required this.answer,
  });
}

class _AiAnswer {
  final bool enoughData;
  final String title;
  final String answer;
  final String? reason;
  final String recommendation;
  final List<_AnswerMetric> metrics;
  final Widget visual;

  const _AiAnswer({
    required this.enoughData,
    required this.title,
    required this.answer,
    this.reason,
    required this.recommendation,
    required this.metrics,
    required this.visual,
  });
}

class _AnswerMetric {
  final String label;
  final String value;

  const _AnswerMetric({required this.label, required this.value});
}

const _templates = [
  _QuestionTemplate(
    id: 'summary',
    text: 'Bagaimana kondisi servis saya saat ini?',
    icon: Icons.health_and_safety_outlined,
    category: 'Ringkasan',
    primary: true,
  ),
  _QuestionTemplate(
    id: 'learning',
    text: 'Seberapa pintar AI ini memahami servis saya?',
    icon: Icons.school_outlined,
    category: 'Ringkasan',
    primary: true,
  ),
  _QuestionTemplate(
    id: 'forecast',
    text: 'Berapa prediksi omzet besok?',
    icon: Icons.trending_up_rounded,
    category: 'Keuangan',
    primary: true,
  ),
  _QuestionTemplate(
    id: 'today_sales',
    text: 'Omzet hari ini bagus atau buruk?',
    icon: Icons.today_outlined,
    category: 'Keuangan',
  ),
  _QuestionTemplate(
    id: 'weekly_outlook',
    text: 'Bagaimana proyeksi omzet 7 hari ke depan?',
    icon: Icons.stacked_line_chart_rounded,
    category: 'Keuangan',
  ),
  _QuestionTemplate(
    id: 'payment_methods',
    text: 'Metode pembayaran apa yang paling sering dipakai?',
    icon: Icons.payments_outlined,
    category: 'Keuangan',
  ),
  _QuestionTemplate(
    id: 'top_products',
    text: 'Layanan atau produk servis apa yang paling laris bulan ini?',
    icon: Icons.local_fire_department_outlined,
    category: 'Produk',
    primary: true,
  ),
  _QuestionTemplate(
    id: 'profit_products',
    text: 'Produk mana yang paling menguntungkan?',
    icon: Icons.insights_rounded,
    category: 'Produk',
  ),
  _QuestionTemplate(
    id: 'restock',
    text: 'Stok operasional apa yang harus saya restock dulu?',
    icon: Icons.inventory_2_outlined,
    category: 'Stok',
    primary: true,
  ),
  _QuestionTemplate(
    id: 'inventory_value',
    text: 'Berapa nilai stok gudang saya?',
    icon: Icons.warehouse_outlined,
    category: 'Stok',
  ),
  _QuestionTemplate(
    id: 'stock_risk',
    text: 'Barang apa yang rawan kehabisan minggu ini?',
    icon: Icons.production_quantity_limits_outlined,
    category: 'Stok',
  ),
  _QuestionTemplate(
    id: 'bundling',
    text: 'Bundling apa yang cocok ditawarkan?',
    icon: Icons.hub_outlined,
    category: 'Produk',
    primary: true,
  ),
  _QuestionTemplate(
    id: 'busy_hour',
    text: 'Jam tersibuk servis saya kapan?',
    icon: Icons.schedule_outlined,
    category: 'Operasional',
    primary: true,
  ),
  _QuestionTemplate(
    id: 'overdue_orders',
    text: 'Order mana yang berisiko telat?',
    icon: Icons.timer_off_outlined,
    category: 'Operasional',
    primary: true,
  ),
  _QuestionTemplate(
    id: 'pickup_queue',
    text: 'Berapa order siap ambil dan jatuh tempo dekat?',
    icon: Icons.fact_check_outlined,
    category: 'Operasional',
    primary: true,
  ),
  _QuestionTemplate(
    id: 'service_mix',
    text: 'Layanan servis apa yang paling dominan?',
    icon: Icons.handyman_outlined,
    category: 'Operasional',
  ),
  _QuestionTemplate(
    id: 'express_load',
    text: 'Apakah beban express masih aman?',
    icon: Icons.flash_on_outlined,
    category: 'Operasional',
  ),
  _QuestionTemplate(
    id: 'kelengkapan',
    text: 'Parfum apa yang paling disukai pelanggan?',
    icon: Icons.spa_outlined,
    category: 'Pelanggan',
  ),
  _QuestionTemplate(
    id: 'price',
    text: 'Ada harga produk yang perlu diubah?',
    icon: Icons.sell_outlined,
    category: 'Produk',
    primary: true,
  ),
  _QuestionTemplate(
    id: 'top_customers',
    text: 'Pelanggan mana yang paling sering belanja?',
    icon: Icons.people_alt_outlined,
    category: 'Pelanggan',
  ),
  _QuestionTemplate(
    id: 'piutang_risk',
    text: 'Piutang mana yang harus ditagih dulu?',
    icon: Icons.request_quote_outlined,
    category: 'Pelanggan',
  ),
  _QuestionTemplate(
    id: 'supplier_debt',
    text: 'Ada hutang supplier yang perlu diprioritaskan?',
    icon: Icons.local_shipping_outlined,
    category: 'Supplier',
  ),
  _QuestionTemplate(
    id: 'risk',
    text: 'Ada masalah bisnis yang perlu dicek?',
    icon: Icons.radar_outlined,
    category: 'Operasional',
    primary: true,
  ),
];

List<_QuestionTemplate> get _primaryTemplates =>
    _templates.where((item) => item.primary).toList(growable: false);

class _AiHeaderDelegate extends SliverPersistentHeaderDelegate {
  final double minExtentValue;
  final double maxExtentValue;
  final Widget child;

  const _AiHeaderDelegate({
    required this.minExtentValue,
    required this.maxExtentValue,
    required this.child,
  });

  @override
  double get minExtent => minExtentValue;

  @override
  double get maxExtent => maxExtentValue;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return child;
  }

  @override
  bool shouldRebuild(covariant _AiHeaderDelegate oldDelegate) {
    return oldDelegate.child != child ||
        oldDelegate.minExtentValue != minExtentValue ||
        oldDelegate.maxExtentValue != maxExtentValue;
  }
}

class _StickyHeaderShell extends StatelessWidget {
  final double horizontalPadding;
  final Widget child;

  const _StickyHeaderShell({
    required this.horizontalPadding,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.background,
      padding: EdgeInsets.fromLTRB(horizontalPadding, 6, horizontalPadding, 6),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1120),
          child: child,
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final AiBusinessSnapshot snapshot;
  final VoidCallback? onBack;

  const _Header({required this.snapshot, this.onBack});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 46,
      decoration: const BoxDecoration(
        color: AppColors.background,
        border: Border(bottom: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        children: [
          Material(
            color: AppColors.surface,
            child: InkWell(
              onTap: onBack ?? () => Navigator.of(context).maybePop(),
              child: Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.border),
                ),
                child: const Icon(
                  Icons.arrow_back_rounded,
                  color: AppColors.textTitle,
                  size: 20,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Asisten AI Servis',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    color: AppColors.textTitle,
                  ),
                ),
                Text(
                  'Rekomendasi offline dari data servis',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: _captionStyle(weight: FontWeight.w700),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          _ScoreBadge(snapshot: snapshot),
        ],
      ),
    );
  }
}

class _ScoreBadge extends StatelessWidget {
  final AiBusinessSnapshot snapshot;

  const _ScoreBadge({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 148),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.brandLight,
        border:
            Border.all(color: AppColors.primaryBrand.withValues(alpha: 0.16)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.auto_awesome_rounded,
            size: 14,
            color: AppColors.primaryBrand,
          ),
          const SizedBox(width: 6),
          Text(
            'AI ${snapshot.learningProfile.dataMaturity}%',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11,
              fontWeight: FontWeight.w900,
              color: AppColors.primaryBrand,
            ),
          ),
        ],
      ),
    );
  }
}

class _RecommendationDashboard extends StatelessWidget {
  final AiBusinessSnapshot snapshot;
  final ValueChanged<String> onSelect;

  const _RecommendationDashboard({
    required this.snapshot,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final insights = _buildPriorityInsights(snapshot);
    final ops = snapshot.servisOperations;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _AiExecutiveCard(
          snapshot: snapshot,
          onPrimaryTap: insights.isEmpty
              ? () => onSelect('summary')
              : () => onSelect(insights.first.questionId),
        ),
        const SizedBox(height: 12),
        _SmallFactGrid(
          facts: [
            _AnswerMetric(label: 'Order aktif', value: '${ops.activeOrders}'),
            _AnswerMetric(label: 'Siap ambil', value: '${ops.readyForPickup}'),
            _AnswerMetric(label: 'Terlambat', value: '${ops.overdueOrders}'),
            _AnswerMetric(
              label: 'Data AI',
              value: '${snapshot.learningProfile.dataMaturity}%',
            ),
          ],
        ),
        const SizedBox(height: 12),
        _CardShell(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: const BoxDecoration(
                      color: AppColors.brandLight,
                      borderRadius: BorderRadius.zero,
                    ),
                    child: const Icon(
                      Icons.task_alt_rounded,
                      color: AppColors.primaryBrand,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Rekomendasi Hari Ini', style: _titleStyle()),
                        const SizedBox(height: 2),
                        Text(
                          'Diurutkan dari yang paling perlu ditangani.',
                          style: _captionStyle(color: AppColors.textBody),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (insights.isEmpty)
                const _EmptyBox(
                  text:
                      'Belum ada prioritas khusus. Lanjutkan pencatatan transaksi, status, stok, dan pembayaran agar rekomendasi makin tajam.',
                )
              else
                Column(
                  children: [
                    for (int i = 0; i < insights.length; i++) ...[
                      _PriorityInsightTile(
                        insight: insights[i],
                        onAnalyze: () => onSelect(insights[i].questionId),
                      ),
                      if (i != insights.length - 1) const SizedBox(height: 9),
                    ],
                  ],
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        _DataQualityPanel(snapshot: snapshot),
      ],
    );
  }
}

class _AiExecutiveCard extends StatelessWidget {
  final AiBusinessSnapshot snapshot;
  final VoidCallback onPrimaryTap;

  const _AiExecutiveCard({
    required this.snapshot,
    required this.onPrimaryTap,
  });

  @override
  Widget build(BuildContext context) {
    final ops = snapshot.servisOperations;
    final seriousAlerts = snapshot.anomalyAlerts
        .where((a) => a.severity == 'danger' || a.severity == 'warning')
        .length;
    final title = seriousAlerts > 0 || ops.overdueOrders > 0
        ? 'Ada prioritas yang perlu dicek'
        : 'Operasional servis terbaca stabil';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.primaryBrand,
        borderRadius: BorderRadius.zero,
        boxShadow: AppShadow.soft,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.zero,
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.18),
                  ),
                ),
                child: const Icon(
                  Icons.auto_awesome_rounded,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 19,
                        height: 1.22,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      snapshot.executiveSummary,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12.5,
                        height: 1.45,
                        fontWeight: FontWeight.w700,
                        color: Colors.white.withValues(alpha: 0.82),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _ExecutiveMetric(
                label: 'Skor',
                value: '${snapshot.healthScore}',
              ),
              const SizedBox(width: 8),
              _ExecutiveMetric(
                label: 'Status',
                value: snapshot.statusLabel,
              ),
              const SizedBox(width: 8),
              _ExecutiveMetric(
                label: 'Prediksi',
                value:
                    '${_money(snapshot.salesForecast.tomorrowLow)} - ${_money(snapshot.salesForecast.tomorrowHigh)}',
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            height: 44,
            child: OutlinedButton.icon(
              onPressed: onPrimaryTap,
              icon: const Icon(Icons.insights_rounded, size: 18),
              label: const Text('Lihat Analisis Prioritas'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white,
                side: BorderSide(color: Colors.white.withValues(alpha: 0.42)),
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
                textStyle: GoogleFonts.plusJakartaSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ExecutiveMetric extends StatelessWidget {
  final String label;
  final String value;

  const _ExecutiveMetric({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        constraints: const BoxConstraints(minHeight: 56),
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.12),
          borderRadius: BorderRadius.zero,
          border: Border.all(color: Colors.white.withValues(alpha: 0.14)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                color: Colors.white.withValues(alpha: 0.74),
              ),
            ),
            const SizedBox(height: 3),
            Text(
              value,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 12.5,
                height: 1.2,
                fontWeight: FontWeight.w900,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PriorityInsight {
  final String questionId;
  final IconData icon;
  final Color color;
  final String title;
  final String message;
  final String actionLabel;
  final String? routeName;
  final int priority;

  const _PriorityInsight({
    required this.questionId,
    required this.icon,
    required this.color,
    required this.title,
    required this.message,
    required this.actionLabel,
    required this.priority,
    this.routeName,
  });
}

class _PriorityInsightTile extends StatelessWidget {
  final _PriorityInsight insight;
  final VoidCallback onAnalyze;

  const _PriorityInsightTile({
    required this.insight,
    required this.onAnalyze,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: insight.color.withValues(alpha: 0.07),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: insight.color.withValues(alpha: 0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: insight.color.withValues(alpha: 0.11),
                  borderRadius: BorderRadius.zero,
                ),
                child: Icon(insight.icon, color: insight.color, size: 19),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      insight.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 13.5,
                        height: 1.25,
                        fontWeight: FontWeight.w900,
                        color: AppColors.textTitle,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      insight.message,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: _captionStyle(color: AppColors.textBody),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: onAnalyze,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: insight.color,
                    side: BorderSide(
                      color: insight.color.withValues(alpha: 0.3),
                    ),
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                  child: Text(
                    'Lihat alasan',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
              if (insight.routeName != null) ...[
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () =>
                        Navigator.pushNamed(context, insight.routeName!),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: insight.color,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero,
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                    child: Text(
                      insight.actionLabel,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _DataQualityPanel extends StatelessWidget {
  final AiBusinessSnapshot snapshot;

  const _DataQualityPanel({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    final profile = snapshot.learningProfile;
    final missing = profile.missingSignals.take(2).toList();
    final strong = profile.strongSignals.take(2).toList();

    return _CardShell(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text('Kualitas Data AI', style: _titleStyle()),
              ),
              Text(
                '${profile.dataMaturity}%',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: AppColors.primaryBrand,
                ),
              ),
            ],
          ),
          const SizedBox(height: 9),
          ClipRRect(
            borderRadius: BorderRadius.zero,
            child: LinearProgressIndicator(
              minHeight: 9,
              value: profile.dataMaturity / 100,
              backgroundColor: AppColors.surfaceDim,
              valueColor:
                  const AlwaysStoppedAnimation<Color>(AppColors.primaryBrand),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            profile.learningSummary,
            style: _captionStyle(color: AppColors.textBody),
          ),
          if (strong.isNotEmpty || missing.isNotEmpty) ...[
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final item in strong)
                  _SignalPill(
                    icon: Icons.check_circle_outline_rounded,
                    color: AppColors.success,
                    text: item,
                  ),
                for (final item in missing)
                  _SignalPill(
                    icon: Icons.add_task_rounded,
                    color: AppColors.warning,
                    text: item,
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _AskBox extends StatelessWidget {
  final List<_QuestionTemplate> templates;
  final String? selectedQuestionId;
  final ValueChanged<String> onSelect;

  const _AskBox({
    required this.templates,
    required this.selectedQuestionId,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return _CardShell(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.surfaceDim.withValues(alpha: 0.72),
              borderRadius: BorderRadius.zero,
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                const Icon(Icons.chat_bubble_outline_rounded,
                    color: AppColors.primaryBrand, size: 20),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Tanyakan detail ke Asisten AI',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textTitle,
                    ),
                  ),
                ),
                const Icon(Icons.expand_more_rounded,
                    color: AppColors.textCaption),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Pilih topik jika ingin penjelasan lebih rinci dari rekomendasi hari ini.',
            style: _captionStyle(color: AppColors.textBody),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final q in templates)
                _QuestionChip(
                  template: q,
                  selected: q.id == selectedQuestionId,
                  onTap: () => onSelect(q.id),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _QuestionChip extends StatelessWidget {
  final _QuestionTemplate template;
  final bool selected;
  final VoidCallback onTap;

  const _QuestionChip({
    required this.template,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.primaryBrand : AppColors.textBody;
    return Material(
      color: selected ? AppColors.brandLight : Colors.white,
      borderRadius: BorderRadius.zero,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.zero,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 280),
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.zero,
            border: Border.all(
              color: selected
                  ? AppColors.primaryBrand.withValues(alpha: 0.35)
                  : AppColors.border,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(template.icon, size: 17, color: color),
              const SizedBox(width: 7),
              Flexible(
                child: Text(
                  template.text,
                  maxLines: 3,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    height: 1.25,
                    fontWeight: FontWeight.w800,
                    color: color,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AnswerView extends StatelessWidget {
  final _QuestionTemplate template;
  final _AiAnswer answer;
  final bool wide;

  const _AnswerView({
    super.key,
    required this.template,
    required this.answer,
    required this.wide,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: Alignment.centerRight,
          child: Container(
            constraints: const BoxConstraints(maxWidth: 620),
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(
              color: AppColors.primaryBrand,
              borderRadius: BorderRadius.zero,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(template.icon, color: Colors.white, size: 18),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    template.text,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        _CardShell(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: answer.enoughData
                          ? AppColors.brandLight
                          : AppColors.warningBg,
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Icon(
                      answer.enoughData
                          ? Icons.auto_awesome_rounded
                          : Icons.info_outline_rounded,
                      color: answer.enoughData
                          ? AppColors.primaryBrand
                          : AppColors.warning,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Text(answer.title, style: _titleStyle())),
                ],
              ),
              const SizedBox(height: 12),
              _ThinkingStatus(enoughData: answer.enoughData),
              const SizedBox(height: 10),
              _AnswerSection(
                icon: Icons.manage_search_rounded,
                label: 'Temuan',
                child: _TypingText(
                  text: answer.answer,
                  style: _bodyStyle(),
                ),
              ),
              const SizedBox(height: 12),
              _AnswerSection(
                icon: Icons.tips_and_updates_outlined,
                label: 'Pertimbangan AI',
                child: Text(
                  answer.reason ?? _defaultReasonFor(template.id),
                  style: _bodyStyle(),
                ),
              ),
              if (answer.metrics.isNotEmpty) ...[
                const SizedBox(height: 14),
                _MetricWrap(metrics: answer.metrics),
              ],
              const SizedBox(height: 16),
              answer.visual,
              const SizedBox(height: 14),
              _RecommendationBox(text: answer.recommendation),
              _AnswerActionBar(questionId: template.id),
            ],
          ),
        ),
      ],
    );
  }
}

class _AnswerSection extends StatelessWidget {
  final IconData icon;
  final String label;
  final Widget child;

  const _AnswerSection({
    required this.icon,
    required this.label,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surfaceDim.withValues(alpha: 0.52),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: AppColors.border.withValues(alpha: 0.72)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 17, color: AppColors.primaryBrand),
              const SizedBox(width: 7),
              Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  color: AppColors.textTitle,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }
}

class _AiRouteAction {
  final String label;
  final String routeName;
  final IconData icon;

  const _AiRouteAction({
    required this.label,
    required this.routeName,
    required this.icon,
  });
}

class _AnswerActionBar extends StatelessWidget {
  final String questionId;

  const _AnswerActionBar({required this.questionId});

  @override
  Widget build(BuildContext context) {
    final action = _actionForQuestion(questionId);
    if (action == null) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: SizedBox(
        width: double.infinity,
        height: 44,
        child: ElevatedButton.icon(
          onPressed: () => Navigator.pushNamed(context, action.routeName),
          icon: Icon(action.icon, size: 18),
          label: Text(action.label),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryBrand,
            foregroundColor: Colors.white,
            elevation: 0,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.zero,
            ),
            textStyle: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ),
    );
  }
}

class _FollowUpQuestions extends StatelessWidget {
  final List<_QuestionTemplate> templates;
  final String? selectedQuestionId;
  final ValueChanged<String> onSelect;

  const _FollowUpQuestions({
    required this.templates,
    required this.selectedQuestionId,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: const Border(top: BorderSide(color: AppColors.border)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 14,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          child: SizedBox(
            width: double.infinity,
            height: 48,
            child: OutlinedButton(
              onPressed: () => _showQuestionDialog(context),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primaryBrand,
                side: BorderSide(
                    color: AppColors.primaryBrand.withValues(alpha: 0.35)),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                backgroundColor: AppColors.brandLight.withValues(alpha: 0.72),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.add_comment_outlined, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    'Tanyakan hal lain',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _showQuestionDialog(BuildContext context) async {
    final items =
        templates.where((item) => item.id != selectedQuestionId).toList();
    final rows = <Object>[];
    String? category;
    for (final item in items) {
      if (item.category != category) {
        category = item.category;
        rows.add(category);
      }
      rows.add(item);
    }
    final selected = await showModalBottomSheet<_QuestionTemplate>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: const BoxDecoration(
                        color: AppColors.brandLight,
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Icon(Icons.auto_awesome_rounded,
                          color: AppColors.primaryBrand, size: 19),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Pilih pertanyaan untuk Asisten AI',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: AppColors.textTitle,
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceDim.withValues(alpha: 0.7),
                    borderRadius: BorderRadius.zero,
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.chat_bubble_outline_rounded,
                          color: AppColors.primaryBrand, size: 19),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Text(
                          'Mau tanya apa lagi tentang servis?',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textTitle,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 420),
                  child: ListView.separated(
                    shrinkWrap: true,
                    itemCount: rows.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 6),
                    itemBuilder: (context, index) {
                      final row = rows[index];
                      if (row is String) {
                        return Padding(
                          padding: const EdgeInsets.fromLTRB(2, 8, 2, 2),
                          child: Text(
                            row.toUpperCase(),
                            style: _captionStyle(
                              weight: FontWeight.w900,
                              color: AppColors.textCaption,
                            ).copyWith(letterSpacing: 0.8),
                          ),
                        );
                      }
                      final item = row as _QuestionTemplate;
                      return Material(
                        color: Colors.white,
                        borderRadius: BorderRadius.zero,
                        child: InkWell(
                          onTap: () => Navigator.pop(context, item),
                          borderRadius: BorderRadius.zero,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 12),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.zero,
                              border: Border.all(color: AppColors.border),
                            ),
                            child: Row(
                              children: [
                                Icon(item.icon,
                                    color: AppColors.textBody, size: 19),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    item.text,
                                    style: GoogleFonts.plusJakartaSans(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w800,
                                      color: AppColors.textBody,
                                    ),
                                  ),
                                ),
                                const Icon(Icons.chevron_right_rounded,
                                    color: AppColors.textCaption),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (selected != null) {
      onSelect(selected.id);
    }
  }
}

class _ThinkingStatus extends StatelessWidget {
  final bool enoughData;

  const _ThinkingStatus({required this.enoughData});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 520),
      curve: Curves.easeOut,
      builder: (context, value, child) => Opacity(
        opacity: value,
        child: child,
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: (enoughData ? AppColors.brandLight : AppColors.warningBg)
              .withValues(alpha: 0.9),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              enoughData
                  ? Icons.check_circle_outline_rounded
                  : Icons.auto_awesome_motion_rounded,
              size: 16,
              color: enoughData ? AppColors.primaryBrand : AppColors.warning,
            ),
            const SizedBox(width: 8),
            Text(
              enoughData
                  ? 'Insight siap dari data lokal'
                  : 'Insight awal, otomatis diperbarui',
              style: _captionStyle(
                color: enoughData ? AppColors.primaryBrand : AppColors.warning,
                weight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TypingText extends StatefulWidget {
  final String text;
  final TextStyle style;

  const _TypingText({
    required this.text,
    required this.style,
  });

  @override
  State<_TypingText> createState() => _TypingTextState();
}

class _TypingTextState extends State<_TypingText> {
  Timer? _timer;
  int _visibleChars = 0;

  @override
  void initState() {
    super.initState();
    _start();
  }

  @override
  void didUpdateWidget(covariant _TypingText oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.text != widget.text) {
      _start();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _start() {
    _timer?.cancel();
    _visibleChars = 0;
    _timer = Timer.periodic(const Duration(milliseconds: 18), (timer) {
      if (!mounted) return;
      setState(() {
        _visibleChars = (_visibleChars + 3).clamp(0, widget.text.length);
      });
      if (_visibleChars >= widget.text.length) {
        timer.cancel();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final visible = widget.text.substring(0, _visibleChars);
    final done = _visibleChars >= widget.text.length;
    return Text.rich(
      TextSpan(
        text: visible,
        children: [
          if (!done)
            TextSpan(
              text: ' |',
              style: widget.style.copyWith(color: AppColors.primaryBrand),
            ),
        ],
      ),
      style: widget.style,
    );
  }
}

class _MetricWrap extends StatelessWidget {
  final List<_AnswerMetric> metrics;

  const _MetricWrap({required this.metrics});

  @override
  Widget build(BuildContext context) {
    return _ResponsiveMetricGrid(
      metrics: metrics,
      dense: false,
    );
  }
}

class _ResponsiveMetricGrid extends StatelessWidget {
  final List<_AnswerMetric> metrics;
  final bool dense;

  const _ResponsiveMetricGrid({
    required this.metrics,
    required this.dense,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final maxWidth = constraints.maxWidth;
        final columns = maxWidth >= 760
            ? 3
            : maxWidth >= 420
                ? 2
                : 1;
        final spacing = dense ? 8.0 : 10.0;
        final cardWidth = (maxWidth - (spacing * (columns - 1))) / columns;
        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: [
            for (final metric in metrics)
              SizedBox(
                width: cardWidth,
                child: _MetricCard(metric: metric, dense: dense),
              ),
          ],
        );
      },
    );
  }
}

class _MetricCard extends StatelessWidget {
  final _AnswerMetric metric;
  final bool dense;

  const _MetricCard({
    required this.metric,
    required this.dense,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(minHeight: dense ? 58 : 78),
      padding: EdgeInsets.all(dense ? 10 : 12),
      decoration: BoxDecoration(
        color: AppColors.surfaceDim.withValues(alpha: 0.7),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: AppColors.border.withValues(alpha: 0.55)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(metric.label, style: _captionStyle()),
          const SizedBox(height: 4),
          Text(
            metric.value,
            softWrap: true,
            style: GoogleFonts.plusJakartaSans(
              fontSize: dense ? 13 : 15,
              height: 1.25,
              fontWeight: FontWeight.w900,
              color: AppColors.textTitle,
            ),
          ),
        ],
      ),
    );
  }
}

class _RecommendationBox extends StatelessWidget {
  final String text;

  const _RecommendationBox({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.brandLight,
        borderRadius: BorderRadius.zero,
        border:
            Border.all(color: AppColors.primaryBrand.withValues(alpha: 0.16)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.tips_and_updates_outlined,
              color: AppColors.primaryBrand, size: 19),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Saran tindakan',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: AppColors.primaryBrand,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  text,
                  style: _captionStyle(
                    color: AppColors.textBody,
                    weight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LearningVisual extends StatelessWidget {
  final AiLearningProfile profile;

  const _LearningVisual({required this.profile});

  @override
  Widget build(BuildContext context) {
    final strong = profile.strongSignals;
    final missing = profile.missingSignals;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.zero,
          child: TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0, end: profile.dataMaturity / 100),
            duration: const Duration(milliseconds: 950),
            curve: Curves.easeOutCubic,
            builder: (context, value, _) => LinearProgressIndicator(
              minHeight: 12,
              value: value,
              backgroundColor: AppColors.surfaceDim,
              valueColor:
                  const AlwaysStoppedAnimation<Color>(AppColors.primaryBrand),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            for (final item in strong)
              _SignalPill(
                icon: Icons.check_circle_outline_rounded,
                color: AppColors.success,
                text: item,
              ),
            for (final item in missing)
              _SignalPill(
                icon: Icons.add_task_rounded,
                color: AppColors.warning,
                text: item,
              ),
          ],
        ),
      ],
    );
  }
}

class _SignalPill extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String text;

  const _SignalPill({
    required this.icon,
    required this.color,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 320),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: color.withValues(alpha: 0.18)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 7),
          Flexible(
            child: Text(
              text,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: _captionStyle(color: AppColors.textBody),
            ),
          ),
        ],
      ),
    );
  }
}

class _SmallFactGrid extends StatelessWidget {
  final List<_AnswerMetric> facts;

  const _SmallFactGrid({required this.facts});

  @override
  Widget build(BuildContext context) {
    return _ResponsiveMetricGrid(
      metrics: facts,
      dense: true,
    );
  }
}

class _BarChart extends StatelessWidget {
  final List<_ChartPoint> points;
  final Color color;

  const _BarChart({
    required this.points,
    this.color = AppColors.primaryBrand,
  });

  @override
  Widget build(BuildContext context) {
    final maxValue =
        points.fold<int>(1, (max, p) => p.value > max ? p.value : max);
    return LayoutBuilder(
      builder: (context, constraints) {
        final maxLabels = (constraints.maxWidth / 54).floor().clamp(2, 10);
        final labelEvery = (points.length / maxLabels).ceil().clamp(1, 999);
        return Container(
          height: 178,
          padding: const EdgeInsets.fromLTRB(2, 10, 2, 0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (int index = 0; index < points.length; index++)
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: _BarColumn(
                      point: points[index],
                      maxValue: maxValue,
                      color: color,
                      showLabel: index == 0 ||
                          index == points.length - 1 ||
                          points[index].highlight ||
                          index % labelEvery == 0,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _BarColumn extends StatelessWidget {
  final _ChartPoint point;
  final int maxValue;
  final Color color;
  final bool showLabel;

  const _BarColumn({
    required this.point,
    required this.maxValue,
    required this.color,
    required this.showLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Expanded(
          child: Align(
            alignment: Alignment.bottomCenter,
            child: Tooltip(
              message: '${point.label}: ${point.tooltip}',
              child: TweenAnimationBuilder<double>(
                tween: Tween<double>(
                  begin: 0,
                  end: (point.value / maxValue * 112).clamp(8, 112).toDouble(),
                ),
                duration: const Duration(milliseconds: 780),
                curve: Curves.easeOutCubic,
                builder: (context, height, _) => Container(
                  height: height,
                  width: double.infinity,
                  constraints: const BoxConstraints(maxWidth: 22),
                  decoration: BoxDecoration(
                    color: color.withValues(
                      alpha: point.highlight ? 1 : 0.28,
                    ),
                    borderRadius: BorderRadius.zero,
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 28,
          child: showLabel
              ? FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    point.label,
                    textAlign: TextAlign.center,
                    style: _captionStyle(weight: FontWeight.w800),
                  ),
                )
              : const SizedBox.shrink(),
        ),
      ],
    );
  }
}

class _ChartPoint {
  final String label;
  final int value;
  final String tooltip;
  final bool highlight;

  const _ChartPoint({
    required this.label,
    required this.value,
    required this.tooltip,
    this.highlight = false,
  });
}

class _ListVisual extends StatelessWidget {
  final List<_ListVisualItem> items;

  const _ListVisual({required this.items});

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return const _EmptyBox(
          text: 'Belum ada data yang cukup untuk ditampilkan.');
    }
    return Column(
      children: [
        for (final item in items)
          TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0, end: 1),
            duration: const Duration(milliseconds: 420),
            curve: Curves.easeOutCubic,
            builder: (context, value, child) => Opacity(
              opacity: value,
              child: Transform.translate(
                offset: Offset(0, 8 * (1 - value)),
                child: child,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: item.color.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Icon(item.icon, color: item.color, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: _itemTitleStyle(),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          item.subtitle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: _captionStyle(),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    item.value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: _itemTitleStyle(),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _ListVisualItem {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final String value;

  const _ListVisualItem({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.value,
  });
}

class _EmptyBox extends StatelessWidget {
  final String text;

  const _EmptyBox({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceDim.withValues(alpha: 0.7),
        borderRadius: BorderRadius.zero,
      ),
      child: Text(text, style: _captionStyle(color: AppColors.textBody)),
    );
  }
}

class _CardShell extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;

  const _CardShell({
    required this.child,
    this.padding = const EdgeInsets.all(16),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: AppColors.border),
        boxShadow: AppShadow.soft,
      ),
      child: child,
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String detail;
  final VoidCallback onRetry;

  const _ErrorState({
    required this.detail,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _CardShell(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline_rounded,
                  color: AppColors.danger, size: 34),
              const SizedBox(height: 12),
              Text('Asisten AI belum bisa membaca data.', style: _titleStyle()),
              const SizedBox(height: 8),
              Text(detail, textAlign: TextAlign.center, style: _captionStyle()),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Coba Lagi'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBrand,
                  foregroundColor: Colors.white,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

List<_PriorityInsight> _buildPriorityInsights(AiBusinessSnapshot snapshot) {
  final ops = snapshot.servisOperations;
  final insights = <_PriorityInsight>[];

  if (ops.overdueOrders > 0) {
    final first =
        ops.overdueDetails.isNotEmpty ? ops.overdueDetails.first : null;
    insights.add(
      _PriorityInsight(
        questionId: 'overdue_orders',
        icon: Icons.timer_off_outlined,
        color: AppColors.danger,
        title: '${ops.overdueOrders} order melewati estimasi',
        message: first == null
            ? 'Ada order aktif yang perlu dicek karena sudah lewat jadwal.'
            : 'Prioritas: ${first.customerName}, status ${first.status}, terlambat ${_minutesLabel(first.minutesDelta)}.',
        actionLabel: 'Buka Status',
        routeName: '/servis_ops',
        priority: 100,
      ),
    );
  }

  if (ops.dueSoonOrders > 0) {
    final first =
        ops.dueSoonDetails.isNotEmpty ? ops.dueSoonDetails.first : null;
    insights.add(
      _PriorityInsight(
        questionId: 'pickup_queue',
        icon: Icons.fact_check_outlined,
        color: AppColors.warning,
        title: '${ops.dueSoonOrders} order jatuh tempo dekat',
        message: first == null
            ? 'Dahulukan finishing dan QC untuk order yang mendekati jadwal.'
            : '${first.customerName} perlu dipantau, jadwal ${DateFormat('dd/MM HH:mm').format(first.pickupSchedule)}.',
        actionLabel: 'Buka Status',
        routeName: '/servis_ops',
        priority: 92,
      ),
    );
  }

  if (ops.readyForPickup > 0) {
    insights.add(
      _PriorityInsight(
        questionId: 'pickup_queue',
        icon: Icons.local_mall_outlined,
        color: AppColors.iconTeal,
        title: '${ops.readyForPickup} order siap ambil',
        message:
            'Pisahkan rak siap ambil dan hubungi pelanggan jika order sudah lama menunggu.',
        actionLabel: 'Buka Status',
        routeName: '/servis_ops',
        priority: 82,
      ),
    );
  }

  if (ops.unpaidActiveOrders > 0) {
    insights.add(
      _PriorityInsight(
        questionId: 'piutang_risk',
        icon: Icons.request_quote_outlined,
        color: AppColors.danger,
        title: '${ops.unpaidActiveOrders} order aktif belum lunas',
        message:
            'Pastikan pembayaran ditagih saat pelanggan mengambil servis agar tagihan tidak menumpuk.',
        actionLabel: 'Buka Tagihan',
        routeName: '/riwayat',
        priority: 78,
      ),
    );
  }

  if (snapshot.restockRecommendations.isNotEmpty) {
    final first = snapshot.restockRecommendations.first;
    final urgent = snapshot.restockRecommendations
        .where((item) => item.priority == 'urgent')
        .length;
    insights.add(
      _PriorityInsight(
        questionId: 'restock',
        icon: Icons.inventory_2_outlined,
        color: urgent > 0 ? AppColors.danger : AppColors.warning,
        title: urgent > 0
            ? '$urgent item stok urgent'
            : '${snapshot.restockRecommendations.length} item perlu dipantau',
        message:
            'Prioritas: ${first.product.name}, saran beli ${first.recommendedQty} ${first.product.unit}.',
        actionLabel: 'Cek Stok',
        routeName: '/laporan/gudang',
        priority: urgent > 0 ? 88 : 70,
      ),
    );
  }

  final seriousAlerts = snapshot.anomalyAlerts
      .where((item) => item.severity == 'danger' || item.severity == 'warning')
      .toList();
  if (seriousAlerts.isNotEmpty) {
    final first = seriousAlerts.first;
    insights.add(
      _PriorityInsight(
        questionId: 'risk',
        icon: Icons.radar_outlined,
        color:
            first.severity == 'danger' ? AppColors.danger : AppColors.warning,
        title: first.title,
        message: first.message,
        actionLabel: 'Cek Detail',
        routeName: _routeForAlert(first),
        priority: first.severity == 'danger' ? 86 : 72,
      ),
    );
  }

  if (snapshot.crossSellRecommendations.isNotEmpty) {
    final first = snapshot.crossSellRecommendations.first;
    insights.add(
      _PriorityInsight(
        questionId: 'bundling',
        icon: Icons.hub_outlined,
        color: AppColors.iconPurple,
        title: 'Paket yang bisa ditawarkan',
        message:
            '${first.productA} + ${first.productB} muncul bersama ${first.togetherCount} kali. Cocok ditawarkan kasir.',
        actionLabel: 'Buka Produk',
        routeName: '/produk',
        priority: 58,
      ),
    );
  }

  if (snapshot.topProducts.isNotEmpty) {
    final first = snapshot.topProducts.first;
    insights.add(
      _PriorityInsight(
        questionId: 'top_products',
        icon: Icons.local_fire_department_outlined,
        color: AppColors.iconOrange,
        title: 'Layanan terlaris: ${first.productName}',
        message:
            'Terjual ${first.totalQty} item dengan omzet ${_money(first.totalSales)} pada periode terbaru.',
        actionLabel: 'Lihat Laporan',
        routeName: '/laporan/produk_terjual',
        priority: 50,
      ),
    );
  }

  insights.add(
    _PriorityInsight(
      questionId: 'forecast',
      icon: Icons.trending_up_rounded,
      color: AppColors.primaryBrand,
      title: 'Prediksi omzet besok tersedia',
      message:
          '${_money(snapshot.salesForecast.tomorrowLow)} - ${_money(snapshot.salesForecast.tomorrowHigh)}. Keyakinan estimasi ${snapshot.salesForecast.confidence}%.',
      actionLabel: 'Lihat Omzet',
      routeName: '/laporan/omzet_per_bulan',
      priority: 42,
    ),
  );

  if (insights.length == 1 &&
      ops.activeOrders == 0 &&
      snapshot.anomalyAlerts.isEmpty) {
    insights.add(
      const _PriorityInsight(
        questionId: 'summary',
        icon: Icons.health_and_safety_outlined,
        color: AppColors.success,
        title: 'Belum ada risiko besar',
        message:
            'Data hari ini terlihat tenang. Tetap pantau transaksi, stok, dan order siap ambil.',
        actionLabel: 'Buka Dashboard',
        priority: 64,
      ),
    );
  }

  insights.sort((a, b) => b.priority.compareTo(a.priority));
  return insights.take(5).toList();
}

String? _routeForAlert(AiAnomalyAlert alert) {
  final text = '${alert.title} ${alert.message}'.toLowerCase();
  if (text.contains('stok') || text.contains('restock')) {
    return '/laporan/gudang';
  }
  if (text.contains('piutang') || text.contains('lunas')) return '/riwayat';
  if (text.contains('harga') || text.contains('modal')) return '/produk';
  return '/servis_ops';
}

_AiRouteAction? _actionForQuestion(String id) {
  switch (id) {
    case 'summary':
    case 'risk':
    case 'busy_hour':
    case 'overdue_orders':
    case 'pickup_queue':
    case 'service_mix':
    case 'express_load':
      return const _AiRouteAction(
        label: 'Buka Status Servis',
        routeName: '/servis_ops',
        icon: Icons.fact_check_outlined,
      );
    case 'forecast':
    case 'today_sales':
    case 'weekly_outlook':
      return const _AiRouteAction(
        label: 'Buka Laporan Omzet',
        routeName: '/laporan/omzet_per_bulan',
        icon: Icons.stacked_line_chart_rounded,
      );
    case 'payment_methods':
    case 'piutang_risk':
      return const _AiRouteAction(
        label: 'Buka Riwayat & Tagihan',
        routeName: '/riwayat',
        icon: Icons.receipt_long_outlined,
      );
    case 'top_products':
      return const _AiRouteAction(
        label: 'Buka Layanan Terjual',
        routeName: '/laporan/produk_terjual',
        icon: Icons.local_fire_department_outlined,
      );
    case 'profit_products':
      return const _AiRouteAction(
        label: 'Buka Analisis Keuntungan',
        routeName: '/laporan/laba_rugi',
        icon: Icons.insights_rounded,
      );
    case 'restock':
    case 'inventory_value':
    case 'stock_risk':
      return const _AiRouteAction(
        label: 'Buka Gudang & Stok',
        routeName: '/laporan/gudang',
        icon: Icons.inventory_2_outlined,
      );
    case 'bundling':
    case 'price':
      return const _AiRouteAction(
        label: 'Buka Layanan & Inventori',
        routeName: '/produk',
        icon: Icons.inventory_outlined,
      );
    case 'top_customers':
      return const _AiRouteAction(
        label: 'Buka Pelanggan',
        routeName: '/pelanggan',
        icon: Icons.people_alt_outlined,
      );
    case 'supplier_debt':
      return const _AiRouteAction(
        label: 'Buka Supplier',
        routeName: '/supplier',
        icon: Icons.local_shipping_outlined,
      );
    default:
      return null;
  }
}

String _defaultReasonFor(String id) {
  switch (id) {
    case 'learning':
      return 'Semakin rutin transaksi, status order, pembayaran, dan stok dicatat, semakin cepat asisten mengenali ritme usaha servis ini.';
    case 'forecast':
    case 'today_sales':
    case 'weekly_outlook':
      return 'Saya membandingkan arah omzet terbaru dengan ritme penjualan sebelumnya agar pemilik bisa menyiapkan stok, kas, dan target harian lebih realistis.';
    case 'restock':
    case 'inventory_value':
    case 'stock_risk':
      return 'Prioritas stok ditentukan dari kebutuhan operasional yang paling berisiko menghambat layanan bila terlambat dibeli.';
    case 'overdue_orders':
    case 'pickup_queue':
    case 'service_mix':
    case 'express_load':
      return 'Saya menilai antrean dari status servis, estimasi selesai, dan beban layanan agar order yang paling mendesak tidak tertinggal.';
    case 'bundling':
    case 'top_products':
    case 'profit_products':
    case 'price':
      return 'Rekomendasi ini dipilih karena layanan tersebut paling menonjol untuk penjualan, margin, atau peluang ditawarkan kembali ke pelanggan.';
    case 'payment_methods':
    case 'piutang_risk':
      return 'Saya memprioritaskan pembayaran yang berpengaruh langsung ke arus kas, terutama tagihan belum lunas dan metode bayar yang sering dipakai.';
    case 'top_customers':
      return 'Pelanggan yang sering kembali perlu diperlakukan sebagai pelanggan prioritas karena berpengaruh ke omzet berulang.';
    case 'supplier_debt':
      return 'Hutang supplier perlu dipantau supaya pasokan bahan servis tetap lancar dan relasi pembelian tidak terganggu.';
    default:
      return 'Saya membaca pola operasional yang paling berpengaruh ke layanan hari ini, lalu mengurutkan hal yang perlu ditangani lebih dulu.';
  }
}

_AiAnswer _buildAnswer(AiBusinessSnapshot snapshot, String id) {
  final activeDays = snapshot.salesForecast.dailyPoints
      .where((p) => p.transactionCount > 0)
      .length;
  final totalTransactions = snapshot.salesForecast.dailyPoints
      .fold<int>(0, (sum, point) => sum + point.transactionCount);
  final hasEnoughSales = activeDays >= 3 && totalTransactions >= 5;
  final hasStrongSales = activeDays >= 7 && totalTransactions >= 15;

  switch (id) {
    case 'learning':
      final profile = snapshot.learningProfile;
      return _AiAnswer(
        enoughData: profile.dataMaturity >= 40,
        title: 'Asisten AI sedang belajar dari pola servis',
        answer:
            '${profile.learningSummary} Saat ini saya membaca ${profile.totalTransactions} transaksi dari ${profile.activeSalesDays} hari aktif, ${profile.totalProducts} produk, dan ${profile.inventoryProducts} produk dengan manajemen stok. Level pemahaman saya: ${profile.level}, dengan kematangan data ${profile.dataMaturity}%.',
        reason:
            'Skor ini dihitung dari transaksi tersimpan, hari aktif penjualan, jumlah layanan atau produk, dan kelengkapan data stok. Semuanya dibaca offline dari database aplikasi.',
        recommendation: profile.missingSignals.isEmpty
            ? 'Data servis sudah sangat bagus. Pertahankan pencatatan order detail agar prediksi tetap tajam.'
            : 'Agar saya makin pintar, prioritas berikutnya: ${profile.missingSignals.first}.',
        metrics: [
          _AnswerMetric(label: 'Level', value: profile.level),
          _AnswerMetric(label: 'Maturity', value: '${profile.dataMaturity}%'),
          _AnswerMetric(
              label: 'Transaksi', value: '${profile.totalTransactions}'),
          _AnswerMetric(
              label: 'Hari aktif', value: '${profile.activeSalesDays}'),
        ],
        visual: _LearningVisual(profile: profile),
      );
    case 'forecast':
      final points = snapshot.salesForecast.dailyPoints.length > 14
          ? snapshot.salesForecast.dailyPoints
              .sublist(snapshot.salesForecast.dailyPoints.length - 14)
          : snapshot.salesForecast.dailyPoints;
      return _AiAnswer(
        enoughData: hasEnoughSales,
        title: hasEnoughSales
            ? 'Prediksi omzet besok sudah bisa dihitung'
            : 'Data transaksi belum cukup untuk prediksi yang kuat',
        answer: hasEnoughSales
            ? 'Berdasarkan pola penjualan harian, rata-rata 7 hari, dan faktor hari dalam minggu, saya memperkirakan omzet besok berada di kisaran ${_money(snapshot.salesForecast.tomorrowLow)} sampai ${_money(snapshot.salesForecast.tomorrowHigh)}. Tingkat keyakinan estimasi saat ini ${snapshot.salesForecast.confidence}%, jadi angka ini sebaiknya dipakai sebagai panduan operasional, bukan target mutlak.'
            : 'Saya menemukan data transaksi aktif baru $activeDays hari dengan $totalTransactions transaksi. Untuk prediksi omzet yang lebih profesional, idealnya tersedia minimal 3-7 hari transaksi. Saat ini saya tetap menampilkan angka awal, tetapi akurasinya masih rendah.',
        recommendation: hasEnoughSales
            ? 'Gunakan kisaran bawah untuk stok aman dan kisaran atas untuk target penjualan. Jika hari ini masih jauh di bawah rata-rata, cek stok produk terlaris sebelum jam ramai.'
            : 'Lanjutkan transaksi beberapa hari lagi. Setelah data cukup, prediksi akan otomatis menjadi lebih stabil tanpa internet.',
        metrics: [
          _AnswerMetric(
              label: 'Prediksi besok',
              value:
                  '${_money(snapshot.salesForecast.tomorrowLow)} - ${_money(snapshot.salesForecast.tomorrowHigh)}'),
          _AnswerMetric(
              label: 'Rata-rata 7 hari',
              value: _money(snapshot.salesForecast.average7Days)),
          _AnswerMetric(
              label: 'Keyakinan',
              value: '${snapshot.salesForecast.confidence}%'),
        ],
        visual: _BarChart(
          points: [
            for (final point in points)
              _ChartPoint(
                label: DateFormat('dd/MM').format(point.date),
                value: point.sales,
                tooltip: _money(point.sales),
                highlight: _isSameDay(point.date, DateTime.now()),
              ),
          ],
        ),
      );
    case 'today_sales':
      final todaySales = snapshot.salesForecast.todaySales;
      final average = snapshot.salesForecast.average7Days;
      final delta = average <= 0
          ? 0.0
          : ((todaySales - average) / average * 100).clamp(-999, 999);
      final isGood = todaySales >= average && average > 0;
      return _AiAnswer(
        enoughData: hasEnoughSales,
        title: average <= 0
            ? 'Omzet hari ini belum bisa dibandingkan'
            : isGood
                ? 'Omzet hari ini di atas rata-rata'
                : 'Omzet hari ini masih di bawah rata-rata',
        answer: average <= 0
            ? 'Saya belum punya rata-rata pembanding yang cukup. Omzet hari ini terbaca ${_money(todaySales)}, tetapi perlu transaksi beberapa hari agar penilaian bagus atau buruk lebih akurat.'
            : 'Omzet hari ini ${_money(todaySales)} dibanding rata-rata 7 hari ${_money(average)}. Selisihnya sekitar ${delta.toStringAsFixed(0)}%, sehingga kondisi hari ini ${isGood ? 'lebih kuat dari pola normal' : 'perlu didorong lagi sebelum servis tutup'}.',
        recommendation: isGood
            ? 'Pertahankan stok layanan dan bahan operasional cepat pakai sampai jam tutup.'
            : 'Cek layanan terlaris, tawarkan add-on servis yang relevan, dan pastikan kasir aktif menawarkan layanan tambahan.',
        metrics: [
          _AnswerMetric(label: 'Omzet hari ini', value: _money(todaySales)),
          _AnswerMetric(label: 'Rata-rata 7 hari', value: _money(average)),
          _AnswerMetric(
              label: 'Selisih', value: '${delta.toStringAsFixed(0)}%'),
        ],
        visual: _BarChart(
          points: [
            for (final point in snapshot.salesForecast.dailyPoints.skip(
                snapshot.salesForecast.dailyPoints.length > 7
                    ? snapshot.salesForecast.dailyPoints.length - 7
                    : 0))
              _ChartPoint(
                label: DateFormat('dd/MM').format(point.date),
                value: point.sales,
                tooltip: _money(point.sales),
                highlight: _isSameDay(point.date, DateTime.now()),
              ),
          ],
        ),
      );
    case 'weekly_outlook':
      return _AiAnswer(
        enoughData: hasEnoughSales,
        title: 'Proyeksi 7 hari ke depan',
        answer:
            'Dengan pola penjualan yang tersedia, estimasi omzet 7 hari ke depan adalah sekitar ${_money(snapshot.salesForecast.next7DaysForecast)}. Tren saat ini ${snapshot.salesForecast.trendPercent >= 0 ? 'naik' : 'turun'} ${snapshot.salesForecast.trendPercent.abs().toStringAsFixed(0)}% dibanding pembanding sebelumnya.',
        recommendation:
            'Gunakan angka ini untuk menyiapkan kapasitas layanan, stok bahan servis, dan batas belanja restock. Jika tren turun, fokuskan promo pada layanan yang perputarannya lambat.',
        metrics: [
          _AnswerMetric(
              label: 'Forecast 7 hari',
              value: _money(snapshot.salesForecast.next7DaysForecast)),
          _AnswerMetric(
              label: 'Trend',
              value:
                  '${snapshot.salesForecast.trendPercent.toStringAsFixed(0)}%'),
          _AnswerMetric(
              label: 'Keyakinan',
              value: '${snapshot.salesForecast.confidence}%'),
        ],
        visual: _LearningVisual(profile: snapshot.learningProfile),
      );
    case 'payment_methods':
      final entries = snapshot.paymentMethods.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));
      final total = entries.fold<int>(0, (sum, entry) => sum + entry.value);
      return _AiAnswer(
        enoughData: entries.isNotEmpty,
        title: entries.isEmpty
            ? 'Metode pembayaran belum terbaca'
            : 'Metode pembayaran dominan: ${entries.first.key}',
        answer: entries.isEmpty
            ? 'Saya belum menemukan transaksi bulan ini untuk membaca metode pembayaran.'
            : '${entries.first.key} menjadi metode pembayaran terbesar bulan ini dengan nilai ${_money(entries.first.value)}${total > 0 ? ' atau sekitar ${(entries.first.value / total * 100).toStringAsFixed(0)}% dari omzet tercatat' : ''}.',
        recommendation:
            'Pastikan metode pembayaran teratas selalu siap. Jika non-tunai dominan, cek QRIS/bank setiap awal shift agar transaksi tidak tertahan.',
        metrics: [
          _AnswerMetric(label: 'Metode terbaca', value: '${entries.length}'),
          _AnswerMetric(label: 'Total tercatat', value: _money(total)),
          _AnswerMetric(
              label: 'Terbesar',
              value: entries.isEmpty ? '-' : entries.first.key),
        ],
        visual: _ListVisual(
          items: [
            for (final entry in entries.take(6))
              _ListVisualItem(
                icon: Icons.payments_outlined,
                color: AppColors.iconTeal,
                title: entry.key,
                subtitle: total <= 0
                    ? 'Belum ada persentase'
                    : '${(entry.value / total * 100).toStringAsFixed(0)}% dari total metode pembayaran',
                value: _money(entry.value),
              ),
          ],
        ),
      );
    case 'top_products':
      final items = snapshot.topProducts;
      return _AiAnswer(
        enoughData: items.isNotEmpty,
        title: items.isNotEmpty
            ? 'Produk terlaris 30 hari terakhir'
            : 'Belum ada layanan terjual yang bisa dibaca',
        answer: items.isNotEmpty
            ? 'Layanan yang paling menonjol saat ini adalah ${items.first.productName}. Layanan ini mencatat ${items.first.totalQty} pcs dengan omzet ${_money(items.first.totalSales)} dalam 30 hari terakhir, sehingga layak ditampilkan lebih kuat di kasir, laporan, dan penawaran pelanggan.'
            : 'Saya belum menemukan layanan yang sudah terjual pada periode terbaru. Setelah transaksi layanan mulai tercatat, asisten akan otomatis menampilkan layanan yang paling kuat.',
        reason: items.isNotEmpty
            ? 'Saya menaruh layanan ini di posisi atas karena kontribusinya paling kuat dibanding layanan lain. Untuk usaha servis, sinyal seperti ini penting untuk menentukan stok bahan pendukung, paket promo, dan prioritas penawaran kasir.'
            : 'Begitu ada transaksi layanan, asisten akan mulai membaca layanan yang paling sering dipilih pelanggan dan yang paling berpengaruh ke omzet.',
        recommendation: items.isNotEmpty
            ? 'Tampilkan layanan terlaris di kasir dan pastikan stok bahan pendukungnya tidak mendekati minimum. Nomor 1-3 bisa dijadikan kandidat paket servis.'
            : 'Pastikan transaksi menyimpan item layanan, bukan hanya total pembayaran, agar analisis layanan bisa dibaca.',
        metrics: items.isEmpty
            ? const []
            : [
                _AnswerMetric(
                    label: 'Terlaris', value: items.first.productName),
                _AnswerMetric(
                    label: 'Terjual', value: '${items.first.totalQty} pcs'),
                _AnswerMetric(
                    label: 'Omzet', value: _money(items.first.totalSales)),
              ],
        visual: _ListVisual(
          items: [
            for (final item in items.take(6))
              _ListVisualItem(
                icon: Icons.local_fire_department_outlined,
                color: AppColors.iconOrange,
                title: item.productName,
                subtitle:
                    'Omzet ${_money(item.totalSales)} dari 30 hari terakhir',
                value: '${item.totalQty} pcs',
              ),
          ],
        ),
      );
    case 'profit_products':
      final items = snapshot.topProducts;
      return _AiAnswer(
        enoughData: items.isNotEmpty && hasEnoughSales,
        title: items.isEmpty
            ? 'Produk menguntungkan belum bisa dibaca'
            : 'Produk penyumbang omzet terbesar',
        answer: items.isEmpty
            ? 'Saya belum punya data item penjualan yang cukup untuk membaca produk penyumbang keuntungan.'
            : 'Dengan data offline yang tersedia, indikator terdekat untuk produk menguntungkan adalah penyumbang omzet terbesar. Produk teratas adalah ${items.first.productName} dengan omzet ${_money(items.first.totalSales)} dan kuantitas ${items.first.totalQty} pcs. Untuk analisis laba bersih yang lebih presisi, pastikan harga modal setiap produk selalu diisi benar.',
        recommendation:
            'Prioritaskan layanan penyumbang omzet terbesar dan stok bahan pendukungnya. Setelah harga modal rapi, analisis laba akan makin tajam.',
        metrics: [
          _AnswerMetric(label: 'Produk terbaca', value: '${items.length}'),
          _AnswerMetric(
              label: 'Omzet tertinggi',
              value: items.isEmpty ? '-' : _money(items.first.totalSales)),
          _AnswerMetric(label: 'Transaksi', value: '$totalTransactions'),
        ],
        visual: _ListVisual(
          items: [
            for (final item in items.take(6))
              _ListVisualItem(
                icon: Icons.insights_rounded,
                color: AppColors.success,
                title: item.productName,
                subtitle:
                    'Penyumbang omzet tinggi. Pastikan harga modal produk ini akurat.',
                value: _money(item.totalSales),
              ),
          ],
        ),
      );
    case 'restock':
      final items = snapshot.restockRecommendations;
      return _AiAnswer(
        enoughData: items.isNotEmpty || activeDays >= 3,
        title: items.isEmpty
            ? 'Belum ada restock mendesak'
            : 'Prioritas restock ditemukan',
        answer: items.isEmpty
            ? 'Dari stok minimum dan laju penjualan yang terbaca, belum ada produk yang masuk prioritas restock. Jika data transaksi masih sedikit, kesimpulan ini akan makin akurat setelah riwayat penjualan bertambah.'
            : 'Prioritas pertama adalah ${items.first.product.name}. Stoknya diperkirakan ${items.first.daysLeft >= 999 ? 'masih lambat bergerak tetapi mendekati batas minimum' : 'habis dalam ${items.first.daysLeft} hari'} dengan saran pembelian ${items.first.recommendedQty} ${items.first.product.unit}.',
        recommendation: items.isEmpty
            ? 'Tetap cek produk dengan stok fisik rendah. AI akan otomatis menaikkan prioritas ketika pola penjualan mulai terlihat.'
            : 'Buat PO dari bahan atau produk prioritas urgent dulu. Untuk item watch, tunggu konfirmasi stok fisik sebelum membeli banyak.',
        metrics: [
          _AnswerMetric(
              label: 'Perlu restock', value: '${items.length} produk'),
          _AnswerMetric(
              label: 'Urgent',
              value: '${items.where((e) => e.priority == 'urgent').length}'),
          _AnswerMetric(label: 'Hari aktif', value: '$activeDays hari'),
        ],
        visual: _ListVisual(
          items: [
            for (final item in items.take(6))
              _ListVisualItem(
                icon: Icons.inventory_2_outlined,
                color: item.priority == 'urgent'
                    ? AppColors.danger
                    : AppColors.warning,
                title: item.product.name,
                subtitle: item.reason,
                value: 'Beli ${item.recommendedQty}',
              ),
          ],
        ),
      );
    case 'inventory_value':
      final inventory = snapshot.inventoryAnalysis;
      final totalSkus = (inventory['total_skus'] as num?)?.toInt() ?? 0;
      final totalItems = (inventory['total_items'] as num?)?.toInt() ?? 0;
      final totalValue = (inventory['total_value'] as num?)?.toInt() ?? 0;
      final lowStock = (inventory['low_stock_count'] as num?)?.toInt() ?? 0;
      return _AiAnswer(
        enoughData: totalSkus > 0,
        title: totalSkus == 0
            ? 'Nilai stok belum tersedia'
            : 'Nilai aset stok terbaca',
        answer: totalSkus == 0
            ? 'Saya belum menemukan data produk untuk menghitung nilai gudang.'
            : 'Nilai stok gudang saat ini sekitar ${_money(totalValue)} dari $totalSkus SKU dan total $totalItems item. Ada $lowStock produk yang berada di bawah atau mendekati minimum stok.',
        recommendation:
            'Gunakan nilai stok ini sebagai batas kontrol modal bahan operasional. Jika nilai stok tinggi tetapi omzet rendah, cek item lambat bergerak dan kurangi pembelian berlebih.',
        metrics: [
          _AnswerMetric(label: 'Nilai stok', value: _money(totalValue)),
          _AnswerMetric(label: 'SKU', value: '$totalSkus'),
          _AnswerMetric(label: 'Stok rendah', value: '$lowStock'),
        ],
        visual: _ListVisual(
          items: [
            _ListVisualItem(
              icon: Icons.warehouse_outlined,
              color: AppColors.iconTeal,
              title: 'Total nilai gudang',
              subtitle: '$totalSkus SKU dengan total $totalItems item',
              value: _money(totalValue),
            ),
            _ListVisualItem(
              icon: Icons.warning_amber_rounded,
              color: lowStock > 0 ? AppColors.warning : AppColors.success,
              title: 'Produk stok rendah',
              subtitle: lowStock > 0
                  ? 'Perlu dicek sebelum jam ramai'
                  : 'Belum ada stok rendah',
              value: '$lowStock',
            ),
          ],
        ),
      );
    case 'stock_risk':
      final items = snapshot.restockRecommendations
          .where((item) => item.priority == 'urgent' || item.daysLeft <= 7)
          .toList();
      return _AiAnswer(
        enoughData: items.isNotEmpty || activeDays >= 3,
        title: items.isEmpty
            ? 'Belum ada risiko kehabisan minggu ini'
            : 'Produk rawan habis minggu ini',
        answer: items.isEmpty
            ? 'Saya belum melihat produk yang jelas rawan habis dalam minggu ini. Kesimpulan ini akan lebih kuat setelah data penjualan beberapa hari terkumpul.'
            : '${items.length} produk perlu dipantau. Prioritas pertama: ${items.first.product.name}, estimasi ${items.first.daysLeft >= 999 ? 'mendekati batas minimum' : 'habis dalam ${items.first.daysLeft} hari'}.',
        recommendation:
            'Cek stok fisik bahan atau produk prioritas, lalu restock bertahap. Jangan menunggu stok benar-benar kosong untuk item yang sering dipakai.',
        metrics: [
          _AnswerMetric(label: 'Rawan habis', value: '${items.length} produk'),
          _AnswerMetric(
              label: 'Urgent',
              value: '${items.where((e) => e.priority == 'urgent').length}'),
          _AnswerMetric(label: 'Hari aktif', value: '$activeDays hari'),
        ],
        visual: _ListVisual(
          items: [
            for (final item in items.take(6))
              _ListVisualItem(
                icon: Icons.production_quantity_limits_outlined,
                color: item.priority == 'urgent'
                    ? AppColors.danger
                    : AppColors.warning,
                title: item.product.name,
                subtitle: item.reason,
                value:
                    item.daysLeft >= 999 ? 'Pantau' : '${item.daysLeft} hari',
              ),
          ],
        ),
      );
    case 'bundling':
      final items = snapshot.crossSellRecommendations;
      return _AiAnswer(
        enoughData: items.isNotEmpty && hasStrongSales,
        title: items.isEmpty
            ? 'Pola bundling belum terbentuk'
            : 'Peluang bundling terbaik',
        answer: items.isNotEmpty && hasStrongSales
            ? 'Bundling paling kuat saat ini adalah ${items.first.productA} + ${items.first.productB}. Kombinasi ini muncul bersama ${items.first.togetherCount} kali dan polanya cukup konsisten untuk ditawarkan kasir saat checkout.'
            : 'Saya belum melihat pola produk yang sering dibeli bersama secara cukup konsisten. Untuk bundling, saya butuh transaksi berisi beberapa item produk dalam periode 30-60 hari.',
        recommendation: items.isNotEmpty
            ? 'Mulai dari bundling pertama dengan diskon kecil atau prompt kasir. Evaluasi lagi setelah beberapa hari transaksi.'
            : 'Dorong pencatatan item detail di setiap transaksi. Setelah pola keranjang terbentuk, rekomendasi bundling akan muncul otomatis.',
        metrics: [
          _AnswerMetric(label: 'Pola bundling', value: '${items.length}'),
          _AnswerMetric(label: 'Transaksi', value: '$totalTransactions'),
          _AnswerMetric(label: 'Data aktif', value: '$activeDays hari'),
        ],
        visual: _ListVisual(
          items: [
            for (final item in items.take(6))
              _ListVisualItem(
                icon: Icons.hub_outlined,
                color: AppColors.iconTeal,
                title: '${item.productA} + ${item.productB}',
                subtitle: item.suggestion,
                value: '${item.confidence}%',
              ),
          ],
        ),
      );
    case 'busy_hour':
      final items = snapshot.busyHours;
      return _AiAnswer(
        enoughData: items.isNotEmpty && hasEnoughSales,
        title: items.isEmpty
            ? 'Jam sibuk belum bisa dibaca'
            : 'Jam operasional paling ramai',
        answer: items.isNotEmpty && hasEnoughSales
            ? 'Jam tersibuk servis saat ini adalah ${items.first.label}. Dalam 30 hari terakhir, jam ini mencatat ${items.first.transactionCount} transaksi dengan omzet ${_money(items.first.totalSales)}. Ini waktu yang paling perlu dijaga untuk kasir, kesiapan workshop, dan kecepatan layanan.'
            : 'Data transaksi per jam belum cukup. Saya butuh transaksi dari beberapa hari berbeda agar jam sibuk tidak bias oleh satu hari saja.',
        recommendation: items.isNotEmpty
            ? 'Hindari input stok besar, opname, atau pergantian kasir pada jam utama. Siapkan layanan dan bahan cepat pakai sebelum jam tersebut.'
            : 'Terus gunakan POS saat transaksi. Jam sibuk akan muncul otomatis setelah pola waktu terbaca.',
        metrics: [
          _AnswerMetric(
              label: 'Jam teratas',
              value: items.isEmpty ? '-' : items.first.label),
          _AnswerMetric(
              label: 'Transaksi jam top',
              value: items.isEmpty ? '0' : '${items.first.transactionCount}'),
          _AnswerMetric(label: 'Hari aktif', value: '$activeDays hari'),
        ],
        visual: _BarChart(
          color: AppColors.iconTeal,
          points: [
            for (final item in items.take(8))
              _ChartPoint(
                label: item.hour.toString().padLeft(2, '0'),
                value: item.transactionCount,
                tooltip: '${item.transactionCount} transaksi',
                highlight: item == items.first,
              ),
          ],
        ),
      );
    case 'overdue_orders':
      final ops = snapshot.servisOperations;
      final items = ops.overdueDetails;
      return _AiAnswer(
        enoughData: ops.activeOrders > 0,
        title: ops.overdueOrders == 0
            ? 'Tidak ada order melewati estimasi'
            : 'Ada order yang berisiko komplain',
        answer: ops.overdueOrders == 0
            ? 'Saya tidak menemukan order aktif yang melewati estimasi pengambilan. Kondisi operasional aman dari sisi keterlambatan.'
            : '${ops.overdueOrders} order aktif sudah melewati estimasi. Prioritas pertama adalah ${items.isEmpty ? 'cek daftar status' : items.first.customerName}, status ${items.isEmpty ? '-' : items.first.status}, terlambat sekitar ${items.isEmpty ? '-' : _minutesLabel(items.first.minutesDelta)}.',
        recommendation: ops.overdueOrders == 0
            ? 'Pertahankan kebiasaan update status dan estimasi pengambilan agar risiko telat tetap terbaca.'
            : 'Urutkan pekerjaan dari estimasi terlama, cek fisik di workshop/rak, lalu hubungi pelanggan jika order sudah siap ambil.',
        metrics: [
          _AnswerMetric(label: 'Order aktif', value: '${ops.activeOrders}'),
          _AnswerMetric(label: 'Terlambat', value: '${ops.overdueOrders}'),
          _AnswerMetric(label: 'Siap ambil', value: '${ops.readyForPickup}'),
        ],
        visual: _ListVisual(
          items: [
            for (final item in items.take(6))
              _ListVisualItem(
                icon: Icons.timer_off_outlined,
                color: AppColors.danger,
                title: item.customerName,
                subtitle:
                    '${item.status} - ${item.orderType} - ${DateFormat('dd/MM HH:mm').format(item.pickupSchedule)}',
                value: _minutesLabel(item.minutesDelta),
              ),
          ],
        ),
      );
    case 'pickup_queue':
      final ops = snapshot.servisOperations;
      final dueSoon = ops.dueSoonDetails;
      return _AiAnswer(
        enoughData: ops.activeOrders > 0,
        title: 'Antrian pickup dan finishing',
        answer:
            'Saat ini ada ${ops.activeOrders} order aktif, ${ops.readyForPickup} siap ambil, dan ${ops.dueSoonOrders} order jatuh tempo dalam 4 jam. Status dominan saat ini: ${ops.dominantStatus}.',
        recommendation: ops.dueSoonOrders > 0
            ? 'Dahulukan finishing dan QC untuk order jatuh tempo terdekat, lalu pisahkan order siap ambil agar pencarian cepat saat pelanggan datang.'
            : 'Gunakan waktu longgar untuk packing order siap ambil dan merapikan rak berdasarkan invoice atau nama pelanggan.',
        metrics: [
          _AnswerMetric(label: 'Aktif', value: '${ops.activeOrders}'),
          _AnswerMetric(label: 'Siap ambil', value: '${ops.readyForPickup}'),
          _AnswerMetric(label: 'Tempo <4j', value: '${ops.dueSoonOrders}'),
        ],
        visual: _ListVisual(
          items: dueSoon.isEmpty
              ? [
                  for (final entry in _sortedEntries(ops.statusCounts).take(6))
                    _ListVisualItem(
                      icon: Icons.handyman_outlined,
                      color: AppColors.iconTeal,
                      title: entry.key,
                      subtitle: 'Distribusi status order 90 hari terakhir',
                      value: '${entry.value}',
                    ),
                ]
              : [
                  for (final item in dueSoon.take(6))
                    _ListVisualItem(
                      icon: Icons.fact_check_outlined,
                      color: AppColors.warning,
                      title: item.customerName,
                      subtitle:
                          '${item.status} - ${item.orderType} - ${DateFormat('dd/MM HH:mm').format(item.pickupSchedule)}',
                      value: _minutesLabel(-item.minutesDelta),
                    ),
                ],
        ),
      );
    case 'service_mix':
      final ops = snapshot.servisOperations;
      final services = _sortedEntries(ops.serviceTypes);
      return _AiAnswer(
        enoughData: services.isNotEmpty,
        title: services.isEmpty
            ? 'Komposisi layanan belum terbaca'
            : 'Layanan dominan: ${services.first.key}',
        answer: services.isEmpty
            ? 'Saya belum menemukan data tipe layanan yang cukup. Isi tipe layanan seperti Reguler, Express, Delivery, atau Ambil Sendiri agar komposisi operasional terbaca.'
            : '${services.first.key} adalah layanan paling dominan dengan ${services.first.value} order dalam data terakhir. AI juga membaca rata-rata estimasi pengerjaan ${ops.averagePlannedHours == 0 ? 'belum tersedia' : '${ops.averagePlannedHours} jam'}.',
        recommendation:
            'Gunakan komposisi layanan untuk mengatur kapasitas mesin, perbaikan, packing, dan harga express/reguler.',
        metrics: [
          _AnswerMetric(label: 'Jenis layanan', value: '${services.length}'),
          _AnswerMetric(
              label: 'Dominan',
              value: services.isEmpty ? '-' : services.first.key),
          _AnswerMetric(
              label: 'Estimasi rata-rata',
              value: ops.averagePlannedHours == 0
                  ? '-'
                  : '${ops.averagePlannedHours}j'),
        ],
        visual: _ListVisual(
          items: [
            for (final entry in services.take(6))
              _ListVisualItem(
                icon: Icons.handyman_outlined,
                color: AppColors.primaryBrand,
                title: entry.key,
                subtitle: 'Komposisi order berdasarkan tipe layanan',
                value: '${entry.value}',
              ),
          ],
        ),
      );
    case 'express_load':
      final ops = snapshot.servisOperations;
      final ratio = ops.activeOrders == 0
          ? 0
          : ((ops.expressActiveOrders / ops.activeOrders) * 100).round();
      return _AiAnswer(
        enoughData: ops.activeOrders > 0,
        title:
            ratio >= 35 ? 'Beban express tinggi' : 'Beban express masih aman',
        answer:
            '${ops.expressActiveOrders} dari ${ops.activeOrders} order aktif adalah express/ekspres ($ratio%). ${ratio >= 35 ? 'Ini sudah cukup tinggi dan bisa mengganggu order reguler jika kapasitas workshop tidak dipisah.' : 'Beban cepat masih relatif aman selama estimasi pickup tetap dipantau.'}',
        recommendation: ratio >= 35
            ? 'Batasi penerimaan express baru, amankan slot mesin/perbaikan, dan cek order yang jatuh tempo dekat.'
            : 'Tetap beri label visual untuk express agar tidak tercampur dengan antrian reguler.',
        metrics: [
          _AnswerMetric(
              label: 'Express aktif', value: '${ops.expressActiveOrders}'),
          _AnswerMetric(label: 'Order aktif', value: '${ops.activeOrders}'),
          _AnswerMetric(label: 'Rasio', value: '$ratio%'),
        ],
        visual: _ListVisual(
          items: [
            for (final entry in _sortedEntries(ops.serviceTypes).take(6))
              _ListVisualItem(
                icon: entry.key.toLowerCase().contains('express') ||
                        entry.key.toLowerCase().contains('ekspres')
                    ? Icons.flash_on_outlined
                    : Icons.schedule_outlined,
                color: entry.key.toLowerCase().contains('express') ||
                        entry.key.toLowerCase().contains('ekspres')
                    ? AppColors.warning
                    : AppColors.iconTeal,
                title: entry.key,
                subtitle: 'Beban layanan aktif dan historis',
                value: '${entry.value}',
              ),
          ],
        ),
      );
    case 'kelengkapan':
      final ops = snapshot.servisOperations;
      final kelengkapans = _sortedEntries(ops.kelengkapanCounts);
      return _AiAnswer(
        enoughData: kelengkapans.isNotEmpty,
        title: kelengkapans.isEmpty
            ? 'Preferensi parfum belum terbaca'
            : 'Parfum favorit: ${kelengkapans.first.key}',
        answer: kelengkapans.isEmpty
            ? 'Saya belum menemukan catatan parfum yang cukup. Jika parfum dicatat di order, AI bisa membaca favorit pelanggan dan membantu stok parfum.'
            : '${kelengkapans.first.key} paling sering dipilih dengan ${kelengkapans.first.value} order. Data ini bisa dipakai untuk prioritas stok parfum dan rekomendasi ke pelanggan baru.',
        recommendation:
            'Pastikan pilihan parfum diinput konsisten. Stok parfum favorit sebaiknya tidak menunggu habis karena langsung memengaruhi pengalaman pelanggan.',
        metrics: [
          _AnswerMetric(label: 'Varian terbaca', value: '${kelengkapans.length}'),
          _AnswerMetric(
              label: 'Favorit',
              value: kelengkapans.isEmpty ? '-' : kelengkapans.first.key),
          _AnswerMetric(label: 'Order aktif', value: '${ops.activeOrders}'),
        ],
        visual: _ListVisual(
          items: [
            for (final entry in kelengkapans.take(6))
              _ListVisualItem(
                icon: Icons.spa_outlined,
                color: AppColors.iconPurple,
                title: entry.key,
                subtitle: 'Preferensi parfum dari transaksi servis',
                value: '${entry.value}',
              ),
          ],
        ),
      );
    case 'price':
      final items = snapshot.priceSuggestions;
      return _AiAnswer(
        enoughData: items.isNotEmpty || snapshot.topProducts.isNotEmpty,
        title: items.isEmpty
            ? 'Harga terlihat aman'
            : 'Ada peluang penyesuaian harga',
        answer: items.isEmpty
            ? 'Saya belum menemukan harga yang perlu segera diubah. Tidak ada sinyal kuat harga jual di bawah modal, margin terlalu tipis pada produk laku, atau produk lambat yang butuh promo ringan.'
            : 'Ada ${items.length} produk yang layak ditinjau. Contoh terkuat adalah ${items.first.product.name}: harga saat ini ${_money(items.first.currentPrice)}, saran saya ${_money(items.first.suggestedPrice)}. Alasannya: ${items.first.reason}',
        recommendation: items.isEmpty
            ? 'Pertahankan harga saat ini, lalu cek ulang setelah data penjualan bertambah atau harga modal berubah.'
            : 'Jangan ubah semua harga sekaligus. Mulai dari 1-3 produk, lalu pantau perubahan omzet dan jumlah transaksi.',
        metrics: [
          _AnswerMetric(label: 'Saran harga', value: '${items.length} produk'),
          _AnswerMetric(
              label: 'Produk terlaris',
              value: '${snapshot.topProducts.length}'),
          _AnswerMetric(label: 'Hari aktif', value: '$activeDays hari'),
        ],
        visual: _ListVisual(
          items: [
            for (final item in items.take(6))
              _ListVisualItem(
                icon: Icons.sell_outlined,
                color: AppColors.iconPurple,
                title: item.product.name,
                subtitle: item.reason,
                value: _money(item.suggestedPrice),
              ),
          ],
        ),
      );
    case 'top_customers':
      final customers = snapshot.topCustomers;
      return _AiAnswer(
        enoughData: customers.isNotEmpty,
        title: customers.isEmpty
            ? 'Pola pelanggan belum terbaca'
            : 'Pelanggan terbaik terbaca',
        answer: customers.isEmpty
            ? 'Saya belum menemukan transaksi dengan pelanggan terdaftar. Jika transaksi masih menggunakan pelanggan umum, saya belum bisa membaca pelanggan paling bernilai.'
            : 'Pelanggan teratas saat ini adalah ${customers.first['customer_name'] ?? 'Pelanggan'} dengan total belanja ${_money((customers.first['total_spending'] as num?)?.toInt() ?? 0)} dari ${(customers.first['transaction_count'] as num?)?.toInt() ?? 0} transaksi.',
        recommendation:
            'Gunakan data pelanggan terbaik untuk promo personal, reminder stok favorit, atau prioritas layanan. Pastikan kasir memilih nama pelanggan saat transaksi.',
        metrics: [
          _AnswerMetric(
              label: 'Pelanggan terbaca', value: '${customers.length}'),
          _AnswerMetric(
              label: 'Belanja tertinggi',
              value: customers.isEmpty
                  ? '-'
                  : _money(
                      (customers.first['total_spending'] as num?)?.toInt() ??
                          0)),
          _AnswerMetric(label: 'Transaksi', value: '$totalTransactions'),
        ],
        visual: _ListVisual(
          items: [
            for (final item in customers.take(5))
              _ListVisualItem(
                icon: Icons.people_alt_outlined,
                color: AppColors.iconTeal,
                title: '${item['customer_name'] ?? 'Pelanggan'}',
                subtitle:
                    '${(item['transaction_count'] as num?)?.toInt() ?? 0} transaksi tercatat',
                value: _money((item['total_spending'] as num?)?.toInt() ?? 0),
              ),
          ],
        ),
      );
    case 'piutang_risk':
      final piutangAlerts = snapshot.anomalyAlerts
          .where((item) => item.title.toLowerCase().contains('piutang'))
          .toList();
      return _AiAnswer(
        enoughData: piutangAlerts.isNotEmpty || totalTransactions > 0,
        title: piutangAlerts.isEmpty
            ? 'Piutang belum menunjukkan risiko besar'
            : 'Ada piutang yang perlu ditagih',
        answer: piutangAlerts.isEmpty
            ? 'Saya belum menemukan sinyal piutang lama yang perlu diprioritaskan. Jika ada piutang baru, pastikan jatuh tempo dan pelanggan dicatat agar reminder lebih akurat.'
            : '${piutangAlerts.length} sinyal piutang perlu dicek. Prioritas pertama: ${piutangAlerts.first.message}',
        recommendation: piutangAlerts.isEmpty
            ? 'Gunakan jatuh tempo dan reminder WhatsApp agar piutang tidak menumpuk.'
            : piutangAlerts.first.action,
        metrics: [
          _AnswerMetric(
              label: 'Alert piutang', value: '${piutangAlerts.length}'),
          _AnswerMetric(
              label: 'Total alert', value: '${snapshot.anomalyAlerts.length}'),
          _AnswerMetric(label: 'Data aktif', value: '$activeDays hari'),
        ],
        visual: _ListVisual(
          items: [
            for (final item in piutangAlerts.take(5))
              _ListVisualItem(
                icon: Icons.request_quote_outlined,
                color: item.severity == 'danger'
                    ? AppColors.danger
                    : AppColors.warning,
                title: item.title,
                subtitle: item.message,
                value: item.severity.toUpperCase(),
              ),
          ],
        ),
      );
    case 'supplier_debt':
      final debts = snapshot.supplierDebts;
      final totalDebt = debts.fold<int>(
          0, (sum, item) => sum + ((item['hutang'] as num?)?.toInt() ?? 0));
      return _AiAnswer(
        enoughData: debts.isNotEmpty,
        title: debts.isEmpty
            ? 'Tidak ada hutang supplier tercatat'
            : 'Hutang supplier perlu dipantau',
        answer: debts.isEmpty
            ? 'Saya belum menemukan hutang supplier aktif. Jika pembelian bahan atau produk lewat PO belum lunas, data hutang akan muncul otomatis di sini.'
            : 'Total hutang supplier tercatat ${_money(totalDebt)}. Prioritas terbesar adalah ${debts.first['name'] ?? 'Supplier'} dengan hutang ${_money((debts.first['hutang'] as num?)?.toInt() ?? 0)}.',
        recommendation:
            'Prioritaskan pembayaran supplier terbesar atau supplier produk cepat laku agar pasokan tidak terganggu.',
        metrics: [
          _AnswerMetric(label: 'Supplier hutang', value: '${debts.length}'),
          _AnswerMetric(label: 'Total hutang', value: _money(totalDebt)),
          _AnswerMetric(
              label: 'Terbesar',
              value: debts.isEmpty ? '-' : '${debts.first['name'] ?? '-'}'),
        ],
        visual: _ListVisual(
          items: [
            for (final item in debts.take(5))
              _ListVisualItem(
                icon: Icons.local_shipping_outlined,
                color: AppColors.warning,
                title: '${item['name'] ?? 'Supplier'}',
                subtitle: '${item['phone'] ?? ''}',
                value: _money((item['hutang'] as num?)?.toInt() ?? 0),
              ),
          ],
        ),
      );
    case 'risk':
      final alerts = snapshot.anomalyAlerts;
      final serious = alerts
          .where((a) => a.severity == 'danger' || a.severity == 'warning')
          .toList();
      return _AiAnswer(
        enoughData: alerts.isNotEmpty,
        title: serious.isEmpty
            ? 'Tidak ada risiko besar'
            : 'Ada sinyal yang perlu dicek',
        answer: serious.isEmpty
            ? 'Saya tidak menemukan anomali besar dari stok, harga, piutang, dan penurunan omzet. Kondisi ini terlihat stabil berdasarkan aturan offline yang tersedia.'
            : 'Saya menemukan ${serious.length} sinyal penting. Yang paling perlu dicek adalah: ${serious.first.title}. ${serious.first.message}',
        recommendation: serious.isEmpty
            ? 'Tetap pantau restock dan laporan harian. Risiko bisa berubah ketika transaksi baru masuk.'
            : serious.first.action,
        metrics: [
          _AnswerMetric(label: 'Total alert', value: '${alerts.length}'),
          _AnswerMetric(label: 'Penting', value: '${serious.length}'),
          _AnswerMetric(label: 'Skor servis', value: '${snapshot.healthScore}'),
        ],
        visual: _ListVisual(
          items: [
            for (final item in alerts.take(6))
              _ListVisualItem(
                icon: item.severity == 'danger'
                    ? Icons.priority_high_rounded
                    : item.severity == 'warning'
                        ? Icons.warning_amber_rounded
                        : Icons.info_outline_rounded,
                color: item.severity == 'danger'
                    ? AppColors.danger
                    : item.severity == 'warning'
                        ? AppColors.warning
                        : AppColors.info,
                title: item.title,
                subtitle: item.message,
                value: item.severity.toUpperCase(),
              ),
          ],
        ),
      );
    default:
      return _AiAnswer(
        enoughData: hasEnoughSales,
        title: 'Kondisi servis saat ini',
        answer: hasEnoughSales
            ? snapshot.executiveSummary
            : 'Data transaksi masih terbatas. Saya tetap bisa membaca stok, harga, dan alert dasar, tetapi analisis tren penjualan akan lebih akurat setelah transaksi beberapa hari terkumpul.',
        recommendation: hasEnoughSales
            ? 'Fokus hari ini: cek alert penting, pastikan bahan prioritas tidak kosong, dan manfaatkan jam ramai.'
            : 'Gunakan aplikasi untuk mencatat transaksi detail. Setelah data cukup, jawaban AI akan otomatis lebih tajam.',
        metrics: [
          _AnswerMetric(label: 'Skor servis', value: '${snapshot.healthScore}'),
          _AnswerMetric(label: 'Data aktif', value: '$activeDays hari'),
          _AnswerMetric(label: 'Transaksi', value: '$totalTransactions'),
        ],
        visual: _BarChart(
          points: [
            for (final point in snapshot.salesForecast.dailyPoints.skip(
                snapshot.salesForecast.dailyPoints.length > 7
                    ? snapshot.salesForecast.dailyPoints.length - 7
                    : 0))
              _ChartPoint(
                label: DateFormat('dd/MM').format(point.date),
                value: point.sales,
                tooltip: _money(point.sales),
                highlight: _isSameDay(point.date, DateTime.now()),
              ),
          ],
        ),
      );
  }
}

TextStyle _titleStyle() => GoogleFonts.plusJakartaSans(
      fontSize: 16,
      fontWeight: FontWeight.w900,
      color: AppColors.textTitle,
    );

TextStyle _itemTitleStyle() => GoogleFonts.plusJakartaSans(
      fontSize: 13,
      fontWeight: FontWeight.w800,
      color: AppColors.textTitle,
    );

TextStyle _bodyStyle() => GoogleFonts.plusJakartaSans(
      fontSize: 14,
      height: 1.55,
      fontWeight: FontWeight.w600,
      color: AppColors.textBody,
    );

TextStyle _captionStyle({
  Color color = AppColors.textCaption,
  FontWeight weight = FontWeight.w600,
}) =>
    GoogleFonts.plusJakartaSans(
      fontSize: 12,
      height: 1.35,
      fontWeight: weight,
      color: color,
    );

String _money(int value) =>
    'Rp${NumberFormat.decimalPattern('id').format(value)}';

String _minutesLabel(int minutes) {
  final value = minutes.abs();
  if (value >= 1440) {
    final days = (value / 1440).floor();
    final hours = ((value % 1440) / 60).floor();
    return hours > 0 ? '${days}h ${hours}j' : '${days}h';
  }
  if (value >= 60) {
    final hours = (value / 60).floor();
    final mins = value % 60;
    return mins > 0 ? '${hours}j ${mins}m' : '${hours}j';
  }
  return '${value}m';
}

List<MapEntry<String, int>> _sortedEntries(Map<String, int> values) {
  final entries = values.entries.toList()
    ..sort((a, b) => b.value.compareTo(a.value));
  return entries;
}

bool _isSameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

String _dayKey(DateTime date) =>
    '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

extension _FirstOrNullExtension<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}

