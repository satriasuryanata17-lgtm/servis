import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../models/db_models.dart';
import '../services/export_service.dart';
import 'detail_stok_screen.dart';
import '../core/theme.dart';
import '../widgets/export_dropdown.dart';

const Color _kBrand = AppColors.primaryBrand;

bool _isWide(BuildContext ctx) {
  final mq = MediaQuery.of(ctx);
  return mq.size.width >= 720 ||
      (mq.orientation == Orientation.landscape && mq.size.width >= 600);
}

double _sidebarW(BuildContext ctx) {
  final mq = MediaQuery.of(ctx);
  final w = mq.size.width;
  final isLandscapePhone =
      mq.orientation == Orientation.landscape && mq.size.shortestSide < 600;
  if (w >= 1200) return 440;
  if (w >= 900) return 380;
  // landscape phone: sidebar 38% lebar layar, max 300
  if (isLandscapePhone) return (w * 0.38).clamp(240.0, 300.0);
  return 340;
}

class GudangLaporanScreen extends ConsumerStatefulWidget {
  const GudangLaporanScreen({super.key});

  @override
  ConsumerState<GudangLaporanScreen> createState() =>
      _GudangLaporanScreenState();
}

class _GudangLaporanScreenState extends ConsumerState<GudangLaporanScreen>
    with SingleTickerProviderStateMixin {
  String _search = '';
  Product? _selectedProduct;
  int _selectedTab = 0;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) return;
      setState(() {
        _selectedTab = _tabController.index;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  String _fRp(int v) {
    if (v == 0) return 'Rp0';
    String s = v.toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return 'Rp$r';
  }

  String _fDate(String? d) {
    if (d == null || d.isEmpty) return '-';
    try {
      final dt = DateTime.parse(d);
      const m = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'Mei',
        'Jun',
        'Jul',
        'Agu',
        'Sep',
        'Okt',
        'Nov',
        'Des'
      ];
      return '${dt.day} ${m[dt.month - 1]} ${dt.year}';
    } catch (_) {
      return d;
    }
  }

  Future<void> _openDetailStok(BuildContext ctx, Product p, bool wide) async {
    if (wide) {
      setState(() => _selectedProduct = p);
    } else {
      await Navigator.push(
        ctx,
        MaterialPageRoute(builder: (_) => DetailStokScreen(product: p)),
      );
      if (mounted) setState(() {});
    }
  }

  Future<void> _exportData(List<Product> products) async {
    final choice = await ExportDropdown.show(context);
    if (choice == null) return;
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);

    if (products.isEmpty) {
      messenger.showSnackBar(const SnackBar(
        content: Text('Belum ada data gudang untuk diekspor.'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
      return;
    }

    final lowStock =
        products.where((p) => p.minStock > 0 && p.stock <= p.minStock).length;
    final totalStok = products.fold<int>(0, (s, p) => s + p.stock);
    final nilaiStok = products.fold<int>(0, (s, p) => s + p.stock * p.buyPrice);

    final Map<String, String> summaryData = {
      'Total Produk': '${products.length} Item',
      'Stok Menipis': '$lowStock Item',
      'Total Unit': '$totalStok',
      'Nilai Stok': _fRp(nilaiStok),
    };

    final headers = ['Nama Produk', 'Stok', 'Software', 'Harga Jual', 'Subtotal'];
    final rows = products
        .map((p) => [
              p.name,
              p.stock,
              p.unit,
              _fRp(p.sellPrice),
              _fRp(p.stock * p.sellPrice),
            ])
        .toList();

    const title = 'Laporan Stok Gudang';

    try {
      if (choice == 'csv') {
        await ExportService.exportAndShareCsv(
          filePrefix: 'laporan_gudang',
          headers: const [
            'ID',
            'Nama Produk',
            'Stok',
            'Min Stok',
            'Harga Beli',
            'Harga Jual',
            'Software',
            'Tanggal Input',
          ],
          rows: products
              .map((p) => [
                    p.id,
                    p.name,
                    p.stock,
                    p.minStock,
                    p.buyPrice,
                    p.sellPrice,
                    p.unit,
                    p.createdAt ?? '',
                  ])
              .toList(),
          subject: 'Ekspor Laporan Gudang',
          message: 'Data gudang dari Juragan Servis.',
        );
      } else if (choice == 'pdf') {
        await ExportService.exportPdfLaporan(
          title: title,
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      } else if (choice == 'print') {
        await ExportService.printPdfLaporan(
          title: title,
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      }
    } catch (e) {
      if (!mounted) return;
      messenger.showSnackBar(
        const SnackBar(
            content:
                Text('Gagal mengekspor laporan gudang. Silakan coba lagi.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productsProvider);
    final sLower = _search.toLowerCase();
    var filteredBase = _search.isEmpty
        ? products
        : products
            .where((p) =>
                p.name.toLowerCase().contains(sLower) ||
                p.unit.toLowerCase().contains(sLower) ||
                (p.sku?.toLowerCase().contains(sLower) ?? false) ||
                (p.barcode?.toLowerCase().contains(sLower) ?? false))
            .toList();

    var filteredLow = filteredBase.where((p) => p.stock <= p.minStock).toList();
    var filtered = _selectedTab == 0 ? filteredBase : filteredLow;

    return LayoutBuilder(builder: (ctx, constraints) {
      final wide = _isWide(ctx);
      return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(children: [
            _buildHeader(ctx, filtered, wide),
            const Divider(height: 1, color: Color(0xFFEEEEEE)),
            TabBar(
              controller: _tabController,
              labelColor: _kBrand,
              unselectedLabelColor: Colors.black54,
              indicatorColor: _kBrand,
              indicatorWeight: 2,
              tabs: const [
                Tab(text: 'Semua Stok'),
                Tab(text: 'Stok Menipis'),
              ],
            ),
            const Divider(height: 1, color: Color(0xFFEEEEEE)),
            if (wide && MediaQuery.of(context).size.shortestSide >= 600)
              _buildStatsBar(products),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  wide
                      ? _buildWideBody(ctx, filteredBase)
                      : _buildNarrowBody(ctx, filteredBase),
                  wide
                      ? _buildWideBody(ctx, filteredLow)
                      : _buildNarrowBody(ctx, filteredLow),
                ],
              ),
            ),
          ]),
        ),
      );
    });
  }

  Widget _buildHeader(BuildContext ctx, List<Product> filtered, bool wide) {
    final mq = MediaQuery.of(ctx);
    final isLandscapePhone =
        mq.orientation == Orientation.landscape && mq.size.shortestSide < 600;
    final vPad = isLandscapePhone ? 8.0 : 12.0;

    return Padding(
      padding: EdgeInsets.fromLTRB(8, vPad, 12, vPad),
      child: Row(children: [
        IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: _kBrand, size: 20),
          onPressed: () => Navigator.pop(ctx),
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
        ),
        const SizedBox(width: 8),
        if (!wide)
          Expanded(
            child: Text('Gudang',
                style: TextStyle(
                    fontSize: isLandscapePhone ? 16 : 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87)),
          )
        else ...[
          Text('Gudang',
              style: TextStyle(
                  fontSize: isLandscapePhone ? 16 : 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87)),
          const SizedBox(width: 20),
          Expanded(child: _buildSearchBar(compact: true, inHeader: true)),
          const SizedBox(width: 16),
        ],
        _ProExportBtn(onTap: () => _exportData(filtered)),
      ]),
    );
  }

  Widget _buildStatsBar(List<Product> products) {
    final totalProduk = products.length;
    final lowStock =
        products.where((p) => p.minStock > 0 && p.stock <= p.minStock).length;
    final totalStok = products.fold<int>(0, (s, p) => s + p.stock);
    final nilaiStok = products.fold<int>(0, (s, p) => s + p.stock * p.buyPrice);

    return Container(
      color: const Color(0xFFF9FAFB),
      child: Row(children: [
        _StatCell('Total Produk', totalProduk.toString(),
            Icons.inventory_2_outlined, Colors.black87),
        _StatCell(
            'Stok Menipis',
            lowStock.toString(),
            Icons.warning_amber_rounded,
            lowStock > 0 ? const Color(0xFFE53935) : Colors.black45),
        _StatCell('Total Unit', totalStok.toString(), Icons.warehouse_outlined,
            _kBrand),
        _StatCell('Nilai Stok', _fRp(nilaiStok), Icons.payments_outlined,
            Colors.teal),
      ]),
    );
  }

  Widget _buildWideBody(BuildContext ctx, List<Product> filtered) {
    final sw = _sidebarW(ctx);
    final mq = MediaQuery.of(ctx);
    final isLandscapePhone =
        mq.orientation == Orientation.landscape && mq.size.shortestSide < 600;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // LEFT: product list
        SafeArea(
          right: false,
          top: false,
          child: SizedBox(
            width: sw,
            child: Column(children: [
              Expanded(child: _buildProductList(ctx, filtered, wide: true)),
              _buildHistoryBtn(compact: isLandscapePhone),
            ]),
          ),
        ),
        const VerticalDivider(width: 1, color: Color(0xFFEEEEEE)),
        // RIGHT: detail panel
        Expanded(
          child: SafeArea(
            left: false,
            top: false,
            child: _selectedProduct == null
                ? _buildDetailPlaceholder()
                : DetailStokScreen(
                    key: ValueKey(_selectedProduct!.id),
                    product: _selectedProduct!,
                    embedded: true,
                  ),
          ),
        ),
      ],
    );
  }

  Widget _buildNarrowBody(BuildContext ctx, List<Product> filtered) {
    return Column(children: [
      _buildSearchBar(),
      const SizedBox(height: 8),
      Expanded(child: _buildProductList(ctx, filtered, wide: false)),
      _buildHistoryBtn(),
    ]);
  }

  Widget _buildSearchBar({bool compact = false, bool inHeader = false}) {
    final height = compact ? 38.0 : 44.0;
    final fontSize = compact ? 12.5 : 13.5;
    return Padding(
      padding: EdgeInsets.fromLTRB(
          inHeader ? 0 : 16, compact ? 6 : 8, inHeader ? 0 : 16, 0),
      child: Container(
        height: height,
        decoration: const BoxDecoration(
          color: Color(0xFFF5F5F5),
          borderRadius: BorderRadius.zero,
        ),
        child: TextField(
          onChanged: (v) => setState(() => _search = v),
          decoration: InputDecoration(
            hintText: 'Cari Nama/SKU/Barcode',
            hintStyle: TextStyle(color: Colors.black38, fontSize: fontSize),
            prefixIcon:
                const Icon(Icons.search, color: Colors.black38, size: 20),
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(vertical: compact ? 9 : 12),
          ),
        ),
      ),
    );
  }

  Widget _buildProductList(BuildContext ctx, List<Product> filtered,
      {required bool wide}) {
    if (filtered.isEmpty) {
      return const Center(
          child: Text('Belum ada produk',
              style: TextStyle(color: Colors.black45)));
    }
    return ListView.separated(
      itemCount: filtered.length,
      separatorBuilder: (_, __) =>
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
      itemBuilder: (c, i) {
        final p = filtered[i];
        final selected = wide && _selectedProduct?.id == p.id;
        return _ProductTile(
          product: p,
          formatRp: _fRp,
          formatDate: _fDate,
          selected: selected,
          compact: wide,
          onDetailTap: () => _openDetailStok(ctx, p, wide),
        );
      },
    );
  }

  Widget _buildHistoryBtn({bool compact = false}) {
    return Padding(
      padding: EdgeInsets.all(compact ? 10 : 16),
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: () =>
              Navigator.pushNamed(context, '/laporan/riwayat_stok'),
          style: ElevatedButton.styleFrom(
            backgroundColor: _kBrand,
            foregroundColor: Colors.white,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            padding: EdgeInsets.symmetric(vertical: compact ? 10 : 14),
          ),
          child: Text('Lihat Riwayat Stok',
              style: TextStyle(
                  fontSize: compact ? 13 : 15, fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }

  Widget _buildDetailPlaceholder() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.inventory_2_outlined, size: 64, color: Colors.grey[200]),
          const SizedBox(height: 16),
          const Text('Pilih produk untuk melihat detail',
              style: TextStyle(color: Colors.black38, fontSize: 14)),
        ],
      ),
    );
  }
}

class _StatCell extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  const _StatCell(this.label, this.value, this.icon, this.color);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: const BoxDecoration(
          border: Border(
            right: BorderSide(color: Color(0xFFEEEEEE)),
            bottom: BorderSide(color: Color(0xFFEEEEEE)),
          ),
        ),
        child: Row(children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style:
                        const TextStyle(fontSize: 10.5, color: Colors.black45)),
                Text(value,
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: color),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}

class _ProductTile extends StatelessWidget {
  final Product product;
  final String Function(int) formatRp;
  final String Function(String?) formatDate;
  final VoidCallback onDetailTap;
  final bool selected;
  final bool compact;

  const _ProductTile({
    required this.product,
    required this.formatRp,
    required this.formatDate,
    required this.onDetailTap,
    this.selected = false,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final low = product.minStock > 0 && product.stock <= product.minStock;

    return InkWell(
      onTap: onDetailTap,
      child: Container(
        color: selected ? _kBrand.withValues(alpha: 0.06) : Colors.transparent,
        padding: EdgeInsets.fromLTRB(16, compact ? 10 : 14, 16, 0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Thumbnail
            Container(
              width: compact ? 44 : 52,
              height: compact ? 44 : 52,
              decoration: BoxDecoration(
                color: const Color(0xFFF0F0F0),
                borderRadius: BorderRadius.zero,
                border:
                    selected ? Border.all(color: _kBrand, width: 1.5) : null,
              ),
              child: const Icon(Icons.image_not_supported_outlined,
                  color: Colors.black26, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Expanded(
                        child: Text(product.name,
                            style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 14,
                                color: Colors.black87)),
                      ),
                      if (low)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: const BoxDecoration(
                            color: Color(0xFFFFEBEE),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: const Text('Stok Menipis',
                              style: TextStyle(
                                  fontSize: 10,
                                  color: Color(0xFFE53935),
                                  fontWeight: FontWeight.w600)),
                        ),
                    ]),
                    Text(
                        '${product.unit}  |  Beli ${formatRp(product.buyPrice)}  |  Jual ${formatRp(product.sellPrice)}',
                        style: const TextStyle(
                            fontSize: 11.5, color: Colors.black54)),
                    const SizedBox(height: 4),
                    Row(children: [
                      _badge('Stok', product.stock.toString(), _kBrand),
                      const SizedBox(width: 6),
                      _badge(
                          'Min',
                          product.minStock > 0
                              ? product.minStock.toString()
                              : '-',
                          Colors.black38),
                    ]),
                  ]),
            ),
          ]),

          // Compact mode: no button, tap the whole row
          if (!compact) ...[
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: onDetailTap,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: _kBrand),
                  foregroundColor: _kBrand,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                ),
                child: const Text('Detail Stok',
                    style:
                        TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
              ),
            ),
          ],
          SizedBox(height: compact ? 10 : 14),
        ]),
      ),
    );
  }

  Widget _badge(String label, String val, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.zero,
      ),
      child: Text('$label: $val',
          style: TextStyle(
              fontSize: 11, fontWeight: FontWeight.w600, color: color)),
    );
  }
}

class _ProExportBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _ProExportBtn({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: const BoxDecoration(
            color: _kBrand, borderRadius: BorderRadius.zero),
        child: const Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.download_rounded, color: Colors.white, size: 14),
          SizedBox(width: 4),
          Text('Ekspor Laporan',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}

