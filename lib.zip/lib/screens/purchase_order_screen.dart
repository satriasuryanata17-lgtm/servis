import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../core/theme.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../widgets/supplier_form_sheet.dart';
import 'responsive_layout.dart';
import '../utils/currency_input_formatter.dart';

//
//  PURCHASE ORDER SCREEN - Responsive v2 (Tablet + Landscape)
//
const Color _kBrand = AppColors.primaryBrand;
final Color _kBrandLight = AppColors.primaryBrand.withValues(alpha: 0.08);
const Color _kBg = Color(0xFFF6F7F9);

String _fRp(int n) {
  if (n == 0) return 'Rp 0';
  String s = n.toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return 'Rp $r';
}

class PurchaseOrderScreen extends StatefulWidget {
  const PurchaseOrderScreen({super.key});
  @override
  State<PurchaseOrderScreen> createState() => _PurchaseOrderScreenState();
}

class _PurchaseOrderScreenState extends State<PurchaseOrderScreen> {
  List<PurchaseOrder> _orders = [];
  bool _loading = true;
  String _filter = 'semua';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await DBHelper.instance.getAllPurchaseOrders();
    if (mounted) {
      setState(() {
        _orders = all;
        _loading = false;
      });
    }
  }

  List<PurchaseOrder> get _filtered {
    if (_filter == 'semua') return _orders;
    if (_filter == 'tempo') {
      return _orders.where((o) => o.outstandingAmount > 0).toList();
    }
    if (_filter == 'paid') return _orders.where((o) => o.isPaid == 1).toList();
    return _orders.where((o) => o.status == _filter).toList();
  }

  Future<void> _confirmReceive(PurchaseOrder po) async {
    final items = await DBHelper.instance.getPurchaseItems(po.id!);
    if (!mounted) return;
    final rows = items.where((item) => item.remainingQty > 0).toList();
    if (rows.isEmpty) return;
    final controllers = <int, TextEditingController>{
      for (final item in rows)
        if (item.id != null)
          item.id!: TextEditingController(text: item.remainingQty.toString())
    };

    final received = await showDialog<Map<int, int>>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Text('Konfirmasi Terima Barang',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        content: SizedBox(
          width: 460,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Masukkan jumlah barang dari "${po.supplierName}" yang diterima. Stok akan bertambah sesuai qty diterima.',
                style: const TextStyle(fontSize: 13, color: Colors.black54),
              ),
              const SizedBox(height: 14),
              Flexible(
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: rows.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (_, index) {
                    final item = rows[index];
                    final ctrl = controllers[item.id]!;
                    return Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(item.productName,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w700)),
                              Text(
                                'Sisa ${item.remainingQty} dari ${item.qty}',
                                style: const TextStyle(
                                    fontSize: 12, color: Colors.black45),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        SizedBox(
                          width: 88,
                          child: TextField(
                            controller: ctrl,
                            keyboardType: TextInputType.number,
                            textAlign: TextAlign.right,
                            decoration: const InputDecoration(
                              labelText: 'Terima',
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.zero),
                              isDense: true,
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child:
                  const Text('Batal', style: TextStyle(color: Colors.black45))),
          ElevatedButton(
            onPressed: () {
              FocusManager.instance.primaryFocus?.unfocus();
              final values = <int, int>{};
              for (final item in rows) {
                final id = item.id;
                if (id == null) continue;
                final raw =
                    int.tryParse(controllers[id]?.text.trim() ?? '') ?? 0;
                values[id] = raw.clamp(0, item.remainingQty).toInt();
              }
              Navigator.pop(ctx, values);
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero)),
            child: const Text('Terima Barang',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      for (final ctrl in controllers.values) {
        ctrl.dispose();
      }
    });
    if (received == null || received.values.every((qty) => qty <= 0)) return;
    await DBHelper.instance
        .receivePurchaseOrder(po.id!, receivedQtyByItemId: received);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Stok berhasil diperbarui!'),
        backgroundColor: AppColors.success,
        behavior: SnackBarBehavior.floating,
      ));
    }
    _load();
  }

  Future<void> _markPaid(PurchaseOrder po) async {
    final receivedValue =
        await DBHelper.instance.getPurchaseOrderReceivedValue(po.id!);
    if (!mounted) return;
    final payable = (receivedValue - po.effectivePaidAmount)
        .clamp(0, po.totalAmount)
        .toInt();
    if (payable <= 0) return;
    final amountCtrl =
        TextEditingController(text: formatCurrencyInput(payable));
    var walletId = 'tunai';
    final payment = await showDialog<({int amount, String walletId})>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          title: const Text('Bayar Supplier',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          content: SizedBox(
            width: 360,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Sisa hutang barang diterima: ${_fRp(payable)}',
                    style:
                        const TextStyle(fontSize: 13, color: Colors.black54)),
                const SizedBox(height: 12),
                TextField(
                  controller: amountCtrl,
                  keyboardType: TextInputType.number,
                  inputFormatters: const [CurrencyInputFormatter()],
                  decoration: const InputDecoration(
                    labelText: 'Nominal Bayar',
                    border: OutlineInputBorder(borderRadius: BorderRadius.zero),
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'Bayar dari Buku Kas',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF64748B),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: _WalletMethodOption(
                        label: 'Tunai',
                        icon: Icons.payments_rounded,
                        selected: walletId == 'tunai',
                        onTap: () => setDialogState(() => walletId = 'tunai'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _WalletMethodOption(
                        label: 'Non-Tunai',
                        icon: Icons.credit_card_rounded,
                        selected: walletId == 'non_tunai',
                        onTap: () =>
                            setDialogState(() => walletId = 'non_tunai'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Batal',
                    style: TextStyle(color: Colors.black45))),
            ElevatedButton(
              onPressed: () {
                final value = parseCurrencyInput(amountCtrl.text);
                Navigator.pop(ctx, (
                  amount: value.clamp(0, payable).toInt(),
                  walletId: walletId,
                ));
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: _kBrand,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero)),
              child: const Text('Simpan Pembayaran',
                  style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
    amountCtrl.dispose();
    if (payment == null || payment.amount <= 0) return;
    await DBHelper.instance.payPurchaseOrder(
      po.id!,
      amount: payment.amount,
      walletId: payment.walletId,
    );
    _load();
  }

  Future<void> _deletePO(PurchaseOrder po) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Text('Hapus Pembelian',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        content: const Text(
            'Pembelian ini akan dibatalkan. Stok diterima akan dikurangi, hutang supplier disesuaikan, dan pembayaran yang tercatat akan dikembalikan ke dompet.',
            style: TextStyle(fontSize: 14)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child:
                  const Text('Batal', style: TextStyle(color: Colors.black45))),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Hapus',
                  style: TextStyle(
                      color: AppColors.danger, fontWeight: FontWeight.bold))),
        ],
      ),
    );
    if (ok == true) {
      await DBHelper.instance.deletePurchaseOrder(po.id!);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isWide = isTabletDevice(context) || isLandscape(context);

    return KasirResponsiveScaffold(
      title: 'Pembelian Supplier',
      showNavRail: false,
      navIndex: 2,
      backgroundColor: _kBg,
      floatingActionButton: null,
      body: isWide
          ? (isLandscape(context)
              ? _buildTabletLandscape()
              : _buildTabletPortrait())
          : _buildPhoneBody(),
      bottomNavigationBar: isWide
          ? null
          : SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                child: SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      await _openCreatePurchase();
                    },
                    icon: const Icon(Icons.add_shopping_cart_rounded, size: 20),
                    label: const Text('Buat Pembelian',
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w600)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                  ),
                ),
              ),
            ),
    );
  }

  Future<void> _openCreatePurchase() async {
    await Navigator.push(
        context, MaterialPageRoute(builder: (_) => const TambahPOScreen()));
    _load();
  }

  Widget _buildWideCreatePurchaseBar() {
    return SafeArea(
      top: false,
      child: Container(
        color: Colors.white,
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
        child: SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton.icon(
            onPressed: _openCreatePurchase,
            icon: const Icon(Icons.add_shopping_cart_rounded, size: 20),
            label: const Text(
              'Buat Pembelian',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              elevation: 0,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTabletPortrait() {
    return Column(
      children: [
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Pembelian Supplier',
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF1E293B))),
              const SizedBox(height: 12),
              _buildFilterRow(),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(child: _buildList()),
        _buildWideCreatePurchaseBar(),
      ],
    );
  }

  Widget _buildTabletLandscape() {
    final draftCount = _orders.where((o) => o.status == 'draft').length;
    final receivedCount = _orders.where((o) => o.status == 'received').length;
    final totalNilai = _orders.fold<int>(0, (s, o) => s + o.totalAmount);

    return KasirLandscapeSplit(
      leftWidth: 280,
      leftPanel: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Pembelian Supplier',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1E293B))),
            const SizedBox(height: 20),
            // Summary stats
            KasirStatCard(
              label: 'Menunggu Terima',
              value: '$draftCount pembelian',
              icon: Icons.assignment_late_outlined,
              color: AppColors.warning,
            ),
            const SizedBox(height: 10),
            KasirStatCard(
              label: 'Sudah Diterima',
              value: '$receivedCount pembelian',
              icon: Icons.assignment_turned_in_outlined,
              color: AppColors.success,
            ),
            const SizedBox(height: 10),
            KasirStatCard(
              label: 'Total Pembelian',
              value: _fRp(totalNilai),
              icon: Icons.receipt_long_outlined,
              color: _kBrand,
            ),
            const SizedBox(height: 20),
            const Text('Filter',
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF64748B))),
            const SizedBox(height: 8),
            ...[
              ('semua', 'Semua Pembelian'),
              ('draft', 'Menunggu Terima'),
              ('partial_received', 'Diterima Sebagian'),
              ('received', 'Sudah Diterima'),
              ('tempo', 'Belum Lunas'),
              ('paid', 'Lunas'),
            ].map((item) => _FilterTile(
                  label: item.$2,
                  selected: _filter == item.$1,
                  onTap: () => setState(() => _filter = item.$1),
                )),
          ],
        ),
      ),
      rightPanel: Column(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            child: Row(children: [
              Text('${_filtered.length} Pembelian',
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF64748B))),
            ]),
          ),
          const Divider(height: 1),
          Expanded(child: _buildList()),
          _buildWideCreatePurchaseBar(),
        ],
      ),
    );
  }

  Widget _buildPhoneBody() {
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: _buildFilterRow(),
          ),
          Expanded(child: _buildList()),
        ],
      ),
    );
  }

  Widget _buildFilterRow() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          ('semua', 'Semua'),
          ('draft', 'Menunggu Terima'),
          ('partial_received', 'Diterima Sebagian'),
          ('received', 'Diterima'),
          ('tempo', 'Belum Lunas'),
          ('paid', 'Lunas'),
        ].map((item) {
          final active = _filter == item.$1;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () => setState(() => _filter = item.$1),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: active ? _kBrandLight : Colors.white,
                  borderRadius: BorderRadius.zero,
                  border: Border.all(
                      color: active ? _kBrand : const Color(0xFFE2E8F0)),
                ),
                child: Text(item.$2,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: active ? FontWeight.bold : FontWeight.w600,
                      color: active ? _kBrand : Colors.black54,
                    )),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildList() {
    if (_loading) {
      return const Center(
          child: CircularProgressIndicator(color: _kBrand, strokeWidth: 2));
    }
    if (_filtered.isEmpty) return _EmptyState(isFilter: _filter != 'semua');
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
      itemCount: _filtered.length,
      itemBuilder: (_, i) {
        final po = _filtered[i];
        return _POCard(
          po: po,
          onReceive: po.isFullyReceived ? null : () => _confirmReceive(po),
          onPaid: po.hasReceivedGoods && po.outstandingAmount > 0
              ? () => _markPaid(po)
              : null,
          onDelete: () => _deletePO(po),
          onTap: () async {
            await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => PODetailScreen(poId: po.id!)));
            _load();
          },
        );
      },
    );
  }
}

class _FilterTile extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _FilterTile(
      {required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: selected
              ? AppColors.primaryBrand.withValues(alpha: 0.10)
              : Colors.transparent,
          borderRadius: BorderRadius.zero,
          border: Border.all(
            color: selected ? AppColors.primaryBrand : const Color(0xFFE2E8F0),
          ),
        ),
        child: Row(
          children: [
            Icon(
              selected ? Icons.radio_button_checked : Icons.radio_button_off,
              size: 18,
              color: selected ? AppColors.primaryBrand : Colors.grey,
            ),
            const SizedBox(width: 10),
            Text(label,
                style: TextStyle(
                    fontWeight: selected ? FontWeight.w700 : FontWeight.normal,
                    color: selected
                        ? AppColors.primaryBrand
                        : const Color(0xFF374151),
                    fontSize: 13)),
          ],
        ),
      ),
    );
  }
}

class _POCard extends StatelessWidget {
  final PurchaseOrder po;
  final VoidCallback? onReceive, onPaid, onDelete, onTap;

  const _POCard(
      {required this.po,
      this.onReceive,
      this.onPaid,
      this.onDelete,
      this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDraft = po.status == 'draft';
    final isPartial = po.status == 'partial_received';
    final statusColor =
        isDraft ? AppColors.warning : (isPartial ? _kBrand : AppColors.success);
    final statusLabel = po.itemStatusLabel;
    final tanggal = DateFormat('dd MMM yyyy')
        .format(DateTime.tryParse(po.createdAt) ?? DateTime.now());

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFF0F0F0)),
      ),
      child: Column(
        children: [
          Material(
            color: Colors.transparent,
            borderRadius: const BorderRadius.vertical(top: Radius.zero),
            child: InkWell(
              onTap: onTap,
              borderRadius: const BorderRadius.vertical(top: Radius.zero),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.zero),
                      child: Icon(
                          isDraft
                              ? Icons.assignment_late_outlined
                              : Icons.assignment_turned_in_outlined,
                          color: statusColor,
                          size: 20),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Pembelian #${po.id}  $tanggal',
                                style: const TextStyle(
                                    fontSize: 12,
                                    color: Colors.black38,
                                    fontWeight: FontWeight.w600)),
                            const SizedBox(height: 2),
                            Text(po.supplierName,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: Colors.black87)),
                            const SizedBox(height: 4),
                            Text(_fRp(po.totalAmount),
                                style: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    color: _kBrand)),
                            if (po.hasReceivedGoods) ...[
                              const SizedBox(height: 2),
                              Text(
                                'Diterima ${_fRp(po.receivedAmount)} | Dibayar ${_fRp(po.effectivePaidAmount)}',
                                style: const TextStyle(
                                    fontSize: 11, color: Colors.black38),
                              ),
                            ],
                          ]),
                    ),
                    Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          _Badge(label: statusLabel, color: statusColor),
                          if (po.hasReceivedGoods) ...[
                            const SizedBox(height: 4),
                            _Badge(
                                label: po.paymentStatusLabel,
                                color: po.isPaid == 1
                                    ? AppColors.success
                                    : AppColors.danger),
                          ],
                        ]),
                  ],
                ),
              ),
            ),
          ),
          if (onReceive != null || onPaid != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: const BoxDecoration(
                  color: Color(0xFFFAFAFA),
                  borderRadius: BorderRadius.vertical(bottom: Radius.zero)),
              child: Row(
                children: [
                  if (onDelete != null)
                    IconButton(
                        onPressed: onDelete,
                        icon: const Icon(AppIcons.recycleBin,
                            color: Colors.black26, size: 20)),
                  const Spacer(),
                  if (onReceive != null)
                    TextButton.icon(
                      onPressed: onReceive,
                      icon: const Icon(Icons.download_rounded, size: 16),
                      label: const Text('Terima Barang',
                          style: TextStyle(
                              fontSize: 12, fontWeight: FontWeight.bold)),
                      style: TextButton.styleFrom(
                          foregroundColor: Colors.white,
                          backgroundColor: _kBrand,
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero)),
                    ),
                  if (onPaid != null)
                    TextButton.icon(
                      onPressed: onPaid,
                      icon: const Icon(Icons.check_circle_outline, size: 16),
                      label: const Text('Tandai Lunas',
                          style: TextStyle(
                              fontSize: 12, fontWeight: FontWeight.bold)),
                      style: TextButton.styleFrom(
                          foregroundColor: Colors.white,
                          backgroundColor: AppColors.success,
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero)),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String label;
  final Color color;
  const _Badge({required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.zero),
        child: Text(label,
            style: TextStyle(
                fontSize: 11, fontWeight: FontWeight.bold, color: color)),
      );
}

class _WalletMethodOption extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _WalletMethodOption({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          decoration: BoxDecoration(
            color: selected ? _kBrandLight : Colors.white,
            border: Border.all(
              color: selected ? _kBrand : const Color(0xFFE2E8F0),
            ),
            borderRadius: BorderRadius.zero,
          ),
          child: Row(
            children: [
              Icon(icon, size: 18, color: selected ? _kBrand : Colors.black45),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: selected ? _kBrand : Colors.black54,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
}

class PODetailScreen extends StatefulWidget {
  final int poId;
  const PODetailScreen({super.key, required this.poId});
  @override
  State<PODetailScreen> createState() => _PODetailScreenState();
}

class _PODetailScreenState extends State<PODetailScreen> {
  PurchaseOrder? _po;
  List<PurchaseItem> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final po = await DBHelper.instance.getPurchaseOrderById(widget.poId);
    final items = await DBHelper.instance.getPurchaseItems(widget.poId);
    if (mounted) {
      setState(() {
        _po = po;
        _items = items;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading || _po == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final po = _po!;
    final tanggal = DateFormat('dd MMMM yyyy HH:mm', 'id')
        .format(DateTime.tryParse(po.createdAt) ?? DateTime.now());

    final isWide = isTabletDevice(context) || isLandscape(context);

    Widget metaCard() => Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.zero,
              border: Border.all(color: const Color(0xFFF0F0F0))),
          child: Column(children: [
            _DetailRow('Supplier', po.supplierName),
            _DetailRow('Tanggal', tanggal),
            _DetailRow('Status', po.itemStatusLabel),
            _DetailRow('Pembayaran', po.paymentStatusLabel),
            _DetailRow('Nilai Diterima', _fRp(po.receivedAmount)),
            _DetailRow('Sudah Dibayar', _fRp(po.effectivePaidAmount)),
            if (po.outstandingAmount > 0)
              _DetailRow('Sisa Hutang', _fRp(po.outstandingAmount)),
            if (po.note?.isNotEmpty == true) _DetailRow('Catatan', po.note!),
          ]),
        );

    Widget productCard() => Container(
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.zero,
              border: Border.all(color: const Color(0xFFF0F0F0))),
          child: Column(children: [
            ..._items.asMap().entries.map((e) {
              final i = e.key;
              final item = e.value;
              return Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                    border: Border(
                        bottom: i < _items.length - 1
                            ? const BorderSide(color: Color(0xFFF5F5F5))
                            : BorderSide.none)),
                child: Row(children: [
                  Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                        Text(item.productName,
                            style: const TextStyle(
                                fontSize: 15, fontWeight: FontWeight.w600)),
                        Text(
                            'Jumlah ${item.qty} | modal ${_fRp(item.unitPrice)} per software | diterima ${item.receivedQty}',
                            style: const TextStyle(
                                fontSize: 13, color: Colors.black38)),
                      ])),
                  Text(_fRp(item.subtotal),
                      style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: _kBrand)),
                ]),
              );
            }),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: _kBrandLight,
                  borderRadius:
                      const BorderRadius.vertical(bottom: Radius.zero)),
              child: Row(children: [
                const Expanded(
                    child: Text('TOTAL',
                        style: TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 14))),
                Text(_fRp(po.totalAmount),
                    style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 17,
                        color: _kBrand)),
              ]),
            ),
          ]),
        );

    return KasirResponsiveScaffold(
      title: 'Detail Pembelian #${po.id}',
      navIndex: 2,
      backgroundColor: _kBg,
      body: isWide
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: 300,
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(20),
                    child: metaCard(),
                  ),
                ),
                const VerticalDivider(width: 1),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.all(20),
                    children: [
                      const Text('Daftar Produk',
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      productCard(),
                    ],
                  ),
                ),
              ],
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                metaCard(),
                const SizedBox(height: 24),
                const Text('Daftar Produk',
                    style:
                        TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                productCard(),
              ],
            ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label, value;
  const _DetailRow(this.label, this.value);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(
              width: 90,
              child: Text(label,
                  style: const TextStyle(fontSize: 14, color: Colors.black38))),
          Expanded(
              child: Text(value,
                  style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87),
                  textAlign: TextAlign.right)),
        ]),
      );
}

class _EmptyState extends StatelessWidget {
  final bool isFilter;
  const _EmptyState({this.isFilter = false});
  @override
  Widget build(BuildContext context) => Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
            padding: const EdgeInsets.all(24),
            decoration: const BoxDecoration(
                color: Color(0xFFEFF6FF), shape: BoxShape.rectangle),
            child: const Icon(Icons.receipt_long_rounded,
                size: 48, color: _kBrand)),
        const SizedBox(height: 18),
        Text(
            isFilter ? 'Pembelian tidak ditemukan' : 'Belum ada data pembelian',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 28),
          child: Text(
              'Pembelian supplier dipakai untuk membeli bahan baku atau stok dari supplier.',
              textAlign: TextAlign.center,
              style:
                  TextStyle(fontSize: 13, color: Colors.black45, height: 1.4)),
        ),
      ]));
}

class TambahPOScreen extends StatefulWidget {
  const TambahPOScreen({super.key});
  @override
  State<TambahPOScreen> createState() => _TambahPOScreenState();
}

class _TambahPOScreenState extends State<TambahPOScreen> {
  List<Supplier> _suppliers = [];
  List<Product> _products = [];
  Supplier? _selectedSupplier;
  final List<_POItemRow> _rows = [];
  final _noteCtrl = TextEditingController();
  bool _loading = true, _saving = false;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final s = await DBHelper.instance.getAllSuppliers();
    final p = await DBHelper.instance.getProductsForSupplierPurchase();
    if (mounted) {
      setState(() {
        _suppliers = s;
        _products = p;
        _loading = false;
      });
    }
  }

  void _showAddSupplier() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => SupplierFormSheet(
        onSaved: (newSupplier) {
          Navigator.pop(context);
          _loadData().then((_) {
            setState(() => _selectedSupplier = _suppliers.firstWhere(
                (s) => s.id == newSupplier.id,
                orElse: () => newSupplier));
          });
        },
      ),
    );
  }

  void _addRow() => setState(() => _rows.add(_POItemRow(products: _products)));
  int get _total => _rows.fold<int>(0, (s, r) => s + r.totalPrice);

  Future<void> _save() async {
    if (_rows.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(' Harap tambahkan minimal satu produk!'),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating));
      return;
    }
    if (_rows.any((r) => r.selectedProduct == null)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(' Ada produk yang belum dipilih!'),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating));
      return;
    }
    if (_rows.any((r) => r.qty <= 0 || r.totalPrice <= 0)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Jumlah masuk dan total harga beli wajib diisi.'),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating));
      return;
    }
    setState(() => _saving = true);
    final now = DateTime.now().toIso8601String();
    final po = PurchaseOrder(
      supplierId: _selectedSupplier?.id,
      supplierName: _selectedSupplier?.name ?? 'Supplier Lain',
      totalAmount: _total,
      status: 'draft',
      note: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
      createdAt: now,
    );
    final poId = await DBHelper.instance.insertPurchaseOrder(po);
    for (final row in _rows) {
      final unitCost = row.derivedUnitCost;
      await DBHelper.instance.insertPurchaseItem(PurchaseItem(
        purchaseOrderId: poId,
        productId: row.selectedProduct!.id!,
        productName: row.selectedProduct!.name,
        qty: row.qty,
        unitPrice: unitCost,
        subtotal: row.totalPrice,
      ));
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isWide = isTabletDevice(context) || isLandscape(context);

    Widget sidePanel() => SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Supplier',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              InkWell(
                onTap: () async {
                  final Supplier? selected =
                      await showModalBottomSheet<Supplier?>(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (ctx) => _SupplierPickerSheet(
                        suppliers: _suppliers, onAdd: _showAddSupplier),
                  );
                  if (selected != null) {
                    setState(() => _selectedSupplier = selected);
                  }
                },
                borderRadius: BorderRadius.zero,
                child: _formCard(Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Row(children: [
                    Icon(Icons.business_rounded,
                        color: _selectedSupplier != null
                            ? _kBrand
                            : Colors.black26,
                        size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                        child: Text(
                            _selectedSupplier?.name ?? 'Pilih Supplier...',
                            style: TextStyle(
                                fontSize: 15,
                                color: _selectedSupplier != null
                                    ? Colors.black87
                                    : Colors.black26,
                                fontWeight: _selectedSupplier != null
                                    ? FontWeight.w600
                                    : FontWeight.normal))),
                    const Icon(Icons.keyboard_arrow_down_rounded,
                        color: Colors.black26, size: 20),
                  ]),
                )),
              ),
              const SizedBox(height: 24),
              const Text('Catatan',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              _formCard(TextField(
                  controller: _noteCtrl,
                  maxLines: 3,
                  style: const TextStyle(fontSize: 15),
                  decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Opsional...',
                      hintStyle: TextStyle(fontSize: 14)))),
              if (isWide) ...[
                const SizedBox(height: 24),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                      color: _kBrandLight, borderRadius: BorderRadius.zero),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('TOTAL PEMBELIAN',
                          style: TextStyle(
                              fontSize: 11,
                              color: Colors.black45,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(_fRp(_total),
                          style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: _kBrand)),
                    ],
                  ),
                ),
              ],
            ],
          ),
        );

    Widget productList() => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Expanded(
                  child: Text('Produk Masuk',
                      style: TextStyle(
                          fontSize: 15, fontWeight: FontWeight.bold))),
              TextButton.icon(
                  onPressed: _addRow,
                  icon: const Icon(Icons.add, size: 20),
                  label: const Text('Tambah Item',
                      style: TextStyle(fontSize: 14))),
            ]),
            const SizedBox(height: 12),
            ..._rows.asMap().entries.map((e) => _buildItemRow(e.key, e.value)),
            if (_rows.isEmpty)
              Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 40),
                  child: Column(
                    children: [
                      Icon(Icons.shopping_cart_outlined,
                          size: 48, color: Colors.grey[300]),
                      const SizedBox(height: 12),
                      const Text('Belum ada produk',
                          style: TextStyle(color: Colors.black38)),
                    ],
                  ),
                ),
              ),
          ],
        );

    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
            icon: const Icon(Icons.close_rounded, color: _kBrand),
            onPressed: () => Navigator.pop(context)),
        title: const Text('Buat Pembelian Supplier',
            style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.bold,
                color: Colors.black87)),
        centerTitle: true,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : (isWide
              ? Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 320,
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: sidePanel(),
                      ),
                    ),
                    const VerticalDivider(width: 1),
                    Expanded(
                      child: ListView(
                        padding: const EdgeInsets.all(20),
                        children: [productList()],
                      ),
                    ),
                  ],
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    sidePanel(),
                    const SizedBox(height: 24),
                    productList(),
                    const SizedBox(height: 100),
                  ],
                )),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: Color(0xFFF0F0F0)))),
          child: Row(children: [
            SizedBox(
              width: isWide ? 300 : null,
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('TOTAL PEMBELIAN',
                        style: TextStyle(
                            fontSize: 12,
                            color: Colors.black38,
                            fontWeight: FontWeight.bold)),
                    Text(_fRp(_total),
                        style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: _kBrand)),
                  ]),
            ),
            if (!isWide) const SizedBox(width: 16),
            Expanded(
              child: SizedBox(
                height: 52,
                child: ElevatedButton(
                  onPressed: _saving ? null : _save,
                  style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero)),
                  child: _saving
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2),
                        )
                      : const Text('Simpan Pembelian',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16)),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _formCard(Widget child) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFE8E8E8))),
        child: child,
      );

  Widget _buildItemRow(int i, _POItemRow row) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFF0F0F0))),
        child: Column(children: [
          Row(children: [
            Expanded(
                child: InkWell(
              onTap: () async {
                final Product? selected = await showModalBottomSheet<Product?>(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  builder: (ctx) => _ProductPickerSheet(products: _products),
                );
                if (selected != null) {
                  setState(() {
                    row.selectedProduct = selected;
                    row.qty = 0;
                    row.totalPrice = 0;
                    row.qtyCtrl.clear();
                    row.priceCtrl.clear();
                  });
                }
              },
              borderRadius: BorderRadius.zero,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                child: Row(children: [
                  Expanded(
                      child: Text(
                          row.selectedProduct?.name ?? 'Pilih Produk...',
                          style: TextStyle(
                              fontSize: 15,
                              fontWeight: row.selectedProduct != null
                                  ? FontWeight.w600
                                  : FontWeight.normal,
                              color: row.selectedProduct != null
                                  ? Colors.black87
                                  : Colors.black26))),
                  const Icon(Icons.keyboard_arrow_down_rounded,
                      color: Colors.black26, size: 18),
                ]),
              ),
            )),
            IconButton(
                onPressed: () => setState(() => _rows.removeAt(i)),
                icon: const Icon(Icons.close_rounded,
                    color: Colors.black26, size: 20)),
          ]),
          const Divider(height: 20),
          Row(children: [
            Expanded(
                flex: 2,
                child: _formCard(TextField(
                    controller: row.qtyCtrl,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w600),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: row.selectedProduct == null
                            ? 'Pilih produk dulu'
                            : 'Contoh: 10000',
                        labelText: 'Jumlah Masuk (${row.unitLabel})',
                        suffixText: row.unitLabel,
                        helperText: row.selectedProduct == null
                            ? 'Pilih produk dulu'
                            : 'Isi jumlah fisik yang dibeli dari supplier.',
                        helperStyle: const TextStyle(fontSize: 11),
                        labelStyle: const TextStyle(fontSize: 13)),
                    onTap: () {
                      if (row.qtyCtrl.text.trim() == '0') {
                        row.qtyCtrl.clear();
                      }
                    },
                    onChanged: (v) =>
                        setState(() => row.qty = int.tryParse(v) ?? 0)))),
            const SizedBox(width: 8),
            Expanded(
                flex: 3,
                child: _formCard(TextField(
                    controller: row.priceCtrl,
                    keyboardType: TextInputType.number,
                    inputFormatters: const [CurrencyInputFormatter()],
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: _kBrand),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Contoh: 200000',
                        labelText: 'Total Harga Beli',
                        prefixText: 'Rp ',
                        helperText: row.modalPreview,
                        helperStyle: const TextStyle(
                            fontSize: 11,
                            color: _kBrand,
                            fontWeight: FontWeight.w600),
                        labelStyle: const TextStyle(fontSize: 13)),
                    onTap: () {
                      if (row.priceCtrl.text.trim() == '0') {
                        row.priceCtrl.clear();
                      }
                    },
                    onChanged: (v) => setState(
                        () => row.totalPrice = parseCurrencyInput(v))))),
          ]),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.zero,
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: Text(
              row.selectedProduct == null
                  ? 'Pilih produk, isi jumlah masuk, lalu isi total uang yang dibayar ke supplier.'
                  : 'Sistem otomatis membagi total harga beli menjadi modal per ${row.unitLabel} untuk stok dan laporan HPP.',
              style: const TextStyle(
                  fontSize: 12, color: Color(0xFF64748B), height: 1.35),
            ),
          ),
        ]),
      );
}

class _POItemRow {
  final List<Product> products;
  Product? selectedProduct;
  int qty = 0;
  int totalPrice = 0;
  final TextEditingController qtyCtrl = TextEditingController();
  final TextEditingController priceCtrl = TextEditingController();
  _POItemRow({required this.products});

  String get unitLabel {
    final unit = selectedProduct?.unit.trim();
    return unit == null || unit.isEmpty ? 'unit' : unit;
  }

  int get derivedUnitCost {
    if (qty <= 0 || totalPrice <= 0) return 0;
    return (totalPrice / qty).round();
  }

  String get modalPreview {
    if (qty <= 0 || totalPrice <= 0) {
      return 'Modal per $unitLabel dihitung otomatis';
    }
    return 'Modal otomatis: ${_fRp(derivedUnitCost)}/$unitLabel';
  }
}

class _SupplierPickerSheet extends StatefulWidget {
  final List<Supplier> suppliers;
  final VoidCallback onAdd;
  const _SupplierPickerSheet({required this.suppliers, required this.onAdd});
  @override
  State<_SupplierPickerSheet> createState() => _SupplierPickerSheetState();
}

class _SupplierPickerSheetState extends State<_SupplierPickerSheet> {
  final _searchCtrl = TextEditingController();
  String _query = '';
  @override
  Widget build(BuildContext context) {
    final filtered = widget.suppliers
        .where((s) => s.name.toLowerCase().contains(_query.toLowerCase()))
        .toList();
    return Container(
      height: MediaQuery.of(context).size.height * 0.7,
      decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero)),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Column(children: [
        Container(
            width: 40,
            height: 4,
            margin: const EdgeInsets.only(bottom: 20),
            decoration: const BoxDecoration(
                color: Colors.black12, borderRadius: BorderRadius.zero)),
        Row(children: [
          const Expanded(
              child: Text('Pilih Supplier',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
          TextButton.icon(
              onPressed: () {
                Navigator.pop(context);
                widget.onAdd();
              },
              icon: const Icon(Icons.add, size: 16),
              label: const Text('Tambah Baru',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
              style: TextButton.styleFrom(foregroundColor: _kBrand)),
        ]),
        const SizedBox(height: 12),
        Container(
          height: 44,
          decoration: BoxDecoration(
              color: _kBg,
              borderRadius: BorderRadius.zero,
              border: Border.all(color: const Color(0xFFE8E8E8))),
          child: TextField(
              controller: _searchCtrl,
              onChanged: (v) => setState(() => _query = v),
              decoration: const InputDecoration(
                  hintText: 'Cari supplier...',
                  hintStyle: TextStyle(fontSize: 13, color: Colors.black38),
                  prefixIcon:
                      Icon(Icons.search, color: Colors.black38, size: 20),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12))),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: filtered.isEmpty
              ? const Center(
                  child: Text('Supplier tidak ditemukan',
                      style: TextStyle(color: Colors.black38, fontSize: 13)))
              : ListView.separated(
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) =>
                      const Divider(height: 1, color: Color(0xFFF5F5F5)),
                  itemBuilder: (ctx, i) {
                    final s = filtered[i];
                    return ListTile(
                      onTap: () => Navigator.pop(context, s),
                      contentPadding: EdgeInsets.zero,
                      leading: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                              color: _kBrandLight,
                              borderRadius: BorderRadius.zero),
                          child: const Icon(Icons.business_rounded,
                              color: _kBrand, size: 18)),
                      title: Text(s.name,
                          style: const TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w600)),
                      subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (s.phone != null)
                              Text(s.phone!,
                                  style: const TextStyle(
                                      fontSize: 13, color: Colors.black38)),
                            if (s.keterangan != null)
                              Text(s.keterangan!,
                                  style: const TextStyle(
                                      fontSize: 13,
                                      color: _kBrand,
                                      fontWeight: FontWeight.w500)),
                          ]),
                      trailing: const Icon(Icons.chevron_right_rounded,
                          color: Colors.black12),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

class _ProductPickerSheet extends StatefulWidget {
  final List<Product> products;
  const _ProductPickerSheet({required this.products});
  @override
  State<_ProductPickerSheet> createState() => _ProductPickerSheetState();
}

class _ProductPickerSheetState extends State<_ProductPickerSheet> {
  final _searchCtrl = TextEditingController();
  String _query = '';
  @override
  Widget build(BuildContext context) {
    final filtered = widget.products
        .where((p) =>
            p.name.toLowerCase().contains(_query.toLowerCase()) ||
            (p.sku?.toLowerCase().contains(_query.toLowerCase()) ?? false))
        .toList();
    return Container(
      height: MediaQuery.of(context).size.height * 0.8,
      decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero)),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Column(children: [
        Container(
            width: 40,
            height: 4,
            margin: const EdgeInsets.only(bottom: 20),
            decoration: const BoxDecoration(
                color: Colors.black12, borderRadius: BorderRadius.zero)),
        const Center(
            child: Text('Pilih Produk',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
        const SizedBox(height: 16),
        Container(
          height: 44,
          decoration: BoxDecoration(
              color: _kBg,
              borderRadius: BorderRadius.zero,
              border: Border.all(color: const Color(0xFFE8E8E8))),
          child: TextField(
              controller: _searchCtrl,
              onChanged: (v) => setState(() => _query = v),
              decoration: const InputDecoration(
                  hintText: 'Cari nama produk atau SKU...',
                  hintStyle: TextStyle(fontSize: 13, color: Colors.black38),
                  prefixIcon:
                      Icon(Icons.search, color: Colors.black38, size: 20),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12))),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: filtered.isEmpty
              ? const Center(
                  child: Text('Produk tidak ditemukan',
                      style: TextStyle(color: Colors.black38, fontSize: 13)))
              : ListView.separated(
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) =>
                      const Divider(height: 1, color: Color(0xFFF5F5F5)),
                  itemBuilder: (ctx, i) {
                    final p = filtered[i];
                    return ListTile(
                      onTap: () => Navigator.pop(context, p),
                      contentPadding: const EdgeInsets.symmetric(vertical: 4),
                      leading: Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                              color: Colors.grey[100],
                              borderRadius: BorderRadius.zero,
                              image: p.imagePath != null
                                  ? DecorationImage(
                                      image: AssetImage(p.imagePath!),
                                      fit: BoxFit.cover)
                                  : null),
                          child: p.imagePath == null
                              ? const Icon(Icons.image_outlined,
                                  color: Colors.black12, size: 24)
                              : null),
                      title: Text(p.name,
                          style: const TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w600)),
                      subtitle: Text('${p.unit}  Stok: ${p.stock}',
                          style: const TextStyle(
                              fontSize: 13, color: Colors.black38)),
                      trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(_fRp(p.buyPrice),
                                style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: _kBrand)),
                            const Text('Modal Saat Ini',
                                style: TextStyle(
                                    fontSize: 12, color: Colors.black26)),
                          ]),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

