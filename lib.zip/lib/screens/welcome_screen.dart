import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/theme.dart';

const String _kWelcomeSeenKey = 'welcome_screen_seen_v1';

/// Cek apakah welcome screen sudah pernah ditampilkan
Future<bool> isWelcomeScreenSeen() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getBool(_kWelcomeSeenKey) ?? false;
}

/// Tandai welcome screen sudah dilihat
Future<void> markWelcomeScreenSeen() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool(_kWelcomeSeenKey, true);
}

class WelcomeScreen extends StatefulWidget {
  final VoidCallback onMasuk;

  const WelcomeScreen({
    super.key,
    required this.onMasuk,
  });

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen>
    with TickerProviderStateMixin {
  late AnimationController _heroCtrl;
  late AnimationController _notifCtrl;
  late AnimationController _floatCtrl;

  late Animation<double> _fadeIn;
  late Animation<Offset> _slideUp;
  late Animation<Offset> _notifSlide;
  late Animation<double> _notifFade;
  late Animation<double> _floatAnim;

  static const _brand = AppColors.primaryBrand;

  @override
  void initState() {
    super.initState();

    _heroCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _notifCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    )..repeat(reverse: true);

    _fadeIn = CurvedAnimation(parent: _heroCtrl, curve: Curves.easeOut);
    _slideUp = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _heroCtrl, curve: Curves.easeOutCubic));

    _notifSlide = Tween<Offset>(
      begin: const Offset(0.4, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _notifCtrl, curve: Curves.easeOutBack));

    _notifFade = CurvedAnimation(parent: _notifCtrl, curve: Curves.easeOut);
    _floatAnim = Tween<double>(begin: -4.0, end: 4.0).animate(
      CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut),
    );

    _heroCtrl.forward();
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _notifCtrl.forward();
    });

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ));
  }

  @override
  void dispose() {
    _heroCtrl.dispose();
    _notifCtrl.dispose();
    _floatCtrl.dispose();
    super.dispose();
  }

  Future<void> _handleMasuk() async {
    await markWelcomeScreenSeen();
    widget.onMasuk();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isTablet = size.width > 600;

    return Scaffold(
      backgroundColor: const Color(0xFFF7F9FB),
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeIn,
          child: SlideTransition(
            position: _slideUp,
            child: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: isTablet ? 48 : 24,
                        vertical: 20,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          //  Logo
                          _buildLogo(),
                          const SizedBox(height: 28),

                          //  Hero Card
                          _buildHeroCard(size),
                          const SizedBox(height: 28),

                          //  Headlines
                          _buildHeadlines(),
                          const SizedBox(height: 20),

                          //  Feature Pills
                          _buildFeaturePills(),
                          const SizedBox(height: 32),
                        ],
                      ),
                    ),
                  ),
                ),

                //  Bottom Buttons (sticky)
                _buildBottomActions(isTablet),
              ],
            ),
          ),
        ),
      ),
    );
  }

  //  LOGO
  Widget _buildLogo() {
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: _brand,
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Icon(Icons.handyman_rounded,
              color: Colors.white, size: 22),
        ),
        const SizedBox(width: 12),
        Text(
          'Juragan Servis',
          style: AppText.h2.copyWith(
            color: const Color(0xFF0A0F1E),
            fontWeight: FontWeight.w800,
            letterSpacing: -0.4,
          ),
        ),
        const Spacer(),
        // Social proof badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: _brand.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.verified_rounded, size: 13, color: _brand),
              SizedBox(width: 4),
              Text(
                '100+ Outlet',
                style: TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: _brand,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  //  HERO CARD
  Widget _buildHeroCard(Size size) {
    return AnimatedBuilder(
      animation: _floatAnim,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _floatAnim.value * 0.4),
          child: child,
        );
      },
      child: Container(
        height: size.height * 0.38,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.07),
              blurRadius: 30,
              offset: const Offset(0, 8),
            ),
            BoxShadow(
              color: _brand.withValues(alpha: 0.06),
              blurRadius: 40,
              offset: const Offset(0, 16),
            ),
          ],
        ),
        clipBehavior: Clip.hardEdge,
        child: Stack(
          children: [
            // Background gradient
            Positioned.fill(
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFFF0FDF9),
                      Colors.white,
                      Color(0xFFF7F9FF),
                    ],
                  ),
                ),
              ),
            ),

            // Decorative circle top-right
            Positioned(
              top: -30,
              right: -30,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _brand.withValues(alpha: 0.06),
                ),
              ),
            ),
            Positioned(
              bottom: -20,
              left: -20,
              child: Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF3B82F6).withValues(alpha: 0.05),
                ),
              ),
            ),

            // Main illustration
            Center(child: _buildIllustration()),

            // Notification chip (floating)
            Positioned(
              top: 16,
              right: 16,
              child: SlideTransition(
                position: _notifSlide,
                child: FadeTransition(
                  opacity: _notifFade,
                  child: _buildNotifChip(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  //  ILLUSTRATION (mini dashboard)
  Widget _buildIllustration() {
    return SizedBox(
      width: 260,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Mini phone mockup
          Container(
            width: 200,
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A2E),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.2),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              children: [
                // Phone top bar
                Container(
                  height: 22,
                  decoration: const BoxDecoration(
                    color: Color(0xFF16213E),
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(20)),
                  ),
                  child: Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.white24,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                ),

                // Screen content
                Container(
                  padding: const EdgeInsets.all(10),
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header row
                      Row(children: [
                        Container(
                            width: 24,
                            height: 24,
                            decoration: BoxDecoration(
                                color: _brand,
                                borderRadius: BorderRadius.circular(6)),
                            child: const Icon(
                                Icons.handyman_rounded,
                                color: Colors.white,
                                size: 14)),
                        const SizedBox(width: 6),
                        const Text('Outlet',
                            style: TextStyle(
                                fontFamily: 'PlusJakartaSans',
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF0A0F1E))),
                        const Spacer(),
                        Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                                color:
                                    AppColors.success.withValues(alpha: 0.12),
                                borderRadius: BorderRadius.circular(4)),
                            child: const Text('Aktif',
                                style: TextStyle(
                                    fontFamily: 'PlusJakartaSans',
                                    fontSize: 8,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.success))),
                      ]),
                      const SizedBox(height: 8),
                      // Revenue card
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: AppColors.gradTeal,
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Omzet Hari Ini',
                                style: TextStyle(
                                    fontFamily: 'PlusJakartaSans',
                                    fontSize: 8,
                                    color: Colors.white70,
                                    fontWeight: FontWeight.w500)),
                            SizedBox(height: 2),
                            Text('Rp 1.850.000',
                                style: TextStyle(
                                    fontFamily: 'PlusJakartaSans',
                                    fontSize: 13,
                                    fontWeight: FontWeight.w800,
                                    color: Colors.white,
                                    letterSpacing: -0.3)),
                            SizedBox(height: 4),
                            Row(children: [
                              Icon(Icons.trending_up_rounded,
                                  color: Colors.white70, size: 10),
                              SizedBox(width: 2),
                              Text('+15% vs kemarin',
                                  style: TextStyle(
                                      fontFamily: 'PlusJakartaSans',
                                      fontSize: 7.5,
                                      color: Colors.white70,
                                      fontWeight: FontWeight.w500)),
                            ]),
                          ],
                        ),
                      ),
                      const SizedBox(height: 6),
                      // Servis items
                      _miniTxItem('Ganti LCD HP', 'Rp 350.000', _brand),
                      const SizedBox(height: 4),
                      _miniTxItem(
                          'Servis AC', 'Rp 150.000', const Color(0xFF3B82F6)),
                      const SizedBox(height: 4),
                      _miniTxItem(
                          'Diagnosa Laptop', 'Rp 75.000', AppColors.warning),
                      const SizedBox(height: 8),
                      // Total row
                      Row(children: [
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 7),
                            decoration: BoxDecoration(
                              color: _brand,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Center(
                                child: Text('Bayar    Rp 75.000',
                                    style: TextStyle(
                                        fontFamily: 'PlusJakartaSans',
                                        fontSize: 9,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white))),
                          ),
                        ),
                      ]),
                    ],
                  ),
                ),

                // Bottom bar (servis status)
                _buildStatusBottom(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniTxItem(String name, String price, Color dot) {
    return Row(children: [
      Container(
          width: 5,
          height: 5,
          decoration: BoxDecoration(color: dot, shape: BoxShape.circle)),
      const SizedBox(width: 5),
      Expanded(
          child: Text(name,
              style: const TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontSize: 8.5,
                  color: Color(0xFF3D4350),
                  fontWeight: FontWeight.w500))),
      Text(price,
          style: const TextStyle(
              fontFamily: 'PlusJakartaSans',
              fontSize: 8.5,
              fontWeight: FontWeight.w700,
              color: Color(0xFF0A0F1E))),
    ]);
  }

  Widget _buildStatusBottom() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: const BoxDecoration(
        color: Color(0xFFF0F9FF),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
      ),
      child: Row(
        children: [
          const Icon(Icons.access_time_rounded,
              size: 14, color: Color(0xFF0EA5E9)),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Status Servis',
                    style: TextStyle(
                        fontFamily: 'PlusJakartaSans',
                        fontSize: 8,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF0EA5E9))),
                const SizedBox(height: 2),
                Container(
                    height: 3,
                    width: 100,
                    decoration: BoxDecoration(
                        color: const Color(0xFF0EA5E9).withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(2),
                        border: const Border(
                            left: BorderSide(
                                color: Color(0xFF0EA5E9), width: 60)))),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
            decoration: BoxDecoration(
              color: const Color(0xFF0EA5E9).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(4),
            ),
            child: const Text('Dikerjakan',
                style: TextStyle(
                    fontFamily: 'PlusJakartaSans',
                    fontSize: 8,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF0EA5E9))),
          ),
        ],
      ),
    );
  }

  //  NOTIFICATION CHIP
  Widget _buildNotifChip() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: _brand.withValues(alpha: 0.15),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: AppColors.success.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.check_circle_rounded,
                size: 14, color: AppColors.success),
          ),
          const SizedBox(width: 8),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Pesanan Selesai',
                  style: TextStyle(
                    fontFamily: 'PlusJakartaSans',
                    fontSize: 9.5,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF8B95A5),
                  )),
              Text('Siap Diambil',
                  style: TextStyle(
                    fontFamily: 'PlusJakartaSans',
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: AppColors.success,
                    letterSpacing: -0.2,
                  )),
            ],
          ),
        ],
      ),
    );
  }

  //  HEADLINES
  Widget _buildHeadlines() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Kelola Servis\nLebih Profesional',
          style: AppText.h1.copyWith(
            fontSize: 28,
            fontWeight: FontWeight.w800,
            color: const Color(0xFF0A0F1E),
            letterSpacing: -0.8,
            height: 1.2,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'Kelola order, teknisi, status perbaikan, nota, dan laporan servis elektronik dari satu aplikasi.',
          style: AppText.bodySmall.copyWith(
            color: const Color(0xFF5A6375),
            fontSize: 15,
            height: 1.55,
          ),
        ),
      ],
    );
  }

  //  FEATURE PILLS
  Widget _buildFeaturePills() {
    final features = [
      (Icons.home_repair_service_rounded, 'Multi Jenis Servis'),
      (Icons.track_changes_rounded, 'Tracking Status'),
      (Icons.print_rounded, 'Print Struk'),
      (Icons.people_alt_rounded, 'Database Pelanggan'),
      (Icons.chat_bubble_rounded, 'Notifikasi WA'),
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: features.map((f) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: const Color(0xFFE2E4E8)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(f.$1, size: 14, color: _brand),
              const SizedBox(width: 6),
              Text(
                f.$2,
                style: const TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF3D4350),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  //  BOTTOM ACTIONS
  Widget _buildBottomActions(bool isTablet) {
    return Container(
      padding: EdgeInsets.fromLTRB(
        isTablet ? 48 : 24,
        16,
        isTablet ? 48 : 24,
        MediaQuery.of(context).padding.bottom + 20,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Primary CTA
          SizedBox(
            height: 52,
            child: ElevatedButton.icon(
              onPressed: _handleMasuk,
              style: ElevatedButton.styleFrom(
                backgroundColor: _brand,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                shadowColor: _brand.withValues(alpha: 0.4),
              ).copyWith(
                elevation: WidgetStateProperty.resolveWith((states) {
                  if (states.contains(WidgetState.pressed)) return 0;
                  return 4;
                }),
              ),
              icon: const Icon(Icons.timer_rounded, size: 18),
              label: const Text(
                'Demo Trial Gratis',
                style: TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.1,
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),

          // Secondary
          SizedBox(
            height: 48,
            child: TextButton(
              onPressed: _handleMasuk,
              style: TextButton.styleFrom(
                foregroundColor: const Color(0xFF5A6375),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: RichText(
                text: const TextSpan(
                  style: TextStyle(
                    fontFamily: 'PlusJakartaSans',
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Color(0xFF5A6375),
                  ),
                  children: [
                    TextSpan(text: 'Sudah punya lisensi? '),
                    TextSpan(
                      text: 'Masuk',
                      style: TextStyle(
                        color: _brand,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

