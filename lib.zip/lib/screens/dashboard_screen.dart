import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../providers/providers.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../core/theme.dart';
import '../widgets/kasir_drawer.dart';
import '../widgets/scan_pairing_dialog.dart';
import '../widgets/modern_confirm_dialog.dart';
import '../services/local_notification_service.dart';
import '../providers/companion_scanner_provider.dart';
import '../services/support_contact_service.dart';
import '../utils/staff_access.dart';
import '../utils/currency_input_formatter.dart';
import 'main_shell.dart';
import 'detail_transaksi_piutang_screen.dart';
import 'struk_screen.dart';
import 'riwayat_tutup_kasir_screen.dart';

// COLOR CONSTANTS

const Color _kBrand = AppColors.primaryBrand;
const Color _kTealDark = Color(0xFF1E40AF);
const Color _kTealDeep = AppColors.primaryDark;
const String _kDashboardAccessDeniedMessage =
    'Akses Dibatasi: Admin/Owner dapat mengubah izin di menu Karyawan.';

void _showDashboardAccessDenied(BuildContext context) {
  ScaffoldMessenger.of(context)
    ..clearSnackBars()
    ..showSnackBar(
      const SnackBar(
        content: Text(_kDashboardAccessDeniedMessage),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
        duration: Duration(milliseconds: 1500),
      ),
    );
}

String _formatQtyLabel(double qty) {
  return qty
      .toStringAsFixed(2)
      .replaceAll(RegExp(r'0+$'), '')
      .replaceAll(RegExp(r'\.$'), '')
      .replaceAll('.', ',');
}

String _transactionItemQtyLabel(TransactionItem item) {
  final unit = item.unit?.trim();
  final qty = _formatQtyLabel(item.qty);
  if (unit != null && unit.isNotEmpty) return '$qty $unit';
  return '$qty item';
}

// RECENT TRANSACTIONS PROVIDER

final recentTransactionsProvider =
    FutureProvider<List<Transaction>>((ref) async {
  ref.watch(transactionsProvider);
  return await DBHelper.instance.getAllTransactions(limit: 10);
});

// DASHBOARD SCREEN

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  static const _pushedSessionNotificationIdsKey =
      'dashboard_pushed_session_notification_ids';

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _notificationSnapshotReady = false;
  Set<String> _knownNotificationIds = <String>{};
  Set<String> _pushedSessionNotificationIds = <String>{};
  Future<void>? _loadPushedSessionNotificationIdsFuture;

  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));
    _checkBackupReminder();
    unawaited(_ensurePushedSessionNotificationIdsLoaded());
  }

  Future<void> _ensurePushedSessionNotificationIdsLoaded() {
    return _loadPushedSessionNotificationIdsFuture ??=
        _loadPushedSessionNotificationIds();
  }

  Future<void> _loadPushedSessionNotificationIds() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _pushedSessionNotificationIds =
          (prefs.getStringList(_pushedSessionNotificationIdsKey) ?? []).toSet();
    } catch (e) {
      debugPrint('load pushed session notification ids error: $e');
    }
  }

  Future<bool> _canPushSystemNotification(NotificationItem item) async {
    if (!item.id.startsWith('active_session_')) return true;

    await _ensurePushedSessionNotificationIdsLoaded();
    return !_pushedSessionNotificationIds.contains(item.id);
  }

  Future<void> _markSystemNotificationPushed(NotificationItem item) async {
    if (!item.id.startsWith('active_session_')) return;

    await _ensurePushedSessionNotificationIdsLoaded();
    if (!_pushedSessionNotificationIds.add(item.id)) return;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _pushedSessionNotificationIdsKey,
      _pushedSessionNotificationIds.take(100).toList(),
    );
  }

  Future<void> _pushNewestNotificationIfNeeded(
    List<NotificationItem> newItems,
  ) async {
    if (newItems.isEmpty) return;
    if (!(Platform.isAndroid ||
        Platform.isIOS ||
        Platform.isMacOS ||
        Platform.isWindows)) {
      return;
    }

    final newest = newItems.first;
    if (!await _canPushSystemNotification(newest)) return;
    if (!mounted) return;

    await LocalNotificationService.show(
      id: newest.id.hashCode,
      title: newest.title,
      body: newest.subtitle,
    );
    await _markSystemNotificationPushed(newest);
  }

  Future<void> _checkBackupReminder() async {
    await Future.delayed(const Duration(seconds: 3));
    if (!mounted) return;
    final shouldRemind = await ref.read(backupCheckProvider.future);
    if (shouldRemind) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          backgroundColor: AppColors.warning,
          elevation: 4,
          duration: const Duration(seconds: 10),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: const BoxDecoration(
                      color: Colors.white24, borderRadius: BorderRadius.zero),
                  child: const Icon(Icons.backup_rounded,
                      color: Colors.white, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Butuh Backup Data',
                          style: TextStyle(
                              fontFamily: 'PlusJakartaSans',
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                              color: Colors.white)),
                      Text('Data belum di-backup > 7 hari',
                          style: TextStyle(
                              fontFamily: 'PlusJakartaSans',
                              fontSize: 11,
                              color: Colors.white.withValues(alpha: 0.7))),
                    ],
                  ),
                ),
              ]),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () =>
                        ScaffoldMessenger.of(context).hideCurrentSnackBar(),
                    child: const Text('NANTI SAJA',
                        style: TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                            fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: () {
                      ScaffoldMessenger.of(context).hideCurrentSnackBar();
                      final activeStaff = ref.read(activeStaffProvider);
                      if (StaffAccess.can(
                          activeStaff, StaffPermissionKey.settings)) {
                        Navigator.pushNamed(context, '/backup_restore');
                      } else {
                        _showDashboardAccessDenied(context);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: AppColors.warning,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 0),
                      minimumSize: const Size(0, 32),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    child: const Text('CADANGKAN',
                        style: TextStyle(
                            fontSize: 12, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }
  }

  String _fmtRp(int v) {
    final s = v.abs().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp ${v < 0 ? '-' : ''}$buf';
  }

  Future<void> _openShiftCashCount(
    int expectedCash,
    dynamic activeSession,
  ) async {
    if (activeSession is! KasirSession) {
      final activeStaff = ref.read(activeStaffProvider);
      if (StaffAccess.can(activeStaff, StaffPermissionKey.wallet)) {
        Navigator.pushNamed(context, '/dompet');
      } else {
        _showDashboardAccessDenied(context);
      }
      return;
    }
    await _showShiftCashCountDialog(
      context: context,
      ref: ref,
      expectedCash: expectedCash,
      session: activeSession,
    );
  }

  void _openBusinessCashbook() {
    final activeStaff = ref.read(activeStaffProvider);
    if (StaffAccess.can(activeStaff, StaffPermissionKey.wallet)) {
      Navigator.pushNamed(context, '/dompet');
    } else {
      _showDashboardAccessDenied(context);
    }
  }

  Widget _buildShiftKpiCard({
    required int drawerCash,
    required dynamic activeSession,
    bool compact = false,
    bool inverted = false,
  }) {
    final shiftSummary = ref.watch(activeShiftSummaryProvider).asData?.value;
    final nonCashShift = activeSession == null ? 0 : shiftSummary?.nonCash ?? 0;
    final totalShift =
        activeSession == null ? 0 : shiftSummary?.totalRevenue ?? 0;

    return _ShiftKpiCard(
      cashValue: activeSession == null ? 'Shift Tutup' : _fmtRp(drawerCash),
      nonCashValue: _fmtRp(nonCashShift),
      totalValue: _fmtRp(totalShift),
      active: activeSession != null,
      onCountTap: () => _openShiftCashCount(drawerCash, activeSession),
      onWalletTap: _openBusinessCashbook,
      compact: compact,
      inverted: inverted,
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 11) return 'Selamat Pagi';
    if (hour < 15) return 'Selamat Siang';
    if (hour < 18) return 'Selamat Sore';
    return 'Selamat Malam';
  }

  String _normalizedservisStatus(Transaction tx) {
    final status = tx.servisStatus.trim();
    if (status == 'Siap Ambil') return 'Siap';
    if (status.toLowerCase().startsWith('selesai')) return 'Selesai';
    return status.isEmpty ? 'Diterima' : status;
  }

  bool _isActiveservis(Transaction tx) =>
      tx.isDeleted == 0 && _normalizedservisStatus(tx) != 'Selesai';

  int _countActiveservis(List<Transaction> txs) {
    return txs.where(_isActiveservis).length;
  }

  int _countReadyForPickup(List<Transaction> txs) {
    return txs
        .where((t) => t.isDeleted == 0 && _normalizedservisStatus(t) == 'Siap')
        .length;
  }

  int _countUnpaid(List<Transaction> txs) {
    return txs
        .where((t) => t.isDeleted == 0 && t.amountPaid < t.grandTotal)
        .length;
  }

  bool get _isTablet => MediaQuery.of(context).size.shortestSide >= 600;
  bool get _isLandscape =>
      MediaQuery.of(context).orientation == Orientation.landscape;

  @override
  Widget build(BuildContext context) {
    ref.listen(allNotificationsProvider, (previous, next) {
      final data = next.asData;
      if (data == null) return;
      final items = data.value;

      final currentIds = items.map((item) => item.id).toSet();
      if (!_notificationSnapshotReady) {
        _knownNotificationIds = currentIds;
        _notificationSnapshotReady = true;
        return;
      }

      final newItems = items
          .where((item) => !_knownNotificationIds.contains(item.id))
          .toList();
      _knownNotificationIds = currentIds;

      unawaited(_pushNewestNotificationIfNeeded(newItems));
    });

    final summaryAsync = ref.watch(dashboardProvider);
    final todaySales = summaryAsync.asData?.value.todaySales ?? 0;
    final isLoading = summaryAsync.isLoading && !summaryAsync.hasValue;
    final drawerCash = ref.watch(drawerCashProvider).asData?.value ?? 0;
    final activeSession = ref.watch(activeKasirSessionProvider).asData?.value;

    // Servis Data
    final allTransactions = ref.watch(transactionsProvider);

    if (_isTablet) {
      // Inside shell: shell provides the rail, just return content
      final inShell = ShellScope.of(context) != null;
      if (inShell) {
        return Scaffold(
          backgroundColor: const Color(0xFFF0F2F5),
          body: SafeArea(
            top: false,
            bottom: false,
            child: _isLandscape
                ? _buildTabletLandscapeContent(todaySales, isLoading,
                    drawerCash, activeSession, allTransactions)
                : _buildTabletPortraitContent(todaySales, isLoading, drawerCash,
                    activeSession, allTransactions),
          ),
        );
      }
      return _buildTabletLayout(
          todaySales, isLoading, drawerCash, activeSession, allTransactions);
    } else if (_isLandscape) {
      return _buildPhoneLandscapeLayout(
          todaySales, isLoading, drawerCash, activeSession, allTransactions);
    } else {
      return _buildPhonePortraitLayout(
          todaySales, isLoading, drawerCash, activeSession, allTransactions);
    }
  }

  // PHONE PORTRAIT

  Widget _buildPhonePortraitLayout(
      int todaySales,
      bool isLoading,
      int drawerCash,
      dynamic activeSession,
      List<Transaction> allTransactions) {
    final inShell = ShellScope.of(context) != null;
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: const Color(0xFFF5F7FA),
      drawer: inShell ? null : const KasirDrawer(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildGradientHeader(
              todaySales: todaySales,
              activeservis: _countActiveservis(allTransactions),
              isLoading: isLoading,
              drawerCash: drawerCash,
              activeSession: activeSession,
              showDrawerBtn: true,
              borderRadius: BorderRadius.zero,
            ),
            const _TrialCountdownBanner(),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 40),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _servisQuickStats(
                    activeservis: _countActiveservis(allTransactions),
                    readyForPickup: _countReadyForPickup(allTransactions),
                    unpaidCount: _countUnpaid(allTransactions),
                  ),
                  const SizedBox(height: 12),
                  const SizedBox(height: 16),
                  const _SalesProgressCard(),
                  const _MainKasirCard(),
                  const SizedBox(height: 12),
                  const _MenuGrid(crossAxisCount: 4),
                  const SizedBox(height: 24),
                  const _RecentTransactionsList(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // PHONE LANDSCAPE

  Widget _buildPhoneLandscapeLayout(
      int todaySales,
      bool isLoading,
      int drawerCash,
      dynamic activeSession,
      List<Transaction> allTransactions) {
    final inShell = ShellScope.of(context) != null;
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: const Color(0xFFF5F7FA),
      drawer: inShell ? null : const KasirDrawer(),
      body: Row(
        children: [
          SizedBox(
            width: 280,
            child: _buildGradientHeader(
              todaySales: todaySales,
              activeservis: _countActiveservis(allTransactions),
              isLoading: isLoading,
              drawerCash: drawerCash,
              activeSession: activeSession,
              showDrawerBtn: true,
              fullHeight: true,
              compact: true,
              borderRadius: BorderRadius.zero,
            ),
          ),
          const Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(16, 14, 16, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _TrialCountdownBanner(),
                  _SalesProgressCard(),
                  _MainKasirCard(),
                  SizedBox(height: 12),
                  _MenuGrid(crossAxisCount: 4),
                  SizedBox(height: 20),
                  _RecentTransactionsList(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // TABLET LAYOUT Professional POS Dashboard
  // Extended NavigationRail + KPI sidebar + content

  Widget _buildTabletLayout(int todaySales, bool isLoading, int drawerCash,
      dynamic activeSession, List<Transaction> allTransactions) {
    final isLandscape = _isLandscape;

    return Scaffold(
      backgroundColor: const Color(0xFFF0F2F5),
      body: SafeArea(
        bottom: false,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildExtendedRail(),
            // Separator removed to fix visual "gap"

            Expanded(
              child: isLandscape
                  ? _buildTabletLandscapeContent(todaySales, isLoading,
                      drawerCash, activeSession, allTransactions)
                  : _buildTabletPortraitContent(todaySales, isLoading,
                      drawerCash, activeSession, allTransactions),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExtendedRail() {
    return Container(
      width: 80,
      color: _kTealDeep,
      child: Column(
        children: [
          const SizedBox(height: 12),
          const Divider(
              height: 1, color: Colors.white12, indent: 16, endIndent: 16),
          const SizedBox(height: 8),

          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.zero,
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  ..._railItems().map((item) => _RailItem(
                        icon: item.icon,
                        activeIcon: item.activeIcon,
                        label: item.label,
                        isSelected: item.isSelected,
                        locked: item.locked,
                        onTap: item.onTap == null
                            ? null
                            : () => item.onTap!(context),
                      )),
                ],
              ),
            ),
          ),

          const SizedBox(height: 8),
          const Divider(
              height: 1, color: Colors.white12, indent: 16, endIndent: 16),
          // Settings at bottom
          _RailItem(
            icon: Icons.settings_outlined,
            activeIcon: Icons.settings_rounded,
            label: 'Setting',
            isSelected: false,
            locked: !StaffAccess.can(
              ref.watch(activeStaffProvider),
              StaffPermissionKey.settings,
            ),
            onTap: () {
              final shell = ShellScope.of(context);
              if (shell != null) {
                shell.onNavigate(9);
                return;
              }
              final activeStaff = ref.read(activeStaffProvider);
              if (StaffAccess.can(activeStaff, StaffPermissionKey.settings)) {
                Navigator.pushNamed(context, '/setting');
              } else {
                _showDashboardAccessDenied(context);
              }
            },
          ),
        ],
      ),
    );
  }

  List<_NavItem> _railItems() {
    final shell = ShellScope.of(context);
    final activeStaff = ref.read(activeStaffProvider);

    void openShellIndex(BuildContext ctx, int index, String route) {
      if (shell != null) {
        shell.onNavigate(index);
        return;
      }
      if (StaffAccess.canOpenShellIndex(activeStaff, index)) {
        Navigator.pushNamed(ctx, route);
      } else {
        _showDashboardAccessDenied(ctx);
      }
    }

    return [
      const _NavItem(
          Icons.dashboard_outlined, Icons.dashboard_rounded, 'Dashboard', null,
          isSelected: true),
      _NavItem(Icons.point_of_sale_outlined, Icons.point_of_sale_rounded,
          'Transaksi Servis', (ctx) => openShellIndex(ctx, 1, '/transaksi'),
          locked: !StaffAccess.canOpenShellIndex(activeStaff, 1)),
      _NavItem(Icons.assignment_outlined, Icons.assignment_rounded,
          'Riwayat & Tagihan', (ctx) => openShellIndex(ctx, 4, '/riwayat'),
          locked: !StaffAccess.canOpenShellIndex(activeStaff, 4)),
      _NavItem(Icons.insert_chart_outlined, Icons.insert_chart_rounded,
          'Laporan', (ctx) => openShellIndex(ctx, 5, '/laporan'),
          locked: !StaffAccess.canOpenShellIndex(activeStaff, 5)),
      _NavItem(Icons.people_outline_rounded, Icons.people_rounded, 'Pelanggan',
          (ctx) => openShellIndex(ctx, 6, '/pelanggan'),
          locked: !StaffAccess.canOpenShellIndex(activeStaff, 6)),
      _NavItem(Icons.badge_outlined, Icons.badge_rounded, 'Karyawan',
          (ctx) => openShellIndex(ctx, 7, '/karyawan'),
          locked: !StaffAccess.canOpenShellIndex(activeStaff, 7)),
      _NavItem(Icons.notifications_outlined, Icons.notifications_rounded,
          'Notifikasi', (ctx) => openShellIndex(ctx, 8, '/notifikasi'),
          locked: !StaffAccess.canOpenShellIndex(activeStaff, 8)),
    ];
  }

  Widget _buildTabletPortraitContent(
      int todaySales,
      bool isLoading,
      int drawerCash,
      dynamic activeSession,
      List<Transaction> allTransactions) {
    final summaryAsync = ref.watch(dashboardProvider);

    return Column(
      children: [
        _buildTabletTopBar(todaySales, isLoading, drawerCash, activeSession,
            _countActiveservis(allTransactions),
            hideStats: true),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Ringkasan Bisnis',
                        style: GoogleFonts.poppins(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFF1E293B))),
                    Text('Pantau performa servis Anda secara real-time.',
                        style: GoogleFonts.inter(
                            fontSize: 12, color: Colors.grey.shade600)),
                  ],
                ),
                const SizedBox(height: 20),

                _buildShiftKpiCard(
                  drawerCash: drawerCash,
                  activeSession: activeSession,
                  compact: true,
                ),
                const SizedBox(height: 12),

                // Top Mini Stats Row
                summaryAsync.when(
                  data: (s) => Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: _StatCard(
                              label: 'Omset Hari Ini',
                              value: _fmtRp(s.todaySales),
                              icon: Icons.account_balance_wallet_rounded,
                              color: _kBrand,
                              trend: 'Harian',
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _StatCard(
                              label: 'Belum Lunas',
                              value: _fmtRp(s.todayUnpaid),
                              icon: Icons.money_off_rounded,
                              color: Colors.red.shade600,
                              trend: 'Perlu Tagih',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: _StatCard(
                              label: 'Pesanan Baru',
                              value: '${s.todayCount}',
                              icon: Icons.add_shopping_cart_rounded,
                              color: Colors.blue.shade700,
                              trend: 'Total Order',
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _StatCard(
                              label: 'Siap Ambil',
                              value: '${s.todayCompleted}',
                              icon: Icons.task_alt_rounded,
                              color: const Color(0xFF2563EB),
                              trend: 'Siap Diambil',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  loading: () => const SizedBox(height: 180),
                  error: (_, __) => const SizedBox(),
                ),
                const SizedBox(height: 24),

                const _MainKasirCard(),
                const SizedBox(height: 24),

                // Weekly Chart Section
                Row(
                  children: [
                    const Icon(Icons.bar_chart_rounded,
                        size: 18, color: _kBrand),
                    const SizedBox(width: 8),
                    Text('Tren Omset Mingguan',
                        style: GoogleFonts.poppins(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFF1E293B))),
                  ],
                ),
                const SizedBox(height: 12),
                Consumer(builder: (context, ref, _) {
                  final trendAsync = ref.watch(salesTrendProvider);
                  return trendAsync.when(
                    data: (data) => _SalesTrendChart(data: data),
                    loading: () => const SizedBox(height: 200),
                    error: (_, __) => const SizedBox(),
                  );
                }),
                const SizedBox(height: 28),
                summaryAsync.when(
                  data: (s) => _LowStockAnalysis(items: s.lowStockProducts),
                  loading: () => const SizedBox(),
                  error: (_, __) => const SizedBox(),
                ),
                const SizedBox(height: 28),
                const _RecentTransactionsList(),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTabletLandscapeContent(
      int todaySales,
      bool isLoading,
      int drawerCash,
      dynamic activeSession,
      List<Transaction> allTransactions) {
    final summaryAsync = ref.watch(dashboardProvider);
    final activeservis = _countActiveservis(allTransactions);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // MAIN DASHBOARD AREA
        Expanded(
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(24, 24, 24, 40),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // NEW UNIFIED HEADER
                      _UnifiedDashHeader(activeSession: activeSession),
                      const _TrialCountdownBanner(),
                      const SizedBox(height: 16),

                      // 1. PRIMARY KPI ROW (CASH, REVENUE, TRANSACTIONS)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 24),
                        child: Column(
                          children: [
                            _buildShiftKpiCard(
                              drawerCash: drawerCash,
                              activeSession: activeSession,
                            ),
                            const SizedBox(height: 16),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: _StatCard(
                                    label: 'Pendapatan Hari Ini',
                                    value: _fmtRp(todaySales),
                                    icon: Icons.auto_graph_rounded,
                                    color: const Color(0xFF16A34A),
                                    trend: 'Total Omset',
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: _StatCard(
                                    label: 'Order Aktif',
                                    value: isLoading ? '...' : '$activeservis',
                                    icon: Icons.assignment_turned_in_outlined,
                                    color: AppColors.info,
                                    trend: 'Belum Selesai',
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: _StatCard(
                                    label: 'Transaksi Hari Ini',
                                    value: summaryAsync.asData?.value.todayCount
                                            .toString() ??
                                        '0',
                                    icon: Icons.receipt_long_rounded,
                                    color: const Color(0xFF6366F1),
                                    trend: 'Total Order',
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      // 2. OPERATIONAL STATUS (Proses, Siap Ambil, Belum Lunas)
                      _servisQuickStats(
                        activeservis: _countActiveservis(allTransactions),
                        readyForPickup: _countReadyForPickup(allTransactions),
                        unpaidCount: _countUnpaid(allTransactions),
                      ),
                      const SizedBox(height: 24),
                      const SizedBox(height: 16),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // CENTER COLUMN (Wide Charts)
                          Expanded(
                            flex: 3,
                            child: Column(
                              children: [
                                const _MainKasirCard(),
                                const SizedBox(height: 24),
                                Consumer(builder: (context, ref, _) {
                                  final trendAsync =
                                      ref.watch(salesTrendProvider);
                                  return trendAsync.when(
                                    data: (data) =>
                                        _SalesTrendChart(data: data),
                                    loading: () => const SizedBox(
                                        height: 300,
                                        child: Center(
                                            child:
                                                CircularProgressIndicator())),
                                    error: (_, __) => const SizedBox(),
                                  );
                                }),
                                const SizedBox(height: 24),
                                // FILLING THE GAP (PHASE 3)
                                Consumer(builder: (context, ref, _) {
                                  final statsAsync =
                                      ref.watch(categorySalesProvider);
                                  return statsAsync.when(
                                    data: (stats) => _CategoryPerformanceCard(
                                        categoryStats: stats),
                                    loading: () => const SizedBox(height: 200),
                                    error: (_, __) => const SizedBox(),
                                  );
                                }),
                              ],
                            ),
                          ),
                          const SizedBox(width: 24),

                          // RIGHT COLUMN (Analytics & Logs)
                          Expanded(
                            flex: 2,
                            child: Column(
                              children: [
                                summaryAsync.when(
                                  data: (s) => Column(
                                    children: [
                                      // Removed TopProductsAnalysis as requested
                                      _LowStockAnalysis(
                                          items: s.lowStockProducts),
                                    ],
                                  ),
                                  loading: () => const SizedBox(height: 200),
                                  error: (_, __) => const SizedBox(),
                                ),
                                const SizedBox(height: 24),
                                const _RecentTransactionsList(),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTabletTopBar(int todaySales, bool isLoading, int drawerCash,
      dynamic activeSession, int activeservis,
      {bool hideStats = false}) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_kBrand, _kTealDark, _kTealDeep],
          stops: [0.0, 0.55, 1.0],
        ),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 16, 0),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_getGreeting(),
                          style: GoogleFonts.inter(
                              color: Colors.white70,
                              fontSize: 12,
                              fontWeight: FontWeight.w500)),
                      FutureBuilder<Map<String, dynamic>>(
                        future: DBHelper.instance.getWarungProfile(),
                        builder: (context, snapshot) {
                          String name = 'Juragan Servis';
                          if (snapshot.hasData) {
                            final dbName = snapshot.data!['nama']?.toString();
                            if (dbName != null && dbName.trim().isNotEmpty) {
                              name = dbName;
                            }
                          }
                          return Text(name,
                              style: GoogleFonts.poppins(
                                  color: Colors.white,
                                  fontSize: 22,
                                  height: 1.1,
                                  fontWeight: FontWeight.w700));
                        },
                      ),
                      const SizedBox(height: 0),
                      Row(children: [
                        Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            shape: BoxShape.rectangle,
                            color: activeSession != null
                                ? Colors.greenAccent
                                : Colors.redAccent,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Flexible(
                          child: Text(
                            activeSession != null
                                ? 'Petugas: ${activeSession.kasirName}'
                                : 'Shift Tutup',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.inter(
                                color: Colors.white70,
                                fontSize: 12,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                      ]),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                if (Platform.isAndroid || Platform.isIOS)
                  IconButton(
                    icon: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.zero,
                        border: Border.all(color: Colors.white24),
                      ),
                      child: const Icon(Icons.account_balance_wallet_rounded,
                          color: Colors.white, size: 18),
                    ),
                    onPressed: _openBusinessCashbook,
                    tooltip: 'Buka Buku Kas Usaha',
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                if (Platform.isAndroid || Platform.isIOS)
                  const SizedBox(width: 8),
                if (Platform.isAndroid || Platform.isIOS)
                  IconButton(
                    icon: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.zero,
                        border: Border.all(color: Colors.white24),
                      ),
                      child: Consumer(
                        builder: (context, ref, _) {
                          final notifCount =
                              ref.watch(unreadNotificationsProvider).length;
                          return Stack(
                            clipBehavior: Clip.none,
                            children: [
                              const Icon(Icons.notifications_none_rounded,
                                  color: Colors.white, size: 18),
                              if (notifCount > 0)
                                Positioned(
                                  right: -6,
                                  top: -6,
                                  child: _NotificationCountBadge(
                                      count: notifCount),
                                ),
                            ],
                          );
                        },
                      ),
                    ),
                    onPressed: () {
                      final shell = ShellScope.of(context);
                      if (shell != null) {
                        shell.onNavigate(8);
                      } else {
                        Navigator.pushNamed(context, '/notifikasi');
                      }
                    },
                    tooltip: 'Buka Notifikasi',
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                const SizedBox(width: 8),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (!hideStats) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Expanded(
                      child: _HeroStatTile(
                          label: 'Pendapatan Hari Ini',
                          value: isLoading ? '...' : _fmtRp(todaySales),
                          onTap: () {
                            final shell = ShellScope.of(context);
                            if (shell != null) {
                              shell.onNavigate(4);
                            } else {
                              Navigator.pushNamed(context, '/riwayat');
                            }
                          })),
                  const SizedBox(width: 12),
                  Expanded(
                      child: _HeroStatTile(
                          label: 'Order Aktif',
                          value: isLoading ? '...' : '$activeservis',
                          onTap: () {
                            final shell = ShellScope.of(context);
                            if (shell != null) {
                              shell.onNavigate(10);
                            } else {
                              Navigator.pushNamed(context, '/servis_status');
                            }
                          })),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: _buildShiftKpiCard(
                drawerCash: drawerCash,
                activeSession: activeSession,
                compact: true,
                inverted: true,
              ),
            ),
          ],
          if (!hideStats) const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildGradientHeader({
    required int todaySales,
    required int activeservis,
    required bool isLoading,
    required int drawerCash,
    required dynamic activeSession,
    bool compact = false,
    bool showDrawerBtn = true,
    bool fullHeight = false,
    BorderRadius? borderRadius,
    bool hideStats = false,
    bool hideRecentList = false,
  }) {
    final decoration = BoxDecoration(
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [_kBrand, _kTealDark, _kTealDeep],
        stops: [0.0, 0.55, 1.0],
      ),
      borderRadius: borderRadius ?? BorderRadius.zero,
    );

    final content = SafeArea(
      bottom: false,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 6, 6, 0),
            child: Row(
              children: [
                if (showDrawerBtn)
                  IconButton(
                    icon: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                            height: 2,
                            width: 20,
                            decoration:
                                const BoxDecoration(color: Colors.white)),
                        const SizedBox(height: 4),
                        Container(
                            height: 2,
                            width: 14,
                            decoration:
                                const BoxDecoration(color: Colors.white70)),
                        const SizedBox(height: 4),
                        Container(
                            height: 2,
                            width: 20,
                            decoration:
                                const BoxDecoration(color: Colors.white)),
                      ],
                    ),
                    onPressed: () {
                      final shell = ShellScope.of(context);
                      if (shell?.openDrawer != null) {
                        shell!.openDrawer!();
                      } else {
                        _scaffoldKey.currentState?.openDrawer();
                      }
                    },
                  ),
                if (showDrawerBtn) const SizedBox(width: 4),
                if (!showDrawerBtn) const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      FutureBuilder<Map<String, dynamic>>(
                        future: DBHelper.instance.getWarungProfile(),
                        builder: (context, snapshot) {
                          String name = 'Juragan Servis';
                          if (snapshot.hasData) {
                            final dbName = snapshot.data!['nama']?.toString();
                            if (dbName != null && dbName.trim().isNotEmpty) {
                              name = dbName;
                            }
                          }
                          return Text(name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.poppins(
                                  color: Colors.white,
                                  fontSize: compact ? 14 : 16,
                                  height: 1.1,
                                  fontWeight: FontWeight.w600));
                        },
                      ),
                      const SizedBox(height: 0),
                      Row(children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            shape: BoxShape.rectangle,
                            color: activeSession != null
                                ? Colors.greenAccent
                                : Colors.redAccent,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Flexible(
                          child: Text(
                            activeSession != null
                                ? 'Petugas: ${activeSession.kasirName}'
                                : 'Shift Tutup',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.inter(
                                color: Colors.white70,
                                fontSize: compact ? 10 : 11,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                      ]),
                      if (Platform.isWindows) const SizedBox(height: 12),
                      if (Platform.isWindows)
                        Consumer(builder: (context, ref, _) {
                          final state =
                              ref.watch(companionScannerStateProvider);

                          String remoteSubtitle = 'OFF';
                          bool isConnected = state.connectedDevices.isNotEmpty;
                          final hasHostStatus = state.isRunning ||
                              state.isStarting ||
                              (state.errorMessage?.isNotEmpty ?? false);

                          if (state.isStarting) {
                            remoteSubtitle = 'Memulai...';
                          } else if (state.isRetryScheduled) {
                            remoteSubtitle = 'Retry Otomatis';
                          } else if (state.errorMessage?.isNotEmpty ?? false) {
                            remoteSubtitle = 'Gagal';
                          } else if (state.isRunning) {
                            remoteSubtitle = isConnected
                                ? state.connectedDevices.first
                                : 'Standby';
                          } else if (!state.autoStartEnabled) {
                            remoteSubtitle = 'Manual';
                          }

                          return Row(
                            children: [
                              Flexible(
                                child: _ScannerStatusPill(
                                  label: 'HP',
                                  isActive: hasHostStatus,
                                  subtitle: remoteSubtitle,
                                  icon: Icons.phonelink_ring_rounded,
                                  indicatorColor: isConnected
                                      ? Colors.greenAccent
                                      : state.isStarting
                                          ? Colors.blueAccent
                                          : (state.errorMessage?.isNotEmpty ??
                                                  false)
                                              ? Colors.redAccent
                                              : (state.isRunning
                                                  ? Colors.white38
                                                  : null),
                                ),
                              ),
                              const SizedBox(width: 8),
                              const Flexible(
                                child: _ScannerStatusPill(
                                  label: 'USB',
                                  isActive: true,
                                  subtitle: 'Siap',
                                  icon: Icons.usb_rounded,
                                ),
                              ),
                            ],
                          );
                        }),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                if (Platform.isWindows)
                  IconButton(
                    icon: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.zero,
                        border: Border.all(color: Colors.white24),
                      ),
                      child: const Icon(Icons.qr_code_scanner_rounded,
                          color: Colors.white, size: 18),
                    ),
                    onPressed: () => ScanPairingDialog.show(context),
                    tooltip: 'Gunakan HP Sebagai Scanner',
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                if (Platform.isWindows)
                  IconButton(
                    icon: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.zero,
                        border: Border.all(color: Colors.white24),
                      ),
                      child: const Icon(Icons.lock_person_rounded,
                          color: Colors.white, size: 18),
                    ),
                    onPressed: () async {
                      final confirmed = await ModernConfirmDialog.show(
                        context,
                        title: 'Kunci Terminal?',
                        content: activeSession == null
                            ? 'Akses terminal akan dikunci. Anda harus login kembali untuk masuk.'
                            : 'Shift kasir tetap aktif dan tidak ditutup. Anda harus login kembali untuk masuk.',
                        confirmLabel: 'Kunci Sekarang',
                        icon: Icons.lock_person_rounded,
                        color: AppColors.danger,
                      );
                      if (confirmed == true) {
                        await ref.read(activeStaffProvider.notifier).set(null);
                      }
                    },
                    tooltip: 'Keluar Terminal (Kunci)',
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                if (Platform.isAndroid || Platform.isIOS)
                  IconButton(
                    icon: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.zero,
                        border: Border.all(color: Colors.white24),
                      ),
                      child: const Icon(Icons.account_balance_wallet_rounded,
                          color: Colors.white, size: 18),
                    ),
                    onPressed: _openBusinessCashbook,
                    tooltip: 'Buka Buku Kas Usaha',
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                if (Platform.isAndroid || Platform.isIOS)
                  const SizedBox(width: 8),
                if (Platform.isAndroid || Platform.isIOS)
                  IconButton(
                    icon: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.zero,
                        border: Border.all(color: Colors.white24),
                      ),
                      child: Consumer(
                        builder: (context, ref, _) {
                          final notifCount =
                              ref.watch(unreadNotificationsProvider).length;
                          return Stack(
                            clipBehavior: Clip.none,
                            children: [
                              const Icon(Icons.notifications_none_rounded,
                                  color: Colors.white, size: 18),
                              if (notifCount > 0)
                                Positioned(
                                  right: -6,
                                  top: -6,
                                  child: _NotificationCountBadge(
                                      count: notifCount),
                                ),
                            ],
                          );
                        },
                      ),
                    ),
                    onPressed: () {
                      final shell = ShellScope.of(context);
                      if (shell != null) {
                        shell.onNavigate(8);
                      } else {
                        Navigator.pushNamed(context, '/notifikasi');
                      }
                    },
                    tooltip: 'Buka Notifikasi',
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                const SizedBox(width: 8),
              ],
            ),
          ),
          if (!hideStats) ...[
            SizedBox(height: compact ? 4 : 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: compact
                  ? Column(
                      children: [
                        _HeroStatTile(
                            label: 'Omset Hari Ini',
                            value: isLoading ? '...' : _fmtRp(todaySales),
                            onTap: () {
                              final shell = ShellScope.of(context);
                              if (shell != null) {
                                shell.onNavigate(4); // Riwayat (History)
                              } else {
                                Navigator.pushNamed(context, '/riwayat');
                              }
                            }),
                        const SizedBox(height: 8),
                        _HeroStatTile(
                            label: 'Order Aktif',
                            value: isLoading ? '...' : '$activeservis',
                            onTap: () {
                              final shell = ShellScope.of(context);
                              if (shell != null) {
                                shell.onNavigate(10);
                              } else {
                                Navigator.pushNamed(context, '/servis_status');
                              }
                            }),
                      ],
                    )
                  : Row(
                      children: [
                        Expanded(
                            child: _HeroStatTile(
                                label: 'Omset Hari Ini',
                                value: isLoading ? '...' : _fmtRp(todaySales),
                                onTap: () {
                                  final shell = ShellScope.of(context);
                                  if (shell != null) {
                                    shell.onNavigate(4);
                                  } else {
                                    Navigator.pushNamed(context, '/riwayat');
                                  }
                                })),
                        const SizedBox(width: 10),
                        Expanded(
                            child: _HeroStatTile(
                                label: 'Order Aktif',
                                value: isLoading ? '...' : '$activeservis',
                                onTap: () {
                                  final shell = ShellScope.of(context);
                                  if (shell != null) {
                                    shell.onNavigate(10);
                                  } else {
                                    Navigator.pushNamed(
                                        context, '/servis_status');
                                  }
                                })),
                      ],
                    ),
            ),
          ],
          SizedBox(height: compact ? 8 : 12),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            child: _buildShiftKpiCard(
              drawerCash: drawerCash,
              activeSession: activeSession,
              compact: compact,
              inverted: true,
            ),
          ),
          if (fullHeight && !hideRecentList) ...[
            const SizedBox(height: 24),
            const _RecentTransactionsSidebar(),
          ],
        ],
      ),
    );

    if (fullHeight) {
      return Container(
        decoration: decoration,
        child: SizedBox.expand(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: content,
          ),
        ),
      );
    }

    return Container(
      decoration: decoration,
      child: content,
    );
  }
}

class _NotificationCountBadge extends StatelessWidget {
  final int count;

  const _NotificationCountBadge({required this.count});

  @override
  Widget build(BuildContext context) {
    final label = count > 99 ? '99+' : '$count';

    return Container(
      constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
      padding: const EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(
        color: AppColors.danger,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white, width: 1.4),
      ),
      alignment: Alignment.center,
      child: Text(
        label,
        style: GoogleFonts.inter(
          color: Colors.white,
          fontSize: count > 99 ? 8 : 9,
          height: 1,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

class _ShiftKpiCard extends StatefulWidget {
  final String cashValue;
  final String nonCashValue;
  final String totalValue;
  final bool active;
  final VoidCallback onCountTap;
  final VoidCallback onWalletTap;
  final bool compact;
  final bool inverted;

  const _ShiftKpiCard({
    required this.cashValue,
    required this.nonCashValue,
    required this.totalValue,
    required this.active,
    required this.onCountTap,
    required this.onWalletTap,
    this.compact = false,
    this.inverted = false,
  });

  @override
  State<_ShiftKpiCard> createState() => _ShiftKpiCardState();
}

class _ShiftKpiCardState extends State<_ShiftKpiCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final compact = widget.compact;
    final inverted = widget.inverted;
    final active = widget.active;
    final inkColor = inverted ? Colors.white : const Color(0xFF0F172A);
    final mutedColor = inverted ? Colors.white70 : const Color(0xFF64748B);
    final borderColor = inverted
        ? Colors.white.withValues(alpha: 0.16)
        : const Color(0xFFE2E8F0);
    final buttonColor = inverted
        ? Colors.white.withValues(alpha: 0.10)
        : const Color(0xFFF8FAFC);
    final iconBoxSize = compact ? 40.0 : 54.0;
    final amountSize = compact ? 20.0 : 27.0;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 14 : 22,
        vertical: compact ? 13 : 18,
      ),
      decoration: BoxDecoration(
        color: inverted ? Colors.white.withValues(alpha: 0.12) : Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: borderColor),
        boxShadow: inverted
            ? null
            : [
                BoxShadow(
                  color: const Color(0xFF0F172A).withValues(alpha: 0.025),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Tooltip(
                message: 'Buka Buku Kas Usaha',
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: widget.onWalletTap,
                    borderRadius: BorderRadius.zero,
                    child: Container(
                      width: iconBoxSize,
                      height: iconBoxSize,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: inverted
                            ? Colors.white.withValues(alpha: 0.16)
                            : const Color(0xFFF1F5F9),
                        borderRadius: BorderRadius.zero,
                        border: Border.all(
                          color: inverted
                              ? Colors.white.withValues(alpha: 0.22)
                              : const Color(0xFFE2E8F0),
                        ),
                      ),
                      child: Icon(
                        Icons.account_balance_wallet_rounded,
                        color: inverted ? Colors.white : _kBrand,
                        size: compact ? 22 : 28,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(width: compact ? 12 : 18),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Kas Tunai di Laci',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: compact ? 11 : 12,
                        color: mutedColor,
                        fontWeight: FontWeight.w800,
                        height: 1.1,
                        letterSpacing: 0,
                      ),
                    ),
                    SizedBox(height: compact ? 3 : 5),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(
                        widget.cashValue,
                        maxLines: 1,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: amountSize,
                          fontWeight: FontWeight.w800,
                          color: inkColor,
                          height: 1.05,
                          letterSpacing: 0,
                          fontFeatures: const [FontFeature.tabularFigures()],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: compact ? 8 : 12),
              _ShiftIconButton(
                icon: Icons.calculate_outlined,
                tooltip: active ? 'Hitung Kas Shift' : 'Buka Dompet Kasir',
                onTap: widget.onCountTap,
                color: inkColor,
                background: buttonColor,
                border: borderColor,
                compact: compact,
              ),
              if (active) ...[
                SizedBox(width: compact ? 6 : 8),
                _ShiftIconButton(
                  icon: _expanded
                      ? Icons.keyboard_arrow_up_rounded
                      : Icons.keyboard_arrow_down_rounded,
                  tooltip:
                      _expanded ? 'Tutup rincian shift' : 'Lihat rincian shift',
                  onTap: () => setState(() => _expanded = !_expanded),
                  color: inkColor,
                  background: buttonColor,
                  border: borderColor,
                  compact: compact,
                ),
              ],
            ],
          ),
          AnimatedSize(
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOutCubic,
            alignment: Alignment.topCenter,
            child: active && _expanded
                ? Column(
                    children: [
                      SizedBox(height: compact ? 10 : 14),
                      Divider(
                        height: 1,
                        color: inverted
                            ? Colors.white.withValues(alpha: 0.16)
                            : const Color(0xFFE2E8F0),
                      ),
                      SizedBox(height: compact ? 9 : 12),
                      _ShiftBreakdown(
                        nonCashLabel: 'Non Tunai',
                        nonCashValue: widget.nonCashValue,
                        totalLabel: 'Pemasukan Shift',
                        totalValue: widget.totalValue,
                        totalSubtitle: 'Tunai + Non Tunai',
                        compact: compact,
                        inverted: inverted,
                      ),
                    ],
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}

class _ShiftIconButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;
  final Color color;
  final Color background;
  final Color border;
  final bool compact;

  const _ShiftIconButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
    required this.color,
    required this.background,
    required this.border,
    required this.compact,
  });

  @override
  Widget build(BuildContext context) {
    final size = compact ? 38.0 : 46.0;
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        child: Container(
          width: size,
          height: size,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: border),
          ),
          child: Icon(icon, color: color, size: compact ? 19 : 22),
        ),
      ),
    );
  }
}

class _ShiftBreakdown extends StatelessWidget {
  final String nonCashLabel;
  final String nonCashValue;
  final String totalLabel;
  final String totalValue;
  final String totalSubtitle;
  final bool compact;
  final bool inverted;

  const _ShiftBreakdown({
    required this.nonCashLabel,
    required this.nonCashValue,
    required this.totalLabel,
    required this.totalValue,
    required this.totalSubtitle,
    this.compact = false,
    this.inverted = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _ShiftBreakdownTile(
            label: nonCashLabel,
            value: nonCashValue,
            compact: compact,
            inverted: inverted,
          ),
        ),
        SizedBox(width: compact ? 8 : 10),
        Expanded(
          child: _ShiftBreakdownTile(
            label: totalLabel,
            value: totalValue,
            subtitle: totalSubtitle,
            compact: compact,
            inverted: inverted,
            emphasized: true,
          ),
        ),
      ],
    );
  }
}

class _ShiftBreakdownTile extends StatelessWidget {
  final String label;
  final String value;
  final String? subtitle;
  final bool compact;
  final bool inverted;
  final bool emphasized;

  const _ShiftBreakdownTile({
    required this.label,
    required this.value,
    this.subtitle,
    required this.compact,
    required this.inverted,
    this.emphasized = false,
  });

  @override
  Widget build(BuildContext context) {
    final labelColor = inverted ? Colors.white70 : const Color(0xFF64748B);
    final subtitleColor = inverted ? Colors.white60 : const Color(0xFF94A3B8);
    final valueColor = inverted
        ? Colors.white
        : (emphasized ? _kBrand : const Color(0xFF0F172A));
    final fillColor = inverted
        ? Colors.white.withValues(alpha: emphasized ? 0.12 : 0.08)
        : (emphasized
            ? AppColors.primaryBrand.withValues(alpha: 0.08)
            : const Color(0xFFF8FAFC));
    final borderColor = inverted
        ? Colors.white.withValues(alpha: emphasized ? 0.20 : 0.12)
        : (emphasized
            ? AppColors.primaryBrand.withValues(alpha: 0.16)
            : const Color(0xFFE2E8F0));

    return Container(
      constraints: BoxConstraints(minHeight: compact ? 58 : 68),
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 10 : 12,
        vertical: compact ? 8 : 10,
      ),
      decoration: BoxDecoration(
        color: fillColor,
        border: Border.all(color: borderColor),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.plusJakartaSans(
              fontSize: compact ? 9.5 : 10.5,
              height: 1,
              color: labelColor,
              fontWeight: FontWeight.w800,
              letterSpacing: 0,
            ),
          ),
          SizedBox(height: compact ? 6 : 8),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              value,
              maxLines: 1,
              style: GoogleFonts.plusJakartaSans(
                fontSize:
                    emphasized ? (compact ? 15 : 17) : (compact ? 14 : 16),
                height: 1,
                color: valueColor,
                fontWeight: FontWeight.w900,
                letterSpacing: 0,
                fontFeatures: const [FontFeature.tabularFigures()],
              ),
            ),
          ),
          if (subtitle?.trim().isNotEmpty ?? false) ...[
            const SizedBox(height: 5),
            Text(
              subtitle!.trim(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.plusJakartaSans(
                fontSize: compact ? 8.5 : 9.5,
                height: 1,
                color: subtitleColor,
                fontWeight: FontWeight.w700,
                letterSpacing: 0,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// NAV ITEM DATA CLASS

class _NavItem {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final void Function(BuildContext)? onTap;
  final bool isSelected;
  final bool locked;
  const _NavItem(this.icon, this.activeIcon, this.label, this.onTap,
      {this.isSelected = false, this.locked = false});
}

// CUSTOM RAIL ITEM

class _RailItem extends StatefulWidget {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool isSelected;
  final VoidCallback? onTap;
  final bool locked;

  const _RailItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.isSelected,
    this.onTap,
    this.locked = false,
  });

  @override
  State<_RailItem> createState() => _RailItemState();
}

class _RailItemState extends State<_RailItem> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: double.infinity,
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: widget.isSelected
                ? Colors.white.withValues(alpha: 0.15)
                : (_isHovered
                    ? Colors.white.withValues(alpha: 0.08)
                    : Colors.transparent),
            borderRadius: BorderRadius.zero,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Icon(
                    widget.isSelected ? widget.activeIcon : widget.icon,
                    color: widget.locked
                        ? Colors.white30
                        : (widget.isSelected || _isHovered)
                            ? Colors.white
                            : Colors.white54,
                    size: 22,
                  ),
                  if (widget.locked)
                    Positioned(
                      right: -9,
                      bottom: -6,
                      child: Container(
                        width: 15,
                        height: 15,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppColors.danger,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: _kTealDeep,
                            width: 1.5,
                          ),
                        ),
                        child: const Icon(
                          Icons.lock_rounded,
                          color: Colors.white,
                          size: 8.5,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                widget.label,
                style: GoogleFonts.inter(
                  color: widget.locked
                      ? Colors.white30
                      : (widget.isSelected || _isHovered)
                          ? Colors.white
                          : Colors.white54,
                  fontSize: 10,
                  fontWeight:
                      widget.isSelected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// HERO STAT TILE

class _HeroStatTile extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback onTap;

  const _HeroStatTile({
    required this.label,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.10),
          borderRadius: BorderRadius.zero,
          border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.inter(
                        fontSize: 11,
                        color: Colors.white60,
                        fontWeight: FontWeight.w500),
                  ),
                ),
                const Icon(Icons.chevron_right_rounded,
                    color: Colors.white38, size: 14),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                  letterSpacing: -0.3),
            ),
          ],
        ),
      ),
    );
  }
}

int? _parseRpInput(String raw) {
  final digits = raw.replaceAll(RegExp(r'[^0-9]'), '');
  if (digits.isEmpty) return null;
  return int.tryParse(digits);
}

Future<void> _showShiftCashCountDialog({
  required BuildContext context,
  required WidgetRef ref,
  required int expectedCash,
  required KasirSession session,
}) async {
  final sessionId = session.id;
  if (sessionId == null) return;
  final notifier = ref.read(kasirSessionsProvider.notifier);

  final submitted = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => _ShiftCashCountDialog(
          expectedCash: expectedCash,
          onSubmit: (actualCash, notes) async {
            await notifier.recordCashCount(
              sessionId: sessionId,
              expectedCash: expectedCash,
              actualCash: actualCash,
              notes: notes,
            );
          },
        ),
      ) ??
      false;

  if (!submitted || !context.mounted) return;
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      behavior: SnackBarBehavior.floating,
      padding: EdgeInsets.zero,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 20),
      content: ClipRRect(
        borderRadius: BorderRadius.zero,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: const Color(0xE60B1220),
              border: Border.all(color: const Color(0x33FFFFFF)),
              borderRadius: BorderRadius.zero,
            ),
            child: const Text(
              'Hasil hitung Kas Shift sudah dicatat',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
      ),
    ),
  );
}

class _ShiftCashCountDialog extends StatefulWidget {
  final int expectedCash;
  final Future<void> Function(int actualCash, String notes) onSubmit;

  const _ShiftCashCountDialog({
    required this.expectedCash,
    required this.onSubmit,
  });

  @override
  State<_ShiftCashCountDialog> createState() => _ShiftCashCountDialogState();
}

class _ShiftCashCountDialogState extends State<_ShiftCashCountDialog> {
  late final TextEditingController _actualCtrl;
  late final TextEditingController _noteCtrl;
  bool _saving = false;
  String? _errorText;

  @override
  void initState() {
    super.initState();
    _actualCtrl =
        TextEditingController(text: formatCurrencyInput(widget.expectedCash));
    _noteCtrl = TextEditingController();
  }

  @override
  void dispose() {
    _actualCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final parsedActual = _parseRpInput(_actualCtrl.text);
    if (parsedActual == null || _saving) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _saving = true;
      _errorText = null;
    });
    try {
      await widget.onSubmit(parsedActual, _noteCtrl.text);
      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).pop(true);
    } catch (e, stackTrace) {
      debugPrint('Shift cash count submit error: $e\n$stackTrace');
      if (!mounted) return;
      setState(() {
        _errorText = 'Gagal mencatat selisih kas. Coba lagi.';
      });
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _cancel() {
    FocusScope.of(context).unfocus();
    Navigator.of(context, rootNavigator: true).pop(false);
  }

  @override
  Widget build(BuildContext context) {
    final actualCash = _parseRpInput(_actualCtrl.text) ?? 0;
    final difference = actualCash - widget.expectedCash;
    final isShort = difference < 0;
    final isOver = difference > 0;
    final diffColor = isShort
        ? AppColors.danger
        : isOver
            ? AppColors.success
            : const Color(0xFF64748B);
    final diffBg = isShort
        ? AppColors.dangerBg
        : isOver
            ? AppColors.iconGreenBg
            : const Color(0xFFF1F5F9);
    final diffIcon = isShort
        ? Icons.trending_down_rounded
        : isOver
            ? Icons.trending_up_rounded
            : Icons.check_circle_outline_rounded;

    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 520),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: AppColors.warningBg,
                        border: Border.all(
                          color: AppColors.warning.withValues(alpha: 0.25),
                        ),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Icon(
                        Icons.calculate_outlined,
                        color: AppColors.primaryBrand,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 14),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hitung Kas Shift',
                            style: TextStyle(
                              fontSize: 19,
                              fontWeight: FontWeight.w900,
                              color: AppColors.textTitle,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            'Catat hasil hitung uang fisik di laci. Selisih masuk Audit Kasir tanpa mengubah Buku Kas Usaha.',
                            style: TextStyle(
                              fontSize: 12.5,
                              height: 1.35,
                              color: AppColors.textCaption,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF8FAFC),
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: _ShiftCashMetric(
                          label: 'Kas Shift Sistem',
                          value: _fmtRp(widget.expectedCash),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _ShiftCashMetric(
                          label: 'Uang Fisik Aktual',
                          value: _fmtRp(actualCash),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'Uang Fisik di Laci',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textBody,
                  ),
                ),
                const SizedBox(height: 7),
                TextField(
                  controller: _actualCtrl,
                  autofocus: true,
                  keyboardType: TextInputType.number,
                  inputFormatters: const [CurrencyInputFormatter()],
                  onChanged: (_) => setState(() {}),
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textTitle,
                  ),
                  decoration: const InputDecoration(
                    prefixText: 'Rp ',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: Color(0xFFE2E8F0)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: Color(0xFFE2E8F0)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(
                        color: AppColors.primaryBrand,
                        width: 1.5,
                      ),
                    ),
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 13,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: diffBg,
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Row(
                    children: [
                      Icon(diffIcon, color: diffColor, size: 20),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          difference == 0
                              ? 'Kas fisik sesuai dengan sistem'
                              : 'Selisih: ${_fmtRp(difference)}',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w900,
                            color: diffColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                if (_errorText != null) ...[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: const BoxDecoration(
                      color: AppColors.dangerBg,
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.error_outline_rounded,
                          color: AppColors.danger,
                          size: 18,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            _errorText!,
                            style: const TextStyle(
                              color: AppColors.danger,
                              fontSize: 12.5,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                ],
                TextField(
                  controller: _noteCtrl,
                  minLines: 2,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    hintText:
                        'Catatan opsional, contoh: uang kurang setelah pergantian kasir',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: Color(0xFFE2E8F0)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide(color: Color(0xFFE2E8F0)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide:
                          BorderSide(color: AppColors.primaryBrand, width: 1.5),
                    ),
                    contentPadding: EdgeInsets.all(12),
                  ),
                ),
                const SizedBox(height: 22),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _saving ? null : _cancel,
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.textBody,
                          side: const BorderSide(color: Color(0xFFE2E8F0)),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        child: const Text('Batal'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed:
                            _parseRpInput(_actualCtrl.text) == null || _saving
                                ? null
                                : _submit,
                        icon: const Icon(Icons.fact_check_outlined, size: 18),
                        label: const FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            'Catat Selisih Kas',
                            style: TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryBrand,
                          foregroundColor: Colors.white,
                          disabledBackgroundColor: const Color(0xFFE5E7EB),
                          disabledForegroundColor: AppColors.textCaption,
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ShiftCashMetric extends StatelessWidget {
  final String label;
  final String value;

  const _ShiftCashMetric({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: AppColors.textCaption,
          ),
        ),
        const SizedBox(height: 5),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(
            value,
            maxLines: 1,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: AppColors.textTitle,
            ),
          ),
        ),
      ],
    );
  }
}

// SCANNER STATUS PILL

class _ScannerStatusPill extends StatelessWidget {
  final String label;
  final String subtitle;
  final bool isActive;
  final IconData icon;
  final Color? indicatorColor;

  final bool isLight;

  const _ScannerStatusPill({
    required this.label,
    required this.subtitle,
    required this.isActive,
    required this.icon,
    this.indicatorColor,
    this.isLight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 155),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: isLight
            ? const Color(0xFFF1F5F9)
            : Colors.white.withValues(alpha: 0.1),
        borderRadius: BorderRadius.zero,
        border: Border.all(
            color: isLight ? const Color(0xFFE2E8F0) : Colors.white12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon,
              size: 11,
              color: indicatorColor ??
                  (isActive
                      ? (isLight ? const Color(0xFF16A34A) : Colors.greenAccent)
                      : (isLight ? Colors.black26 : Colors.white38))),
          const SizedBox(width: 6),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.inter(
                      fontSize: 8,
                      fontWeight: FontWeight.w700,
                      color: isLight ? Colors.black45 : Colors.white60,
                      letterSpacing: 0.1,
                    )),
                Text(subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.inter(
                      fontSize: 9,
                      fontWeight: FontWeight.w600,
                      color: isActive
                          ? (isLight ? const Color(0xFF334155) : Colors.white)
                          : (isLight ? Colors.black26 : Colors.white38),
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// UNIFIED DASHBOARD HEADER

class _UnifiedDashHeader extends ConsumerWidget {
  final dynamic activeSession;
  const _UnifiedDashHeader({this.activeSession});

  void _showTutupKasirDialog(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => TutupKasirSheet(
        activeSession: activeSession,
        onSubmit: (kasirName, openingCash, closingCash, openedAt, notes) async {
          final notifier = ref.read(kasirSessionsProvider.notifier);
          if (activeSession != null) {
            await notifier.closeSession(
              sessionId: activeSession.id!,
              openedAt: activeSession.openedAt,
              openingCash: openingCash,
              closingCash: closingCash,
              notes: notes,
            );
          }
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Sesi berhasil ditutup'),
                backgroundColor: Colors.black87,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              ),
            );
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final showDesktopScannerControls =
        Platform.isWindows || Platform.isLinux || Platform.isMacOS;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              FutureBuilder<Map<String, dynamic>>(
                future: DBHelper.instance.getWarungProfile(),
                builder: (context, snapshot) {
                  String name = 'Juragan Servis';
                  if (snapshot.hasData) {
                    final dbName = snapshot.data!['nama']?.toString();
                    if (dbName != null && dbName.trim().isNotEmpty) {
                      name = dbName;
                    }
                  }
                  return Text(name.toUpperCase(),
                      style: GoogleFonts.plusJakartaSans(
                          color: const Color(0xFF0F172A),
                          letterSpacing: 1.0,
                          fontSize: 24,
                          fontWeight: FontWeight.w800));
                },
              ),
              const SizedBox(height: 4),
              Row(children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: activeSession != null
                        ? const Color(0xFF22C55E)
                        : const Color(0xFFEF4444),
                    boxShadow: [
                      BoxShadow(
                        color: (activeSession != null
                                ? const Color(0xFF22C55E)
                                : const Color(0xFFEF4444))
                            .withValues(alpha: 0.4),
                        blurRadius: 4,
                      )
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    activeSession != null
                        ? 'TERMINAL AKTIF • ${activeSession.kasirName.toUpperCase()}'
                        : 'TERMINAL TERKUNCI / SHIFT TUTUP',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.plusJakartaSans(
                        color: const Color(0xFF64748B),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.8),
                  ),
                ),
              ]),
            ],
          ),
        ),
        const Spacer(),
        // ACTION BUTTONS IN HEADER
        Wrap(
          spacing: 8,
          runSpacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            _buildHeaderAction(
              label: 'BUKU KAS USAHA',
              icon: Icons.account_balance_wallet_rounded,
              locked: !StaffAccess.can(
                ref.watch(activeStaffProvider),
                StaffPermissionKey.wallet,
              ),
              onTap: () {
                final activeStaff = ref.read(activeStaffProvider);
                if (StaffAccess.can(activeStaff, StaffPermissionKey.wallet)) {
                  Navigator.pushNamed(context, '/dompet');
                } else {
                  _showDashboardAccessDenied(context);
                }
              },
            ),
          ],
        ),
        const SizedBox(width: 8),

        if (showDesktopScannerControls)
          Consumer(builder: (context, ref, _) {
            final state = ref.watch(companionScannerStateProvider);
            String remoteSubtitle = 'OFF';
            bool isConnected = state.connectedDevices.isNotEmpty;
            final hasHostStatus = state.isRunning ||
                state.isStarting ||
                (state.errorMessage?.isNotEmpty ?? false);
            if (state.isStarting) {
              remoteSubtitle = 'Memulai...';
            } else if (state.isRetryScheduled) {
              remoteSubtitle = 'Retry Otomatis';
            } else if (state.errorMessage?.isNotEmpty ?? false) {
              remoteSubtitle = 'Gagal';
            } else if (state.isRunning) {
              remoteSubtitle =
                  isConnected ? state.connectedDevices.first : 'Standby';
            } else if (!state.autoStartEnabled) {
              remoteSubtitle = 'Manual';
            }

            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _ScannerStatusPill(
                  label: 'HP SCANNER',
                  isActive: hasHostStatus,
                  subtitle: remoteSubtitle,
                  icon: Icons.phonelink_ring_rounded,
                  isLight: true,
                  indicatorColor: isConnected
                      ? const Color(0xFF16A34A)
                      : state.isStarting
                          ? Colors.blueAccent
                          : (state.errorMessage?.isNotEmpty ?? false)
                              ? Colors.redAccent
                              : null,
                ),
                const SizedBox(width: 8),
                const _ScannerStatusPill(
                  label: 'USB SCANNER',
                  isActive: true,
                  subtitle: 'SIAP',
                  icon: Icons.usb_rounded,
                  isLight: true,
                ),
                const SizedBox(width: 12),
                IconButton(
                  icon: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.zero,
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                    ),
                    child: const Icon(Icons.qr_code_scanner_rounded,
                        color: Color(0xFF64748B), size: 18),
                  ),
                  onPressed: () => ScanPairingDialog.show(context),
                  tooltip: 'Gunakan HP Sebagai Scanner',
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            );
          })
        else
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFFF1F5F9),
                borderRadius: BorderRadius.zero,
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: const Icon(Icons.qr_code_scanner_rounded,
                  color: Color(0xFF64748B), size: 18),
            ),
            onPressed: () =>
                Navigator.pushNamed(context, '/continuous_scanner'),
            tooltip: 'Scan Barcode',
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
        if (activeSession != null) ...[
          const SizedBox(width: 12),
          ElevatedButton.icon(
            onPressed: () => _showTutupKasirDialog(context, ref),
            icon: const Icon(Icons.power_settings_new_rounded, size: 16),
            label: const Text('TUTUP SESI',
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFEF4444),
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildHeaderAction({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
    bool isPrimary = false,
    bool locked = false,
  }) {
    return ElevatedButton.icon(
      onPressed: onTap,
      icon: Stack(
        clipBehavior: Clip.none,
        children: [
          Icon(icon, size: 14),
          if (locked)
            Positioned(
              right: -8,
              bottom: -7,
              child: Container(
                width: 14,
                height: 14,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.danger,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 1.2),
                ),
                child: const Icon(
                  Icons.lock_rounded,
                  color: Colors.white,
                  size: 8,
                ),
              ),
            ),
        ],
      ),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        backgroundColor: isPrimary ? const Color(0xFF0F172A) : Colors.white,
        foregroundColor: isPrimary ? Colors.white : const Color(0xFF0F172A),
        elevation: isPrimary ? 4 : 0,
        shadowColor:
            isPrimary ? const Color(0xFF0F172A).withValues(alpha: 0.3) : null,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: isPrimary
              ? BorderSide.none
              : const BorderSide(color: Color(0xFFE2E8F0)),
        ),
        textStyle: GoogleFonts.plusJakartaSans(
          fontSize: 11,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

// SALES PROGRESS CARD

class _SalesProgressCard extends ConsumerStatefulWidget {
  const _SalesProgressCard();

  @override
  ConsumerState<_SalesProgressCard> createState() => _SalesProgressCardState();
}

class _SalesProgressCardState extends ConsumerState<_SalesProgressCard> {
  bool _dailyNotified = false;
  bool _monthlyNotified = false;

  String _fK(int n) {
    if (n == 0) return '0';
    final s = n.abs().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return '${n < 0 ? '-' : ''}$buf';
  }

  String _fKShort(int n) {
    if (n >= 1000000000) {
      return '${(n / 1000000000).toStringAsFixed(1)}M';
    }
    if (n >= 1000000) {
      return '${(n / 1000000).toStringAsFixed(1)}jt';
    }
    if (n >= 1000) {
      return '${(n / 1000).toStringAsFixed(1)}rb';
    }
    return n.toString();
  }

  @override
  Widget build(BuildContext context) {
    final target = ref.watch(salesTargetProvider);
    if (target.dailyTarget <= 0 && target.monthlyTarget <= 0) {
      return const SizedBox.shrink();
    }

    final progressAsync = ref.watch(salesProgressProvider);
    return progressAsync.when(
      loading: () => const SizedBox.shrink(),
      error: (_, __) => const SizedBox.shrink(),
      data: (progress) {
        if (target.dailyTarget > 0 &&
            progress.todaySales >= target.dailyTarget &&
            !_dailyNotified) {
          _dailyNotified = true;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _showTargetBanner(
                'harian', progress.todaySales, target.dailyTarget);
            LocalNotificationService.showTargetAchieved(
                type: 'harian',
                amount: progress.todaySales,
                target: target.dailyTarget);
          });
        }
        if (target.monthlyTarget > 0 &&
            progress.monthSales >= target.monthlyTarget &&
            !_monthlyNotified) {
          _monthlyNotified = true;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _showTargetBanner(
                'bulanan', progress.monthSales, target.monthlyTarget);
            LocalNotificationService.showTargetAchieved(
                type: 'bulanan',
                amount: progress.monthSales,
                target: target.monthlyTarget);
          });
        }

        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              if (target.dailyTarget > 0)
                Expanded(
                  child: _TargetCompactCard(
                    label: 'Harian',
                    current: progress.todaySales,
                    target: target.dailyTarget,
                    pct: progress.dailyProgressPct,
                    growthPct: progress.dailyGrowthPct,
                    fK: _fKShort,
                  ),
                ),
              if (target.dailyTarget > 0 && target.monthlyTarget > 0)
                const SizedBox(width: 10),
              if (target.monthlyTarget > 0)
                Expanded(
                  child: _TargetCompactCard(
                    label: 'Bulanan',
                    current: progress.monthSales,
                    target: target.monthlyTarget,
                    pct: progress.monthlyProgressPct,
                    growthPct: progress.monthlyGrowthPct,
                    fK: _fKShort,
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  void _showTargetBanner(String type, int amount, int target) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showMaterialBanner(
      MaterialBanner(
        content: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Target ${type == 'harian' ? 'Harian' : 'Bulanan'} Tercapai! 🎯',
              style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: Colors.white),
            ),
            const SizedBox(height: 2),
            Text(
              'Omzet: Rp${_fK(amount)} dari target Rp${_fK(target)}',
              style: TextStyle(
                  fontSize: 12, color: Colors.white.withValues(alpha: 0.85)),
            ),
          ],
        ),
        backgroundColor: const Color(0xFF16A34A),
        leading: const Icon(Icons.emoji_events_rounded,
            color: Colors.amber, size: 26),
        actions: [
          TextButton(
            onPressed: () =>
                ScaffoldMessenger.of(context).hideCurrentMaterialBanner(),
            child: const Text('OK',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
    Future.delayed(const Duration(seconds: 5), () {
      if (mounted) {
        ScaffoldMessenger.of(context).hideCurrentMaterialBanner();
      }
    });
  }
}

class _TargetCompactCard extends StatelessWidget {
  final String label;
  final int current;
  final int target;
  final double pct;
  final double growthPct;
  final String Function(int) fK;

  const _TargetCompactCard({
    required this.label,
    required this.current,
    required this.target,
    required this.pct,
    required this.growthPct,
    required this.fK,
  });

  Color _color(double p) {
    if (p >= 1.0) return const Color(0xFF16A34A);
    if (p >= 0.7) return AppColors.primary;
    if (p >= 0.4) return AppColors.info;
    return const Color(0xFFEF4444);
  }

  @override
  Widget build(BuildContext context) {
    final clampedPct = pct.clamp(0.0, 1.0);
    final color = _color(pct);

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text('Target $label',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF64748B))),
              ),
              Text('${(pct * 100).toInt()}%',
                  style: TextStyle(
                      fontSize: 11, fontWeight: FontWeight.w800, color: color)),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.zero,
            child: LinearProgressIndicator(
              value: clampedPct,
              minHeight: 4,
              backgroundColor: const Color(0xFFE2E8F0),
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
          const SizedBox(height: 8),
          Text('Rp${fK(current)}',
              style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1E293B))),
          const SizedBox(height: 2),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text('Tgt: ${fK(target)}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style:
                        const TextStyle(fontSize: 9, color: Color(0xFF94A3B8))),
              ),
              Row(children: [
                Icon(
                  growthPct >= 0
                      ? Icons.arrow_upward_rounded
                      : Icons.arrow_downward_rounded,
                  size: 8,
                  color: growthPct >= 0
                      ? const Color(0xFF16A34A)
                      : const Color(0xFFEF4444),
                ),
                Text('${growthPct.toInt().abs()}%',
                    style: TextStyle(
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                        color: growthPct >= 0
                            ? const Color(0xFF16A34A)
                            : const Color(0xFFEF4444))),
              ]),
            ],
          ),
        ],
      ),
    );
  }
}

// MENU GRID

class _MenuGrid extends ConsumerWidget {
  final int crossAxisCount;
  const _MenuGrid({this.crossAxisCount = 4});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final transactions = ref.watch(transactionsProvider);
    final uncompletedCount = transactions
        .where((t) =>
            (t.paymentMethod == 'Pesanan' ||
                t.paymentMethod == 'buat_pesanan') &&
            t.amountPaid < t.grandTotal)
        .length;

    final activeStaff = ref.watch(activeStaffProvider);
    final items = _buildItems(context, activeStaff, uncompletedCount);

    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        // Adjust column count or aspect ratio based on available width
        // This ensures items have enough vertical space relative to their width
        double aspectRatio = crossAxisCount >= 4 ? 1.15 : 1.0;

        // If the width per cell is very small, we might need a taller aspect ratio
        final cellWidth = width / crossAxisCount;
        if (cellWidth < 120) {
          aspectRatio = 0.85; // Taller cells for narrow widths
        }

        return GridView.builder(
          padding: EdgeInsets.zero,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            childAspectRatio: aspectRatio,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
          ),
          itemCount: items.length,
          itemBuilder: (context, i) => _MenuCell(item: items[i]),
        );
      },
    );
  }

  List<_MenuItem> _buildItems(
    BuildContext context,
    Employee? activeStaff,
    int uncompletedCount,
  ) {
    final shell = ShellScope.of(context);
    final canProducts =
        StaffAccess.can(activeStaff, StaffPermissionKey.products);
    final canCustomers =
        StaffAccess.can(activeStaff, StaffPermissionKey.customers);
    final canEmployees =
        StaffAccess.can(activeStaff, StaffPermissionKey.employees);
    final canReports = StaffAccess.can(activeStaff, StaffPermissionKey.reports);

    return [
      _MenuItem('Layanan &\nInventori', Icons.dry_cleaning_outlined, () {
        if (shell != null) {
          shell.onNavigate(2);
        } else if (canProducts) {
          Navigator.pushNamed(context, '/produk');
        } else {
          _showDashboardAccessDenied(context);
        }
      }, locked: !canProducts),
      _MenuItem('Pelanggan', Icons.people_outline, () {
        if (shell != null) {
          shell.onNavigate(6);
        } else if (canCustomers) {
          Navigator.pushNamed(context, '/pelanggan');
        } else {
          _showDashboardAccessDenied(context);
        }
      }, locked: !canCustomers),
      _MenuItem('Karyawan', Icons.badge_outlined, () {
        if (shell != null) {
          shell.onNavigate(7);
        } else if (canEmployees) {
          Navigator.pushNamed(context, '/karyawan');
        } else {
          _showDashboardAccessDenied(context);
        }
      }, locked: !canEmployees),
      _MenuItem('Laporan', Icons.insert_chart_outlined, () {
        if (shell != null) {
          shell.onNavigate(5);
        } else if (canReports) {
          Navigator.pushNamed(context, '/laporan');
        } else {
          _showDashboardAccessDenied(context);
        }
      }, locked: !canReports),
    ];
  }
}

class _MenuCell extends StatelessWidget {
  final _MenuItem item;
  const _MenuCell({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE0E0E0), width: 0.8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.zero,
        child: InkWell(
          onTap: item.onTap,
          borderRadius: BorderRadius.zero,
          child: Stack(
            fit: StackFit.expand,
            alignment: Alignment.center,
            children: [
              // Wrap the main content in FittedBox to handle overflows by scaling down
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color:
                              (item.locked ? const Color(0xFF94A3B8) : _kBrand)
                                  .withValues(alpha: 0.08),
                          shape: BoxShape.rectangle,
                        ),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Icon(
                              item.icon,
                              color: item.locked
                                  ? const Color(0xFF94A3B8)
                                  : _kBrand,
                              size: 28,
                            ),
                            if (item.locked)
                              Positioned(
                                right: -10,
                                bottom: -9,
                                child: Container(
                                  width: 18,
                                  height: 18,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    color: AppColors.danger,
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: Colors.white,
                                      width: 1.5,
                                    ),
                                  ),
                                  child: const Icon(
                                    Icons.lock_rounded,
                                    color: Colors.white,
                                    size: 10,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        item.label,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontSize: 12,
                            color: Colors.black87,
                            height: 1.25,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MenuItem {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final bool locked;
  const _MenuItem(
    this.label,
    this.icon,
    this.onTap, {
    this.locked = false,
  });
}

// NEW MODERN DASHBOARD WIDGETS (DESKTOP/TABLET)

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final String? trend;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    this.trend,
  });

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF0F172A).withValues(alpha: 0.04),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
          border: Border.all(color: const Color(0xFFF1F5F9), width: 1.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: color, size: 20),
                ),
                if (trend != null)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      trend!.toUpperCase(),
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        color: const Color(0xFF64748B),
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            Text(
              value,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: const Color(0xFF0F172A),
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF94A3B8),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SalesTrendChart extends ConsumerWidget {
  final List<Map<String, dynamic>> data;
  const _SalesTrendChart({required this.data});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentPeriod = ref.watch(salesTrendPeriodProvider);

    int maxVal = 0;
    for (var d in data) {
      if ((d['sales'] as int) > maxVal) maxVal = d['sales'] as int;
    }
    if (maxVal == 0) maxVal = 100000;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFEEEEEE)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                _getChartTitle(currentPeriod),
                style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFF1E293B)),
              ),
              const Spacer(),
              _buildFilterToggle(ref, currentPeriod),
            ],
          ),
          const SizedBox(height: 30),
          SizedBox(
            height: 224,
            child: data.isEmpty
                ? const Center(child: Text('Tidak ada data pendapatan'))
                : LayoutBuilder(
                    builder: (context, constraints) {
                      final bool showWholeMonth = currentPeriod == 'month' &&
                          constraints.maxWidth >= 520;
                      final double defaultBarWidth =
                          _getBarWidth(currentPeriod);
                      final double barSlotWidth = showWholeMonth
                          ? math.max(18, constraints.maxWidth / data.length)
                          : defaultBarWidth;
                      final double chartWidth = showWholeMonth
                          ? constraints.maxWidth
                          : math.max(
                              constraints.maxWidth,
                              data.length * defaultBarWidth,
                            );
                      final content = SizedBox(
                        width: chartWidth,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: data.map((d) {
                            final sales = d['sales'] as int;
                            final double pct = sales / maxVal;
                            final bool isActive =
                                _isCurrentBarActive(d, currentPeriod);
                            final bool compactMonthly =
                                currentPeriod == 'month' && showWholeMonth;

                            return SizedBox(
                              width: barSlotWidth,
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                  horizontal: compactMonthly ? 2 : 4,
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    _buildBarValueLabel(
                                      sales,
                                      isActive: isActive,
                                      compact: compactMonthly,
                                    ),
                                    const SizedBox(height: 6),
                                    Container(
                                      height: 160 * pct,
                                      decoration: BoxDecoration(
                                        color: isActive
                                            ? _kBrand
                                            : const Color(0xFFE2E8F0),
                                        borderRadius: BorderRadius.zero,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      d['label'] as String,
                                      maxLines: 1,
                                      overflow: TextOverflow.visible,
                                      style: GoogleFonts.inter(
                                        fontSize: compactMonthly ? 10 : 10.5,
                                        fontWeight: isActive
                                            ? FontWeight.w800
                                            : FontWeight.w500,
                                        color: isActive
                                            ? _kBrand
                                            : const Color(0xFF64748B),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      );

                      if (showWholeMonth ||
                          chartWidth <= constraints.maxWidth + 0.5) {
                        return content;
                      }

                      return SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        reverse: currentPeriod != 'month',
                        child: content,
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildBarValueLabel(
    int value, {
    required bool isActive,
    required bool compact,
  }) {
    final label = _fKShort(value);
    if (compact) {
      return SizedBox(
        height: 18,
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            label,
            maxLines: 1,
            style: GoogleFonts.inter(
              fontSize: value > 0 ? 10.5 : 9.5,
              fontWeight: value > 0 ? FontWeight.w800 : FontWeight.w600,
              color: value > 0
                  ? (isActive ? _kBrand : const Color(0xFF334155))
                  : const Color(0xFF94A3B8),
            ),
          ),
        ),
      );
    }

    if (value <= 0) {
      return Text(
        label,
        style: GoogleFonts.inter(
          fontSize: compact ? 9.5 : 10,
          fontWeight: FontWeight.w600,
          color: const Color(0xFF94A3B8),
        ),
      );
    }

    return Container(
      constraints: BoxConstraints(minWidth: compact ? 26 : 34),
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 3 : 6,
        vertical: compact ? 2 : 3,
      ),
      decoration: BoxDecoration(
        color: isActive ? const Color(0xFFEFF6FF) : const Color(0xFFF8FAFC),
        border: Border.all(
          color: isActive ? const Color(0xFFBFDBFE) : const Color(0xFFE2E8F0),
        ),
        borderRadius: BorderRadius.zero,
      ),
      child: Text(
        label,
        maxLines: 1,
        textAlign: TextAlign.center,
        overflow: TextOverflow.visible,
        style: GoogleFonts.inter(
          fontSize: compact ? 10 : 11,
          fontWeight: FontWeight.w800,
          color: isActive ? _kBrand : const Color(0xFF334155),
        ),
      ),
    );
  }

  String _getChartTitle(String period) {
    switch (period) {
      case 'today':
        return 'Tren Pendapatan Hari Ini';
      case 'last_7_days':
        return 'Pendapatan 7 Hari Terakhir';
      case 'month':
        return 'Pendapatan Bulan Ini';
      case 'year':
        return 'Pendapatan Tahunan';
      default:
        return 'Tren Pendapatan';
    }
  }

  double _getBarWidth(String period) {
    switch (period) {
      case 'today':
        return 40;
      case 'month':
        return 30;
      case 'year':
        return 50;
      default:
        return 60;
    }
  }

  bool _isCurrentBarActive(Map<String, dynamic> d, String period) {
    if (period == 'last_7_days') return d['label'] == 'Hari Ini';
    if (period == 'today') {
      return d['key'] == DateTime.now().hour.toString().padLeft(2, '0');
    }
    if (period == 'month') return d['label'] == DateTime.now().day.toString();
    return false;
  }

  Widget _buildFilterToggle(WidgetRef ref, String current) {
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: const BoxDecoration(
        color: Color(0xFFF1F5F9),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _filterBtn(ref, 'today', 'Hari', current == 'today'),
          _filterBtn(ref, 'last_7_days', '7 Hari', current == 'last_7_days'),
          _filterBtn(ref, 'month', 'Bulan', current == 'month'),
          _filterBtn(ref, 'year', 'Tahun', current == 'year'),
        ],
      ),
    );
  }

  Widget _filterBtn(WidgetRef ref, String val, String label, bool isSelected) {
    return InkWell(
      onTap: () => ref.read(salesTrendPeriodProvider.notifier).set(val),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.zero,
          boxShadow: isSelected
              ? [
                  BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
                      blurRadius: 2,
                      offset: const Offset(0, 1))
                ]
              : null,
        ),
        child: Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 10,
            fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
            color: isSelected ? _kBrand : const Color(0xFF64748B),
          ),
        ),
      ),
    );
  }

  String _fKShort(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}jt';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(0)}rb';
    return n.toString();
  }
}

// CATEGORY PERFORMANCE CARD (PHASE 3)

class _CategoryPerformanceCard extends StatelessWidget {
  final List<Map<String, dynamic>> categoryStats;
  const _CategoryPerformanceCard({required this.categoryStats});

  @override
  Widget build(BuildContext context) {
    int maxSales = 0;
    if (categoryStats.isNotEmpty) {
      maxSales = categoryStats.first['sales'] as int;
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFEEEEEE)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Analisis Performa Kategori',
            style: GoogleFonts.poppins(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: const Color(0xFF1E293B)),
          ),
          const SizedBox(height: 20),
          if (categoryStats.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 40),
              child: Center(
                  child: Text('Belum ada data pendapatan',
                      style: TextStyle(fontSize: 12, color: Colors.grey))),
            )
          else
            ...categoryStats.map((item) {
              final int sales = item['sales'] as int;
              final double pct = maxSales > 0 ? sales / maxSales : 0;

              return Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          item['name'] as String,
                          style: GoogleFonts.inter(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: const Color(0xFF334155)),
                        ),
                        Text(
                          _fmtRp(sales),
                          style: GoogleFonts.inter(
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              color: _kBrand),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Stack(
                      children: [
                        Container(
                          height: 6,
                          width: double.infinity,
                          decoration: const BoxDecoration(
                              color: Color(0xFFF1F5F9),
                              borderRadius: BorderRadius.zero),
                        ),
                        FractionallySizedBox(
                          widthFactor: pct.clamp(0.01, 1.0),
                          child: Container(
                            height: 6,
                            decoration: const BoxDecoration(
                              gradient:
                                  LinearGradient(colors: [_kBrand, _kTealDark]),
                              borderRadius: BorderRadius.zero,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _LowStockAnalysis extends StatelessWidget {
  final List<Product> items;
  const _LowStockAnalysis({required this.items});

  @override
  Widget build(BuildContext context) {
    if (Platform.isWindows) return const SizedBox.shrink();
    final materialItems = items.where((p) => p.isMaterial == 1).toList();
    final displayItems = materialItems.take(5).toList();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFEEEEEE)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.science_outlined, size: 18, color: Color(0xFF1E293B)),
              SizedBox(width: 8),
              Text('Bahan Baku Menipis',
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF1E293B))),
            ],
          ),
          const SizedBox(height: 16),
          if (materialItems.isEmpty)
            const Padding(
                padding: EdgeInsets.symmetric(vertical: 20),
                child: Center(
                    child: Text('Bahan baku aman',
                        style: TextStyle(fontSize: 12, color: Colors.grey))))
          else
            ...displayItems.map((p) {
              final bool isCritical = p.stock == 0;
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: IntrinsicHeight(
                  child: Row(
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: isCritical
                              ? const Color(0xFFEF4444)
                              : const Color(0xFFF97316),
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          p.name,
                          style: GoogleFonts.inter(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: const Color(0xFF334155)),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${p.stock}/${p.minStock} ${p.unit}',
                        style: GoogleFonts.inter(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: isCritical
                                ? const Color(0xFFEF4444)
                                : const Color(0xFFF97316)),
                      ),
                    ],
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}

// RECENT TRANSACTIONS LIST (phone/portrait tablet)

class _RecentTransactionsList extends ConsumerWidget {
  const _RecentTransactionsList();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncData = ref.watch(recentTransactionsProvider);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Order Terakhir',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87)),
            GestureDetector(
              onTap: () => Navigator.pushNamed(context, '/riwayat'),
              child: const Text('Lihat Semua',
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: _kBrand)),
            ),
          ],
        ),
        const SizedBox(height: 4),
        asyncData.when(
          loading: () => const Center(
              child: Padding(
                  padding: EdgeInsets.all(20),
                  child: CircularProgressIndicator())),
          error: (err, _) => Center(child: Text('Error: $err')),
          data: (transactions) {
            if (transactions.isEmpty) {
              return Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.zero,
                  border: Border.all(color: const Color(0xFFEEEEEE)),
                ),
                child: const Column(
                  children: [
                    Icon(Icons.receipt_long_outlined,
                        color: Colors.black26, size: 40),
                    SizedBox(height: 8),
                    Text('Belum ada transaksi.',
                        style: TextStyle(color: Colors.black45, fontSize: 13)),
                  ],
                ),
              );
            }
            return Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.zero,
                border: Border.all(color: const Color(0xFFEEEEEE)),
              ),
              child: ListView.separated(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: transactions.length,
                separatorBuilder: (_, __) => const Divider(
                    height: 1, indent: 68, color: Color(0xFFF2F2F2)),
                itemBuilder: (context, index) {
                  final t = transactions[index];
                  final info = _getPaymentInfo(t.paymentMethod);
                  final payLabel = info['label'] as String;
                  final isUnpaid = t.amountPaid < t.grandTotal;
                  String timeStr = '';
                  String dateStr = '';
                  try {
                    final dt = DateTime.parse(t.createdAt);
                    timeStr =
                        '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
                    dateStr =
                        '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}';
                  } catch (_) {
                    timeStr = t.createdAt;
                  }
                  final customer = t.customerName?.isNotEmpty == true
                      ? t.customerName!
                      : 'Pelanggan Umum';
                  final orderLabel = _dashboardOrderTypeLabel(
                    t.fulfillmentType?.isNotEmpty == true
                        ? t.fulfillmentType
                        : t.orderType,
                  );
                  final paymentLabel = isUnpaid
                      ? 'Belum Lunas'
                      : (t.paymentMethod == 'buat_pesanan' ||
                              t.paymentMethod == 'Pesanan'
                          ? 'Sudah Lunas'
                          : payLabel);
                  final metaLabel = [
                    paymentLabel,
                    if (orderLabel != null) orderLabel,
                    if (dateStr.isNotEmpty && timeStr.isNotEmpty)
                      '$dateStr $timeStr',
                  ].join(' - ');

                  return InkWell(
                    onTap: () => _showTransactionDetailSheet(context, t),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 6),
                      child: Row(
                        children: [
                          _DashPaymentThumb(
                              method: t.paymentMethod, isUnpaid: isUnpaid),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(customer,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13,
                                        color: Color(0xFF111111))),
                                const SizedBox(height: 2),
                                Text(
                                  metaLabel,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 10.5,
                                    fontWeight: isUnpaid ||
                                            t.paymentMethod == 'buat_pesanan' ||
                                            t.paymentMethod == 'Pesanan'
                                        ? FontWeight.w700
                                        : FontWeight.w500,
                                    color: isUnpaid
                                        ? AppColors.danger
                                        : (t.paymentMethod == 'buat_pesanan' ||
                                                t.paymentMethod == 'Pesanan'
                                            ? const Color(0xFF16A34A)
                                            : const Color(0xFF9CA3AF)),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(_fmtRp(t.grandTotal),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 13,
                                          color: isUnpaid
                                              ? AppColors.danger
                                              : const Color(0xFF111111))),
                                  const SizedBox(width: 2),
                                  const Icon(Icons.chevron_right_rounded,
                                      size: 14, color: Color(0xFFCCCCCC)),
                                ],
                              ),
                              const SizedBox(height: 2),
                              if (t.servisStatus.isNotEmpty)
                                _servisStatusChip(status: t.servisStatus),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ],
    );
  }
}

String _fmtRp(int v) {
  if (v == 0) return 'Rp0';
  final s = v.abs().toString();
  final buf = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
    buf.write(s[i]);
  }
  return 'Rp${v < 0 ? '-' : ''}$buf';
}

Map<String, Color> _servisStatusColor(String status) {
  final normalized = status.trim().toLowerCase();
  switch (normalized) {
    case 'proses':
      return {'bg': const Color(0xFFFFF3CD), 'fg': const Color(0xFF856404)};
    case 'siap':
    case 'siap ambil':
      return {'bg': const Color(0xFFFFF7CC), 'fg': const Color(0xFFA16207)};
    case 'selesai':
      return {'bg': const Color(0xFFE0E7FF), 'fg': const Color(0xFF3730A3)};
    case 'dibatalkan':
      return {'bg': const Color(0xFFFFE4E6), 'fg': const Color(0xFF9F1239)};
    default: // Diterima
      return {'bg': const Color(0xFFE0F2FE), 'fg': const Color(0xFF0369A1)};
  }
}

class _servisStatusChip extends StatelessWidget {
  final String status;
  const _servisStatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    final colors = _servisStatusColor(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: colors['bg'],
        borderRadius: BorderRadius.zero,
      ),
      child: Text(
        status,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w700,
          color: colors['fg'],
        ),
      ),
    );
  }
}

class _DashOrderTypeChip extends StatelessWidget {
  final String label;
  const _DashOrderTypeChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: const BoxDecoration(
        color: Color(0xFFEFF6FF),
        borderRadius: BorderRadius.zero,
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 9.5,
          fontWeight: FontWeight.w800,
          color: _kBrand,
          letterSpacing: 0,
        ),
      ),
    );
  }
}

String? _dashboardOrderTypeLabel(String? value) {
  final raw = value?.trim() ?? '';
  if (raw.isEmpty) return null;
  final lower = raw.toLowerCase();
  if (lower.contains('antar') ||
      lower.contains('jemput') ||
      lower.contains('delivery') ||
      lower.contains('pickup')) {
    return 'Antar/Jemput';
  }
  return null;
}

Map<String, dynamic> _getPaymentInfo(String method) {
  final m = method.toLowerCase();
  if (m == 'qris') {
    return {'label': 'QRIS', 'icon': Icons.qr_code_2_rounded};
  } else if (m == 'transfer') {
    return {'label': 'Transfer', 'icon': Icons.account_balance_rounded};
  } else if (m == 'pesanan' || m == 'buat_pesanan') {
    return {'label': 'Tagihan', 'icon': Icons.pending_actions_rounded};
  } else {
    return {'label': 'Tunai', 'icon': Icons.payments_rounded};
  }
}

Future<void> _showTransactionDetailSheet(
    BuildContext context, Transaction t) async {
  final isUnpaid = t.amountPaid < t.grandTotal;
  String dateTimeStr = '';
  try {
    final dt = DateTime.parse(t.createdAt);
    dateTimeStr =
        '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}  '
        '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  } catch (_) {
    dateTimeStr = t.createdAt;
  }
  final customer =
      t.customerName?.isNotEmpty == true ? t.customerName! : 'Pelanggan Umum';
  final payInfo = _getPaymentInfo(t.paymentMethod);
  final payLabel = payInfo['label'] as String;
  final orderTypeLabel = _dashboardOrderTypeLabel(t.fulfillmentType) ??
      _dashboardOrderTypeLabel(t.orderType) ??
      t.orderType;

  // load items
  final items = await DBHelper.instance.getTransactionItems(t.id ?? 0);

  if (!context.mounted) return;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    builder: (_) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.6,
      minChildSize: 0.4,
      maxChildSize: 0.92,
      builder: (ctx, scroll) => Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Column(
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.zero,
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(customer,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 17,
                                  color: Colors.black87)),
                          const SizedBox(height: 2),
                          Text(dateTimeStr,
                              style: const TextStyle(
                                  fontSize: 12, color: Colors.black45)),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: isUnpaid
                            ? AppColors.danger.withValues(alpha: 0.1)
                            : AppColors.primaryBrand.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Text(
                        isUnpaid ? 'Belum Lunas' : 'Lunas',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: isUnpaid
                              ? AppColors.danger
                              : AppColors.primaryBrand,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                const Divider(height: 1, color: Color(0xFFEEEEEE)),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              controller: scroll,
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              children: [
                // Metode & Waktu
                _DetailRow(
                    label: 'Metode Bayar',
                    value: isUnpaid
                        ? 'Belum Lunas'
                        : (t.paymentMethod == 'buat_pesanan' ||
                                t.paymentMethod == 'Pesanan'
                            ? 'Sudah Lunas'
                            : payLabel)),
                _DetailRow(label: 'Waktu', value: dateTimeStr),
                if (t.servisStatus.isNotEmpty)
                  _DetailRow(
                    label: 'Status Servis',
                    value: t.servisStatus,
                    valueColor: _servisStatusColor(t.servisStatus)['fg'],
                  ),
                if (t.pickupSchedule != null && t.pickupSchedule!.isNotEmpty)
                  _DetailRow(
                      label: 'Waktu Pengambilan', value: t.pickupSchedule!),
                if (orderTypeLabel != null && orderTypeLabel.isNotEmpty)
                  _DetailRow(label: 'Tipe Pesanan', value: orderTypeLabel),
                if (t.address != null && t.address!.isNotEmpty)
                  _DetailRow(label: 'Alamat', value: t.address!),
                const SizedBox(height: 12),
                const Text('Item Pesanan',
                    style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: Colors.black54)),
                const SizedBox(height: 6),
                if (items.isEmpty)
                  const Text('Tidak ada item.',
                      style: TextStyle(fontSize: 13, color: Colors.black45))
                else
                  ...items.map((item) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                '${item.productName} x ${_transactionItemQtyLabel(item)}',
                                style: const TextStyle(
                                    fontSize: 13, color: Colors.black87),
                              ),
                            ),
                            Text(
                              _fmtRp(item.subtotal),
                              style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black87),
                            ),
                          ],
                        ),
                      )),
                const SizedBox(height: 8),
                const Divider(height: 1, color: Color(0xFFEEEEEE)),
                const SizedBox(height: 8),
                // Total
                if (t.discountAmount > 0) ...[
                  _DetailRow(
                      label: 'Diskon', value: '- ${_fmtRp(t.discountAmount)}'),
                  const SizedBox(height: 4),
                ],
                ...t.chargesList.map((c) {
                  final catatan = c['catatan']?.toString() ?? '';
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _DetailRow(
                          label: c['label']?.toString() ?? 'Biaya Tambahan',
                          value: _fmtRp(c['value'] as int? ?? 0)),
                      if (catatan.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(left: 110, bottom: 2),
                          child: Text(catatan,
                              style: const TextStyle(
                                  fontSize: 11,
                                  color: Colors.black45,
                                  fontStyle: FontStyle.italic)),
                        ),
                      const SizedBox(height: 4),
                    ],
                  );
                }),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total',
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                    Text(_fmtRp(t.grandTotal),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: isUnpaid
                                ? AppColors.danger
                                : AppColors.primaryBrand)),
                  ],
                ),
                if (isUnpaid) ...[
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Sudah Dibayar',
                          style:
                              TextStyle(fontSize: 12, color: Colors.black45)),
                      Text(_fmtRp(t.amountPaid),
                          style: const TextStyle(
                              fontSize: 12, color: Colors.black45)),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Sisa Tagihan',
                          style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: AppColors.danger)),
                      Text(_fmtRp(t.grandTotal - t.amountPaid),
                          style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              color: AppColors.danger)),
                    ],
                  ),
                ],
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: Color(0xFFEEEEEE))),
            ),
            child: SafeArea(
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pop(_);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                StrukScreen(transactionId: t.id ?? 0),
                          ),
                        );
                      },
                      icon: const Icon(
                        Icons.print_outlined,
                        size: 18,
                        color: Colors.white,
                      ),
                      label: const Text(
                        'Cetak Struk',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                    ),
                  ),
                  if (isUnpaid) ...[
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          Navigator.pop(_);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => DetailTransaksiPiutangScreen(
                                  transactionId: t.id ?? 0),
                            ),
                          );
                        },
                        icon: const Icon(Icons.payments_rounded,
                            color: Colors.white, size: 18),
                        label: const Text('BAYAR SEKARANG',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 13)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.danger,
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

// RECENT TRANSACTIONS TABLE (tablet landscape pro mode)
// Shows as a real data table with column headers

// PAYMENT METHOD THUMBNAIL (dashboard)

// DETAIL ROW (transaction detail bottom sheet)

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  const _DetailRow({required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
                width: 110,
                child: Text(label,
                    style:
                        const TextStyle(fontSize: 12, color: Colors.black45))),
            Expanded(
              child: Text(value,
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: valueColor ?? Colors.black87)),
            ),
          ],
        ),
      );
}

class _DashPaymentThumb extends StatelessWidget {
  final String method;
  final bool isUnpaid;
  const _DashPaymentThumb({required this.method, this.isUnpaid = false});

  @override
  Widget build(BuildContext context) {
    final m = method.toLowerCase();
    final Color successBg = _kBrand.withValues(alpha: 0.12);
    const Color successIcon = _kBrand;
    final Color dangerBg = AppColors.danger.withValues(alpha: 0.10);
    const Color dangerIcon = AppColors.danger;

    if (isUnpaid) {
      return Container(
        width: 40,
        height: 40,
        decoration:
            BoxDecoration(color: dangerBg, borderRadius: BorderRadius.zero),
        child: const Icon(Icons.schedule_rounded, color: dangerIcon, size: 20),
      );
    }

    Color bg = successBg;
    Color iconColor = successIcon;
    IconData icon = Icons.payments_rounded;

    if (m == 'qris') {
      return Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.zero),
        padding: const EdgeInsets.all(10),
        child: CustomPaint(painter: _DashQrisPatternPainter(color: iconColor)),
      );
    }
    if (m == 'transfer') {
      icon = Icons.account_balance_rounded;
    } else if (m == 'pesanan' || m == 'buat_pesanan') {
      icon = Icons.receipt_long_rounded;
    }

    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.zero),
      child: Icon(icon, color: iconColor, size: 20),
    );
  }
}

class _DashQrisPatternPainter extends CustomPainter {
  final Color color;
  _DashQrisPatternPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..isAntiAlias = true;
    final s = size.width / 5;
    for (final (dx, dy) in [(0.0, 0.0), (3 * s, 0.0), (0.0, 3 * s)]) {
      p.style = PaintingStyle.stroke;
      p.strokeWidth = s * 0.5;
      canvas.drawRect(
          Rect.fromLTWH(dx + s * 0.25, dy + s * 0.25, s * 1.5, s * 1.5), p);
      p.style = PaintingStyle.fill;
      canvas.drawRect(
          Rect.fromLTWH(dx + s * 0.75, dy + s * 0.75, s * 0.5, s * 0.5), p);
    }
    p.style = PaintingStyle.fill;
    for (final (dx, dy) in [
      (3 * s, 3 * s),
      (4 * s, 3 * s),
      (3 * s, 4 * s),
      (4.5 * s, 4 * s),
      (2 * s, 2 * s),
      (2.5 * s, 0.0),
      (4 * s, 2 * s),
    ]) {
      canvas.drawRect(Rect.fromLTWH(dx, dy, s * 0.7, s * 0.7), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// MAIN KASIR CARD

class _MainKasirCard extends StatefulWidget {
  const _MainKasirCard();

  @override
  State<_MainKasirCard> createState() => _MainKasirCardState();
}

class _MainKasirCardState extends State<_MainKasirCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 100));
    _scaleAnimation =
        Tween<double>(begin: 1.0, end: 0.96).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOut,
    ));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onTapDown(TapDownDetails _) => _controller.forward();
  void _onTapUp(TapUpDetails _) {
    _controller.reverse();
    final shell = ShellScope.of(context);
    if (shell != null) {
      shell.onNavigate(1);
    } else {
      Navigator.pushNamed(context, '/transaksi');
    }
  }

  void _onTapCancel() => _controller.reverse();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: _onTapDown,
      onTapUp: _onTapUp,
      onTapCancel: _onTapCancel,
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: Container(
          height: 90,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_kBrand, _kTealDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.zero,
            // Multi-layered 3D shadow
            boxShadow: [
              // Dark deep shadow (farthest)
              BoxShadow(
                color: _kBrand.withValues(alpha: 0.25),
                blurRadius: 15,
                offset: const Offset(0, 8),
                spreadRadius: -2,
              ),
              // Directional bottom-right shadow (depth)
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.2),
                blurRadius: 4,
                offset: const Offset(2, 4),
              ),
              // Top-left highlight (simulates light)
              BoxShadow(
                color: Colors.white.withValues(alpha: 0.15),
                blurRadius: 0,
                offset: const Offset(-2, -2),
              ),
            ],
            // Subtle "glass" light edge
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.15),
              width: 1,
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                right: -5,
                top: -5,
                child: Icon(Icons.point_of_sale_rounded,
                    size: 95, color: Colors.white.withValues(alpha: 0.1)),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.25),
                        shape: BoxShape.rectangle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.1),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          )
                        ],
                      ),
                      child: const Icon(Icons.handyman_rounded,
                          color: Colors.white, size: 28),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('POS servis',
                              style: GoogleFonts.inter(
                                  color: Colors.white70,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.5)),
                          const SizedBox(height: 2),
                          Text('Buat Pesanan Baru',
                              style: GoogleFonts.poppins(
                                  color: Colors.white,
                                  fontSize: 18,
                                  height: 1.15,
                                  fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right_rounded,
                        color: Colors.white, size: 24),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// RECENT TRANSACTIONS SIDEBAR (tablet landscape)
// Compact version for the gradient sidebar

class _RecentTransactionsSidebar extends ConsumerWidget {
  const _RecentTransactionsSidebar();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncData = ref.watch(recentTransactionsProvider);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Order Terakhir',
                  style: GoogleFonts.inter(
                      color: Colors.white.withValues(alpha: 0.9),
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.3)),
              GestureDetector(
                onTap: () => Navigator.pushNamed(context, '/riwayat'),
                child: Text('Lihat Semua',
                    style: GoogleFonts.inter(
                        color: Colors.white54,
                        fontSize: 11,
                        fontWeight: FontWeight.w600)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          asyncData.when(
            loading: () => const Center(
                child: Padding(
              padding: EdgeInsets.all(20),
              child: CircularProgressIndicator(
                  color: Colors.white24, strokeWidth: 2),
            )),
            error: (err, _) => Padding(
              padding: const EdgeInsets.all(20),
              child: Text('Error: $err',
                  style: const TextStyle(color: Colors.white38, fontSize: 11)),
            ),
            data: (transactions) {
              if (transactions.isEmpty) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 30),
                  child: Center(
                    child: Column(
                      children: [
                        Icon(Icons.history_rounded,
                            color: Colors.white.withValues(alpha: 0.15),
                            size: 32),
                        const SizedBox(height: 10),
                        Text('Belum ada transaksi',
                            style: GoogleFonts.inter(
                                color: Colors.white.withValues(alpha: 0.3),
                                fontSize: 12)),
                      ],
                    ),
                  ),
                );
              }

              return Column(
                children: transactions.take(5).map((t) {
                  final isUnpaid = t.amountPaid < t.grandTotal;
                  final customer = t.customerName?.isNotEmpty == true
                      ? t.customerName!
                      : 'Pelanggan Umum';
                  final orderLabel = _dashboardOrderTypeLabel(
                    t.fulfillmentType?.isNotEmpty == true
                        ? t.fulfillmentType
                        : t.orderType,
                  );

                  String timeStr = '';
                  try {
                    final dt = DateTime.parse(t.createdAt);
                    timeStr =
                        '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
                  } catch (_) {
                    timeStr = '--:--';
                  }

                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.06),
                      borderRadius: BorderRadius.zero,
                      border: Border.all(
                          color: Colors.white.withValues(alpha: 0.1)),
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () => _showTransactionDetailSheet(context, t),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(customer,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: GoogleFonts.inter(
                                            color: Colors.white,
                                            fontSize: 13,
                                            fontWeight: FontWeight.w600)),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        Text(timeStr,
                                            style: GoogleFonts.inter(
                                                color: Colors.white54,
                                                fontSize: 11)),
                                        if (orderLabel != null) ...[
                                          const SizedBox(width: 8),
                                          _DashOrderTypeChip(label: orderLabel),
                                        ],
                                        const SizedBox(width: 8),
                                        Container(
                                          width: 4,
                                          height: 4,
                                          decoration: const BoxDecoration(
                                              color: Colors.white24,
                                              shape: BoxShape.rectangle),
                                        ),
                                        const SizedBox(width: 8),
                                        Expanded(
                                          child: Text(
                                            isUnpaid
                                                ? 'BELUM LUNAS'
                                                : (t.paymentMethod ==
                                                            'buat_pesanan' ||
                                                        t.paymentMethod ==
                                                            'Pesanan'
                                                    ? 'SUDAH LUNAS'
                                                    : _getPaymentInfo(t
                                                                .paymentMethod)[
                                                            'label']
                                                        .toString()
                                                        .toUpperCase()),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: GoogleFonts.inter(
                                                color: isUnpaid
                                                    ? Colors.redAccent
                                                    : (t.paymentMethod ==
                                                                'buat_pesanan' ||
                                                            t.paymentMethod ==
                                                                'Pesanan'
                                                        ? Colors.greenAccent
                                                        : Colors.white54),
                                                fontSize: 9,
                                                fontWeight: FontWeight.w800,
                                                letterSpacing: 0.5),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 12),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(_fmtRp(t.grandTotal),
                                      style: GoogleFonts.poppins(
                                          color: Colors.white,
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold)),
                                  const Icon(Icons.chevron_right_rounded,
                                      size: 14, color: Colors.white30),
                                  if (t.servisStatus.isNotEmpty)
                                    const SizedBox(height: 2),
                                  if (t.servisStatus.isNotEmpty)
                                    _servisStatusChip(status: t.servisStatus),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              );
            },
          ),
          const SizedBox(height: 40), // Spacer at bottom
        ],
      ),
    );
  }
}

class _TrialCountdownBanner extends ConsumerWidget {
  const _TrialCountdownBanner();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final licenseAsync = ref.watch(currentLicenseProvider);

    return licenseAsync.when(
      data: (license) {
        if (license == null || license.isTrial != 1) return const SizedBox();
        if (license.expiredAt == null) return const SizedBox();

        final expiry = DateTime.tryParse(license.expiredAt!);
        if (expiry == null) return const SizedBox();

        final now = DateTime.now();
        final diff = expiry.difference(now);

        if (diff.isNegative) return const SizedBox();

        final days = diff.inDays;
        final hours = diff.inHours % 24;
        final minutes = diff.inMinutes % 60;

        String timeStr = '';
        if (days > 0) {
          timeStr = '$days Hari ${hours > 0 ? '$hours Jam' : ''}';
        } else if (hours > 0) {
          timeStr = '$hours Jam $minutes Menit';
        } else {
          timeStr = '$minutes Menit';
        }

        return Container(
          width: double.infinity,
          margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                AppColors.primaryBrand.withValues(alpha: 0.08),
                AppColors.primaryBrand.withValues(alpha: 0.15)
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(
                color: AppColors.primaryBrand.withValues(alpha: 0.3), width: 1),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFD6A5).withValues(alpha: 0.3),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.timer_outlined,
                    color: AppColors.primaryBrand, size: 18),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'MASA TRIAL AKTIF',
                      style: GoogleFonts.inter(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                        color: AppColors.primaryBrand,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Aplikasi akan terkunci dalam $timeStr',
                      style: GoogleFonts.inter(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textTitle,
                      ),
                    ),
                  ],
                ),
              ),
              TextButton(
                onPressed: () => SupportContactService.launchSupportWhatsapp(
                  message:
                      'Halo Support Juragan Servis, masa trial saya akan segera berakhir. Bagaimana cara upgrade lisensi saya?',
                ),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  backgroundColor: AppColors.primaryBrand,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(0, 32),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
                child: Text(
                  'UPGRADE',
                  style: GoogleFonts.inter(
                      fontSize: 11, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        );
      },
      loading: () => const SizedBox(),
      error: (_, __) => const SizedBox(),
    );
  }
}

class _servisQuickStats extends StatelessWidget {
  final int activeservis;
  final int readyForPickup;
  final int unpaidCount;

  const _servisQuickStats({
    required this.activeservis,
    required this.readyForPickup,
    required this.unpaidCount,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFAFBFC),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        borderRadius: BorderRadius.zero,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.025),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: const BoxDecoration(
                  color: Color(0xFFEFF6FF),
                  borderRadius: BorderRadius.zero,
                ),
                child: const Icon(Icons.handyman_rounded,
                    color: Color(0xFF2563EB), size: 18),
              ),
              const SizedBox(width: 12),
              Text(
                'OPERASIONAL servis',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.0,
                  color: const Color(0xFF475569),
                ),
              ),
              const Spacer(),
              TextButton(
                onPressed: () {
                  final shell = ShellScope.of(context);
                  if (shell != null) {
                    shell.onNavigate(10);
                  } else {
                    Navigator.pushNamed(context, '/servis_status');
                  }
                },
                style: TextButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  minimumSize: Size.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: const Text(
                  'Detail Status',
                  style: TextStyle(
                    color: Color(0xFF2563EB),
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _servisStatItem(
                  label: 'Order Aktif',
                  value: '$activeservis',
                  icon: Icons.handyman_rounded,
                  color: const Color(0xFF2563EB),
                  backgroundColor: const Color(0xFFF8FAFC),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _servisStatItem(
                  label: 'Siap Ambil',
                  value: '$readyForPickup',
                  icon: Icons.check_circle_outline_rounded,
                  color: const Color(0xFF2563EB),
                  backgroundColor: const Color(0xFFF8FAFC),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _servisStatItem(
                  label: 'Belum Lunas',
                  value: '$unpaidCount',
                  icon: Icons.pending_actions_rounded,
                  color: const Color(0xFFDC2626),
                  backgroundColor: const Color(0xFFFEF2F2),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _servisStatItem extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final Color backgroundColor;

  const _servisStatItem({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    required this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
      decoration: BoxDecoration(
        color: backgroundColor,
        border: Border.all(color: color.withValues(alpha: 0.12)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 16),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  label.toUpperCase(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 8,
                    fontWeight: FontWeight.w800,
                    color: color,
                    letterSpacing: 0.3,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: GoogleFonts.poppins(
              fontSize: 28,
              fontWeight: FontWeight.w900,
              color: color,
              height: 1,
            ),
          ),
        ],
      ),
    );
  }
}

