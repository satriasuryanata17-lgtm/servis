import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/db_models.dart';
import '../database/db_helper.dart';
import '../providers/providers.dart';
import 'detail_transaksi_piutang_screen.dart';
import '../widgets/show_error_dialog.dart';
import '../core/theme.dart';
import '../providers/shortcut_provider.dart';
import '../utils/currency_input_formatter.dart';

//
// HELPERS
//
const Color _kBrand = AppColors.primaryBrand;
const Color _kTealDark = AppColors.primaryDark;
const Color _kGreen = Color(0xFF2E7D32);
const Color _kBg = Color(0xFFF5F7FA);

String _fK(int n) {
  if (n == 0) return '0';
  String s = n.toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return r;
}

//
// SCREEN
//
class TambahPiutangScreen extends ConsumerStatefulWidget {
  final int grandTotal;
  final int diskonAmount;
  final int biayaTambahan;
  final List<Map<String, dynamic>>? additionalChargesList;
  final DateTime? transactionDate;
  final String? note;

  const TambahPiutangScreen({
    super.key,
    required this.grandTotal,
    this.diskonAmount = 0,
    this.biayaTambahan = 0,
    this.additionalChargesList,
    this.transactionDate,
    this.note,
  });

  @override
  ConsumerState<TambahPiutangScreen> createState() =>
      _TambahPiutangScreenState();
}

class _TambahPiutangScreenState extends ConsumerState<TambahPiutangScreen> {
  final _namaCtrl = TextEditingController();
  final _pembayaranCtrl = TextEditingController(text: '');
  Customer? _selectedCustomer;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      final customer = ref.read(selectedCustomerProvider);
      if (customer != null && mounted) {
        setState(() {
          _selectedCustomer = customer;
          _namaCtrl.text = customer.name;
        });
      }
    });
  }

  @override
  void dispose() {
    _namaCtrl.dispose();
    _pembayaranCtrl.dispose();
    super.dispose();
  }

  int get _pembayaranAwal => parseCurrencyInput(_pembayaranCtrl.text);

  Future<void> _onCari() async {
    final nama = _namaCtrl.text.trim();
    if (nama.isEmpty) return;

    final customers = await DBHelper.instance.getAllCustomers();
    final found = customers
        .where((c) => c.name.toLowerCase().contains(nama.toLowerCase()))
        .toList();

    if (!mounted) return;

    if (found.length == 1) {
      setState(() => _selectedCustomer = found.first);
    } else if (found.isEmpty) {
      _showTambahPelangganSheet(namaAwal: nama);
    } else {
      _showPilihPelangganSheet(found);
    }
  }

  void _showTambahPelangganSheet({String namaAwal = ''}) {
    final namaNewCtrl = TextEditingController(text: namaAwal);
    final teleponCtrl = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => Padding(
        padding:
            EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero),
          ),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.zero,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Center(
                  child: SizedBox(height: 100, child: _IlustrasiPelanggan())),
              const SizedBox(height: 16),
              const Text('Tambah Pelanggan',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22)),
              const SizedBox(height: 16),
              const Row(
                children: [
                  Text('Nama Pelanggan',
                      style:
                          TextStyle(fontWeight: FontWeight.w500, fontSize: 14)),
                  Text(' *',
                      style: TextStyle(color: AppColors.danger, fontSize: 14)),
                ],
              ),
              const SizedBox(height: 6),
              TextField(
                controller: namaNewCtrl,
                textCapitalization: TextCapitalization.words,
                decoration: _fieldDecor(null),
              ),
              const SizedBox(height: 14),
              const Text('Nomor Telepon',
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 14)),
              const SizedBox(height: 6),
              TextField(
                controller: teleponCtrl,
                keyboardType: TextInputType.phone,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: _fieldDecor('Contoh: 8989482384 (Opsional)',
                    prefixText: '+62 '),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: _kBrand),
                        foregroundColor: _kBrand,
                        minimumSize: const Size.fromHeight(50),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: const Text('Batal',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () async {
                        final nama = namaNewCtrl.text.trim();
                        if (nama.isEmpty) return;
                        final phone = teleponCtrl.text.trim();
                        final customer = Customer(
                          name: nama,
                          phone: phone.isEmpty ? null : '+62$phone',
                          createdAt: DateTime.now().toIso8601String(),
                        );
                        final newId =
                            await DBHelper.instance.insertCustomer(customer);
                        final saved = Customer(
                          id: newId,
                          name: nama,
                          phone: phone.isEmpty ? null : '+62$phone',
                          createdAt: DateTime.now().toIso8601String(),
                        );
                        if (mounted) {
                          Navigator.pop(context);
                          setState(() {
                            _selectedCustomer = saved;
                            _namaCtrl.text = saved.name;
                          });
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        elevation: 0,
                        minimumSize: const Size.fromHeight(50),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: const Text('Simpan',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 15)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ).then((_) {
      Future.delayed(const Duration(milliseconds: 300), () {
        namaNewCtrl.dispose();
        teleponCtrl.dispose();
      });
    });
  }

  void _showPilihPelangganSheet(List<Customer> daftar) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        minChildSize: 0.4,
        expand: false,
        builder: (_, sc) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero),
          ),
          child: Column(
            children: [
              const SizedBox(height: 8),
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.zero,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text('Pilih Pelanggan',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              ),
              const SizedBox(height: 8),
              const Divider(height: 1),
              Expanded(
                child: ListView.builder(
                  controller: sc,
                  itemCount: daftar.length,
                  itemBuilder: (_, i) {
                    final c = daftar[i];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: _kBrand.withValues(alpha: 0.12),
                        child: Text(
                          c.name.isNotEmpty ? c.name[0].toUpperCase() : '?',
                          style: const TextStyle(
                              color: _kBrand, fontWeight: FontWeight.bold),
                        ),
                      ),
                      title: Text(c.name,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: c.phone != null
                          ? Text(c.phone!,
                              style: const TextStyle(
                                  fontSize: 12, color: Colors.black54))
                          : null,
                      onTap: () {
                        setState(() {
                          _selectedCustomer = c;
                          _namaCtrl.text = c.name;
                        });
                        Navigator.pop(context);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showKonfirmasiDialog(int totalPiutang) {
    if (_selectedCustomer == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Pilih pelanggan terlebih dahulu!'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
      return;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Consumer(
        builder: (ctx, ref, child) {
          // Listen for Enter key while dialog is open
          ref.listen(shortcutSignalProvider, (prev, next) {
            if (next == ShortcutAction.checkout) {
              ref.read(shortcutSignalProvider.notifier).clear();
              Navigator.pop(ctx);
              _prosesSimpan();
            }
          });

          return Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.zero),
            ),
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(height: 110, child: _IlustrasiKonfirmasi()),
                const SizedBox(height: 16),
                Text(
                  'Piutang Rp${_fK(totalPiutang)}',
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 20),
                ),
                const SizedBox(height: 8),
                Text(
                  'Konfirmasi piutang dengan total Rp${_fK(totalPiutang)} kepada '
                  'pelanggan atas nama ${_selectedCustomer!.name}.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.black54, fontSize: 14),
                ),
                const SizedBox(height: 28),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: _kBrand),
                          foregroundColor: _kBrand,
                          minimumSize: const Size.fromHeight(50),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                        ),
                        child: const Text('Batal',
                            style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(ctx);
                          _prosesSimpan();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _kBrand,
                          elevation: 0,
                          minimumSize: const Size.fromHeight(50),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                        ),
                        child: const Text('OK',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 15)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> _prosesSimpan() async {
    setState(() => _isLoading = true);
    try {
      final cart = ref.read(cartProvider);
      final txId =
          await ref.read(transactionsProvider.notifier).createTransaction(
                cartItems: cart,
                customer: _selectedCustomer,
                discountAmount: widget.diskonAmount,
                additionalCharges: widget.biayaTambahan,
                additionalChargesList: widget.additionalChargesList,
                paymentMethod: 'Piutang',
                amountPaid: _pembayaranAwal,
                transactionDate: widget.transactionDate,
                note: widget.note,
              );
      ref.read(cartProvider.notifier).clearCart();
      if (mounted) {
        setState(() => _isLoading = false);
        HapticFeedback.heavyImpact();
        ref.read(riwayatTabProvider.notifier).set(1); // Belum Lunas
        ref.read(shellIndexProvider.notifier).set(4); // Riwayat
        Navigator.of(context).popUntil((r) => r.isFirst);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => DetailTransaksiPiutangScreen(transactionId: txId),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        final errorStr = e.toString().replaceAll('Exception: ', '');
        final isStockError = errorStr.toLowerCase().contains('stok') ||
            errorStr.toLowerCase().contains('tidak cukup');

        showKasirErrorDialog(
          context,
          title: isStockError ? 'Stok Tidak Cukup' : 'Gagal Memproses',
          message: errorStr,
        );
      }
    }
  }

  void _showPilihDariDaftarSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _PilihPelangganLengkap(
        onSelected: (c) => setState(() {
          _selectedCustomer = c;
          _namaCtrl.text = c.name;
        }),
        onTambahBaru: () {
          Navigator.pop(context);
          _showTambahPelangganSheet();
        },
      ),
    );
  }

  //
  // MAIN BUILD
  //
  @override
  Widget build(BuildContext context) {
    ref.listen(shortcutSignalProvider, (previous, next) {
      if (next == ShortcutAction.checkout) {
        if (!(ModalRoute.of(context)?.isCurrent ?? false)) return;
        ref.read(shortcutSignalProvider.notifier).clear();

        final totalPiutang =
            (widget.grandTotal - _pembayaranAwal).clamp(0, widget.grandTotal);
        _showKonfirmasiDialog(totalPiutang);
      }
    });

    final mq = MediaQuery.of(context);
    final isTablet = mq.size.shortestSide >= 600;
    final isLandscape = mq.orientation == Orientation.landscape;

    final cart = ref.watch(cartProvider);
    final totalBelanja = widget.grandTotal;
    final totalPiutang =
        (totalBelanja - _pembayaranAwal).clamp(0, totalBelanja);
    final hasCustomer = _selectedCustomer != null;
    final isTyping = _namaCtrl.text.isNotEmpty && !hasCustomer;

    if (isTablet || isLandscape) {
      return _buildWideLayout(
        context,
        cart: cart,
        totalBelanja: totalBelanja,
        totalPiutang: totalPiutang,
        hasCustomer: hasCustomer,
        isTyping: isTyping,
        isTablet: isTablet,
      );
    }
    return _buildPortraitLayout(
      context,
      cart: cart,
      totalBelanja: totalBelanja,
      totalPiutang: totalPiutang,
      hasCustomer: hasCustomer,
      isTyping: isTyping,
    );
  }

  //
  // LAYOUT: PORTRAIT (original)
  //
  Widget _buildPortraitLayout(
    BuildContext context, {
    required Map<dynamic, dynamic> cart,
    required int totalBelanja,
    required int totalPiutang,
    required bool hasCustomer,
    required bool isTyping,
  }) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: const Padding(
            padding: EdgeInsets.only(left: 12),
            child: Icon(Icons.arrow_back_ios_rounded, color: _kBrand, size: 20),
          ),
        ),
        title: const Text('Tambah Piutang',
            style: TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.bold,
                fontSize: 20)),
        centerTitle: false,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: const Color(0xFFEEEEEE)),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: SizedBox(height: 180, child: _IlustrasiHandshake()),
            ),
            const SizedBox(height: 12),
            _buildCustomerSection(hasCustomer: hasCustomer, isTyping: isTyping),
            const SizedBox(height: 16),
            _buildPembayaranField(),
            const SizedBox(height: 20),
            const Divider(height: 1, color: Color(0xFFEEEEEE)),
            const SizedBox(height: 16),
            _buildCartAndSummary(cart, totalBelanja, totalPiutang),
            const SizedBox(height: 32),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNav(totalPiutang),
    );
  }

  //
  // LAYOUT: LANDSCAPE / TABLET
  // Left: Gradient sidebar -- summary + customer chip + save
  // Right: Customer form + cart items
  //
  Widget _buildWideLayout(
    BuildContext context, {
    required Map<dynamic, dynamic> cart,
    required int totalBelanja,
    required int totalPiutang,
    required bool hasCustomer,
    required bool isTyping,
    required bool isTablet,
  }) {
    final sideWidth = isTablet ? 300.0 : 260.0;

    return Scaffold(
      backgroundColor: _kBg,
      body: Row(
        children: [
          SizedBox(
            width: sideWidth,
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [_kBrand, _kTealDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.only(
                  topRight: Radius.zero,
                  bottomRight: Radius.zero,
                ),
              ),
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Back + title
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.15),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: const Icon(Icons.arrow_back_ios_rounded,
                                  color: Colors.white, size: 18),
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Text(
                            'Tambah Piutang',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),

                      // Piutang icon
                      Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.zero,
                        ),
                        child: const Icon(Icons.handshake_rounded,
                            color: Colors.white, size: 30),
                      ),
                      const SizedBox(height: 20),

                      // Section label
                      Text(
                        'RINGKASAN PEMBAYARAN',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.6),
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Summary rows
                      _SideSummaryRow(
                          label: 'Total Belanja',
                          value: 'Rp${_fK(totalBelanja)}',
                          bold: false),
                      const SizedBox(height: 8),
                      _SideSummaryRow(
                          label: 'Dibayar Awal',
                          value: '- Rp${_fK(_pembayaranAwal)}',
                          bold: false),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.zero,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Total Piutang',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            Text(
                              'Rp${_fK(totalPiutang)}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Customer chip
                      if (hasCustomer) ...[
                        Text(
                          'PELANGGAN',
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.6),
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.5,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 18,
                                backgroundColor:
                                    Colors.white.withValues(alpha: 0.25),
                                child: Text(
                                  _selectedCustomer!.name.isNotEmpty
                                      ? _selectedCustomer!.name[0].toUpperCase()
                                      : '?',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _selectedCustomer!.name,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    if (_selectedCustomer!.phone != null)
                                      Text(
                                        _selectedCustomer!.phone!,
                                        style: TextStyle(
                                          color: Colors.white
                                              .withValues(alpha: 0.7),
                                          fontSize: 11,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],

                      const Spacer(),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Pelanggan',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16)),
                        const SizedBox(height: 12),
                        _buildCustomerSection(
                            hasCustomer: hasCustomer, isTyping: isTyping),
                        const SizedBox(height: 20),
                        const Text('Pembayaran Awal',
                            style: TextStyle(
                                fontWeight: FontWeight.w500, fontSize: 15)),
                        const SizedBox(height: 8),
                        _buildPembayaranField(),
                        const SizedBox(height: 24),
                        const Divider(height: 1, color: Color(0xFFEEEEEE)),
                        const SizedBox(height: 16),
                        const Text('Rincian Piutang',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16)),
                        const SizedBox(height: 12),
                        _buildCartItems(cart),
                      ],
                    ),
                  ),
                ),
                // New long horizontal button at the bottom center of main area
                Container(
                  padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    border: Border(top: BorderSide(color: Color(0xFFEEEEEE))),
                  ),
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 600),
                      child: SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton.icon(
                          onPressed: _isLoading
                              ? null
                              : () => _showKonfirmasiDialog(totalPiutang),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _kBrand,
                            elevation: 0,
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                          ),
                          icon: _isLoading
                              ? const SizedBox.shrink()
                              : const Icon(Icons.check_circle_outline_rounded,
                                  color: Colors.white),
                          label: _isLoading
                              ? const SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(
                                      color: Colors.white, strokeWidth: 2.5))
                              : const Text(
                                  'Simpan Piutang',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16),
                                ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomerSection(
      {required bool hasCustomer, required bool isTyping}) {
    if (hasCustomer) {
      return _CustomerSelectedRow(
        customer: _selectedCustomer!,
        onClear: () => setState(() {
          _selectedCustomer = null;
          _namaCtrl.clear();
        }),
        onUbah: () {
          setState(() {
            _selectedCustomer = null;
            _namaCtrl.text = _selectedCustomer?.name ?? '';
          });
        },
      );
    }
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: _namaCtrl,
            textCapitalization: TextCapitalization.words,
            onChanged: (_) => setState(() {}),
            onSubmitted: (_) => _onCari(),
            decoration: _fieldDecor('Contoh: Budi'),
          ),
        ),
        const SizedBox(width: 8),
        if (!isTyping)
          OutlinedButton(
            onPressed: _showPilihDariDaftarSheet,
            style: _outlinedStyle(64),
            child: const Text('Pilih',
                style: TextStyle(fontWeight: FontWeight.bold)),
          )
        else ...[
          OutlinedButton(
            onPressed: _onCari,
            style: _outlinedStyle(56),
            child: const Text('Cari',
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          const SizedBox(width: 8),
          ElevatedButton(
            onPressed: () =>
                _showTambahPelangganSheet(namaAwal: _namaCtrl.text.trim()),
            style: _elevatedStyle(70),
            child: const Text('Simpan',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ],
    );
  }

  Widget _buildPembayaranField() {
    return TextField(
      controller: _pembayaranCtrl,
      keyboardType: TextInputType.number,
      inputFormatters: const [CurrencyInputFormatter()],
      onChanged: (_) => setState(() {}),
      onSubmitted: (_) {
        final totalBelanja = widget.grandTotal;
        final totalPiutang =
            (totalBelanja - _pembayaranAwal).clamp(0, totalBelanja);
        _showKonfirmasiDialog(totalPiutang);
      },
      decoration: _fieldDecor('0', prefixText: 'Rp'),
    );
  }

  Widget _buildCartAndSummary(Map cart, int totalBelanja, int totalPiutang) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Rincian Piutang',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        const SizedBox(height: 12),
        _buildCartItems(cart),
        const SizedBox(height: 8),
        const Divider(height: 1, color: Color(0xFFEEEEEE)),
        const SizedBox(height: 12),
        _SummaryRow(
            label: 'Total Pesanan',
            value: 'Rp${_fK(totalBelanja)}',
            bold: true),
        const SizedBox(height: 8),
        _SummaryRow(
            label: 'Dibayar',
            value: '- Rp${_fK(_pembayaranAwal)}',
            bold: false,
            muted: true),
        const SizedBox(height: 8),
        _SummaryRow(
            label: 'Total Piutang',
            value: 'Rp${_fK(totalPiutang)}',
            bold: true,
            green: true),
      ],
    );
  }

  Widget _buildCartItems(Map cart) {
    return Column(
      children: cart.entries.map((e) {
        final product = e.key;
        final qty = e.value;
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (product.isExtra == 1)
                Container(
                  margin: const EdgeInsets.only(right: 6, top: 2),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: _kBrand.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.zero,
                    border: Border.all(color: _kBrand.withValues(alpha: 0.2)),
                  ),
                  child: const Text('ADD ON',
                      style: TextStyle(
                          color: _kBrand,
                          fontSize: 9,
                          fontWeight: FontWeight.bold)),
                ),
              Expanded(child: Text(product.name)),
              Text('Rp${_fK(product.sellPrice)} x $qty',
                  style: const TextStyle(color: Colors.black54, fontSize: 13)),
              const SizedBox(width: 12),
              Text('Rp${_fK(product.sellPrice * qty)}',
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 14)),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildBottomNav(int totalPiutang) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFEEEEEE))),
      ),
      child: SafeArea(
        child: SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton(
            onPressed:
                _isLoading ? null : () => _showKonfirmasiDialog(totalPiutang),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              disabledBackgroundColor: _kBrand.withValues(alpha: 0.5),
              elevation: 0,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            child: _isLoading
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2.5))
                : const Text('Simpan',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16)),
          ),
        ),
      ),
    );
  }

  ButtonStyle _outlinedStyle(double minWidth) => OutlinedButton.styleFrom(
        side: const BorderSide(color: _kBrand),
        foregroundColor: _kBrand,
        minimumSize: Size(minWidth, 50),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      );

  ButtonStyle _elevatedStyle(double minWidth) => ElevatedButton.styleFrom(
        backgroundColor: _kBrand,
        elevation: 0,
        minimumSize: Size(minWidth, 50),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      );
}

//
// SIDEBAR SUMMARY ROW
//
class _SideSummaryRow extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;

  const _SideSummaryRow(
      {required this.label, required this.value, required this.bold});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(
                color: Colors.white.withValues(alpha: 0.75),
                fontSize: 12,
                fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
        Text(value,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w600)),
      ],
    );
  }
}

//
// SUMMARY ROW (portrait)
//
class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;
  final bool muted;
  final bool green;

  const _SummaryRow({
    required this.label,
    required this.value,
    this.bold = false,
    this.muted = false,
    this.green = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(
              fontWeight: bold ? FontWeight.bold : FontWeight.w500,
              fontSize: bold ? 15 : 14,
              color: muted ? Colors.black54 : Colors.black87,
            )),
        Text(value,
            style: TextStyle(
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
              fontSize: bold ? 16 : 14,
              color: green
                  ? _kGreen
                  : muted
                      ? Colors.black54
                      : Colors.black87,
            )),
      ],
    );
  }
}

//
// CUSTOMER SELECTED ROW
//
class _CustomerSelectedRow extends StatelessWidget {
  final Customer customer;
  final VoidCallback onClear;
  final VoidCallback onUbah;

  const _CustomerSelectedRow({
    required this.customer,
    required this.onClear,
    required this.onUbah,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.zero,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(customer.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 14)),
                      if (customer.phone != null)
                        Text(customer.phone!,
                            style: const TextStyle(
                                fontSize: 12, color: Colors.black54)),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: onClear,
                  child:
                      const Icon(Icons.close_rounded, color: _kBrand, size: 20),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 8),
        OutlinedButton(
          onPressed: onUbah,
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: _kBrand),
            foregroundColor: _kBrand,
            minimumSize: const Size(64, 50),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
          child:
              const Text('Ubah', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
      ],
    );
  }
}

//
// SHEET: Pilih Pelanggan Lengkap
//
class _PilihPelangganLengkap extends ConsumerStatefulWidget {
  final ValueChanged<Customer> onSelected;
  final VoidCallback onTambahBaru;

  const _PilihPelangganLengkap({
    required this.onSelected,
    required this.onTambahBaru,
  });

  @override
  ConsumerState<_PilihPelangganLengkap> createState() =>
      _PilihPelangganLengkapState();
}

class _PilihPelangganLengkapState
    extends ConsumerState<_PilihPelangganLengkap> {
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    ref.read(customersProvider.notifier).loadCustomers();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final all = ref.watch(customersProvider);
    final q = _searchCtrl.text.toLowerCase();
    final filtered = all
        .where((c) =>
            c.name.toLowerCase().contains(q) || (c.phone?.contains(q) ?? false))
        .toList();

    return DraggableScrollableSheet(
      initialChildSize: 0.75,
      maxChildSize: 0.95,
      minChildSize: 0.4,
      expand: false,
      builder: (_, sc) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        child: Column(
          children: [
            const SizedBox(height: 8),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.zero),
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  const Expanded(
                    child: Text('Pilih Pelanggan',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 18)),
                  ),
                  ElevatedButton.icon(
                    onPressed: widget.onTambahBaru,
                    icon: const Icon(Icons.add, size: 16),
                    label:
                        const Text('Pelanggan', style: TextStyle(fontSize: 13)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: _searchCtrl,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  hintText: 'Cari Nama/Nomor Telepon',
                  prefixIcon: Icon(Icons.search_rounded, color: Colors.grey),
                  filled: true,
                  fillColor: Color(0xFFF5F5F5),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: EdgeInsets.symmetric(vertical: 0),
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Divider(height: 1),
            Expanded(
              child: filtered.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.person_search_rounded,
                              size: 64, color: Colors.grey.shade300),
                          const SizedBox(height: 12),
                          const Text('Pelanggan tidak ditemukan',
                              style: TextStyle(
                                  color: Colors.black54,
                                  fontWeight: FontWeight.w500)),
                        ],
                      ),
                    )
                  : ListView.builder(
                      controller: sc,
                      itemCount: filtered.length,
                      itemBuilder: (_, i) {
                        final c = filtered[i];
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundColor: _kBrand.withValues(alpha: 0.12),
                            child: Text(
                              c.name.isNotEmpty ? c.name[0].toUpperCase() : '?',
                              style: const TextStyle(
                                  color: _kBrand, fontWeight: FontWeight.bold),
                            ),
                          ),
                          title: Text(c.name,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: c.phone != null
                              ? Text(c.phone!,
                                  style: const TextStyle(
                                      fontSize: 12, color: Colors.black54))
                              : null,
                          onTap: () {
                            widget.onSelected(c);
                            Navigator.pop(context);
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

//
// ILUSTRASI
//
class _IlustrasiHandshake extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 160,
          height: 160,
          decoration: BoxDecoration(
              color: Colors.grey.shade100, shape: BoxShape.rectangle),
        ),
        Icon(Icons.handshake_rounded, size: 80, color: Colors.grey.shade400),
        Positioned(
          top: 30,
          right: 30,
          child: Container(
            width: 28,
            height: 28,
            decoration:
                const BoxDecoration(color: _kBrand, shape: BoxShape.rectangle),
            child: const Icon(Icons.check, color: Colors.white, size: 16),
          ),
        ),
      ],
    );
  }
}

class _IlustrasiKonfirmasi extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 90,
          height: 100,
          decoration: BoxDecoration(
              color: Colors.grey.shade100, borderRadius: BorderRadius.zero),
          child: Icon(Icons.smartphone_rounded,
              size: 60, color: Colors.grey.shade400),
        ),
        Positioned(
          bottom: 10,
          right: 10,
          child: Container(
            width: 26,
            height: 26,
            decoration:
                const BoxDecoration(color: _kBrand, shape: BoxShape.rectangle),
            child: const Icon(Icons.check, color: Colors.white, size: 14),
          ),
        ),
      ],
    );
  }
}

class _IlustrasiPelanggan extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 90,
          height: 90,
          decoration: BoxDecoration(
              color: Colors.grey.shade100, shape: BoxShape.rectangle),
        ),
        Icon(Icons.person_add_rounded, size: 50, color: Colors.grey.shade400),
      ],
    );
  }
}

//
// INPUT DECORATION HELPER
//
InputDecoration _fieldDecor(String? hint, {String? prefixText}) =>
    InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14),
      prefixText: prefixText,
      prefixStyle: const TextStyle(color: Colors.black87, fontSize: 14),
      border: OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: Colors.grey.shade300)),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: Colors.grey.shade300)),
      focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: _kBrand, width: 1.5)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    );

