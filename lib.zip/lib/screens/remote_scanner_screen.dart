import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/theme.dart';
import '../services/remote_scanner_auth.dart';
import '../widgets/remote_scanner_instructions_dialog.dart';

class RemoteScannerScreen extends StatefulWidget {
  const RemoteScannerScreen({super.key});

  @override
  State<RemoteScannerScreen> createState() => _RemoteScannerScreenState();
}

class _RemoteScannerScreenState extends State<RemoteScannerScreen> {
  static const _ipPrefKey = 'remote_scanner_ip';
  static const _portPrefKey = 'remote_scanner_port';
  static const _tokenPrefKey = 'remote_scanner_token';

  String? _targetIp;
  int? _targetPort;
  String? _targetToken;
  bool _isPairingMode = true;
  bool _isProcessing = false;
  MobileScannerController? _controller;

  @override
  void initState() {
    super.initState();
    _controller = MobileScannerController(
      detectionSpeed: DetectionSpeed.noDuplicates,
      formats: const [
        BarcodeFormat.ean13,
        BarcodeFormat.ean8,
        BarcodeFormat.upcA,
        BarcodeFormat.upcE,
        BarcodeFormat.code39,
        BarcodeFormat.code93,
        BarcodeFormat.code128,
        BarcodeFormat.qrCode,
      ],
    );
    _loadSavedConnection();
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  Future<void> _loadSavedConnection() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final ip = prefs.getString(_ipPrefKey);
      final port = prefs.getInt(_portPrefKey);
      final token = prefs.getString(_tokenPrefKey);

      if (ip == null || port == null || token == null || token.isEmpty) {
        return;
      }

      setState(() => _isProcessing = true);
      final isAlive = await _pingPc(ip, port);

      if (!mounted) {
        return;
      }

      if (!isAlive) {
        setState(() => _isProcessing = false);
        _showError('Gagal terhubung otomatis: PC tidak ditemukan.');
        return;
      }

      final connected = await _connectToServer(ip, port, token);
      if (!mounted) {
        return;
      }

      if (!connected) {
        await _clearSavedConnection();
        setState(() => _isProcessing = false);
        _showError('Pairing scanner sudah tidak valid. Scan ulang QR pairing.');
        return;
      }

      setState(() {
        _targetIp = ip;
        _targetPort = port;
        _targetToken = token;
        _isPairingMode = false;
        _isProcessing = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() => _isProcessing = false);
      }
    }
  }

  Future<bool> _connectToServer(String ip, int port, String token) async {
    try {
      final request = await HttpClient().post(ip, port, '/connect');
      request.headers.contentType = ContentType.json;
      final name = Platform.isAndroid ? 'Android Phone' : 'Remote Scanner';
      request.write(
        jsonEncode(
          RemoteScannerAuth.signPayload(
            secret: token,
            method: 'POST',
            path: '/connect',
            payload: {'deviceName': name},
          ),
        ),
      );

      final response =
          await request.close().timeout(const Duration(seconds: 2));
      return response.statusCode == HttpStatus.ok;
    } catch (e) {
      debugPrint('Error connecting to server: $e');
      return false;
    }
  }

  Future<bool> _pingPc(String ip, int port) async {
    try {
      final request = await HttpClient()
          .get(ip, port, '/ping')
          .timeout(const Duration(seconds: 2));
      final response = await request.close();
      return response.statusCode == HttpStatus.ok;
    } catch (_) {
      return false;
    }
  }

  Future<void> _saveConnection(String ip, int port, String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_ipPrefKey, ip);
    await prefs.setInt(_portPrefKey, port);
    await prefs.setString(_tokenPrefKey, token);
  }

  Future<void> _clearSavedConnection() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_ipPrefKey);
    await prefs.remove(_portPrefKey);
    await prefs.remove(_tokenPrefKey);
  }

  String _cleanBarcode(String raw) {
    return raw.replaceAll(RegExp(r'\(\d{2,4}\)'), '').trim();
  }

  void _onDetect(BarcodeCapture capture) {
    if (_isProcessing || capture.barcodes.isEmpty) {
      return;
    }

    final raw =
        capture.barcodes.first.rawValue ?? capture.barcodes.first.displayValue;
    if (raw == null || raw.trim().isEmpty) {
      return;
    }

    if (_isPairingMode) {
      _handlePairingScan(raw.trim());
    } else {
      final cleaned = _cleanBarcode(raw.trim());
      _handleProductScan(cleaned, original: raw.trim());
    }
  }

  Future<void> _handlePairingScan(String data) async {
    try {
      final json = jsonDecode(data);
      if (json is! Map || json['action'] != 'connect_scanner') {
        _showError('Format QR Code tidak valid untuk pairing.');
        return;
      }

      final ip = json['ip']?.toString();
      final port = json['port'] is int
          ? json['port'] as int
          : int.tryParse(json['port']?.toString() ?? '');
      final token = json['token']?.toString().trim() ?? '';

      if (ip == null || ip.isEmpty || port == null || token.isEmpty) {
        _showError('QR pairing tidak lengkap. Scan ulang dari desktop.');
        return;
      }

      setState(() => _isProcessing = true);
      final connected = await _connectToServer(ip, port, token);

      if (!mounted) {
        return;
      }

      if (!connected) {
        setState(() => _isProcessing = false);
        _showError('Pairing ditolak desktop. Scan ulang QR pairing terbaru.');
        return;
      }

      await _saveConnection(ip, port, token);
      if (!mounted) {
        return;
      }

      setState(() {
        _targetIp = ip;
        _targetPort = port;
        _targetToken = token;
        _isPairingMode = false;
        _isProcessing = false;
      });

      HapticFeedback.mediumImpact();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terhubung ke $_targetIp'),
          backgroundColor: AppColors.primaryBrand,
          duration: const Duration(seconds: 1),
        ),
      );
    } catch (_) {
      _showError('Bukan QR Code pairing kasir desktop.');
    }
  }

  Future<void> _handleProductScan(String barcode, {String? original}) async {
    if (_targetIp == null || _targetPort == null || _targetToken == null) {
      return;
    }

    setState(() => _isProcessing = true);
    HapticFeedback.lightImpact();

    try {
      final request =
          await HttpClient().post(_targetIp!, _targetPort!, '/scan');
      request.headers.contentType = ContentType.json;
      request.write(
        jsonEncode({
          ...RemoteScannerAuth.signPayload(
            secret: _targetToken!,
            method: 'POST',
            path: '/scan',
            payload: {
              'barcode': barcode,
              'original': original ?? barcode,
            },
          ),
        }),
      );

      final response =
          await request.close().timeout(const Duration(seconds: 2));

      if (response.statusCode == HttpStatus.ok) {
        FlutterRingtonePlayer().playNotification();
        if (mounted) {
          ScaffoldMessenger.of(context).clearSnackBars();
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Berhasil dikirim: $barcode'),
              backgroundColor: Colors.green.shade700,
              duration: const Duration(milliseconds: 800),
            ),
          );
        }
      } else if (response.statusCode == HttpStatus.unauthorized) {
        await _clearSavedConnection();
        if (mounted) {
          setState(() {
            _isPairingMode = true;
            _targetIp = null;
            _targetPort = null;
            _targetToken = null;
          });
        }
        _showError('Pairing scanner sudah tidak valid. Scan ulang QR pairing.');
      } else {
        _showError('Desktop menolak barcode. Status: ${response.statusCode}');
      }
    } catch (_) {
      _showError(
          'Koneksi terputus: pastikan PC menyala & satu WiFi (atau gunakan USB Tethering).');
    } finally {
      if (mounted) {
        setState(() => _isProcessing = false);
      }
    }
  }

  void _showError(String msg) {
    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 2),
      ),
    );
    HapticFeedback.vibrate();
  }

  Future<void> _showHelp() async {
    try {
      await _controller?.stop();
    } catch (e) {
      debugPrint('Error stopping scanner for help dialog: $e');
    }

    if (!mounted) {
      return;
    }

    await RemoteScannerInstructionsDialog.show(context);

    if (!mounted) {
      return;
    }

    try {
      await _controller?.start();
    } catch (e) {
      debugPrint('Error restarting scanner after help dialog: $e');
    }
  }

  Future<void> _disconnect() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Text('Putuskan Koneksi?'),
        content: const Text(
          'HP tidak akan bisa lagi mengirim scan ke desktop ini.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Ya, Putuskan'),
          ),
        ],
      ),
    );

    if (confirmed != true) {
      return;
    }

    setState(() => _isProcessing = true);

    if (_targetIp != null && _targetPort != null && _targetToken != null) {
      try {
        final request =
            await HttpClient().post(_targetIp!, _targetPort!, '/disconnect');
        request.headers.contentType = ContentType.json;
        final name = Platform.isAndroid ? 'Android Phone' : 'Remote Scanner';
        request.write(
          jsonEncode(
            RemoteScannerAuth.signPayload(
              secret: _targetToken!,
              method: 'POST',
              path: '/disconnect',
              payload: {'deviceName': name},
            ),
          ),
        );
        await request.close().timeout(const Duration(seconds: 1));
      } catch (_) {
        // Ignore disconnect network errors.
      }
    }

    await _clearSavedConnection();
    if (!mounted) {
      return;
    }

    setState(() {
      _isPairingMode = true;
      _targetIp = null;
      _targetPort = null;
      _targetToken = null;
      _isProcessing = false;
    });

    try {
      await _controller?.stop();
      await Future.delayed(const Duration(milliseconds: 200));
      await _controller?.start();
    } catch (e) {
      debugPrint('Error restarting scanner: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(_isPairingMode ? 'Hubungkan ke PC' : 'Scanner Remote'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        actions: [
          if (!_isPairingMode)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
              child: TextButton.icon(
                style: TextButton.styleFrom(
                  backgroundColor: Colors.red.withValues(alpha: 0.2),
                  foregroundColor: Colors.redAccent,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero,
                  ),
                ),
                icon: const Icon(Icons.phonelink_off_rounded, size: 18),
                label: const Text(
                  'PUTUSKAN',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                ),
                onPressed: _disconnect,
              ),
            ),
          IconButton(
            tooltip: 'Bantuan',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: _showHelp,
          ),
          IconButton(
            icon: const Icon(Icons.flash_on),
            onPressed: () => _controller?.toggleTorch(),
          ),
          IconButton(
            icon: const Icon(Icons.cameraswitch),
            onPressed: () => _controller?.switchCamera(),
          ),
        ],
      ),
      body: Stack(
        children: [
          MobileScanner(
            controller: _controller!,
            onDetect: _onDetect,
          ),
          Container(color: Colors.black.withValues(alpha: 0.4)),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 240,
                  height: 240,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: _isPairingMode
                          ? Colors.white
                          : AppColors.primaryBrand,
                      width: 3,
                    ),
                  ),
                  child: !_isPairingMode
                      ? Center(
                          child: Container(
                            height: 2,
                            width: double.infinity,
                            color:
                                AppColors.primaryBrand.withValues(alpha: 0.5),
                          ),
                        )
                      : null,
                ),
                const SizedBox(height: 24),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.7),
                  ),
                  child: Text(
                    _isPairingMode
                        ? 'Arahkan kotak ini ke QR Code di layar desktop'
                        : 'Arahkan pemindai ke barcode produk',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                if (_isProcessing)
                  const Padding(
                    padding: EdgeInsets.only(top: 16),
                    child: CircularProgressIndicator(color: Colors.white),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

