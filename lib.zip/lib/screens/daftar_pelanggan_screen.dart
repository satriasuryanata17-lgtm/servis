import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../widgets/admin_pin_dialog.dart';
import '../widgets/kasir_dialog.dart';
import 'responsive_layout.dart';
import '../core/theme.dart';

const Color _kBrand = AppColors.primaryBrand;
const Color _kBrandLight = AppColors.brandLight;
const Color _kBg = Color(0xFFF6F7F9);

class DaftarPelangganScreen extends ConsumerStatefulWidget {
  const DaftarPelangganScreen({super.key});

  @override
  ConsumerState<DaftarPelangganScreen> createState() =>
      _DaftarPelangganScreenState();
}

class _DaftarPelangganScreenState extends ConsumerState<DaftarPelangganScreen> {
  final _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  List<Customer> _filter(List<Customer> customers) {
    if (_query.isEmpty) return customers;
    final q = _query.toLowerCase();
    return customers.where((c) {
      return c.name.toLowerCase().contains(q) ||
          (c.phone?.toLowerCase().contains(q) ?? false) ||
          (c.address?.toLowerCase().contains(q) ?? false);
    }).toList();
  }

  Future<void> _showForm({Customer? existing}) async {
    final formKey = GlobalKey<FormState>();
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final phoneCtrl = TextEditingController(text: existing?.phone ?? '');
    final addressCtrl = TextEditingController(text: existing?.address ?? '');
    final discountCtrl = TextEditingController(
      text: existing != null && existing.discountPct > 0
          ? existing.discountPct.toStringAsFixed(0)
          : '',
    );

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 8,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
        ),
        child: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.zero,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(9),
                    decoration: const BoxDecoration(
                      color: _kBrandLight,
                      borderRadius: BorderRadius.zero,
                    ),
                    child: const Icon(Icons.person_outline_rounded,
                        color: _kBrand, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    existing == null ? 'Tambah Pelanggan' : 'Ubah Pelanggan',
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: nameCtrl,
                textInputAction: TextInputAction.next,
                decoration:
                    _inputDeco('Nama Pelanggan', Icons.person_outline_rounded),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Nama wajib diisi' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: phoneCtrl,
                keyboardType: TextInputType.phone,
                textInputAction: TextInputAction.next,
                decoration: _inputDeco(
                    'Nomor Telepon (opsional)', Icons.phone_outlined),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: addressCtrl,
                maxLines: 2,
                decoration:
                    _inputDeco('Alamat (opsional)', Icons.location_on_outlined),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: discountCtrl,
                keyboardType: TextInputType.number,
                decoration: _inputDeco(
                    'Diskon Member % (opsional)', Icons.discount_outlined),
                validator: (v) {
                  if (v != null && v.isNotEmpty) {
                    final n = double.tryParse(v);
                    if (n == null || n < 0 || n > 100) return 'Harus 0-100';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () async {
                    if (!formKey.currentState!.validate()) return;
                    final data = Customer(
                      id: existing?.id,
                      name: nameCtrl.text.trim(),
                      phone: phoneCtrl.text.trim().isEmpty
                          ? null
                          : phoneCtrl.text.trim(),
                      address: addressCtrl.text.trim().isEmpty
                          ? null
                          : addressCtrl.text.trim(),
                      discountPct:
                          double.tryParse(discountCtrl.text.trim()) ?? 0,
                      memberCode: existing?.memberCode,
                      createdAt: existing?.createdAt ??
                          DateTime.now().toIso8601String(),
                    );
                    if (existing == null) {
                      await ref
                          .read(customersProvider.notifier)
                          .addCustomer(data);
                    } else {
                      await ref
                          .read(customersProvider.notifier)
                          .updateCustomer(data);
                    }
                    if (!ctx.mounted) return;
                    Navigator.pop(ctx);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kBrand,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                  child: const Text('Simpan',
                      style:
                          TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showActionSheet(Customer customer) async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.zero,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          AppColors.primaryBrand,
                          AppColors.primaryBrand.withValues(alpha: 0.6)
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Center(
                      child: Text(
                        customer.name.substring(0, 1).toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          customer.name,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          customer.phone?.trim().isNotEmpty == true
                              ? customer.phone!
                              : 'Tanpa nomor telepon',
                          style: TextStyle(
                              color: Colors.grey.shade500, fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Divider(height: 1, color: Color(0xFFF0F0F0)),
            const SizedBox(height: 8),
            _ActionTile(
              icon: Icons.edit_outlined,
              iconColor: const Color(0xFF1976D2),
              iconBg: const Color(0xFFE3F2FD),
              label: 'Ubah Data Pelanggan',
              subtitle: 'Edit nama, telepon, atau alamat',
              onTap: () {
                Navigator.pop(ctx);
                _showForm(existing: customer);
              },
            ),
            _ActionTile(
              icon: AppIcons.recycleBin,
              iconColor: _kBrand,
              iconBg: _kBrandLight,
              label: 'Hapus Pelanggan',
              subtitle: 'Hapus data dari daftar pelanggan',
              isDestructive: true,
              onTap: () {
                Navigator.pop(ctx);
                _confirmDelete(customer);
              },
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: SizedBox(
                width: double.infinity,
                height: 46,
                child: TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  style: TextButton.styleFrom(
                    backgroundColor: const Color(0xFFF5F5F5),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                  child: const Text(
                    'Batal',
                    style: TextStyle(
                        color: Colors.black54, fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(Customer customer) async {
    final ok = await showKasirConfirmDialog(
      context,
      title: 'Hapus Pelanggan',
      message:
          'Hapus "${customer.name}" dari daftar pelanggan? Transaksi lama tetap tersimpan.',
      confirmLabel: 'Ya, Hapus',
      icon: AppIcons.recycleBin,
    );

    if (ok == true && customer.id != null) {
      if (!mounted) return;
      final pinOk = await AdminPinDialog.show(
        context,
        verifyPin: (pin) {
          final profilNotifier = ref.read(profilProvider.notifier);
          if (!profilNotifier.hasConfiguredAdminPin) {
            return 'PIN admin belum diatur. Buka Pengaturan Profil.';
          }
          final valid = profilNotifier.verifyPin(pin);
          return valid ? '' : 'PIN salah';
        },
        title: 'Verifikasi Hapus Pelanggan',
        subtitle:
            'Masukkan PIN Admin/Owner. Transaksi lama tidak akan dihapus.',
      );
      if (!pinOk || !mounted) return;

      try {
        await ref
            .read(customersProvider.notifier)
            .deleteCustomer(customer.id!, pinVerified: true);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Pelanggan berhasil dihapus'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gagal menghapus pelanggan. Silakan coba lagi.'),
            backgroundColor: Colors.redAccent,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final isTablet = mq.size.shortestSide >= 600;
    final isLandscape = mq.orientation == Orientation.landscape;

    final allCustomers = ref.watch(customersProvider);
    final list = _filter(allCustomers);

    return KasirResponsiveScaffold(
      title: 'Daftar Pelanggan',
      showNavRail: false,
      backgroundColor: _kBg,
      body: isTablet || isLandscape
          ? _buildWideBody(context, allCustomers, list, isTablet, isLandscape)
          : _buildPortraitBody(context, allCustomers, list),
      bottomNavigationBar: (isTablet || isLandscape) ? null : _buildAddButton(),
    );
  }

  Widget _buildPortraitBody(
      BuildContext context, List<Customer> allCustomers, List<Customer> list) {
    return Column(
      children: [
        _buildSearchBar(),
        const SizedBox(height: 4),
        Expanded(child: _buildList(list, isGrid: false)),
      ],
    );
  }

  Widget _buildWideBody(BuildContext context, List<Customer> allCustomers,
      List<Customer> list, bool isTablet, bool isLandscape) {
    return Column(
      children: [
        // Top bar with title + stats
        _buildTabletTopBar(context, allCustomers),

        // Content area: landscape = side panel + list, tablet portrait = just list
        Expanded(
          child: isLandscape
              ? _buildLandscapeContent(context, allCustomers, list)
              : _buildTabletPortraitContent(context, allCustomers, list),
        ),
      ],
    );
  }

  Widget _buildTabletTopBar(BuildContext context, List<Customer> allCustomers) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: const BoxDecoration(
              color: _kBrandLight,
              borderRadius: BorderRadius.zero,
            ),
            child: const Icon(Icons.people_rounded, color: _kBrand, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Daftar Pelanggan',
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87)),
                Text('${allCustomers.length} pelanggan terdaftar',
                    style:
                        const TextStyle(fontSize: 12, color: Colors.black45)),
              ],
            ),
          ),
          SizedBox(
            height: 40,
            child: ElevatedButton.icon(
              onPressed: _showForm,
              icon: const Icon(Icons.person_add_rounded, size: 16),
              label: const Text('Tambah',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Landscape: left stats panel + right list
  Widget _buildLandscapeContent(
      BuildContext context, List<Customer> allCustomers, List<Customer> list) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Left: Stats + Search panel
        Container(
          width: 260,
          color: Colors.white,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Divider(height: 1, color: Color(0xFFEEEEEE)),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildStatsCard(allCustomers),
                    const SizedBox(height: 16),
                    _buildSearchBar(padding: EdgeInsets.zero),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(width: 1, color: const Color(0xFFEEEEEE)),
        // Right: Customer list (2-column)
        Expanded(
          child: _buildList(list, isGrid: true, crossAxisCount: 2),
        ),
      ],
    );
  }

  // Tablet portrait: search bar on top + 2-col grid
  Widget _buildTabletPortraitContent(
      BuildContext context, List<Customer> allCustomers, List<Customer> list) {
    return Column(
      children: [
        const Divider(height: 1, color: Color(0xFFEEEEEE)),
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
          child: _buildSearchBar(padding: EdgeInsets.zero),
        ),
        Expanded(child: _buildList(list, isGrid: true, crossAxisCount: 2)),
      ],
    );
  }

  Widget _buildStatsCard(List<Customer> customers) {
    final withDiscount = customers.where((c) => c.discountPct > 0).length;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Ringkasan',
            style: GoogleFonts.inter(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: Colors.black45,
                letterSpacing: 0.5)),
        const SizedBox(height: 10),
        _StatRow(
          icon: Icons.people_rounded,
          label: 'Total Pelanggan',
          value: '${customers.length}',
          color: _kBrand,
        ),
        const SizedBox(height: 8),
        _StatRow(
          icon: Icons.discount_rounded,
          label: 'Punya Diskon',
          value: '$withDiscount',
          color: const Color(0xFFE65100),
        ),
      ],
    );
  }

  Widget _buildSearchBar({EdgeInsetsGeometry? padding}) {
    return Padding(
      padding: padding ?? const EdgeInsets.fromLTRB(16, 0, 16, 14),
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: _kBg,
          borderRadius: BorderRadius.zero,
          border: Border.all(color: const Color(0xFFEAEAEA)),
        ),
        child: TextField(
          controller: _searchCtrl,
          onChanged: (v) => setState(() => _query = v),
          style: const TextStyle(fontSize: 14, color: Colors.black87),
          decoration: const InputDecoration(
            hintText: 'Cari nama, telepon, atau alamat...',
            hintStyle: TextStyle(fontSize: 13, color: Colors.black38),
            prefixIcon: Icon(Icons.search, color: Colors.black38, size: 20),
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(vertical: 12),
            isDense: true,
          ),
        ),
      ),
    );
  }

  Widget _buildList(List<Customer> list,
      {bool isGrid = false, int crossAxisCount = 2}) {
    if (list.isEmpty) {
      return _EmptyPelangganView(isSearching: _query.isNotEmpty);
    }

    if (isGrid) {
      return GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 2.4,
        ),
        itemCount: list.length,
        itemBuilder: (_, i) {
          final c = list[i];
          return _CustomerCardCompact(
            customer: c,
            onTap: () => _showActionSheet(c),
          );
        },
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
      itemCount: list.length,
      itemBuilder: (_, i) {
        final c = list[i];
        return _CustomerCard(customer: c, onTap: () => _showActionSheet(c));
      },
    );
  }

  Widget _buildAddButton() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton.icon(
            onPressed: _showForm,
            icon: const Icon(Icons.person_add_rounded, size: 20),
            label: const Text('Tambah Pelanggan',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              elevation: 0,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
          ),
        ),
      ),
    );
  }
}

class _CustomerCardCompact extends StatelessWidget {
  final Customer customer;
  final VoidCallback onTap;
  const _CustomerCardCompact({required this.customer, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFEEEEEE)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 8,
              offset: const Offset(0, 2)),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.zero,
        child: InkWell(
          borderRadius: BorderRadius.zero,
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        AppColors.primaryBrand,
                        AppColors.primaryBrand.withValues(alpha: 0.6)
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Center(
                    child: Text(
                      customer.name.substring(0, 1).toUpperCase(),
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        customer.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            color: Colors.black87),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        customer.phone?.trim().isNotEmpty == true
                            ? customer.phone!
                            : 'Tanpa nomor',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 12, color: Colors.black45),
                      ),
                    ],
                  ),
                ),
                if (customer.discountPct > 0)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: const BoxDecoration(
                      color: Color(0xFFFFF3E0),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Text(
                      '${customer.discountPct.toStringAsFixed(0)}%',
                      style: const TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFFE65100)),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _StatRow(
      {required this.icon,
      required this.label,
      required this.value,
      required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.10),
            borderRadius: BorderRadius.zero,
          ),
          child: Icon(icon, color: color, size: 16),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(label,
              style: const TextStyle(fontSize: 12, color: Colors.black54)),
        ),
        Text(value,
            style: TextStyle(
                fontSize: 13, fontWeight: FontWeight.bold, color: color)),
      ],
    );
  }
}

class _CustomerCard extends StatelessWidget {
  final Customer customer;
  final VoidCallback onTap;

  const _CustomerCard({required this.customer, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final hasPhone = customer.phone?.trim().isNotEmpty == true;
    final hasAddress = customer.address?.trim().isNotEmpty == true;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.zero,
        child: InkWell(
          borderRadius: BorderRadius.zero,
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                // Avatar gradient
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        AppColors.primaryBrand,
                        AppColors.primaryBrand.withValues(alpha: 0.6)
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Center(
                    child: Text(
                      customer.name.substring(0, 1).toUpperCase(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                // Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        customer.name,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Icon(
                            Icons.phone_outlined,
                            size: 13,
                            color: hasPhone ? Colors.black45 : Colors.black26,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            hasPhone ? customer.phone! : 'Tanpa nomor telepon',
                            style: TextStyle(
                              fontSize: 13,
                              color: hasPhone ? Colors.black54 : Colors.black38,
                            ),
                          ),
                        ],
                      ),
                      if (hasAddress) ...[
                        const SizedBox(height: 2),
                        Row(
                          children: [
                            const Icon(Icons.location_on_outlined,
                                size: 13, color: Colors.black38),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                customer.address!,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 12, color: Colors.black38),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                // Discount badge
                if (customer.discountPct > 0) ...[
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: const BoxDecoration(
                      color: Color(0xFFFFF3E0),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Text(
                      '${customer.discountPct.toStringAsFixed(0)}%',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFFE65100),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                ],
                Container(
                  width: 32,
                  height: 32,
                  decoration: const BoxDecoration(
                    color: Color(0xFFF5F5F5),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: const Icon(Icons.more_vert_rounded,
                      size: 18, color: Colors.black45),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String label;
  final String subtitle;
  final bool isDestructive;
  final VoidCallback onTap;

  const _ActionTile({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.label,
    required this.subtitle,
    required this.onTap,
    this.isDestructive = false,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      leading: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: iconBg,
          borderRadius: BorderRadius.zero,
        ),
        child: Icon(icon, color: iconColor, size: 22),
      ),
      title: Text(
        label,
        style: TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 14,
          color: isDestructive ? AppColors.danger : Colors.black87,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(fontSize: 12, color: Colors.black45),
      ),
      trailing: Icon(Icons.chevron_right_rounded,
          color: Colors.grey.shade300, size: 20),
    );
  }
}

class _EmptyPelangganView extends StatelessWidget {
  final bool isSearching;
  const _EmptyPelangganView({required this.isSearching});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: const BoxDecoration(
              color: _kBrandLight,
              shape: BoxShape.rectangle,
            ),
            child: const Icon(Icons.people_outline_rounded,
                size: 48, color: AppColors.primaryBrand),
          ),
          const SizedBox(height: 18),
          Text(
            isSearching
                ? 'Pelanggan tidak ditemukan'
                : 'Belum ada data pelanggan',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            isSearching
                ? 'Coba gunakan kata kunci lain'
                : 'Tambahkan pelanggan pertama Anda',
            style: const TextStyle(fontSize: 13, color: Colors.black45),
          ),
        ],
      ),
    );
  }
}

InputDecoration _inputDeco(String hint, [IconData? prefixIcon]) {
  return InputDecoration(
    hintText: hint,
    isDense: true,
    prefixIcon: prefixIcon != null
        ? Icon(prefixIcon, size: 18, color: Colors.black38)
        : null,
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    filled: true,
    fillColor: const Color(0xFFF6F7F9),
    border: const OutlineInputBorder(
      borderRadius: BorderRadius.zero,
      borderSide: BorderSide(color: Color(0xFFE0E0E0)),
    ),
    enabledBorder: const OutlineInputBorder(
      borderRadius: BorderRadius.zero,
      borderSide: BorderSide(color: Color(0xFFE8E8E8)),
    ),
    focusedBorder: const OutlineInputBorder(
      borderRadius: BorderRadius.zero,
      borderSide: BorderSide(color: _kBrand, width: 1.5),
    ),
  );
}

