import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../core/theme.dart';
import '../database/db_helper.dart';
import '../widgets/kasir_dialog.dart';
import '../widgets/export_dropdown.dart';
import '../services/export_service.dart';
import 'responsive_layout.dart';

const Color _kBrand = AppColors.primaryBrand;

class AnalisisLayananservisScreen extends StatefulWidget {
  const AnalisisLayananservisScreen({super.key});

  @override
  State<AnalisisLayananservisScreen> createState() =>
      _AnalisisLayananservisScreenState();
}

class _AnalisisLayananservisScreenState
    extends State<AnalisisLayananservisScreen> {
  String _periode = 'Periode Tahunan';
  int _tahun = DateTime.now().year;
  int _bulan = DateTime.now().month;
  DateTime _hariTerpilih = DateTime.now();

  static const _bulanNama = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember'
  ];

  DateTime? _customStart;
  DateTime? _customEnd;

  Map<String, dynamic>? _stats;
  bool _isLoading = false;

  final List<String> _periodeOptions = [
    'Periode Harian',
    'Periode Bulanan',
    'Periode Tahunan',
    'Kustom Tanggal',
  ];

  final List<int> _tahunOptions = [
    DateTime.now().year - 2,
    DateTime.now().year - 1,
    DateTime.now().year,
    DateTime.now().year + 1,
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    DateTime start;
    DateTime end;

    if (_periode == 'Periode Harian') {
      start =
          DateTime(_hariTerpilih.year, _hariTerpilih.month, _hariTerpilih.day);
      end = DateTime(_hariTerpilih.year, _hariTerpilih.month, _hariTerpilih.day,
          23, 59, 59);
    } else if (_periode == 'Periode Bulanan') {
      start = DateTime(_tahun, _bulan, 1);
      var nextMonth = _bulan == 12 ? 1 : _bulan + 1;
      var nextYear = _bulan == 12 ? _tahun + 1 : _tahun;
      end =
          DateTime(nextYear, nextMonth, 1).subtract(const Duration(seconds: 1));
    } else if (_periode == 'Kustom Tanggal') {
      final now = DateTime.now();
      start = _customStart ?? DateTime(now.year, now.month, now.day);
      end = _customEnd ?? DateTime(now.year, now.month, now.day, 23, 59, 59);
    } else {
      // Tahunan
      start = DateTime(_tahun, 1, 1);
      end = DateTime(_tahun, 12, 31, 23, 59, 59);
    }

    final stats = await DBHelper.instance.getSalesStatsReport(start, end);
    if (!mounted) return;
    setState(() {
      _stats = stats;
      _isLoading = false;
    });
  }

  String _formatRp(num value) {
    if (value == 0) return 'Rp0';
    String s = value.toInt().toString();
    String r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0 && s[i - 1] != '-') r = '.$r';
    }
    return 'Rp$r';
  }

  Future<void> _pickCustomDate() async {
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2050),
      initialDateRange: _customStart != null && _customEnd != null
          ? DateTimeRange(start: _customStart!, end: _customEnd!)
          : null,
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: _kBrand,
              onPrimary: Colors.white,
              surface: Colors.white,
              onSurface: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );
    if (range != null) {
      setState(() {
        _customStart = range.start;
        _customEnd = range.end;
      });
      _loadData();
    } else {
      setState(() => _periode = 'Periode Tahunan'); // Fallback
      _loadData();
    }
  }

  Future<void> _showBulanSheet() async {
    final bulanOptions = List.generate(12, (i) => i + 1);
    final selected = await showKasirOptionSheet<int>(
      context,
      title: 'Pilih Bulan',
      options: bulanOptions,
      currentValue: _bulan,
      labelBuilder: (b) => _bulanNama[b - 1],
    );
    if (selected != null && selected != _bulan) {
      if (!mounted) return;
      setState(() => _bulan = selected);
      _loadData();
    }
  }

  Future<void> _pickHariDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _hariTerpilih,
      firstDate: DateTime(2020),
      lastDate: DateTime(2050),
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: _kBrand,
              onPrimary: Colors.white,
              surface: Colors.white,
              onSurface: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() => _hariTerpilih = picked);
      _loadData();
    }
  }

  Future<void> _showPeriodeSheet() async {
    final selected = await showKasirOptionSheet<String>(
      context,
      title: 'Pilih Periode',
      options: _periodeOptions,
      currentValue: _periode,
      labelBuilder: (idx) => idx,
    );
    if (selected != null && selected != _periode) {
      if (!mounted) return;
      setState(() => _periode = selected);
      if (selected == 'Kustom Tanggal') {
        _pickCustomDate();
      } else {
        _loadData();
      }
    }
  }

  Future<void> _showTahunSheet() async {
    final selected = await showKasirOptionSheet<int>(
      context,
      title: 'Pilih Tahun',
      options: _tahunOptions,
      currentValue: _tahun,
      labelBuilder: (y) => y.toString(),
    );
    if (selected != null && selected != _tahun) {
      if (!mounted) return;
      setState(() => _tahun = selected);
      _loadData();
    }
  }

  @override
  Widget build(BuildContext context) {
    String subtitle = _periode;
    if (_periode == 'Kustom Tanggal' &&
        _customStart != null &&
        _customEnd != null) {
      subtitle =
          '${_customStart!.day}/${_customStart!.month}/${_customStart!.year} - ${_customEnd!.day}/${_customEnd!.month}/${_customEnd!.year}';
    }

    final filterPanel = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Period selectors
        Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: isTabletDevice(context) && isLandscape(context)
              ? Column(
                  children: [
                    _buildPeriodeDropdown(subtitle),
                    const SizedBox(height: 10),
                    if (_periode != 'Kustom Tanggal') _buildSecondDropdown(),
                  ],
                )
              : Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: _buildPeriodeDropdown(subtitle),
                    ),
                    if (_periode != 'Kustom Tanggal') const SizedBox(width: 12),
                    if (_periode != 'Kustom Tanggal')
                      Expanded(
                        flex: 3,
                        child: _buildSecondDropdown(),
                      ),
                  ],
                ),
        ),
      ],
    );

    final gridCount = responsiveGridCount(context);
    final mainContent = _isLoading || _stats == null
        ? const Center(child: CircularProgressIndicator(color: _kBrand))
        : GridView.count(
            crossAxisCount: gridCount,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: gridCount == 1 ? 3.2 : 1.72,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10)
                .copyWith(bottom: 20),
            children: [
              _StatCard('Transaksi Lunas', _stats!['lunas_count'].toString(),
                  Icons.check_circle_outline_rounded, _kBrand),
              _StatCard('Item Terjual', _stats!['products'].toString(),
                  Icons.handyman_outlined, _kBrand),
              _StatCard('Omzet', _formatRp(_stats!['omzet']),
                  Icons.payments_outlined, _kBrand),
              _StatCard('Laba', _formatRp(_stats!['profit']),
                  Icons.trending_up_rounded, _kBrand),
              _StatCard('Belum Lunas', _stats!['piutang_count'].toString(),
                  Icons.pending_actions_rounded, _kBrand),
              _StatCard('Total Tagihan', _formatRp(_stats!['total_piutang']),
                  Icons.account_balance_wallet_outlined, _kBrand),
              _StatCard('Pelunasan', _formatRp(_stats!['piutang_terbayar']),
                  Icons.history_rounded, _kBrand),
              _StatCard('Sisa Tagihan', _formatRp(_stats!['sisa_piutang']),
                  Icons.money_off_rounded, _kBrand),
            ],
          );

    return KasirResponsiveScaffold(
      title: 'Analisis Layanan Servis',
      navIndex: 4,
      showNavRail: false,
      backgroundColor: Colors.white,
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: GestureDetector(
            onTap: () async {
              if (_stats == null) return;
              final choice = await ExportDropdown.show(context);
              if (choice == null) return;

              final tLabel = 'Laporan Transaksi - $_periode';
              final subLabel = 'Omzet: ${_formatRp(_stats!['omzet'])}';
              final headers = ['Keterangan', 'Nilai'];
              final rows = [
                ['Transaksi Lunas', _stats!['lunas_count']],
                ['Item Terjual', _stats!['products']],
                ['Omzet', _formatRp(_stats!['omzet'])],
                ['Laba', _formatRp(_stats!['profit'])],
                ['Transaksi Belum Lunas', _stats!['piutang_count']],
                ['Total Tagihan', _formatRp(_stats!['total_piutang'])],
                ['Tagihan Terbayar', _formatRp(_stats!['piutang_terbayar'])],
                ['Sisa Tagihan', _formatRp(_stats!['sisa_piutang'])],
              ];

              final pieData = {
                'Omzet': (_stats!['omzet'] as num).toDouble(),
                'Total Piutang': (_stats!['total_piutang'] as num).toDouble(),
              };

              final summaryData = {
                'Transaksi': _stats!['lunas_count'].toString(),
                'Item Terjual': _stats!['products'].toString(),
                'Omzet': _formatRp(_stats!['omzet']),
                'Laba': _formatRp(_stats!['profit']),
                'Piutang': _formatRp(_stats!['sisa_piutang']),
              };

              try {
                if (choice == 'csv') {
                  await ExportService.exportAndShareCsv(
                    filePrefix: 'Transaksi_Penjualan',
                    headers: headers,
                    rows: rows,
                  );
                } else if (choice == 'pdf') {
                  await ExportService.exportPdfLaporan(
                    title: tLabel,
                    subtitle: subLabel,
                    headers: headers,
                    rows: rows,
                    pieChartData: pieData,
                    summaryData: summaryData,
                  );
                } else if (choice == 'print') {
                  await ExportService.printPdfLaporan(
                    title: tLabel,
                    subtitle: subLabel,
                    headers: headers,
                    rows: rows,
                    pieChartData: pieData,
                    summaryData: summaryData,
                  );
                }
              } catch (e) {
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                      content: Text('Gagal mengekspor. Silakan coba lagi.')),
                );
              }
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: const BoxDecoration(
                color: AppColors.primaryBrand,
                borderRadius: BorderRadius.zero,
              ),
              child: const Row(
                children: [
                  Icon(Icons.download_rounded, color: Colors.white, size: 15),
                  SizedBox(width: 5),
                  Text(
                    'Ekspor',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
      body: Column(
        children: [
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 14),
              child: ResponsiveReportLayout(
                filterPanel: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: filterPanel,
                ),
                content: mainContent,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPeriodeDropdown(String subtitle) {
    return GestureDetector(
      onTap: _showPeriodeSheet,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: const BoxDecoration(
          color: Color(0xFFF5F5F5),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      color: Colors.black87)),
            ),
            const Icon(Icons.keyboard_arrow_down_rounded,
                color: _kBrand, size: 22),
          ],
        ),
      ),
    );
  }

  Widget _buildSecondDropdown() {
    if (_periode == 'Periode Bulanan') {
      return Row(
        children: [
          Expanded(
            flex: 1,
            child: GestureDetector(
              onTap: _showBulanSheet,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                decoration: const BoxDecoration(
                  color: Color(0xFFF5F5F5),
                  borderRadius: BorderRadius.zero,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                        child: Text(_bulanNama[_bulan - 1].substring(0, 3),
                            maxLines: 1,
                            style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                                color: Colors.black87))),
                    const Icon(Icons.keyboard_arrow_down_rounded,
                        color: _kBrand, size: 20),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            flex: 1,
            child: GestureDetector(
              onTap: _showTahunSheet,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                decoration: const BoxDecoration(
                  color: Color(0xFFF5F5F5),
                  borderRadius: BorderRadius.zero,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(_tahun.toString(),
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                            color: Colors.black87)),
                    const Icon(Icons.keyboard_arrow_down_rounded,
                        color: _kBrand, size: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      );
    }

    return GestureDetector(
      onTap: _periode == 'Periode Harian' ? _pickHariDate : _showTahunSheet,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: const BoxDecoration(
          color: Color(0xFFF5F5F5),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
                _periode == 'Periode Harian'
                    ? '${_hariTerpilih.day} ${_bulanNama[_hariTerpilih.month - 1]}'
                    : _tahun.toString(),
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: Colors.black87)),
            const Icon(Icons.keyboard_arrow_down_rounded,
                color: _kBrand, size: 22),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard(this.label, this.value, this.icon, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.zero,
            ),
            child: Icon(icon, color: color, size: 19),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(label,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.inter(
                        color: Colors.black54,
                        fontSize: 11,
                        height: 1.15,
                        fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                SizedBox(
                  width: double.infinity,
                  child: FittedBox(
                    alignment: Alignment.centerLeft,
                    fit: BoxFit.scaleDown,
                    child: Text(value,
                        maxLines: 1,
                        style: GoogleFonts.poppins(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF1E293B))),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

