import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:io';

import '../core/theme.dart';
import '../providers/providers.dart';
import '../services/auth_service.dart';
import '../services/support_contact_service.dart';
import '../widgets/remote_scanner_instructions_dialog.dart';

const Color _kBrand = AppColors.primaryBrand;

class _SerialStyleFormatter extends TextInputFormatter {
  final int maxRawLength;

  const _SerialStyleFormatter({this.maxRawLength = 32});

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final rawChars =
        newValue.text.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
    final limitedRaw = rawChars.length > maxRawLength
        ? rawChars.substring(0, maxRawLength)
        : rawChars;
    final formatted = _formatChunks(limitedRaw);
    final rawSelectionIndex = _countRawCharsBefore(
      newValue.text,
      newValue.selection.extentOffset,
    ).clamp(0, limitedRaw.length);
    final formattedSelectionIndex =
        _selectionOffsetForRawIndex(formatted, rawSelectionIndex);

    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formattedSelectionIndex),
      composing: TextRange.empty,
    );
  }

  String _formatChunks(String value) {
    final buffer = StringBuffer();
    for (var i = 0; i < value.length; i++) {
      if (i > 0 && i % 4 == 0) {
        buffer.write('-');
      }
      buffer.write(value[i]);
    }
    return buffer.toString();
  }

  int _countRawCharsBefore(String text, int offset) {
    final safeOffset = offset.clamp(0, text.length);
    var count = 0;
    for (var i = 0; i < safeOffset; i++) {
      final char = text[i];
      if (RegExp(r'[A-Za-z0-9]').hasMatch(char)) {
        count++;
      }
    }
    return count;
  }

  int _selectionOffsetForRawIndex(String text, int rawIndex) {
    if (rawIndex <= 0) {
      return 0;
    }
    var seen = 0;
    for (var i = 0; i < text.length; i++) {
      final char = text[i];
      if (RegExp(r'[A-Z0-9]').hasMatch(char)) {
        seen++;
        if (seen == rawIndex) {
          return i + 1;
        }
      }
    }
    return text.length;
  }
}

class LoginLisensiScreen extends ConsumerStatefulWidget {
  const LoginLisensiScreen({super.key});

  @override
  ConsumerState<LoginLisensiScreen> createState() => _LoginLisensiScreenState();
}

class _LoginLisensiScreenState extends ConsumerState<LoginLisensiScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _serialCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  late final AnimationController _animCtrl;
  late final Animation<double> _fadeAnim;

  bool _isLoading = false;
  bool _showPass = false;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 550),
    );
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _animCtrl.forward();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _serialCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _aktivasi() async {
    if (_isLoading) {
      return;
    }
    FocusScope.of(context).unfocus();

    final valid = _formKey.currentState?.validate() ?? false;
    if (!valid) {
      return;
    }

    final identifier = _serialCtrl.text.trim();
    final pass = _passCtrl.text.trim();

    setState(() => _isLoading = true);

    try {
      final status = await ref.read(authProvider.notifier).login(
            identifier,
            pass,
          );

      if (!mounted) {
        return;
      }
      setState(() => _isLoading = false);

      if (status == AuthStatus.unauthorized) {
        _showSnack(
          'Serial number atau password tidak valid.',
          isError: true,
        );
      }
    } on DeviceLockedException catch (e) {
      if (!mounted) {
        return;
      }
      setState(() => _isLoading = false);

      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          title: const Text('Perangkat Sudah Terikat'),
          content: Text(
            e.oldDeviceId.isEmpty
                ? 'Lisensi ini sudah aktif di perangkat lain. Demi keamanan, perpindahan perangkat hanya bisa dilakukan dari dashboard admin melalui reset device.'
                : 'Lisensi ini sudah aktif di perangkat lain (${e.oldDeviceId}). Demi keamanan, perpindahan perangkat hanya bisa dilakukan dari dashboard admin melalui reset device.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Tutup'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBrand,
                foregroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
              onPressed: () async {
                Navigator.pop(ctx);
                await _launchSupportWhatsapp();
              },
              child: const Text('Hubungi Admin'),
            ),
          ],
        ),
      );
    } on DeviceLimitReachedException catch (e) {
      if (!mounted) {
        return;
      }
      setState(() => _isLoading = false);

      final identifier = _serialCtrl.text.trim();
      final pass = _passCtrl.text.trim();

      await _showDeviceReplacementFlow(
        serial: identifier,
        password: pass,
        currentDevices: e.currentDevices,
        maxDevices: e.maxDevices,
      );
    } on AuthBackendRequiredException catch (e) {
      if (!mounted) {
        return;
      }
      setState(() => _isLoading = false);
      _showSnack(e.toString(), isError: true);
    } catch (e) {
      if (!mounted) {
        return;
      }
      setState(() => _isLoading = false);
      _showSnack('Terjadi kesalahan: $e', isError: true);
    }
  }

  Future<void> _mulaiDemoTrial() async {
    if (_isLoading) {
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() => _isLoading = true);

    try {
      final status = await ref.read(authProvider.notifier).startDemoTrial();
      if (!mounted) {
        return;
      }
      setState(() => _isLoading = false);

      if (status == AuthStatus.unauthorized) {
        await _showDemoAccessDialog(
          title: 'Demo Tidak Tersedia',
          message: 'Demo trial tidak dapat diaktifkan di perangkat ini.',
        );
      }
    } on DemoTrialException catch (e) {
      if (!mounted) {
        return;
      }
      setState(() => _isLoading = false);
      await _showDemoAccessDialog(
        title: _demoDialogTitle(e.toString()),
        message: e.toString(),
      );
    } on AuthBackendRequiredException catch (e) {
      if (!mounted) {
        return;
      }
      setState(() => _isLoading = false);
      _showSnack(e.toString(), isError: true);
    } catch (e) {
      if (!mounted) {
        return;
      }
      setState(() => _isLoading = false);
      _showSnack('Terjadi kesalahan: $e', isError: true);
    }
  }

  String _demoDialogTitle(String message) {
    final lower = message.toLowerCase();
    if (lower.contains('berakhir') || lower.contains('habis')) {
      return 'Masa Demo Berakhir';
    }
    if (lower.contains('dinonaktifkan')) {
      return 'Akses Demo Dinonaktifkan';
    }
    return 'Demo Tidak Tersedia';
  }

  String _demoDialogBody(String title, String message) {
    final lower = title.toLowerCase();
    if (lower.contains('berakhir')) {
      return 'Masa demo di perangkat ini sudah berakhir. Hubungi tim kami untuk aktivasi lisensi resmi.';
    }
    if (lower.contains('dinonaktifkan')) {
      return 'Akses demo di perangkat ini sedang dinonaktifkan. Hubungi tim kami untuk pengecekan atau aktivasi lisensi resmi.';
    }
    return '$message Hubungi tim kami untuk pengecekan atau aktivasi lisensi resmi.';
  }

  Future<void> _showDemoAccessDialog({
    required String title,
    required String message,
  }) async {
    if (!mounted) {
      return;
    }
    final body = _demoDialogBody(title, message);
    await showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 24, 24, 22),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          alignment: Alignment.center,
                          color: _kBrand.withValues(alpha: 0.1),
                          child: const Icon(
                            Icons.lock_clock_rounded,
                            color: _kBrand,
                            size: 22,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(right: 34),
                            child: Text(
                              title,
                              style: AppText.h2.copyWith(
                                color: const Color(0xFF101828),
                                fontSize: 18,
                                height: 1.2,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Text(
                      body,
                      style: AppText.bodySmall.copyWith(
                        color: const Color(0xFF475467),
                        height: 1.45,
                      ),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      height: 46,
                      child: ElevatedButton.icon(
                        onPressed: () async {
                          Navigator.pop(ctx);
                          await _launchDemoConsultationWhatsapp();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF16A34A),
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero,
                          ),
                        ),
                        icon: const FaIcon(FontAwesomeIcons.whatsapp, size: 16),
                        label: const Text(
                          'Hubungi Support',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: SizedBox(
                  width: 36,
                  height: 36,
                  child: IconButton(
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: () => Navigator.pop(ctx),
                    icon: const Icon(Icons.close_rounded, size: 20),
                    color: const Color(0xFF667085),
                    tooltip: 'Tutup',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showDeviceReplacementFlow({
    required String serial,
    required String password,
    required int currentDevices,
    required int maxDevices,
  }) async {
    setState(() => _isLoading = true);

    List<LicenseDeviceInfo> devices;
    try {
      devices = await AuthService.fetchReplaceableDevices(
        serial: serial,
        password: password,
      );
    } on AuthBackendRequiredException catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      _showSnack(e.toString(), isError: true);
      return;
    } catch (_) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      _showSnack(
        'Gagal membaca daftar perangkat aktif. Pastikan koneksi internet aktif.',
        isError: true,
      );
      return;
    }

    if (!mounted) return;
    setState(() => _isLoading = false);

    if (devices.isEmpty) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          title: const Text('Daftar perangkat tidak ditemukan'),
          content: const Text(
            'Lisensi terbaca penuh, tetapi daftar perangkat aktif belum bisa ditampilkan. Coba lagi beberapa saat, atau hubungi admin untuk reset perangkat.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Tutup'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              onPressed: () async {
                Navigator.pop(ctx);
                await _launchSupportWhatsapp(serial);
              },
              child: const Text('Hubungi Admin'),
            ),
          ],
        ),
      );
      return;
    }

    final selected = await showDialog<LicenseDeviceInfo>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 24),
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: 480,
            maxHeight: MediaQuery.sizeOf(ctx).height - 48,
          ),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 22, 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        alignment: Alignment.center,
                        color: _kBrand.withValues(alpha: 0.1),
                        child: const Icon(
                          Icons.devices_other_rounded,
                          color: _kBrand,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Kuota Perangkat Penuh',
                              style: AppText.h2.copyWith(
                                color: const Color(0xFF101828),
                                fontSize: 19,
                                height: 1.2,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'Lisensi ini sudah digunakan di $currentDevices dari $maxDevices perangkat yang diizinkan.',
                              style: AppText.bodySmall.copyWith(
                                color: const Color(0xFF475467),
                                height: 1.4,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  const _DeviceReplacementNotice(
                    text:
                        'Pilih perangkat lama yang ingin dikeluarkan. Setelah dikonfirmasi, perangkat ini langsung aktif memakai lisensi yang sama.',
                  ),
                  const SizedBox(height: 14),
                  ...List.generate(devices.length, (index) {
                    final device = devices[index];
                    return Padding(
                      padding: EdgeInsets.only(
                        bottom: index == devices.length - 1 ? 0 : 10,
                      ),
                      child: _ReplaceableDeviceTile(
                        title: 'Perangkat ${index + 1}',
                        platform: _platformLabel(device.platform),
                        deviceId: _shortDeviceId(device.deviceId),
                        activatedAt: _formatDeviceDate(device.activatedAt),
                        actionLabel: 'Ganti perangkat ini',
                        onReplace: () => Navigator.pop(ctx, device),
                      ),
                    );
                  }),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 44,
                          child: OutlinedButton(
                            onPressed: () => Navigator.pop(ctx),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFF344054),
                              side: const BorderSide(
                                color: Color(0xFFD0D5DD),
                              ),
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero,
                              ),
                            ),
                            child: const Text('Batal'),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: SizedBox(
                          height: 44,
                          child: OutlinedButton(
                            onPressed: () async {
                              Navigator.pop(ctx);
                              await _launchSupportWhatsapp(serial);
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: _kBrand,
                              side: const BorderSide(color: _kBrand),
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero,
                              ),
                            ),
                            child: const Text('Tambah Kuota'),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );

    if (selected == null || !mounted) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Text('Ganti perangkat ini?'),
        content: const Text(
          'Perangkat lama yang dipilih akan dikeluarkan dari lisensi. Jika perangkat lama masih dipakai, aplikasi di sana akan keluar saat online atau validasi lisensi berikutnya.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Ganti Perangkat'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    await _replaceSelectedDevice(
      serial: serial,
      password: password,
      device: selected,
    );
  }

  Future<void> _replaceSelectedDevice({
    required String serial,
    required String password,
    required LicenseDeviceInfo device,
  }) async {
    setState(() => _isLoading = true);

    try {
      final ok = await AuthService.replaceDeviceAndActivate(
        serial: serial,
        password: password,
        oldDeviceId: device.deviceId,
      );
      if (!mounted) return;
      setState(() => _isLoading = false);

      if (!ok) {
        _showSnack('Gagal mengganti perangkat.', isError: true);
        return;
      }

      await ref.read(authProvider.notifier).activateStoredLicenseSession();
      if (!mounted) return;
      _showSnack(
          'Perangkat berhasil diganti. Akun sudah aktif di perangkat ini.');
    } on DeviceReplacementCooldownException catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      _showSnack(e.toString(), isError: true);
    } on AuthBackendRequiredException catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      _showSnack(e.toString(), isError: true);
    } catch (_) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      _showSnack(
        'Gagal mengganti perangkat. Pastikan koneksi internet aktif.',
        isError: true,
      );
    }
  }

  String _platformLabel(String value) {
    switch (value.trim().toLowerCase()) {
      case 'android':
        return 'Android';
      case 'desktop':
      case 'windows':
        return 'Desktop';
      case 'ios':
        return 'iOS';
      default:
        return 'Perangkat';
    }
  }

  String _shortDeviceId(String value) {
    final trimmed = value.trim();
    if (trimmed.length <= 12) return trimmed;
    return '...${trimmed.substring(trimmed.length - 10)}';
  }

  String _formatDeviceDate(String? value) {
    if (value == null || value.trim().isEmpty) return '-';
    final parsed = DateTime.tryParse(value)?.toLocal();
    if (parsed == null) return value;
    String two(int number) => number.toString().padLeft(2, '0');
    return '${two(parsed.day)}/${two(parsed.month)}/${parsed.year} ${two(parsed.hour)}:${two(parsed.minute)}';
  }

  Future<void> _launchSupportWhatsapp([String? serial]) async {
    try {
      final profile = ref.read(profilProvider);
      String text =
          "Halo Admin Juragan Servis,\n\nSaya ingin menambah kuota perangkat untuk lisensi saya.";
      if (serial != null && serial.isNotEmpty) {
        text += "\n\n*Detail Akun:*";
        text += "\nSerial Number: $serial";
      }
      if (profile.nama.isNotEmpty) {
        text += "\nNama: ${profile.nama}";
      }

      await SupportContactService.launchSupportWhatsapp(message: text);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Tidak dapat membuka WhatsApp'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
      }
    }
  }

  Future<void> _launchDemoConsultationWhatsapp() async {
    try {
      await SupportContactService.launchSupportWhatsapp(
        message:
            'Halo Support Juragan Servis, saya ingin konsultasi aktivasi lisensi setelah mencoba demo.',
      );
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Tidak dapat membuka WhatsApp'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
      }
    }
  }

  Future<void> _launchLoginSupportWhatsapp() async {
    try {
      final serial = _serialCtrl.text.trim();
      var message =
          'Halo Support Juragan Servis, saya membutuhkan bantuan login atau aktivasi lisensi.';
      if (serial.isNotEmpty) {
        message += '\n\nSerial Number: $serial';
      }
      await SupportContactService.launchSupportWhatsapp(message: message);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Tidak dapat membuka WhatsApp'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
      }
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError ? AppColors.danger : Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ),
    );
  }

  Future<void> _openRemoteScanner() async {
    final shouldOpen = await RemoteScannerInstructionsDialog.show(
      context,
      showStartAction: true,
    );
    if (!shouldOpen || !mounted) {
      return;
    }

    Navigator.pushNamed(context, '/remote_scanner');
  }

  @override
  Widget build(BuildContext context) {
    debugPrint('[UI] Building LoginLisensiScreen...');
    final topInset = MediaQuery.of(context).padding.top;
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            24,
            topInset > 0 ? 32 : 56,
            24,
            bottomInset + 24,
          ),
          child: DefaultTextStyle(
            style: const TextStyle(color: Color(0xFF101828)),
            child: FadeTransition(
              opacity: _fadeAnim,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 56,
                        height: 56,
                        padding: const EdgeInsets.all(8),
                        decoration: const BoxDecoration(
                          color: _kBrand,
                          borderRadius: BorderRadius.zero,
                        ),
                        clipBehavior: Clip.hardEdge,
                        child: Transform.scale(
                          scale: 2.0,
                          child: Image.asset(
                            'assets/images/logo.png',
                            color: Colors.white,
                            colorBlendMode: BlendMode.srcIn,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                      const Spacer(),
                      if (Platform.isAndroid || Platform.isIOS)
                        SizedBox(
                          width: 48,
                          height: 48,
                          child: OutlinedButton(
                            onPressed: _isLoading ? null : _openRemoteScanner,
                            style: OutlinedButton.styleFrom(
                              foregroundColor: _kBrand,
                              disabledForegroundColor:
                                  _kBrand.withValues(alpha: 0.45),
                              side: BorderSide(
                                color: _isLoading
                                    ? _kBrand.withValues(alpha: 0.35)
                                    : _kBrand,
                                width: 1.5,
                              ),
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero,
                              ),
                              padding: EdgeInsets.zero,
                            ),
                            child: const Icon(
                              Icons.qr_code_scanner_rounded,
                              size: 22,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 32),
                  Text(
                    'Juragan Servis',
                    style: AppText.h1.copyWith(
                      fontSize: 32,
                      fontWeight: FontWeight.w800,
                      color: const Color(0xFF101828),
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Aktivasi lisensi perangkat untuk mengakses sistem manajemen servis profesional.',
                    style: AppText.bodySmall.copyWith(
                      color: const Color(0xFF475467),
                      fontSize: 15,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 48),
                  Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF8FAFC),
                            border: Border.all(color: const Color(0xFFE2E8F0)),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Icon(
                                Icons.workspace_premium_outlined,
                                color: Color(0xFF0F766E),
                                size: 18,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  'Coba fitur servis gratis 1x24 jam sebelum aktivasi resmi.',
                                  style: AppText.caption.copyWith(
                                    color: const Color(0xFF475467),
                                    fontSize: 12,
                                    height: 1.35,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        _LoginField(
                          controller: _serialCtrl,
                          label: 'Serial Number',
                          hint: 'Ketik Serial Number',
                          icon: Icons.vpn_key_outlined,
                          keyboardType: TextInputType.visiblePassword,
                          textCapitalization: TextCapitalization.characters,
                          textInputAction: TextInputAction.next,
                          inputFormatters: const [
                            _SerialStyleFormatter(maxRawLength: 32),
                          ],
                          validator: (value) {
                            final text = (value ?? '').trim();
                            if (text.isEmpty) {
                              return 'Serial wajib diisi';
                            }
                            return null;
                          },
                        ),
                        const SizedBox(height: 20),
                        _LoginField(
                          controller: _passCtrl,
                          label: 'Password',
                          hint: 'Masukkan password',
                          icon: Icons.lock_outline_rounded,
                          keyboardType: TextInputType.visiblePassword,
                          obscureText: !_showPass,
                          textInputAction: TextInputAction.done,
                          suffixIcon: _showPass
                              ? Icons.visibility_off_outlined
                              : Icons.visibility_outlined,
                          onSuffixTap: () =>
                              setState(() => _showPass = !_showPass),
                          onSubmitted: () => _aktivasi(),
                          validator: (value) {
                            final text = (value ?? '').trim();
                            if (text.isEmpty) {
                              return 'Password wajib diisi';
                            }
                            return null;
                          },
                        ),
                        const SizedBox(height: 32),
                        SizedBox(
                          height: 48,
                          child: ElevatedButton(
                            onPressed: _isLoading ? null : () => _aktivasi(),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _kBrand,
                              disabledBackgroundColor:
                                  _kBrand.withValues(alpha: 0.55),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero,
                              ),
                            ),
                            child: _isLoading
                                ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                          Colors.white),
                                    ),
                                  )
                                : Text(
                                    'Masuk',
                                    style: AppText.h3.copyWith(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 15,
                                    ),
                                  ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 48,
                          child: OutlinedButton.icon(
                            onPressed: _isLoading ? null : _mulaiDemoTrial,
                            style: OutlinedButton.styleFrom(
                              foregroundColor: _kBrand,
                              disabledForegroundColor:
                                  _kBrand.withValues(alpha: 0.45),
                              side: BorderSide(
                                color: _isLoading
                                    ? _kBrand.withValues(alpha: 0.35)
                                    : _kBrand,
                                width: 1.5,
                              ),
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero,
                              ),
                            ),
                            icon: const Icon(Icons.timer_rounded, size: 18),
                            label: Text(
                              'Klik di Sini untuk Demo Gratis',
                              style: AppText.h3.copyWith(
                                color: _isLoading
                                    ? _kBrand.withValues(alpha: 0.45)
                                    : _kBrand,
                                fontWeight: FontWeight.w700,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.wifi_rounded,
                                color: Colors.black45, size: 14),
                            const SizedBox(width: 6),
                            Text(
                              'Memerlukan koneksi internet untuk verifikasi',
                              style: AppText.caption.copyWith(
                                color: Colors.black54,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),
                  Center(
                    child: TextButton.icon(
                      onPressed:
                          _isLoading ? null : _launchLoginSupportWhatsapp,
                      style: TextButton.styleFrom(
                        foregroundColor: const Color(0xFF16A34A),
                        disabledForegroundColor:
                            const Color(0xFF16A34A).withValues(alpha: 0.4),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 12),
                      ),
                      icon: const FaIcon(FontAwesomeIcons.whatsapp, size: 18),
                      label: const Text(
                        'Hubungi Support via WhatsApp',
                        style: TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _LoginField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final bool obscureText;
  final IconData? suffixIcon;
  final VoidCallback? onSuffixTap;
  final VoidCallback? onSubmitted;
  final String? Function(String?)? validator;
  final List<TextInputFormatter>? inputFormatters;
  final TextInputType keyboardType;
  final TextInputAction textInputAction;
  final TextCapitalization textCapitalization;

  const _LoginField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.obscureText = false,
    this.suffixIcon,
    this.onSuffixTap,
    this.onSubmitted,
    this.validator,
    this.inputFormatters,
    this.keyboardType = TextInputType.text,
    this.textInputAction = TextInputAction.next,
    this.textCapitalization = TextCapitalization.none,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppText.caption.copyWith(
            color: const Color(0xFF344054),
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
        const SizedBox(height: 6),
        TextFormField(
          controller: controller,
          obscureText: obscureText,
          autocorrect: false,
          enableSuggestions: false,
          validator: validator,
          keyboardType: keyboardType,
          inputFormatters: inputFormatters,
          textInputAction: textInputAction,
          textCapitalization: textCapitalization,
          onFieldSubmitted: (_) => onSubmitted?.call(),
          style: AppText.body.copyWith(
            fontWeight: FontWeight.w500,
            color: const Color(0xFF101828),
            fontSize: 15,
          ),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: AppText.bodySmall.copyWith(
              color: const Color(0xFF98A2B3),
              fontSize: 14,
              fontWeight: FontWeight.w400,
            ),
            prefixIcon: Icon(icon, color: const Color(0xFF667085), size: 20),
            suffixIcon: suffixIcon == null
                ? null
                : IconButton(
                    onPressed: onSuffixTap,
                    icon: Icon(suffixIcon,
                        color: const Color(0xFF667085), size: 20),
                  ),
            filled: true,
            fillColor: Colors.white,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            border: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: Color(0xFFD0D5DD)),
            ),
            enabledBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: Color(0xFFD0D5DD)),
            ),
            focusedBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: _kBrand, width: 2),
            ),
            errorBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: AppColors.danger),
            ),
            focusedErrorBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: AppColors.danger, width: 2),
            ),
          ),
        ),
      ],
    );
  }
}

class _DeviceReplacementNotice extends StatelessWidget {
  final String text;

  const _DeviceReplacementNotice({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF0F7F6),
        border: Border.all(color: const Color(0xFFB7D8D5)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline_rounded, color: _kBrand, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: AppText.bodySmall.copyWith(
                color: const Color(0xFF344054),
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReplaceableDeviceTile extends StatelessWidget {
  final String title;
  final String platform;
  final String deviceId;
  final String activatedAt;
  final String actionLabel;
  final VoidCallback onReplace;

  const _ReplaceableDeviceTile({
    required this.title,
    required this.platform,
    required this.deviceId,
    required this.activatedAt,
    required this.actionLabel,
    required this.onReplace,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFD0D5DD)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 34,
                height: 34,
                alignment: Alignment.center,
                color: _kBrand.withValues(alpha: 0.08),
                child: const Icon(
                  Icons.devices_rounded,
                  color: _kBrand,
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: AppText.body.copyWith(
                        color: const Color(0xFF101828),
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$platform - ID $deviceId',
                      style: AppText.caption.copyWith(
                        color: const Color(0xFF667085),
                        height: 1.3,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Aktif sejak $activatedAt',
                      style: AppText.caption.copyWith(
                        color: const Color(0xFF667085),
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 40,
            child: ElevatedButton(
              onPressed: onReplace,
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: Text(
                actionLabel,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

