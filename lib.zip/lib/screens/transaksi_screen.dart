import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../core/theme.dart';
import 'checkout_screen.dart';
import 'responsive_layout.dart';
import 'servis_status_screen.dart';
import 'riwayat_screen.dart';
import 'riwayat_tutup_kasir_screen.dart';
import '../providers/shortcut_provider.dart';
import '../widgets/cart_price_override_sheet.dart';

// CONSTANTS

const Color _kBrand = AppColors.primaryBrand;
const Color _kGreen = Color(0xFF2E9D4F);
const String _cashierProductLayoutGridPrefsKey = 'cashier_product_layout_grid';

String _fmtRp(int n) {
  if (n == 0) return 'Rp 0';
  final s = n.toString();
  final buf = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
    buf.write(s[i]);
  }
  return 'Rp $buf';
}

List<Category> _visibleCategoryFilters(List<Category> categories) {
  return categories
      .where((c) => !DBHelper.isDefaultCategoryName(c.name))
      .toList();
}

String _formatQtyDisplay(double qty) {
  return qty
      .toStringAsFixed(2)
      .replaceAll(RegExp(r'0+$'), '')
      .replaceAll(RegExp(r'\.$'), '')
      .replaceAll('.', ',');
}

double _parseQtyInput(String value) {
  return double.tryParse(value.trim().replaceAll(',', '.')) ?? 0;
}

final List<TextInputFormatter> _decimalQtyInputFormatters = [
  FilteringTextInputFormatter.allow(RegExp(r'^\d*[,.]?\d*')),
];

bool _isMeasuredUnit(String unit) {
  final normalized = unit.trim().toLowerCase();
  return {
    'kg',
    'kilogram',
    'gram',
    'gr',
    'g',
    'ml',
    'liter',
    'ltr',
    'l',
    'm2',
    'm²',
    'meter',
    'meter2',
  }.contains(normalized);
}

String _qtyInputLabel(Product product) {
  final unit = product.unit.trim().isEmpty ? 'item' : product.unit.trim();
  if (unit.toLowerCase() == 'kg') return 'Masukkan berat (kg)';
  if (_isMeasuredUnit(unit)) return 'Masukkan jumlah $unit';
  return 'Masukkan jumlah $unit';
}

// SCREEN
class TransaksiScreen extends ConsumerStatefulWidget {
  const TransaksiScreen({super.key});

  @override
  ConsumerState<TransaksiScreen> createState() => _TerimaPengecekananScreenState();
}

class _TerimaPengecekananScreenState extends ConsumerState<TransaksiScreen>
    with TickerProviderStateMixin {
  TabController? _tabController;
  final TextEditingController _searchCtrl = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  String _query = '';
  int _tabCount = 0;
  int _viewIndex = 0; // 0: Cashier, 1: Status, 2: Riwayat
  bool _openingCustomerPicker = false;
  bool _isGridMode = true;

  @override
  void initState() {
    super.initState();
    _loadProductLayoutPreference();
    // Reset customer on entering screen
    Future.microtask(
        () => ref.read(selectedCustomerProvider.notifier).updateState(null));
  }

  @override
  void dispose() {
    _tabController?.dispose();
    _searchCtrl.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  void _buildTabController(int count) {
    if (_tabCount != count) {
      _tabController?.dispose();
      _tabController = TabController(length: count, vsync: this);
      _tabCount = count;
    }
  }

  Future<void> _loadProductLayoutPreference() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _isGridMode = prefs.getBool(_cashierProductLayoutGridPrefsKey) ?? true;
    });
  }

  void _setProductLayoutGrid(bool isGrid) {
    if (_isGridMode == isGrid) return;
    setState(() => _isGridMode = isGrid);
    SharedPreferences.getInstance().then(
      (prefs) => prefs.setBool(_cashierProductLayoutGridPrefsKey, isGrid),
    );
  }

  void _toggleProductLayout() => _setProductLayoutGrid(!_isGridMode);

  //  Customer Picker
  Future<void> _pickCustomer() async {
    if (_openingCustomerPicker) return;
    _openingCustomerPicker = true;

    try {
      await ref.read(customersProvider.notifier).loadCustomers();
      if (!mounted) return;

      final customers = ref.read(customersProvider);
      showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (_) => _CustomerPickerSheet(
          customers: customers,
          onSelected: (customer) {
            if (!mounted) return;
            ref.read(selectedCustomerProvider.notifier).updateState(customer);
          },
        ),
      );
    } finally {
      _openingCustomerPicker = false;
    }
  }

  //  Cart Bottom Sheet
  void _showCart() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _CartSheet(onCheckout: _goCheckout),
    );
  }

  void _goCheckout() {
    final cart = ref.read(cartProvider);
    if (cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Keranjang masih kosong'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
      ));
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const CheckoutScreen(),
      ),
    ).then((_) {
      // Kosongkan cart jika berhasil
      final cartItems = ref.read(cartProvider);
      if (cartItems.isEmpty) {
        ref.read(selectedCustomerProvider.notifier).updateState(null);
      }
    });
  }

  void _showBukaShiftDialog() {
    final activeStaff = ref.read(activeStaffProvider);
    final profile = ref.read(profilProvider);
    final staffId =
        activeStaff != null && activeStaff.id != null && activeStaff.id! > 0
            ? activeStaff.id
            : null;
    final staffName = activeStaff?.name ??
        (profile.nama.trim().isNotEmpty ? profile.nama.trim() : 'Owner');
    final staffRole = activeStaff?.role ?? 'Administrator';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => BukaKasirSheet(
        initialKasirName: staffName,
        onSubmit: (kasirName, openingCash, shiftName) async {
          await ref.read(kasirSessionsProvider.notifier).openSession(
                kasirName: kasirName,
                openingCash: openingCash,
                shiftName: shiftName,
                staffId: staffId,
                staffName: staffName,
                staffRole: staffRole,
              );
          if (!mounted) return;
          Navigator.pop(context);
          ref.invalidate(activeKasirSessionProvider);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Shift berhasil dimulai.'),
              backgroundColor: Colors.black87,
              behavior: SnackBarBehavior.floating,
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final allKategoris = ref.watch(categoriesProvider);
    final kategoris = _visibleCategoryFilters(allKategoris);
    final allLayanan = ref.watch(productsProvider);
    final cart = ref.watch(cartProvider);
    final customer = ref.watch(selectedCustomerProvider);
    ref.watch(hardwarePricingSettingsProvider);
    final cartTotal = ref.watch(cartProvider.notifier).totalBelanja;
    final cartCount = cart.length;
    final activeSessionAsync = ref.watch(activeKasirSessionProvider);

    // Bahan baku adalah item inventori internal, tidak boleh tampil di order.
    final aktifProducts =
        allLayanan.where((p) => p.isExtra == 0 && p.isMaterial == 0).toList();

    // Build tabs: "Semua" + per kategori
    final tabs = <String>[
      'Semua',
      ...kategoris.map((k) => k.name ?? 'Uncategorized')
    ];
    _buildTabController(tabs.length);

    // Listen for category selection from the rail
    ref.listen<int?>(selectedCategoryIdProvider, (prev, next) {
      final isDefaultCategory = allKategoris.any(
        (k) => k.id == next && DBHelper.isDefaultCategoryName(k.name),
      );
      if (next == null || isDefaultCategory) {
        _tabController?.animateTo(0);
      } else {
        final idx = kategoris.indexWhere((k) => k.id == next);
        if (idx != -1) {
          _tabController?.animateTo(idx + 1);
        }
      }
    });

    // Listen for global shortcuts
    ref.listen<ShortcutAction?>(shortcutSignalProvider, (prev, next) {
      if (next == ShortcutAction.checkout && mounted) {
        // Only trigger checkout if TransaksiScreen is the current active route (no dialogs/sheets open)
        if (ModalRoute.of(context)?.isCurrent != true) return;

        ref.read(shortcutSignalProvider.notifier).clear();
        _goCheckout();
      }
    });

    final bool isSessionLoading =
        activeSessionAsync.isLoading || activeSessionAsync.isRefreshing;

    // Strict enforcement: must have a non-null session value to proceed.
    final bool mustBlockShift = activeSessionAsync.when(
      data: (s) => s == null,
      loading: () => false, // handled by isSessionLoading
      error: (_, __) => true, // block on error for safety
    );

    String title = 'Terima Servis';
    if (_viewIndex == 1) title = 'Status Servis';
    if (_viewIndex == 2) title = 'Riwayat Penjualan';

    final transactions = ref.watch(transactionsProvider);
    final activeservisCount = transactions
        .where((tx) => tx.isDeleted == 0 && tx.servisStatus != 'Selesai')
        .length;
    final unpaidSalesCount = transactions
        .where((tx) => tx.isDeleted == 0 && tx.paymentStatus == 'Belum Lunas')
        .length;
    final isTablet = isTabletDevice(context);
    final showMobileServiceTopbar = !isTablet && _viewIndex == 0;
    final showCartPanel = isTablet && _viewIndex == 0;

    final mainViews = IndexedStack(
      index: _viewIndex,
      children: [
        _buildCashierView(
            customer, tabs, aktifProducts, mustBlockShift, kategoris, cart),
        const servisStatusScreen(isEmbedded: true),
        const RiwayatScreen(isEmbedded: true),
      ],
    );

    return KasirResponsiveScaffold(
      title: title,
      titleWidget: showMobileServiceTopbar
          ? Row(
              children: [
                _CashierLayoutSwitch(
                  isGridMode: _isGridMode,
                  onToggleLayout: _toggleProductLayout,
                  compact: true,
                ),
                const SizedBox(width: 8),
                Expanded(child: _buildServiceSearchField(compact: true)),
              ],
            )
          : null,
      showNavRail: true,
      navIndex: 1,
      actions: showMobileServiceTopbar
          ? [
              _buildCustomerAction(customer, compact: true),
              const SizedBox(width: 8),
            ]
          : [
              if (!isTablet && _viewIndex == 0) _buildCustomerAction(customer),
              const SizedBox(width: 16),
            ],
      showAppBar: !isTablet,
      body: isSessionLoading
          ? const Center(child: CircularProgressIndicator(color: _kBrand))
          : isTablet
              ? Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          Expanded(child: mainViews),
                          _DesktopBottomNav(
                            currentIndex: _viewIndex,
                            servisBadge: activeservisCount,
                            historyBadge: unpaidSalesCount,
                            onTabChanged: (idx) =>
                                setState(() => _viewIndex = idx),
                          ),
                        ],
                      ),
                    ),
                    if (showCartPanel) ...[
                      Container(width: 1, color: const Color(0xFFE2E8F0)),
                      SizedBox(
                        width: MediaQuery.of(context).size.width >= 1200
                            ? 380
                            : 340,
                        child: _CartSidePanel(onCheckout: _goCheckout),
                      ),
                    ],
                  ],
                )
              : Column(
                  children: [
                    Expanded(child: mainViews),
                    if (_viewIndex == 0 && cartCount > 0)
                      _CartBar(
                        count: cartCount,
                        total: cartTotal,
                        onTap: _showCart,
                      ),
                  ],
                ),
    );
  }

  Widget _buildCashierView(
      Customer? customer,
      List<String> tabs,
      List<Product> aktifProducts,
      bool mustBlockShift,
      List<Category> kategoris,
      Map<Product, double> cart) {
    return mustBlockShift
        ? _buildShiftBlockedOverlay(context, ref)
        : _buildCashierCatalog(
            tabs, aktifProducts, mustBlockShift, kategoris, customer, cart);
  }

  Widget _buildCashierCatalog(
      List<String> tabs,
      List<Product> aktifProducts,
      bool mustBlockShift,
      List<Category> kategoris,
      Customer? customer,
      Map<Product, double> cart) {
    return Column(
      children: [
        _buildHeader(customer, tabs, aktifProducts, mustBlockShift, cart),
        Expanded(
          child: tabs.isEmpty
              ? const Center(child: CircularProgressIndicator(color: _kBrand))
              : TabBarView(
                  controller: _tabController,
                  children: _buildTabViews(tabs, kategoris, aktifProducts),
                ),
        ),
      ],
    );
  }

  Widget _buildServiceSearchField({bool compact = false}) {
    return SizedBox(
      height: compact ? 42 : 42,
      child: TextField(
        controller: _searchCtrl,
        focusNode: _searchFocusNode,
        cursorOpacityAnimates: false,
        onTapOutside: (_) => _searchFocusNode.unfocus(),
        onChanged: (v) => setState(() => _query = v),
        onSubmitted: (v) {
          _searchFocusNode.unfocus();
          if (v.isEmpty && ref.read(cartProvider).isNotEmpty) {
            _goCheckout();
          }
        },
        textInputAction: TextInputAction.search,
        style: const TextStyle(fontSize: 13, color: Colors.black87),
        decoration: InputDecoration(
          hintText: 'Cari layanan / kode...',
          hintStyle: const TextStyle(fontSize: 13, color: Colors.black38),
          prefixIcon: const Icon(
            Icons.search_rounded,
            size: 18,
            color: Colors.black38,
          ),
          suffixIcon: _query.isEmpty
              ? null
              : IconButton(
                  tooltip: 'Hapus pencarian',
                  icon: const Icon(Icons.close_rounded,
                      size: 18, color: Color(0xFF94A3B8)),
                  onPressed: () {
                    _searchCtrl.clear();
                    setState(() => _query = '');
                  },
                ),
          suffixIconConstraints:
              const BoxConstraints(minWidth: 40, minHeight: 40),
          border: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: Color(0xFFE2E8F0)),
          ),
          enabledBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: Color(0xFFE2E8F0)),
          ),
          focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: _kBrand, width: 1.3),
          ),
          filled: true,
          fillColor: const Color(0xFFF1F5F9),
          contentPadding: const EdgeInsets.symmetric(vertical: 12),
          isDense: true,
        ),
      ),
    );
  }

  Widget _buildCustomerAction(Customer? customer, {bool compact = false}) {
    return Padding(
      padding: EdgeInsets.only(right: compact ? 0 : 16),
      child: GestureDetector(
        onTap: _pickCustomer,
        child: Container(
          height: compact ? 42 : null,
          width: compact ? 48 : null,
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(
            horizontal: compact ? 10 : 14,
            vertical: compact ? 0 : 8,
          ),
          decoration: BoxDecoration(
            color: customer != null ? const Color(0xFFFFD54F) : _kBrand,
            borderRadius: BorderRadius.zero,
            border: Border.all(
              color: customer != null ? const Color(0xFFE0AA00) : _kBrand,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                customer != null
                    ? Icons.person_rounded
                    : Icons.person_add_outlined,
                size: 16,
                color:
                    customer != null ? const Color(0xFF4B3B00) : Colors.white,
              ),
              if (!compact) ...[
                const SizedBox(width: 8),
                Text(
                  customer?.name ?? 'PILIH PELANGGAN',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: customer != null
                        ? const Color(0xFF4B3B00)
                        : Colors.white,
                    letterSpacing: 0.5,
                  ),
                ),
                if (customer != null) ...[
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: () => ref
                        .read(selectedCustomerProvider.notifier)
                        .updateState(null),
                    child: const Icon(
                      Icons.close,
                      size: 16,
                      color: Color(0xFF4B3B00),
                    ),
                  ),
                ],
              ],
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildTabViews(List<String> tabs, List<Category> kategoris,
      List<Product> aktifProducts) {
    final catMap = {for (var k in kategoris) k.name: k.id};
    final qLow = _query.toLowerCase();
    final cart = ref.read(cartProvider);

    return tabs.map((tab) {
      final productList = tab == 'Semua'
          ? aktifProducts
          : aktifProducts.where((l) => l.categoryId == catMap[tab]).toList();
      final filtered = qLow.isEmpty
          ? productList
          : productList
              .where((l) =>
                  l.name.toLowerCase().contains(qLow) ||
                  (l.sku?.toLowerCase().contains(qLow) ?? false) ||
                  (l.barcode?.toLowerCase().contains(qLow) ?? false))
              .toList();
      return _LayananGrid(
        product: filtered,
        cart: cart,
        isGridMode: _isGridMode,
      );
    }).toList();
  }

  Widget _buildHeader(Customer? customer, List<String> tabs,
      List<Product> product, bool isSessionClosed, Map<Product, double> cart) {
    final bool isDesktop = isTabletDevice(context);

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 4,
              offset: const Offset(0, 1))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (isDesktop)
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
              child: Row(
                children: [
                  _CashierLayoutSwitch(
                    isGridMode: _isGridMode,
                    onToggleLayout: _toggleProductLayout,
                  ),
                  const SizedBox(width: 8),
                  Expanded(child: _buildServiceSearchField()),
                  const SizedBox(width: 8),
                  _buildCustomerQuickAction(customer),
                ],
              ),
            ),
          if (!isDesktop && _tabController != null && tabs.isNotEmpty)
            Container(
              decoration: const BoxDecoration(
                border: Border(
                    bottom: BorderSide(color: Color(0xFFE8EDF2), width: 1)),
              ),
              child: TabBar(
                controller: _tabController,
                isScrollable: true,
                tabAlignment: TabAlignment.start,
                indicatorColor: _kBrand,
                indicatorWeight: 2.5,
                indicatorSize: TabBarIndicatorSize.label,
                dividerColor: Colors.transparent,
                labelColor: _kBrand,
                unselectedLabelColor: Colors.black45,
                labelStyle:
                    const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                unselectedLabelStyle:
                    const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
                padding: const EdgeInsets.symmetric(horizontal: 8),
                tabs: tabs.map((t) => Tab(text: t)).toList(),
              ),
            ),
          if (isSessionClosed)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF9C4), // Amber 100
                border: Border(
                  bottom:
                      BorderSide(color: Colors.amber.withValues(alpha: 0.3)),
                ),
              ),
              child: Row(
                children: [
                  const Icon(Icons.warning_amber_rounded,
                      color: Colors.amber, size: 18),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text(
                      'Sesi kasir hari ini belum dibuka. Mohon buka shift terlebih dahulu.',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: Colors.brown,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: _showBukaShiftDialog,
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      minimumSize: Size.zero,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: const Text(
                      'Buka Sesi',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: Colors.amber,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCustomerQuickAction(Customer? customer) {
    final hasCustomer = customer != null;
    return Tooltip(
      message: hasCustomer ? customer.name : 'Pilih Pelanggan',
      child: InkWell(
        onTap: _pickCustomer,
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: hasCustomer
                ? const Color(0xFFFFF7D6)
                : AppColors.primaryBrand.withValues(alpha: 0.08),
            border: Border.all(
              color: hasCustomer
                  ? const Color(0xFFE0AA00)
                  : AppColors.primaryBrand.withValues(alpha: 0.18),
            ),
            borderRadius: BorderRadius.zero,
          ),
          child: Icon(
            hasCustomer ? Icons.person_rounded : Icons.person_add_outlined,
            color:
                hasCustomer ? const Color(0xFF8A5A00) : AppColors.primaryDark,
            size: 20,
          ),
        ),
      ),
    );
  }

  Widget _buildShiftBlockedOverlay(BuildContext context, WidgetRef ref) {
    return Container(
      width: double.infinity,
      color: Colors.white,
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.warning.withValues(alpha: 0.05),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.lock_person_rounded,
              size: 80,
              color: AppColors.warning.withValues(alpha: 0.6),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Shift Operasional Belum Dimulai',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: Color(0xFF1E293B),
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Buka shift terlebih dahulu untuk dapat mengakses katalog layanan dan ke tahap pembayaran.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.black45,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 32),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _showBukaShiftDialog,
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                elevation: 0,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
              child: const Text(
                'Mulai Shift Sekarang',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

//
// LAYANAN GRID
//
class _CashierLayoutSwitch extends StatelessWidget {
  final bool isGridMode;
  final VoidCallback onToggleLayout;
  final bool compact;

  const _CashierLayoutSwitch({
    required this.isGridMode,
    required this.onToggleLayout,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final size = compact ? 32.0 : 36.0;
    final icon =
        isGridMode ? Icons.table_rows_rounded : Icons.grid_view_rounded;
    final tooltip =
        isGridMode ? 'Ubah ke tampilan list' : 'Ubah ke tampilan grid';

    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onToggleLayout,
        borderRadius: BorderRadius.zero,
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: _kBrand,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFD8E5E4)),
          ),
          child: Icon(
            icon,
            size: compact ? 17 : 18,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}

class _LayananGrid extends ConsumerWidget {
  final List<Product> product;
  final Map<Product, double> cart;
  final bool isGridMode;

  const _LayananGrid({
    required this.product,
    required this.cart,
    required this.isGridMode,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (product.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.dry_cleaning_outlined, size: 56, color: Colors.black26),
            SizedBox(height: 12),
            Text('Belum ada layanan',
                style: TextStyle(color: Colors.black38, fontSize: 14)),
          ],
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final availableWidth = constraints.maxWidth;
        final useWideGrid = Platform.isWindows ||
            Platform.isLinux ||
            Platform.isMacOS ||
            isTabletDevice(context);
        if (!isGridMode) {
          final columns = useWideGrid && constraints.maxWidth >= 720 ? 2 : 1;
          final padding = EdgeInsets.fromLTRB(
            12,
            isTabletDevice(context) ? 6 : 10,
            12,
            24,
          );

          Widget itemBuilder(BuildContext context, int i) {
            final item = product[i];
            return _LayananListTile(
              product: item,
              cartItem: cart[item],
            );
          }

          if (columns > 1) {
            return GridView.builder(
              padding: padding,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 6,
                crossAxisSpacing: 8,
                mainAxisExtent: 62,
              ),
              itemCount: product.length,
              itemBuilder: itemBuilder,
            );
          }

          return ListView.separated(
            padding: padding,
            itemCount: product.length,
            separatorBuilder: (_, __) => const SizedBox(height: 6),
            itemBuilder: itemBuilder,
          );
        }

        final columns = useWideGrid ? 4 : 3;
        const horizontalPadding = 12.0;
        final spacing = useWideGrid ? 10.0 : 9.0;
        final cardWidth = (availableWidth -
                (horizontalPadding * 2) -
                (spacing * (columns - 1))) /
            columns;
        final cardHeight = useWideGrid
            ? (cardWidth * 1.34).clamp(226.0, 248.0).toDouble()
            : (cardWidth * 1.68).clamp(210.0, 236.0).toDouble();

        return GridView.builder(
          padding: EdgeInsets.fromLTRB(horizontalPadding,
              isTabletDevice(context) ? 6 : 10, horizontalPadding, 24),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: columns,
            mainAxisSpacing: spacing,
            crossAxisSpacing: spacing,
            mainAxisExtent: cardHeight,
          ),
          itemCount: product.length,
          itemBuilder: (_, i) {
            final item = product[i];
            return _LayananCard(
              product: item,
              cartItem: cart[item],
            );
          },
        );
      },
    );
  }
}

class _LayananListTile extends ConsumerWidget {
  final Product product;
  final double? cartItem;

  const _LayananListTile({
    required this.product,
    this.cartItem,
  });

  bool _checkSession(BuildContext context, WidgetRef ref) {
    final showShift = ref.read(shiftSettingsProvider).enableShift;
    if (!showShift) return true;

    final session = ref.read(activeKasirSessionProvider).value;
    if (session == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Sesi Kasir Belum Dibuka!'),
        backgroundColor: Colors.redAccent,
        behavior: SnackBarBehavior.floating,
      ));
      return false;
    }
    return true;
  }

  void _showOutOfStockSnack(BuildContext context) {
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(
        SnackBar(
          content: Text('${product.name} stoknya habis.'),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  void _incrementItem(BuildContext context, WidgetRef ref) {
    if (!_checkSession(context, ref)) return;
    if (product.tracksInventory && product.isOutOfStock) {
      _showOutOfStockSnack(context);
      return;
    }
    HapticFeedback.selectionClick();
    ref.read(cartProvider.notifier).addItem(product, qty: 1);
    showExtraProductsPickerFor(context, ref, product);
  }

  void _openAddOnPicker(BuildContext context, WidgetRef ref) {
    if (!_checkSession(context, ref)) return;
    if (product.tracksInventory && product.isOutOfStock && cartItem == null) {
      _showOutOfStockSnack(context);
      return;
    }
    if (cartItem == null) {
      if (_isMeasuredUnit(product.unit)) {
        _showQtyInput(context, ref);
        return;
      }
      ref.read(cartProvider.notifier).addItem(product, qty: 1);
    }
    showExtraProductsPickerFor(context, ref, product);
  }

  void _decrementItem(WidgetRef ref) {
    final item = cartItem;
    if (item == null) return;
    HapticFeedback.selectionClick();
    final nextQty = item - 1;
    if (nextQty <= 0) {
      ref.read(cartProvider.notifier).removeItem(product);
      return;
    }
    ref.read(cartProvider.notifier).setQty(product, nextQty);
  }

  void _applyManualQty(
    BuildContext context,
    WidgetRef ref,
    BuildContext dialogContext,
    String value,
  ) {
    final qtyVal = _parseQtyInput(value);
    if (qtyVal <= 0) {
      ref.read(cartProvider.notifier).removeItem(product);
    } else {
      if (product.tracksInventory && product.isOutOfStock && cartItem == null) {
        _showOutOfStockSnack(context);
        Navigator.pop(dialogContext);
        return;
      }
      ref.read(cartProvider.notifier).setQty(product, qtyVal);
    }
    Navigator.pop(dialogContext);
    if (qtyVal > 0) showExtraProductsPickerFor(context, ref, product);
  }

  void _showQtyInput(BuildContext context, WidgetRef ref) {
    if (!_checkSession(context, ref)) return;
    if (product.tracksInventory && product.isOutOfStock && cartItem == null) {
      _showOutOfStockSnack(context);
      return;
    }
    final ctrl = TextEditingController(
      text: cartItem != null ? _formatQtyDisplay(cartItem!) : '',
    );
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: Text(
          product.name,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              _qtyInputLabel(product),
              style: const TextStyle(fontSize: 13, color: Colors.black54),
            ),
            const SizedBox(height: 12),
            KeyboardListener(
              focusNode: FocusNode(),
              onKeyEvent: (event) {
                if (event is KeyDownEvent &&
                    (event.logicalKey == LogicalKeyboardKey.enter ||
                        event.logicalKey == LogicalKeyboardKey.numpadEnter)) {
                  _applyManualQty(context, ref, ctx, ctrl.text);
                }
              },
              child: TextField(
                controller: ctrl,
                autofocus: true,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: _decimalQtyInputFormatters,
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                  suffixText: product.unit,
                  border:
                      const OutlineInputBorder(borderRadius: BorderRadius.zero),
                  focusedBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: _kBrand, width: 1.5),
                  ),
                  hintText: '0',
                ),
                onSubmitted: (v) => _applyManualQty(context, ref, ctx, v),
              ),
            ),
          ],
        ),
        actions: [
          if (cartItem != null)
            TextButton(
              onPressed: () {
                ref.read(cartProvider.notifier).removeItem(product);
                Navigator.pop(ctx);
              },
              child: const Text('Hapus', style: TextStyle(color: Colors.red)),
            ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal', style: TextStyle(color: Colors.black45)),
          ),
          ElevatedButton(
            onPressed: () => _applyManualQty(context, ref, ctx, ctrl.text),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            child: const Text('Terapkan'),
          ),
        ],
      ),
    );
  }

  Widget _qtyControls(BuildContext context, WidgetRef ref) {
    final qty = cartItem ?? 0;
    final isInCart = qty > 0;
    final isOutOfStock = product.tracksInventory && product.isOutOfStock;
    if (!isInCart) {
      return InkWell(
        onTap: isOutOfStock ? null : () => _incrementItem(context, ref),
        borderRadius: BorderRadius.zero,
        child: Container(
          width: 88,
          height: 30,
          alignment: Alignment.center,
          color: isOutOfStock ? const Color(0xFFFFF1F2) : _kBrand,
          child: Text(
            isOutOfStock ? 'Habis' : '+ Tambah',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: isOutOfStock ? const Color(0xFFDC2626) : Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      );
    }

    return Container(
      width: 90,
      height: 30,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFB7D7D5)),
      ),
      child: Row(
        children: [
          _smallQtyButton(Icons.remove_rounded, () => _decrementItem(ref)),
          Expanded(
            child: InkWell(
              onTap: () => _showQtyInput(context, ref),
              borderRadius: BorderRadius.zero,
              child: Center(
                child: Text(
                  _formatQtyDisplay(qty),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF0F172A),
                  ),
                ),
              ),
            ),
          ),
          _smallQtyButton(Icons.add_rounded, () => _incrementItem(context, ref),
              filled: true),
        ],
      ),
    );
  }

  Widget _smallQtyButton(IconData icon, VoidCallback onTap,
      {bool filled = false}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.zero,
      child: Container(
        width: 30,
        height: 30,
        color: _kBrand,
        alignment: Alignment.center,
        child: Icon(
          icon,
          size: 16,
          color: Colors.white,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hasImage =
        product.imagePath != null && File(product.imagePath!).existsSync();
    final unit = product.unit.trim().isEmpty ? 'item' : product.unit.trim();
    final canAddExtras = hasMatchingExtraProducts(ref, product);

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 360;
        final thumbSize = compact ? 32.0 : 34.0;

        return Container(
          padding: EdgeInsets.symmetric(
            horizontal: compact ? 8 : 9,
            vertical: compact ? 4 : 5,
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: thumbSize,
                height: thumbSize,
                color: const Color(0xFFF1F5F9),
                child: hasImage
                    ? Image.file(File(product.imagePath!), fit: BoxFit.cover)
                    : const Icon(
                        Icons.handyman_outlined,
                        size: 17,
                        color: Color(0xFF94A3B8),
                      ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      product.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: compact ? 12.5 : 13,
                        fontWeight: FontWeight.w900,
                        color: const Color(0xFF111827),
                        height: 1.12,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Rp${_fmtRp(product.sellPrice).replaceFirst('Rp ', '')} / $unit',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 10.5,
                        color: Color(0xFF64748B),
                        fontWeight: FontWeight.w700,
                        height: 1.15,
                      ),
                    ),
                    if (canAddExtras) ...[
                      const SizedBox(height: 4),
                      InkWell(
                        onTap: () => _openAddOnPicker(context, ref),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 7, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFEFF6FF),
                            borderRadius: BorderRadius.zero,
                            border: Border.all(
                              color: AppColors.primaryBrand
                                  .withValues(alpha: 0.32),
                            ),
                          ),
                          child: const Text(
                            '+ Add-on',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: AppColors.primaryBrand,
                              fontSize: 10,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 8),
              _qtyControls(context, ref),
            ],
          ),
        );
      },
    );
  }
}

//
// LAYANAN CARD
//
class _LayananCard extends ConsumerWidget {
  final Product product;
  final double? cartItem;

  const _LayananCard({required this.product, this.cartItem});

  void _incrementItem(BuildContext context, WidgetRef ref) {
    if (!_checkSession(context, ref)) return;
    if (product.tracksInventory && product.isOutOfStock) {
      _showOutOfStockSnack(context);
      return;
    }
    HapticFeedback.selectionClick();
    ref.read(cartProvider.notifier).addItem(product, qty: 1);
    _showExtraProductsPicker(context, ref);
  }

  void _openAddOnPicker(
    BuildContext context,
    WidgetRef ref,
    bool isMeasuredUnit,
  ) {
    if (!_checkSession(context, ref)) return;
    if (product.tracksInventory && product.isOutOfStock && cartItem == null) {
      _showOutOfStockSnack(context);
      return;
    }
    if (cartItem == null) {
      if (isMeasuredUnit) {
        _showQtyInput(context, ref);
        return;
      }
      ref.read(cartProvider.notifier).addItem(product, qty: 1);
    }
    _showExtraProductsPicker(context, ref);
  }

  void _decrementItem(WidgetRef ref) {
    final item = cartItem;
    if (item == null) return;
    HapticFeedback.selectionClick();
    final nextQty = item - 1;
    if (nextQty <= 0) {
      ref.read(cartProvider.notifier).removeItem(product);
      return;
    }
    ref.read(cartProvider.notifier).setQty(product, nextQty);
  }

  String _formatQty(double qty) {
    return _formatQtyDisplay(qty);
  }

  void _applyManualQty(
    BuildContext context,
    WidgetRef ref,
    BuildContext dialogContext,
    String value,
  ) {
    final qtyVal = _parseQtyInput(value);
    if (qtyVal <= 0) {
      ref.read(cartProvider.notifier).removeItem(product);
    } else {
      if (product.tracksInventory && product.isOutOfStock && cartItem == null) {
        _showOutOfStockSnack(context);
        Navigator.pop(dialogContext);
        return;
      }
      ref.read(cartProvider.notifier).setQty(product, qtyVal);
    }
    Navigator.pop(dialogContext);
    if (qtyVal > 0) _showExtraProductsPicker(context, ref);
  }

  Widget _buildBottomCounter(
      BuildContext context, WidgetRef ref, bool isInCart) {
    final qtyLabel = cartItem == null ? '0' : _formatQty(cartItem!);
    final isOutOfStock = product.tracksInventory && product.isOutOfStock;

    Widget actionButton({
      required IconData icon,
      required VoidCallback onTap,
      bool enabled = true,
    }) {
      final iconColor = !enabled
          ? const Color(0xFFB8C4D1)
          : (isInCart ? Colors.white : const Color(0xFF0F172A));
      return Expanded(
        child: GestureDetector(
          onTap: enabled ? onTap : null,
          behavior: HitTestBehavior.opaque,
          child: Container(
            height: double.infinity,
            alignment: Alignment.center,
            child: Icon(
              icon,
              size: 17,
              color: iconColor,
            ),
          ),
        ),
      );
    }

    return Container(
      height: 35,
      decoration: BoxDecoration(
        color: isInCart ? AppColors.primaryBrand : Colors.white,
        border: Border.all(
          color: isInCart ? AppColors.primaryBrand : const Color(0xFFD4DEE9),
        ),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        children: [
          actionButton(
            icon: Icons.remove_rounded,
            enabled: isInCart,
            onTap: () => _decrementItem(ref),
          ),
          VerticalDivider(
            width: 1,
            thickness: 1,
            color: isInCart
                ? Colors.white.withValues(alpha: 0.24)
                : const Color(0xFFE7EDF3),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () => _showQtyInput(context, ref),
              behavior: HitTestBehavior.opaque,
              child: Container(
                height: double.infinity,
                alignment: Alignment.center,
                child: Text(
                  qtyLabel,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: isInCart ? Colors.white : const Color(0xFF0F172A),
                  ),
                ),
              ),
            ),
          ),
          VerticalDivider(
            width: 1,
            thickness: 1,
            color: isInCart
                ? Colors.white.withValues(alpha: 0.24)
                : const Color(0xFFE7EDF3),
          ),
          actionButton(
            icon: Icons.add_rounded,
            enabled: !isOutOfStock,
            onTap: () => _incrementItem(context, ref),
          ),
        ],
      ),
    );
  }

  void _showQtyInput(BuildContext context, WidgetRef ref) {
    if (!_checkSession(context, ref)) return;
    if (product.tracksInventory && product.isOutOfStock && cartItem == null) {
      _showOutOfStockSnack(context);
      return;
    }
    final ctrl = TextEditingController(
      text: cartItem != null ? cartItem!.toString() : '',
    );
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: Text(product.name,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              _qtyInputLabel(product),
              style: const TextStyle(fontSize: 13, color: Colors.black54),
            ),
            const SizedBox(height: 12),
            KeyboardListener(
              focusNode: FocusNode(),
              onKeyEvent: (event) {
                if (event is KeyDownEvent &&
                    (event.logicalKey == LogicalKeyboardKey.enter ||
                        event.logicalKey == LogicalKeyboardKey.numpadEnter)) {
                  _applyManualQty(context, ref, ctx, ctrl.text);
                }
              },
              child: TextField(
                controller: ctrl,
                autofocus: true,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: _decimalQtyInputFormatters,
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                  suffixText: product.unit,
                  border:
                      const OutlineInputBorder(borderRadius: BorderRadius.zero),
                  focusedBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: _kBrand, width: 1.5),
                  ),
                  hintText: '0',
                ),
                onSubmitted: (v) => _applyManualQty(context, ref, ctx, v),
              ),
            ),
          ],
        ),
        actions: [
          if (cartItem != null)
            TextButton(
              onPressed: () {
                ref.read(cartProvider.notifier).removeItem(product);
                Navigator.pop(ctx);
              },
              child: const Text('Hapus', style: TextStyle(color: Colors.red)),
            ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal', style: TextStyle(color: Colors.black45)),
          ),
          ElevatedButton(
            onPressed: () => _applyManualQty(context, ref, ctx, ctrl.text),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              elevation: 0,
            ),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isInCart = cartItem != null;
    final isOutOfStock = product.tracksInventory && product.isOutOfStock;
    final software = product.unit.toLowerCase();
    final isMeasuredUnit = _isMeasuredUnit(software);
    final isCompact = MediaQuery.of(context).size.width < 390;
    final iconBox = isCompact ? 38.0 : 42.0;
    final iconSize = isCompact ? 18.0 : 20.0;
    final cardPadding = isCompact ? 9.0 : 10.0;
    final allDiscounts = ref.watch(discountsProvider);
    final hardwareSettings = ref.watch(hardwarePricingSettingsProvider);
    final pricing = CartNotifier.resolveUnitPricing(
      product,
      cartItem ?? 1,
      allDiscounts,
      hardwareSettings: hardwareSettings,
    );
    final hasPromo = pricing.hasPromo;
    final canAddExtras = hasMatchingExtraProducts(ref, product);

    return GestureDetector(
      onTap: () {
        if (isMeasuredUnit) {
          _showQtyInput(context, ref);
          return;
        }
        _incrementItem(context, ref);
      },
      onLongPress: isOutOfStock && !isInCart
          ? () => _showOutOfStockSnack(context)
          : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          color: isOutOfStock && !isInCart
              ? const Color(0xFFFFF7F7)
              : (isInCart ? const Color(0xFFEFF6FF) : Colors.white),
          borderRadius: BorderRadius.zero,
          border: Border.all(
            color: isOutOfStock && !isInCart
                ? AppColors.danger
                : (isInCart ? AppColors.primaryBrand : const Color(0xFFE3E8EF)),
            width: isInCart || (isOutOfStock && !isInCart) ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: isOutOfStock && !isInCart
                  ? AppColors.danger.withValues(alpha: 0.10)
                  : isInCart
                      ? AppColors.primaryBrand.withValues(alpha: 0.18)
                      : Colors.black.withValues(alpha: 0.04),
              blurRadius: isInCart || (isOutOfStock && !isInCart) ? 12 : 6,
              offset:
                  Offset(0, isInCart || (isOutOfStock && !isInCart) ? 4 : 1),
            ),
          ],
        ),
        child: Padding(
          padding: EdgeInsets.all(cardPadding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: iconBox,
                    height: iconBox,
                    decoration: BoxDecoration(
                      color: isOutOfStock && !isInCart
                          ? const Color(0xFFFFE4E6)
                          : (isInCart ? Colors.white : const Color(0xFFF0F4F8)),
                      borderRadius: BorderRadius.zero,
                      border: Border.all(
                        color: isOutOfStock && !isInCart
                            ? AppColors.danger.withValues(alpha: 0.30)
                            : isInCart
                                ? AppColors.primaryBrand.withValues(alpha: 0.22)
                                : const Color(0xFFE2E8F0),
                      ),
                    ),
                    child: (product.imagePath != null &&
                            File(product.imagePath!).existsSync())
                        ? Image.file(
                            File(product.imagePath!),
                            fit: BoxFit.cover,
                          )
                        : Icon(
                            _iconForLayanan(product.name),
                            color: isOutOfStock && !isInCart
                                ? AppColors.danger
                                : isInCart
                                    ? AppColors.primaryBrand
                                    : const Color(0xFF6B7D91),
                            size: iconSize,
                          ),
                  ),
                  const Spacer(),
                  if (isOutOfStock && !isInCart)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 4,
                      ),
                      decoration: const BoxDecoration(
                        color: AppColors.danger,
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Text(
                        'HABIS',
                        style: TextStyle(
                          fontSize: 8,
                          height: 1,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 0,
                        ),
                      ),
                    )
                  else if (isInCart)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 4,
                      ),
                      decoration: const BoxDecoration(
                        color: AppColors.primaryBrand,
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.check_rounded,
                              color: Colors.white, size: 11),
                          SizedBox(width: 3),
                          Text(
                            'DIPILIH',
                            style: TextStyle(
                              fontSize: 8,
                              height: 1,
                              fontWeight: FontWeight.w900,
                              color: Colors.white,
                              letterSpacing: 0,
                            ),
                          ),
                        ],
                      ),
                    )
                  else if (hasPromo)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 4,
                      ),
                      decoration: const BoxDecoration(
                        color: AppColors.primaryBrand,
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Text(
                        'PROMO',
                        style: TextStyle(
                          fontSize: 8,
                          height: 1,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 0,
                        ),
                      ),
                    ),
                ],
              ),
              SizedBox(height: isCompact ? 8 : 10),
              Text(
                product.name,
                style: TextStyle(
                  fontSize: isCompact ? 12.2 : 13,
                  fontWeight: FontWeight.w800,
                  color: const Color(0xFF0F172A),
                  height: 1.25,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 5),
              if (hasPromo) ...[
                Text(
                  '${_fmtRp(pricing.originalUnitPrice)}/$software',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: isCompact ? 10 : 10.4,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF94A3B8),
                    height: 1.15,
                    decoration: TextDecoration.lineThrough,
                  ),
                ),
                const SizedBox(height: 1),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${_fmtRp(pricing.finalUnitPrice)}/$software',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: isCompact ? 10.8 : 11.4,
                          fontWeight: FontWeight.w900,
                          color: AppColors.primaryBrand,
                          height: 1.15,
                        ),
                      ),
                    ),
                    if (isInCart) ...[
                      const SizedBox(width: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 2,
                        ),
                        decoration: const BoxDecoration(
                          color: Color(0xFFEFF6FF),
                          borderRadius: BorderRadius.zero,
                        ),
                        child: const Text(
                          'PROMO',
                          style: TextStyle(
                            color: AppColors.primaryBrand,
                            fontSize: 7.5,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ] else
                Text(
                  '${_fmtRp(product.sellPrice)}/$software',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: isCompact ? 10.8 : 11.4,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF475569),
                    height: 1.25,
                  ),
                ),
              if (product.durationHours > 0) ...[
                const SizedBox(height: 2),
                Text(
                  '~${product.durationHours}j selesai',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: isCompact ? 10.1 : 10.5,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF64748B),
                    height: 1.2,
                  ),
                ),
              ],
              if (isOutOfStock && !isInCart) ...[
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(Icons.block_rounded,
                        size: 12, color: AppColors.danger),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        'Stok habis',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: isCompact ? 10.3 : 10.7,
                          fontWeight: FontWeight.w900,
                          color: AppColors.danger,
                          height: 1.1,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
              if (canAddExtras) ...[
                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity,
                  height: 27,
                  child: OutlinedButton.icon(
                    onPressed: () =>
                        _openAddOnPicker(context, ref, isMeasuredUnit),
                    icon:
                        const Icon(Icons.add_circle_outline_rounded, size: 13),
                    label: const Text(
                      'Add-on',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primaryBrand,
                      side: BorderSide(
                        color: AppColors.primaryBrand.withValues(alpha: 0.42),
                      ),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      padding: const EdgeInsets.symmetric(horizontal: 7),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      textStyle: TextStyle(
                        fontSize: isCompact ? 9.5 : 10.5,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              ],
              const Spacer(),
              _buildBottomCounter(context, ref, isInCart),
            ],
          ),
        ),
      ),
    );
  }

  bool _checkSession(BuildContext context, WidgetRef ref) {
    final showShift = ref.read(shiftSettingsProvider).enableShift;
    if (!showShift) return true;

    final session = ref.read(activeKasirSessionProvider).value;
    if (session == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Sesi Kasir Belum Dibuka!'),
        backgroundColor: Colors.redAccent,
        behavior: SnackBarBehavior.floating,
      ));
      return false;
    }
    return true;
  }

  void _showOutOfStockSnack(BuildContext context) {
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(
        SnackBar(
          content: Text('${product.name} stoknya habis.'),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  IconData _iconForLayanan(String nama) {
    final n = nama.toLowerCase();
    if (n.contains('perbaikan')) return Icons.iron_rounded;
    if (n.contains('sepatu')) return Icons.shopping_bag_outlined;
    if (n.contains('selimut') || n.contains('boneka')) return Icons.bed_rounded;
    if (n.contains('express') || n.contains('kilat')) {
      return Icons.flash_on_rounded;
    }
    return Icons.handyman_rounded;
  }

  void _showExtraProductsPicker(BuildContext context, WidgetRef ref) {
    showExtraProductsPickerFor(context, ref, product);
  }
}

void showExtraProductsPickerFor(
  BuildContext context,
  WidgetRef ref,
  Product product,
) {
  if (product.isExtra == 1) return;
  final allProducts = ref.read(productsProvider);
  final extras = _matchingExtraProducts(product, allProducts);

  if (extras.isEmpty) return;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => _ExtraProductPickerSheet(
      parentProduct: product,
      availableExtras: extras,
    ),
  );
}

bool hasMatchingExtraProducts(WidgetRef ref, Product product) {
  if (product.isExtra == 1) return false;
  return _matchingExtraProducts(product, ref.read(productsProvider)).isNotEmpty;
}

List<Product> _matchingExtraProducts(
    Product parentProduct, List<Product> allProducts) {
  return allProducts.where((ex) {
    if (ex.isExtra != 1) return false;

    final targetCats = _parseTargetIds(ex.extraTargetCategories);
    final targetProds = _parseTargetIds(ex.extraTargetProducts);

    if (targetCats.isEmpty && targetProds.isEmpty) return true;
    if (parentProduct.id != null && targetProds.contains(parentProduct.id)) {
      return true;
    }
    return targetCats.contains(parentProduct.categoryId);
  }).toList()
    ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
}

Set<int> _parseTargetIds(String? raw) {
  if (raw == null || raw.trim().isEmpty) return const {};
  return raw
      .split(',')
      .map((s) => int.tryParse(s.trim()))
      .whereType<int>()
      .toSet();
}

//
// CART BAR (bottom)
//
class _CartBar extends StatelessWidget {
  final int count;
  final int total;
  final VoidCallback onTap;

  const _CartBar(
      {required this.count, required this.total, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.primaryBrand, AppColors.primaryDark],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.zero,
          boxShadow: [
            BoxShadow(
              color: _kBrand.withValues(alpha: 0.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            )
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.2),
                borderRadius: BorderRadius.zero,
              ),
              child: Center(
                child: Text(
                  '$count',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 14),
            const Text(
              'Lihat Keranjang',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5),
            ),
            const Spacer(),
            Text(
              _fmtRp(total),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.5),
            ),
            const SizedBox(width: 6),
            const Icon(Icons.arrow_forward_ios_rounded,
                color: Colors.white, size: 14),
          ],
        ),
      ),
    );
  }
}

class _CartSidePanel extends ConsumerWidget {
  final VoidCallback onCheckout;

  const _CartSidePanel({required this.onCheckout});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cart = ref.watch(cartProvider);
    ref.watch(hardwarePricingSettingsProvider);
    ref.watch(cartPriceOverridesProvider);
    final totalBelanja = ref.watch(cartProvider.notifier).totalBelanja;
    final totalBerat = cart.entries
        .where((e) => e.key.isHardware == 1)
        .fold(0.0, (sum, e) => sum + e.value);

    return Container(
      color: Colors.white,
      child: Column(
        children: [
          Container(
            height: 58,
            padding: const EdgeInsets.symmetric(horizontal: 18),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(bottom: BorderSide(color: Color(0xFFE2E8F0))),
            ),
            child: Row(
              children: [
                const Icon(Icons.shopping_cart_outlined,
                    color: AppColors.primaryDark, size: 23),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'Pesanan Saat Ini',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Color(0xFF0F172A),
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                if (cart.isNotEmpty)
                  TextButton(
                    onPressed: () =>
                        ref.read(cartProvider.notifier).clearCart(),
                    style: TextButton.styleFrom(
                      minimumSize: Size.zero,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 6),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: const Text(
                      'Kosongkan',
                      style: TextStyle(
                        color: AppColors.danger,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: cart.isEmpty
                ? const _CartEmptyState()
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(14, 12, 14, 16),
                    itemCount: cart.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) {
                      final product = cart.keys.elementAt(i);
                      return _CartPanelItem(
                        product: product,
                        qty: cart[product]!,
                      );
                    },
                  ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 14),
            decoration: BoxDecoration(
              color: Colors.white,
              border: const Border(top: BorderSide(color: Color(0xFFE2E8F0))),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 14,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: Column(
                children: [
                  if (totalBerat > 0) ...[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Total Berat',
                            style: TextStyle(
                                color: Color(0xFF64748B), fontSize: 12)),
                        Text(
                          '${totalBerat % 1 == 0 ? totalBerat.toInt() : totalBerat} kg',
                          style: const TextStyle(
                              fontSize: 12, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                  ],
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'TOTAL NOMINAL',
                          style: TextStyle(
                            color: Color(0xFF64748B),
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                      Text(
                        _fmtRp(totalBelanja),
                        style: const TextStyle(
                          color: Color(0xFF0F172A),
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton.icon(
                      onPressed: cart.isEmpty ? null : onCheckout,
                      icon: const Icon(Icons.shopping_cart_checkout_rounded,
                          size: 18),
                      label: const Text(
                        'LANJUT CHECKOUT',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.3,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryBrand,
                        disabledBackgroundColor: const Color(0xFFE5E7EB),
                        foregroundColor: Colors.white,
                        disabledForegroundColor: const Color(0xFF94A3B8),
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CartEmptyState extends StatelessWidget {
  const _CartEmptyState();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.remove_shopping_cart_outlined,
              size: 58, color: Color(0xFFD1D5DB)),
          SizedBox(height: 12),
          Text(
            'Keranjang masih kosong',
            style: TextStyle(
              color: Color(0xFF94A3B8),
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _CartPanelItem extends ConsumerWidget {
  final Product product;
  final double qty;

  const _CartPanelItem({required this.product, required this.qty});

  String _formatQty(double value) {
    return _formatQtyDisplay(value);
  }

  void _showManualQtyInput(BuildContext context, WidgetRef ref) {
    final ctrl = TextEditingController(text: _formatQtyDisplay(qty));
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: Text(product.name, style: const TextStyle(fontSize: 15)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          inputFormatters: _decimalQtyInputFormatters,
          decoration: InputDecoration(
            suffixText: product.unit,
            border: const OutlineInputBorder(borderRadius: BorderRadius.zero),
          ),
          onSubmitted: (_) => _submitManualQty(ctx, ref, ctrl),
        ),
        actions: [
          TextButton(
            onPressed: () {
              ref.read(cartProvider.notifier).removeItem(product);
              Navigator.pop(ctx);
            },
            child: const Text('Hapus', style: TextStyle(color: Colors.red)),
          ),
          ElevatedButton(
            onPressed: () => _submitManualQty(ctx, ref, ctrl),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _submitManualQty(
      BuildContext ctx, WidgetRef ref, TextEditingController ctrl) {
    final qtyVal = _parseQtyInput(ctrl.text);
    if (qtyVal > 0) {
      ref.read(cartProvider.notifier).setQty(product, qtyVal);
    } else {
      ref.read(cartProvider.notifier).removeItem(product);
    }
    Navigator.pop(ctx);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isMeasuredUnit = _isMeasuredUnit(product.unit);
    final allDiscounts = ref.watch(discountsProvider);
    final hardwareSettings = ref.watch(hardwarePricingSettingsProvider);
    final priceOverrides = ref.watch(cartPriceOverridesProvider);
    final overrideUnitPrice =
        product.id == null ? null : priceOverrides[product.id!]?.unitPrice;
    final billableQty = CartNotifier.billableQty(product, qty, hardwareSettings);
    final pricing = CartNotifier.resolveUnitPricing(
      product,
      qty,
      allDiscounts,
      hardwareSettings: hardwareSettings,
      unitPriceOverride: overrideUnitPrice,
    );
    final subtotal = CartNotifier.calculateLineSubtotal(
      product,
      qty,
      allDiscounts,
      hardwareSettings,
      unitPriceOverride: overrideUnitPrice,
    );
    final normalSubtotal = (pricing.originalUnitPrice * billableQty).round();
    final hasPriceOverride = pricing.hasPriceOverride;
    final roundedInfo = hardwareSettings.appliesTo(product) && billableQty != qty
        ? 'Tagih ${_formatQty(billableQty)} kg'
        : null;
    final canAddExtras = hasMatchingExtraProducts(ref, product);

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 38,
                height: 38,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.primaryBrand.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.zero,
                ),
                clipBehavior: Clip.antiAlias,
                child: (product.imagePath != null &&
                        File(product.imagePath!).existsSync())
                    ? Image.file(
                        File(product.imagePath!),
                        width: 38,
                        height: 38,
                        fit: BoxFit.cover,
                      )
                    : const Icon(Icons.handyman_rounded,
                        color: AppColors.primaryBrand, size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      product.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF0F172A),
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        height: 1.2,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      spacing: 6,
                      runSpacing: 3,
                      children: [
                        if (hasPriceOverride)
                          Text(
                            '${_fmtRp(pricing.originalUnitPrice)}/${product.unit}',
                            style: const TextStyle(
                              color: Color(0xFF94A3B8),
                              fontSize: 10.5,
                              fontWeight: FontWeight.w600,
                              decoration: TextDecoration.lineThrough,
                            ),
                          ),
                        Text(
                          '${_fmtRp(pricing.finalUnitPrice)}/${product.unit}',
                          style: TextStyle(
                            color: hasPriceOverride
                                ? const Color(0xFF0F766E)
                                : const Color(0xFF64748B),
                            fontSize: 11,
                            fontWeight: hasPriceOverride
                                ? FontWeight.w900
                                : FontWeight.w600,
                          ),
                        ),
                        if (hasPriceOverride)
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 5, vertical: 2),
                            color: const Color(0xFF0F766E),
                            child: const Text(
                              'NEGO',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 8,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                      ],
                    ),
                    if (roundedInfo != null) ...[
                      const SizedBox(height: 3),
                      Text(
                        roundedInfo,
                        style: const TextStyle(
                          color: AppColors.primaryBrand,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                    if (canAddExtras) ...[
                      const SizedBox(height: 7),
                      OutlinedButton.icon(
                        onPressed: () =>
                            showExtraProductsPickerFor(context, ref, product),
                        icon: const Icon(Icons.add_circle_outline_rounded,
                            size: 14),
                        label: const Text('Tambah Add-on'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.primaryBrand,
                          side: const BorderSide(
                              color: AppColors.primaryBrand, width: 1),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 6),
                          minimumSize: const Size(0, 30),
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          textStyle: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 7),
                    OutlinedButton.icon(
                      onPressed: () => CartPriceOverrideSheet.show(
                        context,
                        product: product,
                        qty: qty,
                      ),
                      icon: const Icon(Icons.price_change_outlined, size: 14),
                      label: const Text('Ubah harga'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: hasPriceOverride
                            ? const Color(0xFF0F766E)
                            : AppColors.primaryBrand,
                        side: BorderSide(
                          color: hasPriceOverride
                              ? const Color(0xFF0F766E)
                              : AppColors.primaryBrand.withValues(alpha: 0.45),
                        ),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 6),
                        minimumSize: const Size(0, 30),
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        textStyle: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  if (hasPriceOverride)
                    Text(
                      _fmtRp(normalSubtotal),
                      style: const TextStyle(
                        color: Color(0xFF94A3B8),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        decoration: TextDecoration.lineThrough,
                      ),
                    ),
                  Text(
                    _fmtRp(subtotal),
                    style: const TextStyle(
                      color: Color(0xFF0F172A),
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (isMeasuredUnit)
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _showManualQtyInput(context, ref),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primaryBrand,
                      side: BorderSide(
                          color:
                              AppColors.primaryBrand.withValues(alpha: 0.45)),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    child: Text(
                      '${_formatQty(qty)} ${product.unit}',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: () =>
                      ref.read(cartProvider.notifier).removeItem(product),
                  icon: const Icon(AppIcons.recycleBin,
                      color: AppColors.danger, size: 20),
                  tooltip: 'Hapus',
                ),
              ],
            )
          else
            Row(
              children: [
                _QtyBtn(
                  icon: Icons.remove,
                  onTap: () {
                    final next = qty - 1;
                    if (next <= 0) {
                      ref.read(cartProvider.notifier).removeItem(product);
                    } else {
                      ref.read(cartProvider.notifier).setQty(product, next);
                    }
                  },
                ),
                Expanded(
                  child: Center(
                    child: Text(
                      _formatQty(qty),
                      style: const TextStyle(
                        color: Color(0xFF0F172A),
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
                _QtyBtn(
                  icon: Icons.add,
                  onTap: () =>
                      ref.read(cartProvider.notifier).setQty(product, qty + 1),
                ),
              ],
            ),
        ],
      ),
    );
  }
}

//
// CART SHEET
//
class _CartSheet extends ConsumerWidget {
  final VoidCallback onCheckout;

  const _CartSheet({required this.onCheckout});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cart = ref.watch(cartProvider);
    ref.watch(cartPriceOverridesProvider);
    final totalBelanja = ref.watch(cartProvider.notifier).totalBelanja;
    final totalBerat = cart.entries
        .where((e) => e.key.isHardware == 1)
        .fold(0.0, (sum, e) => sum + e.value);

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          const SizedBox(height: 12),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.zero,
            ),
          ),
          const SizedBox(height: 16),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                const Text('Keranjang',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const Spacer(),
                TextButton(
                  onPressed: () {
                    ref.read(cartProvider.notifier).clearCart();
                    Navigator.pop(context);
                  },
                  child: const Text('Kosongkan',
                      style: TextStyle(color: Colors.red, fontSize: 13)),
                ),
              ],
            ),
          ),

          const Divider(height: 1, color: Color(0xFFEEEEEE)),

          // Cart Items
          ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.45,
            ),
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(vertical: 8),
              shrinkWrap: true,
              itemCount: cart.length,
              separatorBuilder: (_, __) =>
                  const Divider(height: 1, color: Color(0xFFF5F5F5)),
              itemBuilder: (_, i) {
                final p = cart.keys.elementAt(i);
                final qty = cart[p]!;
                return _CartItemTile(product: p, qty: qty);
              },
            ),
          ),

          const Divider(height: 1, color: Color(0xFFEEEEEE)),

          // Summary
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            child: Column(
              children: [
                if (totalBerat > 0)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Total Berat',
                          style:
                              TextStyle(fontSize: 13, color: Colors.black54)),
                      Text(
                        '${totalBerat % 1 == 0 ? totalBerat.toInt() : totalBerat} kg',
                        style: const TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w500),
                      ),
                    ],
                  ),
                if (totalBerat > 0) const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total Harga',
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w600)),
                    Text(
                      _fmtRp(totalBelanja),
                      style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: _kBrand),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      onCheckout();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      padding: const EdgeInsets.symmetric(vertical: 18),
                    ),
                    child: const Text(
                      'Lanjut ke Checkout',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5),
                    ),
                  ),
                ),
                SizedBox(height: MediaQuery.of(context).viewInsets.bottom + 12),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//
// CART ITEM TILE
//
class _CartItemTile extends ConsumerWidget {
  final Product product;
  final double qty;
  const _CartItemTile({required this.product, required this.qty});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isMeasuredUnit = _isMeasuredUnit(product.unit);
    final allDiscounts = ref.watch(discountsProvider);
    final hardwareSettings = ref.watch(hardwarePricingSettingsProvider);
    final priceOverrides = ref.watch(cartPriceOverridesProvider);
    final overrideUnitPrice =
        product.id == null ? null : priceOverrides[product.id!]?.unitPrice;
    final billableQty = CartNotifier.billableQty(product, qty, hardwareSettings);
    final pricing = CartNotifier.resolveUnitPricing(
      product,
      qty,
      allDiscounts,
      hardwareSettings: hardwareSettings,
      unitPriceOverride: overrideUnitPrice,
    );
    final subtotal = CartNotifier.calculateLineSubtotal(
      product,
      qty,
      allDiscounts,
      hardwareSettings,
      unitPriceOverride: overrideUnitPrice,
    );
    final normalSubtotal = (pricing.originalUnitPrice * billableQty).round();
    final hasPriceOverride = pricing.hasPriceOverride;
    final roundedInfo = hardwareSettings.appliesTo(product) && billableQty != qty
        ? 'Tagih ${_formatQtyDisplay(billableQty)} kg'
        : null;
    final canAddExtras = hasMatchingExtraProducts(ref, product);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Row(
        children: [
          // Icon
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: _kBrand.withValues(alpha: 0.08),
              borderRadius: BorderRadius.zero,
            ),
            clipBehavior: Clip.antiAlias,
            child: (product.imagePath != null &&
                    File(product.imagePath!).existsSync())
                ? Image.file(
                    File(product.imagePath!),
                    width: 40,
                    height: 40,
                    fit: BoxFit.cover,
                  )
                : const Icon(Icons.handyman_rounded,
                    color: _kBrand, size: 20),
          ),
          const SizedBox(width: 12),

          // Name + price
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(product.name,
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w500)),
                Wrap(
                  crossAxisAlignment: WrapCrossAlignment.center,
                  spacing: 6,
                  runSpacing: 3,
                  children: [
                    if (hasPriceOverride)
                      Text(
                        '${_fmtRp(pricing.originalUnitPrice)}/${product.unit}',
                        style: const TextStyle(
                          fontSize: 10.5,
                          color: Colors.black38,
                          decoration: TextDecoration.lineThrough,
                        ),
                      ),
                    Text(
                      '${_fmtRp(pricing.finalUnitPrice)}/${product.unit}',
                      style: TextStyle(
                        fontSize: 11,
                        color: hasPriceOverride
                            ? const Color(0xFF0F766E)
                            : Colors.black45,
                        fontWeight: hasPriceOverride
                            ? FontWeight.w800
                            : FontWeight.w400,
                      ),
                    ),
                    if (hasPriceOverride)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 5, vertical: 2),
                        color: const Color(0xFF0F766E),
                        child: const Text(
                          'NEGO',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                  ],
                ),
                if (roundedInfo != null)
                  Text(
                    roundedInfo,
                    style: const TextStyle(
                      fontSize: 10.5,
                      color: _kBrand,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                if (canAddExtras) ...[
                  const SizedBox(height: 6),
                  InkWell(
                    onTap: () =>
                        showExtraProductsPickerFor(context, ref, product),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 5),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEFF6FF),
                        borderRadius: BorderRadius.zero,
                        border: Border.all(
                          color: AppColors.primaryBrand.withValues(alpha: 0.35),
                        ),
                      ),
                      child: const Text(
                        '+ Tambah Add-on',
                        style: TextStyle(
                          color: AppColors.primaryBrand,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 6),
                InkWell(
                  onTap: () => CartPriceOverrideSheet.show(
                    context,
                    product: product,
                    qty: qty,
                  ),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                    decoration: BoxDecoration(
                      color: hasPriceOverride
                          ? const Color(0xFFE6FFFA)
                          : const Color(0xFFF8FAFC),
                      borderRadius: BorderRadius.zero,
                      border: Border.all(
                        color: hasPriceOverride
                            ? const Color(0xFF0F766E)
                            : const Color(0xFFCBD5E1),
                      ),
                    ),
                    child: Text(
                      'Ubah harga',
                      style: TextStyle(
                        color: hasPriceOverride
                            ? const Color(0xFF0F766E)
                            : const Color(0xFF334155),
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Qty controls
          if (isMeasuredUnit)
            GestureDetector(
              onTap: () {
                final ctrl =
                    TextEditingController(text: _formatQtyDisplay(qty));
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                    title: Text(product.name,
                        style: const TextStyle(fontSize: 15)),
                    content: KeyboardListener(
                      focusNode: FocusNode(),
                      onKeyEvent: (event) {
                        if (event is KeyDownEvent &&
                            (event.logicalKey == LogicalKeyboardKey.enter ||
                                event.logicalKey ==
                                    LogicalKeyboardKey.numpadEnter)) {
                          final qtyVal = _parseQtyInput(ctrl.text);
                          if (qtyVal > 0) {
                            ref
                                .read(cartProvider.notifier)
                                .setQty(product, qtyVal);
                          } else {
                            ref.read(cartProvider.notifier).removeItem(product);
                          }
                          Navigator.pop(ctx);
                        }
                      },
                      child: TextField(
                        controller: ctrl,
                        autofocus: true,
                        keyboardType: const TextInputType.numberWithOptions(
                            decimal: true),
                        inputFormatters: _decimalQtyInputFormatters,
                        textInputAction: TextInputAction.done,
                        decoration: InputDecoration(
                          suffixText: product.unit,
                          border: const OutlineInputBorder(
                              borderRadius: BorderRadius.zero),
                        ),
                        onSubmitted: (v) {
                          final qtyVal = _parseQtyInput(v);
                          if (qtyVal > 0) {
                            ref
                                .read(cartProvider.notifier)
                                .setQty(product, qtyVal);
                          } else {
                            ref.read(cartProvider.notifier).removeItem(product);
                          }
                          Navigator.pop(ctx);
                        },
                      ),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () {
                          ref.read(cartProvider.notifier).removeItem(product);
                          Navigator.pop(ctx);
                        },
                        child: const Text('Hapus',
                            style: TextStyle(color: Colors.red)),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          final qty = _parseQtyInput(ctrl.text);
                          if (qty > 0) {
                            ref
                                .read(cartProvider.notifier)
                                .setQty(product, qty);
                          } else {
                            ref.read(cartProvider.notifier).removeItem(product);
                          }
                          Navigator.pop(ctx);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _kBrand,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                        ),
                        child: const Text('OK'),
                      ),
                    ],
                  ),
                );
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  border: Border.all(color: _kBrand.withValues(alpha: 0.4)),
                  borderRadius: BorderRadius.zero,
                  color: _kBrand.withValues(alpha: 0.06),
                ),
                child: Text(
                  '${_formatQtyDisplay(qty)} ${product.unit}',
                  style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: _kBrand),
                ),
              ),
            )
          else
            Row(
              children: [
                _QtyBtn(
                  icon: Icons.remove,
                  onTap: () {
                    final newQty = qty - 1;
                    if (newQty <= 0) {
                      ref.read(cartProvider.notifier).removeItem(product);
                    } else {
                      ref.read(cartProvider.notifier).setQty(product, newQty);
                    }
                  },
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Text(
                    '${qty.toInt()}',
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                ),
                _QtyBtn(
                  icon: Icons.add,
                  onTap: () {
                    ref.read(cartProvider.notifier).setQty(product, qty + 1);
                  },
                ),
              ],
            ),

          const SizedBox(width: 10),
          // Subtotal
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (hasPriceOverride)
                Text(
                  _fmtRp(normalSubtotal),
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: Colors.black38,
                    decoration: TextDecoration.lineThrough,
                  ),
                ),
              Text(
                _fmtRp(subtotal),
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF1E293B),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _QtyBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _QtyBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: const BoxDecoration(
          color: Color(0xFFF0F4F8),
          borderRadius: BorderRadius.zero,
        ),
        child: Icon(icon, size: 20, color: Colors.black54),
      ),
    );
  }
}

//
// CUSTOMER PICKER SHEET
//
class _CustomerPickerSheet extends StatefulWidget {
  final List<Customer> customers;
  final ValueChanged<Customer?> onSelected;

  const _CustomerPickerSheet({
    required this.customers,
    required this.onSelected,
  });

  @override
  State<_CustomerPickerSheet> createState() => _CustomerPickerSheetState();
}

class _CustomerPickerSheetState extends State<_CustomerPickerSheet> {
  final TextEditingController _searchCtrl = TextEditingController();
  late final List<_CustomerSearchEntry> _searchEntries;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _searchEntries = widget.customers
        .map((c) => _CustomerSearchEntry(
              customer: c,
              searchText: '${c.name} ${c.phone ?? ''}'.toLowerCase(),
            ))
        .toList(growable: false);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _select(Customer? customer) {
    widget.onSelected(customer);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final query = _query.trim().toLowerCase();
    final filtered = query.isEmpty
        ? widget.customers
        : _searchEntries
            .where((entry) => entry.searchText.contains(query))
            .map((entry) => entry.customer)
            .toList(growable: false);

    return Container(
      height: MediaQuery.of(context).size.height * 0.75,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      child: Column(
        children: [
          const SizedBox(height: 12),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.zero,
            ),
          ),
          const SizedBox(height: 16),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Text('Pilih Pelanggan',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _searchCtrl,
              autofocus: false,
              textInputAction: TextInputAction.search,
              onChanged: (v) => setState(() => _query = v),
              onSubmitted: (v) => setState(() => _query = v),
              decoration: const InputDecoration(
                hintText: 'Cari nama / nomor HP...',
                prefixIcon: Icon(Icons.search_rounded, size: 20),
              ),
            ),
          ),
          const SizedBox(height: 8),
          // Pelanggan Umum option
          ListTile(
            leading: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.zero,
              ),
              child: const Icon(Icons.person_outline, color: Colors.black45),
            ),
            title: const Text('Pelanggan Umum',
                style: TextStyle(fontWeight: FontWeight.w500)),
            subtitle: const Text('Tanpa data pelanggan',
                style: TextStyle(fontSize: 12)),
            onTap: () => _select(null),
          ),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          Expanded(
            child: filtered.isEmpty
                ? const Center(
                    child: Text('Tidak ada pelanggan',
                        style: TextStyle(color: Colors.black38)))
                : ListView.separated(
                    keyboardDismissBehavior:
                        ScrollViewKeyboardDismissBehavior.onDrag,
                    cacheExtent: 640,
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) =>
                        const Divider(height: 1, color: Color(0xFFF5F5F5)),
                    itemBuilder: (_, i) {
                      final c = filtered[i];
                      return ListTile(
                        leading: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: _kBrand.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: Center(
                            child: Text(
                              c.name.isNotEmpty ? c.name[0].toUpperCase() : '?',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                color: _kBrand,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                        title: Text(c.name,
                            style: const TextStyle(
                                fontWeight: FontWeight.w500, fontSize: 14)),
                        subtitle: c.phone != null
                            ? Text(c.phone!,
                                style: const TextStyle(fontSize: 12))
                            : null,
                        trailing: c.discountPct > 0
                            ? Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: _kGreen.withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.zero,
                                ),
                                child: Text(
                                  'Diskon ${c.discountPct.toInt()}%',
                                  style: const TextStyle(
                                      fontSize: 11,
                                      color: _kGreen,
                                      fontWeight: FontWeight.w600),
                                ),
                              )
                            : null,
                        onTap: () => _select(c),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _CustomerSearchEntry {
  final Customer customer;
  final String searchText;

  const _CustomerSearchEntry({
    required this.customer,
    required this.searchText,
  });
}

class _ExtraProductPickerSheet extends ConsumerWidget {
  final Product parentProduct;
  final List<Product> availableExtras;

  const _ExtraProductPickerSheet({
    required this.parentProduct,
    required this.availableExtras,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final filteredExtras = availableExtras;

    if (filteredExtras.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      padding: EdgeInsets.fromLTRB(
          20, 20, 20, MediaQuery.of(context).padding.bottom + 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.add_circle_outline_rounded,
                  color: AppColors.primaryBrand, size: 24),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Layanan Tambahan',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    Text('Pilih tambahan untuk ${parentProduct.name}',
                        style: const TextStyle(
                            fontSize: 12, color: Colors.black45)),
                  ],
                ),
              ),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close_rounded),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Flexible(
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: filteredExtras.length,
              separatorBuilder: (_, __) =>
                  const Divider(height: 1, color: Color(0xFFF5F5F5)),
              itemBuilder: (ctx, i) {
                final ex = filteredExtras[i];
                final cart = ref.watch(cartProvider);
                final isInCart = cart.containsKey(ex);

                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(ex.name,
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w500)),
                  subtitle: Text(
                      'Rp ${ex.sellPrice.toString().replaceAllMapped(RegExp(r"(\d{1,3})(?=(\d{3})+(?!\d))"), (Match m) => "${m[1]}.")}',
                      style: const TextStyle(
                          fontSize: 12, color: AppColors.primaryBrand)),
                  trailing: isInCart
                      ? IconButton(
                          icon: const Icon(Icons.check_circle_rounded,
                              color: AppColors.primaryBrand),
                          onPressed: () =>
                              ref.read(cartProvider.notifier).removeItem(ex),
                        )
                      : OutlinedButton(
                          onPressed: () {
                            ref.read(cartProvider.notifier).addItem(ex, qty: 1);
                          },
                          style: OutlinedButton.styleFrom(
                            side:
                                const BorderSide(color: AppColors.primaryBrand),
                            foregroundColor: AppColors.primaryBrand,
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                          ),
                          child: const Text('Tambah',
                              style: TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.bold)),
                        ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBrand,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
              child: const Text('Selesai',
                  style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }
}

class _DesktopBottomNav extends StatelessWidget {
  final int currentIndex;
  final int servisBadge;
  final int historyBadge;
  final Function(int) onTabChanged;

  const _DesktopBottomNav({
    required this.currentIndex,
    required this.servisBadge,
    required this.historyBadge,
    required this.onTabChanged,
  });

  @override
  Widget build(BuildContext context) {
    final bool inStatusView = currentIndex == 1;
    final bool inHistoryView = currentIndex == 2;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: const BoxDecoration(
        color: AppColors.primaryDark,
        border: Border(top: BorderSide(color: Colors.white12)),
      ),
      child: Row(
        children: [
          Expanded(
            child: _NavButton(
              icon: inStatusView
                  ? Icons.arrow_back_rounded
                  : Icons.handyman_rounded,
              label: inStatusView ? 'Kembali ke Kasir' : 'Status Servis',
              isSelected: inStatusView,
              badgeCount: inStatusView ? 0 : servisBadge,
              onTap: () => onTabChanged(inStatusView ? 0 : 1),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _NavButton(
              icon: inHistoryView
                  ? Icons.arrow_back_rounded
                  : Icons.history_rounded,
              label: inHistoryView ? 'Kembali ke Kasir' : 'Riwayat Penjualan',
              isSelected: inHistoryView,
              badgeCount: inHistoryView ? 0 : historyBadge,
              onTap: () => onTabChanged(inHistoryView ? 0 : 2),
            ),
          ),
        ],
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final int badgeCount;
  final VoidCallback onTap;

  const _NavButton({
    required this.icon,
    required this.label,
    required this.isSelected,
    this.badgeCount = 0,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isReturnToKasir = label.toLowerCase() == 'kembali ke kasir';
    final color = isReturnToKasir
        ? const Color(0xFF78350F)
        : (isSelected ? Colors.white : Colors.white70);
    final backgroundColor = isReturnToKasir
        ? const Color(0xFFFBBF24)
        : isSelected
            ? Colors.white.withValues(alpha: 0.15)
            : Colors.transparent;
    final borderColor = isReturnToKasir
        ? const Color(0xFFF59E0B)
        : isSelected
            ? Colors.white30
            : Colors.transparent;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.zero,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: backgroundColor,
            border: Border.all(color: borderColor),
            borderRadius: BorderRadius.zero,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 22),
              const SizedBox(width: 10),
              Text(
                label.toUpperCase(),
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w800,
                  fontSize: 14,
                  letterSpacing: 0.5,
                ),
              ),
              if (badgeCount > 0) ...[
                const SizedBox(width: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.redAccent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    badgeCount.toString(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

