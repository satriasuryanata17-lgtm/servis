import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/finance_category_ui.dart';
import '../core/theme.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import 'responsive_layout.dart';

const Color _kBrand = AppColors.primaryBrand;
const Color _kSystemBadge = Color(0xFF3A7D7C);
const Color _kCustomBadge = Color(0xFF64748B);

final appStringsProvider = Provider<_FinanceCategoryStrings>(
  (ref) => const _FinanceCategoryStrings(),
);

class _FinanceCategoryStrings {
  const _FinanceCategoryStrings();

  String ui(String value) => value;
}

class KategoriKeuanganScreen extends ConsumerStatefulWidget {
  const KategoriKeuanganScreen({super.key});

  @override
  ConsumerState<KategoriKeuanganScreen> createState() =>
      _KategoriKeuanganScreenState();
}

class _KategoriKeuanganScreenState
    extends ConsumerState<KategoriKeuanganScreen> {
  String _type = 'keluar';
  bool _showInactive = false;

  @override
  Widget build(BuildContext context) {
    final strings = ref.watch(appStringsProvider);
    final categories = ref.watch(financeCategoriesProvider);
    final visible = categories
        .where((category) =>
            category.type == _type &&
            isManualFinanceCategory(category) &&
            (_showInactive || category.active))
        .toList()
      ..sort((a, b) {
        final activeCompare = b.isActive.compareTo(a.isActive);
        if (activeCompare != 0) return activeCompare;
        final sortCompare = a.sortOrder.compareTo(b.sortOrder);
        if (sortCompare != 0) return sortCompare;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

    return KasirResponsiveScaffold(
      title: strings.ui('Kategori Keuangan'),
      showNavRail: false,
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1040),
                child: Column(
                  children: [
                    _HeaderPanel(
                      type: _type,
                      showInactive: _showInactive,
                      categories: categories,
                      onTypeChanged: (value) => setState(() => _type = value),
                      onShowInactiveChanged: (value) =>
                          setState(() => _showInactive = value),
                    ),
                    Expanded(
                      child: categories.isEmpty
                          ? const Center(
                              child: CircularProgressIndicator(
                                color: _kBrand,
                                strokeWidth: 2,
                              ),
                            )
                          : visible.isEmpty
                              ? _EmptyFinanceCategoryView(type: _type)
                              : LayoutBuilder(
                                  builder: (context, constraints) {
                                    final useGrid = constraints.maxWidth >= 760;
                                    Widget itemBuilder(
                                      BuildContext context,
                                      int index,
                                    ) {
                                      final category = visible[index];
                                      return _FinanceCategoryRow(
                                        category: category,
                                        onEdit: category.system
                                            ? null
                                            : () => _showCategoryForm(category),
                                        onToggleActive: category.system
                                            ? null
                                            : () => _toggleActive(category),
                                      );
                                    }

                                    if (!useGrid) {
                                      return ListView.separated(
                                        padding: const EdgeInsets.fromLTRB(
                                          20,
                                          4,
                                          20,
                                          96,
                                        ),
                                        itemCount: visible.length,
                                        separatorBuilder: (_, __) =>
                                            const SizedBox(height: 10),
                                        itemBuilder: itemBuilder,
                                      );
                                    }

                                    return GridView.builder(
                                      padding: const EdgeInsets.fromLTRB(
                                        20,
                                        4,
                                        20,
                                        96,
                                      ),
                                      itemCount: visible.length,
                                      gridDelegate:
                                          const SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 2,
                                        mainAxisSpacing: 10,
                                        crossAxisSpacing: 10,
                                        mainAxisExtent: 62,
                                      ),
                                      itemBuilder: itemBuilder,
                                    );
                                  },
                                ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _BottomAddBar(
        label: strings.ui(_type == 'masuk'
            ? 'Tambah Kategori Pemasukan'
            : 'Tambah Kategori Pengeluaran'),
        onPressed: () => _showCategoryForm(null),
      ),
    );
  }

  Future<void> _toggleActive(FinanceCategory category) async {
    final strings = ref.read(appStringsProvider);
    try {
      await ref
          .read(financeCategoriesProvider.notifier)
          .setActive(category, !category.active);
      if (mounted) {
        _snack(strings.ui(category.active
            ? 'Kategori dinonaktifkan'
            : 'Kategori diaktifkan kembali'));
      }
    } catch (_) {
      if (mounted) {
        _snack(strings.ui('Kategori tidak bisa diubah. Silakan coba lagi.'));
      }
    }
  }

  Future<void> _showCategoryForm(FinanceCategory? category) async {
    await showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (_) => _FinanceCategoryFormDialog(
        type: _type,
        category: category,
      ),
    );
  }

  void _snack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message),
      backgroundColor: Colors.black87,
      behavior: SnackBarBehavior.floating,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    ));
  }
}

class _FinanceCategoryFormDialog extends ConsumerStatefulWidget {
  final String type;
  final FinanceCategory? category;

  const _FinanceCategoryFormDialog({
    required this.type,
    required this.category,
  });

  @override
  ConsumerState<_FinanceCategoryFormDialog> createState() =>
      _FinanceCategoryFormDialogState();
}

class _FinanceCategoryFormDialogState
    extends ConsumerState<_FinanceCategoryFormDialog> {
  late final TextEditingController _controller;
  String? _errorText;
  bool _saving = false;

  bool get _isEdit => widget.category != null;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.category?.name ?? '');
  }

  @override
  void dispose() {
    FocusManager.instance.primaryFocus?.unfocus();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_saving) return;

    final strings = ref.read(appStringsProvider);
    final name = _controller.text.trim();
    if (name.isEmpty) {
      setState(() => _errorText = strings.ui('Nama kategori wajib diisi.'));
      return;
    }

    setState(() {
      _saving = true;
      _errorText = null;
    });

    try {
      if (_isEdit) {
        final now = DateTime.now().toIso8601String();
        await ref.read(financeCategoriesProvider.notifier).updateCategory(
              widget.category!.copyWith(
                name: name,
                updatedAt: now,
              ),
            );
      } else {
        await ref.read(financeCategoriesProvider.notifier).addCategory(
              name: name,
              type: widget.type,
              iconKey: defaultFinanceIconKey(widget.type),
              colorHex: defaultFinanceColorHex(widget.type),
            );
      }

      if (mounted) Navigator.of(context).pop();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _errorText = strings.ui('Kategori sudah ada atau tidak bisa disimpan.');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final strings = ref.watch(appStringsProvider);
    final media = MediaQuery.of(context);
    final maxDialogHeight = (media.size.height -
            media.viewInsets.bottom -
            media.padding.top -
            media.padding.bottom -
            48)
        .clamp(220.0, media.size.height);

    return Dialog(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      backgroundColor: Colors.white,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: 520,
          maxHeight: maxDialogHeight,
        ),
        child: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          child: Padding(
            padding: EdgeInsets.fromLTRB(
              22,
              22,
              22,
              18 + media.padding.bottom,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        strings.ui(_isEdit
                            ? 'Edit Kategori'
                            : 'Tambah Kategori Keuangan'),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textTitle,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: strings.ui('Batal'),
                      onPressed: _saving
                          ? null
                          : () => Navigator.of(context).maybePop(),
                      icon: const Icon(Icons.close_rounded, size: 22),
                      color: AppColors.textCaption,
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _controller,
                  autofocus: true,
                  enabled: !_saving,
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) => _save(),
                  decoration: _inputDecoration(
                    strings.ui('Nama kategori'),
                    hint: widget.type == 'masuk'
                        ? strings.ui(
                            'Contoh: Pemasukan jasa, komisi, modal tambahan')
                        : strings.ui('Contoh: Utilitas, perlengkapan, pajak'),
                  ).copyWith(errorText: _errorText),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 48,
                        child: OutlinedButton(
                          onPressed: _saving
                              ? null
                              : () => Navigator.of(context).maybePop(),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppColors.textBody,
                            side: const BorderSide(
                              color: Color(0xFFE2E8F0),
                            ),
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                            ),
                          ),
                          child: Text(
                            strings.ui('Batal'),
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: SizedBox(
                        height: 48,
                        child: ElevatedButton(
                          onPressed: _saving ? null : _save,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _kBrand,
                            foregroundColor: Colors.white,
                            disabledBackgroundColor:
                                _kBrand.withValues(alpha: 0.45),
                            elevation: 0,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero,
                            ),
                          ),
                          child: Text(
                            _saving
                                ? strings.ui('Menyimpan...')
                                : strings.ui(_isEdit
                                    ? 'Simpan Perubahan'
                                    : 'Simpan Kategori'),
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _HeaderPanel extends ConsumerWidget {
  final String type;
  final bool showInactive;
  final List<FinanceCategory> categories;
  final ValueChanged<String> onTypeChanged;
  final ValueChanged<bool> onShowInactiveChanged;

  const _HeaderPanel({
    required this.type,
    required this.showInactive,
    required this.categories,
    required this.onTypeChanged,
    required this.onShowInactiveChanged,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = ref.watch(appStringsProvider);
    final activeCount = categories
        .where((category) =>
            category.type == type &&
            category.active &&
            isManualFinanceCategory(category))
        .length;
    final inactiveCount = categories
        .where((category) =>
            category.type == type &&
            !category.active &&
            isManualFinanceCategory(category))
        .length;

    return Container(
      margin: const EdgeInsets.fromLTRB(20, 18, 20, 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _TypeSegment(
                label: strings.ui('Pengeluaran'),
                active: type == 'keluar',
                onTap: () => onTypeChanged('keluar'),
              ),
              const SizedBox(width: 8),
              _TypeSegment(
                label: strings.ui('Pemasukan'),
                active: type == 'masuk',
                onTap: () => onTypeChanged('masuk'),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: Text(
                  strings.ui(type == 'keluar'
                      ? 'Kategori untuk mencatat biaya usaha dan laporan pengeluaran.'
                      : 'Kategori untuk pemasukan non-penjualan dan catatan kas masuk.'),
                  style: const TextStyle(
                    fontSize: 12.5,
                    height: 1.35,
                    color: AppColors.textBody,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Text(
                strings.ui('{count} aktif').replaceFirst(
                      '{count}',
                      activeCount.toString(),
                    ),
                style: const TextStyle(
                  fontSize: 12,
                  color: _kBrand,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          if (inactiveCount > 0) ...[
            const SizedBox(height: 10),
            InkWell(
              onTap: () => onShowInactiveChanged(!showInactive),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    showInactive
                        ? Icons.check_box_outlined
                        : Icons.check_box_outline_blank_rounded,
                    size: 18,
                    color: _kBrand,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    strings.ui('Tampilkan kategori nonaktif'),
                    style: const TextStyle(
                      fontSize: 12.5,
                      color: AppColors.textBody,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _TypeSegment extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _TypeSegment({
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Container(
          height: 44,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: active ? _kBrand : const Color(0xFFF8FAFC),
            border: Border.all(
              color: active ? _kBrand : const Color(0xFFE2E8F0),
            ),
            borderRadius: BorderRadius.zero,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: active ? Colors.white : AppColors.textTitle,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FinanceCategoryRow extends ConsumerWidget {
  final FinanceCategory category;
  final VoidCallback? onEdit;
  final VoidCallback? onToggleActive;

  const _FinanceCategoryRow({
    required this.category,
    required this.onEdit,
    required this.onToggleActive,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = ref.watch(appStringsProvider);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: category.active ? Colors.white : const Color(0xFFF8FAFC),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    strings.ui(category.name),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w800,
                      color: category.active
                          ? AppColors.textTitle
                          : AppColors.textCaption,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                _MiniBadge(
                  text: strings.ui(category.system ? 'Sistem' : 'Custom'),
                  color: category.system ? _kSystemBadge : _kCustomBadge,
                ),
                if (!category.active) ...[
                  const SizedBox(width: 6),
                  _MiniBadge(
                    text: strings.ui('Nonaktif'),
                    color: AppColors.textCaption,
                  ),
                ],
              ],
            ),
          ),
          if (onEdit != null)
            IconButton(
              tooltip: strings.ui('Ubah'),
              onPressed: onEdit,
              icon: const Icon(Icons.edit_outlined, size: 20),
              color: _kBrand,
            ),
          if (onToggleActive != null)
            IconButton(
              tooltip: strings.ui(category.active ? 'Nonaktifkan' : 'Aktifkan'),
              onPressed: onToggleActive,
              icon: Icon(
                category.active
                    ? Icons.visibility_off_outlined
                    : Icons.visibility_outlined,
                size: 20,
              ),
              color: category.active ? AppColors.danger : _kBrand,
            ),
        ],
      ),
    );
  }
}

class _MiniBadge extends StatelessWidget {
  final String text;
  final Color color;

  const _MiniBadge({required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.zero,
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 10.5,
          color: color,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _BottomAddBar extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;

  const _BottomAddBar({required this.label, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.fromLTRB(
        20,
        10,
        20,
        12 + MediaQuery.paddingOf(context).bottom,
      ),
      child: SizedBox(
        height: 52,
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: onPressed,
          icon: const Icon(Icons.add_rounded, size: 20),
          label: Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: _kBrand,
            foregroundColor: Colors.white,
            elevation: 0,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        ),
      ),
    );
  }
}

class _EmptyFinanceCategoryView extends ConsumerWidget {
  final String type;

  const _EmptyFinanceCategoryView({required this.type});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final strings = ref.watch(appStringsProvider);
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.category_outlined,
              size: 46, color: AppColors.textCaption),
          const SizedBox(height: 12),
          Text(
            strings.ui(type == 'masuk'
                ? 'Belum ada kategori pemasukan aktif'
                : 'Belum ada kategori pengeluaran aktif'),
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w800,
              color: AppColors.textTitle,
            ),
          ),
        ],
      ),
    );
  }
}

InputDecoration _inputDecoration(String label, {String? hint}) {
  return InputDecoration(
    labelText: label,
    hintText: hint,
    filled: true,
    fillColor: const Color(0xFFF8FAFC),
    border: const OutlineInputBorder(
      borderRadius: BorderRadius.zero,
      borderSide: BorderSide(color: Color(0xFFE2E8F0)),
    ),
    enabledBorder: const OutlineInputBorder(
      borderRadius: BorderRadius.zero,
      borderSide: BorderSide(color: Color(0xFFE2E8F0)),
    ),
    focusedBorder: const OutlineInputBorder(
      borderRadius: BorderRadius.zero,
      borderSide: BorderSide(color: _kBrand, width: 2),
    ),
  );
}

