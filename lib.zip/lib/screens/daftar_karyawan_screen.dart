import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:google_fonts/google_fonts.dart';
import '../services/auth_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../widgets/kasir_dialog.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';
import '../utils/staff_access.dart';

const Color _kBrand = AppColors.primaryBrand;
final Color _kBrandLight = AppColors.primaryBrand.withValues(alpha: 0.08);
const Color _kBg = Color(0xFFF6F7F9);

class DaftarKaryawanScreen extends ConsumerStatefulWidget {
  const DaftarKaryawanScreen({super.key});

  @override
  ConsumerState<DaftarKaryawanScreen> createState() =>
      _DaftarKaryawanScreenState();
}

class _DaftarKaryawanScreenState extends ConsumerState<DaftarKaryawanScreen> {
  final _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  List<Employee> _filter(List<Employee> employees) {
    if (_query.isEmpty) return employees;
    final q = _query.toLowerCase();
    return employees.where((e) {
      return e.name.toLowerCase().contains(q) ||
          e.role.toLowerCase().contains(q) ||
          (e.phone?.toLowerCase().contains(q) ?? false);
    }).toList();
  }

  Future<void> _showForm({Employee? existing}) async {
    final formKey = GlobalKey<FormState>();
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final roleCtrl = TextEditingController(text: existing?.role ?? 'Kasir');
    final phoneCtrl = TextEditingController(text: existing?.phone ?? '');
    final pinCtrl = TextEditingController();
    var useDefaultPermissions =
        existing == null || StaffAccess.usesDefaultPermissions(existing);
    final selectedPermissions = <String>{
      ...((existing == null || useDefaultPermissions)
          ? StaffAccess.defaultEmployeePermissions
          : StaffAccess.parsePermissions(existing.permissionsJson) ??
              StaffAccess.defaultEmployeePermissions),
    };

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 8,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.zero,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(9),
                        decoration: BoxDecoration(
                          color: _kBrandLight,
                          borderRadius: BorderRadius.zero,
                        ),
                        child: const Icon(Icons.badge_outlined,
                            color: _kBrand, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        existing == null ? 'Tambah Karyawan' : 'Ubah Karyawan',
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    controller: nameCtrl,
                    textInputAction: TextInputAction.next,
                    decoration: _inputDeco(
                        'Nama Karyawan', Icons.person_outline_rounded),
                    validator: (v) => (v == null || v.trim().isEmpty)
                        ? 'Nama wajib diisi'
                        : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: roleCtrl,
                    textInputAction: TextInputAction.next,
                    decoration: _inputDeco('Jabatan / Role (cth: Kasir)',
                        Icons.work_outline_rounded),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: phoneCtrl,
                    keyboardType: TextInputType.phone,
                    textInputAction: TextInputAction.next,
                    decoration: _inputDeco(
                        'Nomor Telepon (opsional)', Icons.phone_outlined),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: pinCtrl,
                    keyboardType: TextInputType.number,
                    obscureText: true,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    maxLength: 6,
                    decoration: _inputDeco(
                      existing == null ? 'PIN Login' : 'PIN Login (opsional)',
                      Icons.lock_outline_rounded,
                    ),
                    validator: (v) {
                      final text = v?.trim() ?? '';
                      if (existing == null && text.isEmpty) {
                        return 'PIN Login wajib diisi';
                      }
                      if (text.isNotEmpty && text.length != 6) {
                        return 'PIN harus 6 digit';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 8),
                  _buildPermissionEditor(
                    useDefault: useDefaultPermissions,
                    selected: selectedPermissions,
                    onUseDefaultChanged: (value) {
                      setSheetState(() {
                        useDefaultPermissions = value;
                        if (value) {
                          selectedPermissions
                            ..clear()
                            ..addAll(StaffAccess.defaultEmployeePermissions);
                        }
                      });
                    },
                    onTogglePermission: (key, value) {
                      setSheetState(() {
                        useDefaultPermissions = false;
                        if (value) {
                          selectedPermissions.add(key);
                        } else {
                          selectedPermissions.remove(key);
                        }
                      });
                    },
                    onSelectAll: () {
                      setSheetState(() {
                        useDefaultPermissions = false;
                        selectedPermissions
                          ..clear()
                          ..addAll(StaffAccess.fullPermissions);
                      });
                    },
                    onResetDefault: () {
                      setSheetState(() {
                        useDefaultPermissions = true;
                        selectedPermissions
                          ..clear()
                          ..addAll(StaffAccess.defaultEmployeePermissions);
                      });
                    },
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () async {
                        if (!formKey.currentState!.validate()) return;
                        final data = Employee(
                          id: existing?.id,
                          name: nameCtrl.text.trim(),
                          role: roleCtrl.text.trim().isEmpty
                              ? 'Kasir'
                              : roleCtrl.text.trim(),
                          phone: phoneCtrl.text.trim().isEmpty
                              ? null
                              : phoneCtrl.text.trim(),
                          pin: pinCtrl.text.trim().isEmpty
                              ? existing?.pin
                              : AuthService.hashPin(pinCtrl.text.trim()),
                          permissionsJson: useDefaultPermissions
                              ? null
                              : StaffAccess.encodePermissions(
                                  selectedPermissions,
                                ),
                          createdAt: existing?.createdAt ??
                              DateTime.now().toIso8601String(),
                          isActive: existing?.isActive ?? 1,
                        );
                        if (existing == null) {
                          await ref
                              .read(employeesProvider.notifier)
                              .addEmployee(data);
                        } else {
                          await ref
                              .read(employeesProvider.notifier)
                              .updateEmployee(data);
                          final activeStaff = ref.read(activeStaffProvider);
                          if (activeStaff?.id == data.id) {
                            await ref
                                .read(activeStaffProvider.notifier)
                                .set(data);
                          }
                        }
                        if (!ctx.mounted) return;
                        Navigator.pop(ctx);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: const Text('Simpan',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w600)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPermissionEditor({
    required bool useDefault,
    required Set<String> selected,
    required ValueChanged<bool> onUseDefaultChanged,
    required void Function(String key, bool value) onTogglePermission,
    required VoidCallback onSelectAll,
    required VoidCallback onResetDefault,
  }) {
    final groups = <String, List<StaffPermissionSpec>>{};
    for (final spec in StaffAccess.specs) {
      groups.putIfAbsent(spec.group, () => []).add(spec);
    }

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
            child: Row(
              children: [
                const Icon(Icons.admin_panel_settings_outlined,
                    size: 18, color: _kBrand),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text(
                    'Hak Akses Karyawan',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF0F172A),
                    ),
                  ),
                ),
                OutlinedButton.icon(
                  onPressed: onSelectAll,
                  icon: const Icon(Icons.lock_open_rounded, size: 14),
                  label: const Text('Full akses'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(0, 32),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    foregroundColor: _kBrand,
                    backgroundColor: _kBrand.withValues(alpha: 0.06),
                    side: BorderSide(color: _kBrand.withValues(alpha: 0.45)),
                    textStyle: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(
              useDefault
                  ? 'Mengikuti aturan default kasir servis. Fitur tertentu tetap dikunci sesuai kebijakan aplikasi.'
                  : 'Akses khusus aktif. Atur fitur mana saja yang boleh dipakai karyawan ini.',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11,
                height: 1.35,
                fontWeight: FontWeight.w700,
                color: const Color(0xFF64748B),
              ),
            ),
          ),
          SwitchListTile(
            value: useDefault,
            onChanged: onUseDefaultChanged,
            dense: true,
            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            activeThumbColor: _kBrand,
            title: const Text(
              'Pakai aturan default',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5),
            ),
            subtitle: const Text(
              'Akses dasar: Dashboard, Order, Status, Riwayat, Pelanggan, Notifikasi, Scanner.',
              style: TextStyle(fontSize: 10.5),
            ),
          ),
          const Divider(height: 1, color: Color(0xFFE2E8F0)),
          if (!useDefault) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  OutlinedButton.icon(
                    onPressed: onResetDefault,
                    icon: const Icon(Icons.restart_alt_rounded, size: 15),
                    label: const Text('Kembalikan Default'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _kBrand,
                      side: const BorderSide(color: _kBrand),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                  ),
                  OutlinedButton.icon(
                    onPressed: onSelectAll,
                    icon: const Icon(Icons.done_all_rounded, size: 15),
                    label: const Text('Centang Semua'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.success,
                      side: const BorderSide(color: AppColors.success),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                  ),
                ],
              ),
            ),
            for (final entry in groups.entries) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
                child: Text(
                  entry.key.toUpperCase(),
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.6,
                    color: const Color(0xFF64748B),
                  ),
                ),
              ),
              for (final spec in entry.value)
                CheckboxListTile(
                  value: selected.contains(spec.key),
                  onChanged: (value) =>
                      onTogglePermission(spec.key, value == true),
                  dense: true,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                  activeColor: _kBrand,
                  controlAffinity: ListTileControlAffinity.leading,
                  title: Text(
                    spec.title,
                    style: const TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  subtitle: Text(
                    spec.description,
                    style: const TextStyle(fontSize: 10.5, height: 1.25),
                  ),
                ),
              const Divider(height: 1, color: Color(0xFFE2E8F0)),
            ],
          ],
        ],
      ),
    );
  }

  Future<void> _showActionSheet(Employee employee) async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.zero,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF1565C0), Color(0xFF64B5F6)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Center(
                      child: Text(
                        employee.name.substring(0, 1).toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          employee.name,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: const BoxDecoration(
                            color: Color(0xFFE3F2FD),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: Text(
                            employee.role,
                            style: const TextStyle(
                              color: Color(0xFF1565C0),
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Divider(height: 1, color: Color(0xFFF0F0F0)),
            const SizedBox(height: 8),
            _ActionTile(
              icon: Icons.edit_outlined,
              iconColor: const Color(0xFF1976D2),
              iconBg: const Color(0xFFE3F2FD),
              label: 'Ubah Data Karyawan',
              subtitle: 'Edit nama, jabatan, telepon, atau PIN',
              onTap: () {
                Navigator.pop(ctx);
                _showForm(existing: employee);
              },
            ),
            _ActionTile(
              icon: AppIcons.recycleBin,
              iconColor: AppColors.danger,
              iconBg: AppColors.danger.withValues(alpha: 0.08),
              label: 'Hapus Karyawan',
              subtitle: 'Hapus data dari daftar karyawan',
              isDestructive: true,
              onTap: () {
                Navigator.pop(ctx);
                _confirmDelete(employee);
              },
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: SizedBox(
                width: double.infinity,
                height: 46,
                child: TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  style: TextButton.styleFrom(
                    backgroundColor: const Color(0xFFF5F5F5),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                  child: const Text(
                    'Batal',
                    style: TextStyle(
                        color: Colors.black54, fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(Employee employee) async {
    final ok = await showKasirConfirmDialog(
      context,
      title: 'Hapus Karyawan',
      message: 'Hapus "${employee.name}" dari daftar karyawan?',
      confirmLabel: 'Ya, Hapus',
      icon: AppIcons.recycleBin,
    );

    if (ok == true && employee.id != null) {
      await ref.read(employeesProvider.notifier).deleteEmployee(employee.id!);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Karyawan berhasil dihapus'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final isWide =
        mq.size.shortestSide >= 600 || mq.orientation == Orientation.landscape;
    final allEmployees = ref.watch(employeesProvider);
    final list = _filter(allEmployees);

    return KasirResponsiveScaffold(
      showAppBar: isWide || !Platform.isAndroid,
      title: 'Daftar Karyawan',
      showNavRail: false,
      backgroundColor: _kBg,
      body: isWide
          ? _buildWideBody(context, allEmployees, list)
          : SafeArea(child: _buildPortraitBody(context, allEmployees, list)),
      bottomNavigationBar: isWide ? null : _buildAddButton(),
    );
  }

  Widget _buildPortraitBody(
      BuildContext context, List<Employee> allEmployees, List<Employee> list) {
    return Column(
      children: [
        _buildPortraitHeader(context, allEmployees),
        _buildSearch(),
        const SizedBox(height: 4),
        Expanded(child: _buildList(list, isGrid: false)),
      ],
    );
  }

  Widget _buildWideBody(
      BuildContext context, List<Employee> allEmployees, List<Employee> list) {
    final mq = MediaQuery.of(context);
    final isLandscape = mq.orientation == Orientation.landscape;

    return Column(
      children: [
        // Top bar
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _kBrandLight,
                  borderRadius: BorderRadius.zero,
                ),
                child:
                    const Icon(Icons.badge_rounded, color: _kBrand, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Daftar Karyawan',
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87)),
                    Text(
                      '${allEmployees.length} karyawan terdaftar',
                      style:
                          const TextStyle(fontSize: 12, color: Colors.black45),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 40,
                child: ElevatedButton.icon(
                  onPressed: _showForm,
                  icon: const Icon(Icons.person_add_rounded, size: 16),
                  label: const Text('Tambah',
                      style:
                          TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kBrand,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                ),
              ),
            ],
          ),
        ),
        const Divider(height: 1, color: Color(0xFFEEEEEE)),
        Expanded(
          child: isLandscape
              ? _buildLandscapeContent(context, allEmployees, list)
              : Column(
                  children: [
                    Container(
                      color: Colors.white,
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                      child: _buildSearch(padding: EdgeInsets.zero),
                    ),
                    Expanded(
                        child:
                            _buildList(list, isGrid: true, crossAxisCount: 2)),
                  ],
                ),
        ),
      ],
    );
  }

  Widget _buildLandscapeContent(
      BuildContext context, List<Employee> allEmployees, List<Employee> list) {
    final activeCount = allEmployees.where((e) => e.isActive == 1).length;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Left panel: stats + search
        Container(
          width: 260,
          color: Colors.white,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Ringkasan',
                  style: GoogleFonts.inter(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Colors.black45,
                      letterSpacing: 0.5)),
              const SizedBox(height: 10),
              _KaryawanStatRow(
                icon: Icons.people_rounded,
                label: 'Total Karyawan',
                value: '${allEmployees.length}',
                color: _kBrand,
              ),
              const SizedBox(height: 8),
              _KaryawanStatRow(
                icon: Icons.check_circle_rounded,
                label: 'Aktif',
                value: '$activeCount',
                color: const Color(0xFF16A34A),
              ),
              const SizedBox(height: 20),
              _buildSearch(padding: EdgeInsets.zero),
            ],
          ),
        ),
        Container(width: 1, color: const Color(0xFFEEEEEE)),
        // Right: grid list
        Expanded(child: _buildList(list, isGrid: true, crossAxisCount: 2)),
      ],
    );
  }

  Widget _buildPortraitHeader(
      BuildContext context, List<Employee> allEmployees) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _kBrand, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          const SizedBox(width: 2),
          const Expanded(
            child: Text('Daftar Karyawan',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87)),
          ),
          if (allEmployees.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: const BoxDecoration(
                color: Color(0xFFE3F2FD),
                borderRadius: BorderRadius.zero,
              ),
              child: Text('${allEmployees.length} orang',
                  style: const TextStyle(
                      color: Color(0xFF1565C0),
                      fontSize: 12,
                      fontWeight: FontWeight.w700)),
            ),
        ],
      ),
    );
  }

  Widget _buildSearch({EdgeInsetsGeometry? padding}) {
    return Padding(
      padding: padding ?? const EdgeInsets.fromLTRB(16, 0, 16, 14),
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: _kBg,
          borderRadius: BorderRadius.zero,
          border: Border.all(color: const Color(0xFFEAEAEA)),
        ),
        child: TextField(
          controller: _searchCtrl,
          onChanged: (v) => setState(() => _query = v),
          style: const TextStyle(fontSize: 14, color: Colors.black87),
          decoration: const InputDecoration(
            hintText: 'Cari nama, jabatan, atau telepon...',
            hintStyle: TextStyle(fontSize: 13, color: Colors.black38),
            prefixIcon: Icon(Icons.search, color: Colors.black38, size: 20),
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(vertical: 12),
            isDense: true,
          ),
        ),
      ),
    );
  }

  Widget _buildList(List<Employee> list,
      {bool isGrid = false, int crossAxisCount = 2}) {
    if (list.isEmpty) {
      return _EmptyKaryawanView(isSearching: _query.isNotEmpty);
    }
    if (isGrid) {
      return GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 2.6,
        ),
        itemCount: list.length,
        itemBuilder: (_, i) => _EmployeeCardCompact(
          employee: list[i],
          onTap: () => _showActionSheet(list[i]),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
      itemCount: list.length,
      itemBuilder: (_, i) => _EmployeeCard(
        employee: list[i],
        onTap: () => _showActionSheet(list[i]),
      ),
    );
  }

  Widget _buildAddButton() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton.icon(
            onPressed: _showForm,
            icon: const Icon(Icons.person_add_rounded, size: 20),
            label: const Text('Tambah Karyawan',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              elevation: 0,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
          ),
        ),
      ),
    );
  }
}

class _EmployeeCardCompact extends StatelessWidget {
  final Employee employee;
  final VoidCallback onTap;
  const _EmployeeCardCompact({required this.employee, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFEEEEEE)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.zero,
        child: InkWell(
          borderRadius: BorderRadius.zero,
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: _kBrand.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Center(
                    child: Text(
                      employee.name.substring(0, 1).toUpperCase(),
                      style: const TextStyle(
                          color: _kBrand,
                          fontWeight: FontWeight.bold,
                          fontSize: 18),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(employee.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: Colors.black87)),
                      Text(employee.role,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 12, color: Colors.black45)),
                    ],
                  ),
                ),
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    color: employee.isActive == 1
                        ? const Color(0xFF16A34A)
                        : Colors.redAccent,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _KaryawanStatRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _KaryawanStatRow(
      {required this.icon,
      required this.label,
      required this.value,
      required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.10),
            borderRadius: BorderRadius.zero,
          ),
          child: Icon(icon, color: color, size: 16),
        ),
        const SizedBox(width: 10),
        Expanded(
            child: Text(label,
                style: const TextStyle(fontSize: 12, color: Colors.black54))),
        Text(value,
            style: TextStyle(
                fontSize: 13, fontWeight: FontWeight.bold, color: color)),
      ],
    );
  }
}

class _EmployeeCard extends StatelessWidget {
  final Employee employee;
  final VoidCallback onTap;

  const _EmployeeCard({required this.employee, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final hasPhone = employee.phone?.trim().isNotEmpty == true;
    final hasPin = employee.pin?.trim().isNotEmpty == true;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.zero,
        child: InkWell(
          borderRadius: BorderRadius.zero,
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                // Avatar gradient biru untuk karyawan
                Container(
                  width: 48,
                  height: 48,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF1565C0), Color(0xFF64B5F6)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Center(
                    child: Text(
                      employee.name.substring(0, 1).toUpperCase(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                // Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        employee.name,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: const BoxDecoration(
                              color: Color(0xFFE3F2FD),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Text(
                              employee.role,
                              style: const TextStyle(
                                color: Color(0xFF1565C0),
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          if (hasPin) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 3),
                              decoration: const BoxDecoration(
                                color: Color(0xFFF3E5F5),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: const Row(
                                children: [
                                  Icon(Icons.lock_outline_rounded,
                                      size: 10, color: Color(0xFF7B1FA2)),
                                  SizedBox(width: 3),
                                  Text(
                                    'PIN',
                                    style: TextStyle(
                                      color: Color(0xFF7B1FA2),
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ],
                      ),
                      if (hasPhone) ...[
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(Icons.phone_outlined,
                                size: 13, color: Colors.black38),
                            const SizedBox(width: 4),
                            Text(
                              employee.phone!,
                              style: const TextStyle(
                                  fontSize: 12, color: Colors.black45),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 32,
                  height: 32,
                  decoration: const BoxDecoration(
                    color: Color(0xFFF5F5F5),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: const Icon(Icons.more_vert_rounded,
                      size: 18, color: Colors.black45),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String label;
  final String subtitle;
  final bool isDestructive;
  final VoidCallback onTap;

  const _ActionTile({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.label,
    required this.subtitle,
    required this.onTap,
    this.isDestructive = false,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      leading: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: iconBg,
          borderRadius: BorderRadius.zero,
        ),
        child: Icon(icon, color: iconColor, size: 22),
      ),
      title: Text(
        label,
        style: TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 14,
          color: isDestructive ? AppColors.danger : Colors.black87,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(fontSize: 12, color: Colors.black45),
      ),
      trailing: Icon(Icons.chevron_right_rounded,
          color: Colors.grey.shade300, size: 20),
    );
  }
}

class _EmptyKaryawanView extends StatelessWidget {
  final bool isSearching;
  const _EmptyKaryawanView({this.isSearching = false});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: const BoxDecoration(
              color: Color(0xFFE3F2FD),
              shape: BoxShape.rectangle,
            ),
            child: const Icon(Icons.badge_outlined,
                size: 48, color: Color(0xFF1565C0)),
          ),
          const SizedBox(height: 18),
          Text(
            isSearching
                ? 'Karyawan tidak ditemukan'
                : 'Belum ada data karyawan',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            isSearching
                ? 'Coba gunakan kata kunci lain'
                : 'Tambahkan karyawan pertama Anda',
            style: const TextStyle(fontSize: 13, color: Colors.black45),
          ),
        ],
      ),
    );
  }
}

InputDecoration _inputDeco(String hint, [IconData? prefixIcon]) {
  return InputDecoration(
    hintText: hint,
    isDense: true,
    prefixIcon: prefixIcon != null
        ? Icon(prefixIcon, size: 18, color: Colors.black38)
        : null,
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    filled: true,
    fillColor: const Color(0xFFF6F7F9),
    border: const OutlineInputBorder(
      borderRadius: BorderRadius.zero,
      borderSide: BorderSide(color: Color(0xFFE0E0E0)),
    ),
    enabledBorder: const OutlineInputBorder(
      borderRadius: BorderRadius.zero,
      borderSide: BorderSide(color: Color(0xFFE8E8E8)),
    ),
    focusedBorder: const OutlineInputBorder(
      borderRadius: BorderRadius.zero,
      borderSide: BorderSide(color: _kBrand, width: 1.5),
    ),
  );
}

