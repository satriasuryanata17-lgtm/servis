import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../core/theme.dart';
import '../widgets/responsive_layout.dart';

class PengaturanShiftScreen extends ConsumerStatefulWidget {
  const PengaturanShiftScreen({super.key});

  @override
  ConsumerState<PengaturanShiftScreen> createState() =>
      _PengaturanShiftScreenState();
}

class _PengaturanShiftScreenState extends ConsumerState<PengaturanShiftScreen> {
  final TextEditingController _nameCtrl = TextEditingController();

  void _addShift(ShiftSettings settings) {
    if (_nameCtrl.text.trim().isEmpty) return;
    final newNames = List<String>.from(settings.shiftNames)
      ..add(_nameCtrl.text.trim());
    ref
        .read(shiftSettingsProvider.notifier)
        .updateSettings(settings.copyWith(shiftNames: newNames));
    _nameCtrl.clear();
  }

  void _removeShift(ShiftSettings settings, int index) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
                child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.zero))),
            const SizedBox(height: 20),
            const Icon(Icons.warning_amber_rounded,
                color: AppColors.danger, size: 48),
            const SizedBox(height: 16),
            Text('Hapus Shift?', style: AppText.h2),
            const SizedBox(height: 8),
            Text(
              'Shift "${settings.shiftNames[index]}" akan dihapus selamanya.',
              style: AppText.bodySmall.copyWith(color: AppColors.textCaption),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: const BorderSide(color: AppColors.border),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    child: Text('Batal',
                        style: AppText.h3.copyWith(color: AppColors.textBody)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      final newNames = List<String>.from(settings.shiftNames)
                        ..removeAt(index);
                      ref.read(shiftSettingsProvider.notifier).updateSettings(
                          settings.copyWith(shiftNames: newNames));
                      Navigator.pop(ctx);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.danger,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    child: const Text('Ya, Hapus',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _editShift(ShiftSettings settings, int index) {
    final TextEditingController editCtrl =
        TextEditingController(text: settings.shiftNames[index]);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Container(
          padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                  child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.zero))),
              const SizedBox(height: 20),
              Text('Ubah Nama Shift', style: AppText.h2),
              const SizedBox(height: 16),
              TextField(
                controller: editCtrl,
                autofocus: true,
                style: const TextStyle(fontWeight: FontWeight.w600),
                decoration: const InputDecoration(
                  hintText: 'Nama Shift',
                  filled: true,
                  fillColor: Color(0xFFF4F7FC),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide.none),
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: () {
                    if (editCtrl.text.trim().isNotEmpty) {
                      final newNames = List<String>.from(settings.shiftNames);
                      newNames[index] = editCtrl.text.trim();
                      ref.read(shiftSettingsProvider.notifier).updateSettings(
                          settings.copyWith(shiftNames: newNames));
                      Navigator.pop(ctx);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryBrand,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                  child: const Text('Simpan Perubahan',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(shiftSettingsProvider);
    final isTablet = KasirLayout.isTablet(context);
    final isLandscape = KasirLayout.isLandscape(context);

    return KasirResponsiveScaffold(
      title: 'Manajemen Shift',
      showNavRail: false,
      navIndex: 6,
      backgroundColor: const Color(0xFFF7F7F9),
      body: (isTablet && isLandscape)
          ? _buildWideLayout(settings)
          : _buildScrollLayout(settings),
    );
  }

  Widget _buildWideLayout(ShiftSettings settings) {
    return KasirLandscapeSplit(
      leftWidth: 320,
      leftPanel: _buildTogglePanel(settings, padding: const EdgeInsets.all(24)),
      rightPanel: settings.enableShift
          ? _buildShiftListPanel(settings, padding: const EdgeInsets.all(24))
          : const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.access_time_outlined,
                      size: 48, color: Colors.black26),
                  SizedBox(height: 12),
                  Text('Shift belum diaktifkan',
                      style: TextStyle(color: Colors.black38, fontSize: 14)),
                ],
              ),
            ),
    );
  }

  Widget _buildScrollLayout(ShiftSettings settings) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildTogglePanel(settings),
        if (settings.enableShift) ...[
          const SizedBox(height: 24),
          _buildShiftListPanel(settings),
        ],
      ],
    );
  }

  Widget _buildTogglePanel(ShiftSettings settings, {EdgeInsets? padding}) {
    final content = Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: SwitchListTile(
        activeThumbColor: AppColors.primaryBrand,
        title: const Text('Aktifkan Manajemen Shift',
            style: TextStyle(fontWeight: FontWeight.w600)),
        subtitle: const Text(
            'Jika aktif, Kasir wajib memilih shift saat membuka laci.'),
        value: settings.enableShift,
        onChanged: (val) {
          ref
              .read(shiftSettingsProvider.notifier)
              .updateSettings(settings.copyWith(enableShift: val));
        },
      ),
    );
    if (padding != null) return Padding(padding: padding, child: content);
    return content;
  }

  Widget _buildShiftListPanel(ShiftSettings settings, {EdgeInsets? padding}) {
    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Daftar Shift',
          style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black87),
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.03),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: settings.shiftNames.isEmpty
              ? const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(
                    child: Text('Belum ada shift. Tambahkan di bawah.',
                        style: TextStyle(color: Colors.black38)),
                  ),
                )
              : ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: settings.shiftNames.length,
                  separatorBuilder: (_, __) =>
                      const Divider(height: 1, color: Color(0xFFEEEEEE)),
                  itemBuilder: (ctx, i) => ListTile(
                    leading: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: AppColors.primaryBrand.withValues(alpha: 0.10),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Icon(Icons.access_time_rounded,
                          color: AppColors.primaryBrand, size: 18),
                    ),
                    title: Text(settings.shiftNames[i],
                        style: const TextStyle(fontWeight: FontWeight.w500)),
                    trailing: PopupMenuButton<String>(
                      icon: const Icon(Icons.more_vert_rounded,
                          color: Colors.grey),
                      onSelected: (val) {
                        if (val == 'edit') {
                          _editShift(settings, i);
                        } else if (val == 'delete') {
                          _removeShift(settings, i);
                        }
                      },
                      itemBuilder: (_) => [
                        const PopupMenuItem(
                          value: 'edit',
                          child: ListTile(
                            leading:
                                Icon(Icons.edit_outlined, color: Colors.blue),
                            title: Text('Ubah'),
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                        const PopupMenuItem(
                          value: 'delete',
                          child: ListTile(
                            leading:
                                Icon(AppIcons.recycleBin, color: Colors.red),
                            title: Text('Hapus'),
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
        ),
        const SizedBox(height: 16),
        // Add shift row
        Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
          ),
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _nameCtrl,
                  decoration: const InputDecoration(
                    hintText: 'Nama Shift Baru...',
                    filled: true,
                    fillColor: Color(0xFFF7F7F9),
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide.none),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton.icon(
                onPressed: () => _addShift(settings),
                icon: const Icon(Icons.add_rounded, size: 18),
                label: const Text('Tambah'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBrand,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
              ),
            ],
          ),
        ),
      ],
    );

    if (padding != null) {
      return SingleChildScrollView(
        padding: padding,
        child: content,
      );
    }
    return content;
  }
}

