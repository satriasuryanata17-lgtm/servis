import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../services/pos_network_service.dart';

class SyncSettingsScreen extends StatefulWidget {
  const SyncSettingsScreen({super.key});

  @override
  State<SyncSettingsScreen> createState() => _SyncSettingsScreenState();
}

class _SyncSettingsScreenState extends State<SyncSettingsScreen> {
  final POSNetworkService _networkService = POSNetworkService.instance;
  final List<String> _discoveredIps = [];
  bool _isSearching = false;

  @override
  void initState() {
    super.initState();
    _networkService.discoveryStream.listen((ip) {
      if (!_discoveredIps.contains(ip)) {
        setState(() => _discoveredIps.add(ip));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF1F5F9),
      appBar: AppBar(
        title: const Text('Juragan Sync'),
        backgroundColor: Colors.white,
        foregroundColor: AppColors.primaryBrand,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildStatusCard(),
            const SizedBox(height: 24),
            _buildQuickGuide(),
            const SizedBox(height: 24),
            _buildModeSelection(),
            const SizedBox(height: 20),
            if (_networkService.mode == POSNetworkMode.terminal)
              _buildDiscoverySection(),
            if (_networkService.mode == POSNetworkMode.master)
              _buildLogSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusCard() {
    final mode = _networkService.mode;
    final isRunning = _networkService.isRunning;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: isRunning
                ? Colors.green.withValues(alpha: 0.1)
                : Colors.grey.withValues(alpha: 0.1),
            child: Icon(
              isRunning ? Icons.sync_rounded : Icons.sync_disabled_rounded,
              color: isRunning ? Colors.green : Colors.grey,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isRunning ? 'Layanan Aktif' : 'Layanan Terhenti',
                  style: AppText.h3.copyWith(fontSize: 16),
                ),
                Text(
                  mode == POSNetworkMode.master
                      ? 'Berfungsi sebagai Server Utama'
                      : mode == POSNetworkMode.terminal
                          ? 'Berfungsi sebagai Terminal Tambahan'
                          : 'Pilih mode koneksi di bawah',
                  style: AppText.caption,
                ),
              ],
            ),
          ),
          if (isRunning)
            TextButton(
              onPressed: () async {
                await _networkService.stop();
                setState(() {});
              },
              child:
                  const Text('Hentikan', style: TextStyle(color: Colors.red)),
            ),
        ],
      ),
    );
  }

  Widget _buildModeSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('PILIH MODE PERANGKAT', style: AppText.overline),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _ModeCard(
                title: 'Server Utama',
                subtitle: 'Pusat data & sinkronisasi (Tablet)',
                icon: Icons.storage_rounded,
                isSelected: _networkService.mode == POSNetworkMode.master,
                onTap: () async {
                  await _networkService.startMasterMode();
                  setState(() {});
                },
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _ModeCard(
                title: 'Perangkat Staff',
                subtitle: 'Catat pesanan via Wi-Fi (HP)',
                icon: Icons.smartphone_rounded,
                isSelected: _networkService.mode == POSNetworkMode.terminal,
                onTap: () {
                  // Transition to terminal mode
                  _networkService.connectToMaster('');
                  setState(() {});
                  _startDiscovery();
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildDiscoverySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('MENCARI SERVER UTAMA...', style: AppText.overline),
            if (_isSearching)
              const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2)),
          ],
        ),
        const SizedBox(height: 10),
        if (_discoveredIps.isEmpty)
          Container(
            padding: const EdgeInsets.all(30),
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                const Icon(Icons.wifi_find_rounded,
                    size: 48, color: Colors.grey),
                const SizedBox(height: 12),
                Text('Belum menemukan Server Utama', style: AppText.caption),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: _startDiscovery,
                  child: const Text('Cari Ulang'),
                ),
              ],
            ),
          )
        else
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _discoveredIps.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final ip = _discoveredIps[index];
              final isConnected = _networkService.masterIp == ip &&
                  _networkService.mode == POSNetworkMode.terminal;

              return ListTile(
                tileColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
                leading: Icon(Icons.laptop_rounded,
                    color: isConnected ? Colors.green : AppColors.primaryBrand),
                title: Text('Server Utama ($ip)'),
                subtitle: isConnected
                    ? const Text('Terhubung',
                        style: TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                            fontSize: 12))
                    : null,
                trailing: isConnected
                    ? const Icon(Icons.check_circle_rounded,
                        color: Colors.green)
                    : ElevatedButton(
                        onPressed: () async {
                          await _networkService.connectToMaster(ip);
                          if (!mounted) return;
                          setState(() {});
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text('Terhubung ke Server Utama')),
                            );
                          }
                        },
                        child: const Text('Hubungkan'),
                      ),
              );
            },
          ),
      ],
    );
  }

  Widget _buildQuickGuide() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.help_outline,
                  color: AppColors.primaryBrand, size: 20),
              const SizedBox(width: 8),
              Text(
                'Panduan Singkat',
                style: AppText.h3.copyWith(
                  fontSize: 16,
                  color: AppColors.primaryBrand,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _guideItem(
            '1',
            'Satu perangkat harus menjadi "Server Utama" (biasanya tablet frontdesk).',
          ),
          _guideItem(
            '2',
            'Perangkat lain (HP Staff/Workshop) pilih sebagai "Perangkat Staff".',
          ),
          _guideItem(
            '3',
            'Pastikan semua perangkat terhubung ke Wi-Fi yang SAMA.',
          ),
          _guideItem(
            '4',
            'Klik nama Server Utama yang muncul di HP Staff untuk terhubung.',
          ),
        ],
      ),
    );
  }

  Widget _guideItem(String step, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: AppColors.primaryBrand.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                step,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryBrand,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: AppText.body.copyWith(
                fontSize: 14,
                color: Colors.grey[700],
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLogSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('LOG AKTIVITAS JARINGAN', style: AppText.overline),
        const SizedBox(height: 10),
        Container(
          height: 200,
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.black87,
            borderRadius: BorderRadius.circular(8),
          ),
          child: StreamBuilder<String>(
            stream: _networkService.logStream,
            builder: (context, snapshot) {
              return ListView(
                reverse: true,
                children: [
                  if (snapshot.hasData)
                    Text(
                      snapshot.data!,
                      style: const TextStyle(
                          color: Colors.greenAccent,
                          fontSize: 12,
                          fontFamily: 'monospace'),
                    ),
                  const Text('Menunggu aktivitas...',
                      style: TextStyle(color: Colors.grey, fontSize: 10)),
                ],
              );
            },
          ),
        ),
      ],
    );
  }

  void _startDiscovery() {
    setState(() {
      _discoveredIps.clear();
      _isSearching = true;
    });
    _networkService.startDiscovery();
    Future.delayed(const Duration(seconds: 10), () {
      if (mounted) setState(() => _isSearching = false);
    });
  }
}

class _ModeCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _ModeCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primaryBrand : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? AppColors.primaryBrand : Colors.transparent,
            width: 2,
          ),
        ),
        child: Column(
          children: [
            Icon(icon,
                size: 32,
                color: isSelected ? Colors.white : AppColors.primaryBrand),
            const SizedBox(height: 12),
            Text(
              title,
              style: AppText.h3.copyWith(
                fontSize: 14,
                color: isSelected ? Colors.white : AppColors.textTitle,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: AppText.caption.copyWith(
                fontSize: 10,
                color: isSelected
                    ? Colors.white.withValues(alpha: 0.8)
                    : Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

