import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:math' as math;
import 'package:intl/intl.dart';
import '../../core/theme.dart';
import '../../providers/providers.dart';
import '../../services/admin_license_service.dart';
import '../../services/auth_service.dart';
import '../../services/support_contact_service.dart';
import '../ubah_kata_sandi_screen.dart';
import '../../services/remote_print_service.dart';
import '../../services/receipt_print_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:printing/printing.dart';
import 'dart:io';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../utils/modern_ui_helpers.dart';

const Color _kBrand = AppColors.primaryBrand;
const Color _kDark = Color(0xFF0F172A);
const Color _kSlate = Color(0xFF334155);
const Color _kSlateLight = Color(0xFF64748B);
const Color _kBorder = Color(0xFFE2E8F0);
const Color _kSurface = Color(0xFFF8FAFC);

class _LicensePreset {
  final String key;
  final String label;
  final int maxDevices;
  final String type;
  final IconData icon;
  final Color color;

  const _LicensePreset({
    required this.key,
    required this.label,
    required this.maxDevices,
    required this.type,
    required this.icon,
    required this.color,
  });
}

const _presets = [
  _LicensePreset(
      key: 'single',
      label: 'Solo',
      maxDevices: 1,
      type: 'single',
      icon: Icons.person,
      color: Color(0xFF3B82F6)),
  _LicensePreset(
      key: 'duo',
      label: 'Duo',
      maxDevices: 2,
      type: 'bundle',
      icon: Icons.group,
      color: Color(0xFF8B5CF6)),
  _LicensePreset(
      key: 'team',
      label: 'Team',
      maxDevices: 5,
      type: 'multi',
      icon: Icons.groups,
      color: Color(0xFF06B6D4)),
  _LicensePreset(
      key: 'unlimited',
      label: 'Unlimited',
      maxDevices: 0,
      type: 'unlimited',
      icon: Icons.all_inclusive,
      color: Color(0xFFF59E0B)),
];

const _platformOptions = [
  {'key': 'all', 'label': 'Semua', 'icon': Icons.devices},
  {'key': 'android', 'label': 'Android', 'icon': Icons.phone_android},
  {'key': 'desktop', 'label': 'Desktop', 'icon': Icons.desktop_windows},
  {'key': 'android+desktop', 'label': 'Bundle', 'icon': Icons.phonelink},
];

class AdminDashboardScreen extends ConsumerStatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  ConsumerState<AdminDashboardScreen> createState() =>
      _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends ConsumerState<AdminDashboardScreen> {
  static final math.Random _secureRandom = math.Random.secure();
  static const _serialChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  static const _passwordChars =
      'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  bool _isLoading = true;
  List<Map<String, dynamic>> _licenses = [];
  final Map<String, String> _generatedPasswords = {};
  String _searchQuery = '';
  String _filterType = 'all'; // all, active, inactive, free
  String _currentPanel = 'licenses'; // licenses, remote_print
  bool _isAutoPrintLdr = false;

  @override
  void initState() {
    super.initState();
    _fetchLicenses();
    _loadAutoPrintPref();
  }

  Future<void> _loadAutoPrintPref() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _isAutoPrintLdr = prefs.getBool('admin_autoPrintLdr') ?? false;
      });
    }
  }

  Future<void> _saveAutoPrintPref(bool v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('admin_autoPrintLdr', v);
    setState(() => _isAutoPrintLdr = v);
  }

  Future<void> _fetchLicenses() async {
    setState(() => _isLoading = true);
    try {
      setState(() {
        _licenses = [];
      });
      final res = await AdminLicenseService.fetchLicenses();
      if (!mounted) return;
      setState(() {
        _licenses = res;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      _showSnack(
          'Gagal memuat data lisensi. Pastikan perangkat terhubung ke internet.',
          isError: true);
    }
  }

  int get _totalLicenses => _licenses.length;
  int get _activeDevices {
    int count = 0;
    for (final l in _licenses) {
      final dc = l['active_device_count'];
      if (dc is int && dc > 0) {
        count += dc;
      } else if (l['device_id']?.toString().trim().isNotEmpty ?? false) {
        count++;
      }
    }
    return count;
  }

  int get _freeLicenses => _licenses.where((l) {
        final dc = (l['active_device_count'] as int?) ?? 0;
        return dc == 0;
      }).length;

  List<Map<String, dynamic>> get _filteredLicenses {
    final query = _searchQuery.toLowerCase().trim();
    return _licenses.where((l) {
      // text search
      final name = (l['customer_name'] ?? '').toString().toLowerCase();
      final serial = (l['serial'] ?? '').toString().toLowerCase();
      final label = (l['label'] ?? '').toString().toLowerCase();
      final matchesSearch = query.isEmpty ||
          name.contains(query) ||
          serial.contains(query) ||
          label.contains(query);

      if (!matchesSearch) return false;

      // filter chips
      if (_filterType == 'all') return true;
      final dc = (l['active_device_count'] as int?) ?? 0;
      if (_filterType == 'active') return dc > 0;
      if (_filterType == 'free') return dc == 0;
      if (_filterType == 'inactive') return l['is_active'] != true;
      return true;
    }).toList();
  }

  Future<void> _generateLicense() async {
    final nameCtrl = TextEditingController();
    final emailCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final labelCtrl = TextEditingController();
    final serial =
        'JKSR-${_randomToken(4, _serialChars)}-${_randomToken(4, _serialChars)}-${_randomToken(4, _serialChars)}-${_randomToken(4, _serialChars)}';
    final password = _randomToken(12, _passwordChars);

    int selectedPreset = 0; // Solo
    String selectedPlatform = 'all';
    bool canRemotePrint = false;
    bool isTrial = false;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          final preset = _presets[selectedPreset];
          return AlertDialog(
            backgroundColor: Colors.white,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            insetPadding:
                const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            contentPadding: EdgeInsets.zero,
            titlePadding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
            title: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  color: _kBrand.withValues(alpha: 0.1),
                  child: const Icon(Icons.add_task_rounded,
                      color: _kBrand, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                    child: Text('Terbitkan Lisensi',
                        style: AppText.h2.copyWith(fontSize: 17))),
              ],
            ),
            content: SizedBox(
              width: 420,
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _CompactField(
                        ctrl: nameCtrl,
                        label: 'Nama Pembeli *',
                        icon: Icons.person_add_alt_1_rounded),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                            child: _CompactField(
                                ctrl: emailCtrl,
                                label: 'Email',
                                icon: Icons.email_rounded,
                                type: TextInputType.emailAddress)),
                        const SizedBox(width: 10),
                        Expanded(
                            child: _CompactField(
                                ctrl: phoneCtrl,
                                label: 'WhatsApp',
                                icon: Icons.phone_android_rounded,
                                type: TextInputType.phone)),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Text('TIPE LISENSI',
                        style: AppText.overline
                            .copyWith(fontSize: 10, color: _kSlateLight)),
                    const SizedBox(height: 8),
                    Row(
                      children: List.generate(_presets.length, (i) {
                        final p = _presets[i];
                        final isSelected = i == selectedPreset;
                        return Expanded(
                          child: GestureDetector(
                            onTap: () =>
                                setDialogState(() => selectedPreset = i),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              margin: EdgeInsets.only(
                                  right: i < _presets.length - 1 ? 8 : 0),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? p.color.withValues(alpha: 0.12)
                                    : _kSurface,
                                border: Border.all(
                                  color: isSelected ? p.color : _kBorder,
                                  width: isSelected ? 2 : 1,
                                ),
                              ),
                              child: Column(
                                children: [
                                  Icon(p.icon,
                                      size: 20,
                                      color:
                                          isSelected ? p.color : _kSlateLight),
                                  const SizedBox(height: 4),
                                  Text(
                                    p.maxDevices == 0 ? '∞' : '${p.maxDevices}',
                                    style: AppText.h3.copyWith(
                                      fontSize: 16,
                                      color: isSelected ? p.color : _kSlate,
                                    ),
                                  ),
                                  Text(
                                    p.label,
                                    style: AppText.caption.copyWith(
                                      fontSize: 9,
                                      color:
                                          isSelected ? p.color : _kSlateLight,
                                      fontWeight: isSelected
                                          ? FontWeight.w700
                                          : FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 16),
                    Text('PLATFORM',
                        style: AppText.overline
                            .copyWith(fontSize: 10, color: _kSlateLight)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: _platformOptions.map((opt) {
                        final isSelected = selectedPlatform == opt['key'];
                        return ChoiceChip(
                          label: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(opt['icon'] as IconData,
                                  size: 14,
                                  color:
                                      isSelected ? Colors.white : _kSlateLight),
                              const SizedBox(width: 4),
                              Text(opt['label'] as String,
                                  style: TextStyle(
                                      fontSize: 11,
                                      color:
                                          isSelected ? Colors.white : _kSlate)),
                            ],
                          ),
                          selected: isSelected,
                          selectedColor: _kBrand,
                          backgroundColor: _kSurface,
                          side: BorderSide(
                              color: isSelected ? _kBrand : _kBorder),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          onSelected: (_) => setDialogState(
                              () => selectedPlatform = opt['key'] as String),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 12),
                    _CompactField(
                        ctrl: labelCtrl,
                        label: 'Label (opsional)',
                        icon: Icons.label_outline_rounded),
                    const SizedBox(height: 16),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: canRemotePrint
                            ? AppColors.success.withValues(alpha: 0.05)
                            : _kSurface,
                        border: Border.all(
                            color: canRemotePrint
                                ? AppColors.success.withValues(alpha: 0.2)
                                : _kBorder),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.print_rounded,
                              size: 18,
                              color: canRemotePrint
                                  ? AppColors.success
                                  : _kSlateLight),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Fitur Remote Print',
                                    style: AppText.caption.copyWith(
                                        fontSize: 12,
                                        color: _kDark,
                                        fontWeight: FontWeight.w600)),
                                Text('Izinkan akun ini menggunakan Print LDR',
                                    style: AppText.caption.copyWith(
                                        fontSize: 10, color: _kSlateLight)),
                              ],
                            ),
                          ),
                          Switch(
                            value: canRemotePrint,
                            onChanged: (v) =>
                                setDialogState(() => canRemotePrint = v),
                            activeThumbColor: AppColors.success,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: isTrial
                            ? Colors.orange.withValues(alpha: 0.05)
                            : _kSurface,
                        border: Border.all(
                            color: isTrial
                                ? Colors.orange.withValues(alpha: 0.2)
                                : _kBorder),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.timer_rounded,
                              size: 18,
                              color: isTrial ? Colors.orange : _kSlateLight),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Akun Trial',
                                    style: AppText.caption.copyWith(
                                        fontSize: 12,
                                        color: _kDark,
                                        fontWeight: FontWeight.w600)),
                                Text('Akses demo otomatis & Print LDR terbatas',
                                    style: AppText.caption.copyWith(
                                        fontSize: 10, color: _kSlateLight)),
                              ],
                            ),
                          ),
                          Switch(
                            value: isTrial,
                            onChanged: (v) => setDialogState(() => isTrial = v),
                            activeThumbColor: Colors.orange,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Divider(color: _kBorder, height: 1),
                    const SizedBox(height: 16),
                    _InlineCredential(
                        label: 'SERIAL',
                        value: serial,
                        onCopy: () => _showSnack('Serial disalin')),
                    const SizedBox(height: 8),
                    _InlineCredential(
                        label: 'PASSWORD',
                        value: password,
                        onCopy: () => _showSnack('Password disalin')),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(10),
                      color: preset.color.withValues(alpha: 0.08),
                      child: Row(
                        children: [
                          Icon(preset.icon, size: 16, color: preset.color),
                          const SizedBox(width: 8),
                          Text(
                            '${preset.label}  |  ${preset.maxDevices == 0 ? "Unlimited" : "${preset.maxDevices} Device"}  |  ${_platformLabel(selectedPlatform)}${isTrial ? "  |  TRIAL" : ""}',
                            style: AppText.caption.copyWith(
                                fontSize: 11,
                                color: preset.color,
                                fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text('Batal',
                    style: AppText.caption.copyWith(color: _kSlateLight)),
              ),
              ElevatedButton.icon(
                onPressed: () async {
                  if (nameCtrl.text.trim().isEmpty) {
                    _showSnack('Nama wajib diisi!', isError: true);
                    return;
                  }
                  Navigator.pop(ctx);
                  await _pushLicense(
                    serial,
                    password,
                    nameCtrl.text.trim(),
                    emailCtrl.text.trim(),
                    phoneCtrl.text.trim(),
                    maxDevices: preset.maxDevices,
                    licenseType: preset.type,
                    allowedPlatforms: selectedPlatform,
                    canRemotePrint: canRemotePrint,
                    isTrial: isTrial,
                    label: labelCtrl.text.trim().isEmpty
                        ? null
                        : labelCtrl.text.trim(),
                    expiredAt: isTrial
                        ? DateTime.now()
                            .toUtc()
                            .add(const Duration(hours: 24))
                            .toIso8601String()
                        : null,
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: _kBrand,
                  foregroundColor: Colors.white,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                  elevation: 0,
                ),
                icon: const Icon(Icons.rocket_launch_rounded, size: 16),
                label: const Text('Terbitkan'),
              ),
            ],
          );
        },
      ),
    );
  }

  String _platformLabel(String key) {
    switch (key) {
      case 'android':
        return 'Android';
      case 'desktop':
        return 'Desktop';
      case 'android+desktop':
        return 'Android + Desktop';
      default:
        return 'Semua Platform';
    }
  }

  IconData _platformIcon(String key) {
    switch (key) {
      case 'android':
        return Icons.phone_android;
      case 'desktop':
        return Icons.desktop_windows;
      case 'android+desktop':
        return Icons.phonelink;
      default:
        return Icons.devices;
    }
  }

  Future<void> _pushLicense(
    String serial,
    String password,
    String name,
    String email,
    String phone, {
    int maxDevices = 1,
    String licenseType = 'single',
    String allowedPlatforms = 'all',
    bool canRemotePrint = false,
    bool isTrial = false,
    String? label,
    String? expiredAt,
  }) async {
    try {
      await AdminLicenseService.createLicense(
        serial: serial,
        password: password,
        name: name,
        email: email,
        phone: phone,
        maxDevices: maxDevices,
        licenseType: licenseType,
        allowedPlatforms: allowedPlatforms,
        canRemotePrint: canRemotePrint,
        isTrial: isTrial,
        label: label,
        expiredAt: expiredAt,
      );
    } catch (e) {
      _showSnack('Gagal menerbitkan lisensi: $e', isError: true);
      return;
    }

    if (!mounted) return;
    setState(() {
      _generatedPasswords[serial] = password;
    });
    _fetchLicenses();
    _showSnack('Berhasil: Lisensi diterbitkan untuk $name.');
  }

  void _showDetailSheet(Map<String, dynamic> item) {
    final generatedPassword = _generatedPasswords[item['serial']];
    final String date = item['created_at'] != null
        ? DateFormat('dd MMM yyyy')
            .format(DateTime.parse(item['created_at'].toString()))
        : '-';
    final int maxDevices = (item['max_devices'] as int?) ?? 1;
    final int deviceCount = (item['active_device_count'] as int?) ?? 0;
    final String licenseType = (item['license_type'] ?? 'single').toString();
    final String allowedPlatforms =
        (item['allowed_platforms'] ?? 'all').toString();
    final bool canRemotePrint = item['can_remote_print'] == true;
    final String? label = item['label']?.toString();
    final bool isActive = item['is_active'] == true;
    final bool isTrial = item['is_trial'] == true;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _LicenseDetailSheet(
        item: item,
        generatedPassword: generatedPassword,
        date: date,
        maxDevices: maxDevices,
        deviceCount: deviceCount,
        licenseType: licenseType,
        allowedPlatforms: allowedPlatforms,
        canRemotePrint: canRemotePrint,
        label: label,
        isActive: isActive,
        isTrial: isTrial,
        onCopyInfo: () {
          final buffer = StringBuffer()..writeln('Serial: ${item['serial']}');
          if (generatedPassword != null) {
            buffer.writeln('Pass: $generatedPassword');
          }
          Clipboard.setData(ClipboardData(text: buffer.toString().trim()));
          Navigator.pop(ctx);
          _showSnack(
            generatedPassword != null
                ? 'Serial dan password disalin ke clipboard'
                : 'Serial disalin ke clipboard',
          );
        },
        onResetDevice: (deviceId) async {
          Navigator.pop(ctx);
          await _resetDevice(item, deviceId: deviceId);
        },
        onResetAll: () async {
          Navigator.pop(ctx);
          await _resetDevice(item);
        },
        onUpdateConfig: (config) async {
          try {
            await AdminLicenseService.updateLicenseConfig(
              licenseId: item['id'].toString(),
              maxDevices: config['max_devices'] as int?,
              licenseType: config['license_type'] as String?,
              allowedPlatforms: config['allowed_platforms'] as String?,
              label: config['label'] as String?,
              isActive: config['is_active'] as bool?,
              canRemotePrint: config['can_remote_print'] as bool?,
              isTrial: config['is_trial'] as bool?,
              expiredAt: config['expired_at'] as String?,
            );
            if (ctx.mounted) {
              Navigator.pop(ctx);
              _showSnack('Pengaturan lisensi diperbarui.');
              _fetchLicenses();
            }
          } catch (e) {
            _showSnack('Gagal: $e', isError: true);
          }
        },
      ),
    );
  }

  Future<void> _resetDevice(Map<String, dynamic> license,
      {String? deviceId}) async {
    try {
      await AdminLicenseService.resetDevice(
        license['id'].toString(),
        deviceId: deviceId,
      );
      _fetchLicenses();
      _showSnack(deviceId != null
          ? 'Device berhasil di-reset.'
          : 'Semua device berhasil di-reset.');
    } catch (e) {
      _showSnack('Gagal: $e', isError: true);
    }
  }

  Future<void> _openChangePassword() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const UbahKataSandiScreen()),
    );
  }

  Future<void> _openPlayStoreUrlEditor(String currentUrl) async {
    final controller = TextEditingController(text: currentUrl);
    var isSubmitting = false;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => AlertDialog(
          backgroundColor: Colors.white,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          title: Row(
            children: [
              const Icon(Icons.star_rounded,
                  color: Color(0xFFFBBC04), size: 20),
              const SizedBox(width: 8),
              Text('URL Play Store', style: AppText.h2.copyWith(fontSize: 16)),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'URL ini digunakan saat pengguna mengetuk rating bintang di halaman Kritik & Saran.',
                style: AppText.caption.copyWith(fontSize: 11),
              ),
              const SizedBox(height: 16),
              _CompactField(
                ctrl: controller,
                label: 'URL Play Store',
                icon: Icons.link_rounded,
                type: TextInputType.url,
                enabled: !isSubmitting,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: isSubmitting ? null : () => Navigator.pop(ctx),
              child: Text('Batal', style: AppText.caption),
            ),
            ElevatedButton(
              onPressed: isSubmitting
                  ? null
                  : () async {
                      final rawValue = controller.text.trim();
                      if (rawValue.isEmpty) {
                        _showSnack('URL wajib diisi.', isError: true);
                        return;
                      }
                      setModalState(() => isSubmitting = true);
                      try {
                        await SupportContactService.updatePlayStoreUrl(
                            rawValue);
                        if (!mounted || !ctx.mounted) return;
                        ref.invalidate(playStoreUrlProvider);
                        Navigator.pop(ctx);
                        _showSnack('URL Play Store diperbarui.');
                      } on FormatException catch (e) {
                        _showSnack(e.message.toString(), isError: true);
                      } on AuthBackendRequiredException catch (e) {
                        _showSnack(e.toString(), isError: true);
                      } catch (e) {
                        _showSnack('Gagal: $e', isError: true);
                      } finally {
                        if (ctx.mounted) {
                          setModalState(() => isSubmitting = false);
                        }
                      }
                    },
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                elevation: 0,
              ),
              child: isSubmitting
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor:
                              AlwaysStoppedAnimation<Color>(Colors.white)))
                  : const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openSupportWhatsappEditor(String currentNumber) async {
    final controller = TextEditingController(text: currentNumber);
    var isSubmitting = false;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => AlertDialog(
          backgroundColor: Colors.white,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          title: Row(
            children: [
              const Icon(Icons.support_agent_rounded, color: _kBrand, size: 20),
              const SizedBox(width: 8),
              Text('WhatsApp Support',
                  style: AppText.h2.copyWith(fontSize: 16)),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Nomor ini ditampilkan di halaman login lisensi dan menu Pusat Bantuan.',
                style: AppText.caption.copyWith(fontSize: 11),
              ),
              const SizedBox(height: 16),
              _CompactField(
                  ctrl: controller,
                  label: 'Nomor WhatsApp',
                  icon: Icons.phone_android_rounded,
                  type: TextInputType.phone,
                  enabled: !isSubmitting),
            ],
          ),
          actions: [
            TextButton(
              onPressed: isSubmitting ? null : () => Navigator.pop(ctx),
              child: Text('Batal', style: AppText.caption),
            ),
            ElevatedButton(
              onPressed: isSubmitting
                  ? null
                  : () async {
                      final rawValue = controller.text.trim();
                      if (rawValue.isEmpty) {
                        _showSnack('Nomor wajib diisi.', isError: true);
                        return;
                      }
                      setModalState(() => isSubmitting = true);
                      try {
                        await SupportContactService.updateSupportWhatsappNumber(
                            rawValue);
                        if (!mounted || !ctx.mounted) return;
                        ref.invalidate(supportWhatsappProvider);
                        Navigator.pop(ctx);
                        _showSnack('Nomor WhatsApp support diperbarui.');
                      } on FormatException catch (e) {
                        _showSnack(e.message.toString(), isError: true);
                      } on AuthBackendRequiredException catch (e) {
                        _showSnack(e.toString(), isError: true);
                      } catch (e) {
                        _showSnack('Gagal: $e', isError: true);
                      } finally {
                        if (ctx.mounted) {
                          setModalState(() => isSubmitting = false);
                        }
                      }
                    },
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                elevation: 0,
              ),
              child: isSubmitting
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor:
                              AlwaysStoppedAnimation<Color>(Colors.white)))
                  : const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  String _randomToken(int len, String chars) {
    return String.fromCharCodes(
      Iterable.generate(
        len,
        (_) => chars.codeUnitAt(_secureRandom.nextInt(chars.length)),
      ),
    );
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    if (isError) {
      ModernSnackBar.error(context: context, message: msg);
    } else {
      ModernSnackBar.show(context: context, message: msg);
    }
  }

  @override
  Widget build(BuildContext context) {
    final supportWhatsappAsync = ref.watch(supportWhatsappProvider);
    final playStoreUrlAsync = ref.watch(playStoreUrlProvider);
    final filtered = _filteredLicenses;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        ref.read(authProvider.notifier).logout();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFF1F5F9),
        body: Column(
          children: [
            Container(
              color: _kDark,
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back_rounded,
                            color: Colors.white, size: 20),
                        onPressed: () =>
                            ref.read(authProvider.notifier).logout(),
                        visualDensity: VisualDensity.compact,
                      ),
                      const SizedBox(width: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        color: _kBrand.withValues(alpha: 0.2),
                        child: Text(
                          'JURAGAN PUSAT',
                          style: AppText.overline.copyWith(
                              color: _kBrand, fontSize: 10, letterSpacing: 1.5),
                        ),
                      ),
                      const Spacer(),
                      supportWhatsappAsync.when(
                        data: (number) => Flexible(
                          child: InkWell(
                            onTap: () => _openSupportWhatsappEditor(number),
                            child: Container(
                              constraints: const BoxConstraints(maxWidth: 180),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 5),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.white24),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.support_agent_rounded,
                                      color: AppColors.success, size: 14),
                                  const SizedBox(width: 5),
                                  Flexible(
                                    child: Text(
                                      number,
                                      style: AppText.caption.copyWith(
                                          color: Colors.white70, fontSize: 10),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  const SizedBox(width: 4),
                                  const Icon(Icons.edit_rounded,
                                      color: Colors.white38, size: 12),
                                ],
                              ),
                            ),
                          ),
                        ),
                        loading: () => const SizedBox.shrink(),
                        error: (_, __) => const SizedBox.shrink(),
                      ),
                      IconButton(
                        icon: const Icon(Icons.password_rounded,
                            color: Colors.white54, size: 20),
                        tooltip: 'Ubah Kata Sandi',
                        onPressed: _openChangePassword,
                        visualDensity: VisualDensity.compact,
                      ),
                      playStoreUrlAsync.when(
                        data: (url) => Flexible(
                          child: InkWell(
                            onTap: () => _openPlayStoreUrlEditor(url),
                            child: Container(
                              constraints: const BoxConstraints(maxWidth: 180),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 5),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.white24),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.star_rounded,
                                      color: Color(0xFFFBBC04), size: 14),
                                  SizedBox(width: 5),
                                  Flexible(
                                    child: Text(
                                      'Play Store',
                                      style: TextStyle(
                                          color: Colors.white70, fontSize: 10),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  SizedBox(width: 4),
                                  Icon(Icons.edit_rounded,
                                      color: Colors.white38, size: 12),
                                ],
                              ),
                            ),
                          ),
                        ),
                        loading: () => const SizedBox.shrink(),
                        error: (_, __) => const SizedBox.shrink(),
                      ),
                      IconButton(
                        icon: const Icon(Icons.refresh_rounded,
                            color: Colors.white54, size: 20),
                        onPressed: _fetchLicenses,
                        visualDensity: VisualDensity.compact,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              color: _kDark,
              child: Row(
                children: [
                  _TabItem(
                    label: 'LISENSI',
                    isActive: _currentPanel == 'licenses',
                    onTap: () => setState(() => _currentPanel = 'licenses'),
                  ),
                  _TabItem(
                    label: 'PRINT LDR',
                    isActive: _currentPanel == 'remote_print',
                    onTap: () => setState(() => _currentPanel = 'remote_print'),
                  ),
                ],
              ),
            ),
            if (_currentPanel == 'licenses') ...[
              Container(
                color: _kDark,
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Row(
                  children: [
                    _StatChip(
                        label: 'Lisensi',
                        value: '$_totalLicenses',
                        color: const Color(0xFF3B82F6)),
                    const SizedBox(width: 8),
                    _StatChip(
                        label: 'Device',
                        value: '$_activeDevices',
                        color: AppColors.success),
                    const SizedBox(width: 8),
                    _StatChip(
                        label: 'Tersedia',
                        value: '$_freeLicenses',
                        color: const Color(0xFFF59E0B)),
                  ],
                ),
              ),
              Container(
                color: Colors.white,
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            height: 40,
                            decoration: BoxDecoration(
                              color: _kSurface,
                              border: Border.all(color: _kBorder),
                            ),
                            child: TextField(
                              onChanged: (v) =>
                                  setState(() => _searchQuery = v),
                              style: AppText.bodySmall.copyWith(fontSize: 13),
                              decoration: InputDecoration(
                                hintText: 'Cari lisensi...',
                                hintStyle: AppText.caption.copyWith(
                                    color: _kSlateLight.withValues(alpha: 0.5),
                                    fontSize: 12),
                                prefixIcon: const Icon(Icons.search_rounded,
                                    color: _kSlateLight, size: 18),
                                contentPadding:
                                    const EdgeInsets.symmetric(vertical: 10),
                                border: InputBorder.none,
                                prefixIconConstraints:
                                    const BoxConstraints(minWidth: 40),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        SizedBox(
                          height: 40,
                          child: ElevatedButton.icon(
                            onPressed: _generateLicense,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _kBrand,
                              foregroundColor: Colors.white,
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero),
                              elevation: 0,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16),
                            ),
                            icon: const Icon(Icons.add_rounded, size: 18),
                            label: const Text('Terbitkan',
                                style: TextStyle(
                                    fontSize: 12, fontWeight: FontWeight.w600)),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        _FilterChip(
                            label: 'Semua',
                            isActive: _filterType == 'all',
                            onTap: () => setState(() => _filterType = 'all')),
                        const SizedBox(width: 6),
                        _FilterChip(
                            label: 'Aktif',
                            isActive: _filterType == 'active',
                            onTap: () =>
                                setState(() => _filterType = 'active')),
                        const SizedBox(width: 6),
                        _FilterChip(
                            label: 'Tersedia',
                            isActive: _filterType == 'free',
                            onTap: () => setState(() => _filterType = 'free')),
                        const SizedBox(width: 6),
                        _FilterChip(
                            label: 'Nonaktif',
                            isActive: _filterType == 'inactive',
                            onTap: () =>
                                setState(() => _filterType = 'inactive')),
                      ],
                    ),
                  ],
                ),
              ),
              const Divider(height: 1, color: _kBorder),
              Expanded(
                child: _isLoading
                    ? const Center(
                        child: CircularProgressIndicator(color: _kBrand))
                    : filtered.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.inbox_rounded,
                                    color: _kSlateLight, size: 48),
                                const SizedBox(height: 12),
                                Text('Tidak ada lisensi ditemukan',
                                    style: AppText.caption
                                        .copyWith(color: _kSlateLight)),
                              ],
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                            itemCount: filtered.length,
                            itemBuilder: (context, i) {
                              final item = filtered[i];
                              return _LicenseCard(
                                item: item,
                                platformIcon: _platformIcon,
                                onTap: () => _showDetailSheet(item),
                              );
                            },
                          ),
              ),
            ] else ...[
              Expanded(
                child: _RemotePrintPanel(
                  isAutoPrint: _isAutoPrintLdr,
                  onToggleAutoPrint: _saveAutoPrintPref,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _TabItem extends StatelessWidget {
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _TabItem(
      {required this.label, required this.isActive, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: isActive ? _kBrand : Colors.transparent,
                width: 3,
              ),
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: AppText.overline.copyWith(
              color: isActive ? _kBrand : Colors.white54,
              fontSize: 11,
              fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
              letterSpacing: 1.2,
            ),
          ),
        ),
      ),
    );
  }
}

class _RemotePrintPanel extends StatefulWidget {
  final bool isAutoPrint;
  final Function(bool) onToggleAutoPrint;

  const _RemotePrintPanel({
    required this.isAutoPrint,
    required this.onToggleAutoPrint,
  });

  @override
  State<_RemotePrintPanel> createState() => _RemotePrintPanelState();
}

class _RemotePrintPanelState extends State<_RemotePrintPanel> {
  final List<String> _processedIds = [];
  bool _printing = false;
  String _selectedPrinter = '';
  // Android Bluetooth
  String _btPrinterMac = '';
  List<BluetoothInfo> _btPrinters = [];
  bool _scanningBT = false;

  @override
  void initState() {
    super.initState();
    _loadSelectedPrinter();
  }

  Future<void> _loadSelectedPrinter() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        if (Platform.isAndroid) {
          _btPrinterMac = prefs.getString('struk_printerMac') ?? '';
          _selectedPrinter =
              prefs.getString('struk_printerName') ?? 'Belum dipilih';
        } else {
          _selectedPrinter =
              prefs.getString('desktop_printerName') ?? 'Belum dipilih';
        }
      });
    }
  }

  Future<void> _pickAdminPrinter() async {
    if (Platform.isAndroid) {
      _showBtPrinterSheet();
      return;
    }
    try {
      final target = await Printing.pickPrinter(context: context);
      if (target != null) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('desktop_printerName', target.name);
        if (mounted) {
          setState(() => _selectedPrinter = target.name);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Printer: ${target.name}'),
            backgroundColor: const Color(0xFF2E7D32),
            behavior: SnackBarBehavior.floating,
          ));
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Gagal memilih printer. Pastikan printer terhubung.'),
          behavior: SnackBarBehavior.floating,
        ));
      }
    }
  }

  Future<void> _scanBluetooth() async {
    setState(() => _scanningBT = true);
    try {
      await [Permission.bluetoothScan, Permission.bluetoothConnect].request();
      final bool enabled = await PrintBluetoothThermal.bluetoothEnabled;
      if (!enabled) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Aktifkan Bluetooth terlebih dahulu.'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.black87,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ));
        return;
      }
      final list = await PrintBluetoothThermal.pairedBluetooths;
      if (mounted) setState(() => _btPrinters = list);
      if (list.isEmpty && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Tidak ada printer. Pasangkan dulu di Pengaturan HP.'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.black87,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Gagal memindai printer Bluetooth.'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.black87,
        ));
      }
    } finally {
      if (mounted) setState(() => _scanningBT = false);
    }
  }

  void _showBtPrinterSheet() async {
    if (_btPrinters.isEmpty) await _scanBluetooth();
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 8, 4),
                child: Row(
                  children: [
                    const Expanded(
                      child: Text('Pilih Printer Bluetooth',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold)),
                    ),
                    TextButton.icon(
                      onPressed: () async {
                        Navigator.pop(ctx);
                        await _scanBluetooth();
                        if (mounted) _showBtPrinterSheet();
                      },
                      icon: const Icon(Icons.refresh_rounded,
                          size: 16, color: _kBrand),
                      label: const Text('Refresh',
                          style: TextStyle(color: _kBrand, fontSize: 12)),
                    ),
                  ],
                ),
              ),
              if (_btPrinters.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24, horizontal: 16),
                  child: Text(
                    'Tidak ada printer ditemukan.\nPasangkan printer Bluetooth di Pengaturan HP lalu tekan Refresh.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.black45, fontSize: 13),
                  ),
                )
              else
                ..._btPrinters.map((p) => ListTile(
                      leading: Container(
                        width: 36,
                        height: 36,
                        color: _kBrand.withValues(alpha: 0.1),
                        child: const Icon(Icons.print_rounded,
                            color: _kBrand, size: 18),
                      ),
                      title: Text(p.name,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(p.macAdress,
                          style: const TextStyle(
                              fontSize: 11, color: Colors.black38)),
                      trailing: _btPrinterMac == p.macAdress
                          ? const Icon(Icons.check_circle_rounded,
                              color: _kBrand)
                          : null,
                      onTap: () async {
                        final prefs = await SharedPreferences.getInstance();
                        await prefs.setString('struk_printerMac', p.macAdress);
                        await prefs.setString('struk_printerName', p.name);
                        if (mounted) {
                          setState(() {
                            _btPrinterMac = p.macAdress;
                            _selectedPrinter = p.name;
                          });
                        }
                        if (ctx.mounted) Navigator.pop(ctx);
                      },
                    )),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              const Icon(Icons.print_rounded, color: _kBrand, size: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Antrean Print Jarak Jauh',
                        style: AppText.h3.copyWith(fontSize: 15)),
                    Text('Monitoring real-time permintaan cetak',
                        style: AppText.caption.copyWith(fontSize: 11)),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (Platform.isAndroid)
                                const Icon(Icons.bluetooth_rounded,
                                    size: 10, color: _kBrand),
                              if (Platform.isAndroid) const SizedBox(width: 3),
                              Text(
                                _selectedPrinter,
                                style: AppText.caption.copyWith(
                                    fontSize: 10,
                                    color: _kBrand,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          InkWell(
                            onTap: _pickAdminPrinter,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (Platform.isAndroid && _scanningBT)
                                  const SizedBox(
                                    width: 9,
                                    height: 9,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 1.5, color: _kBrand),
                                  )
                                else
                                  Icon(
                                    Platform.isAndroid
                                        ? Icons.bluetooth_searching_rounded
                                        : Icons.print_rounded,
                                    size: 9,
                                    color: _kSlateLight,
                                  ),
                                const SizedBox(width: 3),
                                Text(
                                  Platform.isAndroid
                                      ? 'PILIH BT PRINTER'
                                      : 'PILIH PRINTER',
                                  style: AppText.overline.copyWith(
                                      fontSize: 9,
                                      color: _kSlateLight,
                                      decoration: TextDecoration.underline),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(width: 16),
                      Text('OTOMATIS',
                          style: AppText.overline.copyWith(
                              fontSize: 9,
                              color: widget.isAutoPrint
                                  ? AppColors.success
                                  : _kSlateLight)),
                      const SizedBox(width: 4),
                      Switch(
                        value: widget.isAutoPrint,
                        onChanged: widget.onToggleAutoPrint,
                        activeThumbColor: AppColors.success,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
        const Divider(height: 1, color: _kBorder),
        Expanded(
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: RemotePrintService.streamPendingRequests(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(
                    child: Text('Error: ${snapshot.error}',
                        style: const TextStyle(color: Colors.red)));
              }
              if (!snapshot.hasData) {
                return const Center(
                    child: CircularProgressIndicator(color: _kBrand));
              }

              final requests = snapshot.data!;

              // Handle Auto Print logic
              if (widget.isAutoPrint && requests.isNotEmpty && !_printing) {
                final next = requests.first;
                final id = next['id'].toString();
                if (!_processedIds.contains(id)) {
                  _processedIds.add(id);
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _executePrint(next);
                  });
                }
              }

              if (requests.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.print_disabled_rounded,
                          color: _kSlateLight.withValues(alpha: 0.3), size: 48),
                      const SizedBox(height: 12),
                      Text('Belum ada antrean print',
                          style: AppText.caption.copyWith(color: _kSlateLight)),
                    ],
                  ),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: requests.length,
                itemBuilder: (context, i) {
                  final req = requests[i];
                  final printData = req['print_data'] as Map<String, dynamic>;
                  final createdAt =
                      DateTime.parse(req['created_at'].toString()).toLocal();
                  final timeStr = DateFormat('HH:mm:ss').format(createdAt);

                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: _kBorder),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            color: _kBrand.withValues(alpha: 0.1),
                            child: const Icon(Icons.receipt_long_rounded,
                                color: _kBrand, size: 24),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        req['store_name'] ?? 'Toko Tanpa Nama',
                                        style:
                                            AppText.h3.copyWith(fontSize: 14),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    Text(timeStr,
                                        style: AppText.caption.copyWith(
                                            fontSize: 11,
                                            fontWeight: FontWeight.bold)),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'NO: ${printData['noTransaksi'] ?? '-'}',
                                  style: AppText.caption.copyWith(
                                      fontSize: 12,
                                      color: _kDark,
                                      fontWeight: FontWeight.w600),
                                ),
                                Text(
                                  'Total: Rp ${_formatNumber(printData['grandTotal'] ?? 0)}',
                                  style: AppText.bodySmall.copyWith(
                                      fontSize: 12,
                                      color: AppColors.primaryBrand,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Column(
                            children: [
                              ElevatedButton(
                                onPressed:
                                    _printing ? null : () => _executePrint(req),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: _kBrand,
                                  foregroundColor: Colors.white,
                                  elevation: 0,
                                  shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.zero),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 8),
                                  minimumSize: const Size(80, 36),
                                ),
                                child: const Text('PRINT',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold)),
                              ),
                              const SizedBox(height: 6),
                              InkWell(
                                onTap: () =>
                                    _deleteRequest(req['id'].toString()),
                                child: Text('Hapus',
                                    style: AppText.caption.copyWith(
                                        fontSize: 11, color: Colors.red)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }

  String _formatNumber(dynamic n) {
    if (n == null) return '0';
    final s = n.toString();
    String r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return r;
  }

  Future<void> _executePrint(Map<String, dynamic> req) async {
    if (_printing) return;
    setState(() => _printing = true);

    try {
      final doc = RemotePrintService.jsonToDocument(req['print_data']);
      final bytes = await ReceiptPrintService.buildEscPosBytes(
        document: doc,
        logoPath: '',
      );

      if (Platform.isAndroid) {
        if (_btPrinterMac.isEmpty) {
          throw 'Printer Bluetooth belum dipilih. Ketuk "PILIH BT PRINTER" di atas.';
        }
        final connected = await PrintBluetoothThermal.connect(
          macPrinterAddress: _btPrinterMac,
        );
        if (!connected) {
          throw 'Gagal terhubung ke printer. Pastikan printer menyala & dalam jangkauan.';
        }
        await PrintBluetoothThermal.writeBytes(bytes);
        await PrintBluetoothThermal.disconnect;
      } else {
        final prefs = await SharedPreferences.getInstance();
        final savedName = prefs.getString('desktop_printerName') ?? '';
        if (savedName.isEmpty) {
          throw 'Printer belum dipilih. Ketuk "PILIH PRINTER" di atas.';
        }
        await ReceiptPrintService.printRawEscPosDesktop(
          bytes: bytes,
          printerName: savedName,
        );
      }

      await RemotePrintService.markAsPrinted(req['id'].toString());

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Cetak Berhasil'),
          behavior: SnackBarBehavior.floating,
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(e.toString()),
          behavior: SnackBarBehavior.floating,
        ));
      }
    } finally {
      if (mounted) setState(() => _printing = false);
    }
  }

  Future<void> _deleteRequest(String id) async {
    try {
      await RemotePrintService.deleteRequest(id);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Gagal menghapus data. Silakan coba lagi.')));
      }
    }
  }
}

class _StatChip extends StatelessWidget {
  final String label, value;
  final Color color;
  const _StatChip(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.12),
          border: Border.all(color: color.withValues(alpha: 0.25)),
        ),
        child: Column(
          children: [
            Text(value,
                style: AppText.money.copyWith(color: color, fontSize: 22)),
            const SizedBox(height: 2),
            Text(label.toUpperCase(),
                style: AppText.overline.copyWith(
                    color: color.withValues(alpha: 0.8), fontSize: 9)),
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool isActive;
  final VoidCallback onTap;
  const _FilterChip(
      {required this.label, required this.isActive, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: isActive ? _kBrand : Colors.transparent,
          border: Border.all(color: isActive ? _kBrand : _kBorder),
        ),
        child: Text(
          label,
          style: AppText.caption.copyWith(
            fontSize: 10,
            fontWeight: FontWeight.w600,
            color: isActive ? Colors.white : _kSlateLight,
          ),
        ),
      ),
    );
  }
}

class _CompactField extends StatelessWidget {
  final TextEditingController ctrl;
  final String label;
  final IconData icon;
  final TextInputType type;
  final bool enabled;

  const _CompactField({
    required this.ctrl,
    required this.label,
    required this.icon,
    this.type = TextInputType.text,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: ctrl,
      keyboardType: type,
      enabled: enabled,
      style: AppText.bodySmall.copyWith(fontSize: 13),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: AppText.caption.copyWith(fontSize: 11, color: _kSlateLight),
        prefixIcon: Icon(icon, color: _kBrand, size: 16),
        prefixIconConstraints: const BoxConstraints(minWidth: 36),
        filled: true,
        fillColor: _kSurface,
        border: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: _kBorder)),
        enabledBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: _kBorder)),
        focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: _kBrand, width: 2)),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        isDense: true,
      ),
    );
  }
}

class _InlineCredential extends StatelessWidget {
  final String label, value;
  final VoidCallback onCopy;
  const _InlineCredential(
      {required this.label, required this.value, required this.onCopy});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: const BoxDecoration(
        color: _kSurface,
        border: Border(left: BorderSide(color: _kBrand, width: 3)),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 70,
            child: Text(label,
                style: AppText.overline
                    .copyWith(fontSize: 9, color: _kSlateLight)),
          ),
          Expanded(
            child: SelectableText(
              value,
              style: AppText.h3
                  .copyWith(color: _kBrand, fontSize: 13, letterSpacing: 0.5),
            ),
          ),
          InkWell(
            onTap: () {
              Clipboard.setData(ClipboardData(text: value));
              onCopy();
            },
            child: const Padding(
              padding: EdgeInsets.all(4),
              child: Icon(Icons.content_copy_rounded, size: 14, color: _kBrand),
            ),
          ),
        ],
      ),
    );
  }
}

class _LicenseCard extends StatelessWidget {
  final Map<String, dynamic> item;
  final IconData Function(String) platformIcon;
  final VoidCallback onTap;

  const _LicenseCard(
      {required this.item, required this.platformIcon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final int maxDevices = (item['max_devices'] as int?) ?? 1;
    final int deviceCount = (item['active_device_count'] as int?) ?? 0;
    final String licenseType = (item['license_type'] ?? 'single').toString();
    final String platform = (item['allowed_platforms'] ?? 'all').toString();
    final String? label = item['label']?.toString();
    final bool isActive = item['is_active'] == true;
    final bool hasDevices = deviceCount > 0;

    // Find matching preset color
    Color typeColor = const Color(0xFF3B82F6);
    for (final p in _presets) {
      if (p.type == licenseType || p.key == licenseType) {
        typeColor = p.color;
        break;
      }
    }

    final deviceText =
        maxDevices == 0 ? '$deviceCount / ∞' : '$deviceCount / $maxDevices';

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
            color:
                isActive ? _kBorder : AppColors.danger.withValues(alpha: 0.3)),
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              // Color indicator
              Container(
                width: 4,
                height: 48,
                color: hasDevices ? typeColor : _kBorder,
              ),
              const SizedBox(width: 12),

              // Content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            item['customer_name'] ?? 'Pembeli Umum',
                            style: AppText.h3
                                .copyWith(fontSize: 14, color: _kDark),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (label != null) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            color: typeColor.withValues(alpha: 0.1),
                            child: Text(
                              label,
                              style: AppText.caption.copyWith(
                                  fontSize: 9,
                                  color: typeColor,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item['serial'] ?? '',
                      style: AppText.overline.copyWith(
                          color: _kBrand, fontSize: 9, letterSpacing: 0.5),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        // Device count
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          color: hasDevices
                              ? AppColors.success.withValues(alpha: 0.1)
                              : _kSurface,
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                hasDevices
                                    ? Icons.devices_rounded
                                    : Icons.devices_other_rounded,
                                size: 10,
                                color: hasDevices
                                    ? AppColors.success
                                    : _kSlateLight,
                              ),
                              const SizedBox(width: 3),
                              Text(
                                deviceText,
                                style: AppText.caption.copyWith(
                                  fontSize: 9,
                                  fontWeight: FontWeight.w700,
                                  color: hasDevices
                                      ? AppColors.success
                                      : _kSlateLight,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 6),
                        // Type
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          color: typeColor.withValues(alpha: 0.08),
                          child: Text(
                            licenseType.toUpperCase(),
                            style: AppText.caption.copyWith(
                                fontSize: 8,
                                color: typeColor,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.5),
                          ),
                        ),
                        const SizedBox(width: 6),
                        // Platform
                        Icon(platformIcon(platform),
                            size: 14, color: _kSlateLight),
                        if (item['can_remote_print'] == true) ...[
                          const SizedBox(width: 8),
                          const Icon(Icons.print_rounded,
                              size: 14, color: AppColors.success),
                        ],
                      ],
                    ),
                  ],
                ),
              ),

              const Icon(Icons.chevron_right_rounded,
                  color: _kBorder, size: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class _LicenseDetailSheet extends StatefulWidget {
  final Map<String, dynamic> item;
  final String? generatedPassword;
  final String date;
  final int maxDevices;
  final int deviceCount;
  final String licenseType;
  final String allowedPlatforms;
  final bool canRemotePrint;
  final String? label;
  final bool isActive;
  final bool isTrial;
  final VoidCallback onCopyInfo;
  final void Function(String deviceId) onResetDevice;
  final VoidCallback onResetAll;
  final void Function(Map<String, dynamic> config) onUpdateConfig;

  const _LicenseDetailSheet({
    required this.item,
    required this.generatedPassword,
    required this.date,
    required this.maxDevices,
    required this.deviceCount,
    required this.licenseType,
    required this.allowedPlatforms,
    required this.canRemotePrint,
    required this.label,
    required this.isActive,
    required this.isTrial,
    required this.onCopyInfo,
    required this.onResetDevice,
    required this.onResetAll,
    required this.onUpdateConfig,
  });

  @override
  State<_LicenseDetailSheet> createState() => _LicenseDetailSheetState();
}

class _LicenseDetailSheetState extends State<_LicenseDetailSheet> {
  bool _isLoadingDevices = true;
  List<Map<String, dynamic>> _devices = [];
  late int _selectedPreset;
  late String _selectedPlatform;
  late TextEditingController _labelCtrl;
  late bool _canRemotePrint;
  late bool _isTrial;
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    _labelCtrl = TextEditingController(text: widget.label ?? '');
    _selectedPlatform = widget.allowedPlatforms;
    _canRemotePrint = widget.canRemotePrint;
    _isTrial = widget.isTrial;

    // Find matching preset
    _selectedPreset = 0;
    for (int i = 0; i < _presets.length; i++) {
      if (_presets[i].maxDevices == widget.maxDevices) {
        _selectedPreset = i;
        break;
      }
    }
    _loadDevices();
  }

  @override
  void dispose() {
    _labelCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadDevices() async {
    try {
      final devices = await AdminLicenseService.fetchLicenseDevices(
        widget.item['id'].toString(),
      );
      if (mounted) {
        setState(() {
          _devices = devices;
          _isLoadingDevices = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoadingDevices = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final preset = _presets[_selectedPreset];
    final bottomPad = MediaQuery.of(context).padding.bottom;

    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.85,
      ),
      decoration: const BoxDecoration(color: Colors.white),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: _kBorder)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  color: preset.color.withValues(alpha: 0.1),
                  child: Icon(preset.icon, color: preset.color, size: 22),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.item['customer_name'] ?? 'Pembeli Umum',
                        style: AppText.h2.copyWith(fontSize: 16, color: _kDark),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${widget.item['serial']} -- ${widget.date}',
                        style: AppText.caption
                            .copyWith(fontSize: 10, color: _kSlateLight),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  color: widget.isActive
                      ? AppColors.success.withValues(alpha: 0.1)
                      : AppColors.danger.withValues(alpha: 0.1),
                  child: Text(
                    widget.isActive ? 'AKTIF' : 'NONAKTIF',
                    style: AppText.overline.copyWith(
                      fontSize: 9,
                      color: widget.isActive
                          ? AppColors.success
                          : AppColors.danger,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Flexible(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(20, 16, 20, bottomPad + 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (widget.generatedPassword != null) ...[
                    _InlineCredential(
                      label: 'PASSWORD',
                      value: widget.generatedPassword!,
                      onCopy: () {},
                    ),
                    const SizedBox(height: 12),
                  ],
                  Row(
                    children: [
                      Text('PENGATURAN LISENSI',
                          style: AppText.overline
                              .copyWith(fontSize: 10, color: _kSlateLight)),
                      const Spacer(),
                      GestureDetector(
                        onTap: () => setState(() => _isEditing = !_isEditing),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          color: _isEditing
                              ? _kBrand.withValues(alpha: 0.1)
                              : _kSurface,
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                  _isEditing ? Icons.close : Icons.edit_rounded,
                                  size: 12,
                                  color: _isEditing ? _kBrand : _kSlateLight),
                              const SizedBox(width: 4),
                              Text(
                                _isEditing ? 'Tutup' : 'Ubah',
                                style: AppText.caption.copyWith(
                                    fontSize: 10,
                                    color: _isEditing ? _kBrand : _kSlateLight),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  if (_isEditing) ...[
                    // Editable preset selector
                    Text('Tipe & Kuota Device',
                        style: AppText.caption
                            .copyWith(fontSize: 11, color: _kSlate)),
                    const SizedBox(height: 6),
                    Row(
                      children: List.generate(_presets.length, (i) {
                        final p = _presets[i];
                        final isSelected = i == _selectedPreset;
                        return Expanded(
                          child: GestureDetector(
                            onTap: () => setState(() => _selectedPreset = i),
                            child: Container(
                              margin: EdgeInsets.only(
                                  right: i < _presets.length - 1 ? 6 : 0),
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? p.color.withValues(alpha: 0.12)
                                    : _kSurface,
                                border: Border.all(
                                    color: isSelected ? p.color : _kBorder,
                                    width: isSelected ? 2 : 1),
                              ),
                              child: Column(
                                children: [
                                  Text(
                                    p.maxDevices == 0 ? '∞' : '${p.maxDevices}',
                                    style: AppText.h3.copyWith(
                                        fontSize: 14,
                                        color: isSelected ? p.color : _kSlate),
                                  ),
                                  Text(p.label,
                                      style: AppText.caption.copyWith(
                                          fontSize: 8,
                                          color: isSelected
                                              ? p.color
                                              : _kSlateLight)),
                                ],
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 12),
                    Text('Platform',
                        style: AppText.caption
                            .copyWith(fontSize: 11, color: _kSlate)),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      children: _platformOptions.map((opt) {
                        final isSelected = _selectedPlatform == opt['key'];
                        return GestureDetector(
                          onTap: () => setState(
                              () => _selectedPlatform = opt['key'] as String),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: isSelected ? _kBrand : _kSurface,
                              border: Border.all(
                                  color: isSelected ? _kBrand : _kBorder),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(opt['icon'] as IconData,
                                    size: 12,
                                    color: isSelected
                                        ? Colors.white
                                        : _kSlateLight),
                                const SizedBox(width: 4),
                                Text(opt['label'] as String,
                                    style: AppText.caption.copyWith(
                                        fontSize: 10,
                                        color: isSelected
                                            ? Colors.white
                                            : _kSlate)),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 12),
                    _CompactField(
                        ctrl: _labelCtrl,
                        label: 'Label',
                        icon: Icons.label_outline_rounded),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: _canRemotePrint
                            ? AppColors.success.withValues(alpha: 0.05)
                            : _kSurface,
                        border: Border.all(
                            color: _canRemotePrint
                                ? AppColors.success.withValues(alpha: 0.2)
                                : _kBorder),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.print_rounded,
                              size: 18,
                              color: _canRemotePrint
                                  ? AppColors.success
                                  : _kSlateLight),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Fitur Remote Print',
                                    style: AppText.caption.copyWith(
                                        fontSize: 12,
                                        color: _kDark,
                                        fontWeight: FontWeight.w600)),
                                Text('Izinkan akun ini menggunakan Print LDR',
                                    style: AppText.caption.copyWith(
                                        fontSize: 10, color: _kSlateLight)),
                              ],
                            ),
                          ),
                          Switch(
                            value: _canRemotePrint,
                            onChanged: (v) =>
                                setState(() => _canRemotePrint = v),
                            activeThumbColor: AppColors.success,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: _isTrial
                            ? Colors.orange.withValues(alpha: 0.05)
                            : _kSurface,
                        border: Border.all(
                            color: _isTrial
                                ? Colors.orange.withValues(alpha: 0.2)
                                : _kBorder),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.timer_rounded,
                              size: 18,
                              color: _isTrial ? Colors.orange : _kSlateLight),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Akun Trial',
                                    style: AppText.caption.copyWith(
                                        fontSize: 12,
                                        color: _kDark,
                                        fontWeight: FontWeight.w600)),
                                Text('Akses demo otomatis & Print LDR terbatas',
                                    style: AppText.caption.copyWith(
                                        fontSize: 10, color: _kSlateLight)),
                              ],
                            ),
                          ),
                          Switch(
                            value: _isTrial,
                            onChanged: (v) => setState(() => _isTrial = v),
                            activeThumbColor: Colors.orange,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          final p = _presets[_selectedPreset];
                          final currentExpiredAt =
                              widget.item['expired_at']?.toString().trim();
                          final needsTrialExpiry = _isTrial &&
                              (!widget.isTrial ||
                                  currentExpiredAt == null ||
                                  currentExpiredAt.isEmpty ||
                                  currentExpiredAt.toLowerCase() == 'null');
                          widget.onUpdateConfig({
                            'max_devices': p.maxDevices,
                            'license_type': p.type,
                            'allowed_platforms': _selectedPlatform,
                            'can_remote_print': _canRemotePrint,
                            'is_trial': _isTrial,
                            if (needsTrialExpiry)
                              'expired_at': DateTime.now()
                                  .toUtc()
                                  .add(const Duration(hours: 24))
                                  .toIso8601String(),
                            'label': _labelCtrl.text.trim(),
                          });
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _kBrand,
                          foregroundColor: Colors.white,
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          elevation: 0,
                        ),
                        icon: const Icon(Icons.save_rounded, size: 16),
                        label: const Text('Simpan Perubahan',
                            style: TextStyle(fontSize: 12)),
                      ),
                    ),
                    const SizedBox(height: 16),
                  ] else ...[
                    // Read-only config display
                    Container(
                      padding: const EdgeInsets.all(12),
                      color: _kSurface,
                      child: Row(
                        children: [
                          _ConfigBadge(
                              icon: preset.icon,
                              label: preset.label,
                              color: preset.color),
                          const SizedBox(width: 8),
                          _ConfigBadge(
                            icon: Icons.devices_rounded,
                            label: widget.maxDevices == 0
                                ? 'Unlimited'
                                : '${widget.maxDevices} Device',
                            color: _kSlate,
                          ),
                          const SizedBox(width: 8),
                          _ConfigBadge(
                            icon: Icons.print_rounded,
                            label: widget.canRemotePrint
                                ? 'Remote Print ON'
                                : 'Remote Print OFF',
                            color: widget.canRemotePrint
                                ? AppColors.success
                                : _kSlateLight,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                  Row(
                    children: [
                      Text(
                        'PERANGKAT TERDAFTAR',
                        style: AppText.overline
                            .copyWith(fontSize: 10, color: _kSlateLight),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        color: AppColors.success.withValues(alpha: 0.1),
                        child: Text(
                          '${_devices.length}${widget.maxDevices > 0 ? " / ${widget.maxDevices}" : ""}',
                          style: AppText.caption.copyWith(
                              fontSize: 9,
                              color: AppColors.success,
                              fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (_isLoadingDevices)
                    const Padding(
                      padding: EdgeInsets.all(16),
                      child: Center(
                          child: CircularProgressIndicator(
                              color: _kBrand, strokeWidth: 2)),
                    )
                  else if (_devices.isEmpty)
                    Container(
                      padding: const EdgeInsets.all(20),
                      color: _kSurface,
                      child: Center(
                        child: Column(
                          children: [
                            const Icon(Icons.devices_other_rounded,
                                color: _kSlateLight, size: 28),
                            const SizedBox(height: 6),
                            Text(
                              'Belum ada perangkat terdaftar',
                              style: AppText.caption
                                  .copyWith(color: _kSlateLight, fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    ...List.generate(_devices.length, (i) {
                      final device = _devices[i];
                      final isDesktop = (device['platform'] ?? '')
                          .toString()
                          .contains('desktop');
                      final activatedAt = device['activated_at'] != null
                          ? DateFormat('dd MMM yy HH:mm').format(
                              DateTime.parse(device['activated_at'].toString()))
                          : '-';
                      return Container(
                        margin: const EdgeInsets.only(bottom: 6),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: _kSurface,
                          border: Border.all(color: _kBorder),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              isDesktop
                                  ? Icons.desktop_windows_rounded
                                  : Icons.phone_android_rounded,
                              size: 18,
                              color: isDesktop
                                  ? const Color(0xFF8B5CF6)
                                  : const Color(0xFF3B82F6),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _truncateDeviceId(
                                        device['device_id'] ?? ''),
                                    style: AppText.caption.copyWith(
                                        fontSize: 10,
                                        color: _kDark,
                                        fontWeight: FontWeight.w600),
                                  ),
                                  Text(
                                    '${(device['platform'] ?? 'unknown').toString().toUpperCase()} -- $activatedAt',
                                    style: AppText.caption.copyWith(
                                        fontSize: 9, color: _kSlateLight),
                                  ),
                                ],
                              ),
                            ),
                            InkWell(
                              onTap: () => widget.onResetDevice(
                                  device['device_id'].toString()),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 4),
                                color: AppColors.danger.withValues(alpha: 0.08),
                                child: Text(
                                  'Hapus',
                                  style: AppText.caption.copyWith(
                                      fontSize: 9,
                                      color: AppColors.danger,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: widget.onCopyInfo,
                          style: OutlinedButton.styleFrom(
                            foregroundColor: _kSlate,
                            side: const BorderSide(color: _kBorder),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                          ),
                          icon: const Icon(Icons.copy_all_rounded, size: 14),
                          label: const Text('Salin Info',
                              style: TextStyle(fontSize: 11)),
                        ),
                      ),
                      if (_devices.isNotEmpty) ...[
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: widget.onResetAll,
                            style: ElevatedButton.styleFrom(
                              backgroundColor:
                                  AppColors.danger.withValues(alpha: 0.08),
                              foregroundColor: AppColors.danger,
                              elevation: 0,
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero),
                            ),
                            icon: const Icon(Icons.phonelink_erase_rounded,
                                size: 14),
                            label: const Text('Reset Semua',
                                style: TextStyle(fontSize: 11)),
                          ),
                        ),
                      ],
                    ],
                  ),
                  if ((widget.item['customer_email'] ?? '')
                          .toString()
                          .isNotEmpty ||
                      (widget.item['customer_phone'] ?? '')
                          .toString()
                          .isNotEmpty) ...[
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(10),
                      color: _kSurface,
                      child: Column(
                        children: [
                          if ((widget.item['customer_email'] ?? '')
                              .toString()
                              .isNotEmpty)
                            _SmallInfoRow(
                                icon: Icons.email_rounded,
                                text: widget.item['customer_email'].toString()),
                          if ((widget.item['customer_phone'] ?? '')
                              .toString()
                              .isNotEmpty)
                            _SmallInfoRow(
                                icon: Icons.phone_rounded,
                                text: widget.item['customer_phone'].toString()),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _truncateDeviceId(String id) {
    if (id.length > 24) return '${id.substring(0, 24)}...';
    return id;
  }
}

class _ConfigBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  const _ConfigBadge(
      {required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(label,
              style: AppText.caption.copyWith(
                  fontSize: 9, color: color, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _SmallInfoRow extends StatelessWidget {
  final IconData icon;
  final String text;
  const _SmallInfoRow({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Icon(icon, size: 14, color: _kSlateLight),
          const SizedBox(width: 8),
          Expanded(
              child: Text(text,
                  style:
                      AppText.caption.copyWith(fontSize: 11, color: _kSlate))),
        ],
      ),
    );
  }
}

