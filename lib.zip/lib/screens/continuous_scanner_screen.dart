import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../core/theme.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../services/scan_feedback_service.dart';
import '../database/db_helper.dart';
import 'package:intl/intl.dart';
import 'package:google_fonts/google_fonts.dart';

String _formatTransactionItemQty(TransactionItem item) {
  final qty = item.qty
      .toStringAsFixed(2)
      .replaceAll(RegExp(r'0+$'), '')
      .replaceAll(RegExp(r'\.$'), '')
      .replaceAll('.', ',');
  final unit = item.unit?.trim();
  if (unit != null && unit.isNotEmpty) return '$qty $unit';
  return '${qty}x';
}

class ContinuousScannerScreen extends ConsumerStatefulWidget {
  const ContinuousScannerScreen({super.key});

  @override
  ConsumerState<ContinuousScannerScreen> createState() =>
      _ContinuousScannerScreenState();
}

class _ContinuousScannerScreenState
    extends ConsumerState<ContinuousScannerScreen> {
  late MobileScannerController _controller;
  DateTime? _lastScanTime;
  String? _lastScannedBarcode;

  // Status banner
  String? _statusMessage;
  Color _statusColor = Colors.green;
  IconData _statusIcon = Icons.check_circle_rounded;

  @override
  void initState() {
    super.initState();
    _controller = MobileScannerController(
      detectionSpeed: DetectionSpeed.normal,
      facing: CameraFacing.back,
      formats: const [
        BarcodeFormat.ean13,
        BarcodeFormat.ean8,
        BarcodeFormat.upcA,
        BarcodeFormat.upcE,
        BarcodeFormat.code39,
        BarcodeFormat.code93,
        BarcodeFormat.code128,
        BarcodeFormat.qrCode,
      ],
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _fmt(int n) {
    if (n == 0) return '0';
    String s = n.toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return r;
  }

  bool _isBarcodeMatch(String rawQuery, String? dbBarcode) {
    if (dbBarcode == null || dbBarcode.trim().isEmpty) return false;

    final q = rawQuery.toLowerCase();
    final db = dbBarcode.replaceAll(RegExp(r'\s+'), '').toLowerCase();

    if (q == db) return true;

    // Abaikan awalan '0' (kasus format EAN-13 vs UPC-A)
    final qNum = q.replaceAll(RegExp(r'^0+'), '');
    final dbNum = db.replaceAll(RegExp(r'^0+'), '');

    if (qNum.isNotEmpty && qNum == dbNum) return true;

    return false;
  }

  void _showStatusBanner(String message,
      {Color color = Colors.green,
      IconData icon = Icons.check_circle_rounded}) {
    if (!mounted) return;
    setState(() {
      _statusMessage = message;
      _statusColor = color;
      _statusIcon = icon;
    });
    // Auto-hide after 3 seconds
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() => _statusMessage = null);
      }
    });
  }

  void _onDetect(BarcodeCapture capture) {
    if (capture.barcodes.isEmpty) return;

    final raw =
        capture.barcodes.first.rawValue ?? capture.barcodes.first.displayValue;
    if (raw == null || raw.trim().isEmpty) return;

    // Normalize query: remove spaces and common separators like hyphens
    final query = raw.trim().replaceAll(RegExp(r'[\s\-\_]+'), '');
    if (query.isEmpty) return;

    // Debounce: reduce to 1 second for better UX
    final now = DateTime.now();
    if (_lastScannedBarcode == query && _lastScanTime != null) {
      final diff = now.difference(_lastScanTime!).inMilliseconds;
      if (diff < 1000) return;
    }

    _lastScannedBarcode = query;
    _lastScanTime = now;

    // Auto-detect: Transaction or Product
    _tryHandleScan(query);
  }

  Future<void> _tryHandleScan(String query) async {
    // 1. Check if it's a Transaction Code (receipt barcode)
    final tx = await DBHelper.instance.getTransactionByCode(query);
    if (tx != null) {
      HapticFeedback.heavyImpact();
      final useTTS = ref.read(notificationSettingsProvider).useTTS;
      ScanFeedbackService.instance
          .playProductFound(useTts: useTTS, productName: 'Transaksi ditemukan');

      if (mounted) {
        _showTransactionDetail(tx);
      }
      return;
    }

    // 2. Check if it's a Product barcode/SKU
    final allProducts = ref.read(productsProvider);
    try {
      final product = allProducts.firstWhere((p) =>
          (_isBarcodeMatch(query, p.barcode) ||
              _isBarcodeMatch(query, p.sku)) &&
          p.isExtra != 1);

      // Auto-add to cart silently
      final success = ref.read(cartProvider.notifier).addItem(product, qty: 1);
      final useTTS = ref.read(notificationSettingsProvider).useTTS;

      if (success) {
        if (!mounted) return;
        ScanFeedbackService.instance.playProductFound(
          useTts: useTTS,
          productName: product.name,
        );
        HapticFeedback.heavyImpact();
        _showStatusBanner(
          '${product.name} berhasil ditambahkan',
          color: Colors.green.shade700,
          icon: Icons.check_circle_rounded,
        );
      } else {
        if (!mounted) return;
        HapticFeedback.vibrate();
        _showStatusBanner(
          'Stok ${product.name} habis!',
          color: Colors.red.shade700,
          icon: Icons.error_outline_rounded,
        );
      }
      return;
    } catch (_) {}

    // 3. Check if it's a Customer barcode/phone/memberCode
    final allCustomers = ref.read(customersProvider);
    try {
      final customer = allCustomers.firstWhere((c) =>
          _isBarcodeMatch(query, c.memberCode) ||
          _isBarcodeMatch(query, c.phone));

      ref.read(selectedCustomerProvider.notifier).updateState(customer);
      final useTTS = ref.read(notificationSettingsProvider).useTTS;

      if (mounted) {
        ScanFeedbackService.instance.playProductFound(
          useTts: useTTS,
          productName: customer.name,
        );
        HapticFeedback.heavyImpact();
        _showStatusBanner(
          'Pelanggan: ${customer.name}',
          color: const Color(0xFF1976D2),
          icon: Icons.person_rounded,
        );
      }
      return;
    } catch (_) {
      if (!mounted) return;
      final useTTS = ref.read(notificationSettingsProvider).useTTS;
      ScanFeedbackService.instance.playNotFound(useTts: useTTS);
      HapticFeedback.vibrate();
      _showStatusBanner(
        'Kode tidak dikenali: $query',
        color: Colors.red.shade700,
        icon: Icons.search_off_rounded,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final cart = ref.watch(cartProvider);
    final totalItems = cart.values.fold(0.0, (s, v) => s + v);
    final screenHeight = MediaQuery.of(context).size.height;
    final scanInstructionTop = (screenHeight / 2) + 154;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Full-screen Camera Preview
          Positioned.fill(
            child: MobileScanner(
              controller: _controller,
              onDetect: _onDetect,
            ),
          ),

          // Top AppBar overlay
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: AppBar(
              backgroundColor: Colors.black.withValues(alpha: 0.5),
              foregroundColor: Colors.white,
              elevation: 0,
              title: const Text('Scan Barcode',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              actions: [
                IconButton(
                  icon: const Icon(Icons.flash_on),
                  onPressed: () => _controller.toggleTorch(),
                ),
              ],
            ),
          ),

          // Center Focus Box (Viewfinder Style)
          Center(
            child: Stack(
              children: [
                Container(
                  width: 240,
                  height: 240,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                // Corners
                ...[
                  // Top Left
                  Positioned(
                    top: 0,
                    left: 0,
                    child: Container(
                      width: 24,
                      height: 24,
                      decoration: const BoxDecoration(
                        border: Border(
                          top: BorderSide(color: Colors.white, width: 4),
                          left: BorderSide(color: Colors.white, width: 4),
                        ),
                      ),
                    ),
                  ),
                  // Top Right
                  Positioned(
                    top: 0,
                    right: 0,
                    child: Container(
                      width: 24,
                      height: 24,
                      decoration: const BoxDecoration(
                        border: Border(
                          top: BorderSide(color: Colors.white, width: 4),
                          right: BorderSide(color: Colors.white, width: 4),
                        ),
                      ),
                    ),
                  ),
                  // Bottom Left
                  Positioned(
                    bottom: 0,
                    left: 0,
                    child: Container(
                      width: 24,
                      height: 24,
                      decoration: const BoxDecoration(
                        border: Border(
                          bottom: BorderSide(color: Colors.white, width: 4),
                          left: BorderSide(color: Colors.white, width: 4),
                        ),
                      ),
                    ),
                  ),
                  // Bottom Right
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 24,
                      height: 24,
                      decoration: const BoxDecoration(
                        border: Border(
                          bottom: BorderSide(color: Colors.white, width: 4),
                          right: BorderSide(color: Colors.white, width: 4),
                        ),
                      ),
                    ),
                  ),
                ],
                // Scanning Line Animation (Simplified for now)
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  child: _ScanningLine(),
                ),
              ],
            ),
          ),

          // Instruction text
          Positioned(
            left: 0,
            right: 0,
            top: scanInstructionTop,
            child: Container(
              color: Colors.black.withValues(alpha: 0.5),
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: const Text(
                'Arahkan kamera ke barcode layanan\natau struk pelanggan',
                textAlign: TextAlign.center,
                style:
                    TextStyle(color: Colors.white, fontSize: 13, height: 1.4),
              ),
            ),
          ),

          // Status Banner (animated)
          if (_statusMessage != null)
            Positioned(
              left: 20,
              right: 20,
              bottom: totalItems > 0
                  ? MediaQuery.of(context).padding.bottom + 90
                  : MediaQuery.of(context).padding.bottom + 30,
              child: AnimatedOpacity(
                opacity: _statusMessage != null ? 1.0 : 0.0,
                duration: const Duration(milliseconds: 300),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  decoration: BoxDecoration(
                    color: _statusColor,
                    borderRadius: BorderRadius.zero,
                    boxShadow: [
                      BoxShadow(
                        color: _statusColor.withValues(alpha: 0.4),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Icon(_statusIcon, color: Colors.white, size: 22),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _statusMessage!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

          // Bottom: Cart indicator (only shows when items exist)
          if (totalItems > 0)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.fromLTRB(
                    20, 14, 20, MediaQuery.of(context).padding.bottom + 14),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.primaryBrand.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Icon(Icons.handyman_rounded,
                          color: AppColors.primaryBrand, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '${totalItems.toStringAsFixed(0)} layanan dipilih',
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 14),
                          ),
                          Text(
                            'Rp${_fmt(cart.entries.fold(0, (s, e) => s + (e.key.getPrice(e.value) * e.value).round()))}',
                            style: const TextStyle(
                                fontSize: 13,
                                color: AppColors.primaryBrand,
                                fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () => Navigator.pop(context, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryBrand,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 28, vertical: 14),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: const Text('LANJUT',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  void _showTransactionDetail(Transaction tx) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _TransactionDetailSheet(tx: tx),
    );
  }
}

class _ScanPickupEstimate {
  final String text;
  final String? note;
  final bool isConfigured;

  const _ScanPickupEstimate({
    required this.text,
    this.note,
    this.isConfigured = true,
  });
}

class _TransactionDetailSheet extends StatefulWidget {
  final Transaction tx;
  const _TransactionDetailSheet({required this.tx});

  @override
  State<_TransactionDetailSheet> createState() =>
      _TransactionDetailSheetState();
}

class _TransactionDetailSheetState extends State<_TransactionDetailSheet> {
  late final Future<_ScanPickupEstimate> _pickupEstimateFuture;

  Transaction get tx => widget.tx;

  @override
  void initState() {
    super.initState();
    _pickupEstimateFuture = _resolvePickupEstimate();
  }

  String _fmt(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp $buf';
  }

  String _durationLabel(int hours) {
    if (hours <= 0) return '';
    if (hours < 24) return '$hours jam';

    final days = hours ~/ 24;
    final remainingHours = hours % 24;
    if (remainingHours == 0) return '$days hari';
    return '$days hari $remainingHours jam';
  }

  Future<_ScanPickupEstimate> _resolvePickupEstimate() async {
    final rawPickup = tx.pickupSchedule?.trim() ?? '';
    final created = DateTime.tryParse(tx.createdAt);

    if (rawPickup.isNotEmpty) {
      final pickupAt = DateTime.tryParse(rawPickup);
      if (pickupAt == null) {
        return _ScanPickupEstimate(text: rawPickup);
      }

      String suffix = '';
      if (created != null) {
        final hours = pickupAt.difference(created).inHours;
        if (hours > 0) suffix = ' (Estimasi ${_durationLabel(hours)})';
      }

      return _ScanPickupEstimate(
        text:
            '${DateFormat('EEEE, dd MMMM yyyy, HH:mm', 'id').format(pickupAt)}$suffix',
      );
    }

    if (tx.id == null || created == null) {
      return const _ScanPickupEstimate(
        text: 'Estimasi belum diatur',
        note:
            'Atur estimasi proses pada layanan atau kategori agar jadwal pengambilan otomatis akurat.',
        isConfigured: false,
      );
    }

    final items = await DBHelper.instance.getTransactionItems(tx.id!);
    final categories = await DBHelper.instance.getCategories();
    final categoryDurations = {
      for (final category in categories)
        if (category.id != null) category.id!: category.durationHours,
    };

    int maxDuration = 0;
    String? durationSource;
    for (final item in items) {
      final product = await DBHelper.instance.getProductById(item.productId);
      if (product == null) continue;

      var duration = product.durationHours;
      if (duration <= 0) {
        duration = categoryDurations[product.categoryId] ?? 0;
      }

      if (duration > maxDuration) {
        maxDuration = duration;
        durationSource = product.name;
      }
    }

    if (maxDuration <= 0) {
      return const _ScanPickupEstimate(
        text: 'Estimasi belum diatur',
        note:
            'Atur estimasi proses pada layanan atau kategori agar jadwal pengambilan otomatis akurat.',
        isConfigured: false,
      );
    }

    final pickupAt = created.add(Duration(hours: maxDuration));
    return _ScanPickupEstimate(
      text:
          '${DateFormat('EEEE, dd MMMM yyyy, HH:mm', 'id').format(pickupAt)} (Estimasi ${_durationLabel(maxDuration)})',
      note: durationSource == null
          ? 'Berdasarkan estimasi layanan.'
          : 'Berdasarkan estimasi layanan: $durationSource.',
    );
  }

  @override
  Widget build(BuildContext context) {
    final statusColor = _servisStatusColor(tx.servisStatus);

    final createdDt = DateTime.tryParse(tx.createdAt);
    final createdStr = createdDt != null
        ? DateFormat('dd MMM yyyy, HH:mm', 'id').format(createdDt)
        : tx.createdAt;

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      padding: EdgeInsets.fromLTRB(
          20, 20, 20, MediaQuery.of(context).padding.bottom + 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with close button
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    color: AppColors.primaryBrand.withValues(alpha: 0.1),
                    child: Text(
                      'DATA PELANGGAN',
                      style: GoogleFonts.inter(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: AppColors.primaryBrand,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    tx.transactionCode ?? 'TRX-${tx.id}',
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      color: Colors.black87,
                    ),
                  ),
                  Text(
                    createdStr,
                    style:
                        GoogleFonts.inter(fontSize: 12, color: Colors.black45),
                  ),
                ],
              ),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close_rounded),
                style:
                    IconButton.styleFrom(backgroundColor: Colors.grey.shade100),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Customer name + Weight - prominent
          FutureBuilder<List<TransactionItem>>(
            future: DBHelper.instance.getTransactionItems(tx.id!),
            builder: (context, snapshot) {
              final items = snapshot.data ?? [];
              double totalKg = 0;
              for (var it in items) {
                if (it.unit?.toLowerCase() == 'kg') {
                  totalKg += it.qty;
                }
              }
              final kgStr = totalKg > 0
                  ? (totalKg % 1 == 0
                      ? totalKg.toInt().toString()
                      : totalKg.toStringAsFixed(1))
                  : null;

              return Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.primaryBrand.withValues(alpha: 0.05),
                  border: Border.all(
                      color: AppColors.primaryBrand.withValues(alpha: 0.1)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        color: AppColors.primaryBrand.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Icon(Icons.person_rounded,
                          color: AppColors.primaryBrand, size: 28),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            tx.customerName ?? 'Pelanggan Umum',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: const Color(0xFF1E293B),
                            ),
                          ),
                          if (tx.orderType != null && tx.orderType!.isNotEmpty)
                            Text(
                              tx.orderType!,
                              style: GoogleFonts.inter(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: AppColors.primaryBrand,
                                letterSpacing: 0.5,
                              ),
                            ),
                        ],
                      ),
                    ),
                    if (kgStr != null) ...[
                      const SizedBox(width: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          color: AppColors.primaryBrand,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              kgStr,
                              style: GoogleFonts.poppins(
                                fontSize: 24,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                                height: 1.1,
                              ),
                            ),
                            Text(
                              'KG',
                              style: GoogleFonts.inter(
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                color: Colors.white.withValues(alpha: 0.8),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 16),

          // Status row
          Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  color: statusColor.withValues(alpha: 0.08),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('STATUS servis',
                          style: GoogleFonts.inter(
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: Colors.black38,
                              letterSpacing: 1)),
                      const SizedBox(height: 4),
                      Text(tx.servisStatus.toUpperCase(),
                          style: GoogleFonts.poppins(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: statusColor)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  color:
                      (tx.paymentStatus == 'Lunas' ? Colors.green : Colors.red)
                          .withValues(alpha: 0.08),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('PEMBAYARAN',
                          style: GoogleFonts.inter(
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: Colors.black38,
                              letterSpacing: 1)),
                      const SizedBox(height: 4),
                      Text(
                        tx.paymentStatus?.toUpperCase() ?? 'PENDING',
                        style: GoogleFonts.poppins(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: tx.paymentStatus == 'Lunas'
                                ? Colors.green.shade700
                                : Colors.red.shade700),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Estimasi Selesai / Jadwal Ambil Card
          FutureBuilder<_ScanPickupEstimate>(
            future: _pickupEstimateFuture,
            builder: (context, snapshot) {
              final estimate = snapshot.data;
              final isConfigured = estimate?.isConfigured ?? true;
              final accentColor = isConfigured
                  ? const Color(0xFF2563EB)
                  : const Color(0xFF64748B);

              return Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  border: Border(
                    left: BorderSide(color: accentColor, width: 4),
                    top: const BorderSide(color: Color(0xFFE2E8F0)),
                    right: const BorderSide(color: Color(0xFFE2E8F0)),
                    bottom: const BorderSide(color: Color(0xFFE2E8F0)),
                  ),
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(
                  children: [
                    Icon(
                      isConfigured
                          ? Icons.alarm_on_rounded
                          : Icons.schedule_rounded,
                      color: accentColor,
                      size: 24,
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'ESTIMASI PENGAMBILAN',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                              color: const Color(0xFF64748B),
                              letterSpacing: 1.1,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            estimate?.text ?? 'Menghitung estimasi...',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              color: const Color(0xFF1E293B),
                            ),
                          ),
                          if ((estimate?.note ?? '').isNotEmpty) ...[
                            const SizedBox(height: 3),
                            Text(
                              estimate!.note!,
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 10,
                                color: isConfigured
                                    ? const Color(0xFF64748B)
                                    : const Color(0xFFEA580C),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),

          // Service items
          Text(
            'RINCIAN LAYANAN',
            style: GoogleFonts.inter(
                fontSize: 10,
                fontWeight: FontWeight.bold,
                color: Colors.black38,
                letterSpacing: 1),
          ),
          const SizedBox(height: 10),
          FutureBuilder<List<TransactionItem>>(
            future: DBHelper.instance.getTransactionItems(tx.id!),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(child: LinearProgressIndicator());
              }
              final items = snapshot.data!;
              return Column(
                children: items
                    .map((item) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Row(
                            children: [
                              Text(
                                '${_formatTransactionItemQty(item)} ',
                                style: GoogleFonts.inter(
                                    fontWeight: FontWeight.bold, fontSize: 13),
                              ),
                              Expanded(
                                  child: Text(item.productName,
                                      style: GoogleFonts.inter(fontSize: 13))),
                              Text(_fmt(item.subtotal),
                                  style: GoogleFonts.inter(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13)),
                            ],
                          ),
                        ))
                    .toList(),
              );
            },
          ),
          const Divider(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('TOTAL',
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold, fontSize: 16)),
              Text(_fmt(tx.grandTotal),
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w900,
                      fontSize: 20,
                      color: AppColors.primaryBrand)),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black87,
                foregroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
              child: Text('TUTUP',
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold, letterSpacing: 0.5)),
            ),
          ),
        ],
      ),
    );
  }

  Color _servisStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'pengecekan':
        return Colors.blue.shade600;
      case 'perbaikan':
        return Colors.orange.shade700;
      case 'siap ambil':
        return Colors.green.shade700;
      case 'selesai':
        return Colors.teal.shade700;
      default:
        return Colors.grey.shade600;
    }
  }
}

class _ScanningLine extends StatefulWidget {
  @override
  State<_ScanningLine> createState() => _ScanningLineState();
}

class _ScanningLineState extends State<_ScanningLine>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _controller.value * 240),
          child: Container(
            height: 3,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppColors.primaryBrand.withValues(alpha: 0),
                  AppColors.primaryBrand,
                  AppColors.primaryBrand.withValues(alpha: 0),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

