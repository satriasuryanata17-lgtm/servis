import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import '../core/theme.dart';
import '../services/backup_service.dart';
import 'responsive_layout.dart';

const Color _kBrand = AppColors.primaryBrand;
const Color _kTealDark = Color(0xFF1E40AF);
const Color _kTealDeep = AppColors.primaryDark;

class BackupRestoreScreen extends StatefulWidget {
  const BackupRestoreScreen({super.key});

  @override
  State<BackupRestoreScreen> createState() => _BackupRestoreScreenState();
}

class _BackupRestoreScreenState extends State<BackupRestoreScreen> {
  DateTime? _lastBackup;
  int _estimatedBytes = 0;
  bool _isLoading = false;
  String? _loadingLabel;
  bool _autoEnabled = true;
  String _autoFrequency = BackupService.autoFrequencyDaily;
  String? _customPath;
  List<File> _localFiles = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final size = await BackupService.estimateBackupSize();
    final auto = await BackupService.isAutoBackupEnabled();
    final frequency = await BackupService.getAutoBackupFrequency();
    final path = await BackupService.getCustomBackupPath();
    final files = await BackupService.getLocalBackupFiles();
    final last = _resolveLastBackupDate(
      await BackupService.getLastBackupDate(),
      files,
    );

    if (mounted) {
      setState(() {
        _lastBackup = last;
        _estimatedBytes = size;
        _autoEnabled = auto;
        _autoFrequency = frequency;
        _customPath = path;
        _localFiles = files;
      });
    }
  }

  String _fmtDate(DateTime? dt) {
    if (dt == null) return 'Belum ada backup';
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}  '
        '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }

  String _fmtSize(int b) {
    if (b < 1024) return '$b B';
    if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} KB';
    return '${(b / (1024 * 1024)).toStringAsFixed(2)} MB';
  }

  int get _daysSince =>
      _lastBackup == null ? 0 : DateTime.now().difference(_lastBackup!).inDays;

  bool get _needsBackup => _lastBackup == null || _daysSince >= 7;

  String _frequencyLabel(String value) {
    return switch (value) {
      BackupService.autoFrequencyWeekly => 'Mingguan',
      BackupService.autoFrequencyMonthly => 'Bulanan',
      _ => 'Harian',
    };
  }

  Future<void> _run(String label, Future<void> Function() fn) async {
    setState(() {
      _isLoading = true;
      _loadingLabel = label;
    });
    try {
      await fn();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Operasi gagal. Silakan coba lagi.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ));
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _loadingLabel = null;
        });
        await _load();
      }
    }
  }

  Future<void> _doShare() async {
    final passphrase = await _promptBackupPassphrase(confirm: true);
    if (passphrase == null) return;

    await _run('Menyiapkan file...', () async {
      await BackupService.shareEncryptedPortableBackup(
        passphrase: passphrase,
      );
      if (mounted) {
        _showSnack('Backup terenkripsi siap dibagikan.');
      }
    });
  }

  Future<void> _doSaveLocal() async {
    final passphrase = await _promptBackupPassphrase(confirm: true);
    if (passphrase == null) return;

    await _run('Pilih lokasi penyimpanan...', () async {
      final path = await BackupService.saveEncryptedPortableBackupToDownloads(
        passphrase: passphrase,
      );
      if (!mounted) return;
      if (path != null) {
        await _showBackupSavedDialog(path, title: 'Backup Tersimpan');
      } else {
        _showSnack(
          'Backup dibatalkan atau gagal disimpan. Pilih lokasi lain dan coba lagi.',
          isSuccess: false,
        );
      }
    });
  }

  Future<void> _saveLightBackupDirect() async {
    await _run('Pilih lokasi penyimpanan...', () async {
      final path = await BackupService.saveNativeBackupWithPicker();
      if (!mounted) return;
      if (path != null) {
        await _showBackupSavedDialog(path, title: 'Backup Database Tersimpan');
      } else {
        _showSnack(
          'Backup database dibatalkan atau gagal disimpan.',
          isSuccess: false,
        );
      }
    });
  }

  DateTime? _resolveLastBackupDate(DateTime? stored, List<File> files) {
    DateTime? latest = stored;
    for (final file in files) {
      try {
        if (!file.existsSync()) continue;
        final modified = file.lastModifiedSync();
        if (latest == null || modified.isAfter(latest)) {
          latest = modified;
        }
      } catch (_) {
        // Abaikan file yang tidak dapat dibaca metadata-nya.
      }
    }
    return latest;
  }

  Future<void> _pickFolder() async {
    String? path;
    try {
      path = await FilePicker.platform.getDirectoryPath(
        dialogTitle: 'Pilih Folder Backup Utama',
      );
    } catch (_) {
      _showSnack(
        'Perangkat ini tidak mendukung pilih folder langsung. Backup manual tetap bisa pilih lokasi file.',
        isSuccess: false,
      );
      return;
    }
    if (path != null) {
      final writable = await BackupService.canWriteToBackupDirectory(path);
      if (!writable) {
        _showSnack(
          'Folder ini tidak bisa ditulis langsung. Tekan Cadangkan Sekarang lalu pilih lokasi file.',
          isSuccess: false,
        );
        return;
      }
      await BackupService.setBackupPath(path);
      await _load();
      _showSnack('Folder backup diubah!', isSuccess: true);
    }
  }

  Future<void> _doRestore() async {
    final items = await FilePicker.platform.pickFiles(
      type: Platform.isAndroid ? FileType.any : FileType.custom,
      allowedExtensions: Platform.isAndroid ? null : ['json', 'db', 'jkb'],
    );
    if (items != null && items.files.single.path != null) {
      final path = items.files.single.path!;
      final file = File(path);
      if (!path.toLowerCase().endsWith('.json') &&
          !path.toLowerCase().endsWith('.db') &&
          !path.toLowerCase().endsWith('.jkb')) {
        _showSnack(
          'File tidak valid. Pilih file .json, .jkb, atau .db',
          isSuccess: false,
        );
        return;
      }
      final passphrase = BackupService.requiresPassphrase(file)
          ? await _promptBackupPassphrase(confirm: false)
          : null;
      if (BackupService.requiresPassphrase(file) && passphrase == null) {
        return;
      }

      await _run('Memulihkan data...', () async {
        final summary = await BackupService.getBackupFileSummary(
          file,
          passphrase: passphrase,
        );
        if (!mounted) return;
        if (summary.isEmpty) {
          _showSnack(
            'Gagal membaca isi backup. File mungkin rusak atau kata sandi salah.',
            isSuccess: false,
          );
          return;
        }

        final confirmed = await _showPreviewRestoreDialog(file, summary);
        if (confirmed && mounted) {
          final ok = await BackupService.restoreFromSpecificFile(
            context,
            file,
            passphrase: passphrase,
          );
          if (ok && mounted) {
            _showRestoreSuccessDialog();
          }
        }
      });
    }
  }

  Future<bool> _showPreviewRestoreDialog(
      File file, Map<String, dynamic> summary) async {
    if (summary.isEmpty) return false;
    final isNative = file.path.endsWith('.db');
    final isEncrypted = summary['is_encrypted'] == true;
    final nativeSignatureStatus =
        summary['native_signature_status']?.toString() ?? '';

    return await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                  title: const Text('Ringkasan Data Backup'),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildSummaryRow(
                        Icons.folder_zip_rounded,
                        'Tipe',
                        summary['type']?.toString() ??
                            (isNative ? 'Native Database' : 'JSON Portable'),
                      ),
                      _buildSummaryRow(Icons.category_rounded, 'Kategori',
                          summary['categories']?.toString() ?? '0'),
                      _buildSummaryRow(Icons.inventory_2_rounded, 'Produk',
                          summary['products']?.toString() ?? '0'),
                      _buildSummaryRow(Icons.receipt_long_rounded, 'Transaksi',
                          summary['transactions']?.toString() ?? '0'),
                      _buildSummaryRow(Icons.photo_library_outlined, 'Media',
                          summary['media_files']?.toString() ?? '0'),
                      if (summary['version'] != null)
                        _buildSummaryRow(Icons.update_rounded, 'Versi',
                            summary['version']?.toString() ?? '-'),
                      const Divider(height: 24),
                      if (isEncrypted)
                        const Padding(
                          padding: EdgeInsets.only(bottom: 8),
                          child: Text(
                            'File ini terenkripsi dan hanya bisa dipulihkan dengan kata sandi backup yang benar.',
                            style:
                                TextStyle(fontSize: 12, color: Colors.black54),
                          ),
                        ),
                      if (isNative && nativeSignatureStatus == 'legacy')
                        const Padding(
                          padding: EdgeInsets.only(bottom: 8),
                          child: Text(
                            'Backup native ini adalah backup lama tanpa file signature (.sig). Restore tetap diizinkan selama file database lolos pemeriksaan struktur dan integritas SQLite.',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.orange,
                            ),
                          ),
                        ),
                      if (isNative && nativeSignatureStatus == 'invalid')
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Text(
                            summary['native_signature_error']?.toString() ??
                                'File signature backup native bermasalah.',
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.red,
                            ),
                          ),
                        ),
                      Text(
                        'Peringatan: Seluruh data saat ini akan dihapus dan diganti dengan data dari file ${isNative ? ".db" : (isEncrypted ? ".jkb" : ".json")} ini.',
                        style: const TextStyle(fontSize: 12, color: Colors.red),
                      ),
                    ],
                  ),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('Batal')),
                    ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          foregroundColor: Colors.white),
                      child: const Text('Konfirmasi Restore'),
                    ),
                  ],
                )) ??
        false;
  }

  Widget _buildSummaryRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 18, color: Colors.blueGrey),
          const SizedBox(width: 12),
          Text(label, style: const TextStyle(fontSize: 14)),
          const Spacer(),
          Text(value,
              style:
                  const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  String _cleanBackupPath(String path) {
    return path.startsWith('fallback:')
        ? path.substring('fallback:'.length)
        : path;
  }

  Future<void> _showBackupSavedDialog(
    String rawPath, {
    required String title,
  }) async {
    final fallback = rawPath.startsWith('fallback:');
    final path = _cleanBackupPath(rawPath);
    final isEncrypted = path.toLowerCase().endsWith('.jkb');
    _showSnack('$title.', isSuccess: true);
    if (!mounted) return;

    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(color: Color(0xFFEFF6FF)),
              child: const Icon(
                Icons.check_circle_outline_rounded,
                color: _kBrand,
                size: 21,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 17,
                  color: Color(0xFF0F172A),
                ),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              fallback
                  ? 'Folder pilihan tidak bisa ditulis, jadi file disimpan di folder backup internal aplikasi.'
                  : 'File backup berhasil disimpan di lokasi berikut:',
              style: const TextStyle(
                fontSize: 12.5,
                height: 1.4,
                color: Color(0xFF475569),
              ),
            ),
            if (isEncrypted) ...[
              const SizedBox(height: 8),
              const Text(
                'Simpan kata sandi backup Anda. Tanpa kata sandi, file ini tidak dapat dipulihkan.',
                style: TextStyle(
                  fontSize: 12,
                  height: 1.35,
                  color: Color(0xFF64748B),
                ),
              ),
            ],
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: SelectableText(
                path,
                style: const TextStyle(
                  fontSize: 11,
                  height: 1.35,
                  fontFamily: 'monospace',
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF334155),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Tutup'),
          ),
          OutlinedButton.icon(
            onPressed: () {
              SharePlus.instance.share(ShareParams(files: [XFile(path)]));
            },
            icon: const Icon(Icons.ios_share_rounded, size: 16),
            label: const Text('Bagikan File'),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.pop(ctx);
              _onOpenBackupFolderTap();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              elevation: 0,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            icon: const Icon(Icons.folder_open_rounded, size: 16),
            label: const Text('Buka Folder'),
          ),
        ],
      ),
    );
  }

  void _showRestoreSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Row(
          children: [
            Icon(Icons.stars_rounded, color: Colors.amber, size: 28),
            SizedBox(width: 12),
            Text('Pemulihan Selesai',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          ],
        ),
        content: const Text(
          'Seluruh data Anda telah dipulihkan. Untuk hasil terbaik, silakan mulai ulang (restart) aplikasi untuk menyegarkan seluruh database.',
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              elevation: 0,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            child: const Text('Saya Mengerti'),
          ),
        ],
      ),
    );
  }

  void _showSnack(String msg, {bool isSuccess = true}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isSuccess ? AppColors.success : AppColors.danger,
      behavior: SnackBarBehavior.floating,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    ));
  }

  Future<String?> _promptBackupPassphrase({required bool confirm}) async {
    return await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => _BackupPassphraseDialog(confirm: confirm),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final isTablet = mq.size.shortestSide >= 600;
    final isLandscape = mq.orientation == Orientation.landscape;
    final useTwoCols = isTablet || isLandscape;

    return KasirResponsiveScaffold(
      title: 'Backup & Restore',
      showNavRail: false, // sub-page mode
      backgroundColor: const Color(0xFFF8FAFC),
      actions: [
        IconButton(
          icon: const Icon(Icons.history_rounded),
          tooltip: 'Riwayat Backup',
          onPressed: _openHistoryScreen,
        ),
      ],
      body: useTwoCols
          ? _buildWideBody(context, isLandscape)
          : _buildPortraitBody(context),
    );
  }

  void _openHistoryScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (ctx) => StatefulBuilder(
          builder: (builderContext, setScreenState) {
            return Scaffold(
              appBar: AppBar(
                title: const Text('Riwayat Backup Lokal'),
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                elevation: 1,
              ),
              backgroundColor: const Color(0xFFF8FAFC),
              body: _localFiles.isEmpty
                  ? const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.folder_open_rounded,
                              color: Colors.black12, size: 64),
                          SizedBox(height: 16),
                          Text('Belum ada riwayat backup',
                              style: TextStyle(
                                  color: Colors.black26, fontSize: 16)),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(20),
                      itemCount: _localFiles.length,
                      itemBuilder: (context, index) => _buildFileTile(
                        context,
                        _localFiles[index],
                        onChanged: () => setScreenState(() {}),
                      ),
                    ),
            );
          },
        ),
      ),
    ).then((_) {
      if (mounted) _load();
    });
  }

  Future<void> _onOpenBackupFolderTap() async {
    final success = await BackupService.openBackupDirectory();
    if (success || !mounted) return;

    final dir = await BackupService.getBackupDirectory();
    final path = dir.path;
    if (!mounted) return;

    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        backgroundColor: Colors.white,
        title: const Row(
          children: [
            Icon(Icons.folder_open_rounded, color: _kBrand, size: 28),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                'Akses Folder Backup',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Perangkat ini tidak mengizinkan aplikasi membuka folder backup secara langsung.',
              style: TextStyle(fontSize: 13, height: 1.4),
            ),
            const SizedBox(height: 16),
            const Text(
              'File backup internal tersimpan di:',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.black54,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              color: const Color(0xFFF1F5F9),
              child: SelectableText(
                path,
                style: const TextStyle(
                  fontSize: 11,
                  fontFamily: 'monospace',
                  fontWeight: FontWeight.bold,
                  color: Colors.blueGrey,
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Untuk backup manual, gunakan tombol Cadangkan Sekarang agar sistem langsung meminta lokasi penyimpanan file.',
              style: TextStyle(fontSize: 11.5, color: Colors.black45),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Tutup'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _openHistoryScreen();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            child: const Text('Lihat Riwayat'),
          ),
        ],
      ),
    );
  }

  Widget _buildPortraitBody(BuildContext context) {
    return Column(
      children: [
        _buildGradientHeaderInfo(context),
        Expanded(child: _buildContentScrollable()),
      ],
    );
  }

  Widget _buildWideBody(BuildContext context, bool landscape) {
    return Column(
      children: [
        _buildWideHeaderInfo(context),
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Main actions area
              Expanded(child: _buildContentScrollable()),
              // Stats / Info side panel
              Container(width: 1, color: const Color(0xFFE2E8F0)),
              Container(
                width: 340,
                color: Colors.white,
                child: _buildSideStatsPanel(context),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildGradientHeaderInfo(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_kBrand, _kTealDark, _kTealDeep],
        ),
      ),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
      child: Column(
        children: [
          _BackupStatusIcon(needsBackup: _needsBackup),
          const SizedBox(height: 12),
          Text(
            _needsBackup ? 'Amankan Data Sekarang' : 'Data Anda Terlindungi',
            style: const TextStyle(
                color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 2),
          Text(
            'Lakukan pencadangan rutin untuk keamanan data',
            textAlign: TextAlign.center,
            style: TextStyle(
                color: Colors.white.withValues(alpha: 0.7), fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildWideHeaderInfo(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Color(0xFFE2E8F0))),
      ),
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: const BoxDecoration(
                color: Color(0xFFF1F5F9), borderRadius: BorderRadius.zero),
            child:
                const Icon(Icons.cloud_sync_rounded, color: _kBrand, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Dashboard Pencadangan',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87),
                ),
                Text(
                  'Kelola keamanan database dan portabilitas data',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                ),
              ],
            ),
          ),
          if (_needsBackup)
            _EmergencyBadge(days: _lastBackup == null ? null : _daysSince),
        ],
      ),
    );
  }

  Widget _buildContentScrollable() {
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: _kBrand, strokeWidth: 3),
            const SizedBox(height: 20),
            Text(_loadingLabel ?? 'Sedang Diproses...',
                style: const TextStyle(
                    fontWeight: FontWeight.w600, color: Colors.black54)),
          ],
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        // 1. SINGLE BIG BACKUP BUTTON
        _buildSingleBackupButton(),
        const SizedBox(height: 24),

        // 2. FOLDER BACKUP
        _buildSectionHeader('Lokasi Folder Backup',
            'Kelola dan lihat file cadangan di memori perangkat'),
        _buildOpenFolderCard(),
        const SizedBox(height: 32),

        // 2. RESTORE ACTION
        _buildSectionHeader('Pemulihan Data',
            'Gunakan jika ingin mengembalikan data dari file cadangan'),
        _buildRestoreCard(),
        const SizedBox(height: 32),

        // 3. AUTO BACKUP SETTINGS
        _buildSectionHeader('Pengaturan Otomatis', 'Keamanan tanpa repot'),
        _FlatCard(
          padding: EdgeInsets.zero,
          child: Column(
            children: [
              SwitchListTile(
                value: _autoEnabled,
                activeThumbColor: _kBrand,
                title: const Text('Backup Otomatis',
                    style:
                        TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                subtitle: Text(
                    'Sistem akan otomatis mengamankan data secara ${_frequencyLabel(_autoFrequency).toLowerCase()}.',
                    style: const TextStyle(fontSize: 12)),
                onChanged: (v) async {
                  await BackupService.setAutoBackupEnabled(v);
                  _load();
                },
              ),
              const Divider(height: 1),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(
                  children: [
                    const Icon(Icons.schedule_rounded,
                        size: 20, color: _kBrand),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text('Jadwal Auto Backup',
                          style: TextStyle(
                              fontSize: 13, fontWeight: FontWeight.w700)),
                    ),
                    DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _autoFrequency,
                        items: const [
                          DropdownMenuItem(
                              value: BackupService.autoFrequencyDaily,
                              child: Text('Harian')),
                          DropdownMenuItem(
                              value: BackupService.autoFrequencyWeekly,
                              child: Text('Mingguan')),
                          DropdownMenuItem(
                              value: BackupService.autoFrequencyMonthly,
                              child: Text('Bulanan')),
                        ],
                        onChanged: _autoEnabled
                            ? (value) async {
                                if (value == null) return;
                                await BackupService.setAutoBackupFrequency(
                                    value);
                                _load();
                              }
                            : null,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 48),
        Center(
          child: TextButton.icon(
            onPressed: _showAdvancedMenu,
            icon: const Icon(Icons.settings_outlined, size: 16),
            label: const Text('Pengaturan Lanjutan',
                style: TextStyle(fontSize: 12, color: Colors.black38)),
          ),
        ),
        const SizedBox(height: 40),
      ],
    );
  }

  void _showAdvancedMenu() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text('Opsi Lanjutan',
                  style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.download_rounded),
              title: const Text('Simpan Backup Aman ke Folder HP'),
              subtitle:
                  const Text('File .jkb terenkripsi dengan foto dan data.'),
              onTap: () {
                Navigator.pop(ctx);
                _doSaveLocal();
              },
            ),
            ListTile(
              leading: const Icon(Icons.ios_share_rounded),
              title: const Text('Bagikan Backup Aman'),
              subtitle: const Text('Kirim file backup ke WhatsApp atau Drive.'),
              onTap: () {
                Navigator.pop(ctx);
                _doShare();
              },
            ),
            ListTile(
              leading: const Icon(Icons.folder_open_rounded),
              title: const Text('Ganti Folder Backup Utama'),
              subtitle: Text(_customPath ?? 'Default (Memori Aplikasi)',
                  style: const TextStyle(fontSize: 11)),
              onTap: () {
                Navigator.pop(ctx);
                _pickFolder();
              },
            ),
            ListTile(
              leading: const Icon(Icons.storage_outlined),
              title: const Text('Backup Database Ringan (.db)'),
              subtitle: const Text('Database saja untuk kebutuhan teknis.'),
              onTap: () {
                Navigator.pop(ctx);
                _saveLightBackupDirect();
              },
            ),
            ListTile(
              leading: const Icon(Icons.open_in_new_rounded),
              title: const Text('Buka Folder Backup Internal'),
              onTap: () {
                Navigator.pop(ctx);
                _onOpenBackupFolderTap();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSingleBackupButton() {
    return _FlatCard(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _kBrand.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.cloud_upload_rounded,
                color: _kBrand, size: 48),
          ),
          const SizedBox(height: 20),
          const Text(
            'CADANGKAN SEKARANG',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          const Text(
            'Mengamankan seluruh data order servis, pelanggan, layanan, dan pengaturan agar tidak hilang.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: Colors.black54),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: _doMainBackupAction,
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
              child: const Text('MULAI CADANGKAN DATA',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _doMainBackupAction() async {
    await _doSaveLocal();
  }

  Widget _buildRestoreCard() {
    return Material(
      color: Colors.white,
      shape: Border.all(color: Colors.orange.shade700),
      child: InkWell(
        onTap: _doRestore,
        splashColor: Colors.orange.withValues(alpha: 0.1),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.orange.shade50),
                child: Icon(Icons.restore_page_rounded,
                    color: Colors.orange.shade700, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Pulihkan dari File Lama',
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.orange.shade900),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Kembalikan usaha servis Anda menggunakan file .jkb, .db, atau .json cadangan.',
                      style: TextStyle(
                          fontSize: 12, color: Colors.orange.shade800),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: Colors.orange.shade300),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOpenFolderCard() {
    return Material(
      color: Colors.white,
      shape: Border.all(color: _kBrand.withValues(alpha: 0.3)),
      child: InkWell(
        onTap: _onOpenBackupFolderTap,
        splashColor: _kBrand.withValues(alpha: 0.1),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration:
                    BoxDecoration(color: _kBrand.withValues(alpha: 0.1)),
                child: const Icon(Icons.folder_shared_rounded,
                    color: _kBrand, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Buka Folder Backup',
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: _kBrand),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _customPath ?? 'Folder internal aplikasi',
                      style: TextStyle(
                          fontSize: 12, color: Colors.blueGrey.shade600),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded,
                  size: 16, color: _kBrand),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFileTile(BuildContext context, File file,
      {VoidCallback? onChanged}) {
    if (!file.existsSync()) return const SizedBox.shrink();

    final name = file.path.split(Platform.pathSeparator).last;
    final isPreRestore = name.contains('pre_restore');
    final isEncryptedPortable = name.endsWith('.jkb');

    DateTime date;
    int size;
    try {
      date = file.lastModifiedSync();
      size = file.lengthSync();
    } catch (_) {
      return const SizedBox.shrink(); // Hide if OS couldn't fetch metadata
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: isPreRestore ? const Color(0xFFFFF7ED) : Colors.white,
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: (isPreRestore ? Colors.orange : _kBrand)
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.zero,
              ),
              child: Icon(
                isPreRestore
                    ? Icons.security_rounded
                    : (isEncryptedPortable
                        ? Icons.lock_rounded
                        : Icons.insert_drive_file_rounded),
                color: isPreRestore ? Colors.orange : _kBrand,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: isPreRestore
                          ? Colors.orange.shade900
                          : Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${_fmtDate(date)}  |  ${_fmtSize(size)}',
                    style: const TextStyle(fontSize: 11, color: Colors.black45),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              icon: const Icon(Icons.share_rounded,
                  size: 18, color: Colors.black38),
              onPressed: () => SharePlus.instance.share(
                ShareParams(files: [XFile(file.path)]),
              ),
            ),
            IconButton(
              icon: const Icon(AppIcons.recycleBin,
                  size: 18, color: Colors.redAccent),
              onPressed: () => _confirmDeleteFile(context, file, onChanged),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDeleteFile(
      BuildContext context, File file, VoidCallback? onChanged) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus Backup?'),
        content: const Text('File ini akan dihapus permanen dari memori HP.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Hapus', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (ok == true) {
      await file.delete();
      if (onChanged != null) onChanged();
      _load();
    }
  }

  Widget _buildSectionHeader(String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87)),
          const SizedBox(height: 2),
          Text(subtitle,
              style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
        ],
      ),
    );
  }

  Widget _buildSideStatsPanel(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const Text('Status Saat Ini',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 24),
        _buildStatTile(
            Icons.history_rounded, 'Backup Terakhir', _fmtDate(_lastBackup)),
        _buildStatTile(Icons.storage_rounded, 'Ukuran Database',
            _fmtSize(_estimatedBytes)),
        _buildStatTile(Icons.auto_awesome_rounded, 'Backup Otomatis',
            _autoEnabled ? 'Aktif' : 'Nonaktif'),
        const SizedBox(height: 32),
        const Divider(),
        const SizedBox(height: 24),
        const Text('Info Penting',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 12),
        const Text(
          '• Gunakan "Cadangkan" sebelum update aplikasi atau pindah HP.\n'
          '• File backup (.jkb) terenkripsi adalah cara paling aman untuk migrasi data.\n'
          '• Jangan hapus file .db di folder sistem kecuali Anda tahu apa yang Anda lakukan.',
          style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.6),
        ),
      ],
    );
  }

  Widget _buildStatTile(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Row(
        children: [
          Icon(icon, size: 20, color: _kBrand),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(fontSize: 12, color: Colors.black45)),
              Text(value,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87)),
            ],
          ),
        ],
      ),
    );
  }
}

class _BackupStatusIcon extends StatelessWidget {
  final bool needsBackup;
  const _BackupStatusIcon({required this.needsBackup});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.zero, // Flat
      ),
      child: Icon(
        needsBackup ? Icons.warning_amber_rounded : Icons.cloud_done_rounded,
        color: needsBackup ? Colors.orangeAccent : Colors.white,
        size: 24,
      ),
    );
  }
}

class _EmergencyBadge extends StatelessWidget {
  final int? days;
  const _EmergencyBadge({required this.days});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.red.shade50,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: Colors.red.shade200),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.warning_rounded, color: Colors.red.shade700, size: 14),
          const SizedBox(width: 6),
          Text(
            days == null
                ? 'Belum ada backup'
                : 'Sudah $days hari belum backup!',
            style: TextStyle(
                color: Colors.red.shade800,
                fontSize: 11,
                fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}

class _FlatCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const _FlatCard(
      {required this.child, this.padding = const EdgeInsets.all(16)});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: child,
    );
  }
}

class _BackupPassphraseDialog extends StatefulWidget {
  final bool confirm;
  const _BackupPassphraseDialog({required this.confirm});

  @override
  State<_BackupPassphraseDialog> createState() =>
      _BackupPassphraseDialogState();
}

class _BackupPassphraseDialogState extends State<_BackupPassphraseDialog> {
  final _primaryCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  var _obscurePrimary = true;
  var _obscureConfirm = true;
  var _error = '';

  @override
  void dispose() {
    _primaryCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      title: Text(
        widget.confirm ? 'Kunci Backup Portable' : 'Buka Backup Terenkripsi',
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.confirm
                  ? 'Buat kata sandi untuk file backup terenkripsi. Tanpa kata sandi ini, file tidak bisa dipulihkan.'
                  : 'Masukkan kata sandi backup untuk membuka file terenkripsi.',
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
            const SizedBox(height: 16),
            _buildField(
              controller: _primaryCtrl,
              label: widget.confirm ? 'Kata Sandi Backup' : 'Kata Sandi',
              obscure: _obscurePrimary,
              toggle: () => setState(() => _obscurePrimary = !_obscurePrimary),
            ),
            if (widget.confirm) ...[
              const SizedBox(height: 14),
              _buildField(
                controller: _confirmCtrl,
                label: 'Ulangi Kata Sandi',
                obscure: _obscureConfirm,
                toggle: () =>
                    setState(() => _obscureConfirm = !_obscureConfirm),
              ),
            ],
            if (_error.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(
                _error,
                style: const TextStyle(
                  color: AppColors.danger,
                  fontSize: 12,
                ),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Batal'),
        ),
        ElevatedButton(
          onPressed: () {
            final primary = _primaryCtrl.text.trim();
            final secondary = _confirmCtrl.text.trim();
            if (primary.length < 8) {
              setState(() => _error = 'Kata sandi backup minimal 8 karakter.');
              return;
            }
            if (widget.confirm && primary != secondary) {
              setState(() => _error = 'Konfirmasi kata sandi tidak cocok.');
              return;
            }
            Navigator.pop(context, primary);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: _kBrand,
            foregroundColor: Colors.white,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.zero,
            ),
          ),
          child: Text(widget.confirm ? 'Lanjutkan' : 'Buka File'),
        ),
      ],
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required bool obscure,
    required VoidCallback toggle,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: Colors.black54,
          ),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          obscureText: obscure,
          autocorrect: false,
          enableSuggestions: false,
          decoration: InputDecoration(
            border: const OutlineInputBorder(borderRadius: BorderRadius.zero),
            enabledBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: Color(0xFFD0D5DD)),
            ),
            focusedBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: _kBrand, width: 1.5),
            ),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            suffixIcon: IconButton(
              onPressed: toggle,
              icon: Icon(
                obscure
                    ? Icons.visibility_off_outlined
                    : Icons.visibility_outlined,
                color: Colors.black38,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

