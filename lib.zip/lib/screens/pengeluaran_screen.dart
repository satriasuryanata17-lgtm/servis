import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/theme.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../widgets/kasir_dialog.dart';
import '../widgets/responsive_layout.dart';

//  PENGELUARAN SCREEN Responsive v3 (Tablet + Landscape)

const Color _kBrand = AppColors.primaryBrand;

const List<String> kKategoriPengeluaran = [
  'Gaji',
  'Bahan Baku',
  'Sewa',
  'Listrik/Air',
  'Transportasi',
  'Lainnya',
];

final Map<String, IconData> kKategoriIcon = {
  'Gaji': Icons.badge_outlined,
  'Bahan Baku': Icons.inventory_2_outlined,
  'Sewa': Icons.storefront_outlined,
  'Listrik/Air': Icons.bolt_outlined,
  'Transportasi': Icons.local_shipping_outlined,
  'Lainnya': Icons.receipt_long_outlined,
};

final Map<String, Color> kKategoriColor = {
  'Gaji': const Color(0xFF37474F),
  'Bahan Baku': const Color(0xFF2E7D32),
  'Sewa': const Color(0xFF1565C0),
  'Listrik/Air': const Color(0xFFF57C00),
  'Transportasi': const Color(0xFFC62828),
  'Lainnya': const Color(0xFF546E7A),
};

String _fRp(int n) {
  if (n == 0) return 'Rp 0';
  String s = n.abs().toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return 'Rp $r';
}

int _parseCurrencyInput(String value) {
  return int.tryParse(value.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
}

String _formatCurrencyInput(int value) {
  final digits = value.abs().toString();
  final buffer = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buffer.write('.');
    buffer.write(digits[i]);
  }
  return buffer.toString();
}

class _CurrencyInputFormatter extends TextInputFormatter {
  const _CurrencyInputFormatter();

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final nominal = _parseCurrencyInput(newValue.text);
    if (nominal == 0) {
      return const TextEditingValue(
        text: '',
        selection: TextSelection.collapsed(offset: 0),
      );
    }
    final text = _formatCurrencyInput(nominal);
    return TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
  }
}

class PengeluaranScreen extends StatefulWidget {
  const PengeluaranScreen({super.key});
  @override
  State<PengeluaranScreen> createState() => _PengeluaranScreenState();
}

class _PengeluaranScreenState extends State<PengeluaranScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  int _month = DateTime.now().month;
  int _year = DateTime.now().year;
  List<WalletTransaction> _all = [];
  Map<String, int> _byKategori = {};
  bool _loading = true;

  final List<String> _monthsList = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember'
  ];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final all = await DBHelper.instance.getAllWalletTransactions();
    final filtered = all.where((t) {
      if (t.type != 'keluar') return false;
      try {
        final dt = DateTime.parse(t.tanggal);
        return dt.month == _month && dt.year == _year;
      } catch (_) {
        return false;
      }
    }).toList();

    final byKat = await DBHelper.instance.getExpensesByCategory(_year, _month);
    if (mounted) {
      setState(() {
        _all = filtered;
        _byKategori = byKat;
        _loading = false;
      });
    }
  }

  int get _totalPengeluaran => _all.fold<int>(0, (s, t) => s + t.nominal);

  Future<void> _showMonthSheet() async {
    final selected = await showKasirOptionSheet<int>(
      context,
      title: 'Pilih Bulan',
      options: List.generate(12, (i) => i + 1),
      currentValue: _month,
      labelBuilder: (m) => _monthsList[m - 1],
    );
    if (selected != null && selected != _month) {
      setState(() => _month = selected);
      _load();
    }
  }

  Future<void> _showYearSheet() async {
    final selected = await showKasirOptionSheet<int>(
      context,
      title: 'Pilih Tahun',
      options: List.generate(5, (i) => DateTime.now().year - i),
      currentValue: _year,
      labelBuilder: (y) => y.toString(),
    );
    if (selected != null && selected != _year) {
      setState(() => _year = selected);
      _load();
    }
  }

  void _showTambahForm() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _TambahPengeluaranForm(onSaved: () {
        Navigator.pop(context);
        _load();
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = KasirLayout.isTablet(context);
    final isLandscape = KasirLayout.isLandscape(context);
    final wide = isTablet || isLandscape;

    return KasirResponsiveScaffold(
      title: 'Pengeluaran',
      navIndex: 4,
      showNavRail: false,
      floatingActionButton: (wide && isLandscape) ? _buildFab() : null,
      body: Column(
        children: [
          // Header with period selectors
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              children: [
                Expanded(
                  child: _SelectorBox(
                    label: _monthsList[_month - 1],
                    icon: Icons.calendar_month_outlined,
                    onTap: _showMonthSheet,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _SelectorBox(
                    label: _year.toString(),
                    icon: Icons.event_note_outlined,
                    onTap: _showYearSheet,
                  ),
                ),
              ],
            ),
          ),
          // Tab bar
          Container(
            color: Colors.white,
            child: TabBar(
              controller: _tab,
              labelColor: _kBrand,
              unselectedLabelColor: Colors.black38,
              indicatorColor: _kBrand,
              indicatorWeight: 3,
              labelStyle:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5),
              indicatorSize: TabBarIndicatorSize.label,
              tabs: const [Tab(text: 'Statistik'), Tab(text: 'Riwayat')],
            ),
          ),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),

          // Thin refresh indicator — only shown when reloading with existing data
          if (_loading && _all.isNotEmpty)
            const LinearProgressIndicator(
              backgroundColor: Colors.transparent,
              valueColor: AlwaysStoppedAnimation(_kBrand),
              minHeight: 2,
            ),

          Expanded(
            child: (_loading && _all.isEmpty)
                ? const Center(
                    child: CircularProgressIndicator(
                        color: _kBrand, strokeWidth: 2))
                : wide
                    ? _buildTabletLandscapeContent()
                    : TabBarView(
                        controller: _tab,
                        children: [_buildRekap(), _buildRiwayat()]),
          ),
        ],
      ),
      bottomNavigationBar: isLandscape ? null : _buildBottomBar(),
    );
  }

  Widget _buildTabletLandscapeContent() {
    return Row(
      children: [
        Expanded(child: _buildRekap()),
        Container(width: 1, color: const Color(0xFFE2E8F0)),
        Expanded(child: _buildRiwayat()),
      ],
    );
  }

  Widget _buildFab() {
    return FloatingActionButton.extended(
      onPressed: _showTambahForm,
      backgroundColor: _kBrand,
      foregroundColor: Colors.white,
      icon: const Icon(Icons.add_rounded),
      label:
          const Text('Tambah', style: TextStyle(fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFF1F5F9), width: 1)),
      ),
      child: SafeArea(
        child: SizedBox(
          width: double.infinity,
          height: 54,
          child: ElevatedButton.icon(
            onPressed: _showTambahForm,
            icon: const Icon(Icons.add_rounded, size: 22, color: Colors.white),
            label: const Text('TAMBAH PENGELUARAN',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.0,
                    color: Colors.white)),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              elevation: 4,
              shadowColor: _kBrand.withValues(alpha: 0.3),
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRekap() {
    final total = _totalPengeluaran;
    if (total == 0) {
      return const _EmptyView(
          icon: Icons.auto_graph_rounded,
          msg: 'Belum ada pengeluaran\ndi bulan ini');
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF334155), Color(0xFF1E293B)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.zero,
            boxShadow: [
              BoxShadow(
                  color: const Color(0xFF1E293B).withValues(alpha: 0.15),
                  blurRadius: 15,
                  offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            children: [
              Text('Total Pengeluaran'.toUpperCase(),
                  style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 11,
                      letterSpacing: 1.2,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Text(_fRp(total),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.5)),
            ],
          ),
        ),
        const SizedBox(height: 32),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Statistik Analisis',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF334155))),
            Icon(Icons.insights_rounded,
                size: 18, color: Colors.blueGrey.shade400),
          ],
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFF1F5F9)),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withValues(alpha: 0.02),
                  blurRadius: 20,
                  offset: const Offset(0, 4)),
            ],
          ),
          child: Column(
            children: [
              Row(
                children: [
                  SizedBox(
                      width: 140,
                      height: 140,
                      child: CustomPaint(
                          painter:
                              _DonutPainter(data: _byKategori, total: total))),
                  const SizedBox(width: 24),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: kKategoriPengeluaran
                          .where((p) => (_byKategori[p] ?? 0) > 0)
                          .map((p) =>
                              _LegendRow(p, (_byKategori[p] ?? 0) / total))
                          .toList(),
                    ),
                  ),
                ],
              ),
              if (_byKategori.isNotEmpty) ...[
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Divider(height: 1, color: Color(0xFFF1F5F9)),
                ),
                ...kKategoriPengeluaran
                    .where((p) => (_byKategori[p] ?? 0) > 0)
                    .map((p) => _KatRow(
                        p, _byKategori[p]!, (_byKategori[p] ?? 0) / total)),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRiwayat() {
    if (_all.isEmpty) {
      return const _EmptyView(
          icon: Icons.history_rounded, msg: 'Riwayat transaksi masih kosong');
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
      itemCount: _all.length,
      itemBuilder: (_, i) {
        final tx = _all[i];
        final kat = tx.kategori ?? 'Lainnya';
        final color = kKategoriColor[kat] ?? Colors.blueGrey;
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFF1F5F9)),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withValues(alpha: 0.01),
                  blurRadius: 10,
                  offset: const Offset(0, 4))
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.zero),
                child: Icon(kKategoriIcon[kat] ?? Icons.more_horiz,
                    color: color, size: 22),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tx.keterangan.isNotEmpty ? tx.keterangan : kat,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14.5,
                            color: Color(0xFF334155)),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Text('${tx.tanggal}  |  ${tx.waktu}',
                        style: TextStyle(
                            fontSize: 11,
                            color: Colors.blueGrey.shade400,
                            fontWeight: FontWeight.w500)),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(_fRp(tx.nominal),
                      style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                          color: AppColors.danger)),
                  const SizedBox(height: 4),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: const BoxDecoration(
                        color: Color(0xFFF1F5F9),
                        borderRadius: BorderRadius.zero),
                    child: Text(kat,
                        style: TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            color: Colors.blueGrey.shade500
                                .withValues(alpha: 0.8))),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SelectorBox extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _SelectorBox(
      {required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFFF8FAFC),
            border: Border.all(color: const Color(0xFFF1F5F9)),
            borderRadius: BorderRadius.zero,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(icon, size: 18, color: Colors.blueGrey.shade400),
                  const SizedBox(width: 10),
                  Text(label,
                      style: const TextStyle(
                          fontSize: 13,
                          color: Color(0xFF334155),
                          fontWeight: FontWeight.w700)),
                ],
              ),
              const Icon(Icons.keyboard_arrow_down_rounded,
                  size: 20, color: Colors.blueGrey),
            ],
          ),
        ),
      );
}

class _LegendRow extends StatelessWidget {
  final String label;
  final double pct;
  const _LegendRow(this.label, this.pct);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(
          children: [
            Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                    color: kKategoriColor[label] ?? Colors.grey,
                    borderRadius: BorderRadius.zero)),
            const SizedBox(width: 10),
            Expanded(
                child: Text(label,
                    style: const TextStyle(
                        fontSize: 11.5,
                        color: Colors.black54,
                        fontWeight: FontWeight.w500),
                    maxLines: 1)),
            Text('${(pct * 100).toStringAsFixed(0)}%',
                style: const TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF334155))),
          ],
        ),
      );
}

class _KatRow extends StatelessWidget {
  final String kat;
  final int val;
  final double pct;
  const _KatRow(this.kat, this.val, this.pct);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                      color: (kKategoriColor[kat] ?? Colors.blueGrey)
                          .withValues(alpha: 0.08),
                      shape: BoxShape.rectangle),
                  child: Icon(kKategoriIcon[kat],
                      size: 14, color: kKategoriColor[kat]),
                ),
                const SizedBox(width: 12),
                Expanded(
                    child: Text(kat,
                        style: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF334155)))),
                Text(_fRp(val),
                    style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF334155))),
              ],
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.zero,
              child: LinearProgressIndicator(
                value: pct,
                backgroundColor: const Color(0xFFF1F5F9),
                valueColor: AlwaysStoppedAnimation(kKategoriColor[kat]!),
                minHeight: 8,
              ),
            ),
          ],
        ),
      );
}

class _EmptyView extends StatelessWidget {
  final IconData icon;
  final String msg;
  const _EmptyView({required this.icon, required this.msg});
  @override
  Widget build(BuildContext context) => Center(
        child: Opacity(
          opacity: 0.8,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.rectangle,
                    border:
                        Border.all(color: const Color(0xFFF1F5F9), width: 2)),
                child: Icon(icon, size: 48, color: Colors.blueGrey.shade200),
              ),
              const SizedBox(height: 24),
              Text(msg,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 15,
                      color: Colors.blueGrey.shade400,
                      fontWeight: FontWeight.w600,
                      height: 1.4)),
            ],
          ),
        ),
      );
}

class _DonutPainter extends CustomPainter {
  final Map<String, int> data;
  final int total;
  _DonutPainter({required this.data, required this.total});
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = min(size.width, size.height) / 2;
    double start = -pi / 2;
    final strokeWidth = radius * 0.35;
    final rect =
        Rect.fromCircle(center: center, radius: radius - (strokeWidth / 2));
    if (total == 0) return;
    for (final k in kKategoriPengeluaran) {
      final v = data[k] ?? 0;
      if (v <= 0) continue;
      final sweep = 2 * pi * v / total;
      canvas.drawArc(
          rect,
          start,
          sweep,
          false,
          Paint()
            ..color = kKategoriColor[k]!
            ..style = PaintingStyle.stroke
            ..strokeWidth = strokeWidth
            ..strokeCap = StrokeCap.round);
      start += sweep;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class _TambahPengeluaranForm extends StatefulWidget {
  final VoidCallback onSaved;
  const _TambahPengeluaranForm({required this.onSaved});
  @override
  State<_TambahPengeluaranForm> createState() => _TambahPengeluaranFormState();
}

class _TambahPengeluaranFormState extends State<_TambahPengeluaranForm> {
  final _nominalCtrl = TextEditingController();
  final _keteranganCtrl = TextEditingController();
  String _kat = kKategoriPengeluaran.first;
  String _wallet = 'tunai';
  bool _saving = false;

  Future<void> _save() async {
    final n = _parseCurrencyInput(_nominalCtrl.text);
    if (n <= 0) return;
    setState(() => _saving = true);
    final now = DateTime.now();
    await DBHelper.instance.insertWalletTransaction(WalletTransaction(
      walletId: _wallet,
      nominal: n,
      type: 'keluar',
      tanggal:
          '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}',
      waktu:
          '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}',
      keterangan: _keteranganCtrl.text.trim(),
      createdAt: now.toIso8601String(),
      kategori: _kat,
      source: 'manual',
    ));
    widget.onSaved();
  }

  Future<void> _showCategoryPicker() async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _CategoryGridPicker(current: _kat),
    );
    if (selected != null) setState(() => _kat = selected);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom + 24,
          top: 12,
          left: 24,
          right: 24),
      decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
              child: Container(
                  width: 40,
                  height: 4,
                  decoration: const BoxDecoration(
                      color: Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.zero))),
          const SizedBox(height: 24),
          const Text('Catat Pengeluaran Baru',
              style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF1E293B))),
          const SizedBox(height: 24),
          Text('Kategori Pengeluaran'.toUpperCase(),
              style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  color: Colors.blueGrey,
                  letterSpacing: 1.0)),
          const SizedBox(height: 10),
          _SelectorBox(
              label: _kat,
              icon: kKategoriIcon[_kat] ?? Icons.category_rounded,
              onTap: _showCategoryPicker),
          const SizedBox(height: 20),
          TextField(
            controller: _nominalCtrl,
            keyboardType: TextInputType.number,
            inputFormatters: const [_CurrencyInputFormatter()],
            style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1E293B)),
            decoration: _dec('Nominal (Rp)', prefixText: 'Rp '),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _keteranganCtrl,
            style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w500),
            decoration: _dec('Keterangan opsional, misal: Bayar listrik toko'),
          ),
          const SizedBox(height: 24),
          Text('Sumber Dana'.toUpperCase(),
              style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  color: Colors.blueGrey,
                  letterSpacing: 1.0)),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                  child: _btn(
                      _wallet == 'tunai',
                      'Uang Tunai',
                      Icons.payments_outlined,
                      () => setState(() => _wallet = 'tunai'))),
              const SizedBox(width: 12),
              Expanded(
                  child: _btn(
                      _wallet == 'non_tunai',
                      'Transfer / Bank',
                      Icons.account_balance_rounded,
                      () => setState(() => _wallet = 'non_tunai'))),
            ],
          ),
          const SizedBox(height: 32),
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: _saving ? null : _save,
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                elevation: 4,
                shadowColor: _kBrand.withValues(alpha: 0.3),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
              child: _saving
                  ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 3))
                  : const Text('SIMPAN TRANSAKSI',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 1.0)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _btn(bool active, String txt, IconData icon, VoidCallback onTap) =>
      GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
          decoration: BoxDecoration(
            color: active ? _kBrand : Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(
                color: active ? _kBrand : const Color(0xFFF1F5F9), width: 1.5),
            boxShadow: active
                ? [
                    BoxShadow(
                        color: _kBrand.withValues(alpha: 0.2),
                        blurRadius: 8,
                        offset: const Offset(0, 4))
                  ]
                : [],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon,
                  size: 18, color: active ? Colors.white : Colors.blueGrey),
              const SizedBox(width: 8),
              Text(txt,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: active ? Colors.white : Colors.blueGrey)),
            ],
          ),
        ),
      );

  InputDecoration _dec(String h, {String? prefixText}) => InputDecoration(
        hintText: h,
        prefixText: prefixText,
        prefixStyle: const TextStyle(
            color: Color(0xFF1E293B),
            fontWeight: FontWeight.bold,
            fontSize: 18),
        hintStyle: TextStyle(color: Colors.blueGrey.shade300, fontSize: 14),
        filled: true,
        fillColor: const Color(0xFFF8FAFC),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
        border: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: Color(0xFFF1F5F9))),
        enabledBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: Color(0xFFF1F5F9))),
        focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: _kBrand, width: 2)),
      );
}

class _CategoryGridPicker extends StatelessWidget {
  final String current;
  const _CategoryGridPicker({required this.current});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 32),
      decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
              width: 40,
              height: 4,
              decoration: const BoxDecoration(
                  color: Color(0xFFF1F5F9), borderRadius: BorderRadius.zero)),
          const SizedBox(height: 24),
          const Text('Pilih Kategori',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1E293B))),
          const SizedBox(height: 24),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 1.1),
            itemCount: kKategoriPengeluaran.length,
            itemBuilder: (context, i) {
              final kat = kKategoriPengeluaran[i];
              final isSel = kat == current;
              final color = kKategoriColor[kat] ?? Colors.blueGrey;
              return GestureDetector(
                onTap: () => Navigator.pop(context, kat),
                child: Container(
                  decoration: BoxDecoration(
                    color: isSel ? color.withValues(alpha: 0.08) : Colors.white,
                    borderRadius: BorderRadius.zero,
                    border: Border.all(
                        color: isSel ? color : const Color(0xFFF1F5F9),
                        width: 1.5),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(kKategoriIcon[kat], color: color, size: 28),
                      const SizedBox(height: 8),
                      Text(kat,
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight:
                                  isSel ? FontWeight.w800 : FontWeight.w600,
                              color: isSel ? color : Colors.black87)),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

