import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/finance_category_ui.dart';
import '../providers/providers.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../core/theme.dart';

const Color _kBrand = AppColors.primaryBrand;
const Color _kBg = Color(0xFFF5F7FA);

const List<String> _expenseCategories = [
  'Gaji',
  'Bahan Baku',
  'Sewa',
  'Listrik/Air',
  'Transportasi',
  'Lainnya',
];

const List<String> _incomeCategories = [
  'Pemasukan Lain',
  'Modal Tambahan',
  'Komisi',
  'Bonus',
];

int _parseCurrencyInput(String value) {
  return int.tryParse(value.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
}

String _formatCurrencyInput(int value) {
  final digits = value.abs().toString();
  final buffer = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buffer.write('.');
    buffer.write(digits[i]);
  }
  return buffer.toString();
}

class _CurrencyInputFormatter extends TextInputFormatter {
  const _CurrencyInputFormatter();

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final nominal = _parseCurrencyInput(newValue.text);
    if (nominal == 0) {
      return const TextEditingValue(
        text: '',
        selection: TextSelection.collapsed(offset: 0),
      );
    }
    final text = _formatCurrencyInput(nominal);
    return TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
  }
}

// SCREEN

class TambahTransaksiDompetScreen extends ConsumerStatefulWidget {
  /// 'masuk' = Pemasukan, 'keluar' = Pengeluaran
  final String initialType;
  final WalletTransaction? initialTransaction;

  const TambahTransaksiDompetScreen({
    super.key,
    this.initialType = 'masuk',
    this.initialTransaction,
  });

  @override
  ConsumerState<TambahTransaksiDompetScreen> createState() =>
      _TambahTransaksiDompetScreenState();
}

class _TambahTransaksiDompetScreenState
    extends ConsumerState<TambahTransaksiDompetScreen> {
  late String _type;
  String? _selectedWallet;
  final _nominalController = TextEditingController();
  final _keteranganController = TextEditingController();
  late DateTime _selectedDate;
  late TimeOfDay _selectedTime;
  String _expenseCategory = 'Lainnya';
  String _incomeCategory = 'Pemasukan Lain';
  bool _isSaving = false;
  bool get _isExpense => _type == 'keluar';
  bool get _isEditing => widget.initialTransaction != null;

  @override
  void initState() {
    super.initState();
    final tx = widget.initialTransaction;
    _type = (tx?.type == 'keluar' || widget.initialType == 'keluar')
        ? 'keluar'
        : 'masuk';
    _selectedWallet = tx?.walletId;
    if (tx != null) {
      _nominalController.text = _formatCurrencyInput(tx.nominal);
      _selectedDate = DateTime.tryParse(tx.tanggal) ?? DateTime.now();
      _selectedTime = _parseTimeOfDay(tx.waktu) ?? TimeOfDay.now();
      final category = tx.kategori?.trim();
      if (category != null && category.isNotEmpty) {
        if (_type == 'keluar') {
          _expenseCategory = category;
        } else {
          _incomeCategory =
              (category == 'Manual' || category == 'Pemasukan Manual')
                  ? 'Pemasukan Lain'
                  : category;
        }
      }
      final note = tx.keterangan.trim();
      _keteranganController.text =
          _type == 'keluar' && note == _expenseCategory ? '' : note;
    } else {
      _selectedDate = DateTime.now();
      _selectedTime = TimeOfDay.now();
    }
  }

  @override
  void dispose() {
    _nominalController.dispose();
    _keteranganController.dispose();
    super.dispose();
  }

  String _fmtDate(DateTime dt) => '${dt.day.toString().padLeft(2, '0')}-'
      '${dt.month.toString().padLeft(2, '0')}-'
      '${dt.year}';

  String _fmtTime(TimeOfDay t) => '${t.hour.toString().padLeft(2, '0')}:'
      '${t.minute.toString().padLeft(2, '0')}';

  TimeOfDay? _parseTimeOfDay(String value) {
    final match = RegExp(r'(\d{1,2})[:.](\d{2})').firstMatch(value);
    if (match == null) return null;
    final hour = int.tryParse(match.group(1) ?? '');
    final minute = int.tryParse(match.group(2) ?? '');
    if (hour == null || minute == null) return null;
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
    return TimeOfDay(hour: hour, minute: minute);
  }

  String get _pageTitle =>
      _type == 'keluar' ? 'Pengeluaran Kas' : 'Pemasukan Kas';
  String get _nominalLabel =>
      _type == 'keluar' ? 'Nominal Pengeluaran' : 'Nominal Pemasukan';
  IconData get _pageIcon => _type == 'keluar'
      ? Icons.arrow_upward_rounded
      : Icons.arrow_downward_rounded;

  String _fmtRp(int n) {
    if (n == 0) return 'Rp 0';
    String s = n.abs().toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return 'Rp $r';
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx)
            .copyWith(colorScheme: const ColorScheme.light(primary: _kBrand)),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx)
            .copyWith(colorScheme: const ColorScheme.light(primary: _kBrand)),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _selectedTime = picked);
  }

  Future<void> _save() async {
    final nominal = _parseCurrencyInput(_nominalController.text);

    if (_selectedWallet == null) {
      _snack('Pilih dompet terlebih dahulu');
      return;
    }
    if (nominal <= 0) {
      _snack('Nominal harus lebih dari Rp0');
      return;
    }
    final rawDescription = _keteranganController.text.trim();
    if (!_isExpense && rawDescription.isEmpty) {
      _snack('Keterangan harus diisi');
      return;
    }

    setState(() => _isSaving = true);
    try {
      final selectedCategory = _isExpense ? _expenseCategory : _incomeCategory;
      final tx = WalletTransaction(
        id: widget.initialTransaction?.id,
        walletId: _selectedWallet!,
        nominal: nominal,
        type: _type,
        tanggal: _selectedDate.toIso8601String().substring(0, 10),
        waktu: _fmtTime(_selectedTime),
        keterangan: rawDescription,
        createdAt: widget.initialTransaction?.createdAt ??
            DateTime.now().toIso8601String(),
        kategori: selectedCategory,
        source: 'manual',
      );
      if (_isEditing) {
        final updated = await DBHelper.instance.updateWalletTransaction(tx);
        if (updated == 0) {
          throw StateError('Transaksi tidak bisa diedit.');
        }
        final staff = ref.read(activeStaffProvider);
        await DBHelper.instance.insertAuditLog(AuditLog(
          action: 'wallet_transaction_updated',
          entityType: 'wallet_transaction',
          entityId: tx.id,
          staffId: staff?.id,
          staffName: staff?.name ?? 'Sistem',
          staffRole: staff?.role ?? '',
          amount: tx.nominal,
          note: '${tx.type} - ${_auditTitle(tx)}',
          createdAt: DateTime.now().toIso8601String(),
        ));
      } else {
        await DBHelper.instance.insertWalletTransaction(tx);
      }
      ref.invalidate(walletBalanceProvider);
      ref.invalidate(walletTransactionsProvider);
      ref.invalidate(auditLogsProvider);
      if (mounted) {
        _snack(_isEditing
            ? 'Transaksi berhasil diperbarui'
            : 'Transaksi berhasil disimpan');
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) _snack('Gagal menyimpan transaksi. Silakan coba lagi.');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  String _auditTitle(WalletTransaction tx) {
    final note = tx.keterangan.trim();
    if (note.isNotEmpty) return note;
    final category = tx.kategori?.trim();
    if (category != null && category.isNotEmpty) return category;
    return tx.type == 'masuk' ? 'Pemasukan Lain' : 'Pengeluaran Manual';
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: Colors.black87,
      behavior: SnackBarBehavior.floating,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final isTablet = mq.size.shortestSide >= 600;
    final isLandscape = mq.orientation == Orientation.landscape;

    if (isTablet || isLandscape) {
      return _buildWideLayout(context, isTablet: isTablet);
    }
    return _buildPortraitLayout(context);
  }

  //
  // LAYOUT: PORTRAIT (original)
  //
  Widget _buildPortraitLayout(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: _kBrand, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEditing ? 'Ubah $_pageTitle' : 'Tambah $_pageTitle',
          style: const TextStyle(
              fontSize: 17, fontWeight: FontWeight.bold, color: Colors.black87),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
              child: _buildFormFields(),
            ),
          ),
          _buildSaveButton(),
        ],
      ),
    );
  }

  Widget _buildWideLayout(BuildContext context, {required bool isTablet}) {
    final nomStr = _nominalController.text.replaceAll(RegExp(r'[^0-9]'), '');
    final nominal = int.tryParse(nomStr) ?? 0;

    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(
        bottom: false,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final horizontalPadding =
                constraints.maxWidth >= 1280 ? 32.0 : 16.0;
            final useStackedLayout = constraints.maxWidth < 980;
            final maxContentWidth = constraints.maxWidth >= 1500
                ? 1480.0
                : constraints.maxWidth - (horizontalPadding * 2);
            final sideWidth = constraints.maxWidth >= 1280 ? 340.0 : 300.0;

            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(
                horizontalPadding,
                24,
                horizontalPadding,
                32,
              ),
              child: Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: maxContentWidth.clamp(0, constraints.maxWidth),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildWideHeader(context),
                      const SizedBox(height: 18),
                      if (useStackedLayout) ...[
                        _DesktopPanel(child: _buildFormFields(isWide: true)),
                        const SizedBox(height: 16),
                        _buildSummaryPanel(nominal),
                      ] else
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: _DesktopPanel(
                                child: _buildFormFields(isWide: true),
                              ),
                            ),
                            const SizedBox(width: 20),
                            SizedBox(
                              width: sideWidth,
                              child: _buildSummaryPanel(nominal),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildWideHeader(BuildContext context) {
    return Row(
      children: [
        InkWell(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 46,
            height: 46,
            alignment: Alignment.center,
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.zero,
              border:
                  Border.fromBorderSide(BorderSide(color: Color(0xFFE2E8F0))),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: _kBrand,
              size: 18,
            ),
          ),
        ),
        const SizedBox(width: 14),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _pageTitle,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: Color(0xFF111827),
              ),
            ),
            const SizedBox(height: 2),
            const Text(
              'Catat transaksi Buku Kas Usaha dengan data yang rapi.',
              style: TextStyle(
                fontSize: 12.5,
                color: Color(0xFF64748B),
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSummaryPanel(int nominal) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Color(0xFF0F172A),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                alignment: Alignment.center,
                color: Colors.white12,
                child: Icon(_pageIcon, color: Colors.white, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _pageTitle,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 2),
                    const Text(
                      'Ringkasan sebelum disimpan',
                      style: TextStyle(color: Colors.white54, fontSize: 11.5),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _SummaryItem(
            icon: Icons.payments_outlined,
            label: 'Nominal',
            value: nominal > 0 ? _fmtRp(nominal) : 'Belum diisi',
            highlighted: nominal > 0,
          ),
          const SizedBox(height: 10),
          _SummaryItem(
            icon: _selectedWallet == 'non_tunai'
                ? Icons.credit_card_outlined
                : Icons.account_balance_wallet_outlined,
            label: 'Sumber Dana',
            value: _selectedWallet == 'tunai'
                ? 'Tunai'
                : _selectedWallet == 'non_tunai'
                    ? 'Non Tunai'
                    : 'Belum dipilih',
            highlighted: _selectedWallet != null,
          ),
          const SizedBox(height: 10),
          _SummaryItem(
            icon: Icons.calendar_month_outlined,
            label: 'Tanggal & Waktu',
            value: '${_fmtDate(_selectedDate)} ${_fmtTime(_selectedTime)}',
            highlighted: true,
          ),
          const SizedBox(height: 18),
          _buildSaveButtonContent(isSidebar: true),
        ],
      ),
    );
  }

  Widget _buildFormFields({bool isWide = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _FieldLabel('Pilih Sumber Dana'),
        const SizedBox(height: 8),
        _WalletSelectionRow(
          selected: _selectedWallet,
          onChanged: (val) => setState(() => _selectedWallet = val),
        ),
        const SizedBox(height: 22),
        _FieldLabel(_isExpense ? 'Kategori Pengeluaran' : 'Kategori Pemasukan'),
        const SizedBox(height: 8),
        _FinanceCategorySelector(
          type: _type,
          value: _isExpense ? _expenseCategory : _incomeCategory,
          onChanged: (value) => setState(() {
            if (_isExpense) {
              _expenseCategory = value;
            } else {
              _incomeCategory = value;
            }
          }),
        ),
        const SizedBox(height: 22),
        _FieldLabel(_nominalLabel),
        const SizedBox(height: 8),
        TextField(
          controller: _nominalController,
          keyboardType: TextInputType.number,
          inputFormatters: const [_CurrencyInputFormatter()],
          onChanged: (_) => setState(() {}),
          style: const TextStyle(
              fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black87),
          decoration: _inputDeco(hintText: '0', prefixText: 'Rp '),
        ),
        const SizedBox(height: 22),
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const _FieldLabel('Tanggal'),
                  const SizedBox(height: 8),
                  _DateTimeBox(
                    icon: Icons.calendar_month_outlined,
                    text: _fmtDate(_selectedDate),
                    onTap: _pickDate,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const _FieldLabel('Waktu'),
                  const SizedBox(height: 8),
                  _DateTimeBox(
                    icon: Icons.access_time_outlined,
                    text: _fmtTime(_selectedTime),
                    onTap: _pickTime,
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 22),
        _FieldLabel(
          _isExpense ? 'Keterangan (Opsional)' : 'Keterangan',
          required: !_isExpense,
        ),
        const SizedBox(height: 4),
        Text(
          _isExpense
              ? 'Tambahkan catatan kalau perlu, misalnya nomor nota atau detail pembayaran.'
              : 'Wajib diisi agar sumber pemasukan jelas di Buku Kas.',
          style: const TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _keteranganController,
          minLines: isWide ? 6 : 5,
          maxLines: isWide ? 7 : 5,
          style: const TextStyle(fontSize: 14, color: Colors.black87),
          decoration: _inputDeco(
            hintText: _isExpense
                ? 'Contoh: Bayar listrik toko, belanja bahan baku.'
                : 'Contoh: Uang tip, modal tambahan, dll.',
          ),
        ),
      ],
    );
  }

  Widget _buildSaveButton() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      child: SizedBox(
        width: double.infinity,
        height: 52,
        child: _buildSaveButtonContent(isSidebar: false),
      ),
    );
  }

  Widget _buildSaveButtonContent({bool isSidebar = false}) {
    return ElevatedButton(
      onPressed: _isSaving ? null : _save,
      style: ElevatedButton.styleFrom(
        backgroundColor: isSidebar ? Colors.white : _kBrand,
        foregroundColor: isSidebar ? _kBrand : Colors.white,
        disabledBackgroundColor:
            isSidebar ? Colors.white54 : _kBrand.withValues(alpha: 0.5),
        elevation: 0,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        padding: const EdgeInsets.symmetric(vertical: 14),
      ),
      child: _isSaving
          ? SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(
                  color: isSidebar ? _kBrand : Colors.white, strokeWidth: 2.5),
            )
          : const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.check_circle_outline_rounded, size: 18),
                SizedBox(width: 8),
                Text('Simpan Transaksi',
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3)),
              ],
            ),
    );
  }
}

class _DesktopPanel extends StatelessWidget {
  final Widget child;

  const _DesktopPanel({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: child,
    );
  }
}

class _SummaryItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final bool highlighted;

  const _SummaryItem({
    required this.icon,
    required this.label,
    required this.value,
    this.highlighted = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: highlighted ? 0.14 : 0.1),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: Colors.white.withValues(alpha: 0.06)),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white70, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.64),
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: highlighted ? Colors.white : Colors.white54,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// WALLET SELECTION ROW

class _WalletSelectionRow extends StatelessWidget {
  final String? selected;
  final ValueChanged<String> onChanged;

  const _WalletSelectionRow({required this.selected, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _WalletOptionCard(
            id: 'tunai',
            label: 'Tunai',
            icon: Icons.payments_outlined,
            isSelected: selected == 'tunai',
            onTap: () => onChanged('tunai'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _WalletOptionCard(
            id: 'non_tunai',
            label: 'Non Tunai',
            icon: Icons.credit_card_outlined,
            isSelected: selected == 'non_tunai',
            onTap: () => onChanged('non_tunai'),
          ),
        ),
      ],
    );
  }
}

class _FinanceCategorySelector extends ConsumerWidget {
  final String type;
  final String value;
  final ValueChanged<String> onChanged;

  const _FinanceCategorySelector({
    required this.type,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final categories = ref
        .watch(financeCategoriesProvider)
        .where((category) =>
            category.type == type &&
            category.active &&
            isManualFinanceCategory(category))
        .toList()
      ..sort((a, b) {
        final sortCompare = a.sortOrder.compareTo(b.sortOrder);
        if (sortCompare != 0) return sortCompare;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });
    final options = categories.isEmpty
        ? (type == 'masuk' ? _incomeCategories : _expenseCategories)
            .map((name) => FinanceCategory(
                  name: name,
                  type: type,
                  iconKey: defaultFinanceIconKey(type),
                  colorHex: defaultFinanceColorHex(type),
                  createdAt: '',
                  updatedAt: '',
                ))
            .toList()
        : categories;

    return InkWell(
      onTap: () async {
        final selected = await showModalBottomSheet<String>(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          builder: (ctx) => _FinanceCategoryPickerSheet(
            title:
                type == 'masuk' ? 'Kategori Pemasukan' : 'Kategori Pengeluaran',
            value: value,
            options: options,
          ),
        );
        if (selected != null) onChanged(selected);
      },
      child: InputDecorator(
        decoration: _inputDeco(hintText: 'Pilih kategori'),
        child: Row(
          children: [
            Expanded(
              child: Text(
                value,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textTitle,
                ),
              ),
            ),
            const Icon(Icons.keyboard_arrow_down_rounded,
                color: AppColors.textCaption),
          ],
        ),
      ),
    );
  }
}

class _FinanceCategoryPickerSheet extends StatelessWidget {
  final String title;
  final String value;
  final List<FinanceCategory> options;

  const _FinanceCategoryPickerSheet({
    required this.title,
    required this.value,
    required this.options,
  });

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    final columns = screenWidth >= 720 ? 2 : 1;
    final rows = (options.length / columns).ceil();
    final desiredListHeight = (rows * 48.0) + (rows > 1 ? (rows - 1) * 8 : 0);
    final maxListHeight = screenHeight * 0.52;
    final listHeight =
        desiredListHeight > maxListHeight ? maxListHeight : desiredListHeight;

    return SafeArea(
      top: false,
      child: Align(
        alignment: Alignment.bottomCenter,
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: 620,
            maxHeight: screenHeight * 0.72,
          ),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 12),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.zero),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(height: 12),
                Container(
                  width: 42,
                  height: 4,
                  color: const Color(0xFFE2E8F0),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 14),
                  child: Text(
                    title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textTitle,
                    ),
                  ),
                ),
                Flexible(
                  child: SizedBox(
                    height: listHeight,
                    child: GridView.builder(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                      itemCount: options.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: columns,
                        crossAxisSpacing: 8,
                        mainAxisSpacing: 8,
                        mainAxisExtent: 48,
                      ),
                      itemBuilder: (context, index) {
                        final category = options[index];
                        final selected = category.name == value;
                        return InkWell(
                          onTap: () => Navigator.pop(context, category.name),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            decoration: BoxDecoration(
                              color: selected
                                  ? AppColors.primaryBrand
                                      .withValues(alpha: 0.08)
                                  : Colors.white,
                              border: Border.all(
                                color: selected
                                    ? AppColors.primaryBrand
                                    : const Color(0xFFE2E8F0),
                              ),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    category.name,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: selected
                                          ? FontWeight.w900
                                          : FontWeight.w700,
                                      color: selected
                                          ? AppColors.primaryBrand
                                          : AppColors.textTitle,
                                    ),
                                  ),
                                ),
                                if (selected)
                                  const Icon(Icons.check_rounded,
                                      color: AppColors.primaryBrand, size: 18),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _WalletOptionCard extends StatelessWidget {
  final String id;
  final String label;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _WalletOptionCard({
    required this.id,
    required this.label,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
        decoration: BoxDecoration(
          color: isSelected ? _kBrand.withValues(alpha: 0.08) : Colors.white,
          border: Border.all(
            color: isSelected ? _kBrand : const Color(0xFFE0E0E0),
            width: isSelected ? 1.5 : 1.0,
          ),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 22, color: isSelected ? _kBrand : Colors.black54),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                color: isSelected ? _kBrand : Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// INPUT DECORATION HELPER

InputDecoration _inputDeco({String? hintText, String? prefixText}) {
  const border = OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.zero),
    borderSide: BorderSide(color: Color(0xFFE0E0E0)),
  );
  return InputDecoration(
    hintText: hintText,
    hintStyle: const TextStyle(color: Colors.black38, fontSize: 14),
    prefixText: prefixText,
    prefixStyle: const TextStyle(color: Colors.black87, fontSize: 15),
    border: border,
    enabledBorder: border,
    focusedBorder: border.copyWith(
        borderSide: const BorderSide(color: _kBrand, width: 1.5)),
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
  );
}

// FIELD LABEL

class _FieldLabel extends StatelessWidget {
  final String text;
  final bool required;
  const _FieldLabel(this.text, {this.required = true});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(text,
            style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Colors.black87)),
        if (required) ...[
          const SizedBox(width: 3),
          const Text('*',
              style:
                  TextStyle(color: AppColors.danger, fontSize: 14, height: 1)),
        ],
      ],
    );
  }
}

// DATE / TIME BOX

class _DateTimeBox extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  const _DateTimeBox(
      {required this.icon, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFFE0E0E0)),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          children: [
            Icon(icon, size: 18, color: Colors.black54),
            const SizedBox(width: 8),
            Text(text,
                style: const TextStyle(fontSize: 13.5, color: Colors.black87)),
          ],
        ),
      ),
    );
  }
}

