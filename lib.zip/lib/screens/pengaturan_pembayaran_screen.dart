import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import '../database/db_helper.dart';
import '../core/theme.dart';
import '../widgets/kasir_dialog.dart';
import 'responsive_layout.dart';
import '../widgets/admin_pin_dialog.dart';
import '../providers/providers.dart';
import '../utils/image_utils.dart';

const Color _kBrand = AppColors.primaryBrand;

const List<String> _kBankList = [
  'BCA',
  'Mandiri',
  'BNI',
  'BRI',
  'Bank Syariah Indonesia (BSI)',
  'CIMB Niaga',
  'Bank Tabungan Negara (BTN)',
  'Bank Danamon',
  'Permata Bank',
  'Maybank Indonesia',
  'OCBC NISP',
  'Panin Bank',
  'Bank Mega',
  'Bank DKI',
  'Bank Jabar Banten (BJB)',
  'Bank Jateng',
  'Bank Jatim',
  'GoPay',
  'OVO',
  'DANA',
  'LinkAja',
  'ShopeePay',
];

class PengaturanPembayaranScreen extends ConsumerStatefulWidget {
  const PengaturanPembayaranScreen({super.key});

  @override
  ConsumerState<PengaturanPembayaranScreen> createState() =>
      _PengaturanPembayaranScreenState();
}

class _PengaturanPembayaranScreenState
    extends ConsumerState<PengaturanPembayaranScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final List<Map<String, TextEditingController>> _bankControllers = [];
  final _qrisNameCtrl = TextEditingController();
  final _qrisNameFocus = FocusNode();
  late final TabController _tabController;
  File? _qrisFile;
  bool _isLoading = true;
  int _expandedBankIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadSettings();
  }

  @override
  void dispose() {
    for (var bank in _bankControllers) {
      bank['name']?.dispose();
      bank['account_name']?.dispose();
      bank['account_number']?.dispose();
    }
    _qrisNameCtrl.dispose();
    _qrisNameFocus.dispose();
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    final settings = await DBHelper.instance.getPaymentSettings();
    if (settings != null) {
      final qrisPath = settings['qris_path'] ?? '';
      if (qrisPath.isNotEmpty && File(qrisPath).existsSync()) {
        _qrisFile = File(qrisPath);
      }
      _qrisNameCtrl.text = settings['qris_name'] ?? '';

      // Load Banks
      _bankControllers.clear();
      final banksJson = settings['banks_json'] as String?;
      if (banksJson != null && banksJson.isNotEmpty) {
        try {
          final List decoded = jsonDecode(banksJson);
          for (var item in decoded) {
            _addBankEntry(
              name: item['name'] ?? '',
              accountName: item['account_name'] ?? '',
              accountNumber: item['account_number'] ?? '',
            );
          }
        } catch (_) {}
      }

      // Fallback/Migration from old columns
      if (_bankControllers.isEmpty) {
        final oldBankName = settings['bank_name'] ?? '';
        final oldAccName = settings['account_name'] ?? '';
        final oldAccNumber = settings['account_number'] ?? '';
        if (oldBankName.isNotEmpty ||
            oldAccName.isNotEmpty ||
            oldAccNumber.isNotEmpty) {
          _addBankEntry(
            name: oldBankName,
            accountName: oldAccName,
            accountNumber: oldAccNumber,
          );
        } else {
          // At least one empty entry
          _addBankEntry();
        }
      }
    } else {
      _addBankEntry();
    }
    setState(() => _isLoading = false);
  }

  void _addBankEntry(
      {String name = '', String accountName = '', String accountNumber = ''}) {
    // Validation: Check if the last bank is complete
    if (_bankControllers.isNotEmpty) {
      final last = _bankControllers.last;
      bool isComplete = last['name']!.text.trim().isNotEmpty &&
          last['account_name']!.text.trim().isNotEmpty &&
          last['account_number']!.text.trim().isNotEmpty;

      if (!isComplete) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Lengkapi rekening sebelumnya terlebih dahulu'),
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ));
        return;
      }
    }

    _bankControllers.add({
      'name': TextEditingController(text: name),
      'account_name': TextEditingController(text: accountName),
      'account_number': TextEditingController(text: accountNumber),
    });
    // Expand the new one
    setState(() => _expandedBankIndex = _bankControllers.length - 1);
  }

  Future<void> _removeBankEntry(int index) async {
    final bank = _bankControllers[index];
    final name = bank['name']!.text.trim();
    final number = bank['account_number']!.text.trim();

    // Only show dialog if something is actually filled
    if (name.isNotEmpty || number.isNotEmpty) {
      String display = name.isEmpty ? 'Rekening' : '$name ($number)';
      final confirm = await showKasirConfirmDialog(
        context,
        title: 'Hapus Rekening',
        message: 'Apakah Anda yakin ingin menghapus $display?',
        confirmLabel: 'Hapus',
        cancelLabel: 'Batal',
      );
      if (confirm != true) return;
    }

    if (_bankControllers.length <= 1) {
      // Clear if only one
      _bankControllers[0]['name']?.clear();
      _bankControllers[0]['account_name']?.clear();
      _bankControllers[0]['account_number']?.clear();
      setState(() => _expandedBankIndex = 0);
      return;
    }

    final controllers = _bankControllers.removeAt(index);
    controllers['name']?.dispose();
    controllers['account_name']?.dispose();
    controllers['account_number']?.dispose();

    // Adjust expanded index
    if (_expandedBankIndex >= _bankControllers.length) {
      _expandedBankIndex = _bankControllers.length - 1;
    }
    if (_expandedBankIndex < 0) _expandedBankIndex = 0;

    setState(() {});
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(source: source, imageQuality: 80);
      if (picked == null) return;

      String imagePath = picked.path;
      if (!Platform.isWindows) {
        final cropped = await ImageCropper().cropImage(
          sourcePath: picked.path,
          aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
          compressQuality: 92,
          uiSettings: [
            AndroidUiSettings(
              toolbarTitle: 'Sesuaikan QRIS',
              toolbarColor: _kBrand,
              toolbarWidgetColor: Colors.white,
              statusBarLight: false,
              activeControlsWidgetColor: _kBrand,
              lockAspectRatio: true,
            ),
            IOSUiSettings(
              title: 'Sesuaikan QRIS',
              aspectRatioLockEnabled: true,
            ),
          ],
        );
        if (cropped == null) return;
        imagePath = cropped.path;
      }

      final savedPath = await ImageUtils.saveImageToLocalDirectory(imagePath);
      if (!mounted) return;
      setState(() => _qrisFile = File(savedPath ?? imagePath));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Gagal memilih gambar QRIS. Silakan coba lagi.'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
    }
  }

  Future<void> _simpan() async {
    if (_qrisFile != null && _qrisNameCtrl.text.trim().isEmpty) {
      _tabController.animateTo(0);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Nama QRIS wajib diisi jika gambar QRIS digunakan.'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
      Future<void>.delayed(const Duration(milliseconds: 250), () {
        if (mounted) _qrisNameFocus.requestFocus();
      });
      return;
    }
    if (!_formKey.currentState!.validate()) return;

    // PIN Guard
    final pinOk = await AdminPinDialog.show(
      context,
      verifyPin: (pin) {
        final profilNotifier = ref.read(profilProvider.notifier);
        if (!profilNotifier.hasConfiguredAdminPin) {
          return 'PIN admin belum diatur. Buka Pengaturan Profil.';
        }
        final ok = profilNotifier.verifyPin(pin);
        return ok ? '' : 'PIN salah';
      },
      title: 'Simpan Pengaturan Pembayaran',
      subtitle: 'Masukkan PIN Admin untuk menyimpan perubahan',
    );
    if (!pinOk || !mounted) return;

    final List<Map<String, String>> banksList = _bankControllers
        .map((b) => {
              'name': b['name']!.text.trim(),
              'account_name': b['account_name']!.text.trim(),
              'account_number': b['account_number']!.text.trim(),
            })
        .where((b) => b['name']!.isNotEmpty || b['account_number']!.isNotEmpty)
        .toList();

    final String banksJson = jsonEncode(banksList);

    // For backward compatibility, also save first bank to old columns
    final firstBank = banksList.isNotEmpty ? banksList.first : null;

    setState(() => _isLoading = true);
    await DBHelper.instance.savePaymentSettings(
      qrisPath: _qrisFile?.path ?? '',
      bankName: firstBank?['name'] ?? '',
      accountName: firstBank?['account_name'] ?? '',
      accountNumber: firstBank?['account_number'] ?? '',
      banksJson: banksJson,
      qrisName: _qrisNameCtrl.text.trim(),
    );
    if (!mounted) return;
    setState(() => _isLoading = false);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Pengaturan pembayaran berhasil disimpan'),
      backgroundColor: Colors.black87,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final tablet = isTabletDevice(context);

    return KasirResponsiveScaffold(
      title: 'Bank & QRIS',
      showNavRail: false,
      backgroundColor: tablet ? const Color(0xFFF5F7FA) : Colors.white,
      bottom: TabBar(
        controller: _tabController,
        labelColor: _kBrand,
        unselectedLabelColor: Colors.black54,
        indicatorColor: _kBrand,
        indicatorWeight: 3,
        indicatorSize: TabBarIndicatorSize.tab,
        labelStyle: GoogleFonts.plusJakartaSans(
            fontWeight: FontWeight.w700, fontSize: 13),
        unselectedLabelStyle: GoogleFonts.plusJakartaSans(
            fontWeight: FontWeight.w600, fontSize: 13),
        tabs: const [
          Tab(text: 'QRIS'),
          Tab(text: 'REKENING BANK'),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: _kBrand))
          : Form(
              key: _formKey,
              child: TabBarView(
                controller: _tabController,
                children: [
                  // Tab 1: QRIS
                  SingleChildScrollView(
                    padding: EdgeInsets.symmetric(
                      vertical: tablet ? 32 : 20,
                      horizontal: tablet ? 40 : 16,
                    ),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 600),
                        child: _QrisPanel(
                          qrisFile: _qrisFile,
                          nameCtrl: _qrisNameCtrl,
                          nameFocus: _qrisNameFocus,
                          tablet: tablet,
                          onPick: _pickImage,
                        ),
                      ),
                    ),
                  ),
                  // Tab 2: Bank
                  SingleChildScrollView(
                    padding: EdgeInsets.symmetric(
                      vertical: tablet ? 32 : 20,
                      horizontal: tablet ? 40 : 16,
                    ),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 700),
                        child: _BankPanel(
                          bankControllers: _bankControllers,
                          tablet: tablet,
                          expandedIndex: _expandedBankIndex,
                          onExpand: (i) => setState(() => _expandedBankIndex =
                              (_expandedBankIndex == i ? -1 : i)),
                          onAdd: () => _addBankEntry(),
                          onRemove: (i) => _removeBankEntry(i),
                          onShowSelector: _showBankSelector,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(tablet ? 24 : 16),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _simpan,
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
                elevation: 0,
              ),
              child: const Text('Simpan Pengaturan',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            ),
          ),
        ),
      ),
    );
  }

  void _showBankSelector(TextEditingController controller) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _BankSelectorModal(
        onSelect: (val) {
          controller.text = val;
          Navigator.pop(context);
        },
      ),
    );
  }
}

class _BankSelectorModal extends StatefulWidget {
  final Function(String) onSelect;

  const _BankSelectorModal({required this.onSelect});

  @override
  State<_BankSelectorModal> createState() => _BankSelectorModalState();
}

class _BankSelectorModalState extends State<_BankSelectorModal> {
  String _search = '';

  @override
  Widget build(BuildContext context) {
    final filtered = _kBankList
        .where((b) => b.toLowerCase().contains(_search.toLowerCase()))
        .toList();

    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: Color(0xFFEEEEEE))),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Pilih Bank / E-Wallet',
                    style: GoogleFonts.plusJakartaSans(
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                        color: const Color(0xFF1E293B))),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close_rounded),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: TextField(
              onChanged: (v) => setState(() => _search = v),
              autofocus: true,
              style: GoogleFonts.plusJakartaSans(
                  fontSize: 14, fontWeight: FontWeight.w600),
              decoration: const InputDecoration(
                hintText: 'Cari nama bank / E-Wallet',
                prefixIcon: Icon(Icons.search_rounded, color: _kBrand),
                filled: true,
                fillColor: Color(0xFFF8FAFC),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: Color(0xFFE2E8F0))),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: Color(0xFFE2E8F0))),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: _kBrand, width: 1.5)),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filtered.length,
              padding: const EdgeInsets.only(bottom: 20),
              itemBuilder: (context, index) {
                final bank = filtered[index];
                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 24),
                  title: Text(bank,
                      style: GoogleFonts.plusJakartaSans(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: const Color(0xFF1E293B))),
                  trailing: const Icon(Icons.chevron_right_rounded,
                      color: Colors.grey),
                  onTap: () => widget.onSelect(bank),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

//  QRIS PANEL

class _QrisPanel extends StatelessWidget {
  final File? qrisFile;
  final TextEditingController nameCtrl;
  final FocusNode nameFocus;
  final bool tablet;
  final Function(ImageSource) onPick;

  const _QrisPanel({
    required this.qrisFile,
    required this.nameCtrl,
    required this.nameFocus,
    required this.tablet,
    required this.onPick,
  });

  @override
  Widget build(BuildContext context) {
    final qrSize = tablet ? 240.0 : 200.0;
    return Container(
      padding: EdgeInsets.all(tablet ? 32 : 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 15,
              offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('QRIS Pembayaran',
              style: GoogleFonts.plusJakartaSans(
                  fontSize: tablet ? 18 : 16,
                  fontWeight: FontWeight.w800,
                  color: const Color(0xFF1E293B))),
          const SizedBox(height: 4),
          Text('Gunakan gambar QRIS statis atau dinamis toko Anda.',
              style: GoogleFonts.plusJakartaSans(
                  fontSize: 12, color: Colors.black45)),
          const SizedBox(height: 24),
          TextFormField(
            controller: nameCtrl,
            focusNode: nameFocus,
            validator: (value) {
              if (qrisFile != null && (value ?? '').trim().isEmpty) {
                return 'Nama QRIS wajib diisi.';
              }
              return null;
            },
            style: GoogleFonts.plusJakartaSans(
                fontSize: 15, fontWeight: FontWeight.w600),
            decoration: InputDecoration(
              labelText: 'Nama QRIS (tampil di kasir) *',
              hintText: 'Contoh: TOKO BERKAH',
              helperText: 'Nama ini akan tampil besar saat QRIS dibuka.',
              prefixIcon: const Icon(Icons.badge_outlined, color: _kBrand),
              filled: true,
              fillColor: const Color(0xFFF8FAFC),
              border: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFE2E8F0)),
              ),
              enabledBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFE2E8F0)),
              ),
              focusedBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: _kBrand, width: 2),
              ),
              labelStyle: GoogleFonts.plusJakartaSans(color: Colors.black54),
            ),
          ),
          const SizedBox(height: 24),
          Center(
            child: Container(
              width: qrSize,
              height: qrSize,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                borderRadius: BorderRadius.zero,
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: qrisFile != null
                  ? Image.file(qrisFile!, fit: BoxFit.contain)
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.qr_code_2_rounded,
                            size: 64, color: Colors.grey.shade200),
                        const SizedBox(height: 12),
                        Text('Belum ada QRIS Pembayaran',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.plusJakartaSans(
                                color: Colors.grey.shade400, fontSize: 13)),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _ActionBtn(
                label: 'Kamera',
                icon: Icons.camera_alt_rounded,
                onTap: () => onPick(ImageSource.camera),
              ),
              const SizedBox(width: 12),
              _ActionBtn(
                label: 'Galeri',
                icon: Icons.image_rounded,
                onTap: () => onPick(ImageSource.gallery),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

//  BANK PANEL

class _BankPanel extends StatelessWidget {
  final List<Map<String, TextEditingController>> bankControllers;
  final bool tablet;
  final int expandedIndex;
  final Function(int) onExpand;
  final VoidCallback onAdd;
  final Function(int) onRemove;
  final Function(TextEditingController) onShowSelector;

  const _BankPanel({
    required this.bankControllers,
    required this.tablet,
    required this.expandedIndex,
    required this.onExpand,
    required this.onAdd,
    required this.onRemove,
    required this.onShowSelector,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(tablet ? 32 : 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 15,
              offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Rekening Bank',
                        style: GoogleFonts.plusJakartaSans(
                            fontSize: tablet ? 18 : 16,
                            fontWeight: FontWeight.w800,
                            color: const Color(0xFF1E293B))),
                    const SizedBox(height: 4),
                    Text('Tambahkan hingga beberapa rekening bank.',
                        style: GoogleFonts.plusJakartaSans(
                            fontSize: 12, color: Colors.black45)),
                  ],
                ),
              ),
              GestureDetector(
                onTap: onAdd,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _kBrand.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.zero,
                  ),
                  child:
                      const Icon(Icons.add_rounded, color: _kBrand, size: 24),
                ),
              ),
            ],
          ),
          const SizedBox(height: 32),
          ListView.separated(
            shrinkWrap: true,
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: bankControllers.length,
            separatorBuilder: (_, __) => const SizedBox(height: 16),
            itemBuilder: (ctx, index) {
              final bank = bankControllers[index];
              final isExpanded = expandedIndex == index;
              final bankName = bank['name']!.text;
              final accNum = bank['account_number']!.text;

              return AnimatedContainer(
                key: ValueKey('bank_${index}_${bankControllers.length}'),
                duration: const Duration(milliseconds: 300),
                decoration: BoxDecoration(
                  color: isExpanded ? const Color(0xFFF8FAFC) : Colors.white,
                  borderRadius: BorderRadius.zero,
                  border: Border.all(
                      color: isExpanded
                          ? const Color(0xFFE2E8F0)
                          : Colors.grey.shade200),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header / Summary
                    InkWell(
                      onTap: () => onExpand(index),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: isExpanded
                                    ? const Color(0xFF1E293B)
                                    : Colors.grey.shade100,
                                borderRadius: BorderRadius.zero,
                              ),
                              child: Text('#${index + 1}',
                                  style: GoogleFonts.plusJakartaSans(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w900,
                                      color: isExpanded
                                          ? Colors.white
                                          : Colors.black54,
                                      letterSpacing: 1.0)),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: isExpanded
                                  ? Text('PENGATURAN REKENING',
                                      style: GoogleFonts.plusJakartaSans(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w900,
                                          color: const Color(0xFF64748B),
                                          letterSpacing: 1.0))
                                  : Text(
                                      bankName.isEmpty
                                          ? 'Rekening belum diisi'
                                          : '$bankName - $accNum',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.plusJakartaSans(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w700,
                                          color: const Color(0xFF334155))),
                            ),
                            if (bankControllers.length > 1)
                              IconButton(
                                onPressed: () => onRemove(index),
                                icon: const Icon(AppIcons.recycleBin,
                                    size: 18, color: Colors.redAccent),
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(),
                              ),
                            const SizedBox(width: 8),
                            Icon(
                                isExpanded
                                    ? Icons.keyboard_arrow_up_rounded
                                    : Icons.keyboard_arrow_down_rounded,
                                size: 20,
                                color: Colors.black26),
                          ],
                        ),
                      ),
                    ),
                    if (isExpanded)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                        child: Column(
                          children: [
                            const Divider(height: 1),
                            const SizedBox(height: 20),
                            _buildInput(
                              label: 'NAMA BANK',
                              controller: bank['name']!,
                              hint: 'Pilih Bank / E-Wallet',
                              readOnly: true,
                              onTap: () => onShowSelector(bank['name']!),
                              suffixIcon: const Icon(
                                  Icons.keyboard_arrow_down_rounded,
                                  color: _kBrand),
                            ),
                            const SizedBox(height: 20),
                            _buildInput(
                              label: 'NOMOR REKENING',
                              controller: bank['account_number']!,
                              hint: 'XXXX-XXXX-XXXX',
                              keyboardType: TextInputType.number,
                            ),
                            const SizedBox(height: 20),
                            _buildInput(
                              label: 'ATAS NAMA',
                              controller: bank['account_name']!,
                              hint: 'Nama lengkap sesuai buku tabungan',
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required String hint,
    TextInputType keyboardType = TextInputType.text,
    bool readOnly = false,
    VoidCallback? onTap,
    Widget? suffixIcon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: GoogleFonts.plusJakartaSans(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                color: const Color(0xFF64748B),
                letterSpacing: 0.5)),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          readOnly: readOnly,
          onTap: onTap,
          style: GoogleFonts.plusJakartaSans(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF1E293B)),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: GoogleFonts.plusJakartaSans(
                color: Colors.grey.shade400,
                fontWeight: FontWeight.w400,
                fontSize: 13),
            suffixIcon: suffixIcon,
            filled: true,
            fillColor: Colors.white,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            border: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFE2E8F0))),
            enabledBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFE2E8F0))),
            focusedBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: _kBrand, width: 1.5)),
          ),
        ),
      ],
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _ActionBtn(
      {required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        foregroundColor: _kBrand,
        side: const BorderSide(color: _kBrand, width: 1.5),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ),
      icon: Icon(icon, size: 20),
      label: Text(label,
          style: GoogleFonts.plusJakartaSans(
              fontWeight: FontWeight.w700, fontSize: 13)),
    );
  }
}

