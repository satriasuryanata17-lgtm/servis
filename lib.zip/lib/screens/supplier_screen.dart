import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../utils/currency_input_formatter.dart';
import '../widgets/supplier_form_sheet.dart';
import 'responsive_layout.dart';

//
//  SUPPLIER SCREEN  Responsive (Portrait + Landscape/Tablet)
//
const Color _kBrand = AppColors.primaryBrand;

class SupplierScreen extends StatefulWidget {
  const SupplierScreen({super.key});
  @override
  State<SupplierScreen> createState() => _SupplierScreenState();
}

class _SupplierScreenState extends State<SupplierScreen> {
  final _searchCtrl = TextEditingController();
  String _query = '';
  List<Supplier> _suppliers = [];
  Map<int, List<Map<String, dynamic>>> _supplierProducts = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final data = await DBHelper.instance.getAllSuppliers();
    final productSummary =
        await DBHelper.instance.getSupplierProductSummaryMap();
    if (mounted) {
      setState(() {
        _suppliers = data;
        _supplierProducts = productSummary;
        _loading = false;
      });
    }
  }

  List<Supplier> _filter(List<Supplier> list) {
    if (_query.isEmpty) return list;
    final q = _query.toLowerCase();
    return list.where((s) {
      return s.name.toLowerCase().contains(q) ||
          (s.phone?.toLowerCase().contains(q) ?? false) ||
          (s.address?.toLowerCase().contains(q) ?? false);
    }).toList();
  }

  void _showForm({Supplier? supplier}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => SupplierFormSheet(
        supplier: supplier,
        onSaved: (_) {
          Navigator.pop(context);
          _load();
        },
      ),
    );
  }

  void _confirmDelete(Supplier s) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Text('Hapus Supplier',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        content: Text(
            'Hapus "${s.name}"? Riwayat pembelian supplier tidak ikut terhapus.',
            style: const TextStyle(fontSize: 14)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child:
                  const Text('Batal', style: TextStyle(color: Colors.black45))),
          TextButton(
            onPressed: () async {
              await DBHelper.instance.deleteSupplier(s.id!);
              if (ctx.mounted) Navigator.pop(ctx);
              _load();
            },
            child: const Text('Hapus',
                style: TextStyle(
                    color: AppColors.danger, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showBayarHutang(Supplier s) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: Text('Bayar Hutang ke ${s.name}',
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Sisa Hutang: ${_fRp(s.hutang)}',
                style: const TextStyle(
                    fontWeight: FontWeight.w600, color: AppColors.danger)),
            const SizedBox(height: 16),
            TextField(
              controller: ctrl,
              keyboardType: TextInputType.number,
              inputFormatters: const [CurrencyInputFormatter()],
              decoration: _inputDecor('Nominal Pembayaran (Rp)'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child:
                  const Text('Batal', style: TextStyle(color: Colors.black45))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              elevation: 0,
            ),
            onPressed: () async {
              final nominal = parseCurrencyInput(ctrl.text);
              if (nominal <= 0) return;
              await DBHelper.instance.bayarHutangSupplier(s.id!, nominal);
              if (ctx.mounted) Navigator.pop(ctx);
              _load();
            },
            child: const Text('Bayar',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Future<void> _showManageProducts(Supplier supplier) async {
    final supplierId = supplier.id;
    if (supplierId == null) return;

    final products = await DBHelper.instance.getProductsForSupplierPurchase();
    if (!mounted) return;

    final supplierNames = {
      for (final s in _suppliers)
        if (s.id != null) s.id!: s.name,
    };
    final initialSelected = products
        .where((p) => p.supplierId == supplierId)
        .map((p) => p.id)
        .whereType<int>()
        .toSet();

    final selected = await showModalBottomSheet<Set<int>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _SupplierProductPickerSheet(
        supplier: supplier,
        products: products,
        supplierNames: supplierNames,
        initialSelected: initialSelected,
      ),
    );
    if (selected == null) return;

    await DBHelper.instance.setSupplierProducts(supplierId, selected);
    await _load();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Produk supplier diperbarui.'),
      backgroundColor: AppColors.success,
      behavior: SnackBarBehavior.floating,
    ));
  }

  String _fRp(int n) {
    if (n == 0) return 'Rp 0';
    String s = n.abs().toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return 'Rp $r';
  }

  InputDecoration _inputDecor(String hint) => InputDecoration(
        hintText: hint,
        isDense: true,
        filled: true,
        fillColor: const Color(0xFFF6F7F9),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: Color(0xFFE8E8E8))),
        enabledBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: Color(0xFFE8E8E8))),
        focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: _kBrand, width: 1.5)),
      );

  @override
  Widget build(BuildContext context) {
    final list = _filter(_suppliers);
    final totalHutang = _suppliers.fold<int>(0, (s, e) => s + e.hutang);
    final suppliersWithHutang = _suppliers.where((s) => s.hutang > 0).length;

    return KasirResponsiveScaffold(
      title: 'Supplier',
      actions: [
        _TotalSupplierAction(count: _suppliers.length),
        const SizedBox(width: 8),
      ],
      showNavRail: false,
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          decoration: const BoxDecoration(
            color: Colors.white,
            border: Border(top: BorderSide(color: Color(0xFFEEEEEE))),
          ),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton.icon(
              onPressed: () => _showForm(),
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
              icon: const Icon(Icons.add_business_rounded),
              label: const Text('Tambah Supplier',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            ),
          ),
        ),
      ),
      body: LayoutBuilder(builder: (context, constraints) {
        final wide = constraints.maxWidth >= 720;
        if (wide && (totalHutang > 0 || suppliersWithHutang > 0)) {
          return ResponsiveReportLayout(
            filterPanel: _buildSideStats(totalHutang, suppliersWithHutang),
            content: Column(
              children: [
                _buildSearchBar(),
                const Divider(height: 1, color: Color(0xFFEEEEEE)),
                Expanded(child: _buildList(context, list)),
              ],
            ),
          );
        } else {
          return Column(
            children: [
              _buildSearchBar(),
              const Divider(height: 1, color: Color(0xFFEEEEEE)),
              Expanded(child: _buildList(context, list)),
            ],
          );
        }
      }),
    );
  }

  Widget _buildSideStats(int totalHutang, int suppliersWithHutang,
      {bool isNarrow = false}) {
    // Return row for narrow screens, column for wide
    if (isNarrow) {
      final stats = <Widget>[
        _buildMiniStat(
          'Total Supplier',
          '${_suppliers.length}',
          Icons.people_alt_rounded,
          null,
        ),
        if (suppliersWithHutang > 0)
          _buildMiniStat(
            'Ada Hutang',
            '$suppliersWithHutang',
            Icons.warning_amber_rounded,
            AppColors.danger,
          ),
        if (totalHutang > 0)
          _buildMiniStat(
            'Total Hutang',
            _fRp(totalHutang),
            Icons.payments_rounded,
            AppColors.danger,
          ),
      ];
      return Container(
        color: const Color(0xFFF8FAFC),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        child: Row(
          children: List.generate(stats.length, (index) {
            return Expanded(
              child: Row(
                children: [
                  if (index > 0)
                    Container(
                        width: 1, height: 32, color: const Color(0xFFE2E8F0)),
                  Expanded(child: stats[index]),
                ],
              ),
            );
          }),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          KasirStatCard(
            label: 'Total Supplier',
            value: '${_suppliers.length}',
            icon: Icons.people_alt_rounded,
          ),
          const SizedBox(height: 12),
          KasirStatCard(
            label: 'Punya Hutang',
            value: '$suppliersWithHutang',
            icon: Icons.warning_amber_rounded,
            color: suppliersWithHutang > 0 ? AppColors.danger : null,
          ),
          if (totalHutang > 0) ...[
            const SizedBox(height: 12),
            KasirStatCard(
              label: 'Total Hutang',
              value: _fRp(totalHutang),
              icon: Icons.payments_rounded,
              color: AppColors.danger,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildMiniStat(
      String label, String value, IconData icon, Color? color) {
    return Column(
      children: [
        Icon(icon, size: 16, color: color ?? Colors.black54),
        const SizedBox(height: 2),
        Text(value,
            style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: color ?? Colors.black87),
            maxLines: 1,
            overflow: TextOverflow.ellipsis),
        Text(label,
            style: const TextStyle(fontSize: 11, color: Colors.black54),
            maxLines: 1,
            overflow: TextOverflow.ellipsis),
      ],
    );
  }

  Widget _buildSearchBar() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFFF1F5F9),
          borderRadius: BorderRadius.zero,
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: TextField(
          controller: _searchCtrl,
          onChanged: (v) => setState(() => _query = v),
          decoration: const InputDecoration(
            hintText: 'Cari nama, telepon, atau alamat...',
            hintStyle: TextStyle(fontSize: 13, color: Colors.black38),
            prefixIcon: Icon(Icons.search, color: Colors.black38, size: 20),
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(vertical: 12),
          ),
        ),
      ),
    );
  }

  Widget _buildList(BuildContext context, List<Supplier> list) {
    if (_loading) {
      return const Center(
          child: CircularProgressIndicator(color: _kBrand, strokeWidth: 2));
    }
    if (list.isEmpty) {
      return _EmptyState(isSearching: _query.isNotEmpty);
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
      itemCount: list.length,
      itemBuilder: (_, i) {
        final s = list[i];
        return _SupplierCard(
          supplier: s,
          products:
              s.id == null ? const [] : (_supplierProducts[s.id!] ?? const []),
          onEdit: () => _showForm(supplier: s),
          onDelete: () => _confirmDelete(s),
          onBayar: () => _showBayarHutang(s),
          onManageProducts: () => _showManageProducts(s),
        );
      },
    );
  }
}

class _TotalSupplierAction extends StatelessWidget {
  final int count;
  const _TotalSupplierAction({required this.count});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: _kBrand.withValues(alpha: 0.08),
          border: Border.all(color: _kBrand.withValues(alpha: 0.18)),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.people_alt_rounded, size: 15, color: _kBrand),
            const SizedBox(width: 6),
            Text(
              '$count',
              style: const TextStyle(
                color: _kBrand,
                fontSize: 14,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(width: 4),
            const Text(
              'Supplier',
              style: TextStyle(
                color: _kBrand,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SupplierCard extends StatelessWidget {
  final Supplier supplier;
  final List<Map<String, dynamic>> products;
  final VoidCallback onEdit, onDelete, onBayar, onManageProducts;

  const _SupplierCard({
    required this.supplier,
    required this.products,
    required this.onEdit,
    required this.onDelete,
    required this.onBayar,
    required this.onManageProducts,
  });

  @override
  Widget build(BuildContext context) {
    final kBrandLight = AppColors.primaryBrand.withValues(alpha: 0.08);
    const avatarSize = 48.0;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.02),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: avatarSize,
                  height: avatarSize,
                  decoration: BoxDecoration(
                      color: kBrandLight, borderRadius: BorderRadius.zero),
                  child: const Icon(Icons.business_rounded,
                      color: _kBrand, size: 22),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(supplier.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Color(0xFF1E293B))),
                      if (supplier.phone?.isNotEmpty == true)
                        Text(supplier.phone!,
                            style: const TextStyle(
                                fontSize: 13, color: Color(0xFF64748B))),
                    ],
                  ),
                ),
                if (supplier.hutang > 0)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    color: const Color(0xFFFEF2F2),
                    child: const Text('HUTANG',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: AppColors.danger)),
                  ),
                const SizedBox(width: 8),
                PopupMenuButton(
                  icon: const Icon(Icons.more_vert_rounded,
                      color: Colors.black26),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'edit', child: Text('Edit')),
                    const PopupMenuItem(
                        value: 'products', child: Text('Kelola Produk')),
                    const PopupMenuItem(
                        value: 'delete',
                        child: Text('Hapus',
                            style: TextStyle(color: AppColors.danger))),
                  ],
                  onSelected: (v) {
                    if (v == 'edit') onEdit();
                    if (v == 'products') onManageProducts();
                    if (v == 'delete') onDelete();
                  },
                ),
              ],
            ),
          ),
          if (supplier.address?.isNotEmpty == true)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Row(
                children: [
                  const Icon(Icons.location_on_outlined,
                      size: 14, color: Colors.black26),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(supplier.address!,
                        style: const TextStyle(
                            fontSize: 13, color: Color(0xFF64748B)),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
          _buildSupplierProducts(context),
          if (supplier.hutang > 0)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: const BoxDecoration(
                color: Color(0xFFF8FAFC),
                border: Border(top: BorderSide(color: Color(0xFFF1F5F9))),
              ),
              child: Row(
                children: [
                  const Text('Sisa Hutang:',
                      style: TextStyle(fontSize: 12, color: Color(0xFF64748B))),
                  const SizedBox(width: 8),
                  Text(_fRp(supplier.hutang),
                      style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: AppColors.danger)),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: onBayar,
                    icon: const Icon(Icons.payment_rounded, size: 14),
                    label: const Text('Bayar',
                        style: TextStyle(
                            fontSize: 13, fontWeight: FontWeight.bold)),
                    style: TextButton.styleFrom(
                      foregroundColor: _kBrand,
                      backgroundColor: kBrandLight,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSupplierProducts(BuildContext context) {
    final note = supplier.keterangan?.trim() ?? '';
    final totalProducts = products.length;
    final totalQty = products.fold<int>(
      0,
      (sum, row) => sum + ((row['total_qty'] as num?)?.toInt() ?? 0),
    );

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 12),
          childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          initiallyExpanded: false,
          iconColor: _kBrand,
          collapsedIconColor: Colors.black38,
          title: Row(
            children: [
              Container(
                width: 28,
                height: 28,
                alignment: Alignment.center,
                color: _kBrand.withValues(alpha: 0.08),
                child: const Icon(Icons.inventory_2_outlined,
                    size: 16, color: _kBrand),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Pemasok Produk',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF1E293B),
                  ),
                ),
              ),
              Text(
                '$totalProducts produk',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: _kBrand,
                ),
              ),
            ],
          ),
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: OutlinedButton.icon(
                onPressed: onManageProducts,
                icon: const Icon(Icons.checklist_rounded, size: 16),
                label: const Text(
                  'Kelola Produk Supplier',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                style: OutlinedButton.styleFrom(
                  foregroundColor: _kBrand,
                  side: const BorderSide(color: _kBrand),
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero,
                  ),
                  visualDensity: VisualDensity.compact,
                ),
              ),
            ),
            const SizedBox(height: 10),
            if (products.isNotEmpty) ...[
              Align(
                alignment: Alignment.centerLeft,
                child: Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: products.map((row) {
                    final name = (row['product_name'] ?? '').toString();
                    final qty = (row['total_qty'] as num?)?.toInt() ?? 0;
                    return Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Text(
                        qty > 0 ? '$name ($qty)' : name,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF334155),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              if (totalQty > 0) ...[
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Total stok produk pemasok: $totalQty',
                    style:
                        const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                  ),
                ),
              ],
            ] else ...[
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  note.isNotEmpty ? note : 'Belum ada produk pemasok',
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.35,
                    color: note.isNotEmpty
                        ? const Color(0xFF334155)
                        : Colors.black38,
                    fontWeight:
                        note.isNotEmpty ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ),
              if (note.isEmpty) ...[
                const SizedBox(height: 4),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Aktifkan Manajemen Stok di produk, lalu pilih supplier produk.',
                    style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                  ),
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }

  String _fRp(int n) {
    String s = n.abs().toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return 'Rp $r';
  }
}

class _SupplierProductPickerSheet extends StatefulWidget {
  final Supplier supplier;
  final List<Product> products;
  final Map<int, String> supplierNames;
  final Set<int> initialSelected;

  const _SupplierProductPickerSheet({
    required this.supplier,
    required this.products,
    required this.supplierNames,
    required this.initialSelected,
  });

  @override
  State<_SupplierProductPickerSheet> createState() =>
      _SupplierProductPickerSheetState();
}

class _SupplierProductPickerSheetState
    extends State<_SupplierProductPickerSheet> {
  final _searchCtrl = TextEditingController();
  late final Set<int> _selectedIds;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _selectedIds = {...widget.initialSelected};
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  List<Product> get _filtered {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return widget.products;
    return widget.products.where((p) {
      return p.name.toLowerCase().contains(q) ||
          (p.sku?.toLowerCase().contains(q) ?? false) ||
          (p.barcode?.toLowerCase().contains(q) ?? false);
    }).toList();
  }

  void _toggle(Product product, bool selected) {
    final id = product.id;
    if (id == null) return;
    setState(() {
      if (selected) {
        _selectedIds.add(id);
      } else {
        _selectedIds.remove(id);
      }
    });
  }

  String _formatRp(int value) {
    if (value == 0) return 'Rp 0';
    String s = value.abs().toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return 'Rp $r';
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;

    return DraggableScrollableSheet(
      initialChildSize: 0.86,
      minChildSize: 0.55,
      maxChildSize: 0.94,
      builder: (context, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero),
          ),
          child: Column(
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(top: 10, bottom: 14),
                color: const Color(0xFFE2E8F0),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 14),
                child: Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      alignment: Alignment.center,
                      color: _kBrand.withValues(alpha: 0.08),
                      child: const Icon(Icons.inventory_2_outlined,
                          color: _kBrand, size: 21),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Kelola Produk Supplier',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFF1E293B),
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            widget.supplier.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 13,
                              color: Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close_rounded),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFF1F5F9),
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: TextField(
                    controller: _searchCtrl,
                    onChanged: (value) => setState(() => _query = value),
                    decoration: const InputDecoration(
                      hintText: 'Cari produk atau SKU...',
                      hintStyle: TextStyle(fontSize: 13, color: Colors.black38),
                      prefixIcon: Icon(Icons.search_rounded,
                          size: 20, color: Colors.black38),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                child: Row(
                  children: [
                    Text(
                      '${_selectedIds.length} produk dipilih',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: _kBrand,
                      ),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: _selectedIds.isEmpty
                          ? null
                          : () => setState(_selectedIds.clear),
                      child: const Text('Kosongkan'),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: widget.products.isEmpty
                    ? const _SupplierProductEmptyState()
                    : ListView.separated(
                        controller: scrollController,
                        padding: const EdgeInsets.fromLTRB(12, 8, 12, 88),
                        itemCount: filtered.length,
                        separatorBuilder: (_, __) => const Divider(
                          height: 1,
                          color: Color(0xFFF1F5F9),
                        ),
                        itemBuilder: (context, index) {
                          final product = filtered[index];
                          final id = product.id;
                          final checked =
                              id != null && _selectedIds.contains(id);
                          final assignedSupplierId = product.supplierId;
                          final assignedElsewhere =
                              assignedSupplierId != null &&
                                  assignedSupplierId != widget.supplier.id;
                          final assignedName = assignedElsewhere
                              ? widget.supplierNames[assignedSupplierId] ??
                                  'Supplier lain'
                              : null;

                          return CheckboxListTile(
                            value: checked,
                            onChanged: (value) =>
                                _toggle(product, value ?? false),
                            activeColor: _kBrand,
                            controlAffinity: ListTileControlAffinity.leading,
                            contentPadding:
                                const EdgeInsets.symmetric(horizontal: 8),
                            title: Text(
                              product.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                            subtitle: Padding(
                              padding: const EdgeInsets.only(top: 3),
                              child: Wrap(
                                spacing: 8,
                                runSpacing: 3,
                                children: [
                                  Text(
                                    'Stok: ${product.stock} ${product.unit}',
                                    style: const TextStyle(
                                      fontSize: 12,
                                      color: Color(0xFF64748B),
                                    ),
                                  ),
                                  Text(
                                    'Harga Beli: ${_formatRp(product.buyPrice)}',
                                    style: const TextStyle(
                                      fontSize: 12,
                                      color: Color(0xFF64748B),
                                    ),
                                  ),
                                  if (assignedName != null)
                                    Text(
                                      'Saat ini: $assignedName',
                                      style: const TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w700,
                                        color: AppColors.warning,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
              SafeArea(
                top: false,
                child: Container(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    border: Border(top: BorderSide(color: Color(0xFFE2E8F0))),
                  ),
                  child: SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton.icon(
                      onPressed: () => Navigator.pop(context, _selectedIds),
                      icon: const Icon(Icons.save_rounded, size: 18),
                      label: const Text(
                        'Simpan Produk Supplier',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SupplierProductEmptyState extends StatelessWidget {
  const _SupplierProductEmptyState();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inventory_2_outlined,
                size: 48, color: Color(0xFFCBD5E1)),
            SizedBox(height: 12),
            Text(
              'Belum ada produk dengan Manajemen Stok aktif.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: Color(0xFF334155),
              ),
            ),
            SizedBox(height: 6),
            Text(
              'Aktifkan Manajemen Stok pada produk agar bisa dipilih sebagai produk supplier.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                height: 1.35,
                color: Color(0xFF64748B),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final bool isSearching;
  const _EmptyState({this.isSearching = false});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 320),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 112,
                height: 112,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: _kBrand.withValues(alpha: 0.05),
                    borderRadius: BorderRadius.zero),
                child: const Icon(Icons.business_rounded,
                    size: 54, color: Colors.black12),
              ),
              const SizedBox(height: 24),
              Text(
                isSearching
                    ? 'Supplier tidak ditemukan'
                    : 'Belum ada data supplier',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1E293B)),
              ),
              const SizedBox(height: 8),
              Text(
                isSearching
                    ? 'Coba gunakan kata kunci pencarian lain.'
                    : 'Tambahkan supplier pertama untuk mulai mencatat pembelian supplier.',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFF64748B),
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

