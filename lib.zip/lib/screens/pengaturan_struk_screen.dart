import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart'; // More stable for Windows
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:printing/printing.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../services/cash_drawer_service.dart';
import '../services/receipt_print_service.dart';
import '../database/db_helper.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';

const Color _kBrand = AppColors.primaryBrand;

/// Normalisasi nomor telepon dari DB agar selalu tampil dengan awalan 0.
String _normalizePhone(String raw) {
  final t = raw.trim();
  if (t.isEmpty) return '';
  if (t.startsWith('0') || t.startsWith('+')) return t;
  return '0$t';
}

double _previewStoreNameFontSize(
  double value, {
  bool compact = false,
}) {
  final base = value.clamp(14.0, 32.0).toDouble();
  final adjusted = compact ? base - 2.0 : base;
  return adjusted
      .clamp(compact ? 11.0 : 13.0, compact ? 22.0 : 28.0)
      .toDouble();
}

/// Dinamically determine maxLines: prefer 1 line, but allow 2 if name is too long
int _previewStoreNameMaxLines(String storeName) {
  return storeName.length <= 30 ? 1 : 2;
}

// MODEL PENGATURAN STRUK

class PengaturanStrukScreen extends ConsumerStatefulWidget {
  const PengaturanStrukScreen({super.key});

  @override
  ConsumerState<PengaturanStrukScreen> createState() =>
      _PengaturanStrukScreenState();
}

class _StrukSettings {
  bool logoEnabled = false;
  String logoPath = '';
  bool showAlamat = true;
  bool showTelepon = true;
  bool showTotalPesanan = true;
  String ukuranKertas = '58mm';
  String modulPrinter = 'v1';
  String printerMac = '';
  String printerName = 'Belum dipilih';
  int sharedColor = 0xFF2563EB;
  String logoPosition = 'top'; // 'top', 'bottom', 'left'
  double logoWidth = 40.0;
  double storeNameFontSize = 18.0;
  bool printLdr = false;
  bool showWatermark = true;
  bool transactionNoteEnabled = true;
  bool cashDrawerEnabled = false;
  int cashDrawerPin = 0;
}

class _PengaturanStrukScreenState extends ConsumerState<PengaturanStrukScreen> {
  final _settings = _StrukSettings();
  bool _loading = true;
  bool _savingLogo = false;
  bool _canRemotePrint = false;

  // Info warung (untuk preview)
  String _namaWarung = '';
  String _alamat = '';
  String _telepon = '';

  final _footerCtrl = TextEditingController();
  final _igCtrl = TextEditingController();
  final _fbCtrl = TextEditingController();
  final _tiktokCtrl = TextEditingController();
  final _prefixCtrl = TextEditingController();

  // Daftar printer Bluetooth
  List<BluetoothInfo> _printers = [];
  bool _scanningBT = false;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    final warung = await DBHelper.instance.getWarungProfile();
    final prefs = await SharedPreferences.getInstance();

    setState(() {
      _namaWarung = warung['nama'] ?? '';
      _alamat = warung['alamat'] ?? '';
      _telepon = _normalizePhone(warung['telepon'] ?? '');
      _footerCtrl.text = warung['catatan'] ?? '';
      _igCtrl.text = warung['instagram'] ?? '';
      _fbCtrl.text = warung['facebook'] ?? '';
      _tiktokCtrl.text = warung['tiktok'] ?? '';

      _settings.logoPath = warung['logo_path'] ?? '';
      _settings.logoEnabled = _settings.logoPath.isNotEmpty;

      // Load local settings
      _settings.showAlamat = prefs.getBool('struk_showAlamat') ?? true;
      _settings.showTelepon = prefs.getBool('struk_showTelepon') ?? true;
      _settings.showTotalPesanan =
          prefs.getBool('struk_showTotalPesanan') ?? true;
      _settings.ukuranKertas = prefs.getString('struk_ukuranKertas') ?? '58mm';
      _settings.modulPrinter = prefs.getString('struk_modulPrinter') ?? 'v1';
      _settings.printerMac = prefs.getString('struk_printerMac') ?? '';

      if (Platform.isWindows || Platform.isMacOS || Platform.isLinux) {
        _settings.printerName =
            prefs.getString('desktop_printerName') ?? 'Belum dipilih';
      } else {
        _settings.printerName =
            prefs.getString('struk_printerName') ?? 'Belum dipilih';
      }

      _settings.sharedColor = prefs.getInt('struk_sharedColor') ?? 0xFF2563EB;
      _settings.logoPosition = prefs.getString('struk_logoPosition') ?? 'top';
      _settings.logoWidth = prefs.getDouble('struk_logoWidth') ?? 40.0;
      _settings.storeNameFontSize =
          prefs.getDouble('struk_storeNameFontSize') ?? 18.0;
      _settings.printLdr = prefs.getBool('struk_printLdr') ?? false;
      _settings.showWatermark = prefs.getBool('struk_showWatermark') ?? true;
      _settings.transactionNoteEnabled =
          prefs.getBool('struk_enableTransactionNote') ?? true;
      _settings.cashDrawerEnabled =
          prefs.getBool(CashDrawerService.enabledPrefKey) ?? false;
      _settings.cashDrawerPin = prefs.getInt(CashDrawerService.pinPrefKey) ?? 0;

      _prefixCtrl.text = ref.read(transactionSettingsProvider).prefix;

      _loading = false;
    });

    final license = await DBHelper.instance.getLicense();
    if (license != null && mounted) {
      setState(() => _canRemotePrint = license.canRemotePrint == 1);
    }
  }

  void _showProfileWarning() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        backgroundColor: Colors.white,
        title: const Text('Profil Servis Belum Lengkap',
            style: TextStyle(fontWeight: FontWeight.bold)),
        content: const Text(
            'Silakan lengkapi nama dan alamat servis Anda di menu Pengaturan Toko sebelum melakukan tes print.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Nanti', style: TextStyle(color: Colors.black54)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pushNamed(context, '/pengaturan_servis');
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero)),
            child: const Text('Atur Sekarang',
                style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Future<void> _scanBluetooth() async {
    setState(() => _scanningBT = true);
    try {
      await [Permission.bluetoothScan, Permission.bluetoothConnect].request();
      final bool permitted = await PrintBluetoothThermal.bluetoothEnabled;
      if (!permitted) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Aktifkan Bluetooth terlebih dahulu.'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.black87,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
        return;
      }
      final List<BluetoothInfo> list =
          await PrintBluetoothThermal.pairedBluetooths;
      setState(() => _printers = list);
      if (list.isEmpty) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
                'Tidak ada printer Bluetooth terpasang. Pasangkan dulu di Pengaturan HP.'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.black87,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              'Gagal memindai printer Bluetooth. Pastikan Bluetooth aktif dan coba lagi.'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.black87,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
    } finally {
      if (mounted) setState(() => _scanningBT = false);
    }
  }

  void _showPrinterDialog() async {
    if (Platform.isWindows || Platform.isMacOS || Platform.isLinux) {
      final prefs = await SharedPreferences.getInstance();
      if (!mounted) return;
      final targetPrinter = await Printing.pickPrinter(context: context);
      if (targetPrinter != null) {
        await prefs.setString('desktop_printerName', targetPrinter.name);
        setState(() {
          _settings.printerName = targetPrinter.name;
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Printer Desktop tersimpan: ${targetPrinter.name}'),
            backgroundColor: const Color(0xFF2E7D32),
            behavior: SnackBarBehavior.floating,
          ));
        }
      }
      return;
    }

    if (_printers.isEmpty) {
      await _scanBluetooth();
    }
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.zero,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 8, 4),
                child: Row(
                  children: [
                    const Expanded(
                      child: Text('Pilih Printer Bluetooth',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold)),
                    ),
                    TextButton.icon(
                      onPressed: () async {
                        Navigator.pop(ctx);
                        await _scanBluetooth();
                        if (mounted) _showPrinterDialog();
                      },
                      icon: const Icon(Icons.refresh_rounded,
                          size: 16, color: _kBrand),
                      label: const Text('Refresh',
                          style: TextStyle(color: _kBrand, fontSize: 12)),
                    ),
                  ],
                ),
              ),
              if (_printers.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      Icon(Icons.bluetooth_disabled_rounded,
                          color: Colors.grey.shade400, size: 40),
                      const SizedBox(height: 12),
                      const Text(
                        'Tidak ada printer ditemukan.\nPasangkan printer Bluetooth di Pengaturan HP lalu tekan Refresh.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black45, fontSize: 13),
                      ),
                    ],
                  ),
                )
              else
                ..._printers.map(
                  (p) => ListTile(
                    leading: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: _kBrand.withValues(alpha: 0.1),
                        shape: BoxShape.rectangle,
                      ),
                      child: const Icon(Icons.print_rounded,
                          color: _kBrand, size: 18),
                    ),
                    title: Text(p.name,
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text(p.macAdress,
                        style: const TextStyle(
                            fontSize: 11, color: Colors.black38)),
                    trailing: _settings.printerMac == p.macAdress
                        ? const Icon(Icons.check_circle_rounded, color: _kBrand)
                        : null,
                    onTap: () {
                      setState(() {
                        _settings.printerMac = p.macAdress;
                        _settings.printerName = p.name;
                      });
                      Navigator.pop(ctx);
                    },
                  ),
                ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  ReceiptPrintDocument _buildTestReceiptPrintDocument() {
    return ReceiptPrintService.buildDocument(
      ukuranKertas: _settings.ukuranKertas,
      namaWarung: _namaWarung,
      alamat: _alamat,
      telepon: _telepon,
      footer: _footerCtrl.text.trim(),
      instagram: _igCtrl.text.trim(),
      facebook: _fbCtrl.text.trim(),
      tiktok: _tiktokCtrl.text.trim(),
      logoPosition: _settings.logoPosition,
      logoWidth: _settings.logoWidth,
      storeNameFontSize: _settings.storeNameFontSize,
      showAlamat: _settings.showAlamat,
      showTelepon: _settings.showTelepon,
      showTotalPesanan: _settings.showTotalPesanan,
      noTransaksi: 'TEST-1234567890',
      tanggal: '01-01-2026 12:00',
      kasirName: 'Demo Kasir',
      paymentMethod: 'Tunai',
      items: [
        ReceiptPrintItem(
          name: 'Ganti LCD HP',
          qty: 5,
          unitPrice: 7000,
          subtotal: 35000,
          note: _settings.transactionNoteEnabled
              ? 'Unit mati total, charger ikut dititipkan.'
              : '',
        ),
        const ReceiptPrintItem(
          name: 'Layanan Software (Jas)',
          qty: 1,
          unitPrice: 15000,
          subtotal: 15000,
        ),
      ],
      subtotal: 50000,
      discountAmount: 0,
      charges: const [],
      additionalCharges: 0,
      grandTotal: 50000,
      amountPaid: 100000,
      changeAmount: 50000,
      note: _settings.transactionNoteEnabled
          ? 'Contoh catatan tambahan pelanggan.'
          : null,
      title: 'STRUK servis (TEST)',
    );
  }

  Future<void> _testPrint() async {
    if (_namaWarung.trim().isEmpty ||
        _namaWarung.trim().toLowerCase() == 'nama toko' ||
        _alamat.trim().isEmpty) {
      _showProfileWarning();
      return;
    }

    if (Platform.isWindows || Platform.isMacOS || Platform.isLinux) {
      final prefs = await SharedPreferences.getInstance();
      String savedPrinterName = prefs.getString('desktop_printerName') ?? '';

      final printers = await Printing.listPrinters();
      Printer? targetPrinter;
      if (savedPrinterName.isNotEmpty) {
        try {
          targetPrinter =
              printers.firstWhere((p) => p.name == savedPrinterName);
        } catch (_) {}
      }

      if (targetPrinter == null) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content:
                Text('Pilih Printer Desktop terlebih dahulu di menu atas.'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.black87));
        return;
      }

      final document = _buildTestReceiptPrintDocument();
      final bytes = await ReceiptPrintService.buildEscPosBytes(
        document: document,
        logoPath: _settings.logoEnabled ? _settings.logoPath : '',
      );

      await ReceiptPrintService.printRawEscPosDesktop(
        bytes: bytes,
        printerName: savedPrinterName,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
                'Tes print dikirim ke ${targetPrinter.name} (Direct Text Mode).'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: const Color(0xFF2E7D32),
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      }
      return;
    }

    if (_settings.printerMac.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Pilih printer Bluetooth terlebih dahulu.'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.black87,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
      return;
    }

    // Hubungkan ke printer
    final connected = await PrintBluetoothThermal.connect(
        macPrinterAddress: _settings.printerMac);
    if (!connected) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Gagal terhubung ke printer. Coba lagi.'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.black87,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
      return;
    }

    final document = _buildTestReceiptPrintDocument();
    final bytes = await ReceiptPrintService.buildEscPosBytes(
      document: document,
      logoPath: _settings.logoEnabled ? _settings.logoPath : '',
    );

    await PrintBluetoothThermal.writeBytes(bytes);
    await PrintBluetoothThermal.disconnect;

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text('Tes print dikirim ke ${_settings.printerName}.'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.black87,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
    );
  }

  Future<void> _uploadLogo() async {
    // Rely on file_picker as it is more stable on Windows/Desktop
    final result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      allowMultiple: false,
    );

    if (result == null || result.files.single.path == null || !mounted) return;
    final pickedPath = result.files.single.path!;

    setState(() => _savingLogo = true);
    try {
      // Simpan ke direktori app
      final dir = await getApplicationDocumentsDirectory();
      final logoDir = Directory('${dir.path}/logos');
      if (!await logoDir.exists()) await logoDir.create(recursive: true);

      final ext = pickedPath.split('.').last;
      final dest = '${logoDir.path}/struk_logo.$ext';
      await File(pickedPath).copy(dest);

      // Update database warung_profile
      final warung = await DBHelper.instance.getWarungProfile();
      await DBHelper.instance.saveWarungProfile(
        nama: warung['nama'] ?? '',
        alamat: warung['alamat'] ?? '',
        telepon: warung['telepon'] ?? '',
        catatan: _footerCtrl.text.trim(),
        instagram: _igCtrl.text.trim(),
        facebook: _fbCtrl.text.trim(),
        tiktok: _tiktokCtrl.text.trim(),
        logoPath: dest,
      );

      setState(() {
        _settings.logoPath = dest;
        _settings.logoEnabled = true;
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Logo berhasil disimpan!'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.black87,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text(
                'Gagal menyimpan logo. Silakan pilih gambar dan coba lagi.'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
    } finally {
      if (mounted) setState(() => _savingLogo = false);
    }
  }

  Future<void> _hapusLogo() async {
    final warung = await DBHelper.instance.getWarungProfile();
    await DBHelper.instance.saveWarungProfile(
      nama: warung['nama'] ?? '',
      alamat: warung['alamat'] ?? '',
      telepon: warung['telepon'] ?? '',
      catatan: _footerCtrl.text.trim(),
      instagram: _igCtrl.text.trim(),
      facebook: _fbCtrl.text.trim(),
      tiktok: _tiktokCtrl.text.trim(),
      logoPath: '',
    );
    if (_settings.logoPath.isNotEmpty) {
      try {
        final f = File(_settings.logoPath);
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
    setState(() {
      _settings.logoPath = '';
      _settings.logoEnabled = false;
    });
  }

  Future<void> _simpan() async {
    // Simpan profil warung (catatan & sosmed)
    final warung = await DBHelper.instance.getWarungProfile();
    await DBHelper.instance.saveWarungProfile(
      nama: warung['nama'] ?? '',
      alamat: warung['alamat'] ?? '',
      telepon: warung['telepon'] ?? '',
      catatan: _footerCtrl.text.trim(),
      instagram: _igCtrl.text.trim(),
      facebook: _fbCtrl.text.trim(),
      tiktok: _tiktokCtrl.text.trim(),
      logoPath: _settings.logoEnabled && _settings.logoPath.isNotEmpty
          ? _settings.logoPath
          : '',
    );

    // Simpan preferensi lokal
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('struk_showAlamat', _settings.showAlamat);
    await prefs.setBool('struk_showTelepon', _settings.showTelepon);
    await prefs.setBool('struk_showTotalPesanan', _settings.showTotalPesanan);
    await prefs.setString('struk_ukuranKertas', _settings.ukuranKertas);
    await prefs.setString('struk_modulPrinter', _settings.modulPrinter);
    await prefs.setString('struk_printerMac', _settings.printerMac);
    await prefs.setString('struk_printerName', _settings.printerName);
    await prefs.setInt('struk_sharedColor', _settings.sharedColor);
    await prefs.setString('struk_logoPosition', _settings.logoPosition);
    await prefs.setDouble('struk_logoWidth', _settings.logoWidth);
    await prefs.setDouble(
        'struk_storeNameFontSize', _settings.storeNameFontSize);
    await prefs.setBool('struk_printLdr', _settings.printLdr);
    await prefs.setBool('struk_showWatermark', _settings.showWatermark);
    await prefs.setBool(
        'struk_enableTransactionNote', _settings.transactionNoteEnabled);
    await prefs.setBool(
        CashDrawerService.enabledPrefKey, _settings.cashDrawerEnabled);
    await prefs.setInt(CashDrawerService.pinPrefKey, _settings.cashDrawerPin);

    // Save Transaction Prefix
    await ref
        .read(transactionSettingsProvider.notifier)
        .updatePrefix(_prefixCtrl.text);

    // Jika logo toggle dimatikan, hapus logo dari DB dan file lokal
    if (!_settings.logoEnabled && _settings.logoPath.isNotEmpty) {
      await _hapusLogo();
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Pengaturan struk berhasil disimpan'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
    );
  }

  void _showUkuranKertasDialog() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 10),
          for (final size in ['58mm', '80mm'])
            ListTile(
              title: Text(size),
              trailing: _settings.ukuranKertas == size
                  ? const Icon(Icons.check_circle_rounded,
                      color: AppColors.primaryBrand)
                  : null,
              onTap: () {
                setState(() => _settings.ukuranKertas = size);
                Navigator.pop(ctx);
              },
            ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }

  String _cashDrawerPinLabel(int pin) {
    return pin == 1 ? 'Pin 5' : 'Pin 2';
  }

  void _showCashDrawerPinDialog() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 10),
            Container(
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.zero,
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Mode laci kasir',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
            ),
            for (final pin in const [0, 1])
              ListTile(
                title: Text(_cashDrawerPinLabel(pin)),
                subtitle: Text(pin == 0
                    ? 'Standar ESC/POS untuk mayoritas printer thermal.'
                    : 'Pilih jika Pin 2 tidak membuka laci.'),
                trailing: _settings.cashDrawerPin == pin
                    ? const Icon(Icons.check_circle_rounded,
                        color: AppColors.primaryBrand)
                    : null,
                onTap: () {
                  setState(() => _settings.cashDrawerPin = pin);
                  Navigator.pop(ctx);
                },
              ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  Future<void> _testCashDrawer() async {
    try {
      await CashDrawerService.openConfiguredDrawer();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Perintah buka laci dikirim.'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Color(0xFF2E7D32),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
              'Gagal membuka laci. Pastikan printer dan laci kasir terhubung.'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.red.shade800,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: Colors.white,
        body: Center(
            child: CircularProgressIndicator(color: AppColors.primaryBrand)),
      );
    }

    return KasirResponsiveScaffold(
      title: 'Struk & Buka Laci',
      showNavRail: false,
      backgroundColor: const Color(0xFFF7F7F8),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isDesktop = constraints.maxWidth > 900;

          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: isDesktop ? 6 : 1,
                child: Stack(
                  children: [
                    // Combined Settings List
                    _buildSettingsList(isDesktop: isDesktop),

                    // Save button remains pinned to the bottom of the settings pane
                    _buildStickySaveButton(),
                  ],
                ),
              ),
              if (isDesktop)
                Container(
                  width: 380,
                  decoration: const BoxDecoration(
                    border: Border(left: BorderSide(color: Color(0xFFEEEEEE))),
                    color: Colors.white,
                  ),
                  child: _buildPreviewPanel(),
                ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSettingsList({required bool isDesktop}) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isDesktop) ...[
            _sectionLabel('PREVIEW'),
            const SizedBox(height: 12),
            _StrukPreviewCard(
              namaWarung: _namaWarung,
              alamat: _settings.showAlamat ? _alamat : '',
              telepon: _settings.showTelepon ? _telepon : '',
              footer: _footerCtrl.text.trim(),
              instagram: _igCtrl.text.trim(),
              facebook: _fbCtrl.text.trim(),
              tiktok: _tiktokCtrl.text.trim(),
              logoPath: _settings.logoEnabled ? _settings.logoPath : '',
              logoPosition: _settings.logoPosition,
              logoWidth: _settings.logoWidth,
              storeNameFontSize: _settings.storeNameFontSize,
              showTotalPesanan: _settings.showTotalPesanan,
              showWatermark: _settings.showWatermark,
              transactionNoteEnabled: _settings.transactionNoteEnabled,
            ),
            const SizedBox(height: 24),
          ],
          _sectionLabel('PENGATURAN TRANSAKSI'),
          const SizedBox(height: 12),
          _card(
            child: Column(
              children: [
                _settingRow(
                  icon: Icons.tag_rounded,
                  label: 'Kode Transaksi (Prefix)',
                  trailing: SizedBox(
                    width: 100,
                    child: TextField(
                      controller: _prefixCtrl,
                      decoration: const InputDecoration(
                        hintText: 'TRX',
                        isDense: true,
                        contentPadding:
                            EdgeInsets.symmetric(vertical: 8, horizontal: 10),
                        border:
                            OutlineInputBorder(borderRadius: BorderRadius.zero),
                      ),
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, color: _kBrand),
                      textCapitalization: TextCapitalization.characters,
                    ),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 12),
                  child: Text(
                    'Contoh: TRX, INV, atau kode toko Anda. Default: TRX.',
                    style: TextStyle(fontSize: 11, color: Colors.black45),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _sectionLabel('KONEKSI PRINTER'),
          const SizedBox(height: 12),
          _card(
            child: Column(
              children: [
                _settingRow(
                  icon: Icons.receipt_long_rounded,
                  label: 'Ukuran Kertas',
                  trailing: GestureDetector(
                    onTap: _showUkuranKertasDialog,
                    child: _pill(_settings.ukuranKertas),
                  ),
                ),
                _divider(),
                _settingRow(
                  icon: Icons.bluetooth_rounded,
                  label: 'Printer',
                  trailing: GestureDetector(
                    onTap: _showPrinterDialog,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (_scanningBT)
                          const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: AppColors.primaryBrand),
                          )
                        else
                          _pill(
                            _settings.printerName.length > 16
                                ? '${_settings.printerName.substring(0, 14)}...'
                                : _settings.printerName,
                            icon: Icons.keyboard_arrow_down_rounded,
                          ),
                      ],
                    ),
                  ),
                ),
                _divider(),
                _settingRow(
                  icon: Icons.point_of_sale_rounded,
                  label: 'Buka laci otomatis',
                  trailing: Switch(
                    value: _settings.cashDrawerEnabled,
                    onChanged: (v) =>
                        setState(() => _settings.cashDrawerEnabled = v),
                    activeThumbColor: AppColors.primaryBrand,
                  ),
                ),
                if (_settings.cashDrawerEnabled) ...[
                  _divider(),
                  _settingRow(
                    icon: Icons.cable_rounded,
                    label: 'Mode laci',
                    trailing: GestureDetector(
                      onTap: _showCashDrawerPinDialog,
                      child: _pill(
                        _cashDrawerPinLabel(_settings.cashDrawerPin),
                        icon: Icons.keyboard_arrow_down_rounded,
                      ),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 0, 16, 12),
                    child: Text(
                      'Saat transaksi tunai selesai, aplikasi mengirim perintah ESC/POS untuk membuka cash drawer melalui printer.',
                      style: TextStyle(fontSize: 11, color: Colors.black45),
                    ),
                  ),
                ],
              ],
            ),
          ),
          if (_canRemotePrint) ...[
            const SizedBox(height: 16),
            _sectionLabel('FITUR KHUSUS'),
            const SizedBox(height: 12),
            _card(
              child: Column(
                children: [
                  _settingRow(
                    icon: Icons.cloud_upload_rounded,
                    label: 'Print LDR (Jarak Jauh)',
                    trailing: Switch(
                      value: _settings.printLdr,
                      onChanged: (v) => setState(() => _settings.printLdr = v),
                      activeThumbColor: AppColors.primaryBrand,
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 0, 16, 12),
                    child: Text(
                      'Jika aktif, cetak struk akan terkirim ke Admin Pusat secara real-time untuk dicetak dari jarak jauh.',
                      style: TextStyle(fontSize: 11, color: Colors.black45),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _testPrint,
              icon: const Icon(Icons.print_outlined, size: 18),
              label: const Text('Tes Print'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBrand,
                foregroundColor: Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _testCashDrawer,
              icon: const Icon(Icons.point_of_sale_rounded, size: 18),
              label: const Text('Tes Buka Laci'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primaryBrand,
                side: const BorderSide(color: AppColors.primaryBrand),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Pastikan printer sudah menyala dan tersambung sebelum melakukan tes print atau tes buka laci.',
            style: TextStyle(fontSize: 12, color: Colors.black38),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 32),
          _sectionLabel('LOGO servis'),
          const SizedBox(height: 12),
          _buildBrandingSection(),
          const SizedBox(height: 24),
          if (!isDesktop) ...[
            _sectionLabel('KONFIGURASI TAMPILAN'),
            const SizedBox(height: 12),
            _buildConfigTampilanSection(),
            const SizedBox(height: 24),
          ],
          _sectionLabel('INFORMASI TAMBAHAN'),
          const SizedBox(height: 12),
          _card(
            child: Column(
              children: [
                _settingRow(
                  icon: Icons.sticky_note_2_outlined,
                  label: 'Catatan Tambahan',
                  trailing: Switch(
                    value: _settings.transactionNoteEnabled,
                    onChanged: (v) =>
                        setState(() => _settings.transactionNoteEnabled = v),
                    activeThumbColor: AppColors.primaryBrand,
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(54, 0, 16, 12),
                  child: Text(
                    'Jika aktif, catatan transaksi dan catatan item akan tampil di preview, cetak struk, dan kirim WhatsApp.',
                    style: TextStyle(
                      fontSize: 11,
                      height: 1.35,
                      color: Colors.black45,
                    ),
                  ),
                ),
                _divider(),
                _textFieldRow('Catatan Footer Struk', _footerCtrl, maxLines: 2),
                _divider(),
                _textFieldRow('Instagram', _igCtrl, prefix: '@'),
                _divider(),
                _textFieldRow('Facebook', _fbCtrl, prefix: '@'),
                _divider(),
                _textFieldRow('TikTok', _tiktokCtrl, prefix: '@'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Old helper methods can be removed if they were only used for tabs

  Widget _buildPreviewPanel() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          width: double.infinity,
          color: const Color(0xFFF7F7F8),
          child: const Text('LIVE PREVIEW',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: Colors.black45)),
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                _StrukPreviewCard(
                  namaWarung: _namaWarung,
                  alamat: _settings.showAlamat ? _alamat : '',
                  telepon: _settings.showTelepon ? _telepon : '',
                  footer: _footerCtrl.text.trim(),
                  instagram: _igCtrl.text.trim(),
                  facebook: _fbCtrl.text.trim(),
                  tiktok: _tiktokCtrl.text.trim(),
                  logoPath: _settings.logoEnabled ? _settings.logoPath : '',
                  logoPosition: _settings.logoPosition,
                  logoWidth: _settings.logoWidth,
                  storeNameFontSize: _settings.storeNameFontSize,
                  showTotalPesanan: _settings.showTotalPesanan,
                  showWatermark: _settings.showWatermark,
                  transactionNoteEnabled: _settings.transactionNoteEnabled,
                ),
                const SizedBox(height: 24),
                _sectionLabel('KONFIGURASI TAMPILAN'),
                const SizedBox(height: 12),
                _buildConfigTampilanSection(),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStickySaveButton() {
    return Positioned(
      left: 0,
      right: 0,
      bottom: 0,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Color(0xFFEEEEEE))),
        ),
        child: SafeArea(
          top: false,
          child: ElevatedButton(
            onPressed: _simpan,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBrand,
              foregroundColor: Colors.white,
              minimumSize: const Size(double.infinity, 50),
              elevation: 0,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            child: const Text('Simpan Pengaturan',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
          ),
        ),
      ),
    );
  }

  Widget _buildBrandingSection() {
    final bool hasLogo = _settings.logoPath.isNotEmpty;

    return _card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            if (!hasLogo) ...[
              // EMPTY STATE: Upload Area
              GestureDetector(
                onTap: _uploadLogo,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 24),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7F7F8),
                    border: Border.all(
                        color: const Color(0xFFEEEEEE),
                        style: BorderStyle.solid),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Column(
                    children: [
                      _savingLogo
                          ? const CircularProgressIndicator(
                              color: AppColors.primaryBrand, strokeWidth: 2)
                          : const Icon(Icons.cloud_upload_outlined,
                              size: 40, color: Colors.black26),
                      const SizedBox(height: 12),
                      const Text('Belum ada logo terpasang',
                          style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: Colors.black54)),
                      const SizedBox(height: 4),
                      const Text('Pilih logo untuk mempercantik struk Anda',
                          style:
                              TextStyle(fontSize: 11, color: Colors.black38)),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _uploadLogo,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryBrand,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                        ),
                        child: const Text('PASANG LOGO'),
                      ),
                    ],
                  ),
                ),
              ),
            ] else ...[
              // FILLED STATE: Logo Information
              Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.zero,
                    child: Image.file(
                      File(_settings.logoPath),
                      width: 80,
                      height: 80,
                      fit: BoxFit.cover,
                      cacheWidth: 160,
                      errorBuilder: (ctx, _, __) => Container(
                        width: 80,
                        height: 80,
                        color: Colors.grey.shade100,
                        child: const Icon(Icons.broken_image_outlined,
                            color: Colors.black26, size: 24),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Logo Servis Aktif',
                            style: TextStyle(
                                fontSize: 14, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        const Text(
                            'Logo akan tampil sesuai posisi yang Anda pilih.',
                            style:
                                TextStyle(fontSize: 11, color: Colors.black45)),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            OutlinedButton(
                              onPressed: _uploadLogo,
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(
                                    color: AppColors.primaryBrand),
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.zero),
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 12),
                              ),
                              child: const Text('GANTI',
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: AppColors.primaryBrand)),
                            ),
                            const SizedBox(width: 8),
                            OutlinedButton(
                              onPressed: _hapusLogo,
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: AppColors.danger),
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.zero),
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 12),
                              ),
                              child: const Text('HAPUS',
                                  style: TextStyle(
                                      fontSize: 11, color: AppColors.danger)),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Divider(height: 1, color: Color(0xFFF0F0F0)),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.visibility_outlined,
                          size: 18, color: Colors.black54),
                      SizedBox(width: 8),
                      Text('Tampilkan Logo di Struk',
                          style: TextStyle(
                              fontSize: 13, fontWeight: FontWeight.w600)),
                    ],
                  ),
                  Switch(
                    value: _settings.logoEnabled,
                    onChanged: (v) => setState(() => _settings.logoEnabled = v),
                    activeThumbColor: AppColors.primaryBrand,
                  ),
                ],
              ),
            ],
            const SizedBox(height: 12),
            _sectionLabel('POSISI LOGO'),
            const SizedBox(height: 8),
            Row(
              children: [
                _positionOption('Atas', 'top', Icons.vertical_align_top),
                const SizedBox(width: 8),
                _positionOption(
                    'Samping Nama', 'left', Icons.format_align_left),
                const SizedBox(width: 8),
                _positionOption('Bawah', 'bottom', Icons.vertical_align_bottom),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Icon(Icons.photo_size_select_large_rounded,
                    size: 18, color: Colors.black54),
                const SizedBox(width: 8),
                Text('Ukuran Logo: ${_settings.logoWidth.toInt()}mm',
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w600)),
              ],
            ),
            Slider(
              value: _settings.logoWidth,
              min: 20,
              max: 60,
              divisions: 8,
              activeColor: AppColors.primaryBrand,
              inactiveColor: AppColors.primaryBrand.withValues(alpha: 0.1),
              onChanged: (v) => setState(() => _settings.logoWidth = v),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.text_fields_rounded,
                    size: 18, color: Colors.black54),
                const SizedBox(width: 8),
                Text(
                    'Ukuran Nama Servis: ${_settings.storeNameFontSize.toStringAsFixed(0)}',
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w600)),
              ],
            ),
            Slider(
              value: _settings.storeNameFontSize,
              min: 14,
              max: 32,
              divisions: 18,
              activeColor: AppColors.primaryBrand,
              inactiveColor: AppColors.primaryBrand.withValues(alpha: 0.1),
              onChanged: (v) => setState(() => _settings.storeNameFontSize = v),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 2),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Nama servis panjang akan otomatis turun ke maksimal 2 baris di preview dan hasil cetak.',
                  style: TextStyle(fontSize: 11, color: Colors.black45),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.withValues(alpha: 0.05),
                borderRadius: BorderRadius.zero,
                border: Border.all(color: Colors.blue.withValues(alpha: 0.1)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline, size: 16, color: Colors.blue),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Gunakan format PNG transparan dengan logo berwarna HITAM murni untuk hasil cetak paling tajam. Sistem akan otomatis meningkatkan kontras logo berwarna.',
                      style: TextStyle(
                          fontSize: 11, color: Colors.blue, height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildConfigTampilanSection() {
    return _card(
      child: Column(
        children: [
          _settingRow(
            icon: Icons.location_on_rounded,
            label: 'Tampilkan Alamat',
            trailing: Switch(
              value: _settings.showAlamat,
              onChanged: (v) => setState(() => _settings.showAlamat = v),
              activeThumbColor: AppColors.primaryBrand,
            ),
          ),
          _divider(),
          _settingRow(
            icon: Icons.phone_rounded,
            label: 'Tampilkan Telepon',
            trailing: Switch(
              value: _settings.showTelepon,
              onChanged: (v) => setState(() => _settings.showTelepon = v),
              activeThumbColor: AppColors.primaryBrand,
            ),
          ),
          _divider(),
          _settingRow(
            icon: Icons.receipt_rounded,
            label: 'Tampilkan Total Pesanan',
            trailing: Switch(
              value: _settings.showTotalPesanan,
              onChanged: (v) => setState(() => _settings.showTotalPesanan = v),
              activeThumbColor: AppColors.primaryBrand,
            ),
          ),
          _divider(),
          _settingRow(
            icon: Icons.branding_watermark_outlined,
            label: 'Watermark Brand',
            trailing: Switch(
              value: _settings.showWatermark,
              onChanged: (v) => setState(() => _settings.showWatermark = v),
              activeThumbColor: AppColors.primaryBrand,
            ),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Text(
              'Tampilkan watermark "Powered Juragan Kasir Servis" di bagian bawah struk.',
              style: TextStyle(fontSize: 11, color: Colors.black45),
            ),
          ),
          _divider(),
          _buildColorThemeSection(),
        ],
      ),
    );
  }

  Widget _buildColorThemeSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                    color: AppColors.primaryBrand.withValues(alpha: 0.08)),
                child: const Icon(Icons.palette_rounded,
                    color: AppColors.primaryBrand, size: 16),
              ),
              const SizedBox(width: 10),
              const Text('Warna Tema Berbagi',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            ],
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: _showColorPicker,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Color(_settings.sharedColor).withValues(alpha: 0.1),
                border: Border.all(
                    color: Color(_settings.sharedColor).withValues(alpha: 0.4)),
                borderRadius: BorderRadius.zero,
              ),
              child: Row(
                children: [
                  Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: Color(_settings.sharedColor),
                      shape: BoxShape.rectangle,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text('Ketuk untuk ubah warna tema',
                        style: TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w600)),
                  ),
                  const Icon(Icons.colorize_rounded,
                      size: 18, color: Colors.black45),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _positionOption(String label, String value, IconData icon) {
    final bool isSelected = _settings.logoPosition == value;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _settings.logoPosition = value),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: isSelected ? _kBrand.withValues(alpha: 0.1) : Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(
              color: isSelected ? _kBrand : const Color(0xFFEEEEEE),
              width: isSelected ? 1.5 : 1,
            ),
          ),
          child: Column(
            children: [
              Icon(icon,
                  size: 18, color: isSelected ? _kBrand : Colors.black45),
              const SizedBox(height: 4),
              Text(label,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight:
                        isSelected ? FontWeight.bold : FontWeight.normal,
                    color: isSelected ? _kBrand : Colors.black87,
                  )),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionLabel(String label) => Text(
        label,
        style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: Colors.black45,
            letterSpacing: 0.5),
      );

  Widget _card({required Widget child}) => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 6,
              offset: const Offset(0, 2),
            )
          ],
        ),
        child: child,
      );

  Widget _divider() => const Divider(
      height: 1, indent: 14, endIndent: 14, color: Color(0xFFF0F0F0));

  Widget _settingRow({
    required IconData icon,
    required String label,
    required Widget trailing,
  }) =>
      Padding(
        padding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
        child: Row(
          children: [
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: _kBrand.withValues(alpha: 0.08),
                borderRadius: BorderRadius.zero,
              ),
              child: Icon(icon, color: _kBrand, size: 16),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(label,
                  style: const TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w600)),
            ),
            trailing,
          ],
        ),
      );

  Widget _pill(String label, {IconData? icon}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: const BoxDecoration(
          color: Color(0xFFF0F0F0),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(label,
                style:
                    const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
            if (icon != null) ...[
              const SizedBox(width: 2),
              Icon(icon, size: 14, color: Colors.black54),
            ],
          ],
        ),
      );

  Widget _textFieldRow(String label, TextEditingController ctrl,
          {int maxLines = 1, String? prefix}) =>
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.black54)),
            const SizedBox(height: 6),
            TextField(
              controller: ctrl,
              maxLines: maxLines,
              style: const TextStyle(fontSize: 13),
              decoration: InputDecoration(
                prefixText: prefix != null ? '$prefix ' : null,
                isDense: true,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.zero,
                ),
                focusedBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: _kBrand),
                  borderRadius: BorderRadius.zero,
                ),
              ),
              onChanged: (_) => setState(() {}),
            ),
          ],
        ),
      );

  void _showColorPicker() {
    final List<Color> presets = [
      const Color(0xFF2563EB), // Blue
      const Color(0xFF2E5B9A), // Biru
      const Color(0xFF6A1B9A), // Ungu
      const Color(0xFFE65100), // Oranye
      const Color(0xFF424242), // Hitam
      const Color(0xFFC62828), // Merah
      const Color(0xFF2E7D32), // Hijau
      const Color(0xFFF9A825), // Kuning
      const Color(0xFF37474F), // Blue Grey
      const Color(0xFFD81B60), // Pink
    ];

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Pilih Warna Tema',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        content: SizedBox(
          width: 300,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Preset Warna:',
                  style: TextStyle(fontSize: 12, color: Colors.black54)),
              const SizedBox(height: 12),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: presets
                    .map((c) => GestureDetector(
                          onTap: () {
                            setState(
                                () => _settings.sharedColor = c.toARGB32());
                            Navigator.pop(ctx);
                          },
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: c,
                              border: Border.all(
                                color: _settings.sharedColor == c.toARGB32()
                                    ? Colors.black
                                    : Colors.transparent,
                                width: 2,
                              ),
                            ),
                          ),
                        ))
                    .toList(),
              ),
              const SizedBox(height: 20),
              const Text('Warna Lainnya:',
                  style: TextStyle(fontSize: 12, color: Colors.black54)),
              const SizedBox(height: 12),
              SizedBox(
                height: 120,
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 6,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: Colors.primaries.length,
                  itemBuilder: (ctx, i) {
                    final c = Colors.primaries[i];
                    return GestureDetector(
                      onTap: () {
                        setState(() => _settings.sharedColor = c.toARGB32());
                        Navigator.pop(ctx);
                      },
                      child: Container(
                        decoration: BoxDecoration(color: c),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('BATAL', style: TextStyle(color: Colors.black54)),
          ),
        ],
      ),
    );
  }
}

// PREVIEW CARD (ringkas, tampil di settings)

class _StrukPreviewCard extends StatelessWidget {
  final String namaWarung;
  final String alamat;
  final String telepon;
  final String footer;
  final String instagram;
  final String facebook;
  final String tiktok;
  final String logoPath;
  final String logoPosition;
  final double logoWidth;
  final double storeNameFontSize;
  final bool showTotalPesanan;
  final bool showWatermark;
  final bool transactionNoteEnabled;

  const _StrukPreviewCard({
    required this.namaWarung,
    required this.alamat,
    required this.telepon,
    required this.footer,
    required this.instagram,
    required this.facebook,
    required this.tiktok,
    required this.logoPath,
    required this.logoPosition,
    required this.logoWidth,
    required this.storeNameFontSize,
    required this.showTotalPesanan,
    required this.showWatermark,
    required this.transactionNoteEnabled,
  });

  String _now() {
    final d = DateTime.now();
    return '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year} '
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final hasLogo = logoPath.isNotEmpty;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFEEEEEE)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 6,
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Logo TOP
          if (hasLogo && logoPosition == 'top') ...[
            ClipRRect(
              borderRadius: BorderRadius.zero,
              child: Image.file(
                File(logoPath),
                height: logoWidth,
                fit: BoxFit.contain,
                cacheHeight: 150,
                errorBuilder: (context, error, stackTrace) =>
                    const SizedBox.shrink(),
              ),
            ),
            const SizedBox(height: 6),
          ],

          // Header (Name + Logo LEFT)
          if (logoPosition == 'left' && hasLogo)
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.file(File(logoPath),
                    height: logoWidth * 0.7, width: logoWidth * 0.7),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    namaWarung,
                    maxLines: _previewStoreNameMaxLines(namaWarung),
                    overflow: TextOverflow.ellipsis,
                    softWrap: true,
                    style: TextStyle(
                      fontSize: _previewStoreNameFontSize(
                        storeNameFontSize,
                        compact: true,
                      ),
                      fontWeight: FontWeight.bold,
                      height: 1.1,
                    ),
                  ),
                ),
              ],
            )
          else if (namaWarung.isNotEmpty)
            Text(namaWarung,
                maxLines: _previewStoreNameMaxLines(namaWarung),
                overflow: TextOverflow.ellipsis,
                softWrap: true,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: _previewStoreNameFontSize(storeNameFontSize),
                    fontWeight: FontWeight.bold,
                    height: 1.1)),

          if (alamat.isNotEmpty)
            Text(alamat,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 10, color: Colors.black45)),
          if (telepon.isNotEmpty)
            Text(telepon,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 10, color: Colors.black45)),
          if (namaWarung.isNotEmpty) ...[
            const SizedBox(height: 6),
            const Divider(height: 1, color: Color(0xFFDDDDDD)),
            const SizedBox(height: 6),
          ],
          // Info transaksi (contoh)
          _rr('No', 'XXXXXXXX'),
          _rr('Tanggal', _now()),
          _rr('Kasir', 'Kasir'),
          _rr('Pembayaran', 'Tunai'),
          const Divider(height: 12, color: Color(0xFFDDDDDD)),
          _item(
            'Produk Contoh 1',
            'Rp10.000 x 1',
            'Rp10.000',
            note: transactionNoteEnabled
                ? 'Catatan unit: terdapat goresan pada sisi kanan.'
                : '',
          ),
          _item('Produk Contoh 2', 'Rp15.000 x 2', 'Rp30.000'),
          const Divider(height: 12, color: Color(0xFFDDDDDD)),
          if (showTotalPesanan) _rr('Total Pesanan', 'Rp40.000'),
          _rrBold('TOTAL', 'Rp40.000'),
          _rr('Bayar', 'Rp50.000'),
          _rr('Kembali', 'Rp10.000'),
          if (transactionNoteEnabled) ...[
            const SizedBox(height: 6),
            const Divider(height: 1, color: Color(0xFFDDDDDD)),
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                border: Border.all(color: const Color(0xFFE2E8F0)),
                borderRadius: BorderRadius.zero,
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Catatan Tambahan',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF64748B),
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    'Unit mati total, charger ikut dititipkan.',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 10,
                      height: 1.25,
                      color: Color(0xFF334155),
                    ),
                  ),
                ],
              ),
            ),
          ],
          if (footer.isNotEmpty) ...[
            const SizedBox(height: 6),
            const Divider(height: 1, color: Color(0xFFDDDDDD)),
            const SizedBox(height: 6),
            Text(footer,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 10, color: Colors.black45)),
          ],
          if (instagram.isNotEmpty ||
              facebook.isNotEmpty ||
              tiktok.isNotEmpty) ...[
            const SizedBox(height: 6),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 8,
              runSpacing: 4,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                if (instagram.isNotEmpty)
                  _sosmedRow(Icons.camera_alt_outlined, instagram),
                if (facebook.isNotEmpty)
                  _sosmedRow(Icons.facebook_outlined, facebook),
                if (tiktok.isNotEmpty)
                  _sosmedRow(Icons.music_note_outlined, tiktok),
              ],
            ),
          ],

          // Logo BOTTOM
          if (hasLogo && logoPosition == 'bottom') ...[
            const SizedBox(height: 12),
            Image.file(File(logoPath), height: logoWidth, fit: BoxFit.contain),
          ],

          const SizedBox(height: 10),
          if (showWatermark)
            const Text('Powered Juragan Kasir Servis',
                style: TextStyle(fontSize: 8, color: Colors.black26)),
        ],
      ),
    );
  }

  Widget _sosmedRow(IconData icon, String text) => Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(icon, size: 10, color: Colors.black45),
          const SizedBox(width: 3),
          Text(text,
              style: const TextStyle(fontSize: 10, color: Colors.black45)),
        ],
      );

  Widget _rr(String l, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Expanded(child: Text(l, style: const TextStyle(fontSize: 10))),
            Text(v,
                style:
                    const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
          ],
        ),
      );

  Widget _rrBold(String l, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Expanded(
                child: Text(l,
                    style: const TextStyle(
                        fontSize: 11, fontWeight: FontWeight.bold))),
            Text(v,
                style:
                    const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
          ],
        ),
      );

  Widget _item(String name, String detail, String price, {String note = ''}) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(fontSize: 10)),
                  Text(detail,
                      style:
                          const TextStyle(fontSize: 9, color: Colors.black45)),
                  if (note.trim().isNotEmpty)
                    Text(
                      note.trim(),
                      style: const TextStyle(
                          fontSize: 9, color: Color(0xFF64748B)),
                    ),
                ],
              ),
            ),
            Text(price,
                style:
                    const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
          ],
        ),
      );
}

// FULL SCREEN PREVIEW (bisa zoom, lihat detail)

class _StrukPreviewFullScreen extends StatefulWidget {
  final String namaWarung;
  final String alamat;
  final String telepon;
  final String footer;
  final String instagram;
  final String facebook;
  final String tiktok;
  final String logoPath;
  final String logoPosition;
  final double storeNameFontSize;
  final bool showTotalPesanan;
  final bool showWatermark;
  final bool transactionNoteEnabled;

  const _StrukPreviewFullScreen({
    required this.namaWarung,
    required this.alamat,
    required this.telepon,
    required this.footer,
    required this.instagram,
    required this.facebook,
    required this.tiktok,
    required this.logoPath,
    required this.logoPosition,
    required this.storeNameFontSize,
    required this.showTotalPesanan,
    required this.showWatermark,
    required this.transactionNoteEnabled,
  });

  @override
  State<_StrukPreviewFullScreen> createState() =>
      _StrukPreviewFullScreenState();
}

class _StrukPreviewFullScreenState extends State<_StrukPreviewFullScreen> {
  Uint8List? _pdfBytes;
  bool _loadingPdf = true;

  @override
  void initState() {
    super.initState();
    _buildPreviewPdf();
  }

  Future<void> _buildPreviewPdf() async {
    final doc = pw.Document();
    const pageWidth = 200.0;

    pw.MemoryImage? logo;
    if (widget.logoPath.isNotEmpty && File(widget.logoPath).existsSync()) {
      final bytes = await File(widget.logoPath).readAsBytes();
      logo = pw.MemoryImage(bytes);
    }

    doc.addPage(
      pw.Page(
        pageFormat:
            const PdfPageFormat(pageWidth, double.infinity, marginAll: 10),
        build: (pw.Context ctx) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            // 1. Logo TOP
            if (logo != null && widget.logoPosition == 'top') ...[
              pw.Center(child: pw.Image(logo, height: 50)),
              pw.SizedBox(height: 6),
            ],

            // 2. Header (Name + Logo LEFT)
            if (widget.namaWarung.isNotEmpty) ...[
              if (widget.logoPosition == 'left' && logo != null)
                pw.Row(
                  crossAxisAlignment: pw.CrossAxisAlignment.center,
                  mainAxisAlignment: pw.MainAxisAlignment.center,
                  children: [
                    pw.Container(
                      width: 25,
                      margin: const pw.EdgeInsets.only(right: 6),
                      child: pw.Image(logo),
                    ),
                    pw.Expanded(
                      child: pw.Text(
                        widget.namaWarung,
                        maxLines: 2,
                        style: pw.TextStyle(
                            fontSize: _previewStoreNameFontSize(
                              widget.storeNameFontSize,
                              compact: true,
                            ),
                            fontWeight: pw.FontWeight.bold,
                            lineSpacing: 1.0),
                      ),
                    ),
                  ],
                )
              else
                pw.Text(widget.namaWarung,
                    maxLines: 2,
                    textAlign: pw.TextAlign.center,
                    style: pw.TextStyle(
                        fontSize:
                            _previewStoreNameFontSize(widget.storeNameFontSize),
                        fontWeight: pw.FontWeight.bold,
                        lineSpacing: 1.0)),
              if (widget.alamat.isNotEmpty)
                pw.Text(widget.alamat,
                    textAlign: pw.TextAlign.center,
                    style: const pw.TextStyle(
                        fontSize: 9, color: PdfColors.grey600)),
              if (widget.telepon.isNotEmpty)
                pw.Text(widget.telepon,
                    textAlign: pw.TextAlign.center,
                    style: const pw.TextStyle(
                        fontSize: 9, color: PdfColors.grey600)),
              pw.SizedBox(height: 6),
              pw.Divider(thickness: 0.5),
              pw.SizedBox(height: 4),
            ],

            // Info
            _pdfRow('No', 'TRX1234567890'),
            _pdfRow('Tanggal', '30-03-2026 15:00'),
            _pdfRow('Kasir', 'Kasir'),
            _pdfRow('Pembayaran', 'Tunai'),

            pw.SizedBox(height: 4),
            pw.Divider(thickness: 0.5),
            pw.SizedBox(height: 4),

            // Items
            _pdfItem(
              'Produk Contoh 1',
              widget.transactionNoteEnabled
                  ? 'Rp10.000 x 1\nCatatan unit: terdapat goresan pada sisi kanan.'
                  : 'Rp10.000 x 1',
              'Rp10.000',
            ),
            _pdfItem('Produk Contoh 2', 'Rp15.000 x 2', 'Rp30.000'),
            _pdfItem('Mie Goreng Spesial', 'Rp8.500 x 3', 'Rp25.500'),

            pw.SizedBox(height: 4),
            pw.Divider(thickness: 0.5),
            pw.SizedBox(height: 4),

            if (widget.showTotalPesanan) _pdfRow('Total Pesanan', 'Rp65.500'),
            _pdfRow('Diskon', '- Rp5.500'),
            pw.SizedBox(height: 2),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('TOTAL',
                    style: pw.TextStyle(
                        fontSize: 10, fontWeight: pw.FontWeight.bold)),
                pw.Text('Rp60.000',
                    style: pw.TextStyle(
                        fontSize: 10, fontWeight: pw.FontWeight.bold)),
              ],
            ),
            pw.SizedBox(height: 2),
            _pdfRow('Bayar', 'Rp70.000'),
            _pdfRow('Kembali', 'Rp10.000'),

            if (widget.transactionNoteEnabled) ...[
              pw.SizedBox(height: 8),
              pw.Divider(thickness: 0.5),
              pw.SizedBox(height: 4),
              pw.Container(
                width: double.infinity,
                padding: const pw.EdgeInsets.all(5),
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.grey300, width: 0.5),
                  color: PdfColors.grey100,
                ),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(
                      'Catatan Tambahan',
                      textAlign: pw.TextAlign.left,
                      style: pw.TextStyle(
                        fontSize: 8,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    pw.SizedBox(height: 2),
                    pw.Text(
                      'Unit mati total, charger ikut dititipkan.',
                      textAlign: pw.TextAlign.left,
                      style: const pw.TextStyle(fontSize: 8),
                    ),
                  ],
                ),
              ),
            ],

            if (widget.footer.isNotEmpty ||
                widget.instagram.isNotEmpty ||
                widget.facebook.isNotEmpty ||
                widget.tiktok.isNotEmpty) ...[
              pw.SizedBox(height: 8),
              pw.Divider(thickness: 0.5),
              pw.SizedBox(height: 4),
            ],
            if (widget.footer.isNotEmpty)
              pw.Text(
                widget.footer,
                textAlign: pw.TextAlign.center,
                style:
                    const pw.TextStyle(fontSize: 9, color: PdfColors.grey600),
              ),
            if (widget.instagram.isNotEmpty ||
                widget.facebook.isNotEmpty ||
                widget.tiktok.isNotEmpty) ...[
              pw.SizedBox(height: 6),
              pw.Wrap(
                alignment: pw.WrapAlignment.center,
                spacing: 6,
                runSpacing: 2,
                children: [
                  if (widget.instagram.isNotEmpty)
                    _pdfSosmedRow('IG', widget.instagram),
                  if (widget.facebook.isNotEmpty)
                    _pdfSosmedRow('FB', widget.facebook),
                  if (widget.tiktok.isNotEmpty)
                    _pdfSosmedRow('TikTok', widget.tiktok),
                ],
              ),
            ],

            pw.SizedBox(height: 8),
            if (widget.showWatermark)
              pw.Text('Powered Juragan Kasir Servis',
                  textAlign: pw.TextAlign.center,
                  style: const pw.TextStyle(
                      fontSize: 7, color: PdfColors.grey400)),

            // 3. Logo BOTTOM
            if (logo != null && widget.logoPosition == 'bottom') ...[
              pw.SizedBox(height: 10),
              pw.Center(child: pw.Image(logo, height: 40)),
            ],
          ],
        ),
      ),
    );

    final bytes = await doc.save();
    if (mounted) {
      setState(() {
        _pdfBytes = Uint8List.fromList(bytes);
        _loadingPdf = false;
      });
    }
  }

  pw.Widget _pdfSosmedRow(String label, String value) => pw.Row(
        mainAxisSize: pw.MainAxisSize.min,
        children: [
          pw.Text('@$value ',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
          pw.Text('($label)',
              style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey400)),
        ],
      );

  pw.Widget _pdfRow(String l, String v) => pw.Padding(
        padding: const pw.EdgeInsets.only(bottom: 2),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(l,
                style:
                    const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
            pw.Text(v,
                style:
                    pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
          ],
        ),
      );

  pw.Widget _pdfItem(String name, String detail, String price) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Expanded(
                  child: pw.Text(name, style: const pw.TextStyle(fontSize: 8))),
              pw.Text(price,
                  style: pw.TextStyle(
                      fontSize: 8, fontWeight: pw.FontWeight.bold)),
            ],
          ),
          pw.Text(detail,
              style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey600)),
          pw.SizedBox(height: 3),
        ],
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade900,
      appBar: AppBar(
        backgroundColor: Colors.grey.shade900,
        leading: IconButton(
          icon: const Icon(Icons.close_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Preview Struk',
            style: TextStyle(color: Colors.white, fontSize: 16)),
        actions: [
          if (_pdfBytes != null)
            IconButton(
              icon: const Icon(Icons.share_rounded, color: Colors.white),
              onPressed: () => Printing.sharePdf(
                bytes: _pdfBytes!,
                filename: 'preview_struk.pdf',
              ),
            ),
        ],
      ),
      body: _loadingPdf
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : PdfPreview(
              build: (_) async => _pdfBytes!,
              allowPrinting: true,
              allowSharing: true,
              canChangePageFormat: false,
              canChangeOrientation: false,
              canDebug: false,
              pdfFileName: 'preview_struk.pdf',
              actions: const [],
            ),
    );
  }
}

