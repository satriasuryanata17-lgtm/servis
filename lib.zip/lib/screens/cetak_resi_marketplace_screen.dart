import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:file_picker/file_picker.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import '../services/resi_print_service.dart';
import '../core/theme.dart';
import '../widgets/modern_picker.dart';
import '../widgets/kasir_dialog.dart';
import 'responsive_layout.dart';
import 'package:printing/printing.dart';
import 'package:desktop_drop/desktop_drop.dart';
import '../services/resi_log_service.dart';
import '../services/resi_ocr_service.dart';

class CetakResiMarketplaceScreen extends ConsumerStatefulWidget {
  const CetakResiMarketplaceScreen({super.key});

  @override
  ConsumerState<CetakResiMarketplaceScreen> createState() =>
      _CetakResiMarketplaceScreenState();
}

class _CetakResiMarketplaceScreenState
    extends ConsumerState<CetakResiMarketplaceScreen> {
  final _resiService = ResiPrintService();

  // Existing state variables
  Uint8List? _previewBytes;
  int _paperSize = 58;
  bool _isAutoPrint = false;
  String? _watchPath;
  bool _isLoading = false;
  bool _isDragging = false;
  bool _isOptimizePaper = false;
  bool _isAutoDelete = false;

  // New Super Resi variables
  List<File> _selectedFiles = [];
  ResiBatchStatus? _batchStatus;
  String _detectedCourier = '';
  String _detectedTracking = '';
  String _brandingText = '';
  StreamSubscription? _batchSub;

  String? _selectedWinPrinter;
  List<Printer> _allWinPrinters = [];

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _initSharingIntent();
    if (Platform.isWindows) {
      _loadWinPrinters();
    }
    _listenToBatch();
  }

  @override
  void dispose() {
    _batchSub?.cancel();
    super.dispose();
  }

  void _listenToBatch() {
    _batchSub = _resiService.batchStatusStream.listen((status) {
      if (mounted) {
        setState(() {
          _batchStatus = status.isDone ? null : status;
          if (status.isDone) {
            _selectedFiles = [];
            _previewBytes = null;
            _detectedCourier = '';
            _detectedTracking = '';
          }
        });
      }
    });
  }

  Future<void> _loadSettings() async {
    final size = await _resiService.getPaperSize();
    final isAuto = await _resiService.getAutoPrint();
    final path = await _resiService.getWatchPath();
    final winPrinter = await _resiService.getWinPrinter();
    final opt = await _resiService.getOptimizePaper();
    final del = await _resiService.getAutoDelete();
    final branding = await _resiService.getBrandingText();

    if (mounted) {
      setState(() {
        _paperSize = size;
        _isAutoPrint = isAuto;
        _watchPath = path;
        _selectedWinPrinter = winPrinter;
        _isOptimizePaper = opt;
        _isAutoDelete = del;
        _brandingText = branding;
      });
    }
  }

  Future<void> _loadWinPrinters() async {
    try {
      final printers = await Printing.listPrinters();
      if (mounted) {
        setState(() {
          _allWinPrinters = printers;
        });
      }
    } catch (_) {}
  }

  Future<void> _pickWatchFolder() async {
    String? result = await FilePicker.platform.getDirectoryPath();
    if (result != null) {
      await _resiService.setWatchPath(result);
      if (mounted) {
        setState(() {
          _watchPath = result;
        });
      }
    }
  }

  void _onToggleAutoPrint(bool v) async {
    await _resiService.setAutoPrint(v);
    if (mounted) {
      setState(() {
        _isAutoPrint = v;
      });
    }
  }

  void _initSharingIntent() {
    if (Platform.isAndroid || Platform.isIOS) {
      ReceiveSharingIntent.instance.getMediaStream().listen((value) {
        if (value.isNotEmpty) {
          _handleSharedFile(value.first.path);
        }
      }, onError: (err) {
        debugPrint("getIntentDataStream error: $err");
      });

      ReceiveSharingIntent.instance.getInitialMedia().then((value) {
        if (value.isNotEmpty) {
          _handleSharedFile(value.first.path);
        }
      });
    }
  }

  Future<void> _handleSharedFile(String path) async {
    final file = File(path);
    if (await file.exists()) {
      if (mounted) {
        setState(() {
          _selectedFiles = [file];
        });
        _runOCR(file);
        _generatePreview();
      }
    }
  }

  Future<void> _runOCR(File file) async {
    setState(() {
      _detectedCourier = 'Membaca gambar...';
      _detectedTracking = 'Scanning OCR...';
    });

    final result = await ResiOcrService().detect(file);
    if (mounted) {
      setState(() {
        _detectedCourier = result.courier;
        _detectedTracking = result.trackingNumber;
      });
    }
  }

  Future<void> _generatePreview() async {
    if (_selectedFiles.isEmpty) return;
    if (mounted) setState(() => _isLoading = true);
    try {
      final file = _selectedFiles.first;
      final bytes = await file.readAsBytes();
      final ext = file.path.split('.').last.toLowerCase();

      if (mounted) {
        if (ext == 'pdf') {
          setState(() {
            _previewBytes = null; // Placeholder for PDF
          });
        } else {
          setState(() {
            _previewBytes = bytes;
          });
        }
      }
    } catch (e) {
      debugPrint('Error generating preview: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png', 'webp'],
      allowMultiple: true,
    );

    if (result != null && result.files.isNotEmpty) {
      final files =
          result.paths.where((p) => p != null).map((p) => File(p!)).toList();
      if (mounted) {
        setState(() {
          _selectedFiles = files;
        });
        if (files.length == 1) {
          _runOCR(files.first);
        } else {
          setState(() {
            _detectedCourier = 'Batch (${files.length} file)';
            _detectedTracking = 'Berbagai Resi';
          });
        }
        _generatePreview();
      }
    }
  }

  Future<void> _printResi() async {
    if (_selectedFiles.isEmpty) return;

    if (mounted) setState(() => _isLoading = true);

    if (_selectedFiles.length == 1) {
      final success = await _resiService.printFile(_selectedFiles.first);
      if (mounted) {
        setState(() => _isLoading = false);
        if (success) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('Resi berhasil dikirim ke printer')));
        } else {
          showKasirInfoDialog(context,
              title: 'Gagal',
              message: 'Gagal mencetak resi. Pastikan printer terhubung.');
        }
      }
    } else {
      // Bulk print
      await _resiService.printBatch(_selectedFiles);
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showHistory() async {
    final logs = await ResiLogService().getHistory();
    if (!mounted) return;

    showDialog(
      context: context,
      builder: (context) => KasirDialog(
        title: 'Riwayat Cetak Resi',
        child: SizedBox(
          width: 400,
          height: 500,
          child: logs.isEmpty
              ? const Center(child: Text('Belum ada riwayat cetak'))
              : ListView.separated(
                  itemCount: logs.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final log = logs[i];
                    return ListTile(
                      dense: true,
                      title: Text(log['tracking_number'] ?? '-',
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(
                          '${log['courier']}  |  ${log['created_at'].toString().split('T')[0]}'),
                      trailing: Text(
                          log['source'] == 'manual' ? 'Manual' : 'Auto',
                          style: TextStyle(
                              fontSize: 10, color: Colors.grey.shade400)),
                    );
                  },
                ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return KasirResponsiveScaffold(
      title: 'Cetak Resi',
      showNavRail: false,
      actions: [
        IconButton(
          icon: const Icon(Icons.history_rounded),
          onPressed: _showHistory,
          tooltip: 'Riwayat Cetak',
        ),
      ],
      body: DropTarget(
        onDragDone: (detail) {
          debugPrint('Files dropped: ${detail.files.length}');
          if (detail.files.isNotEmpty) {
            final files = detail.files.map((e) => File(e.path)).toList();
            setState(() {
              _selectedFiles = files;
            });
            if (files.length == 1) _runOCR(files.first);
            _generatePreview();
          }
        },
        onDragEntered: (detail) => setState(() => _isDragging = true),
        onDragExited: (detail) => setState(() => _isDragging = false),
        child: CallbackShortcuts(
          bindings: {
            const SingleActivator(LogicalKeyboardKey.f10): () =>
                _onToggleAutoPrint(!_isAutoPrint),
            const SingleActivator(LogicalKeyboardKey.f11): _pickFile,
            const SingleActivator(LogicalKeyboardKey.f12): _printResi,
          },
          child: Focus(
            autofocus: true,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Builder(
                    builder: (context) {
                      final isWide = KasirLayout.isWide(context);
                      final previewWidget = Container(
                        padding: responsivePadding(context),
                        color: _isDragging
                            ? AppColors.primaryBrand.withValues(alpha: 0.05)
                            : const Color(0xFFF8F9FA),
                        child: Center(
                          child: Stack(
                            children: [
                              _buildPreview(),
                              if (_batchStatus != null) _buildBatchOverlay(),
                            ],
                          ),
                        ),
                      );

                      final settingsWidget = Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: isWide
                              ? Border(
                                  left: BorderSide(color: Colors.grey.shade200))
                              : null,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildSectionHeader('DASAR'),
                            const SizedBox(height: 12),
                            ModernPicker<int>(
                              label: 'Kertas Printer',
                              value: _paperSize,
                              items: const [58, 80],
                              itemLabel: (v) => '$v mm',
                              onChanged: (v) {
                                if (mounted) {
                                  setState(() => _paperSize = v);
                                  _resiService.setPaperSize(v);
                                }
                              },
                            ),
                            const SizedBox(height: 12),
                            _buildSwitch(
                              title: 'Optimalkan Kertas',
                              subtitle: 'Auto-crop margin putih (Smart)',
                              value: _isOptimizePaper,
                              onChanged: (v) {
                                if (mounted) {
                                  setState(() => _isOptimizePaper = v);
                                  _resiService.setOptimizePaper(v);
                                }
                              },
                            ),
                            if (Platform.isWindows) ...[
                              const SizedBox(height: 24),
                              _buildSectionHeader('DESKTOP & AUTOMASI'),
                              const SizedBox(height: 12),
                              ModernPicker<String>(
                                label: 'Pilih Printer Desktop',
                                hint: 'Klik untuk pilih printer...',
                                value: _selectedWinPrinter,
                                items:
                                    _allWinPrinters.map((e) => e.name).toList(),
                                itemLabel: (v) => v,
                                onChanged: (v) {
                                  if (mounted) {
                                    setState(() => _selectedWinPrinter = v);
                                    _resiService.setWinPrinter(v);
                                  }
                                },
                              ),
                              const SizedBox(height: 8),
                              const Text(
                                  '* Gunakan printer thermal agar cetak langsung.',
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.blueGrey,
                                      fontStyle: FontStyle.italic)),
                              const SizedBox(height: 20),
                              _buildSwitch(
                                title: 'Cetak Otomatis',
                                subtitle: 'Print instan dari folder',
                                value: _isAutoPrint,
                                onChanged: _onToggleAutoPrint,
                              ),
                              if (_isAutoPrint) ...[
                                const SizedBox(height: 10),
                                _buildWatchFolderTile(),
                                const SizedBox(height: 12),
                                _buildSwitch(
                                  title: 'Auto-Hapus Arsip',
                                  subtitle: 'Hapus file setelah 7 hari',
                                  value: _isAutoDelete,
                                  onChanged: (v) {
                                    if (mounted) {
                                      setState(() => _isAutoDelete = v);
                                      _resiService.setAutoDelete(v);
                                    }
                                  },
                                ),
                              ],
                            ],
                            const SizedBox(height: 24),
                            _buildSectionHeader('FOOTER BRANDING'),
                            const SizedBox(height: 12),
                            TextField(
                              decoration: InputDecoration(
                                hintText: 'Misal: Terima kasih...',
                                hintStyle: TextStyle(
                                    fontSize: 12, color: Colors.grey.shade400),
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 8),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                    borderSide: BorderSide(
                                        color: Colors.grey.shade200)),
                              ),
                              style: const TextStyle(fontSize: 13),
                              onChanged: (v) {
                                _resiService.setBrandingText(v);
                                _brandingText = v;
                              },
                              controller: TextEditingController(
                                  text: _brandingText)
                                ..selection = TextSelection.fromPosition(
                                    TextPosition(offset: _brandingText.length)),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                                '* Nama toko akan muncul di bagian bawah resi.',
                                style:
                                    TextStyle(fontSize: 9, color: Colors.grey)),
                            const SizedBox(height: 32),
                            SizedBox(
                              width: double.infinity,
                              child: OutlinedButton.icon(
                                onPressed: _pickFile,
                                icon: const Icon(Icons.file_open_rounded,
                                    size: 20),
                                label: const Text('PILIH FILE RESI'),
                                style: OutlinedButton.styleFrom(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 14),
                                  side: const BorderSide(
                                      color: AppColors.primaryBrand,
                                      width: 1.5),
                                  foregroundColor: AppColors.primaryBrand,
                                  textStyle: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                      letterSpacing: 0.5),
                                  shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.zero),
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: _selectedFiles.isNotEmpty
                                    ? _printResi
                                    : null,
                                icon: const Icon(Icons.print_rounded, size: 20),
                                label: Text(_selectedFiles.length > 1
                                    ? 'CETAK SEMUA (${_selectedFiles.length})'
                                    : 'CETAK SEKARANG'),
                                style: ElevatedButton.styleFrom(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 14),
                                  backgroundColor: AppColors.primaryBrand,
                                  foregroundColor: Colors.white,
                                  textStyle: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                      letterSpacing: 0.5),
                                  elevation: 0,
                                  shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.zero),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );

                      if (isWide) {
                        return Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Expanded(flex: 7, child: previewWidget),
                            SizedBox(
                                width: 320,
                                child: SingleChildScrollView(
                                    child: settingsWidget)),
                          ],
                        );
                      }
                      return SingleChildScrollView(
                        child: Column(
                          children: [
                            previewWidget,
                            settingsWidget,
                          ],
                        ),
                      );
                    },
                  ),
                ),
                if (_isDragging)
                  Container(
                    color: AppColors.primaryBrand.withValues(alpha: 0.8),
                    child: const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.file_download_rounded,
                              size: 80, color: Colors.white),
                          SizedBox(height: 20),
                          Text('Lepaskan File untuk Cetak',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPreview() {
    if (_isLoading) return const CircularProgressIndicator();

    if (_selectedFiles.isEmpty) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.file_copy_outlined, size: 64, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          Text('Belum ada file dipilih',
              style: TextStyle(color: Colors.grey.shade500)),
          const SizedBox(height: 8),
          Text('Gunakan tombol di samping atau Share dari aplikasi lain',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: Colors.grey.shade400)),
        ],
      );
    }

    final file = _selectedFiles.first;
    final ext = file.path.split('.').last.toLowerCase();
    final fileName = file.path.split(Platform.pathSeparator).last;

    return Card(
      elevation: 4,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            color: AppColors.primaryBrand,
            child: Row(
              children: [
                Icon(
                    ext == 'pdf'
                        ? Icons.picture_as_pdf_rounded
                        : Icons.image_rounded,
                    color: Colors.white,
                    size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(fileName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 13)),
                ),
                IconButton(
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  icon:
                      const Icon(Icons.close, color: Colors.white70, size: 18),
                  onPressed: () {
                    if (mounted) {
                      setState(() {
                        _selectedFiles = [];
                        _previewBytes = null;
                        _detectedCourier = '';
                        _detectedTracking = '';
                      });
                    }
                  },
                ),
              ],
            ),
          ),
          if (_detectedTracking.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              color: Colors.yellow.shade50,
              child: Row(
                children: [
                  Icon(Icons.auto_awesome_rounded,
                      size: 14, color: Colors.orange.shade700),
                  const SizedBox(width: 8),
                  Text('Terdeteksi: ',
                      style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: Colors.orange.shade900)),
                  Text('$_detectedCourier - $_detectedTracking',
                      style: TextStyle(
                          fontSize: 11, color: Colors.orange.shade900)),
                ],
              ),
            ),
          ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 400),
            child: _previewBytes != null
                ? Image.memory(_previewBytes!, fit: BoxFit.contain)
                : Container(
                    width: 300,
                    height: 300,
                    color: Colors.white,
                    child: const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.picture_as_pdf_rounded,
                              size: 48, color: Colors.redAccent),
                          SizedBox(height: 12),
                          Text('Preview PDF Berhasil Disiapkan',
                              style: TextStyle(fontWeight: FontWeight.bold)),
                          Text('Siap untuk dicetak',
                              style: TextStyle(
                                  fontSize: 12, color: Colors.black54)),
                        ],
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildSwitch(
      {required String title,
      required String subtitle,
      required bool value,
      required ValueChanged<bool> onChanged}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                      color: Colors.black87)),
              const SizedBox(height: 2),
              Text(subtitle,
                  style: TextStyle(
                      fontSize: 11, color: Colors.grey.shade500, height: 1.2)),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Transform.scale(
          scale: 0.8,
          child: Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: AppColors.primaryBrand,
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(String title) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w900,
            color: Colors.grey.shade400,
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 4),
        Container(
            width: 30,
            height: 2,
            color: AppColors.primaryBrand.withValues(alpha: 0.3)),
      ],
    );
  }

  Widget _buildWatchFolderTile() {
    return InkWell(
      onTap: _pickWatchFolder,
      borderRadius: BorderRadius.zero,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFF8FAFC),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Row(
          children: [
            const Icon(Icons.folder_open_rounded,
                size: 18, color: AppColors.primaryBrand),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('FOLDER PANTAUAN',
                      style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          color: Colors.grey)),
                  const SizedBox(height: 2),
                  Text(_watchPath ?? 'Klik untuk pilih folder...',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 11,
                          color: Colors.black87,
                          fontWeight: FontWeight.w500)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded,
                size: 20, color: Colors.grey),
          ],
        ),
      ),
    );
  }

  Widget _buildBatchOverlay() {
    if (_batchStatus == null) return const SizedBox.shrink();

    final progress = _batchStatus!.current / _batchStatus!.total;

    return Container(
      color: Colors.black.withValues(alpha: 0.7),
      padding: const EdgeInsets.all(40),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: Colors.white),
            const SizedBox(height: 24),
            const Text('Mencetak Batch...',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('${_batchStatus!.current} dari ${_batchStatus!.total} resi',
                style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 24),
            LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.white24,
              color: AppColors.primaryBrand,
            ),
            const SizedBox(height: 12),
            Text('Memproses: ${_batchStatus!.fileName}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white54, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

