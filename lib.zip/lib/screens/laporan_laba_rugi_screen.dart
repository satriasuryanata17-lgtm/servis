import 'dart:math';
import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../database/db_helper.dart';
import 'responsive_layout.dart';
import '../widgets/export_dropdown.dart';
import '../services/export_service.dart';
import '../services/profit_loss_pdf_service.dart';
import '../widgets/kasir_dialog.dart';

const Color _kBrand = AppColors.primaryBrand;
const Color _kText = Color(0xFF182236);
const Color _kMuted = Color(0xFF6B7890);
const Color _kSoftSurface = Color(0xFFF8FAFC);

int _asInt(dynamic value) => (value as num?)?.toInt() ?? 0;

double _asDouble(dynamic value) => (value as num?)?.toDouble() ?? 0.0;

String _fmtQty(double value, {String unit = 'pcs'}) {
  final text = value == value.roundToDouble()
      ? value.toStringAsFixed(0)
      : value.toStringAsFixed(2);
  return '$text $unit';
}

String _fRp(int n) {
  if (n == 0) return 'Rp 0';
  final neg = n < 0;
  String s = n.abs().toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return 'Rp ${neg ? '-' : ''}$r';
}

bool _isWide(BuildContext ctx) {
  final mq = MediaQuery.of(ctx);
  return mq.size.width >= 720 ||
      (mq.orientation == Orientation.landscape && mq.size.width >= 600);
}

class AnalisisKeuntunganScreen extends StatefulWidget {
  const AnalisisKeuntunganScreen({super.key});
  @override
  State<AnalisisKeuntunganScreen> createState() =>
      _AnalisisKeuntunganScreenState();
}

class _AnalisisKeuntunganScreenState extends State<AnalisisKeuntunganScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  String _periode = 'Periode Bulanan';
  final List<String> _periodeOptions = [
    'Periode Harian',
    'Periode Bulanan',
    'Periode Tahunan',
    'Kustom Tanggal',
  ];
  int _tahun = DateTime.now().year;
  int _bulan = DateTime.now().month;
  DateTime _hariTerpilih = DateTime.now();
  DateTime? _customStart;
  DateTime? _customEnd;

  final List<String> _bulanNama = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember'
  ];
  final List<int> _tahunOptions =
      List.generate(10, (i) => DateTime.now().year - i);

  bool _loading = true;

  Map<String, int> _summary = {};
  Map<String, int> _expensesByCategory = {};
  List<Map<String, dynamic>> _produkMargin = [];
  List<Map<String, dynamic>> _chartData = [];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);

    DateTime start, end;
    if (_periode == 'Periode Harian') {
      start =
          DateTime(_hariTerpilih.year, _hariTerpilih.month, _hariTerpilih.day);
      end = start.add(const Duration(days: 1));
    } else if (_periode == 'Periode Bulanan') {
      start = DateTime(_tahun, _bulan, 1);
      end = _bulan == 12
          ? DateTime(_tahun + 1, 1, 1)
          : DateTime(_tahun, _bulan + 1, 1);
    } else if (_periode == 'Periode Tahunan') {
      start = DateTime(_tahun, 1, 1);
      end = DateTime(_tahun + 1, 1, 1);
    } else {
      start = _customStart ?? DateTime.now();
      end = _customEnd ?? DateTime.now();
      end = DateTime(end.year, end.month, end.day).add(const Duration(days: 1));
    }

    try {
      final summary = await DBHelper.instance.getLabaRugiRange(start, end);
      final produk =
          await DBHelper.instance.getMarginPerProduk(start, end, limit: 20);
      final chart = await DBHelper.instance.getOmzetVsHppBulanan(_tahun);
      final expenses = await DBHelper.instance
          .getOperationalExpensesByCategoryRange(start, end);

      if (!mounted) return;
      setState(() {
        _summary = summary;
        _expensesByCategory = expenses;
        _produkMargin = produk;
        _chartData = chart;
        _loading = false;
      });
    } catch (e) {
      debugPrint('Error loading laba rugi: $e');
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Terjadi kesalahan saat memuat data: $e')),
      );
    }
  }

  Future<void> _showPeriodeSheet() async {
    final selected = await showKasirOptionSheet<String>(context,
        title: 'Pilih Periode',
        options: _periodeOptions,
        currentValue: _periode,
        labelBuilder: (v) => v);
    if (selected != null && selected != _periode && mounted) {
      setState(() => _periode = selected);
      if (selected == 'Kustom Tanggal') {
        _pickCustomDate();
      } else {
        _load();
      }
    }
  }

  Future<void> _showBulanSheet() async {
    final selected = await showKasirOptionSheet<int>(context,
        title: 'Pilih Bulan',
        options: List.generate(12, (i) => i + 1),
        currentValue: _bulan,
        labelBuilder: (b) => _bulanNama[b - 1]);
    if (selected != null && selected != _bulan && mounted) {
      setState(() => _bulan = selected);
      _load();
    }
  }

  Future<void> _showTahunSheet() async {
    final selected = await showKasirOptionSheet<int>(context,
        title: 'Pilih Tahun',
        options: _tahunOptions,
        currentValue: _tahun,
        labelBuilder: (y) => y.toString());
    if (selected != null && selected != _tahun && mounted) {
      setState(() => _tahun = selected);
      _load();
    }
  }

  Future<void> _pickHariDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _hariTerpilih,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx)
            .copyWith(colorScheme: const ColorScheme.light(primary: _kBrand)),
        child: child!,
      ),
    );
    if (date != null && mounted) {
      setState(() => _hariTerpilih = date);
      _load();
    }
  }

  Future<void> _pickCustomDate() async {
    final range = await showDateRangePicker(
      context: context,
      initialDateRange: _customStart != null && _customEnd != null
          ? DateTimeRange(start: _customStart!, end: _customEnd!)
          : null,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx)
            .copyWith(colorScheme: const ColorScheme.light(primary: _kBrand)),
        child: child!,
      ),
    );
    if (range != null && mounted) {
      setState(() {
        _customStart = range.start;
        _customEnd = range.end;
      });
      _load();
    } else if (mounted && _customStart == null) {
      setState(() => _periode = 'Periode Bulanan');
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final wide = _isWide(context);

    final exportAction = Padding(
      padding: const EdgeInsets.only(right: 16),
      child: GestureDetector(
        onTap: _handleExport,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: const BoxDecoration(
            color: AppColors.primaryBrand,
            borderRadius: BorderRadius.zero,
          ),
          child: const Row(
            children: [
              Icon(Icons.download_rounded, color: Colors.white, size: 15),
              SizedBox(width: 5),
              Text(
                'Ekspor',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );

    return KasirResponsiveScaffold(
      title: 'Analisis Keuntungan',
      navIndex: 4,
      showNavRail: false,
      actions: [exportAction],
      backgroundColor: wide ? const Color(0xFFF5F6FA) : AppColors.background,
      body: Column(
        children: [
          // Period selector
          KasirPeriodBar(
            periode: _periode,
            tahun: _tahun,
            bulan: _bulan,
            hariTerpilih: _hariTerpilih,
            customStart: _customStart,
            customEnd: _customEnd,
            onPeriodeTap: _showPeriodeSheet,
            onTahunTap: _showTahunSheet,
            onBulanTap: _showBulanSheet,
            onHariTap: _pickHariDate,
          ),
          if (!wide)
            TabBar(
              controller: _tab,
              labelColor: _kBrand,
              unselectedLabelColor: Colors.grey,
              indicatorColor: _kBrand,
              tabs: const [
                Tab(text: 'Ringkasan'),
                Tab(text: 'Per Item'),
                Tab(text: 'Grafik'),
              ],
            ),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),

          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: _kBrand))
                : wide
                    ? _buildWideBody(context)
                    : _buildNarrowBody(),
          ),
        ],
      ),
    );
  }

  Future<void> _handleExport() async {
    final option = await ExportDropdown.show(context);
    if (option == null) return;

    String periodStr = '';
    if (_periode == 'Periode Harian') {
      periodStr =
          '${_hariTerpilih.day} ${_bulanNama[_hariTerpilih.month - 1]} ${_hariTerpilih.year}';
    } else if (_periode == 'Periode Bulanan') {
      periodStr = '${_bulanNama[_bulan - 1]} $_tahun';
    } else if (_periode == 'Periode Tahunan') {
      periodStr = 'Tahun $_tahun';
    } else {
      if (_customStart != null && _customEnd != null) {
        periodStr =
            '${_customStart!.day}/${_customStart!.month}/${_customStart!.year} - ${_customEnd!.day}/${_customEnd!.month}/${_customEnd!.year}';
      }
    }

    final period = periodStr;
    const title = 'Laporan Analisis Keuntungan';

    // 1. Prepare CSV Data
    final omzetKotor = _summary['omzet_kotor'] ?? _summary['omzet'] ?? 0;
    final retur = _summary['retur_penjualan'] ?? 0;
    final omzet = _summary['omzet'] ?? 0;
    final hpp = _summary['hpp'] ?? 0;
    final labaKotor = _summary['laba_kotor'] ?? 0;
    final pengeluaran = _summary['pengeluaran'] ?? 0;
    final labaBersih = _summary['laba_bersih'] ?? 0;
    final pembelianStok = _summary['pembelian_stok'] ?? 0;

    final headers = ['Keterangan', 'Nilai'];
    final rows = [
      ['Omzet Kotor', _fRp(omzetKotor)],
      ['Refund / Retur', _fRp(retur)],
      ['Omzet Bersih', _fRp(omzet)],
      ['HPP Tercatat', _fRp(hpp)],
      ['Laba Kotor', _fRp(labaKotor)],
      ['Biaya Operasional', _fRp(pengeluaran)],
      ['Laba Bersih', _fRp(labaBersih)],
      ['Pembelian Stok / Aset (Arus Kas, Bukan Beban)', _fRp(pembelianStok)],
      ['', ''],
      ['RINCIAN PER ITEM/LAYANAN', ''],
      ['Item/Layanan', 'HPP', 'Sumber HPP', 'Laba (Margin)'],
    ];

    for (final p in _produkMargin) {
      final name = p['product_name'] ?? '-';
      final hpp = _asInt(p['total_hpp']);
      final hppSource = (p['hpp_source'] ?? 'HPP tidak dihitung').toString();
      final laba = _asInt(p['laba_kotor']);
      final margin = _asDouble(p['margin_pct']);
      rows.add([
        name,
        hppSource == 'HPP tidak dihitung' ? 'Tidak dihitung' : _fRp(hpp),
        hppSource,
        '${_fRp(laba)} (${margin.toStringAsFixed(1)}%)',
      ]);
    }

    if (option == 'csv') {
      await ExportService.exportAndShareCsv(
        filePrefix: 'Laba_Rugi',
        headers: headers,
        rows: rows,
        subject: '$title - $period',
      );
    } else if (option == 'pdf') {
      await ProfitLossPdfService.generateAndShare(
        period: period,
        summary: _summary,
        expensesByCategory: _expensesByCategory,
        productMargins: _produkMargin,
      );
    } else if (option == 'print') {
      await ProfitLossPdfService.printReport(
        period: period,
        summary: _summary,
        expensesByCategory: _expensesByCategory,
        productMargins: _produkMargin,
      );
    }
  }

  // (Period selector removed, handled by KasirPeriodBar)

  Widget _buildWideBody(BuildContext ctx) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // LEFT: Ringkasan + navigation
        SizedBox(
          width: 360,
          child: Column(children: [
            // Tab nav as sidebar buttons
            _buildSidebarTabs(),
            const Divider(height: 1, color: Color(0xFFEEEEEE)),
            Expanded(
              child: TabBarView(
                controller: _tab,
                children: [
                  _buildRingkasan(wide: true),
                  _buildPerProduk(wide: true),
                  _buildGrafik(wide: true),
                ],
              ),
            ),
          ]),
        ),

        const VerticalDivider(width: 1, color: Color(0xFFEEEEEE)),

        // RIGHT: Highlight card + quick stats
        Expanded(child: _buildWideRightPanel()),
      ],
    );
  }

  Widget _buildSidebarTabs() {
    return AnimatedBuilder(
      animation: _tab,
      builder: (_, __) => Row(
        children: ['Ringkasan', 'Per Item', 'Grafik']
            .asMap()
            .entries
            .map((e) => Expanded(
                  child: InkWell(
                    onTap: () => _tab.animateTo(e.key),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: _tab.index == e.key
                                ? _kBrand
                                : Colors.transparent,
                            width: 2.5,
                          ),
                        ),
                        color: _tab.index == e.key
                            ? _kBrand.withValues(alpha: 0.04)
                            : Colors.white,
                      ),
                      child: Text(
                        e.value,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: _tab.index == e.key ? _kBrand : _kMuted,
                        ),
                      ),
                    ),
                  ),
                ))
            .toList(),
      ),
    );
  }

  Widget _buildMetricWrap(List<Widget> cards) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth < 330 ? 1 : 2;
        const spacing = 10.0;
        final itemWidth =
            (constraints.maxWidth - spacing * (columns - 1)) / columns;

        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: [
            for (final card in cards) SizedBox(width: itemWidth, child: card),
          ],
        );
      },
    );
  }

  Widget _buildWideRightPanel() {
    final retur = _summary['retur_penjualan'] ?? 0;
    final omzet = _summary['omzet'] ?? 0;
    final hpp = _summary['hpp'] ?? 0;
    final labaKotor = _summary['laba_kotor'] ?? 0;
    final pengeluaran = _summary['pengeluaran'] ?? 0;
    final labaBersih = _summary['laba_bersih'] ?? 0;
    final marginB =
        omzet > 0 ? (labaBersih / omzet * 100).toStringAsFixed(1) : '0.0';
    final marginK =
        omzet > 0 ? (labaKotor / omzet * 100).toStringAsFixed(1) : '0.0';

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _ProfitHeroCard(
            labaBersih: labaBersih,
            omzet: omzet,
            labaKotor: labaKotor,
            marginBersih: marginB,
          ),
          const SizedBox(height: 20),
          _buildMetricWrap([
            _KpiCard(
                'Omzet Bersih', _fRp(omzet), Icons.trending_up_rounded, _kBrand,
                subtitle: retur > 0
                    ? 'Refund/retur ${_fRp(retur)}'
                    : 'Servis + produk'),
            _KpiCard('HPP Tercatat', _fRp(hpp), Icons.receipt_long_outlined,
                AppColors.warning,
                subtitle: 'Stok aktif + resep bahan'),
            _KpiCard(
                'Laba Kotor',
                _fRp(labaKotor),
                Icons.account_balance_wallet_outlined,
                labaKotor >= 0 ? AppColors.success : AppColors.danger,
                subtitle: 'Margin $marginK%'),
            _KpiCard('Biaya Operasional', _fRp(pengeluaran),
                Icons.money_off_outlined, AppColors.danger,
                subtitle: 'Biaya usaha periode ini'),
          ]),
        ],
      ),
    );
  }

  Widget _buildNarrowBody() {
    return TabBarView(
      controller: _tab,
      children: [
        _buildRingkasan(wide: false),
        _buildPerProduk(wide: false),
        _buildGrafik(wide: false),
      ],
    );
  }

  // TAB 1: RINGKASAN

  Widget _buildRingkasan({required bool wide}) {
    final omzetKotor = _summary['omzet_kotor'] ?? _summary['omzet'] ?? 0;
    final retur = _summary['retur_penjualan'] ?? 0;
    final omzet = _summary['omzet'] ?? 0;
    final hpp = _summary['hpp'] ?? 0;
    final labaKotor = _summary['laba_kotor'] ?? 0;
    final pengeluaran = _summary['pengeluaran'] ?? 0;
    final labaBersih = _summary['laba_bersih'] ?? 0;
    final pembelianStok = _summary['pembelian_stok'] ?? 0;
    final marginKotor =
        omzet > 0 ? (labaKotor / omzet * 100).toStringAsFixed(1) : '0.0';
    final marginBersih =
        omzet > 0 ? (labaBersih / omzet * 100).toStringAsFixed(1) : '0.0';

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        if (!wide) ...[
          _ProfitHeroCard(
            labaBersih: labaBersih,
            omzet: omzet,
            labaKotor: labaKotor,
            marginBersih: marginBersih,
          ),
          const SizedBox(height: 16),
        ],
        _buildMetricWrap([
          _KpiCard(
            'Omzet Bersih',
            _fRp(omzet),
            Icons.trending_up_rounded,
            _kBrand,
            subtitle: 'Servis + produk',
          ),
          _KpiCard(
            'HPP Tercatat',
            _fRp(hpp),
            Icons.receipt_long_outlined,
            AppColors.warning,
            subtitle: 'Stok aktif + resep bahan',
          ),
          _KpiCard(
            'Laba Kotor',
            _fRp(labaKotor),
            Icons.account_balance_wallet_outlined,
            labaKotor >= 0 ? AppColors.success : AppColors.danger,
            subtitle: 'Margin $marginKotor%',
          ),
          _KpiCard(
            'Operasional',
            _fRp(pengeluaran),
            Icons.money_off_outlined,
            AppColors.danger,
            subtitle: 'Biaya usaha',
          ),
        ]),
        const SizedBox(height: 18),
        const _SectionTitle(
          title: 'Pendapatan & HPP',
          subtitle:
              'Omzet mencakup layanan servis dan produk yang ikut dijual.',
        ),
        const SizedBox(height: 8),
        _SummaryCard(children: [
          _SumRow(
            'Omzet Kotor',
            omzetKotor,
            _kBrand,
            subtitle: 'Sebelum refund atau retur',
          ),
          if (retur > 0) ...[
            const SizedBox(height: 8),
            _SumRow(
              'Dikurangi Refund / Retur',
              -retur,
              AppColors.danger,
              subtitle: 'Transaksi yang dikembalikan',
            ),
          ],
          const Divider(height: 20),
          _SumRow(
            'Omzet Bersih',
            omzet,
            _kText,
            isHeader: true,
            subtitle: 'Pendapatan setelah koreksi',
          ),
          const Divider(height: 20),
          _SumRow(
            'HPP Tercatat',
            hpp,
            AppColors.warning,
            subtitle:
                'Dari resep bahan baku dan item dengan Manajemen Stok aktif',
          ),
          const SizedBox(height: 8),
          _SumRow('Laba Kotor', labaKotor,
              labaKotor >= 0 ? AppColors.success : AppColors.danger,
              isHeader: true, subtitle: 'Margin kotor $marginKotor%'),
        ]),
        const SizedBox(height: 16),
        const _SectionTitle(
          title: 'Operasional',
          subtitle: 'Biaya usaha yang mengurangi laba bersih periode ini.',
        ),
        const SizedBox(height: 8),
        _SummaryCard(children: [
          _SumRow(
            'Biaya Operasional',
            pengeluaran,
            AppColors.danger,
            subtitle: 'Contoh: listrik, gaji, sewa, transport, dan lain-lain',
          ),
          if (pembelianStok > 0) ...[
            const SizedBox(height: 8),
            _InlineNote(
              'Pembelian stok/aset ${_fRp(pembelianStok)} dicatat sebagai arus kas dan aset, bukan beban operasional.',
            ),
          ],
          const Divider(height: 20),
          _SumRow('Estimasi Laba Bersih', labaBersih,
              labaBersih >= 0 ? AppColors.success : AppColors.danger,
              isHeader: true, subtitle: 'Margin bersih $marginBersih%'),
        ]),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFFEFF6FF),
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFD8E7FF)),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.info_outline_rounded, color: _kBrand, size: 17),
                  SizedBox(width: 8),
                  Text(
                    'Cara membaca angka',
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w800,
                      color: _kText,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8),
              Text(
                'Omzet Bersih = Omzet Kotor - Refund/Retur\n'
                'Laba Kotor = Omzet Bersih - HPP\n'
                'Laba Bersih = Laba Kotor - Biaya Operasional\n'
                'HPP hanya dihitung dari resep bahan baku atau item dengan Manajemen Stok aktif.\n'
                'Layanan biasa tanpa stok/resep tidak diberi HPP agar laba tidak bias.',
                style: TextStyle(
                  fontSize: 12,
                  color: Color(0xFF4B5E7A),
                  height: 1.65,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // TAB 2: PER PRODUK

  Widget _buildPerProduk({required bool wide}) {
    if (_produkMargin.isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inventory_2_outlined,
                size: 48, color: Color(0xFFB8C2D4)),
            SizedBox(height: 12),
            Text('Belum ada data penjualan bulan ini',
                style: TextStyle(color: _kMuted)),
          ],
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.all(12),
      itemCount: _produkMargin.length + 1,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, i) {
        if (i == 0) {
          return Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFEFF6FF),
              border: Border.all(color: const Color(0xFFBFDBFE)),
              borderRadius: BorderRadius.zero,
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.info_outline_rounded, size: 17, color: _kBrand),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'HPP dihitung dari resep bahan baku atau item dengan Manajemen Stok aktif. Layanan tanpa stok/resep ditandai tidak dihitung.',
                    style: TextStyle(
                      fontSize: 11.5,
                      height: 1.4,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF1E3A8A),
                    ),
                  ),
                ),
              ],
            ),
          );
        }

        final itemIndex = i - 1;
        final row = _produkMargin[itemIndex];
        final name = (row['product_name'] ?? '-') as String;
        final unit = (row['unit'] ?? 'pcs') as String;
        final qty = _asDouble(row['total_qty']);
        final omzet = _asInt(row['total_omzet']);
        final hpp = _asInt(row['total_hpp']);
        final hppSource =
            (row['hpp_source'] ?? 'HPP tidak dihitung').toString();
        final hppCounted = hppSource != 'HPP tidak dihitung';
        final hppText = hppCounted ? _fRp(hpp) : 'Tidak dihitung';
        final hppColor = hppCounted ? AppColors.warning : _kMuted;
        final laba = _asInt(row['laba_kotor']);
        final margin = _asDouble(row['margin_pct']);
        final profitColor = laba >= 0 ? AppColors.success : AppColors.danger;

        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  width: 28,
                  height: 28,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: _kBrand.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Text('$i',
                      style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: _kBrand)),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name,
                          style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                              color: _kText),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 5),
                      _CostSourceBadge(source: hppSource),
                    ],
                  ),
                ),
                _MarginBadge(margin: margin),
              ]),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: const BoxDecoration(
                  color: _kSoftSurface,
                  borderRadius: BorderRadius.zero,
                ),
                child: Row(children: [
                  Expanded(
                      child: _MiniStat(
                          'Terjual', _fmtQty(qty, unit: unit), _kText)),
                  Expanded(child: _MiniStat('Omzet', _fRp(omzet), _kBrand)),
                  Expanded(child: _MiniStat('HPP', hppText, hppColor)),
                  Expanded(child: _MiniStat('Laba', _fRp(laba), profitColor)),
                ]),
              ),
            ],
          ),
        );
      },
    );
  }

  // TAB 3: GRAFIK

  Widget _buildGrafik({required bool wide}) {
    if (_chartData.isEmpty) {
      return const Center(child: Text('Tidak ada data'));
    }

    final months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'Mei',
      'Jun',
      'Jul',
      'Ags',
      'Sep',
      'Okt',
      'Nov',
      'Des'
    ];
    final chartMax = _chartData
        .map((d) => max(_asInt(d['omzet']), _asInt(d['hpp'])))
        .reduce(max);
    final maxVal = chartMax <= 0 ? 1.0 : chartMax.toDouble();

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        // Legend
        const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _Legend(color: _kBrand, label: 'Omzet'),
            SizedBox(width: 20),
            _Legend(color: AppColors.danger, label: 'HPP'),
            SizedBox(width: 20),
            _Legend(color: AppColors.success, label: 'Laba Kotor'),
          ],
        ),
        const SizedBox(height: 12),

        // Bar chart taller on wide
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: AppColors.border),
          ),
          child: SizedBox(
            height: wide ? 280 : 220,
            child: CustomPaint(
              painter: _BarChartPainter(
                data: _chartData,
                maxVal: maxVal <= 0 ? 1 : maxVal,
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: List.generate(
                    12,
                    (i) => Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(height: wide ? 260 : 200),
                              Text(months[i],
                                  style: const TextStyle(
                                      fontSize: 9, color: _kMuted)),
                            ],
                          ),
                        )),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),

        // Table
        _buildMonthlyTable(months),
      ],
    );
  }

  Widget _buildMonthlyTable(List<String> months) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE3E8F0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.025),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: const BoxDecoration(
            color: AppColors.brandLight,
            borderRadius: BorderRadius.vertical(top: Radius.zero),
          ),
          child: const Row(children: [
            Expanded(
                flex: 2,
                child: Text('Bulan',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: _kText))),
            Expanded(
                child: Text('Laba Kotor',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: _kText),
                    textAlign: TextAlign.right)),
            Expanded(
                child: Text('Margin',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: _kText),
                    textAlign: TextAlign.right)),
          ]),
        ),
        ...List.generate(12, (i) {
          final d = _chartData[i];
          final omzet = _asInt(d['omzet']);
          final laba = _asInt(d['laba_kotor']);
          final margin =
              omzet > 0 ? (laba / omzet * 100).toStringAsFixed(1) : '0.0';
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
            decoration: BoxDecoration(
              border: Border(
                  bottom: i < 11
                      ? const BorderSide(color: AppColors.divider)
                      : BorderSide.none),
            ),
            child: Row(children: [
              Expanded(
                  flex: 2,
                  child: Text(months[i],
                      style: const TextStyle(fontSize: 12, color: _kMuted))),
              Expanded(
                child: Text(_fRp(laba),
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color:
                            laba >= 0 ? AppColors.success : AppColors.danger),
                    textAlign: TextAlign.right),
              ),
              Expanded(
                child: Text('$margin%',
                    style: const TextStyle(fontSize: 12, color: _kMuted),
                    textAlign: TextAlign.right),
              ),
            ]),
          );
        }),
      ]),
    );
  }
}

class _ProfitHeroCard extends StatelessWidget {
  final int labaBersih;
  final int omzet;
  final int labaKotor;
  final String marginBersih;

  const _ProfitHeroCard({
    required this.labaBersih,
    required this.omzet,
    required this.labaKotor,
    required this.marginBersih,
  });

  @override
  Widget build(BuildContext context) {
    final isProfit = labaBersih >= 0;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _kBrand,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: _kBrand.withValues(alpha: 0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 42,
                height: 42,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.zero,
                ),
                child: const Icon(Icons.insights_rounded,
                    color: Colors.white, size: 22),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Estimasi Laba Bersih',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      'Layanan servis + produk terjual',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 11.5,
                        height: 1.25,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.zero,
                  border:
                      Border.all(color: Colors.white.withValues(alpha: 0.18)),
                ),
                child: Text(
                  isProfit ? 'Laba' : 'Rugi',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            child: FittedBox(
              alignment: Alignment.centerLeft,
              fit: BoxFit.scaleDown,
              child: Text(
                _fRp(labaBersih),
                maxLines: 1,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 34,
                  fontWeight: FontWeight.w900,
                  height: 1,
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _HeroMetric(
                  label: 'Margin Bersih',
                  value: '$marginBersih%',
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _HeroMetric(
                  label: 'Omzet Bersih',
                  value: _fRp(omzet),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _HeroMetric(
                  label: 'Laba Kotor',
                  value: _fRp(labaKotor),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _HeroMetric extends StatelessWidget {
  final String label;
  final String value;

  const _HeroMetric({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.11),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: Colors.white.withValues(alpha: 0.14)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 9.5,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          SizedBox(
            width: double.infinity,
            child: FittedBox(
              alignment: Alignment.centerLeft,
              fit: BoxFit.scaleDown,
              child: Text(
                value,
                maxLines: 1,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionTitle({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w800,
            color: _kText,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          subtitle,
          style: const TextStyle(
            fontSize: 11.5,
            height: 1.35,
            fontWeight: FontWeight.w500,
            color: _kMuted,
          ),
        ),
      ],
    );
  }
}

class _InlineNote extends StatelessWidget {
  final String text;

  const _InlineNote(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFBEB),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFFDE68A)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 11,
          color: Color(0xFF7C5B12),
          height: 1.45,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final String? subtitle;

  const _KpiCard(this.label, this.value, this.icon, this.color,
      {this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 98),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFEEEEEE)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(label,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 11.5,
                        height: 1.25,
                        color: _kMuted,
                        fontWeight: FontWeight.w600)),
              ),
              const SizedBox(width: 8),
              Icon(icon, color: color, size: 18),
            ],
          ),
          const SizedBox(height: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: double.infinity,
                child: FittedBox(
                  alignment: Alignment.centerLeft,
                  fit: BoxFit.scaleDown,
                  child: Text(value,
                      maxLines: 1,
                      style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                          color: color)),
                ),
              ),
              if (subtitle != null)
                Padding(
                  padding: const EdgeInsets.only(top: 3),
                  child: Text(subtitle!,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 10.5, height: 1.25, color: _kMuted)),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _BarChartPainter extends CustomPainter {
  final List<Map<String, dynamic>> data;
  final double maxVal;
  _BarChartPainter({required this.data, required this.maxVal});

  @override
  void paint(Canvas canvas, Size size) {
    final barAreaH = size.height - 20;
    final barW = size.width / (data.length * 3 + 1);
    final gap = barW;

    final paintOmzet = Paint()
      ..color = AppColors.primaryBrand.withValues(alpha: 0.85);
    final paintHpp = Paint()..color = AppColors.danger.withValues(alpha: 0.7);
    final paintLaba = Paint()..color = AppColors.success.withValues(alpha: 0.8);
    final paintGrid = Paint()
      ..color = Colors.black.withValues(alpha: 0.05)
      ..strokeWidth = 1;

    for (int i = 1; i <= 4; i++) {
      final y = barAreaH - (barAreaH * i / 4);
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paintGrid);
    }

    for (int i = 0; i < data.length; i++) {
      final d = data[i];
      final omzet = _asDouble(d['omzet']);
      final hpp = _asDouble(d['hpp']);
      final laba = _asDouble(d['laba_kotor']);
      final x = gap + i * (barW * 3 + gap);
      final hOmzet = (omzet / maxVal) * barAreaH;
      final hHpp = (hpp / maxVal) * barAreaH;
      final hLaba = laba > 0 ? (laba / maxVal) * barAreaH : 0.0;
      const rr = Radius.zero;

      if (hOmzet > 0) {
        canvas.drawRRect(
            RRect.fromRectAndCorners(
              Rect.fromLTWH(x, barAreaH - hOmzet, barW, hOmzet),
              topLeft: rr,
              topRight: rr,
            ),
            paintOmzet);
      }
      if (hHpp > 0) {
        canvas.drawRRect(
            RRect.fromRectAndCorners(
              Rect.fromLTWH(x + barW, barAreaH - hHpp, barW, hHpp),
              topLeft: rr,
              topRight: rr,
            ),
            paintHpp);
      }
      if (hLaba > 0) {
        canvas.drawRRect(
            RRect.fromRectAndCorners(
              Rect.fromLTWH(x + barW * 2, barAreaH - hLaba, barW, hLaba),
              topLeft: rr,
              topRight: rr,
            ),
            paintLaba);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class _SummaryCard extends StatelessWidget {
  final List<Widget> children;
  const _SummaryCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: children),
    );
  }
}

class _SumRow extends StatelessWidget {
  final String label;
  final int value;
  final Color color;
  final bool isHeader;
  final String? subtitle;

  const _SumRow(this.label, this.value, this.color,
      {this.isHeader = false, this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: TextStyle(
                      fontSize: isHeader ? 14 : 13,
                      fontWeight: isHeader ? FontWeight.w800 : FontWeight.w600,
                      color: isHeader ? _kText : _kMuted)),
              if (subtitle != null) ...[
                const SizedBox(height: 3),
                Text(
                  subtitle!,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 10.8,
                    height: 1.25,
                    color: _kMuted,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(width: 12),
        Flexible(
          child: FittedBox(
            alignment: Alignment.centerRight,
            fit: BoxFit.scaleDown,
            child: Text(_fRp(value),
                maxLines: 1,
                style: TextStyle(
                    fontSize: isHeader ? 15 : 13,
                    fontWeight: FontWeight.w800,
                    color: color)),
          ),
        ),
      ],
    );
  }
}

class _MarginBadge extends StatelessWidget {
  final double margin;
  const _MarginBadge({required this.margin});

  @override
  Widget build(BuildContext context) {
    final color = margin >= 20
        ? AppColors.success
        : margin >= 10
            ? AppColors.warning
            : AppColors.danger;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.zero,
      ),
      child: Text('${margin.toStringAsFixed(1)}%',
          style: TextStyle(
              fontSize: 12, fontWeight: FontWeight.w700, color: color)),
    );
  }
}

class _CostSourceBadge extends StatelessWidget {
  final String source;

  const _CostSourceBadge({required this.source});

  @override
  Widget build(BuildContext context) {
    final counted = source != 'HPP tidak dihitung';
    final color = source == 'Resep bahan'
        ? AppColors.success
        : counted
            ? AppColors.warning
            : _kMuted;
    final icon = source == 'Resep bahan'
        ? Icons.science_outlined
        : counted
            ? Icons.inventory_2_outlined
            : Icons.block_rounded;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: counted ? 0.12 : 0.08),
        border: Border.all(color: color.withValues(alpha: 0.18)),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 11, color: color),
          const SizedBox(width: 4),
          Text(
            source,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _MiniStat(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 10, color: _kMuted, fontWeight: FontWeight.w600)),
        const SizedBox(height: 2),
        Text(value,
            style: TextStyle(
                fontSize: 10.8,
                height: 1.18,
                fontWeight: FontWeight.w700,
                color: color),
            maxLines: 2,
            overflow: TextOverflow.ellipsis),
      ],
    );
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;
  const _Legend({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
            width: 10,
            height: 10,
            decoration:
                BoxDecoration(color: color, borderRadius: BorderRadius.zero)),
        const SizedBox(width: 5),
        Text(label, style: const TextStyle(fontSize: 11, color: _kMuted)),
      ],
    );
  }
}

