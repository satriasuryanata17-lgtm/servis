import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:barcode/barcode.dart' as barcode;
import 'package:barcode_widget/barcode_widget.dart' as barcode_widget;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/theme.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../services/label_print_service.dart';
import 'responsive_layout.dart';

class ProductPrintItem {
  final Product product;
  int qty;

  ProductPrintItem({required this.product, this.qty = 1});
}

class SelectedProductsPrintNotifier extends Notifier<List<ProductPrintItem>> {
  @override
  List<ProductPrintItem> build() => [];

  void set(List<ProductPrintItem> items) => state = items;
}

final selectedProductsPrintProvider =
    NotifierProvider<SelectedProductsPrintNotifier, List<ProductPrintItem>>(
        () => SelectedProductsPrintNotifier());

class _BarcodeDownloadSize {
  final String label;
  final double width;
  final double height;
  final int thermalBarcodeHeight;
  final int thermalBarcodeWidth;

  const _BarcodeDownloadSize(
    this.label,
    this.width,
    this.height,
    this.thermalBarcodeHeight,
    this.thermalBarcodeWidth,
  );
}

const _barcodeSizes = [
  _BarcodeDownloadSize('Kecil', 220, 100, 48, 2),
  _BarcodeDownloadSize('Sedang', 320, 140, 72, 2),
  _BarcodeDownloadSize('Besar', 440, 190, 96, 3),
];

class CetakLabelScreen extends ConsumerStatefulWidget {
  const CetakLabelScreen({super.key});

  @override
  ConsumerState<CetakLabelScreen> createState() => _CetakLabelScreenState();
}

class _CetakLabelScreenState extends ConsumerState<CetakLabelScreen> {
  int _selectedCategory = 0;
  int _selectedSizeIndex = 1;
  String _searchQuery = '';
  bool _printing = false;
  String? _printStatus;
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  List<Product> _getFilteredProducts(List<Product> allProducts) {
    return allProducts.where((p) {
      if (p.id == null) return false;
      final matchCat =
          _selectedCategory == 0 || p.categoryId == _selectedCategory;
      final barcodeValue = _effectiveBarcode(p).toLowerCase();
      final q = _searchQuery.toLowerCase();
      final matchQuery = q.isEmpty ||
          p.name.toLowerCase().contains(q) ||
          barcodeValue.contains(q) ||
          (p.sku?.toLowerCase().contains(q) ?? false);
      return matchCat && matchQuery;
    }).toList();
  }

  String _effectiveBarcode(Product p) {
    final raw = p.barcode?.trim();
    if (raw != null && raw.isNotEmpty) return raw;
    final prefix = p.isMaterial == 1 ? 'MAT' : 'SVC';
    return '$prefix${(p.id ?? 0).toString().padLeft(6, '0')}';
  }

  void _toggleProductSelection(Product product) {
    final selected = ref.read(selectedProductsPrintProvider);
    final idx = selected.indexWhere((e) => e.product.id == product.id);
    if (idx >= 0) {
      ref
          .read(selectedProductsPrintProvider.notifier)
          .set([...selected.sublist(0, idx), ...selected.sublist(idx + 1)]);
    } else {
      ref
          .read(selectedProductsPrintProvider.notifier)
          .set([...selected, ProductPrintItem(product: product)]);
    }
  }

  void _selectAllInCategory(List<Product> filteredProducts) {
    final currentSelected = ref.read(selectedProductsPrintProvider);
    final currentIds = currentSelected.map((e) => e.product.id).toSet();
    final newItems = filteredProducts
        .where((p) => !currentIds.contains(p.id))
        .map((p) => ProductPrintItem(product: p))
        .toList();

    if (newItems.isNotEmpty) {
      ref
          .read(selectedProductsPrintProvider.notifier)
          .set([...currentSelected, ...newItems]);
    }
  }

  void _clearSelection() {
    ref.read(selectedProductsPrintProvider.notifier).set([]);
  }

  Future<void> _downloadSelectedBarcodes() async {
    final selectedItems = ref.read(selectedProductsPrintProvider);
    if (selectedItems.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Pilih minimal 1 layanan'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
      return;
    }

    final size = _barcodeSizes[_selectedSizeIndex];

    try {
      if (selectedItems.length == 1) {
        final product = selectedItems.first.product;
        final svg = _buildBarcodeSvg(product, size);
        final fileName = '${_safeFileName(product.name)}_barcode.svg';
        await _saveBytes(
          bytes: utf8.encode(svg),
          fileName: fileName,
          dialogTitle: 'Simpan Barcode',
          type: FileType.custom,
          allowedExtensions: const ['svg'],
        );
      } else {
        final archive = Archive();
        for (final item in selectedItems) {
          final product = item.product;
          final svgBytes = utf8.encode(_buildBarcodeSvg(product, size));
          final fileName = '${_safeFileName(product.name)}_barcode.svg';
          archive.addFile(ArchiveFile(fileName, svgBytes.length, svgBytes));
        }

        final zipped = ZipEncoder().encode(archive);
        if (zipped == null) {
          throw Exception('Gagal membuat file ZIP.');
        }

        await _saveBytes(
          bytes: zipped,
          fileName:
              'barcode_layanan_${DateTime.now().millisecondsSinceEpoch}.zip',
          dialogTitle: 'Simpan Kumpulan Barcode',
          type: FileType.custom,
          allowedExtensions: const ['zip'],
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal menyimpan barcode: $e'),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
    }
  }

  Future<void> _printSelectedBarcodes() async {
    if (_printing) return;
    final selectedItems = ref.read(selectedProductsPrintProvider);
    if (selectedItems.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Pilih minimal 1 layanan'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
      return;
    }

    setState(() {
      _printing = true;
      _printStatus = 'Mengecek printer thermal...';
    });
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Mengecek printer thermal...'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        duration: Duration(seconds: 2),
      ),
    );
    try {
      final size = _barcodeSizes[_selectedSizeIndex];
      final settings = ref.read(labelSettingsProvider).copyWith(
            showName: true,
            showPrice: false,
            showSku: false,
            showBarcode: true,
            showStoreName: false,
            showDate: false,
            priceAlign: 'center',
            fontSize: 'normal',
            thermalBarcodeHeight: size.thermalBarcodeHeight,
            thermalBarcodeWidth: size.thermalBarcodeWidth,
          );
      final printItems = selectedItems
          .map(
            (item) => ProductPrintItem(
              product: item.product.copyWith(
                barcode: _effectiveBarcode(item.product),
              ),
              qty: item.qty,
            ),
          )
          .toList();
      final ok = await _printLabelsWithPrinterSetup(
        printItems,
        settings,
        onProgress: (message) {
          if (mounted) setState(() => _printStatus = message);
        },
      );
      if (!mounted) return;
      if (!ok) {
        setState(() {
          _printStatus = 'Pilih printer thermal untuk mulai mencetak barcode.';
        });
        return;
      }
      setState(() {
        _printStatus = 'Barcode berhasil dikirim ke printer.';
      });
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Barcode dikirim ke printer thermal.'),
          backgroundColor: Colors.green.shade700,
          behavior: SnackBarBehavior.floating,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          duration: const Duration(seconds: 3),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      final message = LabelPrintService.errorMessage(e);
      setState(() => _printStatus = message);
      if (LabelPrintService.isPrinterSetupError(e)) {
        ScaffoldMessenger.of(context).clearSnackBars();
        final picked = await _showBluetoothPrinterPicker(
          title: 'Pilih Printer Thermal',
          message:
              'Printer belum siap untuk mencetak barcode. Pilih printer yang sudah dipasangkan dengan HP.',
        );
        if (!mounted) return;
        setState(() {
          _printStatus = picked
              ? 'Printer dipilih. Tekan Print Thermal untuk mencetak.'
              : 'Printer belum dipilih.';
        });
        return;
      }
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          duration: const Duration(seconds: 3),
        ),
      );
    } finally {
      if (mounted) setState(() => _printing = false);
    }
  }

  Future<bool> _showBluetoothPrinterPicker({
    required String title,
    required String message,
  }) async {
    if (!Platform.isAndroid && !Platform.isIOS) return false;

    ScaffoldMessenger.of(context).clearSnackBars();
    await [Permission.bluetoothScan, Permission.bluetoothConnect].request();
    final bluetoothOn = await PrintBluetoothThermal.bluetoothEnabled;
    if (!bluetoothOn) {
      if (!mounted) return false;
      await _showBluetoothRequiredSheet();
      return false;
    }

    if (!mounted) return false;
    final navigator = Navigator.of(context);
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(color: AppColors.primaryBrand),
      ),
    );

    List<BluetoothInfo> printers = [];
    try {
      printers = await PrintBluetoothThermal.pairedBluetooths;
    } catch (_) {}
    if (!mounted) return false;
    navigator.pop();

    if (printers.isEmpty) {
      if (!mounted) return false;
      await showModalBottomSheet<void>(
        context: context,
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        builder: (ctx) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 18, 22, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 44,
                    height: 4,
                    color: const Color(0xFFE5E7EB),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Printer Belum Dipasangkan',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Pasangkan printer thermal di pengaturan Bluetooth HP, lalu kembali ke aplikasi dan coba cetak lagi.',
                  style: TextStyle(
                    fontSize: 13.5,
                    color: Color(0xFF475569),
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  height: 46,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryBrand,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero,
                      ),
                    ),
                    child: const Text(
                      'Mengerti',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
      return false;
    }

    final prefs = await SharedPreferences.getInstance();
    final savedMac = prefs.getString('struk_printerMac') ?? '';
    if (!mounted) return false;
    final selected = await showModalBottomSheet<BluetoothInfo>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 4,
                  color: const Color(0xFFE5E7EB),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                title,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 6),
              Text(
                message,
                style: const TextStyle(
                  fontSize: 13.5,
                  color: Color(0xFF475569),
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 16),
              Flexible(
                child: SingleChildScrollView(
                  child: Column(
                    children: printers.map((printer) {
                      final isSaved = printer.macAdress == savedMac;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: InkWell(
                          onTap: () => Navigator.pop(ctx, printer),
                          child: Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: isSaved
                                  ? AppColors.primaryBrand
                                      .withValues(alpha: 0.08)
                                  : const Color(0xFFF8FAFC),
                              border: Border.all(
                                color: isSaved
                                    ? AppColors.primaryBrand
                                    : const Color(0xFFE2E8F0),
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 42,
                                  height: 42,
                                  color: AppColors.primaryBrand
                                      .withValues(alpha: 0.10),
                                  child: const Icon(
                                    Icons.print_rounded,
                                    color: AppColors.primaryBrand,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        printer.name,
                                        style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w800,
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        printer.macAdress,
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: Color(0xFF64748B),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (isSaved)
                                  const Padding(
                                    padding: EdgeInsets.only(right: 8),
                                    child: Text(
                                      'Terakhir',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: AppColors.primaryBrand,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ),
                                const Icon(Icons.chevron_right_rounded,
                                    color: Color(0xFF94A3B8)),
                              ],
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );

    if (selected == null) return false;
    await prefs.setString('struk_printerMac', selected.macAdress);
    await prefs.setString('struk_printerName', selected.name);
    return true;
  }

  Future<void> _showBluetoothRequiredSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 4,
                  color: const Color(0xFFE5E7EB),
                ),
              ),
              const SizedBox(height: 18),
              const Row(
                children: [
                  Icon(Icons.bluetooth_disabled_rounded,
                      color: AppColors.danger),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Bluetooth Belum Aktif',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'Aktifkan Bluetooth di HP terlebih dahulu. Setelah aktif, tekan Print Thermal lagi untuk memilih printer.',
                style: TextStyle(
                  fontSize: 13.5,
                  color: Color(0xFF475569),
                  height: 1.45,
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                height: 46,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(ctx),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryBrand,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero,
                    ),
                  ),
                  child: const Text(
                    'Saya Aktifkan Dulu',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _printLabelsWithPrinterSetup(
      List<ProductPrintItem> printItems, LabelSettings settings,
      {LabelPrintProgress? onProgress}) async {
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      onProgress?.call('Mengecek printer desktop tersimpan...');
      final prefs = await SharedPreferences.getInstance();
      final savedPrinter = prefs.getString('desktop_printerName') ?? '';
      if (savedPrinter.isEmpty || savedPrinter == 'Belum dipilih') {
        if (!mounted) return false;
        onProgress?.call('Pilih printer thermal desktop...');
        final targetPrinter = await Printing.pickPrinter(context: context);
        if (targetPrinter == null) {
          throw const LabelPrintException('Printer desktop belum dipilih.');
        }
        await prefs.setString('desktop_printerName', targetPrinter.name);
        onProgress?.call('Printer dipilih: ${targetPrinter.name}');
      }
    }
    String? bluetoothMac;
    if (Platform.isAndroid || Platform.isIOS) {
      final prefs = await SharedPreferences.getInstance();
      bluetoothMac = prefs.getString('struk_printerMac') ?? '';
      if (bluetoothMac.isEmpty) {
        onProgress?.call('Pilih printer thermal...');
        final picked = await _showBluetoothPrinterPicker(
          title: 'Pilih Printer Thermal',
          message:
              'Pilih printer bluetooth yang akan dipakai untuk mencetak barcode layanan.',
        );
        if (!picked) return false;
        bluetoothMac = prefs.getString('struk_printerMac') ?? '';
      }

      try {
        await LabelPrintService.ensureBluetoothConnected(
          macPrinterAddress: bluetoothMac,
          onProgress: onProgress,
        );
      } catch (_) {
        onProgress?.call('Printer belum siap. Pilih ulang printer thermal.');
        final picked = await _showBluetoothPrinterPicker(
          title: 'Pilih Ulang Printer Thermal',
          message:
              'Printer tersimpan tidak merespon. Pilih printer yang sedang menyala dan berada dekat dengan kasir.',
        );
        if (!picked) return false;
        bluetoothMac = prefs.getString('struk_printerMac') ?? '';
      }
    }
    return LabelPrintService.printAdvancedLabels(
      printItems,
      settings,
      onProgress: onProgress,
      bluetoothMacAddress: bluetoothMac,
    );
  }

  Future<void> _saveBytes({
    required List<int> bytes,
    required String fileName,
    required String dialogTitle,
    required FileType type,
    List<String>? allowedExtensions,
  }) async {
    final outputPath = await FilePicker.platform.saveFile(
      dialogTitle: dialogTitle,
      fileName: fileName,
      type: type,
      allowedExtensions: allowedExtensions,
      bytes: Platform.isAndroid || Platform.isIOS
          ? Uint8List.fromList(bytes)
          : null,
    );

    if (outputPath == null) return;

    if (!Platform.isAndroid && !Platform.isIOS) {
      await File(outputPath).writeAsBytes(bytes);
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Barcode disimpan ke: $outputPath',
            maxLines: 2, overflow: TextOverflow.ellipsis),
        backgroundColor: Colors.green.shade700,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ),
    );
  }

  String _buildBarcodeSvg(Product product, _BarcodeDownloadSize size) {
    final code = _effectiveBarcode(product);
    final safeName = _escapeXml(product.name);
    final width = size.width;
    final height = size.height + 42;
    final barcodeBody = barcode.Barcode.code128().toSvg(
      code,
      x: 16,
      y: 42,
      width: width - 32,
      height: size.height - 18,
      drawText: true,
      fontFamily: 'monospace',
      fontHeight: 14,
      fullSvg: false,
    );

    return '''
<svg viewBox="0 0 $width $height" width="$width" height="$height" xmlns="http://www.w3.org/2000/svg">
  <rect x="0" y="0" width="$width" height="$height" fill="#ffffff"/>
  <text x="${width / 2}" y="24" text-anchor="middle" font-family="Arial, sans-serif" font-size="16" font-weight="700" fill="#111827">$safeName</text>
  $barcodeBody
</svg>
''';
  }

  String _safeFileName(String value) {
    final cleaned = value
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
        .replaceAll(RegExp(r'_+'), '_')
        .replaceAll(RegExp(r'^_|_$'), '');
    return cleaned.isEmpty ? 'layanan' : cleaned;
  }

  String _escapeXml(String value) {
    return value
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&apos;');
  }

  String _fmtNumber(int number) {
    final s = number.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productsProvider);
    final categories = ref.watch(categoriesProvider);
    final selectedItems = ref.watch(selectedProductsPrintProvider);
    final filteredProducts = _getFilteredProducts(products);
    final selectedProduct =
        selectedItems.isNotEmpty ? selectedItems.first.product : null;
    final size = _barcodeSizes[_selectedSizeIndex];

    final isWide = MediaQuery.of(context).size.shortestSide >= 600 ||
        MediaQuery.of(context).orientation == Orientation.landscape;

    final leftPanel = Container(
      color: Colors.white,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: _searchCtrl,
                  onChanged: (v) => setState(() => _searchQuery = v),
                  decoration: InputDecoration(
                    hintText: 'Cari layanan, SKU, atau barcode...',
                    prefixIcon: const Icon(Icons.search, color: Colors.grey),
                    filled: true,
                    fillColor: AppColors.surfaceDim,
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                    border: const OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide.none),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.close, size: 18),
                            onPressed: () {
                              _searchCtrl.clear();
                              setState(() => _searchQuery = '');
                            },
                          )
                        : null,
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 36,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _buildCategoryChip(0, 'Semua Kategori'),
                      ...categories.map(
                          (c) => _buildCategoryChip(c.id ?? -1, c.name ?? '-')),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${filteredProducts.length} layanan tersedia',
                        style: const TextStyle(
                          fontSize: 13,
                          color: Colors.black87,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    if (selectedItems.isNotEmpty)
                      TextButton(
                        onPressed: _clearSelection,
                        child: const Text('Bersihkan',
                            style: TextStyle(fontSize: 12)),
                      ),
                    TextButton.icon(
                      onPressed: filteredProducts.isEmpty
                          ? null
                          : () => _selectAllInCategory(filteredProducts),
                      icon: const Icon(Icons.checklist, size: 16),
                      label: const Text('Pilih Semua',
                          style: TextStyle(fontSize: 12)),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        minimumSize: Size.zero,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: filteredProducts.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                final p = filteredProducts[i];
                final isSelected =
                    selectedItems.any((e) => e.product.id == p.id);
                final code = _effectiveBarcode(p);

                return Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: isSelected
                          ? AppColors.primaryBrand
                          : Colors.grey.shade200,
                    ),
                    color: isSelected ? AppColors.brandLight : Colors.white,
                  ),
                  child: ListTile(
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    leading: Checkbox(
                      value: isSelected,
                      activeColor: AppColors.primaryBrand,
                      onChanged: (_) => _toggleProductSelection(p),
                    ),
                    title: Text(
                      p.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 14),
                    ),
                    subtitle: Text(
                      '$code  |  Rp ${_fmtNumber(p.sellPrice)}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style:
                          TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    ),
                    trailing: IconButton(
                      tooltip: 'Download',
                      onPressed: () async {
                        ref
                            .read(selectedProductsPrintProvider.notifier)
                            .set([ProductPrintItem(product: p)]);
                        await _downloadSelectedBarcodes();
                      },
                      icon: const Icon(Icons.download_rounded,
                          color: AppColors.primaryBrand),
                    ),
                    onTap: () => _toggleProductSelection(p),
                  ),
                );
              },
            ),
          ),
          if (!isWide) _buildDownloadActionBar(selectedItems),
        ],
      ),
    );

    final rightPanel = Container(
      color: AppColors.background,
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('Preview Barcode',
                      style:
                          TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  const SizedBox(height: 12),
                  Center(
                    child: _BarcodePreviewCard(
                      product: selectedProduct,
                      barcodeValue: selectedProduct == null
                          ? 'SVC000001'
                          : _effectiveBarcode(selectedProduct),
                      size: size,
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text('Ukuran Barcode',
                      style:
                          TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(16),
                    color: Colors.white,
                    child: Row(
                      children: List.generate(_barcodeSizes.length, (i) {
                        final item = _barcodeSizes[i];
                        final selected = i == _selectedSizeIndex;
                        return Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(
                                right: i == _barcodeSizes.length - 1 ? 0 : 8),
                            child: InkWell(
                              onTap: () =>
                                  setState(() => _selectedSizeIndex = i),
                              child: Container(
                                height: 52,
                                decoration: BoxDecoration(
                                  color: selected
                                      ? AppColors.primaryBrand
                                      : AppColors.surfaceDim,
                                  border: Border.all(
                                      color: selected
                                          ? AppColors.primaryBrand
                                          : Colors.grey.shade300),
                                ),
                                alignment: Alignment.center,
                                child: Text(
                                  item.label,
                                  style: TextStyle(
                                    color: selected
                                        ? Colors.white
                                        : AppColors.primaryBrand,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                  ),
                ],
              ),
            ),
          ),
          _buildDownloadActionBar(selectedItems),
        ],
      ),
    );

    return KasirResponsiveScaffold(
      title: 'Download Barcode',
      showNavRail: false,
      body: isWide
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(flex: 6, child: leftPanel),
                Container(width: 1, color: const Color(0xFFEEEEEE)),
                Expanded(flex: 4, child: rightPanel),
              ],
            )
          : DefaultTabController(
              length: 2,
              child: Column(
                children: [
                  const TabBar(
                    indicatorColor: AppColors.primaryBrand,
                    labelColor: AppColors.primaryBrand,
                    unselectedLabelColor: Colors.grey,
                    tabs: [
                      Tab(text: 'Pilih Layanan'),
                      Tab(text: 'Preview'),
                    ],
                  ),
                  Expanded(
                    child: TabBarView(
                      children: [
                        leftPanel,
                        rightPanel,
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildDownloadActionBar(List<ProductPrintItem> selectedItems) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            offset: const Offset(0, -2),
            blurRadius: 10,
          )
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Dipilih:',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
              Text(
                '${selectedItems.length} layanan',
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_printStatus != null) ...[
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: _printing
                    ? const Color(0xFFEFF6FF)
                    : const Color(0xFFF8FAFC),
                border: Border.all(color: const Color(0xFFCBD5E1)),
                borderRadius: BorderRadius.zero,
              ),
              child: Row(
                children: [
                  if (_printing)
                    const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: AppColors.primaryBrand,
                      ),
                    )
                  else
                    const Icon(Icons.info_outline_rounded,
                        size: 17, color: Color(0xFF64748B)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _printStatus!,
                      style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF334155),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: selectedItems.isEmpty || _printing
                  ? null
                  : _printSelectedBarcodes,
              icon: _printing
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.print_rounded, size: 20),
              label: Text(
                _printing ? 'Mencetak...' : 'Print Thermal',
                style:
                    const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primaryBrand,
                side: const BorderSide(color: AppColors.primaryBrand),
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
                disabledForegroundColor: Colors.grey.shade500,
              ),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed:
                  selectedItems.isEmpty ? null : _downloadSelectedBarcodes,
              icon: const Icon(Icons.download_rounded, size: 20),
              label: Text(
                selectedItems.length > 1
                    ? 'Download ZIP Barcode'
                    : 'Download Barcode',
                style:
                    const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBrand,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
                elevation: 0,
                disabledBackgroundColor: Colors.grey.shade300,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryChip(int id, String label) {
    final isSelected = _selectedCategory == id;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        selected: isSelected,
        label: Text(label),
        labelStyle: TextStyle(
          color: isSelected ? Colors.white : Colors.black87,
          fontSize: 13,
          fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
        ),
        selectedColor: AppColors.primaryBrand,
        backgroundColor: Colors.white,
        side: BorderSide(
            color: isSelected ? AppColors.primaryBrand : Colors.grey.shade300),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        onSelected: (_) => setState(() => _selectedCategory = id),
      ),
    );
  }
}

class _BarcodePreviewCard extends StatelessWidget {
  final Product? product;
  final String barcodeValue;
  final _BarcodeDownloadSize size;

  const _BarcodePreviewCard({
    required this.product,
    required this.barcodeValue,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    final scale = size.width > 360 ? 0.74 : 0.9;
    final width = size.width * scale;
    return Container(
      width: width,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 8,
            offset: const Offset(0, 3),
          )
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            product?.name ?? 'Nama Layanan',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 10),
          barcode_widget.BarcodeWidget(
            barcode: barcode_widget.Barcode.code128(),
            data: barcodeValue,
            width: width - 28,
            height: 64,
            drawText: false,
            errorBuilder: (_, __) => const Text(
              'Barcode Invalid',
              style: TextStyle(color: AppColors.danger, fontSize: 11),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            barcodeValue,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 11,
              letterSpacing: 2,
              fontWeight: FontWeight.w800,
              color: Color(0xFF111827),
            ),
          ),
        ],
      ),
    );
  }
}

