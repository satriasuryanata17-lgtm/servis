import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/providers.dart';
import '../services/export_service.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';
import '../widgets/export_dropdown.dart';

const Color _kBrand = AppColors.primaryBrand;

class MasaBerlakuProdukScreen extends ConsumerStatefulWidget {
  const MasaBerlakuProdukScreen({super.key});

  @override
  ConsumerState<MasaBerlakuProdukScreen> createState() =>
      _MasaBerlakuProdukScreenState();
}

class _MasaBerlakuProdukScreenState
    extends ConsumerState<MasaBerlakuProdukScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this, initialIndex: 0);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _exportData() async {
    final choice = await ExportDropdown.show(context);
    if (choice == null) return;

    final allProducts = ref.read(productsProvider);
    if (!mounted) return;

    final now = DateTime.now();
    int expired = 0;
    int soon = 0;
    int normal = 0;

    final rows = allProducts
        .where((p) => p.expiryDate != null)
        .map((p) {
          final exp = DateTime.tryParse(p.expiryDate!);
          if (exp == null) return null;
          final diff = exp.difference(now).inDays;
          String status = 'Normal';
          if (diff < 0) {
            status = 'Kedaluwarsa';
            expired++;
          } else if (diff <= 30) {
            status = 'Segera Habis';
            soon++;
          } else {
            normal++;
          }
          return [
            p.name,
            '${exp.day}/${exp.month}/${exp.year}',
            status,
            diff < 0 ? '${diff.abs()} hari lalu' : '$diff hari lagi',
          ];
        })
        .whereType<List<Object?>>()
        .toList();

    final Map<String, String> summaryData = {
      'Total Item': '${rows.length} Item',
      'Sudah Kedaluwarsa': '$expired Item',
      'Segera Habis': '$soon Item',
      'Masa Berlaku Aman': '$normal Item',
    };

    const title = 'Laporan Masa Berlaku Item';

    try {
      if (choice == 'csv') {
        await ExportService.exportAndShareCsv(
          filePrefix: 'masa_berlaku_produk',
          headers: ['Nama Item', 'Tanggal Exp', 'Status', 'Sisa Hari'],
          rows: rows,
          subject: 'Ekspor Masa Berlaku Produk',
        );
      } else if (choice == 'pdf') {
        await ExportService.exportPdfLaporan(
          title: title,
          headers: ['Nama Item', 'Tanggal Exp', 'Status', 'Keterangan'],
          rows: rows,
          summaryData: summaryData,
        );
      } else if (choice == 'print') {
        await ExportService.printPdfLaporan(
          title: title,
          headers: ['Nama Produk', 'Tanggal Exp', 'Status', 'Keterangan'],
          rows: rows,
          summaryData: summaryData,
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Gagal mengekspor laporan. Silakan coba lagi.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final tablet = isTabletDevice(context);
    final landscape = isLandscape(context);

    return KasirResponsiveScaffold(
      title: 'Masa Berlaku Item',
      showNavRail: false,
      backgroundColor: Colors.white,
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: GestureDetector(
            onTap: _exportData,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: const BoxDecoration(
                color: AppColors.primaryBrand,
                borderRadius: BorderRadius.zero,
              ),
              child: const Row(
                children: [
                  Icon(Icons.download_rounded, color: Colors.white, size: 15),
                  SizedBox(width: 5),
                  Text(
                    'Ekspor',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
      body: Column(
        children: [
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(
                horizontal: tablet ? 24 : 16, vertical: tablet ? 12 : 10),
            color: const Color(0xFFFFF3E0),
            child: Row(
              children: [
                const Icon(Icons.info_outline_rounded,
                    size: 16, color: Color(0xFFE65100)),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Masa berlaku item hanya tersedia untuk produk dengan manajemen stok & tanggal kedaluwarsa aktif.',
                    style: TextStyle(
                        fontSize: tablet ? 13 : 12.5, color: Colors.black87),
                  ),
                ),
              ],
            ),
          ),
          Container(
            color: Colors.white,
            child: TabBar(
              controller: _tabController,
              labelColor: _kBrand,
              unselectedLabelColor: Colors.black54,
              labelStyle: TextStyle(
                  fontWeight: FontWeight.w600, fontSize: tablet ? 14 : 13),
              indicatorColor: _kBrand,
              indicatorWeight: 3,
              padding: EdgeInsets.symmetric(horizontal: tablet ? 16 : 0),
              tabs: const [
                Tab(text: 'Segera Habis'),
                Tab(text: 'Normal'),
                Tab(text: 'Sudah Kedaluwarsa'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _ProductExpTab(
                    filter: 'soon', tablet: tablet, landscape: landscape),
                _ProductExpTab(
                    filter: 'normal', tablet: tablet, landscape: landscape),
                _ProductExpTab(
                    filter: 'expired', tablet: tablet, landscape: landscape),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

//  TAB CONTENT product expiry list

class _ProductExpTab extends ConsumerWidget {
  final String filter; // 'soon' | 'normal' | 'expired'
  final bool tablet;
  final bool landscape;

  const _ProductExpTab({
    required this.filter,
    required this.tablet,
    required this.landscape,
  });

  Color get _statusColor {
    switch (filter) {
      case 'expired':
        return const Color(0xFFD32F2F);
      case 'soon':
        return const Color(0xFFE65100);
      default:
        return const Color(0xFF2E7D32);
    }
  }

  String get _emptyMsg {
    switch (filter) {
      case 'expired':
        return 'Tidak ada item\nyang sudah kedaluwarsa.';
      case 'soon':
        return 'Tidak ada item\nyang hampir kedaluwarsa.';
      default:
        return 'Tidak ada item\ndengan masa berlaku normal.';
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Provider should expose expiry-filtered products
    // For now we pass the filter label through and expect the provider
    // to handle the filtering.
    final allProducts = ref.watch(productsProvider);

    // Filter logic (simplified adjust to real expiry field)
    final now = DateTime.now();
    final filtered = allProducts.where((p) {
      if (p.expiryDate == null) return false;
      final exp = DateTime.tryParse(p.expiryDate!);
      if (exp == null) return false;
      final diff = exp.difference(now).inDays;
      switch (filter) {
        case 'expired':
          return diff < 0;
        case 'soon':
          return diff >= 0 && diff <= 30;
        default:
          return diff > 30;
      }
    }).toList();

    if (filtered.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: _statusColor.withValues(alpha: 0.08),
                shape: BoxShape.rectangle,
              ),
              child: Icon(Icons.event_available_rounded,
                  color: _statusColor, size: tablet ? 48 : 40),
            ),
            const SizedBox(height: 16),
            Text(
              _emptyMsg,
              textAlign: TextAlign.center,
              style:
                  TextStyle(color: Colors.black45, fontSize: tablet ? 15 : 14),
            ),
          ],
        ),
      );
    }

    // Landscape or Tablet 2-column grid
    final useTwoCol = tablet || landscape;

    return Padding(
      padding: EdgeInsets.all(tablet ? 20 : 12),
      child: useTwoCol
          ? GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: tablet ? 3.2 : 2.5,
              ),
              itemCount: filtered.length,
              itemBuilder: (_, i) => _ProductExpCard(
                  product: filtered[i],
                  statusColor: _statusColor,
                  tablet: tablet),
            )
          : ListView.separated(
              itemCount: filtered.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) => _ProductExpCard(
                  product: filtered[i],
                  statusColor: _statusColor,
                  tablet: tablet),
            ),
    );
  }
}

class _ProductExpCard extends StatelessWidget {
  final dynamic product; // Product model
  final Color statusColor;
  final bool tablet;

  const _ProductExpCard({
    required this.product,
    required this.statusColor,
    required this.tablet,
  });

  @override
  Widget build(BuildContext context) {
    final exp = product.expiryDate != null
        ? DateTime.tryParse(product.expiryDate!)
        : null;
    final diff = exp?.difference(DateTime.now()).inDays;

    String expLabel =
        exp != null ? '${exp.day}/${exp.month}/${exp.year}' : 'Tidak diketahui';
    String daysLabel = diff != null
        ? diff < 0
            ? '${diff.abs()} hari lalu'
            : '$diff hari lagi'
        : '-';

    return Container(
      padding: EdgeInsets.all(tablet ? 16 : 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: statusColor.withValues(alpha: 0.3), width: 1),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 6,
              offset: const Offset(0, 2)),
        ],
      ),
      child: Row(
        children: [
          // Product image / icon
          Container(
            width: tablet ? 52 : 44,
            height: tablet ? 52 : 44,
            decoration: BoxDecoration(
              color: statusColor.withValues(alpha: 0.08),
              borderRadius: BorderRadius.zero,
            ),
            child: product.imageUrl != null && product.imageUrl!.isNotEmpty
                ? ClipRRect(
                    borderRadius: BorderRadius.zero,
                    child: Image.file(File(product.imageUrl!),
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Icon(
                            Icons.inventory_2_outlined,
                            color: statusColor,
                            size: 24)))
                : Icon(Icons.inventory_2_outlined,
                    color: statusColor, size: tablet ? 26 : 22),
          ),
          SizedBox(width: tablet ? 14 : 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(product.name ?? '-',
                    style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: tablet ? 15 : 14,
                        color: Colors.black87),
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Row(
                  children: [
                    const Icon(Icons.event_rounded,
                        size: 12, color: Colors.black45),
                    const SizedBox(width: 4),
                    Text(expLabel,
                        style: const TextStyle(
                            fontSize: 12, color: Colors.black45)),
                  ],
                ),
              ],
            ),
          ),
          // Days badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: statusColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.zero,
            ),
            child: Text(daysLabel,
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: statusColor)),
          ),
        ],
      ),
    );
  }
}

