import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../utils/currency_input_formatter.dart';
import '../widgets/custom_components.dart';
import 'struk_screen.dart';
import 'checkout_screen.dart';

String _fK(int n) {
  if (n == 0) return '0';
  String s = n.toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return r;
}

class KeranjangScreen extends ConsumerStatefulWidget {
  const KeranjangScreen({super.key});

  @override
  ConsumerState<KeranjangScreen> createState() => _KeranjangScreenState();
}

class _KeranjangScreenState extends ConsumerState<KeranjangScreen> {
  Customer? _selectedCustomer;
  int _discountAmount = 0;
  String? _note;

  void _showStockLimitAlert(Product p) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.info_outline_rounded,
                color: Colors.white, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                p.stock <= 0
                    ? 'Stok ${p.name} habis'
                    : 'Stok ${p.name} terbatas, hanya tersedia ${p.stock} ${p.unit}',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
              ),
            ),
          ],
        ),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 280),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showCustomerPicker() {
    final customers = ref.read(customersProvider);
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Container(
        constraints:
            BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.6),
        decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero)),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
                child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.zero))),
            const SizedBox(height: 16),
            const Text('Pilih Pelanggan',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            // Umum option
            ListTile(
              leading: Container(
                width: 40,
                height: 40,
                decoration: const BoxDecoration(
                    color: Color(0xFFEEF2F7), shape: BoxShape.rectangle),
                child: const Icon(Icons.person_outline_rounded,
                    color: Colors.grey),
              ),
              title: const Text('Umum (Tanpa Pelanggan)',
                  style: TextStyle(fontWeight: FontWeight.w600)),
              selected: _selectedCustomer == null,
              onTap: () {
                setState(() => _selectedCustomer = null);
                Navigator.pop(ctx);
              },
            ),
            const Divider(),
            if (customers.isEmpty)
              const Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                    'Belum ada pelanggan.\nTambahkan di menu Pelanggan.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey)),
              )
            else
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: customers.length,
                  itemBuilder: (_, i) {
                    final c = customers[i];
                    return ListTile(
                      leading: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                            color:
                                const Color(0xFF1E465B).withValues(alpha: 0.12),
                            shape: BoxShape.rectangle),
                        child: Center(
                            child: Text(
                                c.name.isNotEmpty
                                    ? c.name[0].toUpperCase()
                                    : '?',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: Color(0xFF1E465B)))),
                      ),
                      title: Text(c.name,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: c.phone != null
                          ? Text(c.phone!,
                              style: const TextStyle(
                                  fontSize: 12, color: Colors.grey))
                          : null,
                      selected: _selectedCustomer?.id == c.id,
                      onTap: () {
                        setState(() => _selectedCustomer = c);
                        Navigator.pop(ctx);
                      },
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ignore: unused_element
  void _showPaymentSheet() {
    final cart = ref.read(cartProvider);
    final totalBelanja = ref.read(cartProvider.notifier).totalBelanja;
    final grandTotal = (totalBelanja - _discountAmount).clamp(0, totalBelanja);
    String paymentMethod = 'cash';
    final amountCtrl =
        TextEditingController(text: formatCurrencyInput(grandTotal));
    int change = 0;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setB) => Padding(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: Container(
            decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.zero)),
            padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(
                    child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                            color: Colors.grey[300],
                            borderRadius: BorderRadius.zero))),
                const SizedBox(height: 16),
                const Text('Pembayaran',
                    style:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text('Total: Rp ${_fK(grandTotal)}',
                    style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF1E465B))),
                const SizedBox(height: 20),

                // Payment method buttons
                Row(
                  children: [
                    _PayBtn(
                        icon: Icons.payments_rounded,
                        label: 'Tunai',
                        color: const Color(0xFF059669),
                        active: paymentMethod == 'cash',
                        onTap: () => setB(() => paymentMethod = 'cash')),
                    const SizedBox(width: 10),
                    _PayBtn(
                        icon: Icons.qr_code_rounded,
                        label: 'QRIS',
                        color: const Color(0xFF7C3AED),
                        active: paymentMethod == 'qris',
                        onTap: () => setB(() {
                              paymentMethod = 'qris';
                              amountCtrl.text = formatCurrencyInput(grandTotal);
                              change = 0;
                            })),
                    const SizedBox(width: 10),
                    _PayBtn(
                        icon: Icons.account_balance_rounded,
                        label: 'Transfer',
                        color: const Color(0xFF2563EB),
                        active: paymentMethod == 'transfer',
                        onTap: () => setB(() {
                              paymentMethod = 'transfer';
                              amountCtrl.text = formatCurrencyInput(grandTotal);
                              change = 0;
                            })),
                  ],
                ),
                const SizedBox(height: 20),

                // Amount paid (only for cash)
                if (paymentMethod == 'cash') ...[
                  const Align(
                      alignment: Alignment.centerLeft,
                      child: Text('Uang Diterima (Rp)',
                          style: TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 14))),
                  const SizedBox(height: 8),
                  TextField(
                    controller: amountCtrl,
                    keyboardType: TextInputType.number,
                    inputFormatters: const [CurrencyInputFormatter()],
                    style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF1E465B)),
                    textAlign: TextAlign.center,
                    decoration: const InputDecoration(
                      filled: true,
                      fillColor: Color(0xFFF4F7FC),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.zero,
                          borderSide: BorderSide.none),
                      contentPadding: EdgeInsets.symmetric(vertical: 16),
                    ),
                    onChanged: (v) {
                      final paid = parseCurrencyInput(v);
                      setB(() {
                        change = paid - grandTotal;
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  // Quick amounts
                  Wrap(
                    spacing: 8,
                    children: [grandTotal, 50000, 100000, 200000].map((a) {
                      return ActionChip(
                        label: Text('Rp ${_fK(a)}',
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: a == grandTotal
                                    ? Colors.white
                                    : const Color(0xFF1E465B))),
                        backgroundColor: a == grandTotal
                            ? const Color(0xFF1E465B)
                            : const Color(0xFFEEF2F7),
                        onPressed: () {
                          amountCtrl.text = formatCurrencyInput(a);
                          setB(() {
                            change = a - grandTotal;
                          });
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 12),
                  if (change >= 0)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                      decoration: const BoxDecoration(
                        color: Color(0xFFE8F6F4),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Kembalian',
                              style: TextStyle(fontWeight: FontWeight.w700)),
                          Text('Rp ${_fK(change)}',
                              style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w800,
                                  color: Color(0xFF059669))),
                        ],
                      ),
                    ),
                ],

                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1E465B),
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    onPressed: () async {
                      final paid = parseCurrencyInput(amountCtrl.text);
                      if (paymentMethod == 'cash' && paid < grandTotal) {
                        ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                            content: Text('Uang diterima kurang!'),
                            backgroundColor: Colors.black87,
                            behavior: SnackBarBehavior.floating,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero)));
                        return;
                      }
                      Navigator.pop(ctx); // close sheet
                      _processPayment(cart, paymentMethod, paid);
                    },
                    child: const Text('Konfirmasi Bayar',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _processPayment(
      Map<Product, double> cart, String method, int amountPaid) async {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(
            child: CircularProgressIndicator(color: Color(0xFF1E465B))));

    try {
      final txId =
          await ref.read(transactionsProvider.notifier).createTransaction(
                cartItems: cart,
                customer: _selectedCustomer,
                discountAmount: _discountAmount,
                paymentMethod: method,
                amountPaid: amountPaid,
                note: _note,
              );

      ref.read(cartProvider.notifier).clearCart();
      if (mounted) {
        Navigator.pop(context); // close loading
        HapticFeedback.heavyImpact();
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (_) =>
                    StrukScreen(transactionId: txId, isAfterPayment: true)));
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Terjadi kesalahan. Silakan coba lagi.'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final cart = ref.watch(cartProvider);
    final cn = ref.read(cartProvider.notifier);
    final totalBelanja = cn.totalBelanja;
    final grandTotal = (totalBelanja - _discountAmount).clamp(0, totalBelanja);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 10),
              child: JuraganServisHeader(),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: const Icon(Icons.arrow_back_ios_new_rounded,
                            size: 22, color: Colors.black87),
                      ),
                      const SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Keranjang',
                              style: AppText.h1.copyWith(
                                  fontSize: 24, fontWeight: FontWeight.bold)),
                          Text('${cn.totalItems} item',
                              style: const TextStyle(
                                  color: Colors.grey,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ],
                  ),
                  if (cart.isNotEmpty)
                    TextButton(
                      style: TextButton.styleFrom(
                        backgroundColor: const Color(0xFFFBECEC),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      onPressed: () =>
                          ref.read(cartProvider.notifier).clearCart(),
                      child: const Text('Hapus Semua',
                          style: TextStyle(
                              color: Colors.red,
                              fontWeight: FontWeight.bold,
                              fontSize: 13)),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Table Header
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: DefaultTextStyle(
                style: TextStyle(
                    fontWeight: FontWeight.w800,
                    color: Colors.black87,
                    fontSize: 13),
                child: Row(
                  children: [
                    Expanded(flex: 3, child: Text('Item')),
                    Expanded(
                        flex: 2,
                        child: Text('Qty', textAlign: TextAlign.center)),
                    Expanded(
                        flex: 2,
                        child: Text('Harga', textAlign: TextAlign.right)),
                    Expanded(
                        flex: 2,
                        child: Text('Subtotal', textAlign: TextAlign.right)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Divider(height: 1, color: AppColors.divider),

            Expanded(
              child: cart.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                              padding: const EdgeInsets.all(24),
                              decoration: const BoxDecoration(
                                  color: Color(0xFFE8F6F4),
                                  shape: BoxShape.rectangle),
                              child: const Icon(Icons.shopping_cart_outlined,
                                  color: Color(0xFF279B7C), size: 48)),
                          const SizedBox(height: 16),
                          const Text('Keranjang masih kosong',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.grey,
                                  fontSize: 16)),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: () => Navigator.pop(context),
                            style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF1E465B),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 24, vertical: 14),
                                elevation: 0,
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.zero)),
                            child: const Text('\u2190 Pilih Produk',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
                      itemCount: cart.entries.length,
                      separatorBuilder: (_, __) =>
                          const Divider(color: AppColors.divider),
                      itemBuilder: (_, i) {
                        final e = cart.entries.elementAt(i);
                        return _ItemRow(
                          product: e.key,
                          qty: e.value,
                          ref: ref,
                          onStockLimit: () => _showStockLimitAlert(e.key),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      bottomSheet: cart.isEmpty
          ? null
          : Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
              decoration: BoxDecoration(
                color: Colors.white,
                border: const Border(top: BorderSide(color: AppColors.divider)),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
                      blurRadius: 10,
                      offset: const Offset(0, -2))
                ],
              ),
              child: SafeArea(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Customer selector
                    GestureDetector(
                      onTap: _showCustomerPicker,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF4F7FC),
                          borderRadius: BorderRadius.zero,
                          border: Border.all(color: AppColors.divider),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(5),
                              decoration: const BoxDecoration(
                                  color: Color(0xFF1E465B),
                                  shape: BoxShape.rectangle),
                              child: const Icon(Icons.person_outline_rounded,
                                  color: Colors.white, size: 16),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                _selectedCustomer?.name ?? 'Pelanggan Umum',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: _selectedCustomer != null
                                        ? Colors.black87
                                        : Colors.grey),
                              ),
                            ),
                            const Icon(Icons.chevron_right_rounded,
                                color: Colors.grey, size: 20),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),

                    // Discount row
                    Row(
                      children: [
                        const Icon(Icons.discount_rounded,
                            color: Colors.orange, size: 18),
                        const SizedBox(width: 8),
                        const Text('Diskon:',
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 13)),
                        const SizedBox(width: 8),
                        Expanded(
                          child: SizedBox(
                            height: 32,
                            child: TextField(
                              keyboardType: TextInputType.number,
                              inputFormatters: const [CurrencyInputFormatter()],
                              style: const TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.w700),
                              decoration: const InputDecoration(
                                hintText: '0',
                                hintStyle: TextStyle(color: Colors.grey),
                                prefixText: 'Rp ',
                                prefixStyle: TextStyle(
                                    fontSize: 13, fontWeight: FontWeight.w600),
                                filled: true,
                                fillColor: Color(0xFFF4F7FC),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                    borderSide: BorderSide.none),
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 0),
                              ),
                              onChanged: (v) => setState(() =>
                                  _discountAmount = parseCurrencyInput(v)),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),

                    // Summary
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Total (${cn.totalItems} item)',
                            style: const TextStyle(
                                color: Colors.grey, fontSize: 13)),
                        Text('Rp ${_fK(totalBelanja)}',
                            style: const TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 14)),
                      ],
                    ),
                    if (_discountAmount > 0) ...[
                      const SizedBox(height: 2),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Diskon',
                              style: TextStyle(
                                  color: Colors.orange, fontSize: 13)),
                          Text('- Rp ${_fK(_discountAmount)}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                  color: Colors.orange)),
                        ],
                      ),
                    ],
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Grand Total',
                            style: TextStyle(
                                fontWeight: FontWeight.w800, fontSize: 15)),
                        Text('Rp ${_fK(grandTotal)}',
                            style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 18,
                                color: Color(0xFF1E465B))),
                      ],
                    ),
                    const SizedBox(height: 10),

                    // Pay button
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF1E465B),
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const CheckoutScreen()),
                          );
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Bayar Pesanan',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16)),
                            Text('Rp ${_fK(grandTotal)}',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 18)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}

class _ItemRow extends StatelessWidget {
  final Product product;
  final double qty;
  final WidgetRef ref;
  final VoidCallback onStockLimit;
  const _ItemRow(
      {required this.product,
      required this.qty,
      required this.ref,
      required this.onStockLimit});

  @override
  Widget build(BuildContext context) {
    final currentPrice = product.getPrice(qty);
    final isWholesale = currentPrice != product.sellPrice;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    if (product.isExtra == 1)
                      Container(
                        margin: const EdgeInsets.only(right: 6),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1E465B).withValues(alpha: 0.1),
                          borderRadius: BorderRadius.zero,
                          border: Border.all(
                              color: const Color(0xFF1E465B)
                                  .withValues(alpha: 0.2)),
                        ),
                        child: const Text('ADD ON',
                            style: TextStyle(
                                color: Color(0xFF1E465B),
                                fontSize: 9,
                                fontWeight: FontWeight.bold)),
                      ),
                    Expanded(
                      child: Text(product.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: Colors.black87),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    if (isWholesale)
                      Container(
                        margin: const EdgeInsets.only(right: 6),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 1),
                        decoration: const BoxDecoration(
                          color: Colors.orange,
                          borderRadius: BorderRadius.zero,
                        ),
                        child: const Text('GROSIR',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 8,
                                fontWeight: FontWeight.bold)),
                      ),
                    Text('Rp ${_fK(currentPrice)}/${product.unit}',
                        style: TextStyle(
                            color: isWholesale ? Colors.orange : Colors.grey,
                            fontSize: 11,
                            fontWeight: isWholesale
                                ? FontWeight.bold
                                : FontWeight.normal)),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _SmBtn(Icons.remove_rounded,
                    () => ref.read(cartProvider.notifier).removeItem(product)),
                SizedBox(
                    width: 32,
                    child: Center(
                        child: Text(
                            qty
                                .toStringAsFixed(1)
                                .replaceAll(RegExp(r'\.0$'), ''),
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 13)))),
                _SmBtn(Icons.add_rounded, () {
                  final success = ref
                      .read(cartProvider.notifier)
                      .addItem(product, qty: 1.0);
                  if (!success) {
                    onStockLimit();
                  }
                }),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(_fK(currentPrice),
                style: TextStyle(
                    color: isWholesale ? Colors.orange : Colors.grey,
                    fontSize: 13,
                    fontWeight: FontWeight.w600),
                textAlign: TextAlign.right),
          ),
          Expanded(
            flex: 2,
            child: Text(_fK((currentPrice * qty).round()),
                style: TextStyle(
                    color: isWholesale ? Colors.orange : Colors.black87,
                    fontWeight: FontWeight.w800,
                    fontSize: 14),
                textAlign: TextAlign.right),
          ),
        ],
      ),
    );
  }
}

class _SmBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _SmBtn(this.icon, this.onTap);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 24,
        height: 24,
        decoration: BoxDecoration(
          color: const Color(0xFFF4F7FC),
          borderRadius: BorderRadius.zero,
          border: Border.all(color: AppColors.divider),
        ),
        child: Icon(icon, size: 16, color: Colors.black87),
      ),
    );
  }
}

class _PayBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final bool active;
  final VoidCallback onTap;
  const _PayBtn(
      {required this.icon,
      required this.label,
      required this.color,
      required this.active,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: active
                ? color.withValues(alpha: 0.12)
                : const Color(0xFFF4F7FC),
            borderRadius: BorderRadius.zero,
            border: Border.all(
                color: active ? color : Colors.grey.withValues(alpha: 0.2),
                width: active ? 2 : 1),
          ),
          child: Column(
            children: [
              Icon(icon, color: active ? color : Colors.grey, size: 28),
              const SizedBox(height: 6),
              Text(label,
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                      color: active ? color : Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}

