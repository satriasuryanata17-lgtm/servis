import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../providers/providers.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';

const Color _kBrand = AppColors.primaryBrand;

//  PENGATURAN PROFIL SCREEN Responsive (Tablet / Landscape)

class PengaturanProfilScreen extends ConsumerStatefulWidget {
  const PengaturanProfilScreen({super.key});

  @override
  ConsumerState<PengaturanProfilScreen> createState() =>
      _PengaturanProfilScreenState();
}

class _PengaturanProfilScreenState
    extends ConsumerState<PengaturanProfilScreen> {
  final _namaCtrl = TextEditingController();
  File? _fotoFile;
  String? _savedFotoPath;
  bool _isSaving = false;
  bool _isLoading = true;
  ScaffoldMessengerState? _messenger;

  @override
  void initState() {
    super.initState();
    _loadProfil();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _messenger = ScaffoldMessenger.maybeOf(context);
  }

  @override
  void dispose() {
    _clearSnackbars();
    _namaCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfil() async {
    final profil = ref.read(profilProvider);
    if (mounted) {
      setState(() {
        _namaCtrl.text = profil.nama;
        _savedFotoPath = profil.fotoPath;
        if (_savedFotoPath != null && _savedFotoPath!.isNotEmpty) {
          final f = File(_savedFotoPath!);
          if (f.existsSync()) _fotoFile = f;
        }
        _isLoading = false;
      });
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(source: source, imageQuality: 85);
      if (picked != null && mounted) {
        setState(() => _fotoFile = File(picked.path));
      }
    } catch (_) {
      _snack(
          'Gagal mengakses ${source == ImageSource.camera ? 'kamera' : 'galeri'}');
    }
  }

  Future<void> _simpan() async {
    final nama = _namaCtrl.text.trim();
    if (nama.isEmpty) {
      _snack('Nama tidak boleh kosong');
      return;
    }
    setState(() => _isSaving = true);
    try {
      await ref.read(profilProvider.notifier).updateProfil(
            nama: nama,
            fotoPath: _fotoFile?.path ?? _savedFotoPath ?? '',
          );
      if (mounted) {
        _clearSnackbars();
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) _snack('Gagal menyimpan profil. Silakan coba lagi.');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _clearSnackbars() {
    _messenger?.clearSnackBars();
  }

  void _back() {
    _clearSnackbars();
    Navigator.maybePop(context);
  }

  void _snack(String msg) {
    final messenger = _messenger ?? ScaffoldMessenger.of(context);
    messenger.clearSnackBars();
    messenger.showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: Colors.black87,
      behavior: SnackBarBehavior.floating,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final tablet = isTabletDevice(context);
    final landscape = isLandscape(context);
    final useTwoCols = tablet || landscape;

    return KasirResponsiveScaffold(
      title: 'Pengaturan Profil',
      showNavRail: false,
      backgroundColor: tablet ? const Color(0xFFF5F7FA) : Colors.white,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
        onPressed: _back,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: _kBrand))
          : useTwoCols
              ? _buildTwoColumnLayout(context, tablet)
              : _buildSingleColumnLayout(context),
    );
  }

  Widget _buildTwoColumnLayout(BuildContext context, bool tablet) {
    return Column(
      children: [
        const Divider(height: 1, color: Color(0xFFEEEEEE)),
        Expanded(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(tablet ? 32 : 16),
            child: Center(
              child: ConstrainedBox(
                constraints:
                    BoxConstraints(maxWidth: tablet ? 720 : double.infinity),
                child: Card(
                  elevation: tablet ? 2 : 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                  color: Colors.white,
                  child: Padding(
                    padding: EdgeInsets.all(tablet ? 32 : 20),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildFotoPanel(tablet),
                        SizedBox(width: tablet ? 40 : 20),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              _sectionLabel('Informasi Profil'),
                              const SizedBox(height: 20),
                              _buildNamaField(tablet),
                              const SizedBox(height: 32),
                              _buildSimpanBtn(),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSingleColumnLayout(BuildContext context) {
    return Column(
      children: [
        const Divider(height: 1, color: Color(0xFFEEEEEE)),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 24, 16, 16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildFotoPanel(false),
                const SizedBox(width: 16),
                Expanded(child: _buildNamaField(false)),
              ],
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
          child: Column(
            children: [
              _buildSimpanBtn(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildFotoPanel(bool tablet) {
    final size = tablet ? 160.0 : 130.0;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: const Color(0xFFF0F2F5),
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFE0E0E0)),
          ),
          clipBehavior: Clip.antiAlias,
          child: _fotoFile != null
              ? Image.file(_fotoFile!, fit: BoxFit.cover)
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.person_outline_rounded,
                        size: tablet ? 40 : 32, color: Colors.black26),
                    const SizedBox(height: 6),
                    const Text('Foto Profil',
                        style: TextStyle(
                            fontSize: 12,
                            color: Colors.black38,
                            fontWeight: FontWeight.w400)),
                  ],
                ),
        ),
        if (!Platform.isWindows) ...[
          const SizedBox(height: 12),
          _outlineBtn(
            label: 'Kamera',
            icon: Icons.camera_alt_outlined,
            width: size,
            onTap: () => _pickImage(ImageSource.camera),
          ),
        ],
        const SizedBox(height: 8),
        _outlineBtn(
          label: Platform.isWindows ? 'Ganti Foto' : 'Galeri',
          icon: Icons.photo_library_outlined,
          width: size,
          onTap: () => _pickImage(ImageSource.gallery),
        ),
      ],
    );
  }

  Widget _buildNamaField(bool tablet) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Text('Nama',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.black87)),
            SizedBox(width: 3),
            Text('*',
                style: TextStyle(
                    color: AppColors.danger, fontSize: 14, height: 1)),
          ],
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _namaCtrl,
          style: TextStyle(fontSize: tablet ? 15 : 14, color: Colors.black87),
          decoration: InputDecoration(
            hintText: 'Masukkan nama lengkap / kasir...',
            hintStyle: const TextStyle(color: Colors.black38, fontSize: 13),
            border: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: Color(0xFFE0E0E0)),
            ),
            enabledBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: Color(0xFFE0E0E0)),
            ),
            focusedBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: _kBrand, width: 1.5),
            ),
            contentPadding: EdgeInsets.symmetric(
                horizontal: 14, vertical: tablet ? 16 : 14),
          ),
        ),
      ],
    );
  }

  Widget _buildSimpanBtn() {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: _isSaving ? null : _simpan,
        style: ElevatedButton.styleFrom(
          backgroundColor: _kBrand,
          foregroundColor: Colors.white,
          disabledBackgroundColor: _kBrand.withValues(alpha: 0.6),
          elevation: 0,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
        child: _isSaving
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2.5))
            : const Text('Simpan',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.3)),
      ),
    );
  }

  Widget _sectionLabel(String text) {
    return Text(text,
        style: const TextStyle(
            fontSize: 16, fontWeight: FontWeight.w700, color: Colors.black87));
  }

  Widget _outlineBtn(
      {required String label,
      required IconData icon,
      required double width,
      required VoidCallback onTap}) {
    return SizedBox(
      width: width,
      height: 40,
      child: OutlinedButton.icon(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          foregroundColor: _kBrand,
          side: const BorderSide(color: _kBrand),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          padding: const EdgeInsets.symmetric(horizontal: 8),
        ),
        icon: Icon(icon, size: 16, color: _kBrand),
        label: Text(label,
            style: const TextStyle(
                fontSize: 13, fontWeight: FontWeight.w600, color: _kBrand)),
      ),
    );
  }
}

