import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../services/support_contact_service.dart';
import '../utils/modern_ui_helpers.dart';
import 'responsive_layout.dart';
import 'package:url_launcher/url_launcher.dart';

//
// PUSAT BANTUAN SCREEN
//
class PusatBantuanScreen extends ConsumerWidget {
  const PusatBantuanScreen({super.key});

  static const _email = 'halo.juragankasir@gmail.com';

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _hubungiWA(BuildContext context, WidgetRef ref) async {
    try {
      await SupportContactService.launchSupportWhatsapp(
        message:
            'Halo Tim Juragan Servis, saya membutuhkan bantuan mengenai aplikasi.',
      );
    } catch (e) {
      if (context.mounted) {
        ModernSnackBar.error(
          context: context,
          message: 'Gagal membuka WhatsApp. Pastikan WhatsApp sudah terpasang.',
        );
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isWide = isTabletDevice(context) || isLandscape(context);

    return KasirResponsiveScaffold(
      title: 'Pusat Bantuan',
      showNavRail: false,
      backgroundColor: const Color(0xFFF5F5F5),
      body: SingleChildScrollView(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 960),
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: isWide ? 32 : 16,
                vertical: 24,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  //  Header
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(isWide ? 24 : 18),
                    color: AppColors.primaryBrand,
                    child: Row(
                      children: [
                        const Icon(Icons.headset_mic_outlined,
                            color: Colors.white, size: 26),
                        const SizedBox(width: 14),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Pusat Bantuan',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold)),
                            const SizedBox(height: 2),
                            Text(
                              'Temukan jawaban atau hubungi kami langsung',
                              style: TextStyle(
                                  color: Colors.white.withValues(alpha: 0.75),
                                  fontSize: 12.5),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  //  Kontak (2-col on desktop)
                  const _SectionHeader(label: 'Hubungi Kami'),
                  const SizedBox(height: 10),
                  if (isWide)
                    Row(
                      children: [
                        Expanded(
                          child: _ContactTile(
                            icon: Icons.chat_rounded,
                            title: 'WhatsApp',
                            subtitle:
                                'Respon cepat hari kerja\n08.00  17.00 WIB',
                            actionLabel: 'Chat Sekarang',
                            onTap: () => _hubungiWA(context, ref),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _ContactTile(
                            icon: Icons.email_outlined,
                            title: 'Email',
                            subtitle: _email,
                            actionLabel: 'Kirim Email',
                            onTap: () => _launchUrl(
                                'mailto:$_email?subject=Bantuan%20Juragan%20servis'),
                          ),
                        ),
                      ],
                    )
                  else
                    Column(
                      children: [
                        _ContactTile(
                          icon: Icons.chat_rounded,
                          title: 'WhatsApp',
                          subtitle: 'Respon cepat hari kerja\n08.00  17.00 WIB',
                          actionLabel: 'Chat Sekarang',
                          onTap: () => _hubungiWA(context, ref),
                        ),
                        const SizedBox(height: 8),
                        _ContactTile(
                          icon: Icons.email_outlined,
                          title: 'Email',
                          subtitle: _email,
                          actionLabel: 'Kirim Email',
                          onTap: () => _launchUrl(
                              'mailto:$_email?subject=Bantuan%20Juragan%20servis'),
                        ),
                      ],
                    ),

                  const SizedBox(height: 24),

                  //  FAQ (2-col on desktop)
                  const _SectionHeader(label: 'Pertanyaan Umum (FAQ)'),
                  const SizedBox(height: 10),
                  if (isWide)
                    const _FaqGrid(faqs: _faqs)
                  else
                    Column(
                      children: _faqs
                          .map((faq) => _FaqItem(
                                question: faq['q']!,
                                answer: faq['a']!,
                              ))
                          .toList(),
                    ),

                  const SizedBox(height: 24),

                  //  Panduan Cepat
                  const _SectionHeader(label: 'Panduan Cepat'),
                  const SizedBox(height: 10),
                  _GuideGrid(isWide: isWide),

                  const SizedBox(height: 24),

                  //  Sumber Daya
                  const _SectionHeader(label: 'Sumber Daya'),
                  const SizedBox(height: 10),
                  _ResourceTile(
                    icon: Icons.play_circle_outline_rounded,
                    title: 'Dokumentasi & Tutorial',
                    subtitle:
                        'Panduan lengkap penggunaan aplikasi tersedia dalam format video di YouTube.',
                    label: 'Buka YouTube',
                    onTap: () => _launchUrl(
                        'https://www.youtube.com/channel/UCm6ZyoTNst29kDTu8i4Gbkw'),
                  ),

                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  static const _faqs = [
    {
      'q': 'Bagaimana cara backup data?',
      'a':
          'Buka Pengaturan  Backup & Restore  Buat Backup Sekarang. Disarankan minimal 1x seminggu.',
    },
    {
      'q': 'Bagaimana jika saya ganti HP?',
      'a':
          'Hubungi kami via WhatsApp dengan nomor lisensi Anda untuk proses transfer.',
    },
    {
      'q': 'Apakah data saya aman?',
      'a':
          'Ya. Data tersimpan lokal di perangkat dan tidak dikirim ke server tanpa izin Anda.',
    },
    {
      'q': 'Printer tidak terdeteksi?',
      'a':
          'Pastikan printer sudah dipasangkan di Bluetooth HP, lalu Pengaturan  Struk  Scan Printer.',
    },
    {
      'q': 'Cara menambah karyawan?',
      'a':
          'Menu Karyawan  Tambah Karyawan  isi data dan atur hak akses. Karyawan login via PIN.',
    },
    {
      'q': 'Berapa banyak perangkat yang bisa digunakan?',
      'a':
          'Tidak ada batas. Lisensi Juragan Servis berlaku selamanya dan dapat digunakan di semua perangkat milik Anda.',
    },
  ];
}

//
// Section Header
//
class _SectionHeader extends StatelessWidget {
  final String label;
  const _SectionHeader({required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
            width: 3,
            height: 14,
            color: AppColors.primaryBrand,
            margin: const EdgeInsets.only(right: 8)),
        Text(
          label.toUpperCase(),
          style: const TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w800,
              color: Colors.black54,
              letterSpacing: 0.8),
        ),
      ],
    );
  }
}

//
// Contact Tile
//
class _ContactTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String actionLabel;
  final VoidCallback onTap;

  const _ContactTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.actionLabel,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          top: BorderSide(color: AppColors.primaryBrand, width: 2),
          left: BorderSide(color: Color(0xFFE0E0E0)),
          right: BorderSide(color: Color(0xFFE0E0E0)),
          bottom: BorderSide(color: Color(0xFFE0E0E0)),
        ),
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            color: AppColors.primaryBrand.withValues(alpha: 0.08),
            child: Icon(icon, color: AppColors.primaryBrand, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF1A1A1A))),
                const SizedBox(height: 2),
                Text(subtitle,
                    style: const TextStyle(
                        fontSize: 11.5, color: Colors.black45, height: 1.4)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          TextButton(
            onPressed: onTap,
            style: TextButton.styleFrom(
              foregroundColor: AppColors.primaryBrand,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            child: Text(actionLabel,
                style: const TextStyle(
                    fontSize: 11.5, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}

//
// FAQ Grid (2-col desktop)
//
class _FaqGrid extends StatelessWidget {
  final List<Map<String, String>> faqs;
  const _FaqGrid({required this.faqs});

  @override
  Widget build(BuildContext context) {
    final left = faqs.take(faqs.length ~/ 2 + faqs.length % 2).toList();
    final right = faqs.skip(faqs.length ~/ 2 + faqs.length % 2).toList();

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            children: left
                .map((f) => _FaqItem(question: f['q']!, answer: f['a']!))
                .toList(),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            children: right
                .map((f) => _FaqItem(question: f['q']!, answer: f['a']!))
                .toList(),
          ),
        ),
      ],
    );
  }
}

//
// FAQ Item
//
class _FaqItem extends StatefulWidget {
  final String question;
  final String answer;
  const _FaqItem({required this.question, required this.answer});

  @override
  State<_FaqItem> createState() => _FaqItemState();
}

class _FaqItemState extends State<_FaqItem> {
  bool _open = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
            color: _open
                ? AppColors.primaryBrand.withValues(alpha: 0.4)
                : const Color(0xFFE0E0E0)),
      ),
      child: Column(
        children: [
          InkWell(
            onTap: () => setState(() => _open = !_open),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      widget.question,
                      style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                          color: _open
                              ? AppColors.primaryBrand
                              : const Color(0xFF1A1A1A)),
                    ),
                  ),
                  Icon(
                    _open
                        ? Icons.expand_less_rounded
                        : Icons.expand_more_rounded,
                    color: AppColors.primaryBrand,
                    size: 18,
                  ),
                ],
              ),
            ),
          ),
          if (_open) ...[
            const Divider(height: 1, color: Color(0xFFF0F0F0)),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  widget.answer,
                  style: const TextStyle(
                      fontSize: 12, color: Colors.black54, height: 1.55),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

//
// Guide Grid
//
class _GuideGrid extends StatelessWidget {
  final bool isWide;
  const _GuideGrid({required this.isWide});

  static const _guides = [
    (
      icon: Icons.point_of_sale_rounded,
      label: 'Cara Transaksi',
      steps: [
        'Buka menu Transaksi dari navigasi.',
        'Pilih layanan servis yang ingin ditambahkan, atau scan barcode jika menggunakan barcode layanan.',
        'Sesuaikan jumlah/berat sesuai software layanan (kg/pcs/dll).',
        'Ketuk tombol "Bayar" di bagian bawah layar.',
        'Pilih metode pembayaran (Tunai, Non-Tunai, atau Campuran) / atau pilih "Bayar Nanti (Order)".',
        'Isi data pelanggan (nama & WhatsApp), lalu konfirmasi.',
        'Struk akan tercetak jika printer sudah dikonfigurasi.',
      ],
    ),
    (
      icon: Icons.inventory_2_outlined,
      label: 'Kelola Produk',
      steps: [
        'Buka menu Layanan dari navigasi.',
        'Ketuk tombol "+" untuk menambah layanan baru.',
        'Isi nama layanan, software (kg/pcs/dll), dan harga layanan.',
        'Aktifkan "Manajemen Stok" hanya jika layanan tersebut butuh stok (misal: produk pendukung).',
        'Unggah foto layanan (opsional) agar mudah dikenali.',
        'Pilih kategori layanan atau buat kategori baru.',
        'Simpan layanan. Layanan akan muncul di menu Transaksi.',
        'Untuk mengedit, ketuk layanan lalu pilih "Edit".',
      ],
    ),
    (
      icon: Icons.people_outline_rounded,
      label: 'Kelola Pelanggan',
      steps: [
        'Buka menu Pelanggan dari navigasi.',
        'Ketuk tombol "+" untuk menambah pelanggan baru.',
        'Isi nama, nomor HP, dan alamat pelanggan.',
        'Simpan data pelanggan.',
        'Saat transaksi, pilih nama pelanggan agar riwayat tercatat.',
        'Lihat riwayat transaksi per pelanggan dari halaman detail pelanggan.',
      ],
    ),
    (
      icon: Icons.print_outlined,
      label: 'Cetak Struk',
      steps: [
        'Buka Pengaturan  Struk & Printer.',
        'Pastikan printer Bluetooth sudah di-pair di pengaturan HP.',
        'Ketuk "Scan Printer" untuk mendeteksi printer.',
        'Pilih printer yang ditemukan dan simpan pengaturan.',
        'Atur konten struk: nama toko, alamat, pesan footer.',
        'Setiap transaksi selesai, struk akan dicetak otomatis (jika auto print aktif).',
        'Bisa juga cetak ulang struk dari menu Riwayat Transaksi.',
      ],
    ),
    (
      icon: Icons.bar_chart_rounded,
      label: 'Lihat Laporan',
      steps: [
        'Buka menu Laporan dari navigasi.',
        'Pilih periode laporan: Hari ini, Minggu ini, Bulan ini, atau Custom.',
        'Lihat ringkasan omzet, jumlah transaksi, dan laba kotor.',
        'Buka Laporan Penjualan untuk detail per produk terlaris.',
        'Buka Laporan Arus Kas untuk melihat pemasukan dan pengeluaran.',
        'Export laporan ke Excel atau PDF dengan tombol di pojok kanan atas.',
      ],
    ),
    (
      icon: Icons.backup_outlined,
      label: 'Backup Data',
      steps: [
        'Buka Pengaturan  Backup & Restore.',
        'Ketuk "Buat Backup Sekarang" untuk menyimpan data.',
        'File backup tersimpan di penyimpanan lokal perangkat.',
        'Salin file backup ke Google Drive atau USB untuk keamanan ekstra.',
        'Untuk restore, ketuk "Pulihkan dari Backup" dan pilih file.',
        'Disarankan backup minimal 1 kali seminggu.',
      ],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: isWide ? 3 : 2,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        childAspectRatio: 3.2,
      ),
      itemCount: _guides.length,
      itemBuilder: (_, i) {
        final g = _guides[i];
        return InkWell(
          onTap: () => _showGuide(context, g.label, g.icon, g.steps),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: const Color(0xFFE0E0E0)),
            ),
            child: Row(
              children: [
                const SizedBox(width: 12),
                Icon(g.icon,
                    color: AppColors.primaryBrand.withValues(alpha: 0.7),
                    size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    g.label,
                    style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF333333)),
                  ),
                ),
                const Icon(Icons.chevron_right_rounded,
                    size: 14, color: Colors.black26),
                const SizedBox(width: 6),
              ],
            ),
          ),
        );
      },
    );
  }

  static void _showGuide(
    BuildContext context,
    String title,
    IconData icon,
    List<String> steps,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _GuideSheet(title: title, icon: icon, steps: steps),
    );
  }
}

//
// Guide Bottom Sheet
//
class _GuideSheet extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<String> steps;

  const _GuideSheet({
    required this.title,
    required this.icon,
    required this.steps,
  });

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.6,
      minChildSize: 0.4,
      maxChildSize: 0.9,
      expand: false,
      builder: (_, scrollController) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
        ),
        child: Column(
          children: [
            // Handle bar
            Container(
              width: 36,
              height: 4,
              margin: const EdgeInsets.only(top: 10, bottom: 0),
              decoration: BoxDecoration(
                color: Colors.black12,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 14),
              decoration: const BoxDecoration(
                border: Border(bottom: BorderSide(color: Color(0xFFEEEEEE))),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    color: AppColors.primaryBrand.withValues(alpha: 0.08),
                    child: Icon(icon, color: AppColors.primaryBrand, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF1A1A1A)),
                        ),
                        Text(
                          '${steps.length} langkah',
                          style: const TextStyle(
                              fontSize: 11.5, color: Colors.black45),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close_rounded,
                        color: Colors.black38, size: 20),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ),
            // Steps list
            Expanded(
              child: ListView.separated(
                controller: scrollController,
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                itemCount: steps.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (_, i) => Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Step number
                    Container(
                      width: 24,
                      height: 24,
                      alignment: Alignment.center,
                      color: AppColors.primaryBrand,
                      child: Text(
                        '${i + 1}',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 3),
                        child: Text(
                          steps[i],
                          style: const TextStyle(
                              fontSize: 13,
                              color: Color(0xFF333333),
                              height: 1.5),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//
// Resource Tile
//
class _ResourceTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String label;
  final VoidCallback onTap;

  const _ResourceTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          left: BorderSide(color: Color(0xFFE0E0E0)),
          right: BorderSide(color: Color(0xFFE0E0E0)),
          top: BorderSide(color: Color(0xFFE0E0E0)),
          bottom: BorderSide(color: Color(0xFFE0E0E0)),
        ),
      ),
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            color: AppColors.primaryBrand.withValues(alpha: 0.08),
            child: Icon(icon, color: AppColors.primaryBrand, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF1A1A1A))),
                const SizedBox(height: 2),
                Text(subtitle,
                    style:
                        const TextStyle(fontSize: 11.5, color: Colors.black45)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          TextButton(
            onPressed: onTap,
            style: TextButton.styleFrom(
              foregroundColor: AppColors.primaryBrand,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            child: Text(label,
                style: const TextStyle(
                    fontSize: 11.5, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}

