import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../database/db_helper.dart';
import 'checkout_screen.dart';
import 'struk_screen.dart';
import 'pengaturan_pembayaran_screen.dart';
import '../widgets/show_error_dialog.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';
import '../providers/shortcut_provider.dart';
import '../utils/currency_input_formatter.dart';

//  HELPERS

const Color _kBrand = AppColors.primaryBrand;

String _fK(int n) {
  if (n == 0) return '0';
  String s = n.toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return r;
}

String _paymentSettingText(Map<String, dynamic>? settings, String key) {
  return (settings?[key] ?? '').toString().trim();
}

File? _paymentQrisFile(Map<String, dynamic>? settings) {
  final path = _paymentSettingText(settings, 'qris_path');
  if (path.isEmpty) return null;
  final file = File(path);
  return file.existsSync() ? file : null;
}

List<Map<String, String>> _paymentBanksFromSettings(
  Map<String, dynamic>? settings,
) {
  if (settings == null) return const [];

  final banks = <Map<String, String>>[];
  final banksJson = _paymentSettingText(settings, 'banks_json');
  if (banksJson.isNotEmpty) {
    try {
      final decoded = jsonDecode(banksJson);
      if (decoded is List) {
        for (final item in decoded) {
          if (item is! Map) continue;
          final bank = {
            'name': (item['name'] ?? '').toString().trim(),
            'account_number': (item['account_number'] ?? '').toString().trim(),
            'account_name': (item['account_name'] ?? '').toString().trim(),
          };
          if (bank.values.any((value) => value.isNotEmpty)) {
            banks.add(bank);
          }
        }
      }
    } catch (_) {}
  }

  if (banks.isEmpty) {
    final bank = {
      'name': _paymentSettingText(settings, 'bank_name'),
      'account_number': _paymentSettingText(settings, 'account_number'),
      'account_name': _paymentSettingText(settings, 'account_name'),
    };
    if (bank.values.any((value) => value.isNotEmpty)) {
      banks.add(bank);
    }
  }

  return banks;
}

bool _hasBankPaymentDetails(Map<String, dynamic>? settings) {
  return _paymentBanksFromSettings(settings).any((bank) =>
      (bank['name'] ?? '').isNotEmpty ||
      (bank['account_number'] ?? '').isNotEmpty ||
      (bank['account_name'] ?? '').isNotEmpty);
}

void _showNonCashCustomerDisplay(
  BuildContext context, {
  required String mode,
  required Map<String, dynamic> settings,
  required int amount,
}) {
  Navigator.of(context).push(
    MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => _NonCashCustomerDisplayScreen(
        mode: mode,
        settings: Map<String, dynamic>.from(settings),
        amount: amount,
      ),
    ),
  );
}

enum MetodeBayar { tunai, nonTunai, campuran }

enum _WaValidationState { empty, invalid, unchecked, valid }

const MethodChannel _contactPickerChannel =
    MethodChannel('juragan_servis/contact_picker');

//  SCREEN

class PembayaranScreen extends ConsumerStatefulWidget {
  final int totalPembayaran;
  final int diskonAmount;
  final int additionalCharges;
  final List<Map<String, dynamic>>? additionalChargesList;
  final MetodePemesanan metode;
  final DateTime? transactionDate;
  final String? note;

  const PembayaranScreen({
    super.key,
    required this.totalPembayaran,
    this.diskonAmount = 0,
    this.additionalCharges = 0,
    this.additionalChargesList,
    this.metode = MetodePemesanan.bayarLangsung,
    this.transactionDate,
    this.note,
  });

  @override
  ConsumerState<PembayaranScreen> createState() => _PembayaranScreenState();
}

class _PembayaranScreenState extends ConsumerState<PembayaranScreen> {
  MetodeBayar _metodeBayar = MetodeBayar.tunai;
  Customer? _selectedCustomer;
  final _namaCtrl = TextEditingController();
  final _waCtrl = TextEditingController();
  final _jumlahCtrl = TextEditingController();
  final _campuranTunaiCtrl = TextEditingController();
  int _kembalian = 0;
  String _subMetodeNonTunai = 'qris';
  Map<String, dynamic>? _paymentSettings;
  bool _loadingSettings = true;
  bool _isConfirming = false; // Flag to prevent double dialogs
  bool _openingWhatsapp = false;
  bool _pickingContact = false;
  String? _waValidatedPhone;

  @override
  void initState() {
    super.initState();
    _loadPaymentSettings();
    Future.microtask(() {
      final customer = ref.read(selectedCustomerProvider);
      if (customer != null && mounted) {
        setState(() {
          _applyCustomer(customer);
        });
      }
    });
  }

  @override
  void dispose() {
    _namaCtrl.dispose();
    _waCtrl.dispose();
    _jumlahCtrl.dispose();
    _campuranTunaiCtrl.dispose();
    super.dispose();
  }

  String? _normalizeWa(String raw) {
    final digits = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) return null;
    if (digits.startsWith('0')) {
      return '+62${digits.substring(1)}';
    }
    if (digits.startsWith('62')) return '+$digits';
    return '+62$digits';
  }

  String _phoneKey(String? raw) =>
      (raw ?? '').replaceAll(RegExp(r'[^0-9]'), '');

  bool _isValidWaFormat(String? normalized) {
    final digits = _phoneKey(normalized);
    return RegExp(r'^62[0-9]{8,13}$').hasMatch(digits);
  }

  String _displayWa(String raw) {
    final digits = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.startsWith('62')) return digits.substring(2);
    if (digits.startsWith('0')) return digits.substring(1);
    return digits;
  }

  bool get _isCurrentWaMarkedValid {
    final normalized = _normalizeWa(_waCtrl.text.trim());
    return _isValidWaFormat(normalized) &&
        _phoneKey(_waValidatedPhone) == _phoneKey(normalized);
  }

  _WaValidationState get _waValidationState {
    if (_waCtrl.text.trim().isEmpty) return _WaValidationState.empty;
    final normalized = _normalizeWa(_waCtrl.text.trim());
    if (!_isValidWaFormat(normalized)) return _WaValidationState.invalid;
    return _isCurrentWaMarkedValid
        ? _WaValidationState.valid
        : _WaValidationState.unchecked;
  }

  void _applyCustomer(Customer? customer) {
    _selectedCustomer = customer;
    _waValidatedPhone = customer?.whatsappValidatedPhone;
    if (customer == null) {
      _namaCtrl.clear();
      _waCtrl.clear();
      return;
    }
    _namaCtrl.text = customer.name;
    _waCtrl.text = _displayWa(customer.phone ?? '');
  }

  Future<void> _loadPaymentSettings() async {
    final s = await DBHelper.instance.getPaymentSettings();
    if (mounted) {
      setState(() {
        _paymentSettings = s;
        _loadingSettings = false;
      });
    }
  }

  Future<Customer?> _autoSaveCustomerIfValid() async {
    final nama = _namaCtrl.text.trim();
    final normalized = _normalizeWa(_waCtrl.text.trim());
    if (nama.isEmpty || !_isValidWaFormat(normalized)) {
      return null;
    }

    final saved = await DBHelper.instance.upsertCustomerByPhone(
      name: nama,
      phone: normalized!,
    );
    if (!mounted) return saved;
    setState(() {
      _selectedCustomer = saved;
      _waValidatedPhone = saved.whatsappValidatedPhone;
    });
    ref.read(selectedCustomerProvider.notifier).updateState(saved);
    await ref.read(customersProvider.notifier).loadCustomers();
    return saved;
  }

  Future<void> _pickContactPhone() async {
    if (_pickingContact) return;
    if (!Platform.isAndroid) {
      _showPaymentSnack('Picker kontak saat ini tersedia di Android.');
      return;
    }
    setState(() => _pickingContact = true);
    try {
      final result = await _contactPickerChannel
          .invokeMapMethod<String, dynamic>('pickPhoneContact');
      if (!mounted || result == null) return;
      final pickedName = (result['name'] ?? '').toString().trim();
      final pickedPhone = (result['phone'] ?? '').toString().trim();
      final normalized = _normalizeWa(pickedPhone);
      Customer? existing;
      if (_isValidWaFormat(normalized)) {
        existing = await DBHelper.instance.getCustomerByPhone(normalized!);
      }
      if (!mounted) return;
      setState(() {
        if (existing != null) {
          _applyCustomer(existing);
        } else {
          _selectedCustomer = null;
          _waValidatedPhone = null;
          if (pickedName.isNotEmpty) _namaCtrl.text = pickedName;
          _waCtrl.text = _displayWa(pickedPhone);
        }
      });
    } on PlatformException catch (e) {
      if (e.code != 'CANCELED') {
        _showPaymentSnack(e.message ?? 'Kontak tidak bisa dipilih.');
      }
    } on MissingPluginException {
      _showPaymentSnack('Picker kontak belum tersedia di perangkat ini.');
    } finally {
      if (mounted) setState(() => _pickingContact = false);
    }
  }

  Future<void> _cekWhatsapp() async {
    if (_openingWhatsapp) return;
    final normalized = _normalizeWa(_waCtrl.text.trim());
    if (!_isValidWaFormat(normalized)) {
      _showPaymentSnack('Nomor WhatsApp belum valid. Gunakan format +62.');
      return;
    }

    setState(() => _openingWhatsapp = true);
    try {
      final warung = await DBHelper.instance.getWarungProfile();
      if (!mounted) return;
      final storeName = (warung['nama'] ?? '').trim().isNotEmpty
          ? warung['nama']!.trim()
          : 'Juragan Servis';
      final digits = _phoneKey(normalized);
      final text = Uri.encodeComponent(
        _buildWaCheckMessage(
          storeName: storeName,
          customerName: _namaCtrl.text.trim(),
        ),
      );
      final uri = Uri.parse('https://wa.me/$digits?text=$text');
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!mounted) return;
      if (!opened) {
        _showPaymentSnack('WhatsApp tidak bisa dibuka di perangkat ini.');
        return;
      }
      await _showWaCheckResultSheet();
    } catch (_) {
      if (mounted) _showPaymentSnack('Gagal membuka WhatsApp.');
    } finally {
      if (mounted) setState(() => _openingWhatsapp = false);
    }
  }

  String _buildWaCheckMessage({
    required String storeName,
    required String customerName,
  }) {
    final greeting =
        customerName.isEmpty ? 'Halo kak,' : 'Halo kak $customerName,';

    return [
      greeting,
      '',
      'Kami dari $storeName ingin memastikan nomor WhatsApp ini aktif untuk komunikasi pesanan servis.',
      '',
      'Ke depannya, nomor ini akan digunakan untuk mengirim informasi status perbaikan, pengingat pengambilan, dan nota transaksi.',
      '',
      'Jika pesan ini diterima, kakak tidak perlu membalas.',
      '',
      'Terima kasih,',
      storeName,
    ].join('\n');
  }

  Future<void> _showWaCheckResultSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      builder: (ctx) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Cek WhatsApp',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Jika WhatsApp terbuka ke nomor pelanggan, tandai nomor ini valid agar tersimpan untuk transaksi berikutnya.',
                  style: TextStyle(
                    fontSize: 13,
                    height: 1.35,
                    color: Color(0xFF64748B),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: _kBrand,
                          side: const BorderSide(color: _kBrand),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          padding: const EdgeInsets.symmetric(vertical: 13),
                        ),
                        child: const Text('Nanti',
                            style: TextStyle(fontWeight: FontWeight.w800)),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () async {
                          Navigator.pop(ctx);
                          await _markWhatsappValid();
                        },
                        icon: const Icon(Icons.verified_rounded, size: 17),
                        label: const Text('Tandai Valid'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF059669),
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          textStyle:
                              const TextStyle(fontWeight: FontWeight.w800),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _markWhatsappValid() async {
    final normalized = _normalizeWa(_waCtrl.text.trim());
    if (!_isValidWaFormat(normalized)) {
      _showPaymentSnack('Nomor WhatsApp belum valid.');
      return;
    }
    final saved = await _autoSaveCustomerIfValid();
    if (!mounted) return;
    if (saved == null || saved.id == null) {
      _showPaymentSnack('Isi nama pelanggan sebelum tandai valid.');
      return;
    }
    final now = DateTime.now().toIso8601String();
    await DBHelper.instance.markCustomerWhatsappValidated(
      customerId: saved.id!,
      phone: normalized!,
      validatedAt: now,
    );
    final updated = Customer(
      id: saved.id,
      name: saved.name,
      phone: normalized,
      address: saved.address,
      discountPct: saved.discountPct,
      memberCode: saved.memberCode,
      whatsappValidatedAt: now,
      whatsappValidatedPhone: normalized,
      createdAt: saved.createdAt,
    );
    if (!mounted) return;
    setState(() {
      _selectedCustomer = updated;
      _waValidatedPhone = normalized;
    });
    ref.read(selectedCustomerProvider.notifier).updateState(updated);
    await ref.read(customersProvider.notifier).loadCustomers();
    _showPaymentSnack('Nomor WhatsApp ditandai valid.',
        backgroundColor: const Color(0xFF059669));
  }

  Future<void> _saveCustomerFromForm() async {
    final res = await _autoSaveCustomerIfValid();
    if (!mounted) return;
    if (res != null) {
      _showPaymentSnack(
        'Pelanggan berhasil disimpan',
        backgroundColor: const Color(0xFF059669),
      );
      return;
    }
    _showPaymentSnack('Lengkapi nama dan WhatsApp dulu');
  }

  void _showPaymentSnack(String message,
      {Color backgroundColor = Colors.black87}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: backgroundColor,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ),
    );
  }

  void _hitungKembalian() {
    final bayar = parseCurrencyInput(_jumlahCtrl.text);
    setState(() {
      _kembalian = bayar - widget.totalPembayaran;
    });
  }

  bool get _isPaymentValid {
    if (_metodeBayar == MetodeBayar.tunai) {
      final bayar = parseCurrencyInput(_jumlahCtrl.text);
      return bayar >= widget.totalPembayaran;
    }
    if (_metodeBayar == MetodeBayar.campuran) {
      final tunai = parseCurrencyInput(_campuranTunaiCtrl.text);
      // Campuran is valid if cash <= total (rest is non-cash)
      return tunai > 0 && tunai <= widget.totalPembayaran;
    }
    return true; // Non-tunai is always exact
  }

  @override
  Widget build(BuildContext context) {
    final tablet = isTabletDevice(context);
    final landscape = isLandscape(context);
    final useTwoCols = tablet || landscape;

    // Listen for shortcuts
    ref.listen(shortcutSignalProvider, (previous, next) {
      if (next == null) return;

      // Guard: Only respond if this screen is the active route
      if (!(ModalRoute.of(context)?.isCurrent ?? false)) return;

      switch (next) {
        case ShortcutAction.checkout:
          if (_isPaymentValid) {
            // Check if dialog is likely showing (simple heuristic: don't trigger if recently cleared)
            ref.read(shortcutSignalProvider.notifier).clear();
            _prosesCheckout(context);
          }
          break;
        case ShortcutAction.nextCategory:
          ref.read(shortcutSignalProvider.notifier).clear();
          const types = MetodeBayar.values;
          int nextIdx = (_metodeBayar.index + 1) % types.length;
          setState(() => _metodeBayar = types[nextIdx]);
          break;
        case ShortcutAction.prevCategory:
          ref.read(shortcutSignalProvider.notifier).clear();
          const types = MetodeBayar.values;
          int prevIdx = (_metodeBayar.index - 1 + types.length) % types.length;
          setState(() => _metodeBayar = types[prevIdx]);
          break;
        case ShortcutAction.quickPayPas:
        case ShortcutAction.holdTransaction:
        case ShortcutAction.clearCart:
        case ShortcutAction.focusSearch:
        case ShortcutAction.selectCustomer:
        case ShortcutAction.printLast:
        case ShortcutAction.goToCashier:
          ref.read(shortcutSignalProvider.notifier).clear();
          break;
      }
    });

    return Scaffold(
      backgroundColor: tablet ? const Color(0xFFF5F7FA) : Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: _kBrand, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Pembayaran',
            style: TextStyle(
                color: Colors.black87,
                fontSize: tablet ? 20 : 18,
                fontWeight: FontWeight.w600)),
      ),
      body: useTwoCols
          ? _buildTwoPanelLayout(context, tablet)
          : _buildSingleLayout(context),
    );
  }

  Widget _buildTwoPanelLayout(BuildContext context, bool tablet) {
    return Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: tablet ? 900 : double.infinity),
        child: Padding(
          padding: EdgeInsets.all(tablet ? 24 : 16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 4,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildTotalCard(tablet),
                      const SizedBox(height: 16),
                      _buildCustomerCard(context, tablet),
                    ],
                  ),
                ),
              ),
              SizedBox(width: tablet ? 24 : 16),
              Expanded(
                flex: 5,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildMetodeCard(tablet),
                      const SizedBox(height: 16),
                      _buildPaymentForm(context, tablet),
                      const SizedBox(height: 24),
                      _buildBayarBtn(context),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSingleLayout(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _buildTotalCard(false),
              const SizedBox(height: 8),
              _buildCustomerCard(context, false),
              const SizedBox(height: 8),
              _buildMetodeCard(false),
              const SizedBox(height: 8),
              _buildPaymentForm(context, false),
              const SizedBox(height: 24),
            ],
          ),
        ),
        _buildBayarBtnBottom(context),
      ],
    );
  }

  Widget _buildTotalCard(bool tablet) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(tablet ? 24 : 20),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [_kBrand, Color(0xFF1E40AF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.receipt_long_rounded,
                  color: Colors.white70, size: 18),
              const SizedBox(width: 8),
              Text('Total Pembayaran',
                  style: TextStyle(
                      color: Colors.white70,
                      fontSize: tablet ? 14 : 13,
                      fontWeight: FontWeight.w500)),
            ],
          ),
          SizedBox(height: tablet ? 12 : 8),
          Text(
            'Rp ${_fK(widget.totalPembayaran)}',
            style: TextStyle(
                color: Colors.white,
                fontSize: tablet ? 32 : 28,
                fontWeight: FontWeight.bold,
                letterSpacing: -0.5),
          ),
          if (widget.diskonAmount > 0) ...[
            const SizedBox(height: 6),
            Text('Diskon: Rp ${_fK(widget.diskonAmount)}',
                style: const TextStyle(color: Colors.white60, fontSize: 12)),
          ],
        ],
      ),
    );
  }

  Widget _buildCustomerCard(BuildContext context, bool tablet) {
    final customers = ref.watch(customersProvider);
    final hasValue =
        _selectedCustomer != null || _namaCtrl.text.trim().isNotEmpty;

    return _SectionCard(
      title: 'Pelanggan *',
      icon: Icons.person_outline_rounded,
      tablet: tablet,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _namaCtrl,
                  style: const TextStyle(fontSize: 14),
                  onChanged: (_) {
                    // Jika user edit manual, lepaskan Customer yang dipilih
                    if (_selectedCustomer != null) {
                      setState(() => _selectedCustomer = null);
                    } else {
                      setState(() {}); // refresh tombol clear
                    }
                  },
                  decoration: InputDecoration(
                    hintText: 'Ketik nama pelanggan...',
                    hintStyle: const TextStyle(color: Colors.black38),
                    prefixIcon: const Icon(Icons.person_search_rounded,
                        size: 20, color: Colors.black38),
                    // Tombol X untuk hapus
                    suffixIcon: hasValue
                        ? IconButton(
                            icon: const Icon(Icons.close_rounded,
                                size: 18, color: Colors.black38),
                            onPressed: () =>
                                setState(() => _applyCustomer(null)),
                          )
                        : null,
                    filled: true,
                    fillColor: const Color(0xFFF5F7FA),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                    border: const OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide.none),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              OutlinedButton.icon(
                onPressed: customers.isEmpty
                    ? null
                    : () => _showPilihPelangganSheet(context, customers),
                icon: const Icon(Icons.people_alt_outlined, size: 16),
                label: const Text('Pilih',
                    style:
                        TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                style: OutlinedButton.styleFrom(
                  foregroundColor: _kBrand,
                  side: const BorderSide(color: _kBrand),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 46,
                  child: TextField(
                    controller: _waCtrl,
                    keyboardType: TextInputType.phone,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    textAlignVertical: TextAlignVertical.center,
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      height: 1.1,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF0F172A),
                      fontStyle: FontStyle.normal,
                    ),
                    strutStyle: const StrutStyle(
                      fontSize: 14,
                      height: 1.1,
                      forceStrutHeight: true,
                    ),
                    onChanged: (_) => setState(() {}),
                    decoration: InputDecoration(
                      hintText: 'Nomor WhatsApp',
                      hintStyle: GoogleFonts.inter(
                        fontSize: 13.5,
                        height: 1.1,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF94A3B8),
                        fontStyle: FontStyle.normal,
                      ),
                      prefixIcon: const Icon(
                        Icons.phone_outlined,
                        size: 19,
                        color: Color(0xFF64748B),
                      ),
                      prefixIconConstraints: const BoxConstraints(
                        minWidth: 42,
                        minHeight: 46,
                      ),
                      prefixText: '+62 ',
                      prefixStyle: GoogleFonts.inter(
                        fontSize: 14,
                        height: 1.1,
                        fontWeight: FontWeight.w800,
                        color: const Color(0xFF334155),
                        fontStyle: FontStyle.normal,
                      ),
                      isDense: true,
                      filled: true,
                      fillColor: const Color(0xFFF5F7FA),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 0,
                      ),
                      border: const OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                width: 44,
                height: 46,
                child: OutlinedButton(
                  onPressed: _pickingContact ? null : _pickContactPhone,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _kBrand,
                    side: const BorderSide(color: _kBrand),
                    padding: EdgeInsets.zero,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                  child: _pickingContact
                      ? const SizedBox(
                          width: 15,
                          height: 15,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.contact_phone_outlined, size: 18),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              _WaValidationChip(state: _waValidationState),
              _CustomerActionButton(
                icon: Icons.chat_bubble_outline_rounded,
                label: _openingWhatsapp ? 'Membuka...' : 'Cek WA',
                onPressed: _openingWhatsapp ? null : _cekWhatsapp,
              ),
              _CustomerActionButton(
                icon: Icons.save_rounded,
                label: 'Simpan',
                onPressed: _saveCustomerFromForm,
              ),
              if (_waValidationState == _WaValidationState.unchecked)
                _CustomerActionButton(
                  icon: Icons.verified_outlined,
                  label: 'Tandai Valid',
                  onPressed: _markWhatsappValid,
                  foregroundColor: const Color(0xFF059669),
                  borderColor: const Color(0xFF059669),
                ),
            ],
          ),
        ],
      ),
    );
  }

  void _showPilihPelangganSheet(
      BuildContext context, List<Customer> customers) {
    FocusManager.instance.primaryFocus?.unfocus();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      useSafeArea: true,
      requestFocus: false,
      builder: (ctx) {
        return _PaymentCustomerPickerSheet(
          customers: customers,
          selectedCustomerId: _selectedCustomer?.id,
          onSelected: (customer) {
            if (!mounted) return;
            setState(() => _applyCustomer(customer));
          },
        );
      },
    );
  }

  Widget _buildMetodeCard(bool tablet) {
    return _SectionCard(
      title: 'Metode Pembayaran',
      icon: Icons.payments_outlined,
      tablet: tablet,
      child: Row(
        children: [
          _MetodeChip(
              label: 'Tunai',
              icon: Icons.money_rounded,
              selected: _metodeBayar == MetodeBayar.tunai,
              onTap: () => setState(() => _metodeBayar = MetodeBayar.tunai)),
          const SizedBox(width: 8),
          _MetodeChip(
              label: 'Non-Tunai',
              icon: Icons.contactless_rounded,
              selected: _metodeBayar == MetodeBayar.nonTunai,
              onTap: () => setState(() => _metodeBayar = MetodeBayar.nonTunai)),
          const SizedBox(width: 8),
          _MetodeChip(
              label: 'Campuran',
              icon: Icons.account_balance_wallet_outlined,
              selected: _metodeBayar == MetodeBayar.campuran,
              onTap: () => setState(() => _metodeBayar = MetodeBayar.campuran)),
        ],
      ),
    );
  }

  Widget _buildPaymentForm(BuildContext context, bool tablet) {
    switch (_metodeBayar) {
      case MetodeBayar.tunai:
        return _SectionCard(
          title: 'Detail Tunai',
          icon: Icons.money_rounded,
          tablet: tablet,
          child: Column(
            children: [
              TextField(
                controller: _jumlahCtrl,
                keyboardType: TextInputType.number,
                inputFormatters: const [CurrencyInputFormatter()],
                onChanged: (_) => _hitungKembalian(),
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                decoration: const InputDecoration(
                  labelText: 'Jumlah Bayar (Rp)',
                  hintText: '0',
                  labelStyle: TextStyle(color: Colors.black38, fontSize: 13),
                  prefixText: 'Rp ',
                  prefixStyle: TextStyle(
                      fontWeight: FontWeight.bold, color: Colors.black54),
                  filled: true,
                  fillColor: Color(0xFFF5F7FA),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide.none),
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () {
                    _jumlahCtrl.text =
                        formatCurrencyInput(widget.totalPembayaran);
                    _hitungKembalian();
                  },
                  icon: const Icon(Icons.payments_rounded, size: 18),
                  label: const Text('UANG PAS',
                      style:
                          TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _kBrand,
                    backgroundColor: _kBrand.withValues(alpha: 0.05),
                    side: const BorderSide(color: _kBrand, width: 1.5),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                ),
              ),
              Builder(
                builder: (context) {
                  final denoms = {
                    _roundUp(widget.totalPembayaran, 10000),
                    _roundUp(widget.totalPembayaran, 50000),
                    _roundUp(widget.totalPembayaran, 100000),
                  }.where((v) => v > widget.totalPembayaran).toList()
                    ..sort();

                  if (denoms.isEmpty) return const SizedBox.shrink();

                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 4.5,
                        mainAxisSpacing: 6,
                        crossAxisSpacing: 8,
                      ),
                      itemCount: denoms.length,
                      itemBuilder: (context, i) {
                        final v = denoms[i];
                        return GestureDetector(
                          onTap: () {
                            _jumlahCtrl.text = formatCurrencyInput(v);
                            _hitungKembalian();
                          },
                          child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              border: Border.all(
                                  color: _kBrand.withValues(alpha: 0.3)),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Text('Rp ${_fK(v)}',
                                style: const TextStyle(
                                    fontSize: 12.5,
                                    color: _kBrand,
                                    fontWeight: FontWeight.w700)),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
              if (_kembalian > 0) ...[
                const SizedBox(height: 10),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: _kBrand.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.zero,
                    border: Border.all(color: _kBrand.withValues(alpha: 0.3)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Kembalian',
                          style: TextStyle(
                              fontWeight: FontWeight.w600, color: _kBrand)),
                      Text('Rp ${_fK(_kembalian)}',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              color: Color(0xFF2E7D32))),
                    ],
                  ),
                ),
              ],
            ],
          ),
        );

      case MetodeBayar.nonTunai:
        final qrisFile = _paymentQrisFile(_paymentSettings);
        final hasBankDetails = _hasBankPaymentDetails(_paymentSettings);
        return _SectionCard(
          title: 'Detail Non-Tunai',
          icon: Icons.contactless_rounded,
          tablet: tablet,
          child: _loadingSettings
              ? const Center(child: CircularProgressIndicator(color: _kBrand))
              : Column(
                  children: [
                    Row(
                      children: [
                        _SubMetodeChip(
                            label: 'QRIS',
                            icon: Icons.qr_code_rounded,
                            selected: _subMetodeNonTunai == 'qris',
                            onTap: () =>
                                setState(() => _subMetodeNonTunai = 'qris')),
                        const SizedBox(width: 8),
                        _SubMetodeChip(
                            label: 'Transfer Bank',
                            icon: Icons.account_balance_rounded,
                            selected: _subMetodeNonTunai == 'bank',
                            onTap: () =>
                                setState(() => _subMetodeNonTunai = 'bank')),
                      ],
                    ),
                    const SizedBox(height: 16),
                    if (_subMetodeNonTunai == 'qris' && qrisFile != null)
                      Column(
                        children: [
                          _NonCashViewButton(
                            label: 'Lihat QRIS',
                            icon: Icons.fullscreen_rounded,
                            onPressed: () => _showNonCashCustomerDisplay(
                              context,
                              mode: 'qris',
                              settings: _paymentSettings!,
                              amount: widget.totalPembayaran,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Center(
                            child: Column(
                              children: [
                                if (_paymentSettings?['qris_name'] != null &&
                                    (_paymentSettings!['qris_name'] as String)
                                        .trim()
                                        .isNotEmpty)
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 12),
                                    child: Text(
                                      _paymentSettings!['qris_name'],
                                      style: GoogleFonts.plusJakartaSans(
                                        fontWeight: FontWeight.w800,
                                        fontSize: 16,
                                        color: _kBrand,
                                      ),
                                    ),
                                  ),
                                ClipRRect(
                                  borderRadius: BorderRadius.zero,
                                  child: Image.file(
                                    qrisFile,
                                    width: tablet ? 200 : 180,
                                    height: tablet ? 200 : 180,
                                    fit: BoxFit.contain,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      )
                    else if (_subMetodeNonTunai == 'bank' &&
                        _paymentSettings != null &&
                        hasBankDetails)
                      Column(
                        children: [
                          _NonCashViewButton(
                            label: 'Lihat Detail Bank',
                            icon: Icons.fullscreen_rounded,
                            onPressed: () => _showNonCashCustomerDisplay(
                              context,
                              mode: 'bank',
                              settings: _paymentSettings!,
                              amount: widget.totalPembayaran,
                            ),
                          ),
                          const SizedBox(height: 12),
                          _BankInfo(settings: _paymentSettings!),
                        ],
                      )
                    else
                      GestureDetector(
                        onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    const PengaturanPembayaranScreen())),
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: const BoxDecoration(
                            color: Color(0xFFFFF3E0),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: const Row(
                            children: [
                              Icon(Icons.warning_amber_rounded,
                                  color: Color(0xFFE65100)),
                              SizedBox(width: 10),
                              Expanded(
                                  child: Text(
                                      'Pengaturan pembayaran belum lengkap. Ketuk untuk mengatur.',
                                      style: TextStyle(
                                          fontSize: 13,
                                          color: Color(0xFFE65100)))),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
        );

      case MetodeBayar.campuran:
        final tunai = parseCurrencyInput(_campuranTunaiCtrl.text);
        final sisa =
            (widget.totalPembayaran - tunai).clamp(0, widget.totalPembayaran);

        return _SectionCard(
          title: 'Pembayaran Campuran',
          icon: Icons.account_balance_wallet_outlined,
          tablet: tablet,
          child: Column(
            children: [
              TextField(
                controller: _campuranTunaiCtrl,
                keyboardType: TextInputType.number,
                inputFormatters: const [CurrencyInputFormatter()],
                onChanged: (_) => setState(() {}),
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                decoration: const InputDecoration(
                  labelText: 'Jumlah Tunai (Rp)',
                  hintText: '0',
                  prefixText: 'Rp ',
                  filled: true,
                  fillColor: Color(0xFFF5F7FA),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide.none),
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _kBrand.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.zero,
                  border: Border.all(color: _kBrand.withValues(alpha: 0.1)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Sisa (Non-Tunai)',
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Colors.black54)),
                    Text('Rp ${_fK(sisa)}',
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: _kBrand)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Masukkan jumlah tunai, sisanya akan dianggap sebagai pembayaran non-tunai.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black45, fontSize: 11),
              ),
            ],
          ),
        );
    }
  }

  Widget _buildBayarBtn(BuildContext context) {
    final active = _isPaymentValid;
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton.icon(
        onPressed: active ? () => _prosesCheckout(context) : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: _kBrand,
          foregroundColor: Colors.white,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          elevation: 0,
        ),
        icon: const Icon(Icons.check_circle_rounded, size: 22),
        label: Text('Bayar  -  Rp ${_fK(widget.totalPembayaran)}',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildBayarBtnBottom(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(4, 8, 4, 16),
        child: _buildBayarBtn(context),
      ),
    );
  }

  Future<void> _prosesCheckout(BuildContext context) async {
    if (_isConfirming || !_isPaymentValid) return;

    final cart = ref.read(cartProvider);
    if (cart.isEmpty) return;

    if (_selectedCustomer == null && _namaCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Nama pelanggan wajib diisi'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.black87,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
      return;
    }
    final normalizedWa = _normalizeWa(_waCtrl.text.trim());
    if (!_isValidWaFormat(normalizedWa)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Nomor WhatsApp wajib diisi sebelum pembayaran'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: Colors.black87,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
      return;
    }

    if (_selectedCustomer != null &&
        ((_selectedCustomer!.phone ?? '').trim().isEmpty ||
            _selectedCustomer!.phone != normalizedWa)) {
      final sameValidatedPhone =
          _phoneKey(_selectedCustomer!.whatsappValidatedPhone) ==
              _phoneKey(normalizedWa);
      final updated = Customer(
        id: _selectedCustomer!.id,
        name: _selectedCustomer!.name,
        phone: normalizedWa!,
        address: _selectedCustomer!.address,
        discountPct: _selectedCustomer!.discountPct,
        memberCode: _selectedCustomer!.memberCode,
        whatsappValidatedAt:
            sameValidatedPhone ? _selectedCustomer!.whatsappValidatedAt : null,
        whatsappValidatedPhone: sameValidatedPhone
            ? _selectedCustomer!.whatsappValidatedPhone
            : null,
        createdAt: _selectedCustomer!.createdAt,
      );
      await DBHelper.instance.updateCustomer(updated);
      _selectedCustomer = updated;
      _waValidatedPhone = updated.whatsappValidatedPhone;
      ref.read(customersProvider.notifier).loadCustomers();
    }

    // Auto-save pelanggan (upsert by phone) sebelum transaksi dibuat
    final savedCustomer = await _autoSaveCustomerIfValid();
    if (savedCustomer != null) {
      _selectedCustomer = savedCustomer;
    }

    if (!context.mounted) return;

    final bayar = parseCurrencyInput(_jumlahCtrl.text);
    final amountPaid =
        _metodeBayar == MetodeBayar.tunai ? bayar : widget.totalPembayaran;

    String methodStr = 'cash';
    if (_metodeBayar == MetodeBayar.nonTunai) {
      methodStr = _subMetodeNonTunai;
    } else if (_metodeBayar == MetodeBayar.campuran) {
      final tunai = parseCurrencyInput(_campuranTunaiCtrl.text);
      methodStr =
          'Campuran (Tunai: ${_fK(tunai)} & ${_subMetodeNonTunai.toUpperCase()})';
    }

    // Konfirmasi dialog sebelum bayar (Style sama dengan Tambah Piutang)
    setState(() => _isConfirming = true);

    final confirmed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(height: 110, child: _IlustrasiKonfirmasi()),
            const SizedBox(height: 16),
            Text(
              'Total Rp${_fK(widget.totalPembayaran)}',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
            ),
            const SizedBox(height: 8),
            Text(
              'Apakah Anda yakin ingin memproses pembayaran ini '
              'untuk ${(_selectedCustomer?.name ?? (_namaCtrl.text.trim().isEmpty ? "Pelanggan Umum" : _namaCtrl.text.trim()))}?',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black54, fontSize: 14),
            ),
            const SizedBox(height: 28),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: _kBrand),
                      foregroundColor: _kBrand,
                      minimumSize: const Size.fromHeight(50),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    child: const Text('Batal',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Consumer(builder: (context, ref, child) {
                    // Listen to shortcuts INSIDE dialog to allow Enter to confirm
                    ref.listen(shortcutSignalProvider, (prev, next) {
                      if (next == ShortcutAction.checkout) {
                        // Consume immediately
                        ref.read(shortcutSignalProvider.notifier).clear();
                        Navigator.pop(ctx, true);
                      }
                    });
                    return ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        elevation: 0,
                        minimumSize: const Size.fromHeight(50),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: const Text('Ya, Bayar',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 15)),
                    );
                  }),
                ),
              ],
            ),
          ],
        ),
      ),
    );

    if (mounted) setState(() => _isConfirming = false);

    if (confirmed != true) return;
    if (!mounted || !context.mounted) return;

    try {
      final navigator = Navigator.of(context);
      final txId =
          await ref.read(transactionsProvider.notifier).createTransaction(
                cartItems: cart,
                customer: _selectedCustomer,
                // Kirim nama manual jika user ketik tanpa memilih dari daftar
                customerName: _namaCtrl.text.trim().isNotEmpty
                    ? _namaCtrl.text.trim()
                    : null,
                discountAmount: widget.diskonAmount,
                additionalCharges: widget.additionalCharges,
                additionalChargesList: widget.additionalChargesList,
                paymentMethod: methodStr,
                amountPaid: amountPaid,
                paymentStatus: widget.metode == MetodePemesanan.piutang
                    ? "Belum Lunas"
                    : "Lunas",
                transactionDate: widget.transactionDate,
                note: widget.note,
              );
      ref.read(cartProvider.notifier).clearCart();
      if (!mounted || !context.mounted) return;
      navigator.pushReplacement(
        MaterialPageRoute(
          builder: (_) =>
              StrukScreen(transactionId: txId, isAfterPayment: true),
        ),
      );
    } catch (e) {
      if (!mounted || !context.mounted) return;
      final errorStr = e.toString().replaceAll('Exception: ', '');
      final isStockError = errorStr.toLowerCase().contains('stok') ||
          errorStr.toLowerCase().contains('tidak cukup');

      showKasirErrorDialog(
        context,
        title: isStockError ? 'Stok Tidak Cukup' : 'Gagal Memproses',
        message: errorStr,
      );
    }
  }

  int _roundUp(int amount, int step) {
    return ((amount / step).ceil()) * step;
  }
}

class _PaymentCustomerPickerSheet extends StatefulWidget {
  final List<Customer> customers;
  final int? selectedCustomerId;
  final ValueChanged<Customer?> onSelected;

  const _PaymentCustomerPickerSheet({
    required this.customers,
    required this.selectedCustomerId,
    required this.onSelected,
  });

  @override
  State<_PaymentCustomerPickerSheet> createState() =>
      _PaymentCustomerPickerSheetState();
}

class _PaymentCustomerSearchEntry {
  final Customer customer;
  final String searchText;

  const _PaymentCustomerSearchEntry({
    required this.customer,
    required this.searchText,
  });
}

class _PaymentCustomerPickerSheetState
    extends State<_PaymentCustomerPickerSheet> {
  final TextEditingController _searchCtrl = TextEditingController();
  late final List<_PaymentCustomerSearchEntry> _searchEntries;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _searchEntries = widget.customers
        .map((customer) => _PaymentCustomerSearchEntry(
              customer: customer,
              searchText:
                  '${customer.name} ${customer.phone ?? ''}'.toLowerCase(),
            ))
        .toList(growable: false);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _select(Customer? customer) {
    FocusManager.instance.primaryFocus?.unfocus();
    widget.onSelected(customer);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final keyboardInset = MediaQuery.viewInsetsOf(context).bottom;
    final query = _query.trim().toLowerCase();
    final filtered = query.isEmpty
        ? widget.customers
        : _searchEntries
            .where((entry) => entry.searchText.contains(query))
            .map((entry) => entry.customer)
            .toList(growable: false);

    return AnimatedPadding(
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOutCubic,
      padding: EdgeInsets.only(bottom: keyboardInset),
      child: DraggableScrollableSheet(
        initialChildSize: 0.58,
        minChildSize: 0.42,
        maxChildSize: 0.9,
        expand: false,
        builder: (ctx, scrollController) {
          return Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.zero),
            ),
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 12, bottom: 4),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.zero,
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Pilih Pelanggan',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: Colors.black87,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 6, 16, 10),
                  child: TextField(
                    controller: _searchCtrl,
                    autofocus: false,
                    textInputAction: TextInputAction.search,
                    onChanged: (value) => setState(() => _query = value),
                    decoration: InputDecoration(
                      hintText: 'Cari nama / nomor HP...',
                      prefixIcon: const Icon(Icons.search_rounded,
                          size: 20, color: Colors.black38),
                      suffixIcon: _query.isEmpty
                          ? null
                          : IconButton(
                              icon: const Icon(Icons.close_rounded, size: 18),
                              onPressed: () {
                                _searchCtrl.clear();
                                setState(() => _query = '');
                              },
                            ),
                      filled: true,
                      fillColor: const Color(0xFFF5F7FA),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide(color: Colors.grey.shade200),
                      ),
                      focusedBorder: const OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide(color: _kBrand, width: 1.5),
                      ),
                    ),
                  ),
                ),
                const Divider(height: 1),
                Expanded(
                  child: ListView.separated(
                    controller: scrollController,
                    keyboardDismissBehavior:
                        ScrollViewKeyboardDismissBehavior.onDrag,
                    cacheExtent: 720,
                    itemCount: filtered.length + 1,
                    separatorBuilder: (_, __) =>
                        const Divider(height: 1, indent: 16),
                    itemBuilder: (_, index) {
                      if (index == 0) {
                        final selected = widget.selectedCustomerId == null;
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundColor: const Color(0xFFF1F5F9),
                            child: Icon(
                              Icons.person_outline_rounded,
                              color: selected ? _kBrand : Colors.black38,
                            ),
                          ),
                          title: const Text(
                            'Pelanggan Umum',
                            style: TextStyle(fontWeight: FontWeight.w700),
                          ),
                          subtitle: const Text(
                            'Tanpa data pelanggan',
                            style:
                                TextStyle(fontSize: 12, color: Colors.black45),
                          ),
                          trailing: selected
                              ? const Icon(Icons.check_circle_rounded,
                                  color: _kBrand)
                              : null,
                          onTap: () => _select(null),
                        );
                      }

                      final customer = filtered[index - 1];
                      final selected = widget.selectedCustomerId != null &&
                          widget.selectedCustomerId == customer.id;
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: _kBrand.withValues(alpha: 0.1),
                          child: Text(
                            customer.name.isNotEmpty
                                ? customer.name[0].toUpperCase()
                                : '?',
                            style: const TextStyle(
                              color: _kBrand,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        title: Text(
                          customer.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                          ),
                        ),
                        subtitle:
                            customer.phone != null && customer.phone!.isNotEmpty
                                ? Text(
                                    customer.phone!,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontSize: 12, color: Colors.black45),
                                  )
                                : null,
                        trailing: selected
                            ? const Icon(Icons.check_circle_rounded,
                                color: _kBrand)
                            : null,
                        onTap: () => _select(selected ? null : customer),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

//  SECTION CARD wrapper

class _SectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final bool tablet;
  final Widget child;

  const _SectionCard({
    required this.title,
    required this.icon,
    required this.tablet,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(tablet ? 20 : 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: tablet ? Border.all(color: const Color(0xFFE8E8E8)) : null,
        boxShadow: tablet
            ? [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.04),
                    blurRadius: 10,
                    offset: const Offset(0, 4))
              ]
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: Colors.black45),
              const SizedBox(width: 6),
              Text(title.toUpperCase(),
                  style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: Colors.black38,
                      letterSpacing: 0.8)),
            ],
          ),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }
}

class _MetodeChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _MetodeChip({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
          decoration: BoxDecoration(
            color: selected ? _kBrand : _kBrand.withValues(alpha: 0.06),
            borderRadius: BorderRadius.zero,
            border: Border.all(
                color: selected ? _kBrand : _kBrand.withValues(alpha: 0.2)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: selected ? Colors.white : _kBrand, size: 20),
              const SizedBox(height: 4),
              Text(label,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: selected ? Colors.white : _kBrand)),
            ],
          ),
        ),
      ),
    );
  }
}

class _SubMetodeChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _SubMetodeChip({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color:
                selected ? _kBrand.withValues(alpha: 0.1) : Colors.transparent,
            borderRadius: BorderRadius.zero,
            border:
                Border.all(color: selected ? _kBrand : const Color(0xFFE0E0E0)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 18, color: selected ? _kBrand : Colors.black45),
              const SizedBox(width: 6),
              Text(label,
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: selected ? _kBrand : Colors.black45)),
            ],
          ),
        ),
      ),
    );
  }
}

class _WaValidationChip extends StatelessWidget {
  final _WaValidationState state;

  const _WaValidationChip({required this.state});

  @override
  Widget build(BuildContext context) {
    final config = switch (state) {
      _WaValidationState.valid => (
          icon: Icons.verified_rounded,
          text: 'WA valid',
          fg: const Color(0xFF047857),
          bg: const Color(0xFFE7F8F0),
          border: const Color(0xFFA7F3D0),
        ),
      _WaValidationState.unchecked => (
          icon: Icons.info_outline_rounded,
          text: 'Belum dicek WA',
          fg: const Color(0xFFB45309),
          bg: const Color(0xFFFFF7E6),
          border: const Color(0xFFFCD34D),
        ),
      _WaValidationState.invalid => (
          icon: Icons.error_outline_rounded,
          text: 'Format belum valid',
          fg: const Color(0xFFDC2626),
          bg: const Color(0xFFFFF1F2),
          border: const Color(0xFFFECACA),
        ),
      _WaValidationState.empty => (
          icon: Icons.phone_outlined,
          text: 'Belum ada nomor',
          fg: const Color(0xFF64748B),
          bg: const Color(0xFFF8FAFC),
          border: const Color(0xFFE2E8F0),
        ),
    };

    return Container(
      height: 32,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: config.bg,
        border: Border.all(color: config.border),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(config.icon, size: 15, color: config.fg),
          const SizedBox(width: 6),
          Text(
            config.text,
            style: TextStyle(
              color: config.fg,
              fontSize: 11.5,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _CustomerActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onPressed;
  final Color foregroundColor;
  final Color borderColor;

  const _CustomerActionButton({
    required this.icon,
    required this.label,
    required this.onPressed,
    this.foregroundColor = _kBrand,
    this.borderColor = _kBrand,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 32,
      child: OutlinedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, size: 14),
        label: Text(label),
        style: OutlinedButton.styleFrom(
          foregroundColor: foregroundColor,
          disabledForegroundColor: Colors.black38,
          side: BorderSide(
            color: onPressed == null ? Colors.black12 : borderColor,
          ),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          padding: const EdgeInsets.symmetric(horizontal: 10),
          textStyle:
              const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}

class _BankInfo extends StatefulWidget {
  final Map<String, dynamic> settings;
  const _BankInfo({required this.settings});

  @override
  State<_BankInfo> createState() => _BankInfoState();
}

class _BankInfoState extends State<_BankInfo> {
  int? _expandedIndex;

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> banks = [];

    // Parse banks_json
    final String? banksJson = widget.settings['banks_json'];
    if (banksJson != null && banksJson.isNotEmpty) {
      try {
        final List decoded = jsonDecode(banksJson);
        banks = decoded.map((e) => Map<String, dynamic>.from(e)).toList();
      } catch (_) {}
    }

    // Fallback to old columns if no json is present or list is empty
    if (banks.isEmpty) {
      banks.add({
        'name': widget.settings['bank_name'] ?? '-',
        'account_number': widget.settings['account_number'] ?? '-',
        'account_name': widget.settings['account_name'] ?? '-',
      });
    }

    return Column(
      children: banks.asMap().entries.map((entry) {
        final index = entry.key;
        final bank = entry.value;
        final isLast = index == banks.length - 1;
        final isExpanded = _expandedIndex == index;

        return Container(
          margin: EdgeInsets.only(bottom: isLast ? 0 : 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(
              color: isExpanded
                  ? _kBrand.withValues(alpha: 0.5)
                  : const Color(0xFFE2E8F0),
              width: isExpanded ? 1.5 : 1,
            ),
          ),
          child: Column(
            children: [
              // Header Button
              InkWell(
                onTap: () =>
                    setState(() => _expandedIndex = isExpanded ? null : index),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: _kBrand.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.zero,
                        ),
                        child: const Icon(Icons.account_balance_rounded,
                            color: _kBrand, size: 18),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          bank['name'] ?? '-',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF1E293B),
                          ),
                        ),
                      ),
                      Icon(
                        isExpanded
                            ? Icons.keyboard_arrow_up_rounded
                            : Icons.keyboard_arrow_down_rounded,
                        color: Colors.black26,
                        size: 20,
                      ),
                    ],
                  ),
                ),
              ),
              // Collapsible info
              if (isExpanded) ...[
                const Divider(height: 1, color: Color(0xFFE2E8F0)),
                Container(
                  padding: const EdgeInsets.all(16),
                  color: const Color(0xFFF8FAFC),
                  child: Column(
                    children: [
                      _Row(
                          label: 'No. Rekening',
                          value: bank['account_number'] ?? '-'),
                      const SizedBox(height: 10),
                      _Row(
                          label: 'Atas Nama',
                          value: bank['account_name'] ?? '-'),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            Clipboard.setData(ClipboardData(
                                text: bank['account_number'] ?? '-'));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Nomor rekening disalin'),
                                behavior: SnackBarBehavior.floating,
                                duration: Duration(seconds: 1),
                              ),
                            );
                          },
                          icon: const Icon(Icons.copy_rounded, size: 14),
                          label: const Text('Salin Nomor Rekening',
                              style: TextStyle(fontSize: 12)),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: _kBrand,
                            side: const BorderSide(color: _kBrand),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        );
      }).toList(),
    );
  }
}

class _Row extends StatelessWidget {
  final String label;
  final String value;
  const _Row({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: const TextStyle(fontSize: 13, color: Colors.black45)),
        Text(value,
            style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.black87)),
      ],
    );
  }
}

class _NonCashViewButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onPressed;

  const _NonCashViewButton({
    required this.label,
    required this.icon,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 42,
      child: OutlinedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, size: 17),
        label: Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
        ),
        style: OutlinedButton.styleFrom(
          foregroundColor: _kBrand,
          backgroundColor: _kBrand.withValues(alpha: 0.04),
          side: const BorderSide(color: _kBrand, width: 1.2),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      ),
    );
  }
}

class _NonCashCustomerDisplayScreen extends StatelessWidget {
  final String mode;
  final Map<String, dynamic> settings;
  final int amount;

  const _NonCashCustomerDisplayScreen({
    required this.mode,
    required this.settings,
    required this.amount,
  });

  @override
  Widget build(BuildContext context) {
    final isQris = mode == 'qris';
    final title = isQris ? 'Scan QRIS' : 'Transfer Bank';

    return Scaffold(
      backgroundColor: isQris ? Colors.white : const Color(0xFFF5F7FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: const Color(0xFF111827),
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.close_rounded),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          TextButton.icon(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.close_rounded, size: 17),
            label: const Text(
              'Tutup',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            style: TextButton.styleFrom(foregroundColor: _kBrand),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        top: false,
        child: isQris
            ? _QrisCustomerDisplay(settings: settings, amount: amount)
            : _BankCustomerDisplay(settings: settings, amount: amount),
      ),
    );
  }
}

class _CustomerDisplayAmount extends StatelessWidget {
  final int amount;
  const _CustomerDisplayAmount({required this.amount});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        color: _kBrand.withValues(alpha: 0.08),
        border: Border.all(color: _kBrand.withValues(alpha: 0.22)),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        children: [
          const Expanded(
            child: Text(
              'Total Pembayaran',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: Color(0xFF64748B),
              ),
            ),
          ),
          Text(
            'Rp ${_fK(amount)}',
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w900,
              color: _kBrand,
            ),
          ),
        ],
      ),
    );
  }
}

class _QrisCustomerDisplay extends StatelessWidget {
  final Map<String, dynamic> settings;
  final int amount;

  const _QrisCustomerDisplay({
    required this.settings,
    required this.amount,
  });

  @override
  Widget build(BuildContext context) {
    final qrisFile = _paymentQrisFile(settings);
    final qrisName = _paymentSettingText(settings, 'qris_name');
    final displayName = qrisName.isEmpty ? 'QRIS' : qrisName;

    return LayoutBuilder(
      builder: (context, constraints) {
        var qrSize = constraints.maxWidth - 48;
        final heightTarget = constraints.maxHeight - 210;
        if (heightTarget > 0 && heightTarget < qrSize) qrSize = heightTarget;
        if (qrSize > 760) qrSize = 760;
        if (qrSize < 220) qrSize = 220;

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 760),
                child: _CustomerDisplayAmount(amount: amount),
              ),
            ),
            Expanded(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: qrisFile == null
                      ? const _PaymentDisplayEmpty()
                      : Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              displayName,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 26,
                                fontWeight: FontWeight.w900,
                                color: Color(0xFF111827),
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              'Silakan scan QRIS untuk pembayaran',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF64748B),
                              ),
                            ),
                            const SizedBox(height: 18),
                            Container(
                              width: qrSize,
                              height: qrSize,
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.zero,
                                border: Border.all(
                                  color: const Color(0xFFE2E8F0),
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.06),
                                    blurRadius: 24,
                                    offset: const Offset(0, 8),
                                  ),
                                ],
                              ),
                              child: InteractiveViewer(
                                minScale: 1,
                                maxScale: 4,
                                child:
                                    Image.file(qrisFile, fit: BoxFit.contain),
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _BankCustomerDisplay extends StatelessWidget {
  final Map<String, dynamic> settings;
  final int amount;

  const _BankCustomerDisplay({
    required this.settings,
    required this.amount,
  });

  @override
  Widget build(BuildContext context) {
    final banks = _paymentBanksFromSettings(settings);

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: Column(
            children: [
              _CustomerDisplayAmount(amount: amount),
              const SizedBox(height: 16),
              if (banks.isEmpty)
                const _PaymentDisplayEmpty()
              else
                ...banks.map((bank) => _CustomerBankCard(bank: bank)),
            ],
          ),
        ),
      ),
    );
  }
}

class _CustomerBankCard extends StatelessWidget {
  final Map<String, String> bank;

  const _CustomerBankCard({required this.bank});

  @override
  Widget build(BuildContext context) {
    final name = (bank['name'] ?? '').isEmpty ? '-' : bank['name']!;
    final accountNumber =
        (bank['account_number'] ?? '').isEmpty ? '-' : bank['account_number']!;
    final accountName =
        (bank['account_name'] ?? '').isEmpty ? '-' : bank['account_name']!;

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: _kBrand.withValues(alpha: 0.08),
                  border: Border.all(color: _kBrand.withValues(alpha: 0.18)),
                  borderRadius: BorderRadius.zero,
                ),
                child: const Icon(
                  Icons.account_balance_rounded,
                  color: _kBrand,
                  size: 24,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF111827),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Text(
            'No. Rekening',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: Color(0xFF64748B),
            ),
          ),
          const SizedBox(height: 6),
          SelectableText(
            accountNumber,
            style: const TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.w900,
              color: _kBrand,
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Atas Nama',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: Color(0xFF64748B),
            ),
          ),
          const SizedBox(height: 6),
          SelectableText(
            accountName,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            height: 46,
            child: OutlinedButton.icon(
              onPressed: accountNumber == '-'
                  ? null
                  : () {
                      Clipboard.setData(ClipboardData(text: accountNumber));
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Nomor rekening disalin'),
                          behavior: SnackBarBehavior.floating,
                          duration: Duration(seconds: 1),
                        ),
                      );
                    },
              icon: const Icon(Icons.copy_rounded, size: 17),
              label: const Text(
                'Salin Nomor Rekening',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: _kBrand,
                side: const BorderSide(color: _kBrand),
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PaymentDisplayEmpty extends StatelessWidget {
  const _PaymentDisplayEmpty();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7ED),
        border: Border.all(color: const Color(0xFFFED7AA)),
        borderRadius: BorderRadius.zero,
      ),
      child: const Row(
        children: [
          Icon(Icons.warning_amber_rounded, color: Color(0xFFC2410C)),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'Pengaturan pembayaran belum lengkap. Ketuk untuk mengatur.',
              style: TextStyle(
                color: Color(0xFFC2410C),
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _IlustrasiKonfirmasi extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 90,
          height: 100,
          decoration: BoxDecoration(
              color: Colors.grey.shade100, borderRadius: BorderRadius.zero),
          child: Icon(Icons.smartphone_rounded,
              size: 60, color: Colors.grey.shade400),
        ),
        Positioned(
          bottom: 10,
          right: 10,
          child: Container(
            width: 26,
            height: 26,
            decoration:
                const BoxDecoration(color: _kBrand, shape: BoxShape.rectangle),
            child: const Icon(Icons.check, color: Colors.white, size: 14),
          ),
        ),
      ],
    );
  }
}

