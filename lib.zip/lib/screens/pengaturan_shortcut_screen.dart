import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/shortcut_provider.dart';
import '../core/theme.dart';

class PengaturanShortcutScreen extends ConsumerStatefulWidget {
  const PengaturanShortcutScreen({super.key});

  @override
  ConsumerState<PengaturanShortcutScreen> createState() =>
      _PengaturanShortcutScreenState();
}

class _PengaturanShortcutScreenState
    extends ConsumerState<PengaturanShortcutScreen> {
  static const Color _kBrand = AppColors.primaryBrand;

  void _showRecordDialog(ShortcutAction action, String label) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => _RecordShortcutDialog(
        label: label,
        onRecorded: (key) {
          ref.read(shortcutProvider.notifier).updateShortcut(action, key);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final shortcuts = ref.watch(shortcutProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text('Pengaturan Shortcut Keyboard',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: TextButton.icon(
              onPressed: () =>
                  ref.read(shortcutProvider.notifier).resetToDefaults(),
              icon: const Icon(Icons.refresh_rounded, size: 16),
              label: const Text('Reset ke Default',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
              style: TextButton.styleFrom(foregroundColor: AppColors.danger),
            ),
          ),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 900),
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            children: [
              // Header Info
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _kBrand.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Icon(Icons.keyboard_outlined,
                          color: _kBrand, size: 28),
                    ),
                    const SizedBox(width: 20),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Optimalkan Kecepatan Transaksi',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  color: Color(0xFF1E293B))),
                          SizedBox(height: 4),
                          Text(
                            'Gunakan shortcut keyboard untuk memproses transaksi tanpa mouse. Shortcut hanya aktif di halaman Transaksi pada mode Desktop.',
                            style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                                height: 1.5),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),

              _buildSectionHeader(Icons.payment_rounded, 'ALUR PEMBAYARAN'),
              _buildShortcutTile(
                'Konfirmasi Bayar / Checkout',
                'Membuka halaman pembayaran atau memproses checkout.',
                shortcuts[ShortcutAction.checkout]!,
                () => _showRecordDialog(
                    ShortcutAction.checkout, 'Konfirmasi Bayar'),
              ),
              _buildShortcutTile(
                'Bayar Tunai Pas (Quick Pay)',
                'Langsung menyelesaikan transaksi dengan uang pas (Tunai).',
                shortcuts[ShortcutAction.quickPayPas]!,
                () => _showRecordDialog(
                    ShortcutAction.quickPayPas, 'Bayar Tunai Pas'),
              ),
              _buildShortcutTile(
                'Tahan Pesanan (Hold)',
                'Menyimpan keranjang sebagai pesanan belum lunas.',
                shortcuts[ShortcutAction.holdTransaction]!,
                () => _showRecordDialog(
                    ShortcutAction.holdTransaction, 'Tahan Pesanan'),
              ),
              const SizedBox(height: 24),

              _buildSectionHeader(
                  Icons.shopping_basket_rounded, 'KERANJANG & PELANGGAN'),
              _buildShortcutTile(
                'Cari Layanan',
                'Meletakkan kursor langsung ke kolom pencarian layanan.',
                shortcuts[ShortcutAction.focusSearch]!,
                () => _showRecordDialog(
                    ShortcutAction.focusSearch, 'Cari Layanan'),
              ),
              _buildShortcutTile(
                'Pilih Pelanggan',
                'Membuka daftar pelanggan untuk dihubungkan ke transaksi.',
                shortcuts[ShortcutAction.selectCustomer]!,
                () => _showRecordDialog(
                    ShortcutAction.selectCustomer, 'Pilih Pelanggan'),
              ),
              _buildShortcutTile(
                'Hapus Semua Isi Keranjang',
                'Mengosongkan keranjang belanja secara instan.',
                shortcuts[ShortcutAction.clearCart]!,
                () => _showRecordDialog(
                    ShortcutAction.clearCart, 'Hapus Keranjang'),
              ),
              const SizedBox(height: 24),

              _buildSectionHeader(
                  Icons.settings_suggest_rounded, 'NAVIGASI & OPERASIONAL'),
              _buildShortcutTile(
                'Pindah Kategori Layanan',
                'Berpindah antar tab kategori layanan di transaksi.',
                shortcuts[ShortcutAction.nextCategory]!,
                () => _showRecordDialog(
                    ShortcutAction.nextCategory, 'Pindah Kategori'),
              ),
              _buildShortcutTile(
                'Cetak Struk Terakhir',
                'Mencetak ulang struk dari transaksi paling terakhir.',
                shortcuts[ShortcutAction.printLast]!,
                () => _showRecordDialog(
                    ShortcutAction.printLast, 'Cetak Struk Terakhir'),
              ),
              _buildShortcutTile(
                'Buka Halaman Transaksi (Ctrl + Key)',
                'Berpindah dari halaman manapun langsung ke layar transaksi.',
                shortcuts[ShortcutAction.goToCashier]!,
                () => _showRecordDialog(
                    ShortcutAction.goToCashier, 'Buka Halaman Transaksi'),
              ),
              const SizedBox(height: 60),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(IconData icon, String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16, left: 4),
      child: Row(
        children: [
          Icon(icon, size: 16, color: const Color(0xFF64748B)),
          const SizedBox(width: 10),
          Text(
            title,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: Color(0xFF64748B),
              letterSpacing: 1.2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShortcutTile(String title, String subtitle,
      LogicalKeyboardKey key, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                              color: Color(0xFF1E293B))),
                      const SizedBox(height: 4),
                      Text(subtitle,
                          style: const TextStyle(
                              fontSize: 12, color: Color(0xFF64748B))),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                _KeyBox(keyLabel: getReadableKeyName(key)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _KeyBox extends StatelessWidget {
  final String keyLabel;
  const _KeyBox({required this.keyLabel});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      constraints: const BoxConstraints(minWidth: 60),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFCBD5E1), width: 1.5),
        boxShadow: [
          // Simulate a physical key look
          BoxShadow(
            color: const Color(0xFF94A3B8).withValues(alpha: 0.2),
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Text(
        keyLabel,
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: Color(0xFF334155),
          fontWeight: FontWeight.w900,
          fontSize: 13,
          letterSpacing: 0.5,
          fontFamily: 'monospace',
        ),
      ),
    );
  }
}

class _RecordShortcutDialog extends StatefulWidget {
  final String label;
  final ValueChanged<LogicalKeyboardKey> onRecorded;

  const _RecordShortcutDialog({required this.label, required this.onRecorded});

  @override
  State<_RecordShortcutDialog> createState() => _RecordShortcutDialogState();
}

class _RecordShortcutDialogState extends State<_RecordShortcutDialog> {
  LogicalKeyboardKey? _lastKeyPressed;

  @override
  void initState() {
    super.initState();
    HardwareKeyboard.instance.addHandler(_onKeyEvent);
  }

  @override
  void dispose() {
    HardwareKeyboard.instance.removeHandler(_onKeyEvent);
    super.dispose();
  }

  bool _onKeyEvent(KeyEvent event) {
    if (event is KeyDownEvent) {
      setState(() {
        _lastKeyPressed = event.logicalKey;
      });
      // Delay slightly to show the recorded key before closing
      Future.delayed(const Duration(milliseconds: 300), () {
        if (mounted) {
          widget.onRecorded(event.logicalKey);
          Navigator.pop(context);
        }
      });
    }
    return true; // Intercept everything while recording
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Tekan Tombol Baru untuk:',
              style: TextStyle(color: Colors.grey.shade600, fontSize: 14),
            ),
            const SizedBox(height: 8),
            Text(
              widget.label,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 48),
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                border: Border.all(color: AppColors.primaryBrand, width: 2),
                color: AppColors.primaryBrand.withValues(alpha: 0.05),
              ),
              alignment: Alignment.center,
              child: _lastKeyPressed == null
                  ? const Icon(Icons.keyboard_outlined,
                      size: 48, color: AppColors.primaryBrand)
                  : Text(
                      getReadableKeyName(_lastKeyPressed!),
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        color: AppColors.primaryBrand,
                      ),
                    ),
            ),
            const SizedBox(height: 48),
            Text(
              _lastKeyPressed == null
                  ? 'Silakan tekan tombol apa saja di keyboard Anda...'
                  : 'Berhasil direkam!',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _lastKeyPressed == null ? Colors.black54 : Colors.green,
                fontStyle: _lastKeyPressed == null
                    ? FontStyle.italic
                    : FontStyle.normal,
              ),
            ),
            const SizedBox(height: 24),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
          ],
        ),
      ),
    );
  }
}

