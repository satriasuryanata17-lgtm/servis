import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../core/theme.dart';
import '../database/db_helper.dart';
import '../widgets/kasir_dialog.dart';
import 'responsive_layout.dart';
import '../widgets/export_dropdown.dart';
import '../services/export_service.dart';

const Color _kBrand = AppColors.primaryBrand;

class OmzetPerBulanScreen extends StatefulWidget {
  const OmzetPerBulanScreen({super.key});

  @override
  State<OmzetPerBulanScreen> createState() => _OmzetPerBulanScreenState();
}

class _OmzetPerBulanScreenState extends State<OmzetPerBulanScreen> {
  String _periode = 'Periode Tahunan';
  int _tahun = DateTime.now().year;
  int _bulan = DateTime.now().month;

  static const _bulanNama = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember',
  ];

  List<double>? _monthlyData;
  bool _isLoading = false;

  final List<String> _periodeOptions = ['Periode Tahunan', 'Periode Bulanan'];
  final List<int> _tahunOptions = [
    DateTime.now().year - 2,
    DateTime.now().year - 1,
    DateTime.now().year,
    DateTime.now().year + 1,
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final data = await DBHelper.instance.getMonthlyOmzetReport(_tahun);
    if (!mounted) return;
    setState(() {
      _monthlyData = data;
      _isLoading = false;
    });
  }

  Future<void> _showBulanSheet() async {
    final selected = await showKasirOptionSheet<int>(
      context,
      title: 'Pilih Bulan',
      options: List.generate(12, (i) => i + 1),
      currentValue: _bulan,
      labelBuilder: (b) => _bulanNama[b - 1],
    );
    if (selected != null && selected != _bulan && mounted) {
      setState(() => _bulan = selected);
      _loadData();
    }
  }

  Future<void> _showPeriodeSheet() async {
    final selected = await showKasirOptionSheet<String>(
      context,
      title: 'Pilih Periode',
      options: _periodeOptions,
      currentValue: _periode,
      labelBuilder: (idx) => idx,
    );
    if (selected != null && selected != _periode && mounted) {
      setState(() => _periode = selected);
      _loadData();
    }
  }

  Future<void> _showTahunSheet() async {
    final selected = await showKasirOptionSheet<int>(
      context,
      title: 'Pilih Tahun',
      options: _tahunOptions,
      currentValue: _tahun,
      labelBuilder: (y) => y.toString(),
    );
    if (selected != null && selected != _tahun && mounted) {
      setState(() => _tahun = selected);
      _loadData();
    }
  }

  Future<void> _exportData() async {
    final choice = await ExportDropdown.show(context);
    if (choice == null) return;

    final data = _monthlyData ?? List<double>.filled(12, 0);
    if (!mounted) return;

    final headers = ['Bulan', 'Omzet'];
    final rows = List.generate(
        12,
        (i) => [
              _bulanNama[i],
              'Rp ${data[i].toStringAsFixed(0)}',
            ]);

    final Map<String, String> summaryData = {
      'Total Omzet': 'Rp ${_totalOmzet.toStringAsFixed(0)}',
      'Bulan Terbaik':
          _maxBulan > 0 && _peakBulanIdx >= 0 ? _bulanNama[_peakBulanIdx] : '-',
      'Tahun': _tahun.toString(),
    };

    const title = 'Laporan Omzet Bulanan';

    try {
      if (choice == 'csv') {
        await ExportService.exportAndShareCsv(
          filePrefix: 'omzet_bulanan',
          headers: ['Bulan', 'Omzet', 'Tahun'],
          rows: List.generate(12, (i) => [_bulanNama[i], data[i], _tahun]),
          subject: 'Ekspor Omzet Bulanan $_tahun',
        );
      } else if (choice == 'pdf') {
        await ExportService.exportPdfLaporan(
          title: title,
          subtitle: 'Tahun: $_tahun',
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      } else if (choice == 'print') {
        await ExportService.printPdfLaporan(
          title: title,
          subtitle: 'Tahun: $_tahun',
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content:
                Text('Gagal mengekspor laporan omzet. Silakan coba lagi.')),
      );
    }
  }

  double get _totalOmzet => (_monthlyData ?? []).fold(0, (a, b) => a + b);
  double get _maxBulan => (_monthlyData ?? []).fold(0, (a, b) => a > b ? a : b);
  int get _peakBulanIdx => (_monthlyData ?? []).indexOf(_maxBulan);
  int get _activeMonthCount =>
      (_monthlyData ?? []).where((value) => value > 0).length;
  double get _averageActiveOmzet =>
      _activeMonthCount == 0 ? 0 : _totalOmzet / _activeMonthCount;
  int get _selectedMonthIdx => _bulan - 1;
  double get _selectedMonthOmzet {
    final data = _monthlyData ?? List<double>.filled(12, 0);
    if (_selectedMonthIdx < 0 || _selectedMonthIdx >= data.length) return 0;
    return data[_selectedMonthIdx];
  }

  String _fmtRp(double v) {
    if (v >= 1000000) return 'Rp ${(v / 1000000).toStringAsFixed(1)}Jt';
    if (v >= 1000) return 'Rp ${(v / 1000).toStringAsFixed(0)}Rb';
    return 'Rp ${v.toStringAsFixed(0)}';
  }

  String _fmtRpFull(double v) {
    final value = v.round();
    final s = value.abs().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp ${value < 0 ? '-' : ''}$buf';
  }

  @override
  Widget build(BuildContext context) {
    final tablet = isTabletDevice(context);
    final landscape = isLandscape(context);
    final useSidebar = tablet || landscape;

    return KasirResponsiveScaffold(
      title: 'Omzet Per Bulan',
      navIndex: 4,
      showNavRail: false,
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: GestureDetector(
            onTap: _exportData,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: const BoxDecoration(
                color: AppColors.primaryBrand,
                borderRadius: BorderRadius.zero,
              ),
              child: const Row(
                children: [
                  Icon(Icons.download_rounded, color: Colors.white, size: 15),
                  SizedBox(width: 5),
                  Text(
                    'Ekspor',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
      body:
          useSidebar ? _buildTwoPanelLayout(tablet) : _buildSinglePanelLayout(),
    );
  }

  Widget _buildTwoPanelLayout(bool tablet) {
    final data = _monthlyData ?? List<double>.filled(12, 0);
    return Row(
      children: [
        Container(
          width: tablet ? 260 : 200,
          color: const Color(0xFFF5F7FA),
          child: SingleChildScrollView(
            padding: EdgeInsets.all(tablet ? 20 : 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildFilterDropdown(
                    _showPeriodeSheet, _periode, 'Periode', tablet),
                const SizedBox(height: 10),
                if (_periode == 'Periode Bulanan') ...[
                  _buildFilterDropdown(_showBulanSheet,
                      _bulanNama[_bulan - 1].substring(0, 3), 'Bulan', tablet),
                  const SizedBox(height: 10),
                ],
                _buildFilterDropdown(
                    _showTahunSheet, _tahun.toString(), 'Tahun', tablet),
                const SizedBox(height: 24),
                const Divider(color: Color(0xFFE0E0E0)),
                const SizedBox(height: 16),
                // Stats cards
                _statCard('Total Omzet', _fmtRp(_totalOmzet),
                    Icons.payments_outlined, tablet),
                const SizedBox(height: 10),
                _statCard(
                  'Bulan Terbaik',
                  _maxBulan > 0 && _peakBulanIdx >= 0
                      ? _bulanNama[_peakBulanIdx]
                      : '-',
                  Icons.emoji_events_outlined,
                  tablet,
                ),
                const SizedBox(height: 10),
                _statCard(
                  'Omzet Terbaik',
                  _fmtRp(_maxBulan),
                  Icons.trending_up_rounded,
                  tablet,
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator(color: _kBrand))
              : SingleChildScrollView(child: _buildReportContent(data, tablet)),
        ),
      ],
    );
  }

  Widget _buildSinglePanelLayout() {
    final data = _monthlyData ?? List<double>.filled(12, 0);
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 20),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: _filterTile(_showPeriodeSheet, _periode)),
              const SizedBox(width: 12),
              if (_periode == 'Periode Bulanan') ...[
                Expanded(
                  child: _filterTile(
                    _showBulanSheet,
                    _bulanNama[_bulan - 1].substring(0, 3),
                  ),
                ),
                const SizedBox(width: 6),
              ],
              Expanded(child: _filterTile(_showTahunSheet, _tahun.toString())),
            ],
          ),
          const SizedBox(height: 14),
          if (_isLoading)
            const Padding(
              padding: EdgeInsets.only(top: 80),
              child: CircularProgressIndicator(color: _kBrand),
            )
          else
            _buildReportContent(data, false),
        ],
      ),
    );
  }

  Widget _buildReportContent(List<double> data, bool tablet) {
    return Padding(
      padding: EdgeInsets.fromLTRB(tablet ? 24 : 0, 0, tablet ? 24 : 0, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildOverviewPanel(data, tablet),
          const SizedBox(height: 12),
          _buildBarChart(data, tablet),
          const SizedBox(height: 12),
          _buildMonthlyBreakdown(data, tablet),
        ],
      ),
    );
  }

  Widget _buildOverviewPanel(List<double> data, bool tablet) {
    final peakMonth =
        _maxBulan > 0 && _peakBulanIdx >= 0 ? _bulanNama[_peakBulanIdx] : '-';
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: _kBrand.withValues(alpha: 0.09),
                  borderRadius: BorderRadius.zero,
                ),
                child: const Icon(Icons.bar_chart_rounded,
                    color: _kBrand, size: 21),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Ringkasan Omzet $_tahun',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: tablet ? 17 : 15,
                        fontWeight: FontWeight.w900,
                        color: const Color(0xFF0F172A),
                      ),
                    ),
                    Text(
                      _activeMonthCount == 0
                          ? 'Belum ada omzet pada tahun ini.'
                          : '$_activeMonthCount bulan memiliki transaksi tercatat.',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF64748B),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _summaryMetric(
                  'Total Omzet',
                  _fmtRpFull(_totalOmzet),
                  Icons.payments_outlined,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _summaryMetric(
                  'Rata-rata',
                  _fmtRpFull(_averageActiveOmzet),
                  Icons.insights_rounded,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _summaryMetric(
                  'Bulan Terbaik',
                  peakMonth,
                  Icons.emoji_events_outlined,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _summaryMetric(
                  _periode == 'Periode Bulanan'
                      ? _bulanNama[_selectedMonthIdx]
                      : 'Omzet Terbaik',
                  _periode == 'Periode Bulanan'
                      ? _fmtRpFull(_selectedMonthOmzet)
                      : _fmtRpFull(_maxBulan),
                  Icons.trending_up_rounded,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _summaryMetric(String label, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 16, color: _kBrand),
          const SizedBox(width: 7),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 10.5,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    color: Color(0xFF0F172A),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBarChart(List<double> data, bool tablet) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'Mei',
      'Jun',
      'Jul',
      'Agu',
      'Sep',
      'Okt',
      'Nov',
      'Des',
    ];
    final maxVal = data.fold<double>(0, (a, b) => a > b ? a : b);
    final safeMax = maxVal <= 0 ? 1.0 : maxVal;
    final chartHeight = tablet ? 310.0 : 245.0;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Grafik Omzet Bulanan',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.plusJakartaSans(
                        fontWeight: FontWeight.w900,
                        fontSize: tablet ? 17 : 15,
                        color: const Color(0xFF0F172A),
                      ),
                    ),
                    const Text(
                      'Angka dalam skala ringkas agar mudah dibaca.',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11.5,
                        color: Color(0xFF64748B),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: _kBrand.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.zero,
                ),
                child: Text(
                  'Total ${_fmtRp(_totalOmzet)}',
                  style: const TextStyle(
                    fontSize: 11.5,
                    color: _kBrand,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: chartHeight,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(
                  width: 42,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: List.generate(5, (i) {
                      final value = safeMax * (4 - i) / 4;
                      return Text(
                        _fmtRp(value),
                        style: const TextStyle(
                          fontSize: 9.5,
                          color: Color(0xFF94A3B8),
                          fontWeight: FontWeight.w700,
                        ),
                      );
                    }),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Stack(
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: List.generate(
                          5,
                          (_) => const Divider(
                            height: 1,
                            color: Color(0xFFEFF3F8),
                          ),
                        ),
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: List.generate(12, (i) {
                          final isSelected =
                              _periode == 'Periode Bulanan' && i == _bulan - 1;
                          final isPeak = i == _peakBulanIdx && data[i] > 0;
                          final barHeight =
                              (data[i] / safeMax * (chartHeight - 34))
                                  .clamp(2.0, chartHeight - 34);
                          final color = isSelected
                              ? _kBrand
                              : isPeak
                                  ? const Color(0xFFF59E0B)
                                  : const Color(0xFF94A3B8);
                          return Expanded(
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 2.5),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  if (data[i] > 0 && (isSelected || isPeak))
                                    FittedBox(
                                      fit: BoxFit.scaleDown,
                                      child: Text(
                                        _fmtRp(data[i]),
                                        style: TextStyle(
                                          fontSize: 9,
                                          fontWeight: FontWeight.w900,
                                          color: color,
                                        ),
                                      ),
                                    ),
                                  const SizedBox(height: 4),
                                  Tooltip(
                                    message:
                                        '${_bulanNama[i]}: ${_fmtRpFull(data[i])}',
                                    child: Container(
                                      height: barHeight,
                                      decoration: BoxDecoration(
                                        color: color,
                                        borderRadius: BorderRadius.zero,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    months[i],
                                    style: TextStyle(
                                      fontSize: tablet ? 10 : 8.5,
                                      color: isSelected
                                          ? _kBrand
                                          : const Color(0xFF64748B),
                                      fontWeight: isSelected || isPeak
                                          ? FontWeight.w900
                                          : FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMonthlyBreakdown(List<double> data, bool tablet) {
    final maxVal = data.fold<double>(0, (a, b) => a > b ? a : b);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Rincian Bulanan',
            style: GoogleFonts.plusJakartaSans(
              fontSize: tablet ? 16 : 14,
              fontWeight: FontWeight.w900,
              color: const Color(0xFF0F172A),
            ),
          ),
          const SizedBox(height: 10),
          ...List.generate(12, (i) {
            final value = data[i];
            final ratio = maxVal <= 0 ? 0.0 : value / maxVal;
            final isPeak = value > 0 && i == _peakBulanIdx;
            return Padding(
              padding: EdgeInsets.only(bottom: i == 11 ? 0 : 9),
              child: Row(
                children: [
                  SizedBox(
                    width: 42,
                    child: Text(
                      _bulanNama[i].substring(0, 3),
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: isPeak ? FontWeight.w900 : FontWeight.w700,
                        color: isPeak ? _kBrand : const Color(0xFF64748B),
                      ),
                    ),
                  ),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.zero,
                      child: LinearProgressIndicator(
                        minHeight: 8,
                        value: ratio.clamp(0.0, 1.0),
                        backgroundColor: const Color(0xFFEFF3F8),
                        valueColor: AlwaysStoppedAnimation<Color>(
                          isPeak ? _kBrand : const Color(0xFF94A3B8),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  SizedBox(
                    width: 78,
                    child: Text(
                      value <= 0 ? '-' : _fmtRp(value),
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: isPeak ? FontWeight.w900 : FontWeight.w700,
                        color: isPeak ? _kBrand : const Color(0xFF334155),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _filterTile(VoidCallback onTap, String label) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: const BoxDecoration(
            color: Color(0xFFF5F5F5), borderRadius: BorderRadius.zero),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
                child: Text(label,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 13),
                    overflow: TextOverflow.ellipsis)),
            const Icon(Icons.keyboard_arrow_down_rounded,
                color: _kBrand, size: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterDropdown(
      VoidCallback onTap, String value, String label, bool tablet) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          border: Border.all(color: const Color(0xFFE0E0E0)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(label,
                    style:
                        const TextStyle(fontSize: 10, color: Colors.black45)),
                Text(value,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: tablet ? 14 : 13,
                        color: Colors.black87)),
              ],
            ),
            const Icon(Icons.keyboard_arrow_down_rounded,
                color: _kBrand, size: 20),
          ],
        ),
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon, bool tablet) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE8E8E8)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: _kBrand.withValues(alpha: 0.08),
                borderRadius: BorderRadius.zero),
            child: Icon(icon, color: _kBrand, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style:
                        const TextStyle(fontSize: 10, color: Colors.black45)),
                Text(value,
                    style: TextStyle(
                        fontSize: tablet ? 13 : 12,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87),
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

