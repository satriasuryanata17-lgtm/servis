import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../widgets/kasir_dialog.dart';

const Color _kBrand = AppColors.primaryBrand;

//
//  RIWAYAT PESANAN TERHAPUS  --  Responsive (Phone + Tablet/Landscape)
//
class RiwayatPesananTerhapusScreen extends ConsumerStatefulWidget {
  const RiwayatPesananTerhapusScreen({super.key});

  @override
  ConsumerState<RiwayatPesananTerhapusScreen> createState() =>
      _RiwayatPesananTerhapusScreenState();
}

class _RiwayatPesananTerhapusScreenState
    extends ConsumerState<RiwayatPesananTerhapusScreen> {
  List<Transaction> _deleted = [];
  Map<int, List<TransactionItem>> _itemsMap = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await DBHelper.instance.getDeletedTransactions();
    final map = <int, List<TransactionItem>>{};
    for (final tx in list) {
      if (tx.id != null) {
        map[tx.id!] = await DBHelper.instance.getTransactionItems(tx.id!);
      }
    }
    if (mounted) {
      setState(() {
        _deleted = list;
        _itemsMap = map;
        _loading = false;
      });
    }
  }

  bool _isWide(BuildContext context) =>
      MediaQuery.of(context).size.width >= 720;

  String _formatQty(TransactionItem item) {
    final qty = item.qty
        .toStringAsFixed(2)
        .replaceAll(RegExp(r'0+$'), '')
        .replaceAll(RegExp(r'\.$'), '')
        .replaceAll('.', ',');
    final unit = item.unit?.trim();
    if (unit != null && unit.isNotEmpty) return '$qty $unit';
    return '${qty}x';
  }

  String _formatDate(String? raw) {
    if (raw == null || raw.isEmpty) return '-';
    try {
      final dt = DateTime.parse(raw).toLocal();
      const months = [
        '',
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'Mei',
        'Jun',
        'Jul',
        'Agu',
        'Sep',
        'Okt',
        'Nov',
        'Des'
      ];
      final h = dt.hour.toString().padLeft(2, '0');
      final m = dt.minute.toString().padLeft(2, '0');
      return '${dt.day} ${months[dt.month]} ${dt.year}  $h:$m';
    } catch (_) {
      return raw;
    }
  }

  String _formatRp(int amount) {
    final s = amount.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp ${buf.toString()}';
  }

  String _paymentLabel(String method) {
    switch (method.toLowerCase()) {
      case 'cash':
        return 'Tunai';
      case 'qris':
        return 'QRIS';
      case 'transfer':
        return 'Transfer';
      default:
        return method;
    }
  }

  Color _paymentColor(String method) {
    switch (method.toLowerCase()) {
      case 'cash':
        return const Color(0xFF2E7D32);
      case 'qris':
        return const Color(0xFF1565C0);
      case 'transfer':
        return const Color(0xFF6A1B9A);
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final wide = _isWide(context);

    return Scaffold(
      backgroundColor: wide ? const Color(0xFFF5F5F7) : const Color(0xFFF5F5F5),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new_rounded,
                        color: _kBrand, size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                  const SizedBox(width: 4),
                  const Expanded(
                    child: Text(
                      'Riwayat Penjualan Terhapus',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87),
                    ),
                  ),
                  if (!_loading)
                    Text(
                      '${_deleted.length} data',
                      style:
                          TextStyle(fontSize: 13, color: Colors.grey.shade500),
                    ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              color: _kBrand.withValues(alpha: 0.08),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: [
                  Icon(Icons.info_outline_rounded,
                      size: 16, color: _kBrand.withValues(alpha: 0.8)),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text(
                      'Penjualan terhapus tersimpan hingga 3 bulan. Anda dapat memulihkan transaksi jika diperlukan.',
                      style: TextStyle(
                          fontSize: 12, color: Colors.black54, height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _loading
                  ? const Center(
                      child: CircularProgressIndicator(color: _kBrand))
                  : _deleted.isEmpty
                      ? _emptyState()
                      : RefreshIndicator(
                          color: _kBrand,
                          onRefresh: _load,
                          child: wide ? _buildTabletGrid() : _buildPhoneList(),
                        ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhoneList() {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 24),
      itemCount: _deleted.length,
      itemBuilder: (_, i) => _buildCard(_deleted[i]),
    );
  }

  Widget _buildTabletGrid() {
    return LayoutBuilder(
      builder: (context, constraints) {
        // Decide columns based on actual width
        final cols = constraints.maxWidth >= 1100 ? 3 : 2;
        return GridView.builder(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: cols,
            crossAxisSpacing: 14,
            mainAxisSpacing: 14,
            childAspectRatio: cols == 3 ? 2.1 : 2.25,
          ),
          itemCount: _deleted.length,
          itemBuilder: (_, i) => _buildCard(_deleted[i]),
        );
      },
    );
  }

  Widget _buildCard(Transaction tx) {
    final items = _itemsMap[tx.id] ?? [];
    final itemCount = items.fold<double>(0, (sum, i) => sum + i.qty);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
            color: AppColors.border.withValues(alpha: 0.5), width: 1),
        boxShadow: AppShadow.soft,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    'Dihapus: ${_formatDate(tx.deletedAt)}',
                    style: AppText.caption.copyWith(
                      color: AppColors.danger,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color:
                        _paymentColor(tx.paymentMethod).withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    _paymentLabel(tx.paymentMethod),
                    style: AppText.label.copyWith(
                      color: _paymentColor(tx.paymentMethod),
                      fontSize: 10,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: AppColors.divider),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Transaksi #${tx.id}',
                  style: AppText.h3.copyWith(fontSize: 15),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(Icons.history,
                        size: 14, color: AppColors.textMuted),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        'Terjual: ${_formatDate(tx.createdAt)}',
                        style: AppText.caption,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
                if (tx.customerName != null && tx.customerName!.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.person_outline,
                          size: 14, color: AppColors.textMuted),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          tx.customerName!,
                          style: AppText.bodySmall
                              .copyWith(fontWeight: FontWeight.w500),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],

                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Divider(height: 1, color: AppColors.divider),
                ),

                // Item List (Minimalist)
                if (items.isNotEmpty) ...[
                  ...items.take(1).map((item) => Padding(
                        padding: const EdgeInsets.only(bottom: 5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                '${item.productName} x ${_formatQty(item)}',
                                style: AppText.bodySmall,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Text(
                              _formatRp(item.subtotal),
                              style: AppText.bodySmall.copyWith(
                                fontWeight: FontWeight.w600,
                                color: AppColors.textTitle,
                              ),
                            ),
                          ],
                        ),
                      )),
                  if (items.length > 1)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text(
                        '+ ${items.length - 1} produk lainnya',
                        style: AppText.caption
                            .copyWith(fontStyle: FontStyle.italic),
                      ),
                    ),
                  const SizedBox(height: 8),
                ],

                // Total
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        _formatRp(tx.grandTotal),
                        style: AppText.h3.copyWith(
                          color: AppColors.textTitle,
                          fontWeight: FontWeight.w900,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${itemCount.toStringAsFixed(1).replaceAll(RegExp(r'\.0$'), '')} Item',
                      style: AppText.label,
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // Professional Button (Flat Secondary action)
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    onPressed: () => _confirmRestore(tx),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryBrand,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: EdgeInsets.zero,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(6)),
                      ),
                    ),
                    child: Text(
                      'Pulihkan Pesanan',
                      style: AppText.label.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmRestore(Transaction tx) async {
    final confirmed = await showKasirConfirmDialog(
      context,
      title: 'Pulihkan Pesanan?',
      message:
          'Transaksi #${tx.id} akan dikembalikan ke riwayat penjualan. Data stok dan saldo akan disesuaikan.',
      confirmLabel: 'Pulihkan',
      confirmColor: AppColors.primaryBrand,
      icon: Icons.history_rounded,
      iconColor: AppColors.primaryBrand,
    );

    if (confirmed == true) {
      await ref.read(transactionsProvider.notifier).restoreTransaction(tx.id!);
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Pesanan Berhasil Dipulihkan'),
          backgroundColor: AppColors.primaryBrand,
          behavior: SnackBarBehavior.floating,
        ),
      );
      _load();
    }
  }

  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                color: AppColors.divider,
                shape: BoxShape.rectangle,
              ),
              child: const Icon(
                AppIcons.recycleBin,
                size: 48,
                color: AppColors.textMuted,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Riwayat Kosong',
              style: AppText.h2,
            ),
            const SizedBox(height: 8),
            Text(
              'Transaksi yang Anda hapus dalam 3 bulan terakhir akan muncul di sini untuk dipulihkan.',
              textAlign: TextAlign.center,
              style: AppText.caption,
            ),
          ],
        ),
      ),
    );
  }
}

