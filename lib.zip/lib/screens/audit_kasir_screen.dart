import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../core/theme.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';

class AuditKasirScreen extends ConsumerStatefulWidget {
  const AuditKasirScreen({super.key});

  @override
  ConsumerState<AuditKasirScreen> createState() => _AuditKasirScreenState();
}

class _AuditKasirScreenState extends ConsumerState<AuditKasirScreen> {
  String _filter = 'all';
  final _currency = NumberFormat.decimalPattern('id_ID');

  static const _filterItems = [
    ('all', 'Semua aktivitas'),
    ('shift_opened', 'Buka shift'),
    ('shift_cash_counted', 'Hitung kas shift'),
    ('shift_closed', 'Tutup shift'),
    ('transaction_created', 'Transaksi dibuat'),
    ('transaction_deleted', 'Transaksi dihapus'),
    ('customer_deleted', 'Pelanggan dihapus'),
    ('discount_applied', 'Diskon diberikan'),
    ('wallet_adjusted', 'Koreksi saldo'),
    ('piutang_payment', 'Pembayaran piutang'),
  ];

  @override
  Widget build(BuildContext context) {
    final logsAsync = ref.watch(auditLogsProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      appBar: AppBar(
        title: const Text('Audit Kasir'),
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF111827),
        surfaceTintColor: Colors.transparent,
      ),
      body: logsAsync.when(
        skipLoadingOnRefresh: true,
        skipLoadingOnReload: true,
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => _EmptyState(
          icon: Icons.error_outline_rounded,
          title: 'Audit belum bisa dimuat',
          subtitle: '$e',
        ),
        data: (logs) {
          final filtered = _filter == 'all'
              ? logs
              : logs.where((log) => log.action == _filter).toList();
          final showEmpty = filtered.isEmpty;
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(auditLogsProvider),
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
              itemCount: 4 + (showEmpty ? 1 : filtered.length),
              itemBuilder: (context, index) {
                if (index == 0) {
                  return _SummaryPanel(logs: logs, formatRp: _formatRp);
                }
                if (index == 1 || index == 3) {
                  return const SizedBox(height: 10);
                }
                if (index == 2) {
                  return _FilterDropdown(
                    items: _filterItems,
                    selected: _filter,
                    onSelected: (value) => setState(() => _filter = value),
                  );
                }
                if (showEmpty) {
                  return const _EmptyState(
                    icon: Icons.manage_search_rounded,
                    title: 'Belum ada aktivitas',
                    subtitle:
                        'Audit akan terisi otomatis saat kasir buka shift, transaksi, diskon, koreksi saldo, dan tutup kasir.',
                  );
                }
                final log = filtered[index - 4];
                return _AuditTile(
                  log: log,
                  amountLabel: _amountLabel(log),
                );
              },
            ),
          );
        },
      ),
    );
  }

  String _formatRp(int value) {
    final sign = value < 0 ? '-' : '';
    return '${sign}Rp${_currency.format(value.abs())}';
  }

  String _amountLabel(AuditLog log) {
    if (log.amount == 0) return '';
    if (log.action == 'shift_closed' || log.action == 'shift_cash_counted') {
      return 'Selisih ${_formatRp(log.amount)}';
    }
    return _formatRp(log.amount);
  }
}

class _SummaryPanel extends StatelessWidget {
  final List<AuditLog> logs;
  final String Function(int value) formatRp;

  const _SummaryPanel({required this.logs, required this.formatRp});

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final todayPrefix = DateTime(today.year, today.month, today.day)
        .toIso8601String()
        .substring(0, 10);
    final todayLogs =
        logs.where((log) => log.createdAt.startsWith(todayPrefix)).toList();
    final deleted = todayLogs
        .where((log) =>
            log.action == 'transaction_deleted' ||
            log.action == 'customer_deleted')
        .length;
    final discounts = todayLogs
        .where((log) => log.action == 'discount_applied')
        .fold<int>(0, (sum, log) => sum + log.amount);
    final cashDiff = todayLogs
        .where((log) => log.action == 'shift_closed')
        .fold<int>(0, (sum, log) => sum + log.amount);

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE4E7EC)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Ringkasan Hari Ini',
            style: AppText.h2.copyWith(
              fontSize: 17,
              color: const Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _MiniStat(
                  label: 'Aktivitas',
                  value: '${todayLogs.length}',
                  icon: Icons.timeline_rounded,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _MiniStat(
                  label: 'Hapus',
                  value: '$deleted',
                  icon: AppIcons.recycleBin,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _MiniStat(
                  label: 'Diskon',
                  value: formatRp(discounts),
                  icon: Icons.local_offer_outlined,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _MiniStat(
                  label: 'Selisih Kas',
                  value: formatRp(cashDiff),
                  icon: Icons.account_balance_wallet_outlined,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _MiniStat({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE8ECF1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 17, color: AppColors.primaryBrand),
          const SizedBox(height: 7),
          Text(
            label,
            style: const TextStyle(color: Color(0xFF667085), fontSize: 12),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            softWrap: true,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
          ),
        ],
      ),
    );
  }
}

class _FilterDropdown extends StatelessWidget {
  final List<(String, String)> items;
  final String selected;
  final ValueChanged<String> onSelected;

  const _FilterDropdown({
    required this.items,
    required this.selected,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE4E7EC)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: selected,
          isExpanded: true,
          dropdownColor: Colors.white,
          borderRadius: BorderRadius.zero,
          icon: const Icon(Icons.keyboard_arrow_down_rounded,
              color: Color(0xFF475467)),
          style: const TextStyle(
            color: Color(0xFF111827),
            fontWeight: FontWeight.w700,
            fontSize: 14,
          ),
          items: [
            for (final item in items)
              DropdownMenuItem(
                value: item.$1,
                child: Row(
                  children: [
                    Icon(
                      _filterIcon(item.$1),
                      size: 17,
                      color: AppColors.primaryBrand,
                    ),
                    const SizedBox(width: 10),
                    Text(item.$2),
                  ],
                ),
              ),
          ],
          onChanged: (value) {
            if (value != null) onSelected(value);
          },
        ),
      ),
    );
  }

  IconData _filterIcon(String value) {
    switch (value) {
      case 'shift_opened':
        return Icons.login_rounded;
      case 'shift_cash_counted':
        return Icons.calculate_outlined;
      case 'shift_closed':
        return Icons.fact_check_outlined;
      case 'transaction_created':
        return Icons.receipt_long_outlined;
      case 'transaction_deleted':
        return AppIcons.recycleBin;
      case 'customer_deleted':
        return Icons.person_remove_outlined;
      case 'discount_applied':
        return Icons.local_offer_outlined;
      case 'wallet_adjusted':
        return Icons.tune_rounded;
      case 'piutang_payment':
        return Icons.payments_outlined;
      default:
        return Icons.filter_list_rounded;
    }
  }
}

class _AuditTile extends StatelessWidget {
  final AuditLog log;
  final String amountLabel;

  const _AuditTile({required this.log, required this.amountLabel});

  @override
  Widget build(BuildContext context) {
    final time = DateTime.tryParse(log.createdAt);
    final meta = _readMetadata(log.metadataJson);
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE4E7EC)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: _color.withValues(alpha: 0.12),
            ),
            child: Icon(_icon, color: _color, size: 20),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(_title,
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 14)),
                    ),
                    if (amountLabel.isNotEmpty)
                      Flexible(
                        child: Text(
                          amountLabel,
                          textAlign: TextAlign.end,
                          softWrap: true,
                          style: TextStyle(
                            color: _color,
                            fontWeight: FontWeight.w800,
                            fontSize: 12.5,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(log.note.isEmpty ? _subtitle : log.note,
                    style: const TextStyle(
                        color: Color(0xFF475467), height: 1.28, fontSize: 13)),
                const SizedBox(height: 7),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    _Tag(
                      Icons.person_outline_rounded,
                      '${log.staffName}${log.staffRole.isEmpty ? '' : ' - ${log.staffRole}'}',
                    ),
                    if (time != null)
                      _Tag(Icons.schedule_rounded,
                          DateFormat('dd MMM HH:mm', 'id_ID').format(time)),
                    if (log.entityId != null)
                      _Tag(Icons.tag_rounded, '#${log.entityId}'),
                    ...meta.entries.take(3).map(
                          (entry) => _Tag(
                            Icons.info_outline_rounded,
                            '${_readableKey(entry.key)}: ${entry.value}',
                          ),
                        ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Map<String, dynamic> _readMetadata(String? raw) {
    if (raw == null || raw.trim().isEmpty) return {};
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) return decoded;
    } catch (_) {}
    return {};
  }

  String _readableKey(String key) {
    switch (key) {
      case 'opening_cash':
        return 'Modal awal';
      case 'closing_cash':
        return 'Kas fisik';
      case 'expected_cash':
        return 'Kas sistem';
      case 'actual_cash':
        return 'Kas fisik aktual';
      case 'difference':
        return 'Selisih';
      case 'total_transactions':
        return 'Transaksi';
      case 'payment_method':
        return 'Metode';
      case 'payment_status':
        return 'Status';
      case 'item_count':
        return 'Item';
      default:
        return key.replaceAll('_', ' ');
    }
  }

  String get _title {
    switch (log.action) {
      case 'shift_opened':
        return 'Buka Shift';
      case 'shift_closed':
        return 'Tutup Kasir';
      case 'shift_cash_counted':
        return 'Hitung Kas Shift';
      case 'transaction_created':
        return 'Transaksi Dibuat';
      case 'transaction_deleted':
        return 'Transaksi Dihapus';
      case 'customer_deleted':
        return 'Pelanggan Dihapus';
      case 'discount_applied':
        return 'Diskon Diberikan';
      case 'wallet_adjusted':
        return 'Koreksi Saldo';
      case 'piutang_payment':
        return 'Pembayaran Piutang';
      default:
        return 'Aktivitas';
    }
  }

  String get _subtitle => 'Aktivitas tercatat otomatis oleh sistem audit.';

  IconData get _icon {
    switch (log.action) {
      case 'shift_opened':
        return Icons.login_rounded;
      case 'shift_cash_counted':
        return Icons.calculate_outlined;
      case 'shift_closed':
        return Icons.fact_check_outlined;
      case 'transaction_created':
        return Icons.receipt_long_outlined;
      case 'transaction_deleted':
        return AppIcons.recycleBin;
      case 'customer_deleted':
        return Icons.person_remove_outlined;
      case 'discount_applied':
        return Icons.local_offer_outlined;
      case 'wallet_adjusted':
        return Icons.tune_rounded;
      case 'piutang_payment':
        return Icons.payments_outlined;
      default:
        return Icons.timeline_rounded;
    }
  }

  Color get _color {
    switch (log.action) {
      case 'transaction_deleted':
      case 'customer_deleted':
        return const Color(0xFFB42318);
      case 'discount_applied':
        return const Color(0xFFB54708);
      case 'shift_closed':
      case 'shift_cash_counted':
        return const Color(0xFF175CD3);
      default:
        return AppColors.primaryBrand;
    }
  }
}

class _Tag extends StatelessWidget {
  final IconData icon;
  final String label;

  const _Tag(this.icon, this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFFF2F4F7),
        border: Border.all(color: const Color(0xFFE7EAF0)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: const Color(0xFF667085)),
          const SizedBox(width: 4),
          Text(label,
              style: const TextStyle(fontSize: 11.5, color: Color(0xFF475467))),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _EmptyState({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 24),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE4E7EC)),
      ),
      child: Column(
        children: [
          Icon(icon, size: 42, color: AppColors.primaryBrand),
          const SizedBox(height: 12),
          Text(title,
              textAlign: TextAlign.center,
              style:
                  const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 6),
          Text(subtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xFF667085), height: 1.4)),
        ],
      ),
    );
  }
}

