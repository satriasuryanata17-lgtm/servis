import 'package:flutter/material.dart';
import 'daftar_karyawan_screen.dart';
import 'riwayat_tutup_kasir_screen.dart';
import 'pengaturan_shift_screen.dart';
import 'audit_kasir_screen.dart';
import '../widgets/kasir_drawer.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';

const Color _kBrand = AppColors.primaryBrand;

class KaryawanScreen extends StatelessWidget {
  const KaryawanScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tablet = KasirLayout.isTablet(context);
    final landscape = KasirLayout.isLandscape(context);
    final wide =
        tablet || (landscape && MediaQuery.of(context).size.width >= 720);

    return KasirResponsiveScaffold(
      title: 'Karyawan',
      navIndex: 6,
      drawer: const KasirDrawer(),
      backgroundColor: wide ? const Color(0xFFF5F6FA) : Colors.white,
      body: wide ? _buildWideBody(context) : _buildNarrowBody(context),
    );
  }

  Widget _buildWideBody(BuildContext ctx) {
    final menus = _menus(ctx);
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section title
          const Padding(
            padding: EdgeInsets.only(bottom: 16),
            child: Text(
              'Menu Manajemen Karyawan',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Colors.black45,
                letterSpacing: 0.5,
              ),
            ),
          ),
          // Grid of cards
          LayoutBuilder(builder: (ctx2, c2) {
            final crossCount = c2.maxWidth > 700 ? 3 : 2;
            return GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: crossCount,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 1.8,
              children: menus
                  .map((m) => _MenuCard(
                        title: m.title,
                        subtitle: m.subtitle,
                        icon: m.icon,
                        onTap: m.onTap,
                      ))
                  .toList(),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildNarrowBody(BuildContext ctx) {
    final menus = _menus(ctx);
    return ListView.separated(
      itemCount: menus.length,
      separatorBuilder: (_, __) =>
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
      itemBuilder: (_, i) => _MenuItem(
        title: menus[i].title,
        subtitle: menus[i].subtitle,
        onTap: menus[i].onTap,
      ),
    );
  }

  List<_MenuDef> _menus(BuildContext ctx) => [
        _MenuDef(
          title: 'Daftar Karyawan',
          subtitle: 'Lihat dan kelola semua karyawan',
          icon: Icons.badge_outlined,
          onTap: () => Navigator.push(
            ctx,
            MaterialPageRoute(builder: (_) => const DaftarKaryawanScreen()),
          ),
        ),
        _MenuDef(
          title: 'Riwayat Shift',
          subtitle: 'Jumlah dan riwayat penutupan shift',
          icon: Icons.point_of_sale_outlined,
          onTap: () => Navigator.push(
            ctx,
            MaterialPageRoute(builder: (_) => const RiwayatTutupKasirScreen()),
          ),
        ),
        _MenuDef(
          title: 'Audit Kasir',
          subtitle:
              'Pantau aktivitas shift, pembayaran piutang, hapus order, dan tutup kasir',
          icon: Icons.manage_search_outlined,
          onTap: () => Navigator.push(
            ctx,
            MaterialPageRoute(builder: (_) => const AuditKasirScreen()),
          ),
        ),
        _MenuDef(
          title: 'Manajemen Shift',
          subtitle: 'Atur nama dan jadwal shift kerja',
          icon: Icons.schedule_outlined,
          onTap: () => Navigator.push(
            ctx,
            MaterialPageRoute(builder: (_) => const PengaturanShiftScreen()),
          ),
        ),
      ];
}

class _MenuDef {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  const _MenuDef({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
  });
}

class _MenuCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  const _MenuCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.zero,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.zero,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFEEEEEE)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.03),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _kBrand.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Icon(icon, color: _kBrand, size: 22),
                  ),
                  const Icon(Icons.arrow_forward_ios_rounded,
                      color: _kBrand, size: 14),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      )),
                  const SizedBox(height: 3),
                  Text(subtitle,
                      style:
                          const TextStyle(fontSize: 12, color: Colors.black45),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MenuItem extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _MenuItem({
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87)),
                const SizedBox(height: 3),
                Text(subtitle,
                    style:
                        const TextStyle(fontSize: 13, color: Colors.black45)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: _kBrand, size: 24),
        ]),
      ),
    );
  }
}

