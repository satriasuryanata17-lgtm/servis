import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../database/db_helper.dart';
import '../providers/providers.dart';
import '../models/db_models.dart';
import '../core/theme.dart';
import '../utils/modern_ui_helpers.dart';
import '../widgets/kasir_dialog.dart';

const Color _kBrand = AppColors.primaryBrand;

bool _isWide(BuildContext ctx) {
  final mq = MediaQuery.of(ctx);
  return mq.size.width >= 720 ||
      (mq.orientation == Orientation.landscape && mq.size.width >= 600);
}

class KategoriScreen extends ConsumerStatefulWidget {
  const KategoriScreen({super.key});

  @override
  ConsumerState<KategoriScreen> createState() => _KategoriScreenState();
}

class _KategoriScreenState extends ConsumerState<KategoriScreen> {
  // For wide mode: inline edit panel
  Category? _editingCategory; // null = add new
  bool _showingEditPanel = false;
  final _editCtrl = TextEditingController();
  final _editFocus = FocusNode();

  @override
  void dispose() {
    _editCtrl.dispose();
    _editFocus.dispose();
    super.dispose();
  }

  void _openEditPanel(Category? existing) {
    if (existing != null && _isDefaultCategory(existing)) {
      _showDefaultCategorySnack();
      return;
    }
    setState(() {
      _editingCategory = existing;
      _showingEditPanel = true;
      _editCtrl.text = existing?.name ?? '';
    });
    Future.delayed(const Duration(milliseconds: 50), () {
      if (mounted) _editFocus.requestFocus();
    });
  }

  void _closeEditPanel() {
    setState(() => _showingEditPanel = false);
    _editCtrl.clear();
  }

  Future<void> _saveCategory() async {
    final name = _editCtrl.text.trim();
    if (name.isEmpty) return;
    if (DBHelper.isDefaultCategoryName(name)) {
      ModernSnackBar.error(
        context: context,
        message: 'Nama "Semua" dipakai untuk kategori sistem.',
      );
      return;
    }
    if (_editingCategory == null) {
      await ref
          .read(categoriesProvider.notifier)
          .addCategory(name, durationHours: 0);
    } else {
      await ref
          .read(categoriesProvider.notifier)
          .updateCategory(_editingCategory!.id!, name, durationHours: 0);
    }
    if (mounted) _closeEditPanel();
  }

  Future<void> _confirmDelete(Category cat) async {
    if (_isDefaultCategory(cat)) {
      _showDefaultCategorySnack();
      return;
    }
    final count =
        await ref.read(categoriesProvider.notifier).checkProductCount(cat.id!);
    if (!mounted) return;

    if (count > 0) {
      final ok = await showKasirConfirmDialog(
        context,
        title: 'Kategori Berisi Layanan',
        message:
            'Kategori "${cat.name}" berisi $count layanan. Jika dihapus, semua layanan ini akan dipindahkan ke kategori "Semua/Umum". Lanjutkan?',
        icon: Icons.warning_rounded,
        iconColor: Colors.orange,
        confirmLabel: 'Ya, Hapus',
      );
      if (ok == true) {
        if (!mounted) return;
        try {
          await ref.read(categoriesProvider.notifier).deleteCategory(cat.id!);
          if (_editingCategory?.id == cat.id && mounted) _closeEditPanel();
          if (mounted) {
            ModernSnackBar.show(
              context: context,
              message: 'Kategori berhasil dihapus',
            );
          }
        } catch (e) {
          if (!mounted) return;
          ModernSnackBar.error(
            context: context,
            message:
                'Kategori tidak bisa dihapus. ${e.toString().replaceAll('Exception: ', '')}',
          );
        }
      }
    } else {
      final ok = await showKasirConfirmDialog(
        context,
        title: 'Hapus Kategori?',
        message: 'Apakah Anda yakin ingin menghapus kategori "${cat.name}"?',
      );
      if (ok == true) {
        if (!mounted) return;
        try {
          await ref.read(categoriesProvider.notifier).deleteCategory(cat.id!);
          if (_editingCategory?.id == cat.id && mounted) _closeEditPanel();
          if (mounted) {
            ModernSnackBar.show(
              context: context,
              message: 'Kategori berhasil dihapus',
            );
          }
        } catch (e) {
          if (!mounted) return;
          ModernSnackBar.error(
            context: context,
            message:
                'Kategori tidak bisa dihapus. ${e.toString().replaceAll('Exception: ', '')}',
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final cats = ref.watch(categoriesProvider);

    return LayoutBuilder(builder: (ctx, constraints) {
      final wide = _isWide(ctx);
      final isLandscape =
          MediaQuery.of(ctx).orientation == Orientation.landscape;
      return Scaffold(
        backgroundColor: AppColors.background,
        appBar: _buildAppBar(wide, ctx),
        body: wide ? _buildWideBody(ctx, cats) : _buildNarrowBody(ctx, cats),
        // Narrow: bottom add button (only if not landscape)
        bottomNavigationBar:
            (wide || isLandscape) ? null : _buildAddButton(ctx, wide: false),
      );
    });
  }

  bool _isDefaultCategory(Category cat) =>
      DBHelper.isDefaultCategoryName(cat.name);

  void _showDefaultCategorySnack() {
    ModernSnackBar.error(
      context: context,
      message: 'Kategori "Semua" adalah kategori sistem dan tidak bisa diubah.',
    );
  }

  PreferredSizeWidget _buildAppBar(bool wide, BuildContext context) {
    final isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;
    return AppBar(
      backgroundColor: AppColors.surface,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarIconBrightness: Brightness.dark,
        statusBarColor: Colors.transparent,
      ),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new, color: _kBrand, size: 18),
        onPressed: () => Navigator.pop(context),
      ),
      title: Text(
        'Kelola Kategori',
        style: AppText.h2,
      ),
      centerTitle: true,
      shape: const Border(
        bottom: BorderSide(color: AppColors.divider, width: 0.5),
      ),
      actions: [
        if (!wide && isLandscape)
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: TextButton.icon(
              onPressed: () => _showAddEditDialog(null),
              icon: const Icon(Icons.add_rounded, size: 18, color: _kBrand),
              label: const Text('Tambah',
                  style:
                      TextStyle(color: _kBrand, fontWeight: FontWeight.bold)),
            ),
          ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(color: const Color(0xFFEEEEEE), height: 1),
      ),
    );
  }

  Widget _buildWideBody(BuildContext ctx, List<Category> cats) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // LEFT: list
        SizedBox(
          width: 360,
          child: Column(
            children: [
              Expanded(
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    // Summary bar
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 16),
                      color: Colors.white,
                      child: Row(children: [
                        Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: _kBrand.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: const Icon(Icons.category_outlined,
                              color: _kBrand, size: 16),
                        ),
                        const SizedBox(width: 12),
                        Text('${cats.length} Kategori',
                            style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF111111))),
                      ]),
                    ),
                    const Divider(height: 1, color: Color(0xFFEEEEEE)),
                    // Category items
                    ...cats
                        .map((cat) => _buildCategoryTile(ctx, cat, wide: true)),
                  ],
                ),
              ),
            ],
          ),
        ),

        const VerticalDivider(width: 1, color: Color(0xFFEEEEEE)),

        // RIGHT: edit panel
        Expanded(
          child: Column(
            children: [
              Expanded(
                child: _showingEditPanel
                    ? _buildEditPanel()
                    : _buildEditPlaceholder(),
              ),
              _buildWideAddButton(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildNarrowBody(BuildContext ctx, List<Category> cats) {
    if (cats.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.category_outlined, size: 70, color: Colors.grey[200]),
            const SizedBox(height: 16),
            const Text(
              'Daftar kategori masih kosong',
              style: TextStyle(
                  color: Colors.grey,
                  fontSize: 15,
                  fontWeight: FontWeight.w500),
            ),
          ],
        ),
      );
    }
    return _buildCategoryList(cats, wide: false);
  }

  Widget _buildCategoryList(List<Category> cats, {required bool wide}) {
    if (cats.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.category_outlined, size: 56, color: Colors.grey[200]),
              const SizedBox(height: 12),
              const Text('Belum ada kategori',
                  style: TextStyle(color: Colors.grey)),
            ],
          ),
        ),
      );
    }

    return ListView.builder(
      itemCount: cats.length,
      padding: const EdgeInsets.symmetric(vertical: 10),
      itemBuilder: (context, i) =>
          _buildCategoryTile(context, cats[i], wide: wide),
    );
  }

  Widget _buildCategoryTile(BuildContext context, Category cat,
      {required bool wide}) {
    final selected = wide && _editingCategory?.id == cat.id;
    final isDefault = _isDefaultCategory(cat);
    final counts = ref.watch(categoryProductCountsProvider).value ?? {};
    final productCount = counts[cat.id] ?? 0;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Material(
        color: selected ? _kBrand.withValues(alpha: 0.05) : Colors.white,
        shape: Border.all(
            color: selected
                ? _kBrand.withValues(alpha: 0.3)
                : const Color(0xFFEEEEEE)),
        child: InkWell(
          onTap: () {
            if (isDefault) {
              _showDefaultCategorySnack();
              return;
            }
            if (wide) {
              _openEditPanel(cat);
            } else {
              _showAddEditDialog(cat);
            }
          },
          child: Padding(
            padding: EdgeInsets.symmetric(
                horizontal: 16,
                vertical: wide
                    ? 16
                    : (MediaQuery.of(context).orientation ==
                            Orientation.landscape
                        ? 10
                        : 16)),
            child: Row(children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: _kBrand.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.zero,
                ),
                child: const Icon(Icons.category_rounded,
                    color: _kBrand, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      cat.name ?? '-',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: (MediaQuery.of(context).orientation ==
                                    Orientation.landscape &&
                                !wide)
                            ? 14
                            : 15,
                        color: selected ? _kBrand : const Color(0xFF111111),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '$productCount Layanan',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: selected
                            ? _kBrand.withValues(alpha: 0.7)
                            : Colors.grey.shade500,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              if (selected)
                const Icon(Icons.edit_rounded, color: _kBrand, size: 16),
              const SizedBox(width: 8),
              if (isDefault)
                IconButton(
                  icon: Icon(Icons.lock_outline_rounded,
                      color: Colors.grey.shade400, size: 18),
                  onPressed: _showDefaultCategorySnack,
                  visualDensity: VisualDensity.compact,
                )
              else
                IconButton(
                  icon: Icon(AppIcons.recycleBin,
                      color: Colors.grey.shade400, size: 18),
                  onPressed: () => _confirmDelete(cat),
                  visualDensity: VisualDensity.compact,
                ),
              if (!wide)
                Icon(Icons.chevron_right_rounded,
                    color: Colors.grey.shade300, size: 20),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildEditPanel() {
    final isAdd = _editingCategory == null;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Panel header
          Row(children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _kBrand.withValues(alpha: 0.08),
                borderRadius: BorderRadius.zero,
              ),
              child: Icon(
                isAdd ? Icons.add_circle_outline : Icons.edit_outlined,
                color: _kBrand,
                size: 22,
              ),
            ),
            const SizedBox(width: 14),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                isAdd ? 'Kategori Baru' : 'Perbarui Kategori',
                style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.5),
              ),
              Text(
                isAdd
                    ? 'Tambah kategori produk baru'
                    : 'Edit nama kategori "${_editingCategory?.name}"',
                style: const TextStyle(fontSize: 13, color: Colors.black45),
              ),
            ]),
          ]),
          const SizedBox(height: 32),

          // Field
          const Text('Nama Kategori',
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87)),
          const SizedBox(height: 8),
          TextField(
            controller: _editCtrl,
            focusNode: _editFocus,
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
            decoration: InputDecoration(
              hintText: 'Misal: HP, Laptop, AC, TV...',
              hintStyle: TextStyle(color: Colors.grey.shade400),
              filled: true,
              fillColor: const Color(0xFFF8F9FA),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Colors.grey.shade200),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Colors.grey.shade200),
              ),
              focusedBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: _kBrand, width: 1.5),
              ),
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            ),
            onSubmitted: (_) => _saveCategory(),
          ),
          const SizedBox(height: 16),
          const SizedBox(height: 16),

          // Buttons
          Row(children: [
            Expanded(
              child: OutlinedButton(
                onPressed: _closeEditPanel,
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  side: BorderSide(color: Colors.grey.shade300),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
                child: Text('Batal',
                    style: TextStyle(
                        color: Colors.grey.shade600,
                        fontWeight: FontWeight.w700)),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton(
                onPressed: _saveCategory,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _kBrand,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                  elevation: 0,
                ),
                child: const Text('Simpan',
                    style:
                        TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              ),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _buildEditPlaceholder() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.edit_note_rounded, size: 64, color: Colors.grey[200]),
          const SizedBox(height: 16),
          const Text('Pilih kategori untuk mengedit',
              style: TextStyle(color: Colors.black38, fontSize: 14)),
          const SizedBox(height: 6),
          const Text('Gunakan tombol di bawah untuk menambah kategori baru.',
              style: TextStyle(color: Colors.black26, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildWideAddButton() {
    return SafeArea(
      top: false,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(24, 10, 24, 16),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Colors.grey.shade100)),
        ),
        child: SizedBox(
          height: 52,
          child: ElevatedButton.icon(
            onPressed: () => _openEditPanel(null),
            icon: const Icon(Icons.add_rounded, size: 20),
            label: const Text(
              'Tambah Kategori',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.zero,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAddButton(BuildContext ctx, {required bool wide}) {
    return Container(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        bottom: MediaQuery.of(ctx).padding.bottom + 16,
        top: 16,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey.shade100)),
      ),
      child: ElevatedButton(
        onPressed: () => _showAddEditDialog(null),
        style: ElevatedButton.styleFrom(
          backgroundColor: _kBrand,
          foregroundColor: Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.add_rounded, size: 20),
            SizedBox(width: 8),
            Text('Tambah Kategori',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }

  void _showAddEditDialog(Category? existing) {
    if (existing != null && _isDefaultCategory(existing)) {
      _showDefaultCategorySnack();
      return;
    }
    final ctrl = TextEditingController(text: existing?.name);
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 32),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                existing == null ? 'Kategori Baru' : 'Perbarui Kategori',
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.5),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: ctrl,
                autofocus: true,
                style:
                    const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                decoration: InputDecoration(
                  hintText: 'Misal: HP, Laptop, AC, TV...',
                  hintStyle: TextStyle(color: Colors.grey.shade400),
                  filled: true,
                  fillColor: const Color(0xFFF8F9FA),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: Colors.grey.shade200),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: Colors.grey.shade200),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: _kBrand, width: 1.5),
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
              ),
              const SizedBox(height: 16),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    child: Text('Batal',
                        style: TextStyle(
                            color: Colors.grey.shade500,
                            fontWeight: FontWeight.w700)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () async {
                      final name = ctrl.text.trim();
                      if (name.isEmpty) return;
                      if (DBHelper.isDefaultCategoryName(name)) {
                        ModernSnackBar.error(
                          context: context,
                          message:
                              'Nama "Semua" dipakai untuk kategori sistem.',
                        );
                        return;
                      }
                      if (existing == null) {
                        await ref
                            .read(categoriesProvider.notifier)
                            .addCategory(name, durationHours: 0);
                      } else {
                        await ref
                            .read(categoriesProvider.notifier)
                            .updateCategory(existing.id!, name,
                                durationHours: 0);
                      }
                      if (!mounted || !ctx.mounted) return;
                      Navigator.pop(ctx);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      foregroundColor: Colors.white,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      elevation: 0,
                    ),
                    child: const Text('Simpan',
                        style: TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
    ).whenComplete(() {
      ctrl.dispose();
    });
  }
}

