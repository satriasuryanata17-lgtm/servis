import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../widgets/admin_pin_dialog.dart';
import '../widgets/custom_components.dart';
import '../widgets/kasir_dialog.dart';
import 'responsive_layout.dart';

class PelangganScreen extends ConsumerStatefulWidget {
  const PelangganScreen({super.key});

  @override
  ConsumerState<PelangganScreen> createState() => _PelangganScreenState();
}

class _PelangganScreenState extends ConsumerState<PelangganScreen> {
  Customer? _selected; // for tablet master-detail

  void _showForm(BuildContext context, WidgetRef ref, {Customer? existing}) {
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final phoneCtrl = TextEditingController(text: existing?.phone ?? '');
    final addressCtrl = TextEditingController(text: existing?.address ?? '');

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Container(
          decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.zero)),
          padding: const EdgeInsets.fromLTRB(24, 12, 24, 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Center(
                  child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.zero))),
              const SizedBox(height: 16),
              Text(existing == null ? 'Tambah Pelanggan' : 'Edit Pelanggan',
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              _FormField(
                  controller: nameCtrl,
                  label: 'Nama Pelanggan',
                  icon: Icons.person_outline),
              const SizedBox(height: 12),
              _FormField(
                  controller: phoneCtrl,
                  label: 'No. Telepon',
                  icon: Icons.phone_outlined,
                  keyboardType: TextInputType.phone),
              const SizedBox(height: 12),
              _FormField(
                  controller: addressCtrl,
                  label: 'Alamat (Opsional)',
                  icon: Icons.location_on_outlined),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1E465B),
                    elevation: 0,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                  onPressed: () async {
                    if (nameCtrl.text.trim().isEmpty) {
                      ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                          content: Text('Nama pelanggan wajib diisi!'),
                          backgroundColor: Colors.black87,
                          behavior: SnackBarBehavior.floating));
                      return;
                    }
                    final c = Customer(
                      id: existing?.id,
                      name: nameCtrl.text.trim(),
                      phone: phoneCtrl.text.trim().isEmpty
                          ? null
                          : phoneCtrl.text.trim(),
                      address: addressCtrl.text.trim().isEmpty
                          ? null
                          : addressCtrl.text.trim(),
                      createdAt: existing?.createdAt ??
                          DateTime.now().toIso8601String(),
                    );
                    if (existing == null) {
                      await ref.read(customersProvider.notifier).addCustomer(c);
                    } else {
                      await ref
                          .read(customersProvider.notifier)
                          .updateCustomer(c);
                      if (mounted && _selected?.id == existing.id) {
                        setState(() => _selected = c);
                      }
                    }
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                  child: Text(existing == null ? 'Simpan' : 'Update',
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmDelete(
      BuildContext context, WidgetRef ref, Customer c) async {
    final confirmed = await showKasirConfirmDialog(
      context,
      title: 'Hapus ${c.name}?',
      message:
          'Data pelanggan akan dihapus dari daftar. Transaksi lama tetap tersimpan.',
      confirmLabel: 'Ya, Hapus',
      icon: AppIcons.recycleBin,
    );

    if (confirmed == true) {
      if (!mounted || !context.mounted) return;
      final pinOk = await AdminPinDialog.show(
        context,
        verifyPin: (pin) {
          final profilNotifier = ref.read(profilProvider.notifier);
          if (!profilNotifier.hasConfiguredAdminPin) {
            return 'PIN admin belum diatur. Buka Pengaturan Profil.';
          }
          final valid = profilNotifier.verifyPin(pin);
          return valid ? '' : 'PIN salah';
        },
        title: 'Verifikasi Hapus Pelanggan',
        subtitle:
            'Masukkan PIN Admin/Owner. Transaksi lama tidak akan dihapus.',
      );
      if (!pinOk || !mounted || !context.mounted) return;

      final messenger = ScaffoldMessenger.of(context);
      try {
        await ref
            .read(customersProvider.notifier)
            .deleteCustomer(c.id!, pinVerified: true);
        if (mounted) {
          if (_selected?.id == c.id) {
            setState(() => _selected = null);
          }
          messenger.showSnackBar(
            const SnackBar(
                content: Text('Pelanggan berhasil dihapus'),
                backgroundColor: Colors.black87,
                behavior: SnackBarBehavior.floating),
          );
        }
      } catch (e) {
        if (mounted) {
          messenger.showSnackBar(
            const SnackBar(
                content: Text('Gagal menghapus pelanggan. Silakan coba lagi.'),
                backgroundColor: Colors.redAccent,
                behavior: SnackBarBehavior.floating),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final customers = ref.watch(customersProvider);
    final tablet = isTabletDevice(context);
    final landscape = isLandscape(context);

    // Tablet landscape master-detail (two panel)
    if (tablet && landscape) {
      return _buildMasterDetailLayout(context, ref, customers);
    }

    // Tablet portrait or phone original list with wider cards
    return _buildListLayout(context, ref, customers, tablet);
  }

  Widget _buildMasterDetailLayout(
      BuildContext context, WidgetRef ref, List<Customer> customers) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      body: SafeArea(
        bottom: false,
        child: Row(
          children: [
            Container(
              width: 320,
              color: Colors.white,
              child: Column(
                children: [
                  _buildHeader(context, ref, customers, tablet: true),
                  const Divider(height: 1, color: AppColors.divider),
                  Expanded(
                    child: customers.isEmpty
                        ? _buildEmpty()
                        : ListView.separated(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            itemCount: customers.length,
                            separatorBuilder: (_, __) =>
                                const Divider(height: 1, indent: 70),
                            itemBuilder: (_, i) {
                              final c = customers[i];
                              final isSelected = _selected?.id == c.id;
                              return ListTile(
                                onTap: () => setState(() => _selected = c),
                                selected: isSelected,
                                selectedTileColor: AppColors.primaryBrand
                                    .withValues(alpha: 0.06),
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 6),
                                leading: _Avatar(customer: c),
                                title: Text(c.name,
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        color: isSelected
                                            ? AppColors.primaryBrand
                                            : Colors.black87)),
                                subtitle: c.phone != null
                                    ? Text(c.phone!,
                                        style: const TextStyle(
                                            fontSize: 12,
                                            color: Colors.black45))
                                    : null,
                                trailing: isSelected
                                    ? const Icon(Icons.chevron_right_rounded,
                                        color: AppColors.primaryBrand)
                                    : null,
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
            Container(width: 1, color: const Color(0xFFE2E8F0)),
            Expanded(
              child: _selected == null
                  ? const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.person_search_rounded,
                              size: 64, color: Colors.black12),
                          SizedBox(height: 12),
                          Text('Pilih pelanggan untuk detail',
                              style: TextStyle(
                                  color: Colors.black38, fontSize: 15)),
                        ],
                      ),
                    )
                  : _CustomerDetail(
                      customer: _selected!,
                      onEdit: () =>
                          _showForm(context, ref, existing: _selected),
                      onDelete: () => _confirmDelete(context, ref, _selected!),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListLayout(BuildContext context, WidgetRef ref,
      List<Customer> customers, bool tablet) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 10),
              child: JuraganServisHeader(),
            ),
            _buildHeader(context, ref, customers, tablet: tablet),
            const SizedBox(height: 12),
            const Divider(height: 1, color: AppColors.divider),
            Expanded(
              child: customers.isEmpty
                  ? _buildEmpty()
                  : ListView.separated(
                      padding: EdgeInsets.fromLTRB(
                          tablet ? 24 : 20, 16, tablet ? 24 : 20, 100),
                      itemCount: customers.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) {
                        final c = customers[i];
                        return _CustomerListCard(
                          customer: c,
                          tablet: tablet,
                          onEdit: () => _showForm(context, ref, existing: c),
                          onDelete: () => _confirmDelete(context, ref, c),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(
      BuildContext context, WidgetRef ref, List<Customer> customers,
      {required bool tablet}) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: tablet ? 20 : 20, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: const Icon(Icons.arrow_back_ios_new_rounded,
                    size: 22, color: Colors.black87),
              ),
              const SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Pelanggan',
                      style: AppText.h1.copyWith(
                          fontSize: tablet ? 22 : 24,
                          fontWeight: FontWeight.bold)),
                  Text('${customers.length} pelanggan',
                      style: const TextStyle(color: Colors.grey, fontSize: 13)),
                ],
              ),
            ],
          ),
          GestureDetector(
            onTap: () => _showForm(context, ref),
            child: Container(
              width: tablet ? 44 : 52,
              height: tablet ? 44 : 52,
              decoration: const BoxDecoration(
                color: Color(0xFF1E465B),
                borderRadius: BorderRadius.zero,
              ),
              child: const Center(
                  child: Icon(Icons.add, color: Colors.white, size: 28)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: const BoxDecoration(
                color: Color(0xFFEBF5FB), shape: BoxShape.rectangle),
            child: const Icon(Icons.people_outline_rounded,
                color: Color(0xFF1E465B), size: 48),
          ),
          const SizedBox(height: 16),
          const Text('Belum ada pelanggan',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.grey,
                  fontSize: 16)),
          const SizedBox(height: 8),
          const Text('Tekan tombol + untuk menambahkan\npelanggan pertama Anda',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 13)),
        ],
      ),
    );
  }
}

//  CUSTOMER DETAIL PANEL (tablet master-detail)

class _CustomerDetail extends StatelessWidget {
  final Customer customer;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _CustomerDetail({
    required this.customer,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _Avatar(customer: customer, size: 72, fontSize: 32),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(customer.name,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 22,
                            color: Colors.black87)),
                    if (customer.phone != null) ...[
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.phone_outlined,
                            size: 14, color: Colors.grey),
                        const SizedBox(width: 4),
                        Text(customer.phone!,
                            style: const TextStyle(
                                color: Colors.grey,
                                fontSize: 14,
                                fontWeight: FontWeight.w600)),
                      ]),
                    ],
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 32),
          if (customer.address != null && customer.address!.isNotEmpty) ...[
            _DetailRow(
                icon: Icons.location_on_outlined,
                label: 'Alamat',
                value: customer.address!),
            const SizedBox(height: 16),
          ],
          _DetailRow(
            icon: Icons.calendar_today_outlined,
            label: 'Terdaftar',
            value: customer.createdAt ?? '-',
          ),
          const SizedBox(height: 40),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onEdit,
                  icon: const Icon(Icons.edit_rounded, size: 18),
                  label: const Text('Edit'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.primaryBrand,
                    side: const BorderSide(color: AppColors.primaryBrand),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onDelete,
                  icon: const Icon(AppIcons.recycleBin, size: 18),
                  label: const Text('Hapus'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.red,
                    side: const BorderSide(color: Colors.red),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _DetailRow(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: const BoxDecoration(
            color: Color(0xFFF0F2F5),
            borderRadius: BorderRadius.zero,
          ),
          child: Icon(icon, size: 20, color: Colors.black54),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                      fontSize: 11,
                      color: Colors.black38,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5)),
              const SizedBox(height: 2),
              Text(value,
                  style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      color: Colors.black87)),
            ],
          ),
        ),
      ],
    );
  }
}

//  CUSTOMER LIST CARD (phone & tablet portrait)

class _CustomerListCard extends StatelessWidget {
  final Customer customer;
  final bool tablet;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _CustomerListCard({
    required this.customer,
    required this.tablet,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: AppColors.divider),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.02),
              blurRadius: 4,
              offset: const Offset(0, 2))
        ],
      ),
      child: ListTile(
        contentPadding:
            EdgeInsets.symmetric(horizontal: 16, vertical: tablet ? 12 : 8),
        leading: _Avatar(
            customer: customer,
            size: tablet ? 52 : 48,
            fontSize: tablet ? 22 : 20),
        title: Text(customer.name,
            style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: tablet ? 17 : 16,
                color: Colors.black87)),
        subtitle: customer.phone != null
            ? Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Row(
                  children: [
                    const Icon(Icons.phone_outlined,
                        size: 14, color: Colors.grey),
                    const SizedBox(width: 4),
                    Text(customer.phone!,
                        style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 13,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
              )
            : null,
        trailing: PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert, color: Colors.grey),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          onSelected: (v) {
            if (v == 'edit') onEdit();
            if (v == 'delete') onDelete();
          },
          itemBuilder: (_) => [
            const PopupMenuItem(
                value: 'edit',
                child: Row(children: [
                  Icon(Icons.edit_rounded, size: 18, color: Colors.blue),
                  SizedBox(width: 8),
                  Text('Edit')
                ])),
            const PopupMenuItem(
                value: 'delete',
                child: Row(children: [
                  Icon(AppIcons.recycleBin, size: 18, color: Colors.red),
                  SizedBox(width: 8),
                  Text('Hapus', style: TextStyle(color: Colors.red))
                ])),
          ],
        ),
      ),
    );
  }
}

//  SHARED AVATAR

class _Avatar extends StatelessWidget {
  final Customer customer;
  final double size;
  final double fontSize;

  const _Avatar({required this.customer, this.size = 48, this.fontSize = 20});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: const Color(0xFF1E465B).withValues(alpha: 0.12),
        shape: BoxShape.rectangle,
      ),
      child: Center(
        child: Text(
          customer.name.isNotEmpty ? customer.name[0].toUpperCase() : '?',
          style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: fontSize,
              color: const Color(0xFF1E465B)),
        ),
      ),
    );
  }
}

class _FormField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final TextInputType? keyboardType;
  const _FormField(
      {required this.controller,
      required this.label,
      required this.icon,
      this.keyboardType});

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      style: const TextStyle(fontWeight: FontWeight.w600),
      decoration: InputDecoration(
        labelText: label,
        labelStyle:
            const TextStyle(color: Colors.grey, fontWeight: FontWeight.w500),
        prefixIcon: Icon(icon, color: const Color(0xFF1E465B), size: 22),
        filled: true,
        fillColor: const Color(0xFFF4F7FC),
        border: const OutlineInputBorder(
            borderRadius: BorderRadius.zero, borderSide: BorderSide.none),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }
}

