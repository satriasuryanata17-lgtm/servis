import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../providers/providers.dart';
import '../services/support_contact_service.dart';
import '../utils/modern_ui_helpers.dart';
import 'responsive_layout.dart';
import 'package:url_launcher/url_launcher.dart';

// KRITIK & SARAN SCREEN

class KritikSaranScreen extends ConsumerStatefulWidget {
  const KritikSaranScreen({super.key});

  @override
  ConsumerState<KritikSaranScreen> createState() => _KritikSaranScreenState();
}

class _KritikSaranScreenState extends ConsumerState<KritikSaranScreen> {
  static const _email = 'halo.juragankasir@gmail.com';

  final _messageCtrl = TextEditingController();
  String _category = 'Saran Fitur';
  int _rating = 0;
  bool _sending = false;

  static const _categories = [
    'Saran Fitur',
    'Laporan Bug',
    'Pertanyaan',
    'Keluhan',
    'Pujian',
    'Lainnya',
  ];

  @override
  void dispose() {
    _messageCtrl.dispose();
    super.dispose();
  }

  Future<void> _kirimViaWhatsApp() async {
    final msg = _messageCtrl.text.trim();
    if (msg.isEmpty) {
      _snack('Pesan tidak boleh kosong.');
      return;
    }

    setState(() => _sending = true);
    try {
      final bintang = _rating == 0
          ? 'Belum diisi'
          : '${'⭐' * _rating}${'' * (5 - _rating)}';
      final text = 'Kritik & Saran - Juragan Servis\n\n'
          '• *Kategori:* $_category\n'
          '• *Rating:* $bintang\n\n'
          '• *Pesan:* \n$msg';
      await SupportContactService.launchSupportWhatsapp(message: text);
    } catch (e) {
      if (mounted) {
        _snack('Gagal membuka WhatsApp. Pastikan WhatsApp terpasang.');
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _kirimViaEmail() async {
    final msg = _messageCtrl.text.trim();
    if (msg.isEmpty) {
      _snack('Pesan tidak boleh kosong.');
      return;
    }

    final bintang =
        _rating == 0 ? 'Belum diisi' : '${'⭐' * _rating} ($_rating/5)';
    final subject = Uri.encodeComponent('[$_category] Feedback Juragan Servis');
    final body = Uri.encodeComponent(
        'Kategori: $_category\nRating: $bintang\n\nPesan:\n$msg');
    final uri = Uri.parse('mailto:$_email?subject=$subject&body=$body');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      if (mounted) _snack('Tidak dapat membuka aplikasi email.');
    }
  }

  void _copyToClipboard() {
    final msg = _messageCtrl.text.trim();
    if (msg.isEmpty) {
      _snack('Tidak ada pesan untuk disalin.');
      return;
    }
    Clipboard.setData(ClipboardData(text: msg));
    _snack('Pesan disalin ke clipboard.');
  }

  void _snack(String msg) {
    ModernSnackBar.show(context: context, message: msg);
  }

  Future<void> _openPlayStore() async {
    final url = await ref.read(playStoreUrlProvider.future);
    final uri = Uri.parse(url);
    // Coba buka di aplikasi Play Store (market://)
    final marketUri = Uri.parse(
        'market://details?id=${uri.queryParameters['id'] ?? 'com.juraganservis.app'}');
    if (await canLaunchUrl(marketUri)) {
      await launchUrl(marketUri);
    } else if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      if (mounted) _snack('Tidak dapat membuka Play Store.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isWide = isTabletDevice(context) || isLandscape(context);

    return KasirResponsiveScaffold(
      title: 'Kritik & Saran',
      showNavRail: false,
      backgroundColor: const Color(0xFFF5F5F5),
      body: SingleChildScrollView(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 960),
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: isWide ? 32 : 16,
                vertical: 24,
              ),
              child: isWide ? _buildWide() : _buildNarrow(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildWide() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Form (2/3)
        Expanded(
          flex: 2,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _header(isWide: true),
              const SizedBox(height: 20),
              _formCard(),
            ],
          ),
        ),
        const SizedBox(width: 20),
        // Info panel (1/3)
        Expanded(
          flex: 1,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 88), // align with form start
              _infoPanel(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildNarrow() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _header(isWide: false),
        const SizedBox(height: 16),
        _formCard(),
        const SizedBox(height: 16),
        _infoPanel(),
      ],
    );
  }

  Widget _header({required bool isWide}) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(isWide ? 24 : 18),
      color: AppColors.primaryBrand,
      child: Row(
        children: [
          const Icon(Icons.rate_review_outlined, color: Colors.white, size: 24),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Kritik & Saran',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 2),
              Text(
                'Bantu kami terus berkembang',
                style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.75),
                    fontSize: 12.5),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _formCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE0E0E0)),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Rating
          const _FieldLabel(text: 'Rating Aplikasi'),
          const SizedBox(height: 4),
          const Text(
            'Ketuk bintang untuk menilai di Play Store',
            style: TextStyle(fontSize: 11, color: Colors.black45),
          ),
          const SizedBox(height: 10),
          Row(
            children: List.generate(5, (i) {
              final star = i + 1;
              return GestureDetector(
                onTap: () {
                  setState(() => _rating = star);
                  _openPlayStore();
                },
                child: Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: Icon(
                    _rating >= star
                        ? Icons.star_rounded
                        : Icons.star_border_rounded,
                    color: _rating >= star
                        ? AppColors.primaryBrand
                        : Colors.black26,
                    size: 30,
                  ),
                ),
              );
            }),
          ),
          if (_rating > 0) ...[
            const SizedBox(height: 6),
            Text(
              _ratingLabel(),
              style: const TextStyle(
                  fontSize: 12,
                  color: AppColors.primaryBrand,
                  fontWeight: FontWeight.w600),
            ),
          ],

          const SizedBox(height: 18),
          const Divider(height: 1, color: Color(0xFFF0F0F0)),
          const SizedBox(height: 18),

          // Kategori
          const _FieldLabel(text: 'Kategori'),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: _categories.map((c) {
              final sel = _category == c;
              return GestureDetector(
                onTap: () => setState(() => _category = c),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 120),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color:
                        sel ? AppColors.primaryBrand : const Color(0xFFF5F5F5),
                    border: Border.all(
                        color: sel
                            ? AppColors.primaryBrand
                            : const Color(0xFFDDDDDD)),
                  ),
                  child: Text(
                    c,
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: sel ? Colors.white : Colors.black54),
                  ),
                ),
              );
            }).toList(),
          ),

          const SizedBox(height: 18),
          const Divider(height: 1, color: Color(0xFFF0F0F0)),
          const SizedBox(height: 18),

          // Pesan
          const _FieldLabel(text: 'Pesan / Masukan'),
          const SizedBox(height: 10),
          TextField(
            controller: _messageCtrl,
            maxLines: 5,
            maxLength: 500,
            style: const TextStyle(fontSize: 13),
            decoration: const InputDecoration(
              hintText:
                  'Tuliskan saran, kritik, atau pertanyaan Anda di sini...',
              hintStyle: TextStyle(fontSize: 12.5, color: Colors.black38),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: Color(0xFFDDDDDD))),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: Color(0xFFDDDDDD))),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide:
                      BorderSide(color: AppColors.primaryBrand, width: 1.5)),
              contentPadding: EdgeInsets.all(12),
              filled: true,
              fillColor: Color(0xFFFAFAFA),
            ),
          ),

          const SizedBox(height: 16),

          // Action buttons
          Row(
            children: [
              Expanded(
                child: _ActionBtn(
                  icon: Icons.chat_rounded,
                  label: 'WhatsApp',
                  loading: _sending,
                  onTap: _kirimViaWhatsApp,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _ActionBtn(
                  icon: Icons.email_outlined,
                  label: 'Email',
                  loading: false,
                  onTap: _kirimViaEmail,
                ),
              ),
              const SizedBox(width: 8),
              Tooltip(
                message: 'Salin ke Clipboard',
                child: InkWell(
                  onTap: _copyToClipboard,
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF5F5F5),
                      border: Border.all(color: const Color(0xFFDDDDDD)),
                    ),
                    child: const Icon(Icons.copy_rounded,
                        size: 16, color: Colors.black54),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _infoPanel() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE0E0E0)),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            color: AppColors.primaryBrand.withValues(alpha: 0.08),
            child: const Icon(Icons.info_outline_rounded,
                color: AppColors.primaryBrand, size: 18),
          ),
          const SizedBox(height: 12),
          const Text(
            'Tentang Feedback',
            style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1A1A1A)),
          ),
          const SizedBox(height: 8),
          const Divider(height: 1, color: Color(0xFFF0F0F0)),
          const SizedBox(height: 10),
          const _InfoRow(
              icon: Icons.access_time_outlined,
              text: 'Respon dalam 1-24 jam kerja'),
          const SizedBox(height: 8),
          const _InfoRow(
              icon: Icons.check_circle_outline_rounded,
              text: 'Setiap masukan dipertimbangkan'),
          const SizedBox(height: 8),
          const _InfoRow(icon: Icons.email_outlined, text: _email),
          const SizedBox(height: 16),
          const Divider(height: 1, color: Color(0xFFF0F0F0)),
          const SizedBox(height: 10),
          const Text(
            'Pesan Anda akan diteruskan langsung ke tim Juragan Servis.',
            style:
                TextStyle(fontSize: 11.5, color: Colors.black45, height: 1.5),
          ),
        ],
      ),
    );
  }

  String _ratingLabel() {
    switch (_rating) {
      case 1:
        return 'Sangat Kurang';
      case 2:
        return 'Kurang Memuaskan';
      case 3:
        return 'Cukup';
      case 4:
        return 'Bagus';
      case 5:
        return 'Sangat Puas!';
      default:
        return '';
    }
  }
}

// Shared widgets

class _FieldLabel extends StatelessWidget {
  final String text;
  const _FieldLabel({required this.text});

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
          fontSize: 12.5,
          fontWeight: FontWeight.w700,
          color: Color(0xFF333333)),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool loading;
  final VoidCallback onTap;

  const _ActionBtn({
    required this.icon,
    required this.label,
    required this.loading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: loading ? null : onTap,
      icon: loading
          ? const SizedBox(
              width: 13,
              height: 13,
              child: CircularProgressIndicator(
                  strokeWidth: 2, color: Colors.white))
          : Icon(icon, size: 15),
      label: Text(label,
          style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primaryBrand,
        foregroundColor: Colors.white,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String text;
  const _InfoRow({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon,
            size: 13, color: AppColors.primaryBrand.withValues(alpha: 0.7)),
        const SizedBox(width: 7),
        Expanded(
          child: Text(text,
              style: const TextStyle(fontSize: 12, color: Colors.black54)),
        ),
      ],
    );
  }
}

