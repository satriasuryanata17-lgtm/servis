import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../services/export_service.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';
import '../widgets/export_dropdown.dart';

const Color _kBg = Color(0xFFF6F7F9);

class TransaksiPelangganScreen extends ConsumerStatefulWidget {
  const TransaksiPelangganScreen({super.key});

  @override
  ConsumerState<TransaksiPelangganScreen> createState() =>
      _TransaksiPelangganScreenState();
}

class _TransaksiPelangganScreenState
    extends ConsumerState<TransaksiPelangganScreen> {
  String _periode = 'Periode Bulanan';
  DateTime _selectedDate = DateTime.now();

  final List<String> _periodeOptions = const [
    'Periode Harian',
    'Periode Mingguan',
    'Periode Bulanan',
  ];

  //  Helpers

  String _fmtRp(int value) {
    final f = NumberFormat.currency(
      locale: 'id',
      symbol: 'Rp',
      decimalDigits: 0,
    );
    return f.format(value);
  }

  String _fmtDate(DateTime d) => DateFormat('dd MMM yyyy', 'id').format(d);

  String _labelRange() {
    final r = _range();
    if (_periode == 'Periode Harian') return _fmtDate(r.start);
    if (_periode == 'Periode Bulanan') {
      return DateFormat('MMMM yyyy', 'id').format(r.start);
    }
    return '${_fmtDate(r.start)}  ${_fmtDate(r.end.subtract(const Duration(days: 1)))}';
  }

  DateTimeRange _range() {
    final dayStart = DateTime(
      _selectedDate.year,
      _selectedDate.month,
      _selectedDate.day,
    );
    if (_periode == 'Periode Mingguan') {
      final weekdayOffset = _selectedDate.weekday - DateTime.monday;
      final start = dayStart.subtract(Duration(days: weekdayOffset));
      return DateTimeRange(
          start: start, end: start.add(const Duration(days: 7)));
    }
    if (_periode == 'Periode Bulanan') {
      final start = DateTime(_selectedDate.year, _selectedDate.month, 1);
      return DateTimeRange(
        start: start,
        end: DateTime(_selectedDate.year, _selectedDate.month + 1, 1),
      );
    }
    return DateTimeRange(
        start: dayStart, end: dayStart.add(const Duration(days: 1)));
  }

  Map<String, Map<String, dynamic>> _aggregate(List<Transaction> transactions) {
    final range = _range();
    final map = <String, Map<String, dynamic>>{};
    // Track payment method frequency per customer
    final methodFreq = <String, Map<String, int>>{};
    for (final tx in transactions) {
      final dt = DateTime.tryParse(tx.createdAt);
      if (dt == null) continue;
      if (dt.isBefore(range.start) || !dt.isBefore(range.end)) continue;

      final key = (tx.customerName == null || tx.customerName!.trim().isEmpty)
          ? 'Pelanggan Umum'
          : tx.customerName!.trim();
      final existing = map.putIfAbsent(
        key,
        () => {'name': key, 'count': 0, 'total': 0, 'topMethod': 'cash'},
      );
      existing['count'] = (existing['count'] as int) + 1;
      existing['total'] = (existing['total'] as int) + tx.grandTotal;

      // Track payment method frequency
      final mf = methodFreq.putIfAbsent(key, () => {});
      final m = tx.paymentMethod.toLowerCase();
      mf[m] = (mf[m] ?? 0) + 1;
    }
    // Set dominant payment method per customer
    for (final key in map.keys) {
      final mf = methodFreq[key];
      if (mf != null && mf.isNotEmpty) {
        final dominant =
            mf.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
        map[key]!['topMethod'] = dominant;
      }
    }
    return map;
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: const ColorScheme.light(primary: AppColors.primaryBrand),
        ),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  Future<void> _showPeriodeSheet() async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 8),
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.zero,
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Pilih Periode',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const SizedBox(height: 8),
          ..._periodeOptions.map(
            (opt) => ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 20),
              leading: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: opt == _periode
                      ? AppColors.brandLight
                      : const Color(0xFFF5F5F5),
                  borderRadius: BorderRadius.zero,
                ),
                child: Icon(
                  opt == 'Periode Harian'
                      ? Icons.today_rounded
                      : opt == 'Periode Mingguan'
                          ? Icons.date_range_rounded
                          : Icons.calendar_month_rounded,
                  color:
                      opt == _periode ? AppColors.primaryBrand : Colors.black45,
                  size: 20,
                ),
              ),
              title: Text(
                opt,
                style: TextStyle(
                  fontWeight:
                      opt == _periode ? FontWeight.bold : FontWeight.normal,
                  color:
                      opt == _periode ? AppColors.primaryBrand : Colors.black87,
                ),
              ),
              trailing: opt == _periode
                  ? const Icon(Icons.check_circle_rounded,
                      color: AppColors.primaryBrand, size: 20)
                  : null,
              onTap: () => Navigator.pop(context, opt),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
    if (selected != null) setState(() => _periode = selected);
  }

  Future<void> _exportData(List<Map<String, dynamic>> grouped) async {
    final choice = await ExportDropdown.show(context);
    if (choice == null) return;
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);

    if (grouped.isEmpty) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text('Belum ada data untuk diekspor.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
      return;
    }

    final range = _range();
    final totalTransaksi =
        grouped.fold<int>(0, (s, e) => s + (e['count'] as int));
    final totalBelanja =
        grouped.fold<int>(0, (s, e) => s + (e['total'] as int));

    final Map<String, String> summaryData = {
      'Pelanggan Unik': '${grouped.length}',
      'Total Transaksi': '$totalTransaksi',
      'Total Omzet': _fmtRp(totalBelanja),
      'Periode': _periode,
    };

    final headers = ['Nama Pelanggan', 'Transaksi', 'Total Belanja'];
    final rows = grouped
        .map((item) => [
              item['name'],
              '${item['count']}x',
              _fmtRp(item['total'] as int),
            ])
        .toList();

    const title = 'Laporan Transaksi Pelanggan';
    final subtitle = 'Periode: ${_labelRange()}';

    try {
      if (choice == 'csv') {
        await ExportService.exportAndShareCsv(
          filePrefix: 'transaksi_pelanggan',
          headers: const [
            'Nama Pelanggan',
            'Jumlah Transaksi',
            'Total Belanja',
            'Periode',
            'Mulai',
            'Sampai',
          ],
          rows: grouped
              .map((item) => [
                    item['name'],
                    item['count'],
                    item['total'],
                    _periode,
                    _fmtDate(range.start),
                    _fmtDate(range.end.subtract(const Duration(days: 1))),
                  ])
              .toList(),
          subject: 'Ekspor Transaksi Pelanggan',
          message: 'Ekspor transaksi pelanggan dari Juragan Servis.',
        );
      } else if (choice == 'pdf') {
        await ExportService.exportPdfLaporan(
          title: title,
          subtitle: subtitle,
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      } else if (choice == 'print') {
        await ExportService.printPdfLaporan(
          title: title,
          subtitle: subtitle,
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      }
    } catch (e) {
      if (!mounted) return;
      messenger.showSnackBar(
        const SnackBar(
          content: Text('Gagal mengekspor data. Silakan coba lagi.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
    }
  }

  //  Build

  @override
  Widget build(BuildContext context) {
    final transactions = ref.watch(transactionsProvider);
    final grouped = _aggregate(transactions).values.toList()
      ..sort((a, b) => (b['total'] as int).compareTo(a['total'] as int));

    final totalTransaksi =
        grouped.fold<int>(0, (s, e) => s + (e['count'] as int));
    final totalBelanja =
        grouped.fold<int>(0, (s, e) => s + (e['total'] as int));
    final maxTotal = grouped.isNotEmpty ? (grouped.first['total'] as int) : 1;

    final filterPanel = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        //  Filter Periode & Tanggal
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
          child: isTabletDevice(context) && isLandscape(context)
              ? Column(
                  children: [
                    _buildPeriodeDropdown(),
                    const SizedBox(height: 10),
                    _buildDatePicker(),
                  ],
                )
              : Row(
                  children: [
                    Expanded(child: _buildPeriodeDropdown()),
                    const SizedBox(width: 10),
                    Expanded(child: _buildDatePicker()),
                  ],
                ),
        ),

        //  Summary Cards
        if (grouped.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: isTabletDevice(context) && isLandscape(context)
                ? Column(
                    children: [
                      Row(
                        children: [
                          _SummaryCard(
                            icon: Icons.people_alt_rounded,
                            iconColor: AppColors.primaryBrand,
                            iconBg: AppColors.brandLight,
                            label: 'Pelanggan',
                            value: '${grouped.length}',
                            sub: 'unik',
                            isWide: true,
                          ),
                          const SizedBox(width: 10),
                          _SummaryCard(
                            icon: Icons.receipt_long_rounded,
                            iconColor: AppColors.primaryBrand,
                            iconBg: AppColors.brandLight,
                            label: 'Transaksi',
                            value: '$totalTransaksi',
                            sub: 'total',
                            isWide: true,
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          _SummaryCard(
                            icon: Icons.payments_rounded,
                            iconColor: AppColors.primaryBrand,
                            iconBg: AppColors.brandLight,
                            label: 'Omzet',
                            value: _fmtRp(totalBelanja),
                            sub: 'total',
                            isWide: true,
                          ),
                        ],
                      ),
                    ],
                  )
                : Row(
                    children: [
                      _SummaryCard(
                        icon: Icons.people_alt_rounded,
                        iconColor: AppColors.primaryBrand,
                        iconBg: AppColors.brandLight,
                        label: 'Pelanggan',
                        value: '${grouped.length}',
                        sub: 'unik',
                      ),
                      const SizedBox(width: 8),
                      _SummaryCard(
                        icon: Icons.receipt_long_rounded,
                        iconColor: AppColors.primaryBrand,
                        iconBg: AppColors.brandLight,
                        label: 'Transaksi',
                        value: '$totalTransaksi',
                        sub: 'total',
                      ),
                      const SizedBox(width: 8),
                      _SummaryCard(
                        icon: Icons.payments_rounded,
                        iconColor: AppColors.primaryBrand,
                        iconBg: AppColors.brandLight,
                        label: 'Omzet',
                        value: _fmtRp(totalBelanja),
                        sub: 'total',
                        isWide: true,
                      ),
                    ],
                  ),
          ),
      ],
    );

    final mainContent = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        //  Judul Ranking
        if (grouped.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const Expanded(
                  child: Text(
                    'Ranking Belanja',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.black87,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'Urut belanja terbesar',
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                ),
              ],
            ),
          ),

        //  List/Grid
        Expanded(
          child: grouped.isEmpty
              ? _EmptyTransaksiView(periode: _periode)
              : isTabletDevice(context) && !isLandscape(context)
                  // Grid untuk tablet portrait
                  ? GridView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        mainAxisExtent: 110,
                      ),
                      itemCount: grouped.length,
                      itemBuilder: (_, i) {
                        final item = grouped[i];
                        final total = item['total'] as int;
                        final ratio = maxTotal > 0 ? total / maxTotal : 0.0;
                        return _CustomerTxCard(
                          rank: i + 1,
                          name: item['name'] as String,
                          count: item['count'] as int,
                          total: total,
                          fmtRp: _fmtRp,
                          ratio: ratio,
                          topMethod: item['topMethod'] as String? ?? 'cash',
                        );
                      },
                    )
                  // Full List untuk tablet landscape atau phone
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                      itemCount: grouped.length,
                      itemBuilder: (_, i) {
                        final item = grouped[i];
                        final total = item['total'] as int;
                        final ratio = maxTotal > 0 ? total / maxTotal : 0.0;
                        return _CustomerTxCard(
                          rank: i + 1,
                          name: item['name'] as String,
                          count: item['count'] as int,
                          total: total,
                          fmtRp: _fmtRp,
                          ratio: ratio,
                          topMethod: item['topMethod'] as String? ?? 'cash',
                        );
                      },
                    ),
        ),
      ],
    );

    return KasirResponsiveScaffold(
      title: 'Transaksi Pelanggan',
      navIndex: 4,
      showNavRail: false,
      backgroundColor: _kBg,
      actions: [
        // Tombol ekspor
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: GestureDetector(
            onTap: () => _exportData(grouped),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: const BoxDecoration(
                color: AppColors.primaryBrand,
                borderRadius: BorderRadius.zero,
              ),
              child: const Row(
                children: [
                  Icon(Icons.download_rounded, color: Colors.white, size: 15),
                  SizedBox(width: 5),
                  Text(
                    'Ekspor',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
      body: ResponsiveReportLayout(
        filterPanel: filterPanel,
        content: mainContent,
      ),
    );
  }

  Widget _buildPeriodeDropdown() {
    return GestureDetector(
      onTap: _showPeriodeSheet,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: const BoxDecoration(
          color: AppColors.brandLight,
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          children: [
            const Icon(Icons.tune_rounded,
                color: AppColors.primaryBrand, size: 16),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                _periode.replaceAll('Periode ', ''),
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.primaryBrand,
                ),
              ),
            ),
            const Icon(Icons.keyboard_arrow_down_rounded,
                color: AppColors.primaryBrand, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildDatePicker() {
    return GestureDetector(
      onTap: _pickDate,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: _kBg,
          borderRadius: BorderRadius.zero,
          border: Border.all(color: const Color(0xFFEAEAEA)),
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_today_rounded,
                color: Colors.black45, size: 16),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                _labelRange(),
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//  Summary Card

class _SummaryCard extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String label;
  final String value;
  final String sub;
  final bool isWide;

  const _SummaryCard({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.label,
    required this.value,
    required this.sub,
    this.isWide = false,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: isWide ? 2 : 1,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: AppColors.primaryBrand.withValues(alpha: 0.1),
                borderRadius: BorderRadius.zero,
              ),
              child: Icon(icon, color: AppColors.primaryBrand, size: 16),
            ),
            const SizedBox(height: 8),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 14,
                color: Colors.black87,
              ),
            ),
            Text(
              label,
              style: const TextStyle(fontSize: 11, color: Colors.black45),
            ),
          ],
        ),
      ),
    );
  }
}

//  Customer Transaction Card

class _CustomerTxCard extends StatelessWidget {
  final int rank;
  final String name;
  final int count;
  final int total;
  final String Function(int) fmtRp;
  final double ratio;
  final String topMethod;

  const _CustomerTxCard({
    required this.rank,
    required this.name,
    required this.count,
    required this.total,
    required this.fmtRp,
    required this.ratio,
    required this.topMethod,
  });

  // Payment method style (sama seperti dashboard)
  Color get _methodBg {
    return AppColors.brandLight;
  }

  Color get _methodColor {
    return AppColors.primaryBrand;
  }

  IconData get _methodIcon {
    final m = topMethod.toLowerCase();
    if (m == 'qris') return Icons.qr_code_rounded;
    if (m == 'transfer') return Icons.account_balance_rounded;
    if (m == 'pesanan' || m == 'buat_pesanan') {
      return Icons.receipt_long_rounded;
    }
    return Icons.payments_rounded;
  }

  String get _methodLabel {
    final m = topMethod.toLowerCase();
    if (m == 'qris') return 'QRIS';
    if (m == 'transfer') return 'Transfer';
    if (m == 'pesanan' || m == 'buat_pesanan') return 'Tagihan';
    return 'Tunai';
  }

  Color get _rankBadgeColor {
    if (rank == 1) return const Color(0xFF1E40AF); // Dark blue for 1st
    if (rank == 2) return const Color(0xFF3B82F6); // Medium blue for 2nd
    if (rank == 3) return const Color(0xFF93C5FD); // Light blue for 3rd
    return Colors.black26;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Row(
              children: [
                // Payment method thumbnail + rank badge
                Stack(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: _methodBg,
                        borderRadius: BorderRadius.zero,
                      ),
                      child: Icon(_methodIcon, color: _methodColor, size: 24),
                    ),
                    // Nomor rank di pojok kanan bawah
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        width: 18,
                        height: 18,
                        decoration: BoxDecoration(
                          color: _rankBadgeColor,
                          borderRadius: BorderRadius.zero,
                        ),
                        child: Center(
                          child: Text(
                            '$rank',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 14),
                // Nama, transaksi & metode
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 7, vertical: 3),
                            decoration: const BoxDecoration(
                              color: Color(0xFFF5F5F5),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Text(
                              '$count transaksi',
                              style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: Colors.black54,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 7, vertical: 3),
                            decoration: BoxDecoration(
                              color: _methodBg,
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Text(
                              _methodLabel,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: _methodColor,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Total belanja
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      fmtRp(total),
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'total belanja',
                      style:
                          TextStyle(fontSize: 11, color: Colors.grey.shade400),
                    ),
                  ],
                ),
              ],
            ),
            // Progress bar
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.zero,
              child: LinearProgressIndicator(
                value: ratio.clamp(0.0, 1.0),
                minHeight: 5,
                backgroundColor: const Color(0xFFF0F0F0),
                color: _methodColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//  Empty State

class _EmptyTransaksiView extends StatelessWidget {
  final String periode;
  const _EmptyTransaksiView({required this.periode});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: const BoxDecoration(
              color: AppColors.brandLight,
              shape: BoxShape.rectangle,
            ),
            child: const Icon(Icons.receipt_long_outlined,
                size: 48, color: AppColors.primaryBrand),
          ),
          const SizedBox(height: 18),
          const Text(
            'Tidak ada transaksi',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Belum ada data di $periode ini',
            style: const TextStyle(fontSize: 13, color: Colors.black45),
          ),
          const SizedBox(height: 4),
          const Text(
            'Coba ubah periode atau tanggal',
            style: TextStyle(fontSize: 12, color: Colors.black38),
          ),
        ],
      ),
    );
  }
}

