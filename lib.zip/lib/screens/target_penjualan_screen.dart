import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';
import '../utils/currency_input_formatter.dart';

const Color _kBrand = AppColors.primaryBrand;

class TargetPenjualanScreen extends ConsumerStatefulWidget {
  const TargetPenjualanScreen({super.key});

  @override
  ConsumerState<TargetPenjualanScreen> createState() =>
      _TargetPenjualanScreenState();
}

class _TargetPenjualanScreenState extends ConsumerState<TargetPenjualanScreen> {
  final _dailyCtrl = TextEditingController();
  final _monthlyCtrl = TextEditingController();
  bool _loaded = false;
  bool _isSaving = false;

  @override
  void dispose() {
    _dailyCtrl.dispose();
    _monthlyCtrl.dispose();
    super.dispose();
  }

  String _fK(int n) {
    if (n == 0) return '0';
    String s = n.toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return r;
  }

  Future<void> _save() async {
    if (_isSaving) return;
    setState(() => _isSaving = true);
    try {
      final daily = parseCurrencyInput(_dailyCtrl.text);
      final monthly = parseCurrencyInput(_monthlyCtrl.text);
      await ref
          .read(salesTargetProvider.notifier)
          .setTargets(daily: daily, monthly: monthly);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Target penjualan berhasil disimpan'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      );
      Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Gagal menyimpan target. Silakan coba lagi.'),
            backgroundColor: Colors.red.shade700,
            behavior: SnackBarBehavior.floating,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final target = ref.watch(salesTargetProvider);
    if (!_loaded) {
      _loaded = true;
      if (target.dailyTarget > 0) {
        _dailyCtrl.text = _fK(target.dailyTarget);
      }
      if (target.monthlyTarget > 0) {
        _monthlyCtrl.text = _fK(target.monthlyTarget);
      }
    }

    final sidePanel = Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: AppColors.gradTeal,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.zero,
              boxShadow: [
                BoxShadow(
                  color: _kBrand.withValues(alpha: 0.25),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child:
                const Icon(Icons.flag_rounded, color: Colors.white, size: 48),
          ),
          const SizedBox(height: 24),
          const Text(
            'Atur Target Omzet',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Target akan tampil di dashboard sebagai progress ring. Pantau pencapaian harian dan bulanan Anda dengan mudah.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.black54,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );

    final formContent = ListView(
      padding: responsivePadding(context).copyWith(bottom: 24),
      children: [
        // Icon hero (only shown if not in two-panel mode)
        if (!isLandscape(context)) ...[
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: AppColors.gradTeal,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.zero,
              boxShadow: [
                BoxShadow(
                  color: _kBrand.withValues(alpha: 0.25),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: const Icon(Icons.flag_rounded,
                      color: Colors.white, size: 28),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Atur Target Omzet',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Target akan tampil di dashboard sebagai progress ring.',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.8),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),
        ],

        if (isLandscape(context)) ...[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const _SectionLabel('Target Omzet Harian'),
                    const SizedBox(height: 8),
                    _TargetField(
                      controller: _dailyCtrl,
                      hint: '0',
                      icon: Icons.today_rounded,
                      subtitle: 'Target setiap hari',
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const _SectionLabel('Target Omzet Bulanan'),
                    const SizedBox(height: 8),
                    _TargetField(
                      controller: _monthlyCtrl,
                      hint: '0',
                      icon: Icons.calendar_month_rounded,
                      subtitle: 'Target setiap bulan',
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
        ] else ...[
          // Target Harian
          const _SectionLabel('Target Omzet Harian'),
          const SizedBox(height: 8),
          _TargetField(
            controller: _dailyCtrl,
            hint: '0',
            icon: Icons.today_rounded,
            subtitle: 'Target yang harus dicapai setiap hari',
          ),
          const SizedBox(height: 24),

          // Target Bulanan
          const _SectionLabel('Target Omzet Bulanan'),
          const SizedBox(height: 8),
          _TargetField(
            controller: _monthlyCtrl,
            hint: '0',
            icon: Icons.calendar_month_rounded,
            subtitle: 'Target yang harus dicapai setiap bulan',
          ),
          const SizedBox(height: 24),
        ],

        // Info
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF8EC),
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFFFE0A0)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.info_outline_rounded,
                  color: Color(0xFFD97706), size: 18),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Isi 0 atau kosongkan jika tidak ingin menampilkan target. '
                  'Notifikasi akan dikirim saat target tercapai.',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.orange.shade800,
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 32),
        SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton(
            onPressed: _isSaving ? null : _save,
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              foregroundColor: Colors.white,
              disabledBackgroundColor: _kBrand.withValues(alpha: 0.6),
              elevation: 0,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            child: _isSaving
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2.5))
                : const Text('Simpan Target',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          height: 52,
          child: OutlinedButton(
            onPressed: _isSaving
                ? null
                : () {
                    _dailyCtrl.clear();
                    _monthlyCtrl.clear();
                    _save();
                  },
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.red.shade600,
              side: BorderSide(color: Colors.red.shade200),
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            child: const Text('Hapus Target',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ),
        ),
      ],
    );

    return KasirResponsiveScaffold(
      title: 'Target Omzet',
      showNavRail: false,
      backgroundColor: Colors.white,
      body: Row(
        children: [
          if (isLandscape(context)) Expanded(child: sidePanel),
          Expanded(flex: 3, child: formContent),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
          fontSize: 14, fontWeight: FontWeight.w600, color: Colors.black87),
    );
  }
}

class _TargetField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final String subtitle;

  const _TargetField({
    required this.controller,
    required this.hint,
    required this.icon,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF6F7F9),
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE8E8E8)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: _kBrand, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: controller,
                  keyboardType: TextInputType.number,
                  inputFormatters: const [CurrencyInputFormatter()],
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                  decoration: InputDecoration(
                    prefixText: 'Rp ',
                    prefixStyle: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: _kBrand,
                    ),
                    hintText: hint,
                    hintStyle: const TextStyle(color: Colors.black26),
                    border: InputBorder.none,
                    isDense: true,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: const TextStyle(fontSize: 11, color: Colors.black45),
          ),
        ],
      ),
    );
  }
}

