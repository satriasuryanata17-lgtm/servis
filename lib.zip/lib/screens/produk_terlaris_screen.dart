import 'package:flutter/material.dart';

import '../database/db_helper.dart';
import '../core/theme.dart';
import '../widgets/kasir_dialog.dart';
import '../widgets/responsive_layout.dart';
import '../widgets/export_dropdown.dart';
import '../services/export_service.dart';

const Color _kBrand = AppColors.primaryBrand;

String _fmtQty(dynamic value) {
  final qty = (value as num?)?.toDouble() ?? 0;
  return qty
      .toStringAsFixed(2)
      .replaceAll(RegExp(r'0+$'), '')
      .replaceAll(RegExp(r'\.$'), '')
      .replaceAll('.', ',');
}

class ProdukTerlarisScreen extends StatefulWidget {
  const ProdukTerlarisScreen({super.key});

  @override
  State<ProdukTerlarisScreen> createState() => _ProdukTerlarisScreenState();
}

class _ProdukTerlarisScreenState extends State<ProdukTerlarisScreen> {
  String _periode = 'Periode Tahunan';
  int _tahun = DateTime.now().year;
  int _bulan = DateTime.now().month;
  DateTime _hariTerpilih = DateTime.now();

  static const _bulanNama = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember'
  ];

  DateTime? _customStart;
  DateTime? _customEnd;

  List<Map<String, dynamic>>? _topProducts;
  bool _isLoading = false;

  final List<String> _periodeOptions = [
    'Periode Harian',
    'Periode Bulanan',
    'Periode Tahunan',
    'Kustom Tanggal',
  ];
  final List<int> _tahunOptions = [
    DateTime.now().year - 2,
    DateTime.now().year - 1,
    DateTime.now().year,
    DateTime.now().year + 1,
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    DateTime start;
    DateTime end;

    if (_periode == 'Periode Harian') {
      start =
          DateTime(_hariTerpilih.year, _hariTerpilih.month, _hariTerpilih.day);
      end = DateTime(_hariTerpilih.year, _hariTerpilih.month, _hariTerpilih.day,
          23, 59, 59);
    } else if (_periode == 'Periode Bulanan') {
      start = DateTime(_tahun, _bulan, 1);
      var nextMonth = _bulan == 12 ? 1 : _bulan + 1;
      var nextYear = _bulan == 12 ? _tahun + 1 : _tahun;
      end =
          DateTime(nextYear, nextMonth, 1).subtract(const Duration(seconds: 1));
    } else if (_periode == 'Kustom Tanggal') {
      final now = DateTime.now();
      start = _customStart ?? DateTime(now.year, now.month, now.day);
      end = _customEnd ?? DateTime(now.year, now.month, now.day, 23, 59, 59);
    } else {
      start = DateTime(_tahun, 1, 1);
      end = DateTime(_tahun, 12, 31, 23, 59, 59);
    }

    final data = await DBHelper.instance
        .getTopSellingProductsByDateRange(start, end, limit: 30);
    if (!mounted) return;
    setState(() {
      _topProducts = data;
      _isLoading = false;
    });
  }

  Future<void> _pickCustomDate() async {
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2050),
      initialDateRange: _customStart != null && _customEnd != null
          ? DateTimeRange(start: _customStart!, end: _customEnd!)
          : null,
      builder: (context, child) => Theme(
        data: ThemeData.light().copyWith(
          colorScheme: const ColorScheme.light(
            primary: _kBrand,
            onPrimary: Colors.white,
            surface: Colors.white,
            onSurface: Colors.black,
          ),
        ),
        child: child!,
      ),
    );
    if (range != null) {
      setState(() {
        _customStart = range.start;
        _customEnd = range.end;
      });
      _loadData();
    } else {
      setState(() => _periode = 'Periode Tahunan');
      _loadData();
    }
  }

  Future<void> _showBulanSheet() async {
    final selected = await showKasirOptionSheet<int>(
      context,
      title: 'Pilih Bulan',
      options: List.generate(12, (i) => i + 1),
      currentValue: _bulan,
      labelBuilder: (b) => _bulanNama[b - 1],
    );
    if (selected != null && selected != _bulan && mounted) {
      setState(() => _bulan = selected);
      _loadData();
    }
  }

  Future<void> _pickHariDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _hariTerpilih,
      firstDate: DateTime(2020),
      lastDate: DateTime(2050),
      builder: (context, child) => Theme(
        data: ThemeData.light().copyWith(
          colorScheme: const ColorScheme.light(
            primary: _kBrand,
            onPrimary: Colors.white,
            surface: Colors.white,
            onSurface: Colors.black,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _hariTerpilih = picked);
      _loadData();
    }
  }

  Future<void> _showPeriodeSheet() async {
    final selected = await showKasirOptionSheet<String>(
      context,
      title: 'Pilih Periode',
      options: _periodeOptions,
      currentValue: _periode,
      labelBuilder: (v) => v,
    );
    if (selected != null && selected != _periode && mounted) {
      setState(() => _periode = selected);
      if (selected == 'Kustom Tanggal') {
        _pickCustomDate();
      } else {
        _loadData();
      }
    }
  }

  Future<void> _exportData() async {
    final choice = await ExportDropdown.show(context);
    if (choice == null) return;

    final top = _topProducts ?? [];
    if (!mounted) return;
    if (top.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Belum ada data layanan terjual.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      return;
    }

    String dateInfo = _periode;
    if (_periode == 'Periode Bulanan') {
      dateInfo = '${_bulanNama[_bulan - 1]} $_tahun';
    } else if (_periode == 'Periode Harian') {
      dateInfo =
          '${_hariTerpilih.day} ${_bulanNama[_hariTerpilih.month - 1]} ${_hariTerpilih.year}';
    } else if (_periode == 'Kustom Tanggal' && _customStart != null) {
      dateInfo =
          '${_customStart!.day}/${_customStart!.month}/${_customStart!.year} - ${_customEnd!.day}/${_customEnd!.month}/${_customEnd!.year}';
    } else {
      dateInfo = '$_tahun';
    }

    final headers = ['Nama Layanan', 'Software', 'Total Terjual'];
    final rows = top
        .map((row) => [
              row['name'] ?? '-',
              row['unit'] ?? '-',
              _fmtQty(row['total_sold']),
            ])
        .toList();

    final Map<String, String> summaryData = {
      'Total Layanan': '${top.length} Item',
      'Layanan Teratas': (top.first['name'] ?? '-').toString(),
      'Periode': _periode,
      'Filter': dateInfo,
    };

    const title = 'Laporan Layanan Terlaris';

    try {
      if (choice == 'csv') {
        await ExportService.exportAndShareCsv(
          filePrefix: 'produk_terlaris',
          headers: [
            'Nama Layanan',
            'Software',
            'Total Terjual',
            'Periode',
            'Tanggal Filter'
          ],
          rows: top
              .map((row) => [
                    row['name'] ?? '-',
                    row['unit'] ?? '-',
                    _fmtQty(row['total_sold']),
                    _periode,
                    dateInfo
                  ])
              .toList(),
          subject: 'Ekspor Layanan Terlaris',
          message: 'Filter: $dateInfo',
        );
      } else if (choice == 'pdf') {
        await ExportService.exportPdfLaporan(
          title: title,
          subtitle: 'Filter: $dateInfo',
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      } else if (choice == 'print') {
        await ExportService.printPdfLaporan(
          title: title,
          subtitle: 'Filter: $dateInfo',
          headers: headers,
          rows: rows,
          summaryData: summaryData,
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Gagal mengekspor data. Silakan coba lagi.')),
      );
    }
  }

  Future<void> _showTahunSheet() async {
    final selected = await showKasirOptionSheet<int>(
      context,
      title: 'Pilih Tahun',
      options: _tahunOptions,
      currentValue: _tahun,
      labelBuilder: (y) => y.toString(),
    );
    if (selected != null && selected != _tahun && mounted) {
      setState(() => _tahun = selected);
      _loadData();
    }
  }

  //  BUILD
  @override
  Widget build(BuildContext context) {
    final isTablet = KasirLayout.isTablet(context);
    final isLandscape = KasirLayout.isLandscape(context);

    return KasirResponsiveScaffold(
      title: 'Layanan Terlaris',
      showNavRail: false,
      navIndex: 4,
      backgroundColor: Colors.white,
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: GestureDetector(
            onTap: _exportData,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: const BoxDecoration(
                color: AppColors.primaryBrand,
                borderRadius: BorderRadius.zero,
              ),
              child: const Row(
                children: [
                  Icon(Icons.download_rounded, color: Colors.white, size: 15),
                  SizedBox(width: 5),
                  Text(
                    'Ekspor',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
      body: (isTablet || isLandscape)
          ? _buildWideLayout()
          : _buildPortraitLayout(),
    );
  }

  //  Wide: filter panel left, list right
  Widget _buildWideLayout() {
    return KasirLandscapeSplit(
      leftWidth: 260,
      leftPanel: _buildFilterPanel(),
      rightPanel:
          _buildProductList(padding: const EdgeInsets.fromLTRB(20, 16, 20, 20)),
    );
  }

  //  Portrait: stacked header + list
  Widget _buildPortraitLayout() {
    return Column(
      children: [
        const Divider(height: 1, color: Color(0xFFEEEEEE)),
        KasirPeriodBar(
          periode: _periode,
          tahun: _tahun,
          bulan: _bulan,
          hariTerpilih: _hariTerpilih,
          customStart: _customStart,
          customEnd: _customEnd,
          onPeriodeTap: _showPeriodeSheet,
          onTahunTap: _showTahunSheet,
          onBulanTap: _showBulanSheet,
          onHariTap: _pickHariDate,
        ),
        const SizedBox(height: 12),
        Expanded(
            child: _buildProductList(
                padding: const EdgeInsets.symmetric(horizontal: 16))),
      ],
    );
  }

  //  Filter panel (for wide layout left side)
  Widget _buildFilterPanel() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Filter Periode',
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF64748B))),
          const SizedBox(height: 12),
          ..._periodeOptions.map((opt) => _FilterOption(
                label: opt,
                selected: _periode == opt,
                onTap: () {
                  setState(() => _periode = opt);
                  if (opt == 'Kustom Tanggal') {
                    _pickCustomDate();
                  } else {
                    _loadData();
                  }
                },
              )),
          if (_periode == 'Periode Bulanan') ...[
            const SizedBox(height: 16),
            const Text('Bulan',
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF64748B))),
            const SizedBox(height: 8),
            _DropdownTile(
              label: _bulanNama[_bulan - 1],
              onTap: _showBulanSheet,
            ),
            const SizedBox(height: 8),
            _DropdownTile(
              label: _tahun.toString(),
              onTap: _showTahunSheet,
            ),
          ] else if (_periode == 'Periode Tahunan' ||
              _periode == 'Periode Harian') ...[
            const SizedBox(height: 16),
            const Text('Waktu',
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF64748B))),
            const SizedBox(height: 8),
            _DropdownTile(
              label: _periode == 'Periode Harian'
                  ? '${_hariTerpilih.day} ${_bulanNama[_hariTerpilih.month - 1]} ${_hariTerpilih.year}'
                  : _tahun.toString(),
              onTap: _periode == 'Periode Harian'
                  ? _pickHariDate
                  : _showTahunSheet,
            ),
          ] else if (_periode == 'Kustom Tanggal' && _customStart != null) ...[
            const SizedBox(height: 16),
            const Text('Rentang Tanggal',
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF64748B))),
            const SizedBox(height: 8),
            _DropdownTile(
              label:
                  '${_customStart!.day}/${_customStart!.month}  ${_customEnd!.day}/${_customEnd!.month}',
              onTap: _pickCustomDate,
            ),
          ],
          // Summary stat
          if (_topProducts != null && !_isLoading) ...[
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppColors.primaryBrand, AppColors.primaryDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.zero,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Total Layanan',
                      style: TextStyle(color: Colors.white70, fontSize: 11)),
                  const SizedBox(height: 4),
                  Text(
                    '${_topProducts!.length} item',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(_periode,
                      style:
                          const TextStyle(color: Colors.white60, fontSize: 11)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  //  Product list
  Widget _buildProductList({EdgeInsets padding = EdgeInsets.zero}) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: _kBrand));
    }
    if (_topProducts == null || _topProducts!.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.bar_chart_outlined, size: 56, color: Colors.grey[300]),
            const SizedBox(height: 12),
            const Text('Belum ada data layanan terjual pada periode ini.',
                style: TextStyle(color: Colors.black54)),
          ],
        ),
      );
    }
    return ListView.separated(
      padding: padding,
      itemCount: _topProducts!.length,
      separatorBuilder: (_, __) =>
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
      itemBuilder: (_, i) {
        final row = _topProducts![i];
        final sold = _fmtQty(row['total_sold']);
        final name = '${row['name'] ?? '-'}';
        final unit = '${row['unit'] ?? '-'}';

        Color rankColor = _kBrand;
        if (i == 0) rankColor = const Color(0xFFFFB300); // gold
        if (i == 1) rankColor = const Color(0xFF90A4AE); // silver
        if (i == 2) rankColor = const Color(0xFF8D6E63); // bronze

        return ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          leading: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: rankColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.zero,
            ),
            alignment: Alignment.center,
            child: Text(
              '${i + 1}',
              style: TextStyle(
                  color: rankColor, fontWeight: FontWeight.bold, fontSize: 14),
            ),
          ),
          title: Text(name,
              style:
                  const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
          subtitle: Text('Terjual: $sold $unit',
              style: const TextStyle(color: Colors.black54, fontSize: 12)),
          trailing: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: _kBrand.withValues(alpha: 0.08),
              borderRadius: BorderRadius.zero,
            ),
            child: Text(sold,
                style: const TextStyle(
                    color: _kBrand, fontWeight: FontWeight.bold, fontSize: 13)),
          ),
        );
      },
    );
  }
}

//
// FILTER OPTION ROW (for wide left panel)
//
class _FilterOption extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _FilterOption(
      {required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: selected
              ? AppColors.primaryBrand.withValues(alpha: 0.10)
              : Colors.transparent,
          borderRadius: BorderRadius.zero,
          border: Border.all(
            color: selected ? AppColors.primaryBrand : const Color(0xFFE2E8F0),
          ),
        ),
        child: Row(
          children: [
            Icon(
              selected ? Icons.radio_button_checked : Icons.radio_button_off,
              size: 18,
              color: selected ? AppColors.primaryBrand : Colors.grey,
            ),
            const SizedBox(width: 10),
            Text(label,
                style: TextStyle(
                    fontWeight: selected ? FontWeight.w700 : FontWeight.normal,
                    color: selected
                        ? AppColors.primaryBrand
                        : const Color(0xFF374151),
                    fontSize: 13)),
          ],
        ),
      ),
    );
  }
}

class _DropdownTile extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _DropdownTile({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: const BoxDecoration(
          color: Color(0xFFF5F5F5),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          children: [
            Expanded(
                child: Text(label,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 13))),
            const Icon(Icons.keyboard_arrow_down_rounded,
                color: AppColors.primaryBrand, size: 20),
          ],
        ),
      ),
    );
  }
}

