import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../providers/providers.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import 'struk_screen.dart';
import '../core/theme.dart';
import '../widgets/responsive_layout.dart';
import '../utils/transaction_code_formatter.dart';
import 'main_shell.dart';

const Color _kBrand = AppColors.primaryBrand;

String _fK(int n) {
  if (n == 0) return '0';
  String s = n.toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) r = '.$r';
  }
  return r;
}

String _fmtQty(double n) {
  return n
      .toStringAsFixed(2)
      .replaceAll(RegExp(r'0+$'), '')
      .replaceAll(RegExp(r'\.$'), '')
      .replaceAll('.', ',');
}

String _itemUnit(TransactionItem item) {
  final unit = item.unit?.trim();
  if (unit != null && unit.isNotEmpty) return unit;
  return item.isHardware == 1 ? 'kg' : '';
}

double _itemBillableQty(TransactionItem item) {
  if (item.unitPrice <= 0 || item.subtotal <= 0) return item.qty;
  final billed = item.subtotal / item.unitPrice;
  return billed > 0 ? billed : item.qty;
}

bool _hasRoundedBilling(TransactionItem item) {
  final unit = _itemUnit(item).toLowerCase();
  if (unit != 'kg' && item.isHardware != 1) return false;
  return (_itemBillableQty(item) - item.qty).abs() > 0.001;
}

String _itemPriceLine(TransactionItem item) {
  final unit = _itemUnit(item);
  final unitSuffix = unit.isEmpty ? '' : '/$unit';
  final qtyLabel =
      unit.isEmpty ? _fmtQty(item.qty) : '${_fmtQty(item.qty)} $unit';
  final rounded = _hasRoundedBilling(item)
      ? ' (tagih ${_fmtQty(_itemBillableQty(item))} $unit)'
      : '';
  return '$qtyLabel$rounded x Rp${_fK(item.unitPrice)}$unitSuffix';
}

String _formatNoPesanan(Transaction tx) {
  return TransactionCodeFormatter.format(
    id: tx.id ?? 0,
    createdAt: tx.createdAt,
    transactionCode: tx.transactionCode,
  );
}

// SCREEN

class PesananBerhasilScreen extends ConsumerStatefulWidget {
  final int transactionId;
  final String customerName;
  final String jenisPesanan;
  final int antrian;

  const PesananBerhasilScreen({
    super.key,
    required this.transactionId,
    required this.customerName,
    this.jenisPesanan = '',
    this.antrian = 1,
  });

  @override
  ConsumerState<PesananBerhasilScreen> createState() =>
      _PesananBerhasilScreenState();
}

class _PesananBerhasilScreenState extends ConsumerState<PesananBerhasilScreen> {
  Transaction? _tx;
  List<Map<String, dynamic>> _itemsWithExtra = [];
  bool _loading = true;
  bool _expanded = false;
  final Map<int, bool> _itemChecked = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final tx =
          await DBHelper.instance.getTransactionById(widget.transactionId);
      final items =
          await DBHelper.instance.getTransactionItems(widget.transactionId);
      if (!mounted) return;
      final List<Map<String, dynamic>> itemsWithExtra = [];
      for (final item in items) {
        final p = await DBHelper.instance.getProductById(item.productId);
        itemsWithExtra.add({'item': item, 'isExtra': p?.isExtra ?? 0});
      }
      if (!mounted) return;
      setState(() {
        _tx = tx;
        _itemsWithExtra = itemsWithExtra;
        _loading = false;
        for (int i = 0; i < itemsWithExtra.length; i++) {
          _itemChecked[i] = false;
        }
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content:
            Text('Gagal memuat data pesanan. Silakan kembali dan coba lagi.'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
    }
  }

  String get _noPesanan {
    if (_tx == null) return '';
    return _formatNoPesanan(_tx!);
  }

  String get _tanggalWaktu {
    if (_tx == null) return '';
    try {
      return DateFormat('d MMM yyyy HH:mm')
          .format(DateTime.parse(_tx!.createdAt));
    } catch (_) {
      return '';
    }
  }

  void _copyNoPesanan() {
    Clipboard.setData(ClipboardData(text: _noPesanan));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Nomor pesanan disalin'),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 1),
        backgroundColor: Colors.black87,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
  }

  void _hapusItem(int index) {
    setState(() {
      _itemsWithExtra.removeAt(index);
      final newMap = <int, bool>{};
      for (int i = 0; i < _itemsWithExtra.length; i++) {
        newMap[i] = _itemChecked[i < index ? i : i + 1] ?? false;
      }
      _itemChecked
        ..clear()
        ..addAll(newMap);
    });
  }

  void _showCetakStrukSheet() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StrukScreen(transactionId: widget.transactionId),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = KasirLayout.isTablet(context);
    final isLandscape = KasirLayout.isLandscape(context);
    final isDirect = widget.jenisPesanan == 'Bayar Langsung';

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: const Padding(
              padding: EdgeInsets.only(left: 12),
              child:
                  Icon(Icons.arrow_back_ios_rounded, color: _kBrand, size: 20)),
        ),
        title: Text(
            isDirect ? 'Pembayaran Berhasil' : 'Pesanan Servis Berhasil',
            style: const TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.bold,
                fontSize: 20)),
        centerTitle: false,
        bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1),
            child: Container(height: 1, color: const Color(0xFFEEEEEE))),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _kBrand))
          : (isTablet && isLandscape)
              ? _buildWideLayout(isDirect)
              : _buildPortraitLayout(isDirect),
      bottomNavigationBar: _buildBottomBar(isDirect),
    );
  }

  Widget _buildWideLayout(bool isDirect) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Left: success illustration + summary stats
        Container(
          width: 280,
          color: const Color(0xFFF8FAFC),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 180,
                  child: Image.asset('assets/images/logo.png',
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => _FallbackIllustration()),
                ),
                const SizedBox(height: 16),
                Text(
                    isDirect
                        ? 'Pembayaran Berhasil!'
                        : 'Pesanan Servis Berhasil!',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Colors.black87),
                    textAlign: TextAlign.center),
                if (!isDirect) ...[
                  const SizedBox(height: 20),
                  // Queue number badge
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                          colors: [AppColors.primaryBrand, Color(0xFF1E40AF)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Column(children: [
                      const Text('No. Antrian',
                          style:
                              TextStyle(color: Colors.white70, fontSize: 12)),
                      const SizedBox(height: 6),
                      Text('${widget.antrian}',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 48,
                              fontWeight: FontWeight.w900)),
                      if (widget.jenisPesanan.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(widget.jenisPesanan,
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 12)),
                      ],
                    ]),
                  ),
                ] else ...[
                  const SizedBox(height: 12),
                  const Icon(Icons.check_circle_rounded,
                      color: Colors.green, size: 48),
                  const SizedBox(height: 8),
                  const Text('Transaksi Selesai',
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.w600)),
                ],
              ],
            ),
          ),
        ),
        Container(width: 1, color: const Color(0xFFE2E8F0)),
        // Right: order detail card
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: _buildOrderCard(isDirect),
          ),
        ),
      ],
    );
  }

  Widget _buildPortraitLayout(bool isDirect) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
              height: 220,
              child: Image.asset('assets/images/logo.png',
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => _FallbackIllustration())),
          const SizedBox(height: 16),
          Text(
              isDirect
                  ? 'Pembayaran Berhasil Ditambahkan'
                  : 'Pesanan Servis Berhasil Ditambahkan',
              style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: Colors.black87),
              textAlign: TextAlign.center),
          const SizedBox(height: 20),
          _buildOrderCard(isDirect),
          const SizedBox(height: 90),
        ],
      ),
    );
  }

  Widget _buildOrderCard(bool isDirect) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFEEEEEE), width: 1),
        borderRadius: BorderRadius.zero,
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Wrap(spacing: 6, runSpacing: 4, children: [
          _Badge(
            label: isDirect ? 'LUNAS' : 'Pesanan Diproses',
            color: isDirect ? const Color(0xFFE8F5E9) : const Color(0xFFFFF3CD),
            textColor:
                isDirect ? const Color(0xFF2E7D32) : const Color(0xFF856404),
          ),
          if (widget.jenisPesanan.isNotEmpty && !isDirect)
            _Badge(
                label: widget.jenisPesanan,
                color: Colors.white,
                textColor: Colors.black87,
                outlined: true),
        ]),
        const SizedBox(height: 10),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                  widget.customerName.isEmpty
                      ? 'Pelanggan'
                      : widget.customerName,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 4),
              GestureDetector(
                onTap: _copyNoPesanan,
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text('No. $_noPesanan',
                      style: const TextStyle(
                          color: _kBrand,
                          fontSize: 13,
                          fontWeight: FontWeight.w500)),
                  const SizedBox(width: 4),
                  const Icon(Icons.copy_rounded, size: 14, color: _kBrand),
                ]),
              ),
              const SizedBox(height: 2),
              Text(
                  '$_tanggalWaktu${isDirect ? '' : '  -  Antrian ${widget.antrian}'}',
                  style: const TextStyle(color: Colors.black54, fontSize: 12)),
            ]),
          ),
          GestureDetector(
            onTap: () => setState(() => _expanded = !_expanded),
            child: Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Icon(
                    _expanded
                        ? Icons.keyboard_arrow_up_rounded
                        : Icons.keyboard_arrow_down_rounded,
                    color: _kBrand,
                    size: 24)),
          ),
        ]),
        if (_expanded) ...[
          const SizedBox(height: 12),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          const SizedBox(height: 10),
          ..._itemsWithExtra.asMap().entries.map((entry) {
            final i = entry.key;
            final data = entry.value;
            final item = data['item'] as TransactionItem;
            final isExtra = data['isExtra'] == 1;
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                              width: 22,
                              height: 22,
                              child: Checkbox(
                                value: _itemChecked[i] ?? false,
                                onChanged: (v) =>
                                    setState(() => _itemChecked[i] = v!),
                                activeColor: _kBrand,
                                side: const BorderSide(
                                    color: Color(0xFFBDBDBD), width: 1.5),
                                materialTapTargetSize:
                                    MaterialTapTargetSize.shrinkWrap,
                                visualDensity: VisualDensity.compact,
                              )),
                          const SizedBox(width: 8),
                          Expanded(
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                Row(children: [
                                  if (isExtra)
                                    Container(
                                        margin: const EdgeInsets.only(right: 6),
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 4, vertical: 2),
                                        decoration: BoxDecoration(
                                            color:
                                                _kBrand.withValues(alpha: 0.1),
                                            borderRadius: BorderRadius.zero),
                                        child: const Text('ADD ON',
                                            style: TextStyle(
                                                color: _kBrand,
                                                fontSize: 8,
                                                fontWeight: FontWeight.bold))),
                                  Expanded(
                                      child: Text(item.productName,
                                          style: const TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.w500))),
                                ]),
                                const SizedBox(height: 2),
                                Text(_itemPriceLine(item),
                                    style: const TextStyle(
                                        fontSize: 12, color: Colors.black54)),
                              ])),
                          Text('Rp${_fK(item.subtotal)}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600, fontSize: 13)),
                          const SizedBox(width: 8),
                          GestureDetector(
                              onTap: () => _hapusItem(i),
                              child: const Icon(AppIcons.recycleBin,
                                  color: Color(0xFFBDBDBD), size: 20)),
                        ]),
                    if (item.note != null && item.note!.isNotEmpty)
                      Padding(
                          padding: const EdgeInsets.only(top: 2, left: 30),
                          child: Text(item.note!,
                              style: const TextStyle(
                                  fontSize: 11,
                                  color: Colors.black54,
                                  fontStyle: FontStyle.italic))),
                  ]),
            );
          }),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Total Pesanan', style: TextStyle(fontSize: 13)),
            Text('Rp${_fK(_tx?.totalAmount ?? 0)}',
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
          ]),
          const SizedBox(height: 4),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Total',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            Text('Rp${_fK(_tx?.grandTotal ?? 0)}',
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 16, color: _kBrand)),
          ]),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {
                final scope = ShellScope.of(context);
                if (scope != null) {
                  Navigator.of(context).popUntil((r) => r.isFirst);
                  ref
                      .read(riwayatTabProvider.notifier)
                      .set(1); // Go to Tagihan tab
                  scope.onNavigate(4);
                } else {
                  ref
                      .read(riwayatTabProvider.notifier)
                      .set(1); // Go to Tagihan tab
                  ref.read(shellIndexProvider.notifier).set(4);
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => const MainShell()),
                    (r) => false,
                  );
                }
              },
              style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: _kBrand),
                  foregroundColor: _kBrand,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                  padding: const EdgeInsets.symmetric(vertical: 12)),
              child: const Text('Lihat Riwayat & Tagihan',
                  style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ]),
    );
  }

  Widget _buildBottomBar(bool isDirect) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
      decoration: BoxDecoration(
          color: Colors.white,
          border: const Border(top: BorderSide(color: Color(0xFFEEEEEE))),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 8,
                offset: const Offset(0, -2))
          ]),
      child: SafeArea(
        child: SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton(
            onPressed: _showCetakStrukSheet,
            style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                elevation: 0,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero)),
            child: Text(
                isDirect ? 'Cetak Struk Pembayaran' : 'Cetak Struk Servis',
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16)),
          ),
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String label;
  final Color color, textColor;
  final bool outlined;
  const _Badge(
      {required this.label,
      required this.color,
      required this.textColor,
      this.outlined = false});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
            color: outlined ? Colors.white : color,
            border:
                Border.all(color: outlined ? Colors.black54 : color, width: 1),
            borderRadius: BorderRadius.zero),
        child: Text(label,
            style: TextStyle(
                fontSize: 12, fontWeight: FontWeight.w500, color: textColor)),
      );
}

class _FallbackIllustration extends StatelessWidget {
  @override
  Widget build(BuildContext context) =>
      Stack(alignment: Alignment.center, children: [
        Container(
            width: 120,
            height: 200,
            decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFF37474F), width: 3),
                borderRadius: BorderRadius.zero),
            child: Center(
                child: Container(
                    width: 56,
                    height: 56,
                    decoration: const BoxDecoration(
                        color: _kBrand, shape: BoxShape.rectangle),
                    child: const Icon(Icons.check,
                        color: Colors.white, size: 32)))),
      ]);
}

