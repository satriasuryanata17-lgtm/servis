import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import '../core/theme.dart';
import '../services/scan_feedback_service.dart';
import 'responsive_layout.dart';

class NotifikasiScreen extends ConsumerStatefulWidget {
  const NotifikasiScreen({super.key});

  @override
  ConsumerState<NotifikasiScreen> createState() => _NotifikasiScreenState();
}

class _NotifikasiScreenState extends ConsumerState<NotifikasiScreen> {
  late bool _showStok;
  late bool _showKeuangan;
  late bool _showSistem;
  late bool _useTTS;
  late TextEditingController _stokCtrl;
  late TextEditingController _expiryCtrl;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _stokCtrl = TextEditingController();
    _expiryCtrl = TextEditingController();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      final settings = ref.read(notificationSettingsProvider);
      _showStok = settings.showStok;
      _showKeuangan = settings.showKeuangan;
      _showSistem = settings.showSistem;
      _useTTS = settings.useTTS;
      _stokCtrl.text = settings.minStok.toString();
      _expiryCtrl.text = settings.expiryDays.toString();
      _initialized = true;
    }
  }

  @override
  void dispose() {
    _stokCtrl.dispose();
    _expiryCtrl.dispose();
    super.dispose();
  }

  void _simpan() async {
    final minStok = int.tryParse(_stokCtrl.text) ?? 5;
    final expiryDays = int.tryParse(_expiryCtrl.text) ?? 30;
    final newSettings = NotificationSettings(
      showStok: _showStok,
      showKeuangan: _showKeuangan,
      showSistem: _showSistem,
      useTTS: _useTTS,
      minStok: minStok,
      expiryDays: expiryDays,
    );
    await ref.read(notificationSettingsProvider.notifier).update(newSettings);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Row(children: [
          Icon(Icons.check_circle_outline, color: Colors.white),
          SizedBox(width: 12),
          Text('Pengaturan berhasil disimpan'),
        ]),
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.black87,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ));
      Navigator.pop(context);
    }
  }

  Future<void> _ujiSuaraTts() async {
    await ScanFeedbackService.instance.playTtsPreview(useTts: true);
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Row(children: [
        Icon(Icons.volume_up_outlined, color: Colors.white),
        SizedBox(width: 12),
        Text('Contoh suara pembacaan diputar'),
      ]),
      behavior: SnackBarBehavior.floating,
      backgroundColor: Colors.black87,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      duration: Duration(seconds: 2),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final tablet = isTabletDevice(context);
    final landscape = isLandscape(context);
    final useTwoCols = tablet || landscape;

    return KasirResponsiveScaffold(
      title: 'Pengaturan Notifikasi',
      showNavRail: true,
      backgroundColor: const Color(0xFFF8F9FA),
      body: useTwoCols
          ? _buildTwoColLayout(context, tablet)
          : _buildSingleColLayout(),
    );
  }

  Widget _buildTwoColLayout(BuildContext context, bool tablet) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(vertical: 24),
      child: Center(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: tablet ? 860 : double.infinity),
          child: Padding(
            padding: EdgeInsets.all(tablet ? 28 : 16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 5,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildSectionHeader(
                          'Kategori Notifikasi', Icons.category_outlined),
                      const SizedBox(height: 12),
                      _buildSettingCard(
                        title: 'Notifikasi Stok',
                        subtitle: 'Peringatan stok menipis & kedaluwarsa',
                        icon: Icons.inventory_2_outlined,
                        value: _showStok,
                        onChanged: (v) => setState(() => _showStok = v),
                      ),
                      _buildSettingCard(
                        title: 'Notifikasi Tagihan',
                        subtitle: 'Peringatan tagihan pelanggan belum lunas',
                        icon: Icons.account_balance_wallet_outlined,
                        value: _showKeuangan,
                        onChanged: (v) => setState(() => _showKeuangan = v),
                      ),
                      _buildSettingCard(
                        title: 'Notifikasi Sistem',
                        subtitle: 'Pengingat shift & sistem',
                        icon: Icons.settings_suggest_outlined,
                        value: _showSistem,
                        onChanged: (v) => setState(() => _showSistem = v),
                      ),
                      _buildSettingCard(
                        title: 'Suara Pembacaan (TTS)',
                        subtitle: 'Bacakan hasil scan produk dan transaksi',
                        icon: Icons.record_voice_over_outlined,
                        value: _useTTS,
                        onChanged: (v) => setState(() => _useTTS = v),
                        action: _buildTtsPreviewButton(),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: tablet ? 24 : 16),
                Expanded(
                  flex: 4,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildSectionHeader(
                          'Konfigurasi Peringatan', Icons.tune_rounded),
                      const SizedBox(height: 12),
                      _buildInputCard(
                        title: 'Batas Stok Minimum',
                        subtitle:
                            'Notifikasi muncul jika stok di bawah angka ini',
                        controller: _stokCtrl,
                        icon: Icons.low_priority_rounded,
                        suffix: 'Pcs',
                      ),
                      const SizedBox(height: 12),
                      _buildInputCard(
                        title: 'Pengingat Kedaluwarsa',
                        subtitle: 'Notifikasi muncul X hari sebelum basi',
                        controller: _expiryCtrl,
                        icon: Icons.timer_outlined,
                        suffix: 'Hari',
                      ),
                      const SizedBox(height: 24),
                      _buildSaveBtn(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSingleColLayout() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _buildSectionHeader('Kategori Notifikasi', Icons.category_outlined),
        const SizedBox(height: 12),
        _buildSettingCard(
          title: 'Notifikasi Stok',
          subtitle: 'Peringatan stok menipis & kedaluwarsa',
          icon: Icons.inventory_2_outlined,
          value: _showStok,
          onChanged: (v) => setState(() => _showStok = v),
        ),
        _buildSettingCard(
          title: 'Notifikasi Tagihan',
          subtitle: 'Peringatan tagihan pelanggan belum lunas',
          icon: Icons.account_balance_wallet_outlined,
          value: _showKeuangan,
          onChanged: (v) => setState(() => _showKeuangan = v),
        ),
        _buildSettingCard(
          title: 'Notifikasi Sistem',
          subtitle: 'Pengingat shift & sistem',
          icon: Icons.settings_suggest_outlined,
          value: _showSistem,
          onChanged: (v) => setState(() => _showSistem = v),
        ),
        _buildSettingCard(
          title: 'Suara Pembacaan (TTS)',
          subtitle: 'Bacakan hasil scan produk dan transaksi',
          icon: Icons.record_voice_over_outlined,
          value: _useTTS,
          onChanged: (v) => setState(() => _useTTS = v),
          action: _buildTtsPreviewButton(),
        ),
        const SizedBox(height: 32),
        _buildSectionHeader('Konfigurasi Peringatan', Icons.tune_rounded),
        const SizedBox(height: 12),
        _buildInputCard(
          title: 'Batas Stok Minimum',
          subtitle: 'Notifikasi muncul jika stok di bawah angka ini',
          controller: _stokCtrl,
          icon: Icons.low_priority_rounded,
          suffix: 'Pcs',
        ),
        const SizedBox(height: 16),
        _buildInputCard(
          title: 'Pengingat Kedaluwarsa',
          subtitle: 'Notifikasi muncul X hari sebelum basi',
          controller: _expiryCtrl,
          icon: Icons.timer_outlined,
          suffix: 'Hari',
        ),
        const SizedBox(height: 40),
        _buildSaveBtn(),
      ],
    );
  }

  Widget _buildSaveBtn() {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton(
        onPressed: _simpan,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryBrand,
          foregroundColor: Colors.white,
          shadowColor: AppColors.primaryBrand.withValues(alpha: 0.3),
          elevation: 4,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
        child: const Text('Simpan Pengaturan',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 18, color: Colors.black54),
        const SizedBox(width: 8),
        Text(
          title.toUpperCase(),
          style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: Colors.black54,
              letterSpacing: 1),
        ),
      ],
    );
  }

  Widget _buildSettingCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required bool value,
    required ValueChanged<bool> onChanged,
    Widget? action,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: const BoxDecoration(
                    color: Color(0xFFF8F9FA), borderRadius: BorderRadius.zero),
                child: Icon(icon, color: Colors.black87, size: 22),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87)),
                    Text(subtitle,
                        style: const TextStyle(
                            fontSize: 12, color: Colors.black54)),
                  ],
                ),
              ),
              Switch.adaptive(
                  value: value,
                  onChanged: onChanged,
                  activeThumbColor: AppColors.primaryBrand),
            ],
          ),
          if (action != null) ...[
            const SizedBox(height: 12),
            action,
          ],
        ],
      ),
    );
  }

  Widget _buildTtsPreviewButton() {
    return SizedBox(
      width: double.infinity,
      height: 44,
      child: OutlinedButton.icon(
        onPressed: _ujiSuaraTts,
        icon: const Icon(Icons.volume_up_outlined, size: 18),
        label: const Text('Uji Suara Pembacaan'),
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.primaryBrand,
          side:
              BorderSide(color: AppColors.primaryBrand.withValues(alpha: 0.55)),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }

  Widget _buildInputCard({
    required String title,
    required String subtitle,
    required TextEditingController controller,
    required IconData icon,
    required String suffix,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: const BoxDecoration(
                color: Color(0xFFF8F9FA), borderRadius: BorderRadius.zero),
            child: Icon(icon, color: Colors.black87, size: 22),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87)),
                Text(subtitle,
                    style:
                        const TextStyle(fontSize: 12, color: Colors.black54)),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 80,
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.zero,
              border: Border.all(color: Colors.black12),
            ),
            child: TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
                border: InputBorder.none,
                suffixText: suffix,
                suffixStyle:
                    const TextStyle(fontSize: 10, color: Colors.black38),
              ),
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}

