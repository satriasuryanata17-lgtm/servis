import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../database/db_helper.dart';
import 'pembayaran_screen.dart';
import 'tambah_piutang_screen.dart';
import 'pesanan_berhasil_screen.dart';
import 'struk_screen.dart';
import 'riwayat_tutup_kasir_screen.dart';
import '../widgets/show_error_dialog.dart';
import '../widgets/kasir_dialog.dart';
import '../core/theme.dart';
import '../providers/shortcut_provider.dart';
import 'main_shell.dart';
import '../utils/modern_ui_helpers.dart';
import '../utils/currency_input_formatter.dart';
import '../widgets/cart_price_override_sheet.dart';

// HELPERS

const Color _kBrand = AppColors.primaryBrand;

class _CheckoutEstimateInfo {
  final int durationHours;
  final String sourceLabel;
  final String finishLabel;
  final bool isConfigured;

  const _CheckoutEstimateInfo({
    required this.durationHours,
    required this.sourceLabel,
    required this.finishLabel,
    required this.isConfigured,
  });
}

String _fK(int n) {
  if (n == 0) {
    return '0';
  }
  String s = n.toString(), r = '';
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    r = s[i] + r;
    c++;
    if (c % 3 == 0 && i != 0) {
      r = '.$r';
    }
  }
  return r;
}

String _paymentSettingText(Map<String, dynamic>? settings, String key) {
  return (settings?[key] ?? '').toString().trim();
}

File? _paymentQrisFile(Map<String, dynamic>? settings) {
  final path = _paymentSettingText(settings, 'qris_path');
  if (path.isEmpty) return null;
  final file = File(path);
  return file.existsSync() ? file : null;
}

List<Map<String, String>> _paymentBanksFromSettings(
  Map<String, dynamic>? settings,
) {
  if (settings == null) return const [];

  final banks = <Map<String, String>>[];
  final banksJson = _paymentSettingText(settings, 'banks_json');
  if (banksJson.isNotEmpty) {
    try {
      final decoded = jsonDecode(banksJson);
      if (decoded is List) {
        for (final item in decoded) {
          if (item is! Map) continue;
          final bank = {
            'name': (item['name'] ?? '').toString().trim(),
            'account_number': (item['account_number'] ?? '').toString().trim(),
            'account_name': (item['account_name'] ?? '').toString().trim(),
          };
          if (bank.values.any((value) => value.isNotEmpty)) {
            banks.add(bank);
          }
        }
      }
    } catch (_) {}
  }

  if (banks.isEmpty) {
    final bank = {
      'name': _paymentSettingText(settings, 'bank_name'),
      'account_number': _paymentSettingText(settings, 'account_number'),
      'account_name': _paymentSettingText(settings, 'account_name'),
    };
    if (bank.values.any((value) => value.isNotEmpty)) {
      banks.add(bank);
    }
  }

  return banks;
}

bool _hasBankPaymentDetails(Map<String, dynamic>? settings) {
  return _paymentBanksFromSettings(settings).any((bank) =>
      (bank['name'] ?? '').isNotEmpty ||
      (bank['account_number'] ?? '').isNotEmpty ||
      (bank['account_name'] ?? '').isNotEmpty);
}

void _showNonCashCustomerDisplay(
  BuildContext context, {
  required String mode,
  required Map<String, dynamic> settings,
  required int amount,
}) {
  Navigator.of(context).push(
    MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => _NonCashCustomerDisplayScreen(
        mode: mode,
        settings: Map<String, dynamic>.from(settings),
        amount: amount,
      ),
    ),
  );
}

String _fmtD(double n) {
  return n
      .toStringAsFixed(2)
      .replaceAll(RegExp(r'0+$'), '')
      .replaceAll(RegExp(r'\.$'), '')
      .replaceAll('.', ',');
}

Future<bool> _launchWhatsAppPreferred({
  required String phoneDigits,
  required String encodedText,
}) async {
  Future<bool> tryLaunch(Uri uri) async {
    try {
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }

  if (Platform.isWindows || Platform.isMacOS || Platform.isLinux) {
    final desktopUri =
        Uri.parse('whatsapp://send?phone=$phoneDigits&text=$encodedText');
    if (await tryLaunch(desktopUri)) return true;

    final webUri = Uri.parse(
        'https://web.whatsapp.com/send?phone=$phoneDigits&text=$encodedText');
    return tryLaunch(webUri);
  }

  final mobileUri = Uri.parse('https://wa.me/$phoneDigits?text=$encodedText');
  return tryLaunch(mobileUri);
}

// ENUM METODE PEMESANAN

enum MetodePemesanan { bayarLangsung, piutang, buatPesanan, gabungkanPesanan }

enum MetodeBayar { tunai, nonTunai, campuran }

// SCREEN

class CheckoutScreen extends ConsumerStatefulWidget {
  const CheckoutScreen({super.key});

  @override
  ConsumerState<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends ConsumerState<CheckoutScreen> {
  MetodePemesanan _metode = MetodePemesanan.bayarLangsung;
  bool _biayaTambahanAktif = false;
  bool _diskonAktif = false;
  bool _isDiskonPersen = false;

  final TextEditingController _diskonCtrl = TextEditingController(text: '');

  // Member discount
  Customer? _memberCustomer;

  // List biaya tambahan: {label, nilai, isPercentage}
  final List<Map<String, dynamic>> _biayaList = [];

  MetodeBayar _metodeBayar = MetodeBayar.tunai;
  final _namaCtrl = TextEditingController();
  final _waCtrl = TextEditingController();
  final _catatanCtrl = TextEditingController(); // Added for servis notes
  final _jumlahCtrl = TextEditingController();
  final _campuranTunaiCtrl = TextEditingController();
  final _alamatCtrl = TextEditingController();
  int _kembalian = 0;
  bool _openingWhatsapp = false;
  bool _customerSaved = false;
  String? _waValidatedPhone;

  void _showBukaShiftDialog() {
    final activeStaff = ref.read(activeStaffProvider);
    final profile = ref.read(profilProvider);
    final staffId =
        activeStaff != null && activeStaff.id != null && activeStaff.id! > 0
            ? activeStaff.id
            : null;
    final staffName = activeStaff?.name ??
        (profile.nama.trim().isNotEmpty ? profile.nama.trim() : 'Owner');
    final staffRole = activeStaff?.role ?? 'Administrator';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => BukaKasirSheet(
        initialKasirName: staffName,
        onSubmit: (kasirName, openingCash, shiftName) async {
          await ref.read(kasirSessionsProvider.notifier).openSession(
                kasirName: kasirName,
                openingCash: openingCash,
                shiftName: shiftName,
                staffId: staffId,
                staffName: staffName,
                staffRole: staffRole,
              );
          if (!mounted) return;
          Navigator.pop(context);
          ref.invalidate(activeKasirSessionProvider);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Shift berhasil dimulai.'),
              backgroundColor: Colors.black87,
              behavior: SnackBarBehavior.floating,
            ),
          );
        },
      ),
    );
  }

  String _subMetodeNonTunai = 'qris';
  Map<String, dynamic>? _paymentSettings;
  bool _loadingSettings = true;
  bool _isConfirming = false;
  DateTime _transactionDate = DateTime.now();

  // Buat Pesanan states (Integrated for Wide Layout)
  String _jenisPesanan = 'Ambil Sendiri';
  bool _jadwalAmbilAktif = false;
  DateTime? _tanggal;
  TimeOfDay? _waktu;

  // Gabungkan Pesanan states (Integrated for Wide Layout)
  Transaction? _selectedMergeTx;
  String _mergeSearchQuery = '';
  final _mergeSearchCtrl = TextEditingController();

  // Servis specific states
  final String _servisStatus = 'Diterima';

  @override
  void initState() {
    super.initState();
    _loadPaymentSettings();
    Future.microtask(() {
      final customer = ref.read(selectedCustomerProvider);
      if (customer != null && mounted) {
        setState(() {
          _memberCustomer = customer;
          _namaCtrl.text = customer.name;
          _waCtrl.text = customer.phone ?? '';
          _customerSaved = true;
          _waValidatedPhone =
              _phoneKey(customer.whatsappValidatedPhone ?? '') ==
                      _phoneKey(customer.phone ?? '')
                  ? customer.phone
                  : null;
        });
      }
    });
  }

  @override
  void dispose() {
    _diskonCtrl.dispose();
    _namaCtrl.dispose();
    _waCtrl.dispose();
    _catatanCtrl.dispose();
    _jumlahCtrl.dispose();
    _campuranTunaiCtrl.dispose();
    _alamatCtrl.dispose();
    _mergeSearchCtrl.dispose();
    for (final b in _biayaList) {
      final ctrl = b['ctrl'];
      if (ctrl is TextEditingController) ctrl.dispose();
      final cCtrl = b['catatanCtrl'];
      if (cCtrl is TextEditingController) cCtrl.dispose();
    }
    super.dispose();
  }

  String? _normalizeWa(String raw) {
    final digits = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) return null;
    if (digits.startsWith('0')) return '+62${digits.substring(1)}';
    if (digits.startsWith('62')) return '+$digits';
    return '+62$digits';
  }

  bool _isValidWaFormat(String? value) {
    if (value == null) return false;
    final digits = value.replaceAll(RegExp(r'[^0-9]'), '');
    return digits.startsWith('62') && digits.length >= 11;
  }

  String _phoneKey(String value) => value.replaceAll(RegExp(r'[^0-9]'), '');

  bool get _isCurrentWaValidated {
    final normalized = _normalizeWa(_waCtrl.text.trim());
    if (normalized == null || _waValidatedPhone == null) return false;
    return _phoneKey(normalized) == _phoneKey(_waValidatedPhone!);
  }

  void _resetCheckoutCustomerValidation() {
    _customerSaved = false;
    _waValidatedPhone = null;
  }

  void _applyCheckoutCustomer(Customer customer) {
    _memberCustomer = customer;
    _namaCtrl.text = customer.name;
    _waCtrl.text = customer.phone ?? '';
    _alamatCtrl.text = customer.address ?? _alamatCtrl.text;
    _customerSaved = true;
    _waValidatedPhone = _phoneKey(customer.whatsappValidatedPhone ?? '') ==
            _phoneKey(customer.phone ?? '')
        ? customer.phone
        : null;
  }

  String _buildWaCheckMessage({
    required String storeName,
    required String customerName,
  }) {
    final greeting =
        customerName.isEmpty ? 'Halo kak,' : 'Halo kak $customerName,';
    return [
      greeting,
      '',
      'Kami dari $storeName ingin memastikan nomor WhatsApp ini aktif untuk komunikasi pesanan servis.',
      '',
      'Nomor ini akan dipakai untuk info status perbaikan, estimasi selesai, dan nota transaksi.',
      '',
      'Jika pesan ini diterima, kakak tidak perlu membalas.',
      '',
      'Terima kasih,',
      storeName,
    ].join('\n');
  }

  Future<void> _cekWhatsapp() async {
    if (_openingWhatsapp) return;
    final normalized = _normalizeWa(_waCtrl.text.trim());
    if (!_isValidWaFormat(normalized)) {
      ModernSnackBar.error(
        context: context,
        message: 'Nomor WhatsApp belum valid.',
      );
      return;
    }

    setState(() => _openingWhatsapp = true);
    try {
      final warung = await DBHelper.instance.getWarungProfile();
      if (!mounted) return;
      final storeName = (warung['nama'] ?? '').trim().isNotEmpty
          ? warung['nama']!.trim()
          : 'Juragan Servis';
      final text = Uri.encodeComponent(
        _buildWaCheckMessage(
          storeName: storeName,
          customerName: _namaCtrl.text.trim(),
        ),
      );
      final opened = await _launchWhatsAppPreferred(
        phoneDigits: _phoneKey(normalized!),
        encodedText: text,
      );
      if (!mounted) return;
      if (!opened) {
        ModernSnackBar.error(
          context: context,
          message: 'WhatsApp Desktop/Web tidak bisa dibuka di perangkat ini.',
        );
        return;
      }
      await _showWaCheckResultSheet();
    } catch (_) {
      if (!mounted) return;
      ModernSnackBar.error(
        context: context,
        message: 'Gagal membuka WhatsApp.',
      );
    } finally {
      if (mounted) setState(() => _openingWhatsapp = false);
    }
  }

  Future<void> _showWaCheckResultSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      builder: (ctx) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Cek WhatsApp',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Di desktop aplikasi akan mencoba membuka WhatsApp Desktop dulu. Jika terbuka ke nomor pelanggan, tandai valid.',
                  style: TextStyle(
                    fontSize: 13,
                    height: 1.35,
                    color: Color(0xFF64748B),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: _kBrand,
                          side: const BorderSide(color: _kBrand),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          padding: const EdgeInsets.symmetric(vertical: 13),
                        ),
                        child: const Text('Nanti',
                            style: TextStyle(fontWeight: FontWeight.w800)),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () async {
                          Navigator.pop(ctx);
                          await _markWhatsappValid();
                        },
                        icon: const Icon(Icons.verified_rounded, size: 17),
                        label: const Text('Tandai Valid'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF059669),
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          textStyle:
                              const TextStyle(fontWeight: FontWeight.w800),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _markWhatsappValid() async {
    final normalized = _normalizeWa(_waCtrl.text.trim());
    if (!_isValidWaFormat(normalized)) {
      ModernSnackBar.error(
        context: context,
        message: 'Nomor WhatsApp belum valid.',
      );
      return;
    }

    final saved = await _autoSaveCustomerIfValid();
    if (!mounted) return;
    if (saved == null || saved.id == null) {
      ModernSnackBar.error(
        context: context,
        message: 'Isi nama pelanggan sebelum tandai valid.',
      );
      return;
    }

    final now = DateTime.now().toIso8601String();
    await DBHelper.instance.markCustomerWhatsappValidated(
      customerId: saved.id!,
      phone: normalized!,
      validatedAt: now,
    );
    final updated = Customer(
      id: saved.id,
      name: saved.name,
      phone: normalized,
      address: saved.address,
      discountPct: saved.discountPct,
      memberCode: saved.memberCode,
      whatsappValidatedAt: now,
      whatsappValidatedPhone: normalized,
      createdAt: saved.createdAt,
    );
    if (!mounted) return;
    setState(() => _applyCheckoutCustomer(updated));
    ref.read(selectedCustomerProvider.notifier).updateState(updated);
    await ref.read(customersProvider.notifier).loadCustomers();
    if (!mounted) return;
    ModernSnackBar.success(
      context: context,
      message: 'Nomor WhatsApp ditandai valid.',
    );
  }

  bool _validateCustomerRequired() {
    final nama = _namaCtrl.text.trim();
    final normalized = _normalizeWa(_waCtrl.text.trim());
    if (nama.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Nama pelanggan wajib diisi.'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
      ));
      return false;
    }
    if (normalized == null || normalized.length < 11) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Nomor WhatsApp wajib diisi dan harus valid.'),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
      ));
      return false;
    }
    return true;
  }

  Future<Customer?> _autoSaveCustomerIfValid() async {
    final nama = _namaCtrl.text.trim();
    final normalized = _normalizeWa(_waCtrl.text.trim());
    if (nama.isEmpty || normalized == null || normalized.length < 11) {
      return null;
    }

    final saved = await DBHelper.instance.upsertCustomerByPhone(
      name: nama,
      phone: normalized,
      address: _alamatCtrl.text.trim().isEmpty ? null : _alamatCtrl.text.trim(),
    );
    if (!mounted) return saved;
    setState(() => _applyCheckoutCustomer(saved));
    ref.read(selectedCustomerProvider.notifier).updateState(saved);
    await ref.read(customersProvider.notifier).loadCustomers();
    return saved;
  }

  Future<void> _loadPaymentSettings() async {
    final s = await DBHelper.instance.getPaymentSettings();
    if (mounted) {
      setState(() {
        _paymentSettings = s;
        _loadingSettings = false;
      });
    }
  }

  String _formatTransactionDate(DateTime value) {
    return '${value.day.toString().padLeft(2, '0')}/'
        '${value.month.toString().padLeft(2, '0')}/'
        '${value.year} '
        '${value.hour.toString().padLeft(2, '0')}:'
        '${value.minute.toString().padLeft(2, '0')}';
  }

  Future<void> _pickTransactionDate() async {
    final now = DateTime.now();
    final initial = _transactionDate.isAfter(now) ? now : _transactionDate;
    final date = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(now.year - 5),
      lastDate: now,
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(initial),
    );
    if (time == null || !mounted) return;
    var selected = DateTime(
      date.year,
      date.month,
      date.day,
      time.hour,
      time.minute,
    );
    if (selected.isAfter(now)) selected = now;
    setState(() => _transactionDate = selected);
  }

  Widget _buildTransactionDateSelector() {
    return InkWell(
      onTap: _pickTransactionDate,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFFF8FAFC),
          border: Border.all(color: const Color(0xFFE2E8F0)),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          children: [
            Container(
              width: 28,
              height: 28,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: _kBrand.withValues(alpha: 0.10),
                borderRadius: BorderRadius.zero,
              ),
              child: const Icon(Icons.event_note_outlined,
                  color: _kBrand, size: 16),
            ),
            const SizedBox(width: 8),
            const Expanded(
              child: Text(
                'Tanggal Pencatatan',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                  color: Colors.black87,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                _formatTransactionDate(_transactionDate),
                style: const TextStyle(
                  color: _kBrand,
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                ),
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.right,
              ),
            ),
            const SizedBox(width: 2),
            const Icon(Icons.keyboard_arrow_down_rounded,
                color: Colors.black45, size: 18),
          ],
        ),
      ),
    );
  }

  void _hitungKembalian(int total) {
    final bayar = parseCurrencyInput(_jumlahCtrl.text);
    setState(() {
      _kembalian = bayar - total;
    });
  }

  bool _isPaymentValid(int grandTotal) {
    if (_metode != MetodePemesanan.bayarLangsung) {
      return true;
    }
    if (_metodeBayar == MetodeBayar.tunai) {
      final bayar = parseCurrencyInput(_jumlahCtrl.text);
      return bayar >= grandTotal;
    }
    if (_metodeBayar == MetodeBayar.campuran) {
      final tunai = parseCurrencyInput(_campuranTunaiCtrl.text);
      return tunai > 0 && tunai <= grandTotal;
    }
    return true;
  }

  String get _btnLabel {
    switch (_metode) {
      case MetodePemesanan.bayarLangsung:
        return 'Bayar Langsung';
      case MetodePemesanan.piutang:
        return 'Piutang';
      case MetodePemesanan.buatPesanan:
        return 'Bayar Nanti';
      case MetodePemesanan.gabungkanPesanan:
        return 'Tambah ke Pesanan Aktif';
    }
  }

  bool get _usesPaymentAction => _metode == MetodePemesanan.bayarLangsung;

  String get _primaryActionLabel =>
      _usesPaymentAction ? 'Proses Pembayaran' : _btnLabel;

  IconData get _primaryActionIcon =>
      _usesPaymentAction ? Icons.check_circle_rounded : Icons.payment_rounded;

  int _resolveDurationHours(Product product, List<Category> categories) {
    if (product.durationHours > 0) return product.durationHours;
    final category = categories.where((c) => c.id == product.categoryId);
    if (category.isNotEmpty) return category.first.durationHours;
    return 0;
  }

  _CheckoutEstimateInfo _buildEstimateInfo(
    Map<Product, double> cart,
    List<Category> categories,
  ) {
    Product? longestProduct;
    int longestDuration = 0;

    for (final entry in cart.entries) {
      final duration = _resolveDurationHours(entry.key, categories);
      if (duration > longestDuration) {
        longestDuration = duration;
        longestProduct = entry.key;
      }
    }

    if (longestDuration <= 0 || longestProduct == null) {
      return const _CheckoutEstimateInfo(
        durationHours: 0,
        sourceLabel: 'Pilih tanggal atau jam jika perlu jadwal khusus',
        finishLabel: 'Estimasi selesai bisa diatur manual',
        isConfigured: false,
      );
    }

    final finishAt = DateTime.now().add(Duration(hours: longestDuration));
    return _CheckoutEstimateInfo(
      durationHours: longestDuration,
      sourceLabel: '${longestProduct.name} - $longestDuration jam',
      finishLabel: DateFormat('EEE, dd MMM yyyy HH:mm', 'id').format(finishAt),
      isConfigured: true,
    );
  }

  String? _resolveAutomaticPickupSchedule(
    Map<Product, double> cart,
    List<Category> categories,
  ) {
    int maxDuration = 0;
    for (final entry in cart.entries) {
      final duration = _resolveDurationHours(entry.key, categories);
      if (duration > maxDuration) maxDuration = duration;
    }
    if (maxDuration <= 0) return null;
    return DateTime.now().add(Duration(hours: maxDuration)).toIso8601String();
  }

  void _onBottomBtn(int currentGrandTotal, int diskonAmount, int biayaTambahan,
      List<Map<String, dynamic>> detailBiayaList) {
    final mq = MediaQuery.of(context);
    final isWide =
        mq.size.shortestSide >= 600 || mq.orientation == Orientation.landscape;

    if (isWide && _metode == MetodePemesanan.bayarLangsung) {
      _prosesCheckout(context, currentGrandTotal, diskonAmount, biayaTambahan,
          detailBiayaList);
      return;
    }

    if (isWide && _metode == MetodePemesanan.buatPesanan) {
      _prosesBuatPesananIntegrasi(
          currentGrandTotal, diskonAmount, biayaTambahan, detailBiayaList);
      return;
    }

    final note =
        _catatanCtrl.text.trim().isNotEmpty ? _catatanCtrl.text.trim() : null;

    if (_metode == MetodePemesanan.piutang) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => TambahPiutangScreen(
            grandTotal: currentGrandTotal,
            diskonAmount: diskonAmount,
            biayaTambahan: biayaTambahan,
            additionalChargesList: detailBiayaList,
            transactionDate: _transactionDate,
            note: note,
          ),
        ),
      );
      return;
    }
    if (_metode == MetodePemesanan.buatPesanan) {
      _showBuatPesananSheet(
          currentGrandTotal, diskonAmount, biayaTambahan, detailBiayaList);
      return;
    }
    if (_metode == MetodePemesanan.gabungkanPesanan) {
      if (isWide) {
        if (_selectedMergeTx != null) {
          _prosesMergeIntegrasi(_selectedMergeTx!);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text(
                    'Silakan pilih pesanan aktif di kolom Informasi Metode')),
          );
        }
      } else {
        _showGabungkanPesananSheet();
      }
      return;
    }

    // Fallback for mobile bayarLangsung
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PembayaranScreen(
          totalPembayaran: currentGrandTotal,
          diskonAmount: diskonAmount,
          additionalCharges: biayaTambahan,
          additionalChargesList: detailBiayaList,
          metode: _metode,
          transactionDate: _transactionDate,
          note: note,
        ),
      ),
    );
  }

  Future<void> _prosesCheckout(
      BuildContext context,
      int currentGrandTotal,
      int diskonAmount,
      int additionalCharges,
      List<Map<String, dynamic>>? additionalChargesList) async {
    if (_isConfirming || !_isPaymentValid(currentGrandTotal)) {
      return;
    }

    final cart = ref.read(cartProvider);
    if (cart.isEmpty) return;

    // Wajib isi nama pelanggan + nomor WA (samakan flow desktop dengan Android)
    if (!_validateCustomerRequired()) return;

    final bayar = parseCurrencyInput(_jumlahCtrl.text);
    final amountPaid =
        _metodeBayar == MetodeBayar.tunai ? bayar : currentGrandTotal;

    String methodStr = 'cash';
    if (_metodeBayar == MetodeBayar.nonTunai) {
      methodStr = _subMetodeNonTunai;
    } else if (_metodeBayar == MetodeBayar.campuran) {
      final tunai = parseCurrencyInput(_campuranTunaiCtrl.text);
      methodStr =
          'Campuran (Tunai: ${_fK(tunai)} & ${_subMetodeNonTunai.toUpperCase()})';
    }

    setState(() => _isConfirming = true);

    final confirmed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(height: 110, child: _IlustrasiKonfirmasi()),
            const SizedBox(height: 16),
            Text(
              'Total Rp${_fK(currentGrandTotal)}',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
            ),
            const SizedBox(height: 8),
            Text(
              'Apakah Anda yakin ingin memproses pembayaran ini '
              'untuk ${(_memberCustomer?.name ?? (_namaCtrl.text.trim().isEmpty ? "Pelanggan Umum" : _namaCtrl.text.trim()))}?',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black54, fontSize: 14),
            ),
            const SizedBox(height: 28),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: _kBrand),
                      foregroundColor: _kBrand,
                      minimumSize: const Size.fromHeight(50),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    child: const Text('Batal',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Consumer(builder: (context, ref, child) {
                    ref.listen(shortcutSignalProvider, (prev, next) {
                      if (next == ShortcutAction.checkout) {
                        ref.read(shortcutSignalProvider.notifier).clear();
                        Navigator.pop(ctx, true);
                      }
                    });
                    return ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        elevation: 0,
                        minimumSize: const Size.fromHeight(50),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: const Text('Ya, Bayar',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 15)),
                    );
                  }),
                ),
              ],
            ),
          ],
        ),
      ),
    );

    if (mounted) {
      setState(() => _isConfirming = false);
    }
    if (confirmed != true) {
      return;
    }
    if (!mounted || !context.mounted) {
      return;
    }

    try {
      final navigator = Navigator.of(context);

      // Auto-save pelanggan (upsert by phone) sebelum transaksi dibuat
      final savedCustomer = await _autoSaveCustomerIfValid();

      // Auto-calculate pickup if still null
      String? pickupSchedule;
      if (_tanggal != null && _waktu != null) {
        pickupSchedule = DateTime(
          _tanggal!.year,
          _tanggal!.month,
          _tanggal!.day,
          _waktu!.hour,
          _waktu!.minute,
        ).toIso8601String();
      } else {
        pickupSchedule =
            _resolveAutomaticPickupSchedule(cart, ref.read(categoriesProvider));
      }

      final txId = await ref
          .read(transactionsProvider.notifier)
          .createTransaction(
            cartItems: cart,
            customer: savedCustomer ?? _memberCustomer,
            customerName:
                _namaCtrl.text.trim().isNotEmpty ? _namaCtrl.text.trim() : null,
            discountAmount: diskonAmount,
            additionalCharges: additionalCharges,
            additionalChargesList: additionalChargesList,
            paymentMethod: methodStr,
            amountPaid: amountPaid,
            paymentStatus:
                _metode == MetodePemesanan.piutang ? "Belum Lunas" : "Lunas",
            servisStatus: _servisStatus,
            kelengkapan: null,
            pickupSchedule: pickupSchedule,
            note: _catatanCtrl.text.trim().isNotEmpty
                ? _catatanCtrl.text.trim()
                : null,
            transactionDate: _transactionDate,
          );
      ref.read(cartProvider.notifier).clearCart();
      if (!mounted || !context.mounted) {
        return;
      }
      navigator.pushReplacement(
        MaterialPageRoute(
          builder: (_) =>
              StrukScreen(transactionId: txId, isAfterPayment: true),
        ),
      );
    } catch (e) {
      if (!mounted || !context.mounted) {
        return;
      }
      final errorStr = e.toString().replaceAll('Exception: ', '');
      final isStockError = errorStr.toLowerCase().contains('stok') ||
          errorStr.toLowerCase().contains('tidak cukup');

      showKasirErrorDialog(
        context,
        title: isStockError ? 'Stok Tidak Cukup' : 'Gagal Memproses',
        message: errorStr,
      );
    }
  }

  void _showGabungkanPesananSheet() {
    final cart = ref.read(cartProvider);
    final allTx = ref.read(transactionsProvider);
    final openOrders = allTx
        .where((t) =>
            (t.paymentMethod == 'Pesanan' ||
                t.paymentMethod == 'buat_pesanan') &&
            t.amountPaid < t.grandTotal)
        .toList();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      useSafeArea: true,
      builder: (_) => _GabungkanPesananSheet(
        cartItems: cart,
        openOrders: openOrders,
        onBatal: () => Navigator.of(context).pop(),
        onOk: (selectedTx) async {
          try {
            final totalBelanja = ref.read(cartProvider.notifier).totalBelanja;
            final biayaTambahan = _hitungBiayaTambahan(totalBelanja);
            final grandTotal = totalBelanja + biayaTambahan;

            await ref.read(transactionsProvider.notifier).mergeTransaction(
                  existingTxId: selectedTx.id!,
                  cartItems: cart,
                  additionalTotalAmount: totalBelanja,
                  additionalGrandTotal: grandTotal,
                );
            ref.read(cartProvider.notifier).clearCart();
            if (mounted) {
              Navigator.of(context).pop();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (_) => PesananBerhasilScreen(
                    transactionId: selectedTx.id!,
                    customerName: selectedTx.customerName ?? 'Pelanggan Umum',
                    jenisPesanan: 'Tambah ke Pesanan Aktif',
                    antrian: 0,
                  ),
                ),
              );
            }
          } catch (e) {
            if (mounted) {
              ModernSnackBar.error(
                context: context,
                message: 'Terjadi kesalahan. Silakan coba lagi.',
              );
            }
          }
        },
      ),
    );
  }

  void _showBuatPesananSheet(
      int grandTotal,
      int diskonAmount,
      int additionalCharges,
      List<Map<String, dynamic>>? additionalChargesList) {
    final cart = ref.read(cartProvider);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BuatPesananScreen(
          cartItems: cart,
          grandTotal: grandTotal,
          diskonAmount: diskonAmount,
          additionalCharges: additionalCharges,
          additionalChargesList: additionalChargesList,
          initialservisStation: ref.read(selectedservisOrderStationProvider),
          transactionDate: _transactionDate,
          note: _catatanCtrl.text.trim().isNotEmpty
              ? _catatanCtrl.text.trim()
              : null,
          onSuccess: (txId, customerName, jenisPesanan, antrian) {
            Navigator.of(context).popUntil((route) => route.isFirst);
            ref.read(riwayatTabProvider.notifier).set(1); // Belum Lunas
            ref.read(shellIndexProvider.notifier).set(4); // Riwayat
          },
        ),
      ),
    );
  }

  int _hitungBiayaTambahan(int subtotal) {
    if (!_biayaTambahanAktif) {
      return 0;
    }
    int total = 0;
    for (final b in _biayaList) {
      final ctrl = b['ctrl'] as TextEditingController;
      if (b['isPercentage'] == true) {
        final nilai = int.tryParse(ctrl.text) ?? 0;
        total += (subtotal * nilai / 100).round();
      } else {
        final nilai = parseCurrencyInput(ctrl.text);
        total += nilai;
      }
    }
    return total;
  }

  List<Map<String, dynamic>> _getBiayaDetailList(int subtotal) {
    if (!_biayaTambahanAktif) return [];
    return _biayaList.map((b) {
      final ctrl = b['ctrl'] as TextEditingController;
      int calcValue = 0;
      if (b['isPercentage'] == true) {
        final nilai = int.tryParse(ctrl.text) ?? 0;
        calcValue = (subtotal * nilai / 100).round();
      } else {
        final nilai = parseCurrencyInput(ctrl.text);
        calcValue = nilai;
      }
      final percentageValue =
          b['isPercentage'] == true ? (int.tryParse(ctrl.text) ?? 0) : 0;
      return {
        'label': b['isPercentage'] == true
            ? '${b['label']} ($percentageValue%)'
            : b['label'] as String,
        'value': calcValue,
        if (b['catatanCtrl'] != null)
          'catatan': (b['catatanCtrl'] as TextEditingController).text.trim(),
      };
    }).toList();
  }

  void _setDiscountMode(bool percentage) {
    final current = parseCurrencyInput(_diskonCtrl.text);
    _isDiskonPersen = percentage;
    _diskonCtrl.text = current == 0 ? '' : current.toString();
    if (!percentage && current > 0) {
      _diskonCtrl.text = formatCurrencyInput(current);
    }
  }

  void _applyCurrencyInput(
    TextEditingController controller,
    String value,
    bool isCurrency,
  ) {
    controller.text = value;
    if (isCurrency && value.isNotEmpty) {
      controller.text = formatCurrencyInput(parseCurrencyInput(value));
      controller.selection =
          TextSelection.collapsed(offset: controller.text.length);
    }
  }

  void _showPilihBiayaSheet() {
    final sudahAda = _biayaList.map((b) => b['label'] as String).toSet();

    final opsi = [
      {
        'label': 'Pajak',
        'icon': Icons.receipt_long_rounded,
        'desc': 'Persentase pajak dari total belanja',
        'isPercentage': true,
      },
      {
        'label': 'Ongkir',
        'icon': Icons.local_shipping_rounded,
        'desc': 'Biaya pengiriman (Rupiah)',
        'isPercentage': false,
      },
      {
        'label': 'Biaya Lain',
        'icon': Icons.add_circle_outline_rounded,
        'desc': 'Biaya tambahan lainnya (Rupiah)',
        'isPercentage': false,
      },
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.zero),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Pilih Jenis Biaya Tambahan',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 4),
            const Text(
              'Pilih biaya yang ingin diterapkan ke transaksi ini.',
              style: TextStyle(color: Colors.black54, fontSize: 13),
            ),
            const SizedBox(height: 16),
            ...opsi.map((o) {
              final label = o['label'] as String;
              // Pajak & Ongkir hanya boleh 1x; Biaya Lain boleh berkali-kali
              final disabled = (label == 'Pajak' || label == 'Ongkir') &&
                  sudahAda.contains(label);
              return GestureDetector(
                onTap: disabled
                    ? null
                    : () {
                        Navigator.pop(context);
                        final ctrl = TextEditingController(text: '');
                        final catatanCtrl = label == 'Biaya Lain'
                            ? TextEditingController(text: '')
                            : null;
                        setState(() => _biayaList.add({
                              'label': label,
                              'nilai': '',
                              'isPercentage': o['isPercentage'],
                              'ctrl': ctrl,
                              if (catatanCtrl != null)
                                'catatanCtrl': catatanCtrl,
                            }));
                      },
                child: Opacity(
                  opacity: disabled ? 0.4 : 1.0,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _kBrand.withValues(alpha: 0.08),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: Icon(o['icon'] as IconData,
                              color: _kBrand, size: 22),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(label,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14)),
                              Text(o['desc'] as String,
                                  style: const TextStyle(
                                      color: Colors.black54, fontSize: 12)),
                            ],
                          ),
                        ),
                        if (disabled)
                          const Text('Sudah ditambahkan',
                              style: TextStyle(
                                  fontSize: 11, color: Colors.black38))
                        else
                          const Icon(Icons.chevron_right_rounded,
                              color: Colors.black38),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  void _showCustomerPicker() async {
    final customers = await DBHelper.instance.getAllCustomers();
    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(ctx).size.height * 0.7,
        ),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        child: _CustomerSearchPicker(
          customers: customers,
          onSelected: (c) {
            setState(() {
              _applyCheckoutCustomer(c);
            });
            Navigator.pop(ctx);
          },
        ),
      ),
    );
  }

  void _showMemberPickerSheet() async {
    final customers = await DBHelper.instance.getAllCustomers();
    final membersWithDiscount =
        customers.where((c) => c.discountPct > 0).toList();

    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(ctx).size.height * 0.6,
        ),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.zero,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Pilih Member (Diskon)',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              'Hanya pelanggan dengan diskon > 0%',
              style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
            ),
            const SizedBox(height: 14),
            if (membersWithDiscount.isEmpty)
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Icon(Icons.person_off_outlined,
                        size: 42, color: Colors.grey.shade300),
                    const SizedBox(height: 8),
                    const Text(
                      'Belum ada pelanggan dengan diskon member',
                      style: TextStyle(color: Colors.black45, fontSize: 13),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              )
            else
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: membersWithDiscount.length,
                  itemBuilder: (_, i) {
                    final c = membersWithDiscount[i];
                    final isSelected = _memberCustomer?.id == c.id;
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor:
                            isSelected ? _kBrand : AppColors.brandLight,
                        child: Icon(
                          Icons.person_rounded,
                          color: isSelected ? Colors.white : _kBrand,
                          size: 20,
                        ),
                      ),
                      title: Text(c.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 14)),
                      subtitle: Text(
                        'Diskon: ${c.discountPct.toStringAsFixed(0)}%',
                        style: const TextStyle(
                            fontSize: 12, color: Colors.black45),
                      ),
                      trailing: isSelected
                          ? const Icon(Icons.check_circle_rounded,
                              color: _kBrand)
                          : null,
                      onTap: () {
                        setState(() {
                          _applyCheckoutCustomer(c);
                        });
                        Navigator.pop(ctx);
                      },
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    );
                  },
                ),
              ),
            const SizedBox(height: 8),
            if (_memberCustomer != null)
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () {
                    setState(() => _memberCustomer = null);
                    Navigator.pop(ctx);
                  },
                  child: const Text('Hapus Member',
                      style: TextStyle(color: Colors.red)),
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _showPilihPelangganSheetCheckout(BuildContext context) async {
    final customers = await DBHelper.instance.getAllCustomers();
    if (!mounted || !context.mounted) {
      return;
    }
    final searchCtrl = TextEditingController();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          final q = searchCtrl.text.toLowerCase();
          final filtered = q.isEmpty
              ? customers
              : customers
                  .where((c) => c.name.toLowerCase().contains(q))
                  .toList();
          return Container(
            height: MediaQuery.of(context).size.height * 0.6,
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.zero),
            ),
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 12, bottom: 4),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.zero),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Pilih Pelanggan',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                  child: TextField(
                    controller: searchCtrl,
                    onChanged: (_) => setSheet(() {}),
                    autofocus: true,
                    decoration: InputDecoration(
                      hintText: 'Cari nama pelanggan...',
                      prefixIcon: const Icon(Icons.search_rounded,
                          size: 20, color: Colors.black38),
                      filled: true,
                      fillColor: const Color(0xFFF5F7FA),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.zero,
                          borderSide: BorderSide(color: Colors.grey.shade200)),
                      focusedBorder: const OutlineInputBorder(
                          borderRadius: BorderRadius.zero,
                          borderSide: BorderSide(color: _kBrand, width: 1.5)),
                    ),
                  ),
                ),
                const Divider(height: 1),
                Expanded(
                  child: filtered.isEmpty
                      ? const Center(
                          child: Text('Tidak ada pelanggan ditemukan',
                              style: TextStyle(color: Colors.black45)))
                      : ListView.separated(
                          itemCount: filtered.length,
                          separatorBuilder: (_, __) =>
                              const Divider(height: 1, indent: 16),
                          itemBuilder: (_, i) {
                            final c = filtered[i];
                            return ListTile(
                              leading: CircleAvatar(
                                backgroundColor: _kBrand.withValues(alpha: 0.1),
                                child: Text(
                                  c.name.isNotEmpty
                                      ? c.name[0].toUpperCase()
                                      : '?',
                                  style: const TextStyle(
                                      color: _kBrand,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              title: Text(c.name,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w600)),
                              subtitle: (c.phone != null && c.phone!.isNotEmpty)
                                  ? Text(c.phone!,
                                      style: const TextStyle(
                                          fontSize: 12, color: Colors.black45))
                                  : null,
                              onTap: () {
                                setState(() {
                                  _applyCheckoutCustomer(c);
                                });
                                Navigator.pop(ctx);
                              },
                            );
                          },
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cart = ref.watch(cartProvider);
    final itemNotes = ref.watch(cartItemNotesProvider);
    ref.watch(discountsProvider); // Ensure reactivity to promos
    ref.watch(hardwarePricingSettingsProvider);
    ref.watch(cartPriceOverridesProvider);
    final totalBelanja = ref.read(cartProvider.notifier).totalBelanja;
    final biayaTambahan = _hitungBiayaTambahan(totalBelanja);
    final diskonInput = _isDiskonPersen
        ? (int.tryParse(_diskonCtrl.text) ?? 0)
        : parseCurrencyInput(_diskonCtrl.text);
    final diskonAmount = _diskonAktif
        ? (_isDiskonPersen
            ? (totalBelanja * diskonInput / 100).round()
            : diskonInput)
        : 0;
    final memberDiskonPct = _memberCustomer?.discountPct ?? 0;
    final memberDiskonAmount = memberDiskonPct > 0
        ? ((totalBelanja - diskonAmount) * memberDiskonPct / 100).round()
        : 0;

    int currentGrandTotal =
        totalBelanja - diskonAmount - memberDiskonAmount + biayaTambahan;
    if (currentGrandTotal < 0) currentGrandTotal = 0;

    // Listen for shortcuts
    ref.listen(shortcutSignalProvider, (previous, next) {
      if (next == null) return;

      // Guard: Only respond if this screen is the active route
      if (!(ModalRoute.of(context)?.isCurrent ?? false)) return;

      // Consume the signal immediately
      ref.read(shortcutSignalProvider.notifier).clear();

      switch (next) {
        case ShortcutAction.checkout:
          _onBottomBtn(currentGrandTotal, diskonAmount, biayaTambahan,
              _getBiayaDetailList(totalBelanja));
          break;
        case ShortcutAction.nextCategory:
          const types = MetodePemesanan.values;
          int nextIdx = (_metode.index + 1) % types.length;
          setState(() => _metode = types[nextIdx]);
          break;
        case ShortcutAction.prevCategory:
          const types = MetodePemesanan.values;
          int prevIdx = (_metode.index - 1 + types.length) % types.length;
          setState(() => _metode = types[prevIdx]);
          break;
        case ShortcutAction.quickPayPas:
        case ShortcutAction.holdTransaction:
        case ShortcutAction.clearCart:
        case ShortcutAction.focusSearch:
        case ShortcutAction.selectCustomer:
          _showMemberPickerSheet();
          break;
        case ShortcutAction.printLast:
        case ShortcutAction.goToCashier:
          break;
      }
    });

    final tampilkanOpsi = _metode == MetodePemesanan.bayarLangsung ||
        _metode == MetodePemesanan.piutang ||
        _metode == MetodePemesanan.buatPesanan;

    final shiftSettings = ref.watch(shiftSettingsProvider);
    final showShift = shiftSettings.enableShift;
    final activeSessionAsync = ref.watch(activeKasirSessionProvider);

    final bool isSessionLoading = showShift &&
        (activeSessionAsync.isLoading || activeSessionAsync.isRefreshing);

    final bool mustBlockShift = showShift &&
        (activeSessionAsync.when(
          data: (s) => s == null,
          loading: () => false,
          error: (_, __) => true,
        ));

    if (isSessionLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator(color: _kBrand)),
      );
    }

    if (mustBlockShift) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Checkout'),
          backgroundColor: Colors.white,
          foregroundColor: Colors.black87,
          elevation: 0,
        ),
        body: _buildShiftBlockedOverlay(context, ref),
      );
    }

    final mq = MediaQuery.of(context);
    final isTablet = mq.size.shortestSide >= 600;
    final isLandscape = mq.orientation == Orientation.landscape;

    if (isTablet || isLandscape) {
      return _buildWideLayout(
        context,
        cart,
        itemNotes,
        totalBelanja,
        biayaTambahan,
        diskonAmount,
        memberDiskonAmount,
        currentGrandTotal,
        tampilkanOpsi,
      );
    }
    return _buildPortraitLayout(
      context,
      cart,
      itemNotes,
      totalBelanja,
      biayaTambahan,
      diskonAmount,
      memberDiskonAmount,
      currentGrandTotal,
      tampilkanOpsi,
    );
  }

  Widget _buildShiftBlockedOverlay(BuildContext context, WidgetRef ref) {
    return Container(
      width: double.infinity,
      color: Colors.white,
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.warning.withValues(alpha: 0.05),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.lock_person_rounded,
              size: 80,
              color: AppColors.warning.withValues(alpha: 0.6),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Sesi Kasir Belum Dibuka',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: Color(0xFF1E293B),
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Buka shift terlebih dahulu untuk dapat mengakses pembayaran servis.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.black45,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 32),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _showBukaShiftDialog,
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                elevation: 0,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
              child: const Text(
                'Mulai Shift Sekarang',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // PORTRAIT LAYOUT (original)

  Widget _buildPortraitLayout(
    BuildContext context,
    Map<Product, double> cart,
    Map<int, String> itemNotes,
    int totalBelanja,
    int biayaTambahan,
    int diskonAmount,
    int memberDiskonAmount,
    int grandTotal,
    bool tampilkanOpsi,
  ) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: _buildAppBar(context),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: _buildCheckoutBody(
                context,
                cart,
                itemNotes,
                totalBelanja,
                biayaTambahan,
                diskonAmount,
                memberDiskonAmount,
                grandTotal,
                tampilkanOpsi,
                excludeSummary: true,
              ),
            ),
          ),
          // Sticky Bottom Panel (Summary + Action)
          Container(
            padding: const EdgeInsets.fromLTRB(4, 10, 4, 8),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 10,
                  offset: const Offset(0, -5),
                ),
              ],
              border: const Border(
                top: BorderSide(color: Color(0xFFEEEEEE)),
              ),
            ),
            child: SafeArea(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildOptionsAndSummary(
                    context,
                    totalBelanja,
                    biayaTambahan,
                    diskonAmount,
                    memberDiskonAmount,
                    grandTotal,
                    tampilkanOpsi,
                    onlySummary: true,
                    hideTotalBox: true, // Hide green box
                  ),
                  const SizedBox(height: 8),
                  _buildBottomBar(
                      grandTotal, diskonAmount, biayaTambahan, totalBelanja,
                      compact: true),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // WIDE LAYOUT (tablet + landscape) two-panel
  // Left: Item list  |  Right: Options + Summary + Pay

  Widget _buildWideLayout(
    BuildContext context,
    Map<Product, double> cart,
    Map<int, String> itemNotes,
    int totalBelanja,
    int biayaTambahan,
    int diskonAmount,
    int memberDiskonAmount,
    int grandTotal,
    bool tampilkanOpsi,
  ) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F9),
      body: SafeArea(
        bottom: false,
        child: Row(
          children: [
            // Sidebar removed for focus

            Expanded(
              child: Column(
                children: [
                  // Top bar
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              color: Color(0xFFF1F5F9),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: const Icon(Icons.arrow_back_ios_new_rounded,
                                color: Colors.black54, size: 18),
                          ),
                        ),
                        const SizedBox(width: 14),
                        const Text('Checkout',
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87)),
                        const SizedBox(width: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: _kBrand.withValues(alpha: 0.10),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: Text('${cart.length} item',
                              style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: _kBrand)),
                        ),
                      ],
                    ),
                  ),
                  Container(height: 1, color: const Color(0xFFEEEEEE)),

                  // Two panels
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 2,
                          child: SingleChildScrollView(
                            padding: const EdgeInsets.all(20),
                            child: _buildRincianPesanan(cart, itemNotes),
                          ),
                        ),
                        Container(width: 1, color: const Color(0xFFEEEEEE)),
                        Expanded(
                          flex: 3,
                          child: Column(
                            children: [
                              Expanded(
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Part A: Adjustments & Summary
                                    Expanded(
                                      child: SingleChildScrollView(
                                        padding: const EdgeInsets.all(20),
                                        child: _buildOptionsAndSummary(
                                          context,
                                          totalBelanja,
                                          biayaTambahan,
                                          diskonAmount,
                                          memberDiskonAmount,
                                          grandTotal,
                                          tampilkanOpsi,
                                        ),
                                      ),
                                    ),

                                    // Part B: Integrated Payment details / Method Info
                                    Container(
                                        width: 1,
                                        color: const Color(0xFFEEEEEE)),
                                    Expanded(
                                      child: SingleChildScrollView(
                                        padding: const EdgeInsets.all(20),
                                        child: _metode ==
                                                MetodePemesanan.bayarLangsung
                                            ? _PaymentSection(
                                                isWide: true,
                                                grandTotal: grandTotal,
                                                metodeBayar: _metodeBayar,
                                                onMetodeChanged: (m) =>
                                                    setState(
                                                        () => _metodeBayar = m),
                                                jumlahCtrl: _jumlahCtrl,
                                                campuranTunaiCtrl:
                                                    _campuranTunaiCtrl,
                                                kembalian: _kembalian,
                                                onHitungKembalian: () =>
                                                    _hitungKembalian(
                                                        grandTotal),
                                                subMetodeNonTunai:
                                                    _subMetodeNonTunai,
                                                onSubMetodeChanged: (s) =>
                                                    setState(() =>
                                                        _subMetodeNonTunai = s),
                                                paymentSettings:
                                                    _paymentSettings,
                                                loadingSettings:
                                                    _loadingSettings,
                                                namaCtrl: _namaCtrl,
                                                waCtrl: _waCtrl,
                                                openingWhatsapp:
                                                    _openingWhatsapp,
                                                whatsappValidated:
                                                    _isCurrentWaValidated,
                                                onCustomerChanged: () => setState(
                                                    _resetCheckoutCustomerValidation),
                                                onCheckWhatsapp: _cekWhatsapp,
                                                onPilihPelanggan: () =>
                                                    _showPilihPelangganSheetCheckout(
                                                        context),
                                                onSaveCustomer: _customerSaved
                                                    ? null
                                                    : () async {
                                                        final res =
                                                            await _autoSaveCustomerIfValid();
                                                        if (res != null &&
                                                            context.mounted) {
                                                          ScaffoldMessenger.of(
                                                                  context)
                                                              .showSnackBar(
                                                            const SnackBar(
                                                              content: Text(
                                                                  'Pelanggan berhasil disimpan'),
                                                              backgroundColor:
                                                                  Colors.green,
                                                              behavior:
                                                                  SnackBarBehavior
                                                                      .floating,
                                                            ),
                                                          );
                                                        }
                                                      },
                                              )
                                            : _buildMetodeInfoSection(
                                                grandTotal),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              // Sticky pay button
                              Container(
                                color: Colors.white,
                                padding:
                                    const EdgeInsets.fromLTRB(8, 12, 8, 14),
                                child: SizedBox(
                                  width: double.infinity,
                                  height: 56,
                                  child: ElevatedButton(
                                    onPressed: () => _onBottomBtn(
                                        grandTotal,
                                        diskonAmount,
                                        biayaTambahan,
                                        _getBiayaDetailList(totalBelanja)),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: ((_metode ==
                                                  MetodePemesanan
                                                      .bayarLangsung) &&
                                              !_isPaymentValid(grandTotal))
                                          ? Colors.grey.shade400
                                          : _kBrand,
                                      elevation: 0,
                                      shape: const RoundedRectangleBorder(
                                          borderRadius: BorderRadius.zero),
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(_primaryActionIcon,
                                            color: Colors.white, size: 19),
                                        const SizedBox(width: 8),
                                        Text(_primaryActionLabel,
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w800,
                                              fontSize: 15,
                                            )),
                                        const Spacer(),
                                        Text('Rp${_fK(grandTotal)}',
                                            style: const TextStyle(
                                                color: Colors.white70,
                                                fontWeight: FontWeight.w600,
                                                fontSize: 14)),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionsAndSummary(
    BuildContext context,
    int totalBelanja,
    int biayaTambahan,
    int diskonAmount,
    int memberDiskonAmount,
    int grandTotal,
    bool tampilkanOpsi, {
    bool onlyOptions = false,
    bool onlySummary = false,
    bool hideTotalBox = false,
  }) {
    final showOptions = !onlySummary;
    final showSummary = !onlyOptions;
    final estimateInfo = _buildEstimateInfo(
        ref.watch(cartProvider), ref.watch(categoriesProvider));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (showOptions) ...[
          const Text('Metode Pemesanan',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 10),
          Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 96,
                      child: _MetodeCard(
                        title: 'Bayar Langsung',
                        desc: 'Bayar saat masuk (DP/Lunas)',
                        selected: _metode == MetodePemesanan.bayarLangsung,
                        onTap: () => setState(
                            () => _metode = MetodePemesanan.bayarLangsung),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: SizedBox(
                      height: 96,
                      child: _MetodeCard(
                        title: 'Bayar Nanti',
                        desc: 'Tagihan dibayar saat pelanggan mengambil.',
                        selected: _metode == MetodePemesanan.buatPesanan,
                        onTap: () => setState(
                            () => _metode = MetodePemesanan.buatPesanan),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              _ActiveOrderMethodCard(
                selected: _metode == MetodePemesanan.gabungkanPesanan,
                onTap: () =>
                    setState(() => _metode = MetodePemesanan.gabungkanPesanan),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.grey.shade200),
              borderRadius: BorderRadius.zero,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Estimasi Selesai',
                    style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF64748B))),
                const SizedBox(height: 5),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 36,
                        child: InkWell(
                          onTap: () async {
                            final now = DateTime.now();
                            final date = await showDatePicker(
                              context: context,
                              initialDate: _tanggal ?? now,
                              firstDate: now,
                              lastDate: now.add(const Duration(days: 30)),
                              builder: (ctx, child) => Theme(
                                data: Theme.of(ctx).copyWith(
                                  colorScheme: const ColorScheme.light(
                                    primary: _kBrand,
                                    onPrimary: Colors.white,
                                    onSurface: Colors.black87,
                                  ),
                                ),
                                child: child!,
                              ),
                            );
                            if (date != null) {
                              setState(() => _tanggal = date);
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 9),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey.shade300),
                              borderRadius: BorderRadius.zero,
                              color: _tanggal == null
                                  ? Colors.blue.shade50.withValues(alpha: 0.3)
                                  : Colors.white,
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.calendar_today_rounded,
                                    size: 14, color: Colors.black45),
                                const SizedBox(width: 7),
                                Expanded(
                                  child: Text(
                                    _tanggal == null
                                        ? 'Otomatis (Produk)'
                                        : '${_tanggal!.day}/${_tanggal!.month}/${_tanggal!.year}',
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      color: _tanggal == null
                                          ? Colors.blue.shade700
                                          : Colors.black87,
                                      fontWeight: _tanggal == null
                                          ? FontWeight.w600
                                          : FontWeight.bold,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: SizedBox(
                        height: 36,
                        child: InkWell(
                          onTap: () async {
                            final time = await showTimePicker(
                              context: context,
                              initialTime: _waktu ?? TimeOfDay.now(),
                            );
                            if (time != null) {
                              setState(() => _waktu = time);
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 9),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey.shade300),
                              borderRadius: BorderRadius.zero,
                              color: _waktu == null
                                  ? Colors.blue.shade50.withValues(alpha: 0.3)
                                  : Colors.white,
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.access_time_rounded,
                                    size: 14, color: Colors.black45),
                                const SizedBox(width: 7),
                                Expanded(
                                  child: Text(
                                    _waktu == null
                                        ? 'Otomatis'
                                        : _waktu!.format(context),
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      color: _waktu == null
                                          ? Colors.blue.shade700
                                          : Colors.black87,
                                      fontWeight: _waktu == null
                                          ? FontWeight.w600
                                          : FontWeight.bold,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Container(
                  width: double.infinity,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF8FAFC),
                    border: Border.all(
                      color: const Color(0xFFE2E8F0),
                    ),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(
                        estimateInfo.isConfigured
                            ? Icons.timer_outlined
                            : Icons.edit_calendar_outlined,
                        size: 15,
                        color: const Color(0xFF475569),
                      ),
                      const SizedBox(width: 7),
                      Expanded(
                        child: Text(
                          estimateInfo.isConfigured
                              ? '${estimateInfo.finishLabel} - ${estimateInfo.sourceLabel}'
                              : estimateInfo.finishLabel,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF0F172A),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                _buildDataUnitServisSection(compact: true),
                const SizedBox(height: 8),
                _buildCatatanTambahanSection(compact: true),
              ],
            ),
          ),
          if (tampilkanOpsi) ...[
            const SizedBox(height: 16),
            const Divider(height: 1, color: Color(0xFFEEEEEE)),
            Theme(
              data:
                  Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                tilePadding: EdgeInsets.zero,
                maintainState: true,
                title: const Text('Diskon & Biaya Tambahan',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                children: [
                  const SizedBox(height: 12),
                  _buildTransactionDateSelector(),
                  const SizedBox(height: 12),
                  const Divider(height: 1, color: Color(0xFFEEEEEE)),
                  const SizedBox(height: 8),

                  // Diskon Member
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Diskon Member',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14)),
                      TextButton.icon(
                        onPressed: _showMemberPickerSheet,
                        icon: Icon(
                          _memberCustomer != null
                              ? Icons.swap_horiz_rounded
                              : Icons.person_add_alt_1_rounded,
                          size: 16,
                        ),
                        label: Text(
                          _memberCustomer != null
                              ? '${_memberCustomer!.name} (${_memberCustomer!.discountPct.toStringAsFixed(0)}%)'
                              : 'Pilih Member',
                          style: const TextStyle(fontSize: 12),
                        ),
                        style: TextButton.styleFrom(
                          foregroundColor: _kBrand,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                        ),
                      ),
                    ],
                  ),

                  if (_memberCustomer != null &&
                      _memberCustomer!.discountPct > 0)
                    Container(
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF3E0),
                        borderRadius: BorderRadius.zero,
                        border: Border.all(color: const Color(0xFFFFE0A0)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.discount_outlined,
                              color: Color(0xFFE65100), size: 18),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Diskon ${_memberCustomer!.discountPct.toStringAsFixed(0)}%  |  hemat Rp${_fK(memberDiskonAmount)}',
                              style: const TextStyle(
                                  fontSize: 12, color: Color(0xFFE65100)),
                            ),
                          ),
                          GestureDetector(
                            onTap: () => setState(() => _memberCustomer = null),
                            child: const Icon(Icons.close_rounded,
                                size: 16, color: Colors.black38),
                          ),
                        ],
                      ),
                    ),

                  const Divider(height: 1, color: Color(0xFFEEEEEE)),
                  const SizedBox(height: 8),

                  // Diskon Transaksi
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Diskon Transaksi',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14)),
                      Row(
                        children: [
                          Text(_diskonAktif ? 'Ya' : 'Tidak',
                              style: const TextStyle(
                                  color: Colors.black54, fontSize: 13)),
                          Transform.scale(
                            scale: 0.85,
                            child: Switch(
                              value: _diskonAktif,
                              onChanged: (val) => setState(() {
                                _diskonAktif = val;
                                if (!val) _diskonCtrl.text = '';
                              }),
                              activeThumbColor: _kBrand,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),

                  if (_diskonAktif) ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          flex: 3,
                          child: Text(
                              _isDiskonPersen ? 'Diskon (%)' : 'Nominal Diskon',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600, fontSize: 13)),
                        ),
                        const SizedBox(width: 12),
                        // Rp / % Toggle
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.grey.shade100,
                            borderRadius: BorderRadius.zero,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              _buildToggleBtn('Rp', !_isDiskonPersen, () {
                                setState(() => _setDiscountMode(false));
                              }),
                              _buildToggleBtn('%', _isDiskonPersen, () {
                                setState(() => _setDiscountMode(true));
                              }),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 4,
                          child: TextField(
                            controller: _diskonCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: _isDiskonPersen
                                ? [FilteringTextInputFormatter.digitsOnly]
                                : const [CurrencyInputFormatter()],
                            decoration: InputDecoration(
                              hintText: '0',
                              prefixText: _isDiskonPersen ? null : 'Rp',
                              suffixText: _isDiskonPersen ? '%' : null,
                              border: const OutlineInputBorder(
                                  borderRadius: BorderRadius.zero),
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 12),
                            ),
                            onChanged: (v) => setState(() {}),
                            onSubmitted: (_) => _onBottomBtn(
                                grandTotal,
                                diskonAmount,
                                biayaTambahan,
                                _getBiayaDetailList(totalBelanja)),
                          ),
                        ),
                      ],
                    ),
                  ],

                  const Divider(height: 1, color: Color(0xFFEEEEEE)),
                  const SizedBox(height: 8),

                  // Biaya Tambahan
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Biaya Tambahan',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14)),
                      Row(
                        children: [
                          Text(_biayaTambahanAktif ? 'Ya' : 'Tidak',
                              style: const TextStyle(
                                  color: Colors.black54, fontSize: 13)),
                          Transform.scale(
                            scale: 0.85,
                            child: Switch(
                              value: _biayaTambahanAktif,
                              onChanged: (val) =>
                                  setState(() => _biayaTambahanAktif = val),
                              activeThumbColor: _kBrand,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),

                  if (_biayaTambahanAktif) ...[
                    const SizedBox(height: 8),
                    ...List.generate(_biayaList.length, (i) {
                      final b = _biayaList[i];
                      final isPercentage = b['isPercentage'] as bool;
                      final isBiayaLain = b['label'] == 'Biaya Lain';
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: BorderRadius.zero,
                          border: Border.all(color: Colors.grey.shade200),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(b['label'] as String,
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 13)),
                                      Text(
                                          isPercentage
                                              ? 'Persentase (%)'
                                              : 'Nominal (Rp)',
                                          style: TextStyle(
                                              color: Colors.grey.shade500,
                                              fontSize: 11)),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  flex: 3,
                                  child: SizedBox(
                                    height: 38,
                                    child: TextField(
                                      controller:
                                          b['ctrl'] as TextEditingController,
                                      keyboardType: TextInputType.number,
                                      textAlign: TextAlign.right,
                                      inputFormatters: isPercentage
                                          ? [
                                              FilteringTextInputFormatter
                                                  .digitsOnly
                                            ]
                                          : const [CurrencyInputFormatter()],
                                      style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold),
                                      decoration: InputDecoration(
                                        isDense: true,
                                        hintText: '0',
                                        suffixText: isPercentage ? '%' : null,
                                        prefixText: isPercentage ? null : 'Rp',
                                        filled: true,
                                        fillColor: Colors.white,
                                        border: OutlineInputBorder(
                                            borderRadius: BorderRadius.zero,
                                            borderSide: BorderSide(
                                                color: Colors.grey.shade300)),
                                        enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.zero,
                                            borderSide: BorderSide(
                                                color: Colors.grey.shade300)),
                                        focusedBorder: const OutlineInputBorder(
                                            borderRadius: BorderRadius.zero,
                                            borderSide:
                                                BorderSide(color: _kBrand)),
                                        contentPadding:
                                            const EdgeInsets.symmetric(
                                                horizontal: 10, vertical: 8),
                                      ),
                                      onChanged: (v) =>
                                          setState(() => _applyCurrencyInput(
                                                b['ctrl']
                                                    as TextEditingController,
                                                v,
                                                !isPercentage,
                                              )),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                GestureDetector(
                                  onTap: () => setState(() {
                                    _biayaList.removeAt(i);
                                  }),
                                  child: Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                        color: AppColors.danger
                                            .withValues(alpha: 0.08),
                                        borderRadius: BorderRadius.zero),
                                    child: const Icon(AppIcons.recycleBin,
                                        color: AppColors.danger, size: 17),
                                  ),
                                ),
                              ],
                            ),
                            if (isBiayaLain && b['catatanCtrl'] != null) ...[
                              const SizedBox(height: 8),
                              TextField(
                                controller:
                                    b['catatanCtrl'] as TextEditingController,
                                textCapitalization:
                                    TextCapitalization.sentences,
                                style: const TextStyle(fontSize: 13),
                                decoration: InputDecoration(
                                  isDense: true,
                                  hintText:
                                      'Catatan biaya (misal: Antar jemput)',
                                  filled: true,
                                  fillColor: Colors.white,
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.zero,
                                      borderSide: BorderSide(
                                          color: Colors.grey.shade300)),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.zero,
                                      borderSide: BorderSide(
                                          color: Colors.grey.shade300)),
                                  focusedBorder: const OutlineInputBorder(
                                      borderRadius: BorderRadius.zero,
                                      borderSide: BorderSide(color: _kBrand)),
                                  contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 8),
                                ),
                                onChanged: (_) => setState(() {}),
                              ),
                            ],
                          ],
                        ),
                      );
                    }),
                    OutlinedButton(
                      onPressed: _showPilihBiayaSheet,
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: _kBrand),
                        foregroundColor: _kBrand,
                        minimumSize: const Size(double.infinity, 46),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: const Text('+ Biaya Tambahan',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(height: 8),
                  ],
                ],
              ),
            ),
          ],
        ],
        if (showSummary) ...[
          if (!hideTotalBox) const SizedBox(height: 16),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          const SizedBox(height: 8),
          _SummaryRow(
            label: 'Total Pesanan',
            value: 'Rp${_fK(totalBelanja)}',
            highlight: true,
          ),
          if (_diskonAktif && diskonAmount > 0)
            _SummaryRow(
                label: _isDiskonPersen
                    ? 'Diskon Transaksi (${_diskonCtrl.text}%)'
                    : 'Diskon Transaksi',
                value: '-Rp${_fK(diskonAmount)}',
                color: _kBrand),
          if (_memberCustomer != null && memberDiskonAmount > 0)
            _SummaryRow(
              label:
                  'Diskon Member (${_memberCustomer!.discountPct.toStringAsFixed(0)}%)',
              value: '-Rp${_fK(memberDiskonAmount)}',
              color: const Color(0xFFE65100),
            ),
          ..._biayaList.map((b) {
            final ctrl = b['ctrl'] as TextEditingController;
            final nilai = b['isPercentage'] == true
                ? (int.tryParse(ctrl.text) ?? 0)
                : parseCurrencyInput(ctrl.text);
            if (nilai == 0) return const SizedBox.shrink();
            final calcValue = b['isPercentage'] == true
                ? (totalBelanja * nilai / 100).round()
                : nilai;

            final label = b['isPercentage'] == true
                ? '${b['label']} ($nilai%)'
                : b['label'] as String;

            return _SummaryRow(label: label, value: 'Rp${_fK(calcValue)}');
          }),
          if (!hideTotalBox) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFFF0FDF4),
                borderRadius: BorderRadius.zero,
                border: Border.all(color: const Color(0xFFBBF7D0)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Total',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text('Rp${_fK(grandTotal)}',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: Color(0xFF16A34A))),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],
        ],
      ],
    );
  }

  Widget _buildRincianPesanan(
      Map<Product, double> cart, Map<int, String> itemNotes) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Rincian Pesanan',
            style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                color: Colors.black87)),
        const SizedBox(height: 10),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFEEEEEE)),
          ),
          child: Column(
            children: [
              ...cart.entries.toList().asMap().entries.map((entry) {
                final idx = entry.key;
                final e = entry.value;
                final product = e.key;
                final qty = e.value;
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 10),
                      child: _CheckoutItemRow(
                        product: product,
                        qty: qty,
                        note: itemNotes[product.id],
                        onEditNote: () => _showEditNoteDialog(product),
                        onEditPrice: () => _showEditPriceSheet(product, qty),
                        ref: ref,
                      ),
                    ),
                    if (idx < cart.length - 1)
                      const Divider(
                          height: 1,
                          color: Color(0xFFF5F5F5),
                          indent: 10,
                          endIndent: 10),
                  ],
                );
              }),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDataUnitServisSection({bool compact = false}) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 16, vertical: compact ? 12 : 16),
      margin: EdgeInsets.only(bottom: compact ? 8 : 16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.blue.shade100),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.build_circle_outlined, color: _kBrand, size: 20),
              const SizedBox(width: 8),
              Text('Data Unit Servis',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: compact ? 13 : 15)),
            ],
          ),
          const SizedBox(height: 12),
          _buildTextField(
            controller: _merekCtrl,
            label: 'Merek & Tipe (Misal: Samsung A51)',
            icon: Icons.devices_rounded,
          ),
          const SizedBox(height: 10),
          _buildTextField(
            controller: _keluhanCtrl,
            label: 'Keluhan Kerusakan',
            icon: Icons.warning_amber_rounded,
            maxLines: 2,
          ),
          const SizedBox(height: 10),
          _buildTextField(
            controller: _sandiPolaCtrl,
            label: 'Sandi / Pola Layar',
            icon: Icons.password_rounded,
          ),
          const SizedBox(height: 10),
          _buildTextField(
            controller: _kelengkapanCtrl,
            label: 'Kelengkapan (Dus, Charger, dll)',
            icon: Icons.backpack_outlined,
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    int maxLines = 1,
  }) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, size: 18, color: Colors.black45),
        filled: true,
        fillColor: const Color(0xFFF8FAFC),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.zero,
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
      ),
    );
  }

  Widget _buildCatatanTambahanSection({bool compact = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.sticky_note_2_outlined,
                size: 15, color: Color(0xFF64748B)),
            const SizedBox(width: 6),
            Text(
              'Catatan Tambahan',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: compact ? 11.5 : 15,
                color: compact ? const Color(0xFF64748B) : Colors.black87,
              ),
            ),
          ],
        ),
        if (!compact) ...[
          const SizedBox(height: 6),
          const Text(
            'Opsional. Catatan ini tampil di struk dan pesan WhatsApp jika fitur catatan struk aktif.',
            style: TextStyle(
              fontSize: 12,
              height: 1.35,
              color: Color(0xFF64748B),
            ),
          ),
        ],
        SizedBox(height: compact ? 6 : 10),
        TextField(
          controller: _catatanCtrl,
          minLines: compact ? 1 : 3,
          maxLines: compact ? 2 : 4,
          textInputAction: TextInputAction.newline,
          decoration: InputDecoration(
            hintText: compact
                ? 'Catatan struk, opsional...'
                : 'Contoh: unit mati total, charger ikut dititipkan.',
            hintStyle: TextStyle(
              color: const Color(0xFF94A3B8),
              fontSize: compact ? 12 : null,
            ),
            filled: true,
            fillColor: Colors.white,
            prefixIcon: compact
                ? null
                : const Padding(
                    padding: EdgeInsets.only(bottom: 42),
                    child: Icon(Icons.sticky_note_2_outlined,
                        size: 20, color: Color(0xFF64748B)),
                  ),
            contentPadding: EdgeInsets.symmetric(
              horizontal: compact ? 10 : 14,
              vertical: compact ? 10 : 14,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: Colors.grey.shade300),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: Colors.grey.shade300),
            ),
            focusedBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.zero,
              borderSide: BorderSide(color: _kBrand, width: 1.4),
            ),
          ),
        ),
      ],
    );
  }

  // PORTRAIT HELPERS

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: AppColors.surface,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
        onPressed: () => Navigator.pop(context),
      ),
      title: Text(
        'Checkout',
        style: AppText.h2,
      ),
      shape: const Border(
        bottom: BorderSide(color: AppColors.divider, width: 0.5),
      ),
    );
  }

  Widget _buildCheckoutBody(
    BuildContext context,
    Map<Product, double> cart,
    Map<int, String> itemNotes,
    int totalBelanja,
    int biayaTambahan,
    int diskonAmount,
    int memberDiskonAmount,
    int grandTotal,
    bool tampilkanOpsi, {
    bool excludeSummary = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // 1. Payment Options & Fees
        _buildOptionsAndSummary(
          context,
          totalBelanja,
          biayaTambahan,
          diskonAmount,
          memberDiskonAmount,
          grandTotal,
          tampilkanOpsi,
          onlyOptions: true,
        ),

        const SizedBox(height: 24),

        // 2. Order Details (Rincian Pesanan) - MOVED HERE
        _buildRincianPesanan(cart, itemNotes),

        if (!excludeSummary) ...[
          const SizedBox(height: 24),
          // 3. Final Summary (Total)
          _buildOptionsAndSummary(
            context,
            totalBelanja,
            biayaTambahan,
            diskonAmount,
            memberDiskonAmount,
            grandTotal,
            tampilkanOpsi,
            onlySummary: true,
          ),
        ],
      ],
    );
  }

  Widget _buildBottomBar(
      int grandTotal, int diskonAmount, int biayaTambahan, int totalBelanja,
      {bool compact = false}) {
    return Container(
      color: Colors.white,
      padding:
          compact ? EdgeInsets.zero : const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: SafeArea(
        top: false,
        bottom: !compact,
        child: SizedBox(
          width: double.infinity,
          height: compact ? 56 : 56,
          child: ElevatedButton.icon(
            onPressed: () => _onBottomBtn(grandTotal, diskonAmount,
                biayaTambahan, _getBiayaDetailList(totalBelanja)),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kBrand,
              elevation: 0,
              shape:
                  const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            ),
            icon: Icon(_primaryActionIcon, color: Colors.white, size: 19),
            label: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(_primaryActionLabel,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 15)),
                Text('Rp${_fK(grandTotal)}',
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 15)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _showEditNoteDialog(Product product) async {
    final note = await showKasirNoteDialog(
      context,
      title: product.name,
      initialNote: ref.read(cartItemNotesProvider)[product.id] ?? '',
      hintText: 'Tulis catatan untuk ${product.name}...',
    );
    if (note != null) {
      ref.read(cartItemNotesProvider.notifier).setNote(product.id!, note);
    }
  }

  Future<void> _showEditPriceSheet(Product product, double qty) {
    return CartPriceOverrideSheet.show(
      context,
      product: product,
      qty: qty,
    );
  }

  Widget _buildToggleBtn(String label, bool active, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: active ? _kBrand : Colors.transparent,
          borderRadius: BorderRadius.zero,
        ),
        child: Text(
          label,
          style: TextStyle(
            color: active ? Colors.white : Colors.black54,
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
      ),
    );
  }

  Widget _buildMetodeInfoSection(int grandTotal) {
    String title = '';
    String desc = '';
    IconData icon = Icons.info_outline;

    switch (_metode) {
      case MetodePemesanan.piutang:
        title = 'Metode Piutang';
        desc =
            'Transaksi ini akan dicatat sebagai hutang pelanggan. Pastikan Anda telah memilih pelanggan di kolom sebelah kiri.';
        icon = Icons.assignment_ind_outlined;
        break;
      case MetodePemesanan.buatPesanan:
        title = 'Bayar Nanti';
        desc =
            'Simpan pesanan sebagai tagihan belum lunas. Pembayaran dilakukan saat pelanggan mengambil atau melunasi servis.';
        icon = Icons.receipt_long_outlined;
        break;
      case MetodePemesanan.gabungkanPesanan:
        title = 'Tambah ke Pesanan';
        desc =
            'Item belanja ini akan ditambahkan ke dalam pesanan aktif yang sudah ada sebelumnya.';
        icon = Icons.add_to_photos_outlined;
        break;
      default:
        break;
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionCardPorted(
          title: 'Informasi Metode',
          icon: icon,
          tablet: true,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 8),
              Text(desc,
                  style: const TextStyle(
                      color: Colors.black54, fontSize: 13, height: 1.4)),
              const SizedBox(height: 16),
              if (_metode == MetodePemesanan.buatPesanan) ...[
                const Divider(height: 32),
                // Nama Pelanggan (Reuse existing _namaCtrl)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Nama Pelanggan *',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 13)),
                    TextButton.icon(
                      onPressed: _showCustomerPicker,
                      icon: const Icon(Icons.person_search_rounded, size: 16),
                      label: const Text('Pilih Pelanggan',
                          style: TextStyle(fontSize: 12)),
                      style: TextButton.styleFrom(
                        foregroundColor: _kBrand,
                        padding: EdgeInsets.zero,
                        minimumSize: Size.zero,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _namaCtrl,
                  onChanged: (_) => setState(_resetCheckoutCustomerValidation),
                  decoration: InputDecoration(
                    hintText: 'Tulis nama pelanggan...',
                    isDense: true,
                    filled: true,
                    fillColor: Colors.grey.shade50,
                    border: const OutlineInputBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                ),
                const SizedBox(height: 14),

                const Text('Nomor WhatsApp *',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                const SizedBox(height: 8),
                TextField(
                  controller: _waCtrl,
                  keyboardType: TextInputType.phone,
                  onChanged: (_) => setState(_resetCheckoutCustomerValidation),
                  decoration: InputDecoration(
                    hintText: 'Contoh: 0812xxxxxxx',
                    suffixIcon: _isCurrentWaValidated
                        ? const Icon(Icons.verified_rounded,
                            color: Color(0xFF059669), size: 18)
                        : null,
                    isDense: true,
                    filled: true,
                    fillColor: Colors.grey.shade50,
                    border: const OutlineInputBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    if (_isCurrentWaValidated)
                      Expanded(
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 12,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFECFDF5),
                            border: Border.all(color: const Color(0xFFA7F3D0)),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.verified_rounded,
                                  color: Color(0xFF059669), size: 17),
                              SizedBox(width: 8),
                              Text(
                                'WA Valid',
                                style: TextStyle(
                                  color: Color(0xFF047857),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    else
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _openingWhatsapp ? null : _cekWhatsapp,
                          icon: const Icon(Icons.message_outlined, size: 16),
                          label: Text(
                            _openingWhatsapp ? 'Membuka...' : 'Cek WA',
                            overflow: TextOverflow.ellipsis,
                          ),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFF059669),
                            side: const BorderSide(color: Color(0xFF86EFAC)),
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                            textStyle: const TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _customerSaved
                            ? null
                            : () async {
                                if (!_validateCustomerRequired()) return;
                                await _autoSaveCustomerIfValid();
                                if (!mounted) return;
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(const SnackBar(
                                  content: Text('Pelanggan tersimpan.'),
                                  backgroundColor: Colors.green,
                                  behavior: SnackBarBehavior.floating,
                                ));
                              },
                        icon: const Icon(Icons.save_rounded, size: 16),
                        label: const Text(
                          'Simpan',
                          overflow: TextOverflow.ellipsis,
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _kBrand,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          textStyle: const TextStyle(
                              fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Pengambilan & Pengantaran',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 13)),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: _kBrand.withValues(alpha: 0.08),
                        border: Border.all(color: const Color(0xFFDBEAFE)),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Text(
                        'Wajib',
                        style: TextStyle(
                          color: _kBrand,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  'Pilih cara servis diserahkan atau diterima pelanggan.',
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  initialValue: _jenisPesanan,
                  decoration: const InputDecoration(
                      isDense: true,
                      border:
                          OutlineInputBorder(borderRadius: BorderRadius.zero)),
                  items: ['Ambil Sendiri', 'Antar Jemput']
                      .map((s) => DropdownMenuItem(
                          value: s,
                          child: Text(s, style: const TextStyle(fontSize: 13))))
                      .toList(),
                  onChanged: (v) => setState(() => _jenisPesanan = v!),
                ),
                if (_jenisPesanan == 'Antar Jemput') ...[
                  const SizedBox(height: 14),
                  const Text('Alamat Lengkap',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _alamatCtrl,
                    maxLines: 3,
                    decoration: InputDecoration(
                      hintText: 'Tulis alamat lengkap pelanggan...',
                      isDense: true,
                      filled: true,
                      fillColor: Colors.grey.shade50,
                      border: const OutlineInputBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                  ),
                ],

                const SizedBox(height: 16),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _jenisPesanan == 'Antar Jemput'
                          ? 'Jadwal Jemput / Antar'
                          : 'Estimasi Pengambilan',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                    Transform.scale(
                      scale: 0.8,
                      child: Switch(
                        value: _jadwalAmbilAktif,
                        onChanged: (v) => setState(() => _jadwalAmbilAktif = v),
                        activeThumbColor: _kBrand,
                      ),
                    ),
                  ],
                ),
                Text(
                  _jadwalAmbilAktif
                      ? 'Atur tanggal dan jam manual untuk komunikasi pelanggan.'
                      : 'Opsional. Jika kosong, sistem memakai estimasi layanan.',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    height: 1.35,
                  ),
                ),
                const SizedBox(height: 8),
                if (_jadwalAmbilAktif) ...[
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () async {
                            final d = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime.now(),
                                lastDate: DateTime.now()
                                    .add(const Duration(days: 365)));
                            if (d != null) setState(() => _tanggal = d);
                          },
                          style: OutlinedButton.styleFrom(
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero)),
                          child: Text(
                              _tanggal == null
                                  ? 'Pilih Tgl'
                                  : '${_tanggal!.day}/${_tanggal!.month}',
                              style: const TextStyle(fontSize: 12)),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () async {
                            final t = await showTimePicker(
                                context: context, initialTime: TimeOfDay.now());
                            if (t != null) setState(() => _waktu = t);
                          },
                          style: OutlinedButton.styleFrom(
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero)),
                          child: Text(
                              _waktu == null
                                  ? 'Pilih Jam'
                                  : _waktu!.format(context),
                              style: const TextStyle(fontSize: 12)),
                        ),
                      ),
                    ],
                  ),
                ],

                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF8FAFC),
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.payments_outlined,
                          size: 17, color: Color(0xFF64748B)),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Status pembayaran: Belum Lunas',
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF334155),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              if (_metode == MetodePemesanan.piutang &&
                  _memberCustomer == null) ...[
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.orange.withValues(alpha: 0.1),
                    border:
                        Border.all(color: Colors.orange.withValues(alpha: 0.3)),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.warning_amber_rounded,
                          color: Colors.orange, size: 20),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Pilih Member untuk melanjutkan transaksi piutang.',
                          style: TextStyle(
                              color: Colors.orange,
                              fontSize: 12,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              if (_metode == MetodePemesanan.gabungkanPesanan) ...[
                const Divider(height: 32),
                _buildIntegratedMergeSelection(),
              ],
              if (_metode != MetodePemesanan.buatPesanan &&
                  _metode != MetodePemesanan.gabungkanPesanan) ...[
                const SizedBox(height: 12),
                Center(
                  child: Opacity(
                    opacity: 0.5,
                    child: Icon(icon, size: 80, color: Colors.grey.shade200),
                  ),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _prosesBuatPesananIntegrasi(
      int grandTotal,
      int diskonAmount,
      int additionalCharges,
      List<Map<String, dynamic>>? additionalChargesList) async {
    if (!_validateCustomerRequired()) return;
    if (_jenisPesanan == 'Antar Jemput' && _alamatCtrl.text.trim().isEmpty) {
      ModernSnackBar.error(
        context: context,
        message: 'Alamat wajib diisi untuk antar jemput.',
      );
      return;
    }

    setState(() => _isConfirming = true);
    try {
      final cart = ref.read(cartProvider);

      final orderType = _jenisPesanan;
      String? pickupSchedule;
      if (_tanggal != null && _waktu != null) {
        pickupSchedule = DateTime(
          _tanggal!.year,
          _tanggal!.month,
          _tanggal!.day,
          _waktu!.hour,
          _waktu!.minute,
        ).toIso8601String();
      } else {
        pickupSchedule =
            _resolveAutomaticPickupSchedule(cart, ref.read(categoriesProvider));
      }

      // Auto-save pelanggan (upsert by phone) sebelum pesanan dibuat
      final customer = await _autoSaveCustomerIfValid();

      // (Logic moved up)
      final selectedservisStation =
          ref.read(selectedservisOrderStationProvider);
      final servisNote = selectedservisStation == null
          ? null
          : 'STATION:${selectedservisStation.name};AREA:${selectedservisStation.displayArea}';

      const methodStr = 'buat_pesanan';

      String finalNote = servisNote ?? '';
      final manualNote = _catatanCtrl.text.trim();
      if (manualNote.isNotEmpty) {
        finalNote = finalNote.isEmpty ? manualNote : '$finalNote\n$manualNote';
      }

      await ref.read(transactionsProvider.notifier).createTransaction(
            cartItems: cart,
            customer: customer ?? _memberCustomer,
            discountAmount: diskonAmount,
            additionalCharges: additionalCharges,
            additionalChargesList: additionalChargesList,
            paymentMethod: methodStr,
            amountPaid: 0,
            note: finalNote.isEmpty ? null : finalNote,
            orderType: orderType,
            pickupSchedule: pickupSchedule,
            paymentStatus: "Belum Lunas",
            servisStatus: _servisStatus,
            kelengkapan: null,
            address: _alamatCtrl.text.trim().isEmpty
                ? null
                : _alamatCtrl.text.trim(),
            servisStationId: selectedservisStation?.id,
            servisStationName: selectedservisStation?.name,
            sendToWorkshop: selectedservisStation != null,
            transactionDate: _transactionDate,
          );

      ref.read(cartProvider.notifier).clearCart();
      if (mounted) {
        final scope = ShellScope.of(context);
        HapticFeedback.heavyImpact();
        ref.read(riwayatTabProvider.notifier).set(1);
        ref.read(shellIndexProvider.notifier).set(4);
        if (scope != null) {
          Navigator.of(context).popUntil((r) => r.isFirst);
          scope.onNavigate(4);
        } else {
          ref.read(shellIndexProvider.notifier).set(4);
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (_) => const MainShell()),
            (route) => false,
          );
        }
      }
    } catch (e) {
      if (mounted) {
        showKasirErrorDialog(context, title: 'Gagal', message: e.toString());
      }
    } finally {
      if (mounted) setState(() => _isConfirming = false);
    }
  }

  Future<void> _prosesMergeIntegrasi(Transaction selectedTx) async {
    final cart = ref.read(cartProvider);
    if (cart.isEmpty) return;

    setState(() => _isConfirming = true);
    try {
      final totalBelanja = ref.read(cartProvider.notifier).totalBelanja;
      final biayaTambahan = _hitungBiayaTambahan(totalBelanja);
      final grandTotal = totalBelanja + biayaTambahan;

      await ref.read(transactionsProvider.notifier).mergeTransaction(
            existingTxId: selectedTx.id!,
            cartItems: cart,
            additionalTotalAmount: totalBelanja,
            additionalGrandTotal: grandTotal,
          );
      ref.read(cartProvider.notifier).clearCart();
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => PesananBerhasilScreen(
              transactionId: selectedTx.id!,
              customerName: selectedTx.customerName ?? 'Pelanggan Umum',
              jenisPesanan: 'Tambah ke Pesanan Aktif',
              antrian: 0,
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        showKasirErrorDialog(context, title: 'Gagal', message: e.toString());
      }
    } finally {
      if (mounted) setState(() => _isConfirming = false);
    }
  }

  String _formatTime(String iso) {
    try {
      final dt = DateTime.parse(iso);
      final diff = DateTime.now().difference(dt);
      if (diff.inMinutes < 60) return '${diff.inMinutes}m yang lalu';
      if (diff.inHours < 24) return '${diff.inHours}j yang lalu';
      return '${dt.day}/${dt.month} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return '';
    }
  }

  Widget _buildIntegratedMergeSelection() {
    final allTx = ref.watch(transactionsProvider);
    final openOrders = allTx
        .where((t) =>
            (t.paymentMethod == 'Pesanan' ||
                t.paymentMethod == 'buat_pesanan') &&
            t.amountPaid < t.grandTotal)
        .toList();

    final filtered = _mergeSearchQuery.isEmpty
        ? openOrders
        : openOrders.where((t) {
            final name = (t.customerName ?? '').toLowerCase();
            final id = t.id.toString();
            final query = _mergeSearchQuery.toLowerCase();
            return name.contains(query) || id.contains(query);
          }).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Pilih Pesanan Aktif *',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        const SizedBox(height: 8),
        TextField(
          controller: _mergeSearchCtrl,
          onChanged: (v) => setState(() => _mergeSearchQuery = v),
          decoration: InputDecoration(
            hintText: 'Cari nama atau no pesanan...',
            prefixIcon: const Icon(Icons.search, size: 20),
            isDense: true,
            filled: true,
            fillColor: Colors.grey.shade50,
            border: const OutlineInputBorder(borderRadius: BorderRadius.zero),
          ),
        ),
        const SizedBox(height: 12),
        if (openOrders.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 20),
            child: Center(
              child: Text('Tidak ada pesanan aktif',
                  style: TextStyle(color: Colors.black45, fontSize: 13)),
            ),
          )
        else
          Container(
            constraints: const BoxConstraints(maxHeight: 400),
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: filtered.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) {
                final tx = filtered[i];
                final isSelected = _selectedMergeTx?.id == tx.id;
                return InkWell(
                  onTap: () => setState(() => _selectedMergeTx = tx),
                  borderRadius: BorderRadius.zero,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? _kBrand.withValues(alpha: 0.05)
                          : Colors.white,
                      border: Border.all(
                        color: isSelected ? _kBrand : Colors.grey.shade300,
                        width: isSelected ? 1.5 : 1.0,
                      ),
                      borderRadius: BorderRadius.zero,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                tx.customerName?.isNotEmpty == true
                                    ? tx.customerName!
                                    : 'Pelanggan Umum',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                  color: isSelected ? _kBrand : Colors.black87,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '#${tx.id}  |  ${_formatTime(tx.createdAt)}',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: isSelected
                                      ? _kBrand.withValues(alpha: 0.7)
                                      : Colors.black45,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (isSelected)
                          const Icon(Icons.check_circle_rounded,
                              color: _kBrand, size: 20),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
      ],
    );
  }
} // end _CheckoutScreenState

// CHECKOUT ITEM ROW (wide layout left panel)

class _CheckoutItemRow extends StatelessWidget {
  final Product product;
  final double qty;
  final String? note;
  final VoidCallback onEditNote;
  final VoidCallback onEditPrice;
  final WidgetRef ref;

  const _CheckoutItemRow({
    required this.product,
    required this.qty,
    required this.onEditNote,
    required this.onEditPrice,
    required this.ref,
    this.note,
  });

  @override
  Widget build(BuildContext context) {
    final allDiscounts = ref.watch(discountsProvider);
    final hardwareSettings = ref.watch(hardwarePricingSettingsProvider);
    final priceOverrides = ref.watch(cartPriceOverridesProvider);
    final overrideUnitPrice =
        product.id == null ? null : priceOverrides[product.id!]?.unitPrice;
    final billableQty = CartNotifier.billableQty(product, qty, hardwareSettings);
    final pricing = CartNotifier.resolveUnitPricing(
      product,
      qty,
      allDiscounts,
      hardwareSettings: hardwareSettings,
      unitPriceOverride: overrideUnitPrice,
    );
    final promoPrice = CartNotifier.calculateDiscountedPrice(
      product,
      qty,
      allDiscounts,
      hardwareSettings: hardwareSettings,
    );
    final basePrice = product.getPrice(billableQty);
    final lineSubtotal = CartNotifier.calculateLineSubtotal(
      product,
      qty,
      allDiscounts,
      hardwareSettings,
      unitPriceOverride: overrideUnitPrice,
    );
    final hasPriceOverride = pricing.hasPriceOverride;
    final normalSubtotal = (pricing.originalUnitPrice * billableQty).round();
    final hasPromo = !hasPriceOverride && promoPrice < basePrice;
    final isGrosir = product.hasWholesale == 1 &&
        billableQty >= product.wholesaleMinQty &&
        product.wholesalePrice > 0;
    final isKg = hardwareSettings.appliesTo(product);
    final roundedInfo = isKg && billableQty != qty
        ? 'Berat ${_fmtD(qty)} kg, ditagih ${_fmtD(billableQty)} kg'
        : null;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Product info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  if (product.isExtra == 1)
                    Container(
                      margin: const EdgeInsets.only(right: 6),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 1.5),
                      decoration: BoxDecoration(
                        color: _kBrand.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.zero,
                        border:
                            Border.all(color: _kBrand.withValues(alpha: 0.2)),
                      ),
                      child: const Text('ADD ON',
                          style: TextStyle(
                              color: _kBrand,
                              fontSize: 8.5,
                              fontWeight: FontWeight.bold)),
                    ),
                  if (hasPromo)
                    Container(
                      margin: const EdgeInsets.only(right: 6),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 1.5),
                      decoration: const BoxDecoration(
                        color: _kBrand,
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Text('PROMO',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 8.5,
                              fontWeight: FontWeight.bold)),
                    ),
                  if (hasPriceOverride)
                    Container(
                      margin: const EdgeInsets.only(right: 6),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 1.5),
                      decoration: const BoxDecoration(
                        color: Color(0xFF0F766E),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Text('NEGO',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 8.5,
                              fontWeight: FontWeight.bold)),
                    ),
                  if (isGrosir &&
                      !hasPromo &&
                      !hasPriceOverride) // Promo/nego takes priority
                    Container(
                      margin: const EdgeInsets.only(right: 6),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 1.5),
                      decoration: const BoxDecoration(
                        color: Colors.orange,
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Text('GROSIR',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 8.5,
                              fontWeight: FontWeight.bold)),
                    ),
                  Expanded(
                    child: Text(product.name,
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 13.5)),
                  ),
                ],
              ),
              const SizedBox(height: 2),
              GestureDetector(
                onTap: onEditNote,
                child: Row(
                  children: [
                    Icon(Icons.edit_note_rounded,
                        color: _kBrand.withValues(alpha: 0.7), size: 15),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        note ?? 'Catatan...',
                        style: TextStyle(
                            color: note != null ? Colors.black87 : _kBrand,
                            fontSize: 11.5,
                            fontWeight: note != null
                                ? FontWeight.normal
                                : FontWeight.w500),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 5),
              InkWell(
                onTap: onEditPrice,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  decoration: BoxDecoration(
                    color: hasPriceOverride
                        ? const Color(0xFFE6FFFA)
                        : const Color(0xFFF8FAFC),
                    border: Border.all(
                      color: hasPriceOverride
                          ? const Color(0xFF0F766E)
                          : const Color(0xFFCBD5E1),
                    ),
                  ),
                  child: Text(
                    'Ubah harga',
                    style: TextStyle(
                      color: hasPriceOverride
                          ? const Color(0xFF0F766E)
                          : const Color(0xFF334155),
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
              if (roundedInfo != null) ...[
                const SizedBox(height: 4),
                Text(
                  roundedInfo,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF1D4ED8),
                    fontSize: 10.8,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(width: 8),
        // Qty adjustment + price
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _qtyBtn(Icons.remove, () {
                  if (qty <= 1) {
                    ref.read(cartProvider.notifier).removeItem(product);
                  } else {
                    ref.read(cartProvider.notifier).setQty(product, qty - 1);
                  }
                }),
                SizedBox(
                  width: 32,
                  child: Center(
                    child: Text(
                      _fmtD(qty),
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 13.5),
                    ),
                  ),
                ),
                _qtyBtn(Icons.add, () {
                  ref.read(cartProvider.notifier).addItem(product, qty: 1);
                }),
              ],
            ),
            const SizedBox(height: 4),
            if (hasPriceOverride) ...[
              Text(
                'Rp${_fK(pricing.originalUnitPrice)} / ${isKg ? 'kg' : 'item'}',
                style: const TextStyle(
                  color: Colors.black38,
                  fontSize: 10,
                  decoration: TextDecoration.lineThrough,
                ),
              ),
              if (normalSubtotal != lineSubtotal)
                Text(
                  'Total awal Rp${_fK(normalSubtotal)}',
                  style: const TextStyle(
                    color: Colors.black38,
                    fontSize: 10,
                    decoration: TextDecoration.lineThrough,
                  ),
                ),
              Text(
                'Rp${_fK(lineSubtotal)}',
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13.5,
                    color: Color(0xFF0F766E)),
              ),
            ] else if (hasPromo) ...[
              Text(
                'Rp${_fK(basePrice)}',
                style: const TextStyle(
                  color: Colors.black38,
                  fontSize: 10,
                  decoration: TextDecoration.lineThrough,
                ),
              ),
              Text(
                'Rp${_fK(lineSubtotal)}',
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13.5,
                    color: _kBrand),
              ),
            ] else ...[
              Text(
                'Rp${_fK(basePrice)} / ${isKg ? 'kg' : 'item'}',
                style: TextStyle(
                    color: isGrosir ? Colors.orange : Colors.black54,
                    fontSize: 10.5,
                    fontWeight: isGrosir ? FontWeight.bold : FontWeight.normal),
              ),
              Text(
                'Rp${_fK(lineSubtotal)}',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13.5,
                    color: isGrosir ? Colors.orange : Colors.black87),
              ),
            ],
          ],
        ),
      ],
    );
  }

  Widget _qtyBtn(IconData ic, VoidCallback onT) {
    return InkWell(
      onTap: onT,
      child: Container(
        width: 26,
        height: 26,
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.black12, width: 1),
          borderRadius: BorderRadius.zero,
        ),
        child: Icon(ic, size: 14, color: Colors.black54),
      ),
    );
  }
}

// SUMMARY ROW (inside _buildOptionsAndSummary)

class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? color;
  final bool highlight;

  const _SummaryRow({
    required this.label,
    required this.value,
    this.color,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: highlight ? 10 : 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: TextStyle(
                  fontSize: highlight ? 15 : 13,
                  color: color ?? (highlight ? Colors.black : Colors.black54),
                  fontWeight: highlight
                      ? FontWeight.bold
                      : (color != null ? FontWeight.w600 : FontWeight.normal))),
          Text(value,
              style: TextStyle(
                  fontSize: highlight ? 15 : 13,
                  fontWeight: highlight ? FontWeight.w900 : FontWeight.w600,
                  color: color ?? (highlight ? Colors.black : Colors.black87))),
        ],
      ),
    );
  }
}

// WIDGET: KARTU METODE PEMESANAN

class _MetodeCard extends StatelessWidget {
  final String title, desc;
  final bool selected;
  final VoidCallback onTap;

  const _MetodeCard({
    required this.title,
    required this.desc,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? _kBrand.withValues(alpha: 0.04) : Colors.white,
          border: Border.all(
            color: selected ? _kBrand : Colors.grey.shade300,
            width: selected ? 1.5 : 1.0,
          ),
          borderRadius: BorderRadius.zero,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 13,
                color: selected ? _kBrand : Colors.black87,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            Text(
              desc,
              style: TextStyle(
                fontSize: 11,
                color: selected ? _kBrand : Colors.black54,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

class _ActiveOrderMethodCard extends StatelessWidget {
  final bool selected;
  final VoidCallback onTap;

  const _ActiveOrderMethodCard({
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        width: double.infinity,
        constraints: const BoxConstraints(minHeight: 58),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? _kBrand.withValues(alpha: 0.04) : Colors.white,
          border: Border.all(
            color: selected ? _kBrand : Colors.grey.shade300,
            width: selected ? 1.5 : 1.0,
          ),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Flexible(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    'Tambah ke Pesanan Aktif',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: selected ? _kBrand : Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Gabungkan item ke transaksi berjalan',
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 11,
                      color: selected ? _kBrand : Colors.black54,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// SHEET: TAMBAH PELANGGAN

class _TambahPelangganSheet extends StatefulWidget {
  final String namaAwal;
  final Function(Customer) onSaved;

  const _TambahPelangganSheet({
    required this.namaAwal,
    required this.onSaved,
  });

  @override
  State<_TambahPelangganSheet> createState() => _TambahPelangganSheetState();
}

class _TambahPelangganSheetState extends State<_TambahPelangganSheet> {
  late TextEditingController _namaNewCtrl;
  late TextEditingController _teleponCtrl;

  String? _normalizeWa(String raw) {
    final digits = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) return null;
    if (digits.startsWith('0')) {
      return '+62${digits.substring(1)}';
    }
    if (digits.startsWith('62')) return '+$digits';
    return '+62$digits';
  }

  @override
  void initState() {
    super.initState();
    _namaNewCtrl = TextEditingController(text: widget.namaAwal);
    _teleponCtrl = TextEditingController();
  }

  @override
  void dispose() {
    _namaNewCtrl.dispose();
    _teleponCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Tambah Pelanggan',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
            const SizedBox(height: 16),
            TextField(
              controller: _namaNewCtrl,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Nama Pelanggan',
                border: OutlineInputBorder(borderRadius: BorderRadius.zero),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _teleponCtrl,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Nomor WhatsApp *',
                prefixText: '+62 ',
                border: OutlineInputBorder(borderRadius: BorderRadius.zero),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () async {
                final nama = _namaNewCtrl.text.trim();
                if (nama.isEmpty) return;
                final normalizedWa = _normalizeWa(_teleponCtrl.text.trim());
                if (normalizedWa == null || normalizedWa.length < 11) {
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Nomor WhatsApp wajib diisi dengan benar'),
                      behavior: SnackBarBehavior.floating,
                      backgroundColor: Colors.black87,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                  );
                  return;
                }
                final customer = Customer(
                  name: nama,
                  phone: normalizedWa,
                  createdAt: DateTime.now().toIso8601String(),
                );
                final newId = await DBHelper.instance.insertCustomer(customer);
                final saved = Customer(
                  id: newId,
                  name: nama,
                  phone: normalizedWa,
                  createdAt: DateTime.now().toIso8601String(),
                );
                if (!mounted || !context.mounted) return;
                widget.onSaved(saved);
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: _kBrand,
                minimumSize: const Size.fromHeight(50),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero),
              ),
              child: const Text('Simpan',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}

// WIDGET: SHEET BUAT PESANAN

class BuatPesananScreen extends ConsumerStatefulWidget {
  final Map<Product, double> cartItems;
  final int grandTotal;
  final int diskonAmount;
  final int additionalCharges;
  final List<Map<String, dynamic>>? additionalChargesList;
  final servisStation? initialservisStation;
  final DateTime transactionDate;
  final String? note;
  final void Function(
    int txId,
    String customerName,
    String jenisPesanan,
    int antrian,
  ) onSuccess;

  const BuatPesananScreen({
    super.key,
    required this.cartItems,
    required this.grandTotal,
    this.diskonAmount = 0,
    this.additionalCharges = 0,
    this.additionalChargesList,
    this.initialservisStation,
    required this.transactionDate,
    required this.onSuccess,
    this.note,
  });

  @override
  ConsumerState<BuatPesananScreen> createState() => _BuatPesananScreenState();
}

class _BuatPesananScreenState extends ConsumerState<BuatPesananScreen> {
  final _namaCtrl = TextEditingController();
  final _waCtrl = TextEditingController();
  Customer? _selectedCustomer;
  final _alamatCtrl = TextEditingController();
  String _jenisPesanan = 'Ambil Sendiri';
  bool _jadwalAmbilAktif = false;
  DateTime? _tanggal;
  TimeOfDay? _waktu;
  bool _loading = false;
  bool _customerSaved = false;
  bool _openingWhatsapp = false;
  String? _waValidatedPhone;

  @override
  void initState() {
    super.initState();
    final station = widget.initialservisStation;
    if (station != null) {
      _namaCtrl.text = 'Station ${station.name}';
      _jenisPesanan = 'Ambil Sendiri';
    }
  }

  @override
  void dispose() {
    _namaCtrl.dispose();
    _waCtrl.dispose();
    _alamatCtrl.dispose();
    super.dispose();
  }

  String? _normalizeWa(String raw) {
    final digits = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) return null;
    if (digits.startsWith('0')) {
      return '+62${digits.substring(1)}';
    }
    if (digits.startsWith('62')) return '+$digits';
    return '+62$digits';
  }

  bool _isValidWaFormat(String? value) {
    if (value == null) return false;
    final digits = value.replaceAll(RegExp(r'[^0-9]'), '');
    return digits.startsWith('62') && digits.length >= 11;
  }

  String _phoneKey(String value) => value.replaceAll(RegExp(r'[^0-9]'), '');

  String _buildWaCheckMessage({
    required String storeName,
    required String customerName,
  }) {
    final greeting =
        customerName.isEmpty ? 'Halo kak,' : 'Halo kak $customerName,';
    return [
      greeting,
      '',
      'Kami dari $storeName ingin memastikan nomor WhatsApp ini aktif untuk komunikasi pesanan servis.',
      '',
      'Nomor ini akan dipakai untuk info status perbaikan, estimasi selesai, dan nota transaksi.',
      '',
      'Jika pesan ini diterima, kakak tidak perlu membalas.',
      '',
      'Terima kasih,',
      storeName,
    ].join('\n');
  }

  Future<void> _cekWhatsapp() async {
    if (_openingWhatsapp) return;
    final normalized = _normalizeWa(_waCtrl.text.trim());
    if (!_isValidWaFormat(normalized)) {
      ModernSnackBar.error(
        context: context,
        message: 'Nomor WhatsApp belum valid.',
      );
      return;
    }

    setState(() => _openingWhatsapp = true);
    try {
      final warung = await DBHelper.instance.getWarungProfile();
      if (!mounted) return;
      final storeName = (warung['nama'] ?? '').trim().isNotEmpty
          ? warung['nama']!.trim()
          : 'Juragan Servis';
      final text = Uri.encodeComponent(
        _buildWaCheckMessage(
          storeName: storeName,
          customerName: _namaCtrl.text.trim(),
        ),
      );
      final opened = await _launchWhatsAppPreferred(
        phoneDigits: _phoneKey(normalized!),
        encodedText: text,
      );
      if (!mounted) return;
      if (!opened) {
        ModernSnackBar.error(
          context: context,
          message: 'WhatsApp Desktop/Web tidak bisa dibuka di perangkat ini.',
        );
        return;
      }
      await _showWaCheckResultSheet();
    } catch (_) {
      if (!mounted) return;
      ModernSnackBar.error(
        context: context,
        message: 'Gagal membuka WhatsApp.',
      );
    } finally {
      if (mounted) setState(() => _openingWhatsapp = false);
    }
  }

  Future<void> _showWaCheckResultSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      builder: (ctx) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Cek WhatsApp',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Jika WhatsApp terbuka ke nomor pelanggan, tandai valid agar tersimpan untuk transaksi berikutnya.',
                  style: TextStyle(
                    fontSize: 13,
                    height: 1.35,
                    color: Color(0xFF64748B),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: _kBrand,
                          side: const BorderSide(color: _kBrand),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          padding: const EdgeInsets.symmetric(vertical: 13),
                        ),
                        child: const Text('Nanti',
                            style: TextStyle(fontWeight: FontWeight.w800)),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () async {
                          Navigator.pop(ctx);
                          await _markWhatsappValid();
                        },
                        icon: const Icon(Icons.verified_rounded, size: 17),
                        label: const Text('Tandai Valid'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF059669),
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          textStyle:
                              const TextStyle(fontWeight: FontWeight.w800),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _markWhatsappValid() async {
    final normalized = _normalizeWa(_waCtrl.text.trim());
    if (!_isValidWaFormat(normalized)) {
      ModernSnackBar.error(
        context: context,
        message: 'Nomor WhatsApp belum valid.',
      );
      return;
    }

    final saved = await _saveCustomerSilently();
    if (!mounted) return;
    if (saved == null || saved.id == null) {
      ModernSnackBar.error(
        context: context,
        message: 'Isi nama pelanggan sebelum tandai valid.',
      );
      return;
    }

    final now = DateTime.now().toIso8601String();
    await DBHelper.instance.markCustomerWhatsappValidated(
      customerId: saved.id!,
      phone: normalized!,
      validatedAt: now,
    );
    final updated = Customer(
      id: saved.id,
      name: saved.name,
      phone: normalized,
      address: saved.address,
      discountPct: saved.discountPct,
      memberCode: saved.memberCode,
      whatsappValidatedAt: now,
      whatsappValidatedPhone: normalized,
      createdAt: saved.createdAt,
    );
    if (!mounted) return;
    setState(() {
      _selectedCustomer = updated;
      _waValidatedPhone = normalized;
      _customerSaved = true;
    });
    ref.read(selectedCustomerProvider.notifier).updateState(updated);
    await ref.read(customersProvider.notifier).loadCustomers();
    if (!mounted) return;
    ModernSnackBar.success(
      context: context,
      message: 'Nomor WhatsApp ditandai valid.',
    );
  }

  Future<Customer?> _saveCustomerSilently() async {
    final nama = _namaCtrl.text.trim();
    final normalizedWa = _normalizeWa(_waCtrl.text.trim());
    if (nama.isEmpty || normalizedWa == null || normalizedWa.length < 11) {
      return null;
    }
    final saved = await DBHelper.instance.upsertCustomerByPhone(
      name: nama,
      phone: normalizedWa,
      address: _alamatCtrl.text.trim().isEmpty ? null : _alamatCtrl.text.trim(),
    );
    if (!mounted) return saved;
    setState(() {
      _selectedCustomer = saved;
      _customerSaved = true;
      if (_phoneKey(saved.whatsappValidatedPhone ?? '') ==
          _phoneKey(normalizedWa)) {
        _waValidatedPhone = normalizedWa;
      }
    });
    ref.read(selectedCustomerProvider.notifier).updateState(saved);
    await ref.read(customersProvider.notifier).loadCustomers();
    return saved;
  }

  Future<void> _onCari() async {
    final nama = _namaCtrl.text.trim();
    if (nama.isEmpty) return;

    final customers = await DBHelper.instance.getAllCustomers();
    final found = customers
        .where((c) => c.name.toLowerCase().contains(nama.toLowerCase()))
        .toList();

    if (!mounted) return;

    if (found.length == 1) {
      setState(() {
        _selectedCustomer = found.first;
        _waCtrl.text = found.first.phone ?? '';
        _alamatCtrl.text = found.first.address ?? _alamatCtrl.text;
        _waValidatedPhone =
            _phoneKey(found.first.whatsappValidatedPhone ?? '') ==
                    _phoneKey(found.first.phone ?? '')
                ? found.first.phone
                : null;
      });
    } else if (found.isEmpty) {
      _showTambahPelangganSheet(namaAwal: nama);
    } else {
      _showPilihPelangganSheet(found);
    }
  }

  void _showPilihPelangganSheet(List<Customer> daftar) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        minChildSize: 0.4,
        expand: false,
        builder: (_, sc) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.zero),
          ),
          child: Column(
            children: [
              const SizedBox(height: 16),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text('Pilih Pelanggan',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              ),
              const SizedBox(height: 8),
              const Divider(height: 1),
              Expanded(
                child: daftar.isEmpty
                    ? const Center(
                        child: Text('Belum ada data pelanggan.',
                            style: TextStyle(color: Colors.black45)),
                      )
                    : ListView.builder(
                        controller: sc,
                        itemCount: daftar.length,
                        itemBuilder: (_, i) {
                          final c = daftar[i];
                          return ListTile(
                            leading: CircleAvatar(
                              backgroundColor: _kBrand.withValues(alpha: 0.12),
                              child: Text(
                                  c.name.isNotEmpty
                                      ? c.name[0].toUpperCase()
                                      : '?',
                                  style: const TextStyle(
                                      color: _kBrand,
                                      fontWeight: FontWeight.bold)),
                            ),
                            title: Text(c.name,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600)),
                            subtitle: c.phone != null
                                ? Text(c.phone!,
                                    style: const TextStyle(fontSize: 12))
                                : null,
                            trailing: TextButton(
                              onPressed: () {
                                setState(() {
                                  _selectedCustomer = c;
                                  _namaCtrl.text = c.name;
                                  _waCtrl.text = c.phone ?? '';
                                  _waValidatedPhone = _phoneKey(
                                              c.whatsappValidatedPhone ?? '') ==
                                          _phoneKey(c.phone ?? '')
                                      ? c.phone
                                      : null;
                                  if (c.address != null &&
                                      _alamatCtrl.text.isEmpty) {
                                    _alamatCtrl.text = c.address!;
                                  }
                                });
                                Navigator.pop(context);
                              },
                              style: TextButton.styleFrom(
                                foregroundColor: _kBrand,
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.zero),
                              ),
                              child: const Text('Pilih'),
                            ),
                            onTap: () {
                              setState(() {
                                _selectedCustomer = c;
                                _namaCtrl.text = c.name;
                                _waCtrl.text = c.phone ?? '';
                                _waValidatedPhone =
                                    _phoneKey(c.whatsappValidatedPhone ?? '') ==
                                            _phoneKey(c.phone ?? '')
                                        ? c.phone
                                        : null;
                                if (c.address != null &&
                                    _alamatCtrl.text.isEmpty) {
                                  _alamatCtrl.text = c.address!;
                                }
                              });
                              Navigator.pop(context);
                            },
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showTambahPelangganSheet({String namaAwal = ''}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _TambahPelangganSheet(
        namaAwal: namaAwal,
        onSaved: (customer) {
          setState(() {
            _selectedCustomer = customer;
            _namaCtrl.text = customer.name;
            _waCtrl.text = customer.phone ?? '';
            _waValidatedPhone =
                _phoneKey(customer.whatsappValidatedPhone ?? '') ==
                        _phoneKey(customer.phone ?? '')
                    ? customer.phone
                    : null;
            if (customer.address != null && _alamatCtrl.text.isEmpty) {
              _alamatCtrl.text = customer.address!;
            }
          });
        },
      ),
    );
  }

  Future<void> _simpanPelangganCepat() async {
    final nama = _namaCtrl.text.trim();
    final normalizedWa = _normalizeWa(_waCtrl.text.trim());
    if (nama.isEmpty || normalizedWa == null || normalizedWa.length < 11) {
      if (!context.mounted) return;
      FocusScope.of(context).unfocus();
      ModernSnackBar.error(
        context: context,
        message: 'Isi nama dan nomor WhatsApp yang valid dulu.',
      );
      return;
    }

    final saved = await _saveCustomerSilently();
    if (!mounted) return;
    FocusScope.of(context).unfocus();
    if (saved == null) {
      ModernSnackBar.error(
        context: context,
        message: 'Pelanggan belum bisa disimpan.',
      );
      return;
    }
    ModernSnackBar.success(
      context: context,
      message: 'Data pelanggan disimpan.',
    );
  }

  Future<void> _submit() async {
    final nama = _namaCtrl.text.trim();
    if (nama.isEmpty) {
      FocusScope.of(context).unfocus();
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          title: const Text('Gagal'),
          content: const Text('Nama pelanggan wajib diisi.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              style: TextButton.styleFrom(foregroundColor: _kBrand),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return;
    }
    final normalizedWa = _normalizeWa(_waCtrl.text.trim());
    if (normalizedWa == null || normalizedWa.length < 11) {
      FocusScope.of(context).unfocus();
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          title: const Text('Gagal'),
          content:
              const Text('Nomor WhatsApp wajib diisi sebelum simpan pesanan.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              style: TextButton.styleFrom(foregroundColor: _kBrand),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return;
    }
    if (_jenisPesanan == 'Antar Jemput' && _alamatCtrl.text.trim().isEmpty) {
      FocusScope.of(context).unfocus();
      ModernSnackBar.error(
        context: context,
        message: 'Alamat wajib diisi untuk antar jemput.',
      );
      return;
    }
    setState(() => _loading = true);
    try {
      Customer? finalCustomer = _selectedCustomer;

      if (finalCustomer != null && (finalCustomer.phone ?? '').trim().isEmpty) {
        final updated = Customer(
          id: finalCustomer.id,
          name: finalCustomer.name,
          phone: normalizedWa,
          address: finalCustomer.address,
          discountPct: finalCustomer.discountPct,
          memberCode: finalCustomer.memberCode,
          createdAt: finalCustomer.createdAt,
        );
        await DBHelper.instance.updateCustomer(updated);
        finalCustomer = updated;
      }

      // Jika belum dipilih via search, coba cari/buat berdasarkan nama diketik
      if (finalCustomer == null) {
        final all = await DBHelper.instance.getAllCustomers();
        try {
          finalCustomer =
              all.firstWhere((c) => c.name.toLowerCase() == nama.toLowerCase());
        } catch (_) {
          // Buat pelanggan baru otomatis
          final newId = await DBHelper.instance.insertCustomer(Customer(
            name: nama,
            phone: normalizedWa,
            createdAt: DateTime.now().toIso8601String(),
          ));
          finalCustomer = Customer(
            id: newId,
            name: nama,
            phone: normalizedWa,
            createdAt: DateTime.now().toIso8601String(),
          );
          // Refresh list pelanggan global
          ref.read(customersProvider.notifier).loadCustomers();
        }
      }

      final orderType = _jenisPesanan;
      String? address;
      String? pickupSchedule;
      const paymentStatus = "Belum Lunas";

      if (_jenisPesanan == 'Antar Jemput') {
        address = _alamatCtrl.text.trim();
      }
      if (_jadwalAmbilAktif && _tanggal != null && _waktu != null) {
        pickupSchedule = DateTime(
          _tanggal!.year,
          _tanggal!.month,
          _tanggal!.day,
          _waktu!.hour,
          _waktu!.minute,
        ).toIso8601String();
      }
      final selectedservisStation = widget.initialservisStation;
      final servisNote = selectedservisStation == null
          ? null
          : 'STATION:${selectedservisStation.name};AREA:${selectedservisStation.displayArea}';

      String? finalNote;
      if (servisNote != null && widget.note != null) {
        finalNote = '$servisNote\n${widget.note}';
      } else {
        finalNote = servisNote ?? widget.note;
      }

      final txId =
          await ref.read(transactionsProvider.notifier).createTransaction(
                cartItems: widget.cartItems,
                customer: finalCustomer,
                discountAmount: widget.diskonAmount,
                additionalCharges: widget.additionalCharges,
                additionalChargesList: widget.additionalChargesList,
                paymentMethod: 'buat_pesanan',
                amountPaid: 0,
                note: finalNote,
                orderType: orderType,
                pickupSchedule: pickupSchedule,
                paymentStatus: paymentStatus,
                address: address,
                servisStationId: selectedservisStation?.id,
                servisStationName: selectedservisStation?.name,
                sendToWorkshop: selectedservisStation != null,
                transactionDate: widget.transactionDate,
              );
      ref.read(cartProvider.notifier).clearCart();
      if (mounted) {
        widget.onSuccess(
          txId,
          _namaCtrl.text.trim(),
          _jenisPesanan,
          1,
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
        final errorStr = e.toString().replaceAll('Exception: ', '');
        final isStockError = errorStr.toLowerCase().contains('stok') ||
            errorStr.toLowerCase().contains('tidak cukup');

        showKasirErrorDialog(
          context,
          title: isStockError ? 'Stok Tidak Cukup' : 'Gagal Memproses',
          message: errorStr,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Bayar Nanti',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFEFF6FF),
                border: Border.all(color: const Color(0xFFBFDBFE)),
                borderRadius: BorderRadius.zero,
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.receipt_long_rounded, size: 18, color: _kBrand),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Pesanan disimpan sebagai tagihan belum lunas. Pembayaran dilakukan saat servis diambil atau saat pelanggan melunasi.',
                      style: TextStyle(
                        fontSize: 12,
                        height: 1.35,
                        color: Color(0xFF1D4ED8),
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            RichText(
              text: const TextSpan(
                style: TextStyle(
                  color: Colors.black87,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
                children: [
                  TextSpan(text: 'Nama Pelanggan '),
                  TextSpan(
                      text: '*', style: TextStyle(color: AppColors.danger)),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _namaCtrl,
                    decoration: InputDecoration(
                      hintText: 'Cari atau tulis nama...',
                      prefixIcon: const Icon(Icons.person_outline, size: 20),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.search, color: _kBrand),
                        onPressed: _onCari,
                      ),
                      isDense: true,
                      filled: true,
                      fillColor: Colors.grey.shade50,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.zero,
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton(
                  onPressed: () async {
                    final all = await DBHelper.instance.getAllCustomers();
                    if (!mounted) return;
                    _showPilihPelangganSheet(all);
                  },
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: _kBrand),
                    foregroundColor: _kBrand,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 12),
                  ),
                  child: const Text('Pilih'),
                ),
              ],
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _waCtrl,
              keyboardType: TextInputType.phone,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              onChanged: (_) => setState(() {
                _customerSaved = false;
                _waValidatedPhone = null;
              }),
              decoration: InputDecoration(
                hintText: 'Nomor WhatsApp pelanggan',
                prefixIcon: const Icon(Icons.phone_outlined, size: 20),
                prefixText: '+62 ',
                suffixIcon: _waValidatedPhone == null
                    ? null
                    : const Icon(Icons.verified_rounded,
                        color: Color(0xFF059669), size: 18),
                isDense: true,
                filled: true,
                fillColor: Colors.grey.shade50,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _openingWhatsapp ? null : _cekWhatsapp,
                    icon: const Icon(Icons.message_outlined, size: 16),
                    label: Text(_openingWhatsapp ? 'Membuka...' : 'Cek WA'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF059669),
                      side: const BorderSide(color: Color(0xFF86EFAC)),
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      textStyle: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _customerSaved ? null : _simpanPelangganCepat,
                    icon: const Icon(Icons.save_rounded, size: 16),
                    label: const Text('Simpan Pelanggan'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: Colors.grey.shade300,
                      disabledForegroundColor: Colors.black26,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                      textStyle: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Pengambilan & Pengantaran',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _kBrand.withValues(alpha: 0.08),
                    border: Border.all(color: const Color(0xFFDBEAFE)),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: const Text(
                    'Wajib',
                    style: TextStyle(
                      color: _kBrand,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            const Text(
              'Pilih cara pelanggan menyerahkan/mengambil servis.',
              style: TextStyle(
                fontSize: 12,
                color: Color(0xFF64748B),
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            RadioGroup<String>(
              groupValue: _jenisPesanan,
              onChanged: (v) {
                if (v != null) {
                  setState(() => _jenisPesanan = v);
                }
              },
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () =>
                          setState(() => _jenisPesanan = 'Ambil Sendiri'),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: _jenisPesanan == 'Ambil Sendiri'
                                ? _kBrand
                                : Colors.grey.shade300,
                            width: _jenisPesanan == 'Ambil Sendiri' ? 1.5 : 1,
                          ),
                          borderRadius: BorderRadius.zero,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Radio<String>(
                              value: 'Ambil Sendiri',
                              activeColor: _kBrand,
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                              visualDensity: VisualDensity.compact,
                            ),
                            const SizedBox(width: 2),
                            Text(
                              'Ambil di Toko',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: _jenisPesanan == 'Ambil Sendiri'
                                    ? FontWeight.w800
                                    : FontWeight.w600,
                                color: _jenisPesanan == 'Ambil Sendiri'
                                    ? _kBrand
                                    : const Color(0xFF334155),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: GestureDetector(
                      onTap: () =>
                          setState(() => _jenisPesanan = 'Antar Jemput'),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: _jenisPesanan == 'Antar Jemput'
                                ? _kBrand
                                : Colors.grey.shade300,
                            width: _jenisPesanan == 'Antar Jemput' ? 1.5 : 1,
                          ),
                          borderRadius: BorderRadius.zero,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Radio<String>(
                              value: 'Antar Jemput',
                              activeColor: _kBrand,
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                              visualDensity: VisualDensity.compact,
                            ),
                            const SizedBox(width: 2),
                            Text(
                              'Antar/Jemput',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: _jenisPesanan == 'Antar Jemput'
                                    ? FontWeight.w800
                                    : FontWeight.w600,
                                color: _jenisPesanan == 'Antar Jemput'
                                    ? _kBrand
                                    : const Color(0xFF334155),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (_jenisPesanan == 'Antar Jemput') ...[
              const SizedBox(height: 12),
              const Text(
                'Alamat Pelanggan',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
              const SizedBox(height: 6),
              TextField(
                controller: _alamatCtrl,
                maxLines: 2,
                decoration: InputDecoration(
                  hintText: 'Masukkan alamat lengkap...',
                  prefixIcon: const Icon(Icons.location_on_outlined, size: 20),
                  isDense: true,
                  filled: true,
                  fillColor: Colors.grey.shade50,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: Colors.grey.shade300),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.zero,
                    borderSide: BorderSide(color: Colors.grey.shade300),
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                ),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _jenisPesanan == 'Antar Jemput'
                      ? 'Jadwal Jemput / Antar'
                      : 'Estimasi Pengambilan',
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 15),
                ),
                Row(
                  children: [
                    Text(
                      _jadwalAmbilAktif ? 'Manual' : 'Tidak diatur',
                      style: const TextStyle(
                        color: Color(0xFF64748B),
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Transform.scale(
                      scale: 0.85,
                      child: Switch(
                        value: _jadwalAmbilAktif,
                        onChanged: (v) => setState(() => _jadwalAmbilAktif = v),
                        activeThumbColor: _kBrand,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              _jadwalAmbilAktif
                  ? 'Atur tanggal dan jam manual untuk komunikasi ke pelanggan.'
                  : 'Opsional. Jika tidak diatur, sistem memakai estimasi layanan bila tersedia.',
              style: const TextStyle(
                fontSize: 12,
                color: Color(0xFF64748B),
                height: 1.35,
              ),
            ),
            if (_jadwalAmbilAktif) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        final d = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime.now(),
                          lastDate:
                              DateTime.now().add(const Duration(days: 365)),
                        );
                        if (d != null) setState(() => _tanggal = d);
                      },
                      icon: const Icon(Icons.calendar_today_outlined, size: 16),
                      label: Text(
                        _tanggal == null
                            ? 'Pilih Tanggal'
                            : '${_tanggal!.day}/${_tanggal!.month}/${_tanggal!.year}',
                        style: const TextStyle(fontSize: 13),
                      ),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: Colors.grey.shade400),
                        foregroundColor: Colors.black54,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        final t = await showTimePicker(
                          context: context,
                          initialTime: TimeOfDay.now(),
                        );
                        if (t != null) setState(() => _waktu = t);
                      },
                      icon: const Icon(Icons.access_time_outlined, size: 16),
                      label: Text(
                        _waktu == null
                            ? 'Pilih Waktu'
                            : _waktu!.format(context),
                        style: const TextStyle(fontSize: 13),
                      ),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: Colors.grey.shade400),
                        foregroundColor: Colors.black54,
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                border: Border.all(color: const Color(0xFFE2E8F0)),
                borderRadius: BorderRadius.zero,
              ),
              child: const Row(
                children: [
                  Icon(Icons.payments_outlined,
                      size: 17, color: Color(0xFF64748B)),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Status pembayaran: Belum Lunas',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF334155),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: _kBrand, width: 1.5),
                      foregroundColor: _kBrand,
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    child: const Text('Batal',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 15)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _loading ? null : _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      disabledBackgroundColor: _kBrand.withValues(alpha: 0.5),
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                    child: _loading
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2.5),
                          )
                        : const Text(
                            'Simpan Tagihan',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.bold),
                          ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// WIDGET: SHEET TAMBAH KE PESANAN AKTIF

class _GabungkanPesananSheet extends StatefulWidget {
  final Map<Product, double> cartItems;
  final List<Transaction> openOrders;
  final VoidCallback onBatal;
  final Future<void> Function(Transaction selectedTx) onOk;

  const _GabungkanPesananSheet({
    required this.cartItems,
    required this.openOrders,
    required this.onBatal,
    required this.onOk,
  });

  @override
  State<_GabungkanPesananSheet> createState() => _GabungkanPesananSheetState();
}

class _GabungkanPesananSheetState extends State<_GabungkanPesananSheet> {
  Transaction? _selected;
  bool _loading = false;
  String _search = '';
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  List<Transaction> get _filtered {
    if (_search.isEmpty) return widget.openOrders;
    return widget.openOrders.where((t) {
      final name = (t.customerName ?? '').toLowerCase();
      final id = t.id.toString();
      final query = _search.toLowerCase();
      return name.contains(query) || id.contains(query);
    }).toList();
  }

  String _formatTime(String iso) {
    try {
      final dt = DateTime.parse(iso);
      final diff = DateTime.now().difference(dt);
      if (diff.inMinutes < 60) return '${diff.inMinutes}m yang lalu';
      if (diff.inHours < 24) return '${diff.inHours}j yang lalu';
      return '${dt.day}/${dt.month} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.8,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      builder: (ctx, sc) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.zero),
        ),
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                controller: sc,
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.zero,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color:
                                const Color(0xFF6366F1).withValues(alpha: 0.1),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: const Icon(Icons.add_shopping_cart_rounded,
                              color: Color(0xFF6366F1), size: 24),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Pilih Pesanan Aktif',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 18),
                              ),
                              Text(
                                'Pilih pesanan pelanggan untuk ditambah item.',
                                style: TextStyle(
                                    color: Colors.black54, fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _searchCtrl,
                      onChanged: (v) => setState(() => _search = v),
                      decoration: InputDecoration(
                        hintText: 'Cari nama atau no pesanan...',
                        prefixIcon: const Icon(Icons.search, size: 20),
                        isDense: true,
                        filled: true,
                        fillColor: Colors.grey.shade100,
                        border: const OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.zero,
                        ),
                        contentPadding:
                            const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                    const SizedBox(height: 16),
                    if (widget.openOrders.isEmpty)
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 40),
                        child: const Column(
                          children: [
                            Icon(Icons.inventory_2_outlined,
                                size: 48, color: Color(0xFFCCCCCC)),
                            SizedBox(height: 12),
                            Text(
                              'Tidak ada pesanan aktif',
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Gunakan "Bayar Nanti" untuk pesanan baru.',
                              style: TextStyle(
                                  color: Colors.black45, fontSize: 13),
                            ),
                          ],
                        ),
                      )
                    else if (_filtered.isEmpty)
                      const Center(
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 40),
                          child: Text('Pesanan tidak ditemukan',
                              style: TextStyle(color: Colors.black38)),
                        ),
                      )
                    else
                      ListView.separated(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _filtered.length,
                        separatorBuilder: (_, __) =>
                            const Divider(height: 1, color: Color(0xFFEEEEEE)),
                        itemBuilder: (_, i) {
                          final tx = _filtered[i];
                          final isSelected = _selected?.id == tx.id;
                          return InkWell(
                            onTap: () => setState(() => _selected = tx),
                            borderRadius: BorderRadius.zero,
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              padding: const EdgeInsets.symmetric(
                                  vertical: 12, horizontal: 10),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? const Color(0xFF6366F1)
                                        .withValues(alpha: 0.08)
                                    : Colors.transparent,
                                borderRadius: BorderRadius.zero,
                                border: Border.all(
                                  color: isSelected
                                      ? const Color(0xFF6366F1)
                                      : Colors.transparent,
                                  width: 1,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '#${tx.id}',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 11,
                                          color: isSelected
                                              ? const Color(0xFF6366F1)
                                              : Colors.black38,
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        tx.customerName?.isNotEmpty == true
                                            ? tx.customerName!
                                            : 'Pelanggan Umum',
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 15,
                                          color: isSelected
                                              ? const Color(0xFF6366F1)
                                              : Colors.black87,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Row(
                                        children: [
                                          Icon(Icons.access_time_rounded,
                                              size: 13,
                                              color: Colors.grey.shade400),
                                          const SizedBox(width: 4),
                                          Text(
                                            _formatTime(tx.createdAt),
                                            style: TextStyle(
                                              fontSize: 11,
                                              color: Colors.grey.shade500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  const Spacer(),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        'Rp${_fK(tx.grandTotal)}',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                          color: isSelected
                                              ? const Color(0xFF6366F1)
                                              : Colors.black87,
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      const Text(
                                        'Tagihan Saat Ini',
                                        style: TextStyle(
                                          fontSize: 10,
                                          color: Colors.black54,
                                        ),
                                      ),
                                    ],
                                  ),
                                  if (isSelected)
                                    const Icon(Icons.check_circle_rounded,
                                        color: _kBrand, size: 20),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(
                  20, 12, 20, MediaQuery.of(context).padding.bottom + 16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: Colors.grey.shade200)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: widget.onBatal,
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: _kBrand),
                        foregroundColor: _kBrand,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: const Text('Batal',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: (_selected == null || _loading)
                          ? null
                          : () async {
                              final messenger = ScaffoldMessenger.of(context);
                              setState(() => _loading = true);
                              try {
                                await widget.onOk(_selected!);
                              } catch (e) {
                                if (mounted) {
                                  messenger.showSnackBar(const SnackBar(
                                    content: Text(
                                        'Operasi gagal. Silakan coba lagi.'),
                                    backgroundColor: Colors.black87,
                                    behavior: SnackBarBehavior.floating,
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.zero),
                                  ));
                                }
                              } finally {
                                if (mounted) setState(() => _loading = false);
                              }
                            },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kBrand,
                        disabledBackgroundColor: _kBrand.withValues(alpha: 0.4),
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.zero),
                      ),
                      child: _loading
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                  color: Colors.white, strokeWidth: 2),
                            )
                          : const Text(
                              'OK',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _IlustrasiKonfirmasi extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 90,
          height: 100,
          decoration: BoxDecoration(
              color: Colors.grey.shade100, borderRadius: BorderRadius.zero),
          child: Icon(Icons.smartphone_rounded,
              size: 60, color: Colors.grey.shade400),
        ),
        Positioned(
          bottom: 10,
          right: 10,
          child: Container(
            width: 26,
            height: 26,
            decoration:
                const BoxDecoration(color: _kBrand, shape: BoxShape.rectangle),
            child: const Icon(Icons.check, color: Colors.white, size: 14),
          ),
        ),
      ],
    );
  }
}

class _PaymentSection extends StatelessWidget {
  final bool isWide;
  final int grandTotal;
  final MetodeBayar metodeBayar;
  final ValueChanged<MetodeBayar> onMetodeChanged;
  final TextEditingController? namaCtrl;
  final TextEditingController? waCtrl;
  final VoidCallback? onPilihPelanggan;
  final VoidCallback? onCustomerChanged;
  final VoidCallback? onCheckWhatsapp;
  final bool openingWhatsapp;
  final bool whatsappValidated;
  final TextEditingController jumlahCtrl;
  final TextEditingController campuranTunaiCtrl;
  final int kembalian;
  final VoidCallback onHitungKembalian;
  final String subMetodeNonTunai;
  final ValueChanged<String> onSubMetodeChanged;
  final Map<String, dynamic>? paymentSettings;
  final bool loadingSettings;
  final VoidCallback? onSaveCustomer;

  const _PaymentSection({
    required this.isWide,
    required this.grandTotal,
    required this.metodeBayar,
    required this.onMetodeChanged,
    required this.jumlahCtrl,
    required this.campuranTunaiCtrl,
    required this.kembalian,
    required this.onHitungKembalian,
    required this.subMetodeNonTunai,
    required this.onSubMetodeChanged,
    required this.paymentSettings,
    required this.loadingSettings,
    this.namaCtrl,
    this.waCtrl,
    this.onPilihPelanggan,
    this.onCustomerChanged,
    this.onCheckWhatsapp,
    this.openingWhatsapp = false,
    this.whatsappValidated = false,
    this.onSaveCustomer,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (namaCtrl != null) ...[
          _SectionCardPorted(
            title: 'Data Pelanggan (Wajib)',
            icon: Icons.person_outline_rounded,
            tablet: true,
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: namaCtrl,
                        onChanged: (_) => onCustomerChanged?.call(),
                        style: const TextStyle(fontSize: 14),
                        decoration: const InputDecoration(
                          hintText: 'Ketik nama pelanggan...',
                          hintStyle: TextStyle(color: Colors.black38),
                          prefixIcon: Icon(Icons.person_search_rounded,
                              size: 18, color: Colors.black38),
                          filled: true,
                          fillColor: Color(0xFFF5F7FA),
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: 14, vertical: 12),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.zero,
                              borderSide: BorderSide.none),
                        ),
                      ),
                    ),
                    if (onPilihPelanggan != null) ...[
                      const SizedBox(width: 8),
                      OutlinedButton.icon(
                        onPressed: onPilihPelanggan,
                        icon: const Icon(Icons.people_alt_outlined, size: 16),
                        label: const Text('Pilih',
                            style: TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w600)),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: _kBrand,
                          side: const BorderSide(color: _kBrand),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 12),
                          shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.zero),
                        ),
                      ),
                    ],
                  ],
                ),
                if (waCtrl != null) ...[
                  const SizedBox(height: 10),
                  TextField(
                    controller: waCtrl,
                    keyboardType: TextInputType.phone,
                    onChanged: (_) => onCustomerChanged?.call(),
                    style: const TextStyle(fontSize: 14),
                    decoration: InputDecoration(
                      hintText: 'Nomor WhatsApp...',
                      hintStyle: const TextStyle(color: Colors.black38),
                      prefixIcon: const Icon(Icons.phone_rounded,
                          size: 18, color: Colors.black38),
                      suffixIcon: whatsappValidated
                          ? const Icon(Icons.verified_rounded,
                              color: Color(0xFF059669), size: 18)
                          : null,
                      filled: true,
                      fillColor: const Color(0xFFF5F7FA),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 12),
                      border: const OutlineInputBorder(
                          borderRadius: BorderRadius.zero,
                          borderSide: BorderSide.none),
                    ),
                  ),
                  if (whatsappValidated) ...[
                    const SizedBox(height: 8),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFECFDF5),
                        border: Border.all(color: const Color(0xFFA7F3D0)),
                        borderRadius: BorderRadius.zero,
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.verified_rounded,
                              color: Color(0xFF059669), size: 17),
                          SizedBox(width: 8),
                          Text(
                            'WA Valid',
                            style: TextStyle(
                              color: Color(0xFF047857),
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ] else if (onCheckWhatsapp != null ||
                      onSaveCustomer != null) ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        if (onCheckWhatsapp != null)
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed:
                                  openingWhatsapp ? null : onCheckWhatsapp,
                              icon:
                                  const Icon(Icons.message_outlined, size: 16),
                              label: Text(
                                openingWhatsapp ? 'Membuka...' : 'Cek WA',
                                overflow: TextOverflow.ellipsis,
                              ),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: const Color(0xFF059669),
                                side:
                                    const BorderSide(color: Color(0xFF86EFAC)),
                                padding:
                                    const EdgeInsets.symmetric(vertical: 12),
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.zero),
                                textStyle: const TextStyle(
                                    fontSize: 12, fontWeight: FontWeight.w800),
                              ),
                            ),
                          ),
                        if (onCheckWhatsapp != null && onSaveCustomer != null)
                          const SizedBox(width: 8),
                        if (onSaveCustomer != null)
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: onSaveCustomer,
                              icon: const Icon(Icons.save_rounded, size: 16),
                              label: const Text(
                                'Simpan',
                                overflow: TextOverflow.ellipsis,
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _kBrand,
                                foregroundColor: Colors.white,
                                elevation: 0,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 12),
                                shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.zero),
                                textStyle: const TextStyle(
                                    fontSize: 12, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ],
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],
        _SectionCardPorted(
          title: 'Metode Pembayaran',
          icon: Icons.payments_outlined,
          tablet: true,
          child: Row(
            children: [
              _MetodeChipPorted(
                  label: 'Tunai',
                  icon: Icons.money_rounded,
                  selected: metodeBayar == MetodeBayar.tunai,
                  onTap: () => onMetodeChanged(MetodeBayar.tunai)),
              const SizedBox(width: 8),
              _MetodeChipPorted(
                  label: 'Non-Tunai',
                  icon: Icons.contactless_rounded,
                  selected: metodeBayar == MetodeBayar.nonTunai,
                  onTap: () => onMetodeChanged(MetodeBayar.nonTunai)),
              const SizedBox(width: 8),
              _MetodeChipPorted(
                  label: 'Campuran',
                  icon: Icons.account_balance_wallet_outlined,
                  selected: metodeBayar == MetodeBayar.campuran,
                  onTap: () => onMetodeChanged(MetodeBayar.campuran)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _buildPaymentFormPorted(context),
      ],
    );
  }

  Widget _buildPaymentFormPorted(BuildContext context) {
    switch (metodeBayar) {
      case MetodeBayar.tunai:
        return _SectionCardPorted(
          title: 'Detail Tunai',
          icon: Icons.money_rounded,
          tablet: true,
          child: Column(
            children: [
              TextField(
                controller: jumlahCtrl,
                keyboardType: TextInputType.number,
                inputFormatters: const [CurrencyInputFormatter()],
                onChanged: (_) => onHitungKembalian(),
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                decoration: const InputDecoration(
                  labelText: 'Jumlah Bayar (Rp)',
                  hintText: '0',
                  labelStyle: TextStyle(color: Colors.black38, fontSize: 13),
                  prefixText: 'Rp ',
                  prefixStyle: TextStyle(
                      fontWeight: FontWeight.bold, color: Colors.black54),
                  filled: true,
                  fillColor: Color(0xFFF5F7FA),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide.none),
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                ),
              ),
              const SizedBox(height: 12),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () {
                    jumlahCtrl.text = formatCurrencyInput(grandTotal);
                    onHitungKembalian();
                  },
                  icon: const Icon(Icons.payments_rounded, size: 18),
                  label: const Text('UANG PAS',
                      style:
                          TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _kBrand,
                    backgroundColor: _kBrand.withValues(alpha: 0.05),
                    side: const BorderSide(color: _kBrand, width: 1.5),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                  ),
                ),
              ),
              Builder(
                builder: (context) {
                  final denoms = {
                    _roundUpPorted(grandTotal, 10000),
                    _roundUpPorted(grandTotal, 50000),
                    _roundUpPorted(grandTotal, 100000),
                  }.where((v) => v > grandTotal).toList()
                    ..sort();

                  if (denoms.isEmpty) return const SizedBox.shrink();

                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 4.5,
                        mainAxisSpacing: 6,
                        crossAxisSpacing: 8,
                      ),
                      itemCount: denoms.length,
                      itemBuilder: (context, i) {
                        final v = denoms[i];
                        return GestureDetector(
                          onTap: () {
                            jumlahCtrl.text = formatCurrencyInput(v);
                            onHitungKembalian();
                          },
                          child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              border: Border.all(
                                  color: _kBrand.withValues(alpha: 0.3)),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Text('Rp ${_fK(v)}',
                                style: const TextStyle(
                                    fontSize: 12,
                                    color: _kBrand,
                                    fontWeight: FontWeight.w700)),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
              if (kembalian > 0) ...[
                const SizedBox(height: 10),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: _kBrand.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.zero,
                    border: Border.all(color: _kBrand.withValues(alpha: 0.3)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Kembalian',
                          style: TextStyle(
                              fontWeight: FontWeight.w600, color: _kBrand)),
                      Text('Rp ${_fK(kembalian)}',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              color: Color(0xFF2E7D32))),
                    ],
                  ),
                ),
              ],
            ],
          ),
        );
      case MetodeBayar.nonTunai:
        final qrisFile = _paymentQrisFile(paymentSettings);
        final hasBankDetails = _hasBankPaymentDetails(paymentSettings);
        return _SectionCardPorted(
          title: 'Detail Non-Tunai',
          icon: Icons.contactless_rounded,
          tablet: true,
          child: loadingSettings
              ? const Center(child: CircularProgressIndicator(color: _kBrand))
              : Column(
                  children: [
                    Row(
                      children: [
                        _SubMetodeChipPorted(
                            label: 'QRIS',
                            icon: Icons.qr_code_rounded,
                            selected: subMetodeNonTunai == 'qris',
                            onTap: () => onSubMetodeChanged('qris')),
                        const SizedBox(width: 8),
                        _SubMetodeChipPorted(
                            label: 'Transfer Bank',
                            icon: Icons.account_balance_rounded,
                            selected: subMetodeNonTunai == 'bank',
                            onTap: () => onSubMetodeChanged('bank')),
                      ],
                    ),
                    const SizedBox(height: 16),
                    if (subMetodeNonTunai == 'qris' && qrisFile != null)
                      Column(
                        children: [
                          _NonCashViewButton(
                            label: 'Lihat QRIS',
                            icon: Icons.fullscreen_rounded,
                            onPressed: () => _showNonCashCustomerDisplay(
                              context,
                              mode: 'qris',
                              settings: paymentSettings!,
                              amount: grandTotal,
                            ),
                          ),
                          const SizedBox(height: 12),
                          if (_paymentSettingText(paymentSettings, 'qris_name')
                              .isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: Text(
                                _paymentSettingText(
                                  paymentSettings,
                                  'qris_name',
                                ),
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 15,
                                  color: _kBrand,
                                ),
                              ),
                            ),
                          Center(
                            child: ClipRRect(
                              borderRadius: BorderRadius.zero,
                              child: Image.file(
                                qrisFile,
                                width: 160,
                                height: 160,
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),
                        ],
                      )
                    else if (subMetodeNonTunai == 'bank' &&
                        paymentSettings != null &&
                        hasBankDetails)
                      Column(
                        children: [
                          _NonCashViewButton(
                            label: 'Lihat Detail Bank',
                            icon: Icons.fullscreen_rounded,
                            onPressed: () => _showNonCashCustomerDisplay(
                              context,
                              mode: 'bank',
                              settings: paymentSettings!,
                              amount: grandTotal,
                            ),
                          ),
                          const SizedBox(height: 12),
                          _BankInfoPorted(settings: paymentSettings!),
                        ],
                      )
                    else
                      const Text('Pengaturan pembayaran belum lengkap.',
                          style: TextStyle(fontSize: 12, color: Colors.orange)),
                  ],
                ),
        );
      case MetodeBayar.campuran:
        final tunai = parseCurrencyInput(campuranTunaiCtrl.text);
        final sisa = (grandTotal - tunai).clamp(0, grandTotal);
        return _SectionCardPorted(
          title: 'Pembayaran Campuran',
          icon: Icons.account_balance_wallet_outlined,
          tablet: true,
          child: Column(
            children: [
              TextField(
                controller: campuranTunaiCtrl,
                keyboardType: TextInputType.number,
                inputFormatters: const [CurrencyInputFormatter()],
                onChanged: (_) => onHitungKembalian(),
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                decoration: const InputDecoration(
                  labelText: 'Jumlah Tunai (Rp)',
                  hintText: '0',
                  prefixText: 'Rp ',
                  filled: true,
                  fillColor: Color(0xFFF5F7FA),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.zero,
                      borderSide: BorderSide.none),
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _kBrand.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.zero,
                  border: Border.all(color: _kBrand.withValues(alpha: 0.1)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Sisa (Non-Tunai)',
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Colors.black54)),
                    Text('Rp ${_fK(sisa)}',
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: _kBrand)),
                  ],
                ),
              ),
            ],
          ),
        );
    }
  }

  int _roundUpPorted(int amount, int step) {
    if (step == 0) return amount;
    return ((amount / step).ceil()) * step;
  }
}

class _SectionCardPorted extends StatelessWidget {
  final String title;
  final IconData icon;
  final bool tablet;
  final Widget child;

  const _SectionCardPorted(
      {required this.title,
      required this.icon,
      required this.tablet,
      required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(tablet ? 16 : 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.zero,
        border: Border.all(color: const Color(0xFFE8E8E8)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Icon(icon, size: 14, color: Colors.black45),
              const SizedBox(width: 6),
              Text(title.toUpperCase(),
                  style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      color: Colors.black38,
                      letterSpacing: 0.8)),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _MetodeChipPorted extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _MetodeChipPorted(
      {required this.label,
      required this.icon,
      required this.selected,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: selected ? _kBrand : _kBrand.withValues(alpha: 0.05),
            borderRadius: BorderRadius.zero,
            border: Border.all(
                color: selected ? _kBrand : _kBrand.withValues(alpha: 0.1)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: selected ? Colors.white : _kBrand, size: 20),
              const SizedBox(height: 4),
              Text(label,
                  style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: selected ? Colors.white : _kBrand)),
            ],
          ),
        ),
      ),
    );
  }
}

class _SubMetodeChipPorted extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _SubMetodeChipPorted(
      {required this.label,
      required this.icon,
      required this.selected,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color:
                selected ? _kBrand.withValues(alpha: 0.1) : Colors.transparent,
            borderRadius: BorderRadius.zero,
            border:
                Border.all(color: selected ? _kBrand : const Color(0xFFE0E0E0)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 16, color: selected ? _kBrand : Colors.black45),
              const SizedBox(width: 6),
              Text(label,
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: selected ? _kBrand : Colors.black45)),
            ],
          ),
        ),
      ),
    );
  }
}

class _BankInfoPorted extends StatelessWidget {
  final Map<String, dynamic> settings;
  const _BankInfoPorted({required this.settings});

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> banks = [];
    final String? banksJson = settings['banks_json'];
    if (banksJson != null && banksJson.isNotEmpty) {
      try {
        final decoded = jsonDecode(banksJson);
        banks =
            (decoded as List).map((e) => Map<String, dynamic>.from(e)).toList();
      } catch (_) {}
    }
    if (banks.isEmpty) {
      banks.add({
        'name': settings['bank_name'] ?? '-',
        'account_number': settings['account_number'] ?? '-',
        'account_name': settings['account_name'] ?? '-',
      });
    }
    return Column(
      children: banks.map((bank) {
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFF5F7FA),
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFE0E0E0)),
          ),
          child: Column(
            children: [
              _RowPorted(label: 'Bank', value: bank['name'] ?? '-'),
              const SizedBox(height: 6),
              _RowPorted(
                  label: 'No. Rekening', value: bank['account_number'] ?? '-'),
              const SizedBox(height: 6),
              _RowPorted(
                  label: 'Atas Nama', value: bank['account_name'] ?? '-'),
            ],
          ),
        );
      }).toList(),
    );
  }
}

class _RowPorted extends StatelessWidget {
  final String label;
  final String value;
  const _RowPorted({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: const TextStyle(fontSize: 12, color: Colors.black45)),
        Text(value,
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: Colors.black87)),
      ],
    );
  }
}

class _NonCashViewButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onPressed;

  const _NonCashViewButton({
    required this.label,
    required this.icon,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 42,
      child: OutlinedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, size: 17),
        label: Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
        ),
        style: OutlinedButton.styleFrom(
          foregroundColor: _kBrand,
          backgroundColor: _kBrand.withValues(alpha: 0.04),
          side: const BorderSide(color: _kBrand, width: 1.2),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ),
      ),
    );
  }
}

class _NonCashCustomerDisplayScreen extends StatelessWidget {
  final String mode;
  final Map<String, dynamic> settings;
  final int amount;

  const _NonCashCustomerDisplayScreen({
    required this.mode,
    required this.settings,
    required this.amount,
  });

  @override
  Widget build(BuildContext context) {
    final isQris = mode == 'qris';
    final title = isQris ? 'Scan QRIS' : 'Transfer Bank';

    return Scaffold(
      backgroundColor: isQris ? Colors.white : const Color(0xFFF5F7FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: const Color(0xFF111827),
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.close_rounded),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          TextButton.icon(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.close_rounded, size: 17),
            label: const Text(
              'Tutup',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            style: TextButton.styleFrom(foregroundColor: _kBrand),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        top: false,
        child: isQris
            ? _QrisCustomerDisplay(settings: settings, amount: amount)
            : _BankCustomerDisplay(settings: settings, amount: amount),
      ),
    );
  }
}

class _CustomerDisplayAmount extends StatelessWidget {
  final int amount;
  const _CustomerDisplayAmount({required this.amount});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        color: _kBrand.withValues(alpha: 0.08),
        border: Border.all(color: _kBrand.withValues(alpha: 0.22)),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        children: [
          const Expanded(
            child: Text(
              'Total Pembayaran',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: Color(0xFF64748B),
              ),
            ),
          ),
          Text(
            'Rp ${_fK(amount)}',
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w900,
              color: _kBrand,
            ),
          ),
        ],
      ),
    );
  }
}

class _QrisCustomerDisplay extends StatelessWidget {
  final Map<String, dynamic> settings;
  final int amount;

  const _QrisCustomerDisplay({
    required this.settings,
    required this.amount,
  });

  @override
  Widget build(BuildContext context) {
    final qrisFile = _paymentQrisFile(settings);
    final qrisName = _paymentSettingText(settings, 'qris_name');
    final displayName = qrisName.isEmpty ? 'QRIS' : qrisName;

    return LayoutBuilder(
      builder: (context, constraints) {
        var qrSize = constraints.maxWidth - 48;
        final heightTarget = constraints.maxHeight - 210;
        if (heightTarget > 0 && heightTarget < qrSize) qrSize = heightTarget;
        if (qrSize > 760) qrSize = 760;
        if (qrSize < 220) qrSize = 220;

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 760),
                child: _CustomerDisplayAmount(amount: amount),
              ),
            ),
            Expanded(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: qrisFile == null
                      ? const _PaymentDisplayEmpty()
                      : Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              displayName,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 26,
                                fontWeight: FontWeight.w900,
                                color: Color(0xFF111827),
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              'Silakan scan QRIS untuk pembayaran',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF64748B),
                              ),
                            ),
                            const SizedBox(height: 18),
                            Container(
                              width: qrSize,
                              height: qrSize,
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.zero,
                                border: Border.all(
                                  color: const Color(0xFFE2E8F0),
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.06),
                                    blurRadius: 24,
                                    offset: const Offset(0, 8),
                                  ),
                                ],
                              ),
                              child: InteractiveViewer(
                                minScale: 1,
                                maxScale: 4,
                                child:
                                    Image.file(qrisFile, fit: BoxFit.contain),
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _BankCustomerDisplay extends StatelessWidget {
  final Map<String, dynamic> settings;
  final int amount;

  const _BankCustomerDisplay({
    required this.settings,
    required this.amount,
  });

  @override
  Widget build(BuildContext context) {
    final banks = _paymentBanksFromSettings(settings);

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: Column(
            children: [
              _CustomerDisplayAmount(amount: amount),
              const SizedBox(height: 16),
              if (banks.isEmpty)
                const _PaymentDisplayEmpty()
              else
                ...banks.map((bank) => _CustomerBankCard(bank: bank)),
            ],
          ),
        ),
      ),
    );
  }
}

class _CustomerBankCard extends StatelessWidget {
  final Map<String, String> bank;

  const _CustomerBankCard({required this.bank});

  @override
  Widget build(BuildContext context) {
    final name = (bank['name'] ?? '').isEmpty ? '-' : bank['name']!;
    final accountNumber =
        (bank['account_number'] ?? '').isEmpty ? '-' : bank['account_number']!;
    final accountName =
        (bank['account_name'] ?? '').isEmpty ? '-' : bank['account_name']!;

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: _kBrand.withValues(alpha: 0.08),
                  border: Border.all(color: _kBrand.withValues(alpha: 0.18)),
                  borderRadius: BorderRadius.zero,
                ),
                child: const Icon(
                  Icons.account_balance_rounded,
                  color: _kBrand,
                  size: 24,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF111827),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Text(
            'No. Rekening',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: Color(0xFF64748B),
            ),
          ),
          const SizedBox(height: 6),
          SelectableText(
            accountNumber,
            style: const TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.w900,
              color: _kBrand,
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Atas Nama',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: Color(0xFF64748B),
            ),
          ),
          const SizedBox(height: 6),
          SelectableText(
            accountName,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            height: 46,
            child: OutlinedButton.icon(
              onPressed: accountNumber == '-'
                  ? null
                  : () {
                      Clipboard.setData(ClipboardData(text: accountNumber));
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Nomor rekening disalin'),
                          behavior: SnackBarBehavior.floating,
                          duration: Duration(seconds: 1),
                        ),
                      );
                    },
              icon: const Icon(Icons.copy_rounded, size: 17),
              label: const Text(
                'Salin Nomor Rekening',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: _kBrand,
                side: const BorderSide(color: _kBrand),
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PaymentDisplayEmpty extends StatelessWidget {
  const _PaymentDisplayEmpty();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7ED),
        border: Border.all(color: const Color(0xFFFED7AA)),
        borderRadius: BorderRadius.zero,
      ),
      child: const Row(
        children: [
          Icon(Icons.warning_amber_rounded, color: Color(0xFFC2410C)),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'Pengaturan pembayaran belum lengkap.',
              style: TextStyle(
                color: Color(0xFFC2410C),
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CustomerSearchPicker extends StatefulWidget {
  final List<Customer> customers;
  final Function(Customer) onSelected;

  const _CustomerSearchPicker({
    required this.customers,
    required this.onSelected,
  });

  @override
  State<_CustomerSearchPicker> createState() => _CustomerSearchPickerState();
}

class _CustomerSearchPickerState extends State<_CustomerSearchPicker> {
  final _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _query.isEmpty
        ? widget.customers
        : widget.customers
            .where((c) =>
                c.name.toLowerCase().contains(_query.toLowerCase()) ||
                (c.phone?.contains(_query) ?? false))
            .toList();

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 40,
          height: 4,
          decoration: BoxDecoration(
            color: Colors.grey.shade300,
            borderRadius: BorderRadius.zero,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'Pilih Pelanggan',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _searchCtrl,
          autofocus: true,
          onChanged: (v) => setState(() => _query = v),
          decoration: const InputDecoration(
            hintText: 'Cari nama / nomor HP...',
            prefixIcon: Icon(Icons.search_rounded, size: 20),
            isDense: true,
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: filtered.isEmpty
              ? const Center(child: Text('Pelanggan tidak ditemukan'))
              : ListView.builder(
                  itemCount: filtered.length,
                  itemBuilder: (_, i) {
                    final c = filtered[i];
                    return ListTile(
                      leading: const CircleAvatar(
                        backgroundColor: AppColors.brandLight,
                        child: Icon(Icons.person_rounded,
                            color: AppColors.primaryBrand, size: 20),
                      ),
                      title: Text(c.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 14)),
                      subtitle: Text(c.phone ?? '-',
                          style: const TextStyle(
                              fontSize: 12, color: Colors.black45)),
                      onTap: () => widget.onSelected(c),
                    );
                  },
                ),
        ),
      ],
    );
  }
}






