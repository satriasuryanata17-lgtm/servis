import 'package:flutter/material.dart';
import '../core/theme.dart';
import 'responsive_layout.dart';
import 'package:url_launcher/url_launcher.dart';

// HUKUM & PRIVASI SCREEN

class HukumPrivasiScreen extends StatelessWidget {
  const HukumPrivasiScreen({super.key});

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isWide = isTabletDevice(context) || isLandscape(context);

    return KasirResponsiveScaffold(
      title: 'Hukum & Privasi',
      showNavRail: false,
      backgroundColor: const Color(0xFFF5F5F5),
      body: SingleChildScrollView(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 960),
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: isWide ? 32 : 16,
                vertical: 24,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _PageHeader(
                    icon: Icons.balance_outlined,
                    title: 'Hukum & Privasi',
                    subtitle:
                        'Kebijakan privasi dan syarat penggunaan Juragan Servis',
                    isWide: isWide,
                  ),
                  SizedBox(height: isWide ? 28 : 20),
                  if (isWide)
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(child: _privacySection(context)),
                        const SizedBox(width: 20),
                        Expanded(child: _termsSection(context)),
                      ],
                    )
                  else ...[
                    _privacySection(context),
                    const SizedBox(height: 20),
                    _termsSection(context),
                  ],
                  const SizedBox(height: 24),
                  const _FooterNote(),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _privacySection(BuildContext context) {
    return _Section(
      icon: Icons.shield_outlined,
      title: 'Kebijakan Privasi',
      items: const [
        _Item(
          title: 'Data yang Dikumpulkan',
          content:
              'Juragan Servis mengumpulkan data yang Anda masukkan secara langsung - produk, transaksi, pelanggan, dan profil toko. Semua data tersimpan lokal di perangkat Anda.',
        ),
        _Item(
          title: 'Penggunaan Data',
          content:
              'Data digunakan semata-mata untuk operasional servis Anda. Kami tidak menjual, menyewakan, atau membagikan data Anda kepada pihak ketiga.',
        ),
        _Item(
          title: 'Keamanan Data',
          content:
              'Data diamankan dengan enkripsi lokal. Backup dikelola oleh pengguna. Lakukan backup rutin untuk perlindungan optimal.',
        ),
        _Item(
          title: 'Lisensi & Aktivasi',
          content:
              'Lisensi Juragan Servis berlaku seumur hidup dan dapat digunakan di perangkat yang Anda miliki tanpa batas. Tidak ada biaya langganan tahunan.',
        ),
      ],
      linkLabel: 'Lihat kebijakan lengkap',
      linkUrl:
          'https://sites.google.com/view/juraganservis-privacy/halaman-muka',
      launchUrl: _launchUrl,
    );
  }

  Widget _termsSection(BuildContext context) {
    return _Section(
      icon: Icons.description_outlined,
      title: 'Syarat & Ketentuan',
      items: const [
        _Item(
          title: 'Penggunaan Aplikasi',
          content:
              'Juragan Servis hanya boleh digunakan untuk keperluan bisnis yang sah sesuai hukum yang berlaku di Indonesia.',
        ),
        _Item(
          title: 'Lisensi Pengguna',
          content:
              'Setiap lisensi berlaku selamanya dan dapat digunakan di banyak perangkat milik Anda sendiri. Tidak ada pembatasan jumlah perangkat.',
        ),
        _Item(
          title: 'Pembaruan Aplikasi',
          content:
              'Kami berhak memperbarui fitur dan antarmuka sewaktu-waktu. Pengguna akan diberitahu melalui notifikasi dalam aplikasi.',
        ),
        _Item(
          title: 'Tanggung Jawab Pengguna',
          content:
              'Pengguna bertanggung jawab atas keamanan kata sandi dan data yang dikelola. Kami tidak bertanggung jawab atas kehilangan data akibat kelalaian pengguna.',
        ),
        _Item(
          title: 'Pembatasan Tanggung Jawab',
          content:
              'Juragan Servis disediakan "sebagaimana adanya." Kami tidak bertanggung jawab atas kerugian tidak langsung akibat penggunaan aplikasi.',
        ),
      ],
      linkLabel: 'Lihat syarat lengkap',
      linkUrl:
          'https://sites.google.com/view/syarat-ketentuan-juraganservis/halaman-muka',
      launchUrl: _launchUrl,
    );
  }
}

// PAGE HEADER

class _PageHeader extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool isWide;

  const _PageHeader({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.isWide,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(isWide ? 24 : 18),
      color: AppColors.primaryBrand,
      child: Row(
        children: [
          Icon(icon, color: Colors.white.withValues(alpha: 0.9), size: 28),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.75),
                      fontSize: 12.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// SECTION WIDGET

class _Section extends StatelessWidget {
  final IconData icon;
  final String title;
  final List<_Item> items;
  final String linkLabel;
  final String linkUrl;
  final Future<void> Function(String) launchUrl;

  const _Section({
    required this.icon,
    required this.title,
    required this.items,
    required this.linkLabel,
    required this.linkUrl,
    required this.launchUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          top: BorderSide(color: AppColors.primaryBrand, width: 2),
          left: BorderSide(color: Color(0xFFE0E0E0)),
          right: BorderSide(color: Color(0xFFE0E0E0)),
          bottom: BorderSide(color: Color(0xFFE0E0E0)),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Row(
              children: [
                Icon(icon, color: AppColors.primaryBrand, size: 18),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1A1A1A)),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),

          // Items
          ...items.map((item) => _ItemTile(item: item)),

          // Link
          InkWell(
            onTap: () => launchUrl(linkUrl),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              child: Row(
                children: [
                  const Icon(Icons.open_in_new_rounded,
                      size: 12, color: AppColors.primaryBrand),
                  const SizedBox(width: 6),
                  Text(
                    linkLabel,
                    style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.primaryBrand,
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ITEM TILE

class _ItemTile extends StatelessWidget {
  final _Item item;
  const _ItemTile({required this.item});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 2),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                  width: 3,
                  height: 12,
                  color: AppColors.primaryBrand.withValues(alpha: 0.5),
                  margin: const EdgeInsets.only(right: 7)),
              Expanded(
                child: Text(
                  item.title,
                  style: const TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF333333)),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10, top: 4, bottom: 8),
            child: Text(
              item.content,
              style: const TextStyle(
                  fontSize: 12, color: Colors.black54, height: 1.55),
            ),
          ),
          const Divider(height: 1, color: Color(0xFFF0F0F0)),
        ],
      ),
    );
  }
}

// Data model
class _Item {
  final String title;
  final String content;
  const _Item({required this.title, required this.content});
}

// Footer Note (const-safe)

class _FooterNote extends StatelessWidget {
  const _FooterNote();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE0E0E0)),
      ),
      child: const Text(
        'Dengan menggunakan Juragan Servis, Anda menyetujui Kebijakan Privasi dan Syarat & Ketentuan yang berlaku. '
        'Pertanyaan? Hubungi kami di halo.juragankasir@gmail.com. '
        'Terakhir diperbarui: April 2025.',
        style: TextStyle(fontSize: 11.5, color: Colors.black45, height: 1.6),
        textAlign: TextAlign.center,
      ),
    );
  }
}

