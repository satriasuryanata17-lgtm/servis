import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../models/db_models.dart';
import '../providers/providers.dart';
import '../services/export_service.dart';
import '../utils/currency_input_formatter.dart';
import '../widgets/kasir_dialog.dart';
import '../core/theme.dart';

const Color _kBrand = AppColors.primaryBrand;
const Color _kBg = Color(0xFFF7F7F9);

// HELPERS
String _fmtRp(int value) {
  final s = value.abs().toString();
  final buf = StringBuffer('Rp');
  if (value < 0) buf.write('-');
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
    buf.write(s[i]);
  }
  return buf.toString();
}

String _fmtDate(String? iso, {String fmt = 'dd MMM yyyy, HH:mm'}) {
  if (iso == null || iso.isEmpty) return '-';
  final dt = DateTime.tryParse(iso);
  if (dt == null) return iso;
  return DateFormat(fmt, 'id').format(dt);
}

String _durasi(String openedAt, String? closedAt) {
  final a = DateTime.tryParse(openedAt);
  final b = closedAt != null ? DateTime.tryParse(closedAt) : null;
  if (a == null || b == null) return '-';
  final diff = b.difference(a);
  final h = diff.inHours;
  final m = diff.inMinutes % 60;
  if (h > 0) return '${h}j ${m}m';
  return '${m}m';
}

String _petugasName(KasirSession session) {
  final name = session.staffName?.trim() ?? '';
  return name.isNotEmpty ? name : 'Tidak tercatat';
}

String _petugasLabel(KasirSession session) {
  final role = session.staffRole?.trim() ?? '';
  final name = _petugasName(session);
  if (name == 'Tidak tercatat') {
    return 'Petugas belum tersimpan pada data lama';
  }
  return role.isNotEmpty ? '$name ($role)' : name;
}

// FILTER HELPERS
enum _Periode { bulanan, mingguan, harian }

List<String> _bulanOptions() {
  final now = DateTime.now();
  const months = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember',
  ];
  final result = <String>[];
  for (int i = 0; i < 13; i++) {
    final dt = DateTime(now.year, now.month - i, 1);
    result.add('${months[dt.month - 1]} ${dt.year}');
  }
  return result;
}

DateTime _parseBulan(String bulan) {
  const monthMap = {
    'Januari': 1,
    'Februari': 2,
    'Maret': 3,
    'April': 4,
    'Mei': 5,
    'Juni': 6,
    'Juli': 7,
    'Agustus': 8,
    'September': 9,
    'Oktober': 10,
    'November': 11,
    'Desember': 12,
  };
  final parts = bulan.split(' ');
  final month = monthMap[parts.first] ?? DateTime.now().month;
  final year = int.tryParse(parts.last) ?? DateTime.now().year;
  return DateTime(year, month);
}

List<KasirSession> _applyFilter(
    List<KasirSession> all, _Periode periode, String bulan) {
  final now = DateTime.now();
  return all.where((s) {
    final dt = DateTime.tryParse(s.closedAt ?? s.openedAt);
    if (dt == null) return false;
    switch (periode) {
      case _Periode.harian:
        return dt.year == now.year &&
            dt.month == now.month &&
            dt.day == now.day;
      case _Periode.mingguan:
        final weekStart = now.subtract(Duration(days: now.weekday - 1));
        final weekEnd = weekStart.add(const Duration(days: 7));
        return dt.isAfter(weekStart.subtract(const Duration(seconds: 1))) &&
            dt.isBefore(weekEnd);
      case _Periode.bulanan:
        final m = _parseBulan(bulan);
        return dt.year == m.year && dt.month == m.month;
    }
  }).toList()
    ..sort((a, b) =>
        (b.closedAt ?? b.openedAt).compareTo(a.closedAt ?? a.openedAt));
}

//
//  RIWAYAT TUTUP KASIR  --  Responsive (Phone + Tablet/Landscape)
//
class RiwayatTutupKasirScreen extends ConsumerStatefulWidget {
  const RiwayatTutupKasirScreen({super.key});

  @override
  ConsumerState<RiwayatTutupKasirScreen> createState() =>
      _RiwayatTutupKasirScreenState();
}

class _RiwayatTutupKasirScreenState
    extends ConsumerState<RiwayatTutupKasirScreen> {
  _Periode _periode = _Periode.bulanan;
  late String _bulan;
  final _bulanOpts = _bulanOptions();
  final Set<int> _expandedIds = {};

  bool _isWide(BuildContext context) =>
      MediaQuery.of(context).size.width >= 720;

  @override
  void initState() {
    super.initState();
    _bulan = _bulanOpts.first;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final args = ModalRoute.of(context)?.settings.arguments;
      if (args == true) {
        _showTutupKasirDialog();
      } else if (args == 'open' || args == false) {
        // Jika args == false dari TransaksiScreen, berarti mau buka
        _showBukaKasirDialog();
      }
    });
  }

  String _periodeLabel() {
    switch (_periode) {
      case _Periode.harian:
        return 'Hari Ini';
      case _Periode.mingguan:
        return 'Minggu Ini';
      case _Periode.bulanan:
        return _bulan;
    }
  }

  Future<void> _export(List<KasirSession> sessions) async {
    if (sessions.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Belum ada data untuk diekspor.'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
      );
      return;
    }
    final rows = sessions
        .map((s) => <Object?>[
              s.id,
              s.kasirName,
              s.staffName ?? '',
              s.staffRole ?? '',
              s.shiftName ?? '-',
              _fmtDate(s.openedAt),
              _fmtDate(s.closedAt),
              _durasi(s.openedAt, s.closedAt),
              s.openingCash,
              s.closingCash,
              s.totalTransactions,
              s.totalRevenue,
              s.totalCash,
              s.totalNonCash,
              s.selisihKas,
              s.notes ?? '',
            ])
        .toList();
    try {
      await ExportService.exportAndShareCsv(
        filePrefix: 'riwayat_tutup_kasir',
        headers: const [
          'ID',
          'Petugas (Sistem)',
          'Petugas',
          'Role',
          'Shift',
          'Buka',
          'Tutup',
          'Durasi',
          'Modal Awal',
          'Kas Akhir',
          'Jml Trx',
          'Total Omzet',
          'Tunai',
          'Non-Tunai',
          'Selisih Kas',
          'Catatan',
        ],
        rows: rows,
        subject: 'Ekspor Riwayat Shift',
        message: 'Periode: ${_periodeLabel()}',
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Gagal mengekspor laporan. Silakan coba lagi.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
    }
  }

  void _showTutupKasirDialog() {
    final activeSession = ref.read(activeKasirSessionProvider).asData?.value;
    if (activeSession == null) {
      _showBukaKasirDialog();
      return;
    }
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => TutupKasirSheet(
        activeSession: activeSession,
        onSubmit: (kasirName, openingCash, closingCash, openedAt, notes) async {
          final notifier = ref.read(kasirSessionsProvider.notifier);
          await notifier.closeSession(
            sessionId: activeSession.id!,
            openedAt: activeSession.openedAt,
            openingCash: openingCash,
            closingCash: closingCash,
            notes: notes,
          );
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('- Shift berhasil ditutup'),
                backgroundColor: Colors.black87,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              ),
            );
          }
        },
      ),
    );
  }

  void _showBukaKasirDialog() {
    final activeStaff = ref.read(activeStaffProvider);
    final profile = ref.read(profilProvider);
    final staffId =
        activeStaff != null && activeStaff.id != null && activeStaff.id! > 0
            ? activeStaff.id
            : null;
    final staffName = activeStaff?.name ??
        (profile.nama.trim().isNotEmpty ? profile.nama.trim() : 'Owner');
    final staffRole = activeStaff?.role ?? 'Administrator';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => BukaKasirSheet(
        initialKasirName: staffName,
        onSubmit: (kasirName, openingCash, shiftName) async {
          await ref.read(kasirSessionsProvider.notifier).openSession(
                kasirName: kasirName,
                openingCash: openingCash,
                shiftName: shiftName,
                staffId: staffId,
                staffName: staffName,
                staffRole: staffRole,
              );
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('- Shift berhasil dimulai. Selamat bertugas!'),
                backgroundColor: Colors.black87,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              ),
            );
            // Navigasi balik ke transaksi jika tadi dari sana
            if (Navigator.canPop(context)) {
              Navigator.pop(context); // Tutup sheet
              final args = ModalRoute.of(context)?.settings.arguments;
              if (args == 'open' || args == false) {
                if (Navigator.canPop(context)) Navigator.pop(context);
              }
            }
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final all = ref.watch(kasirSessionsProvider);
    final filtered = _applyFilter(all, _periode, _bulan);
    final totalOmzet = filtered.fold<int>(0, (s, e) => s + e.totalRevenue);
    final totalTrx = filtered.fold<int>(0, (s, e) => s + e.totalTransactions);
    final closedSess = filtered.where((s) => !s.isOpen).length;
    final wide = _isWide(context);

    return Scaffold(
      backgroundColor: wide ? const Color(0xFFF5F5F7) : _kBg,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(filtered),
            Expanded(
              child: wide
                  ? _buildTabletLayout(
                      all: all,
                      filtered: filtered,
                      closedSess: closedSess,
                      totalTrx: totalTrx,
                      totalOmzet: totalOmzet,
                    )
                  : _buildPhoneLayout(
                      all: all,
                      filtered: filtered,
                      closedSess: closedSess,
                      totalTrx: totalTrx,
                      totalOmzet: totalOmzet,
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(List<KasirSession> filtered) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(4, 10, 12, 10),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _kBrand, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          const Expanded(
            child: Text('Riwayat Shift',
                style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87)),
          ),
          const SizedBox(width: 8),
          _SmallButton(
            label: 'Ekspor',
            onTap: () => _export(filtered),
            color: _kBrand,
          ),
        ],
      ),
    );
  }

  Widget _buildFilterRow() {
    return Row(
      children: [
        Expanded(
          child: _DropdownChip(
            value: _periodeLabel(),
            options: const [
              'Periode Harian',
              'Periode Mingguan',
              'Periode Bulanan'
            ],
            onChanged: (v) => setState(() {
              if (v.contains('Harian')) _periode = _Periode.harian;
              if (v.contains('Mingguan')) _periode = _Periode.mingguan;
              if (v.contains('Bulanan')) _periode = _Periode.bulanan;
            }),
          ),
        ),
        if (_periode == _Periode.bulanan) ...[
          const SizedBox(width: 10),
          Expanded(
            child: _DropdownChip(
              value: _bulan,
              options: _bulanOpts,
              onChanged: (v) => setState(() => _bulan = v),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildPhoneLayout({
    required List<KasirSession> all,
    required List<KasirSession> filtered,
    required int closedSess,
    required int totalTrx,
    required int totalOmzet,
  }) {
    return Column(
      children: [
        Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: _buildFilterRow(),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: _SummaryCard(
            sesi: closedSess,
            transaksi: totalTrx,
            omzet: totalOmzet,
          ),
        ),
        const SizedBox(height: 8),
        Expanded(child: _buildSessionList(all, filtered)),
      ],
    );
  }

  Widget _buildTabletLayout({
    required List<KasirSession> all,
    required List<KasirSession> filtered,
    required int closedSess,
    required int totalTrx,
    required int totalOmzet,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 300,
          color: Colors.white,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'FILTER PERIODE',
                  style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Colors.black38,
                      letterSpacing: 1.0),
                ),
                const SizedBox(height: 12),
                _DropdownChip(
                  value: _periodeLabel(),
                  options: const [
                    'Periode Harian',
                    'Periode Mingguan',
                    'Periode Bulanan',
                  ],
                  onChanged: (v) => setState(() {
                    if (v.contains('Harian')) _periode = _Periode.harian;
                    if (v.contains('Mingguan')) _periode = _Periode.mingguan;
                    if (v.contains('Bulanan')) _periode = _Periode.bulanan;
                  }),
                ),
                if (_periode == _Periode.bulanan) ...[
                  const SizedBox(height: 10),
                  _DropdownChip(
                    value: _bulan,
                    options: _bulanOpts,
                    onChanged: (v) => setState(() => _bulan = v),
                  ),
                ],
                const SizedBox(height: 24),
                const Divider(height: 1, color: Color(0xFFEEEEEE)),
                const SizedBox(height: 20),
                _SummaryCard(
                  sesi: closedSess,
                  transaksi: totalTrx,
                  omzet: totalOmzet,
                ),
                const SizedBox(height: 20),
                _buildTabletStats(filtered),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _showTutupKasirDialog,
                    icon: const Icon(Icons.point_of_sale_rounded, size: 18),
                    label: const Text('Tutup Shift',
                        style: TextStyle(
                            fontSize: 13, fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kBrand,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const VerticalDivider(width: 1, color: Color(0xFFEEEEEE)),
        Expanded(
          child: Container(
            color: const Color(0xFFF5F5F7),
            child: _buildSessionList(all, filtered),
          ),
        ),
      ],
    );
  }

  Widget _buildTabletStats(List<KasirSession> filtered) {
    final openSess = filtered.where((s) => s.isOpen).length;
    final totalCash = filtered.fold<int>(0, (s, e) => s + e.totalCash);
    final totalNonCash = filtered.fold<int>(0, (s, e) => s + e.totalNonCash);

    final items = [
      (
        icon: Icons.lock_open_rounded,
        label: 'Sesi Aktif',
        value: '$openSess',
        color: const Color(0xFFFFB300),
      ),
      (
        icon: Icons.payments_outlined,
        label: 'Tunai',
        value: _fmtRp(totalCash),
        color: const Color(0xFF059669),
      ),
      (
        icon: Icons.contactless_outlined,
        label: 'Non-Tunai',
        value: _fmtRp(totalNonCash),
        color: const Color(0xFF2563EB),
      ),
    ];

    return Column(
      children: items.map((item) {
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: item.color.withValues(alpha: 0.07),
            borderRadius: BorderRadius.zero,
            border: Border.all(color: item.color.withValues(alpha: 0.2)),
          ),
          child: Row(
            children: [
              Icon(item.icon, color: item.color, size: 18),
              const SizedBox(width: 10),
              Expanded(
                child: Text(item.label,
                    style:
                        const TextStyle(fontSize: 12, color: Colors.black54)),
              ),
              Flexible(
                child: Text(
                  item.value,
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: item.color),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildSessionList(
      List<KasirSession> all, List<KasirSession> filtered) {
    if (all.isEmpty) return const _EmptyState();
    if (filtered.isEmpty) {
      return _EmptyState(
        subtitle: 'Tidak ada data shift\npada ${_periodeLabel()}',
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      itemCount: filtered.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) {
        final s = filtered[i];
        final key = s.id ?? i;
        final expanded = _expandedIds.contains(key);
        return _SessionCard(
          session: s,
          expanded: expanded,
          onToggle: () => setState(() {
            if (expanded) {
              _expandedIds.remove(key);
            } else {
              _expandedIds.add(key);
            }
          }),
        );
      },
    );
  }
}

//
// TUTUP SHIFT SHEET
//
class TutupKasirSheet extends StatefulWidget {
  final KasirSession? activeSession;
  final Future<void> Function(String, int, int, String, String?) onSubmit;
  const TutupKasirSheet(
      {super.key, required this.activeSession, required this.onSubmit});

  @override
  State<TutupKasirSheet> createState() => _TutupKasirSheetState();
}

class _TutupKasirSheetState extends State<TutupKasirSheet> {
  final _kasirCtrl = TextEditingController();
  final _modalCtrl = TextEditingController();
  final _kasAkhirCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  DateTime _openedAt = DateTime.now().subtract(const Duration(hours: 8));
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    if (widget.activeSession != null) {
      _kasirCtrl.text = widget.activeSession!.kasirName;
      _modalCtrl.text = formatCurrencyInput(widget.activeSession!.openingCash);
      _openedAt =
          DateTime.tryParse(widget.activeSession!.openedAt) ?? _openedAt;
    }
  }

  @override
  void dispose() {
    _kasirCtrl.dispose();
    _modalCtrl.dispose();
    _kasAkhirCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  int _parseInt(String v) => parseCurrencyInput(v);

  Future<void> _submit() async {
    final kasir = _kasirCtrl.text.trim();
    if (kasir.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Masukkan nama petugas.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      return;
    }
    if (_kasAkhirCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Masukkan kas akhir aktual.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      return;
    }
    setState(() => _loading = true);
    try {
      await widget.onSubmit(
        kasir,
        _parseInt(_modalCtrl.text),
        _parseInt(_kasAkhirCtrl.text),
        _openedAt.toIso8601String(),
        _notesCtrl.text.trim().isEmpty ? null : _notesCtrl.text.trim(),
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Gagal menutup shift. Silakan coba lagi.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _pickOpenedAt() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _openedAt,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx)
            .copyWith(colorScheme: const ColorScheme.light(primary: _kBrand)),
        child: child!,
      ),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_openedAt),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx)
            .copyWith(colorScheme: const ColorScheme.light(primary: _kBrand)),
        child: child!,
      ),
    );
    if (time == null) return;
    setState(() => _openedAt =
        DateTime(date.year, date.month, date.day, time.hour, time.minute));
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    final modal = _parseInt(_modalCtrl.text);
    final kasAkhir = _parseInt(_kasAkhirCtrl.text);
    final selisih = kasAkhir - modal;
    final selisihColor =
        selisih >= 0 ? const Color(0xFF388E3C) : AppColors.danger;

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      padding: EdgeInsets.fromLTRB(20, 16, 20, 24 + bottomInset),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.zero),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: _kBrand.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.zero),
                  child: const Icon(Icons.point_of_sale_rounded,
                      color: _kBrand, size: 22),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Tutup Shift',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87)),
                    Text(
                      widget.activeSession != null
                          ? 'Sesi aktif: ${_fmtDate(widget.activeSession!.openedAt)}'
                          : 'Catat penutupan shift',
                      style:
                          const TextStyle(fontSize: 12, color: Colors.black45),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Divider(height: 1),
            const SizedBox(height: 16),
            const FieldLabel('Nama Petugas'),
            InputField(
              controller: _kasirCtrl,
              hint: 'Contoh: Budi',
              readOnly: widget.activeSession != null,
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 14),
            if (widget.activeSession == null) ...[
              const FieldLabel('Waktu Mulai Shift'),
              GestureDetector(
                onTap: _pickOpenedAt,
                child: Container(
                  width: double.infinity,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(
                    color: _kBg,
                    borderRadius: BorderRadius.zero,
                    border: Border.all(color: const Color(0xFFE0E0E0)),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                          child: Text(
                        DateFormat('dd MMM yyyy, HH:mm', 'id')
                            .format(_openedAt),
                        style: const TextStyle(
                            fontSize: 14, color: Colors.black87),
                      )),
                      const Icon(Icons.calendar_today_outlined,
                          color: _kBrand, size: 18),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
            ],
            const FieldLabel('Modal Awal (Kas Tunai)'),
            InputField(
              controller: _modalCtrl,
              hint: '0',
              keyboardType: TextInputType.number,
              prefix: 'Rp',
              readOnly: widget.activeSession != null,
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 14),
            const FieldLabel('Kas Akhir Aktual (Hitung Fisik)'),
            TextField(
              controller: _kasAkhirCtrl,
              keyboardType: TextInputType.number,
              autofocus: true,
              cursorColor: _kBrand,
              cursorWidth: 2,
              inputFormatters: const [CurrencyInputFormatter()],
              onChanged: (_) => setState(() {}),
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w800,
                color: Colors.black87,
              ),
              decoration: InputDecoration(
                hintText: '0',
                hintStyle: const TextStyle(
                  color: Colors.black26,
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                ),
                prefixText: 'Rp ',
                prefixStyle: const TextStyle(
                  fontSize: 17,
                  color: _kBrand,
                  fontWeight: FontWeight.w800,
                ),
                filled: true,
                fillColor: Colors.white,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                border: const OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: Color(0xFFB9D4D2), width: 1.2),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(
                    color: _kasAkhirCtrl.text.trim().isEmpty
                        ? _kBrand.withValues(alpha: 0.65)
                        : const Color(0xFFB9D4D2),
                    width: _kasAkhirCtrl.text.trim().isEmpty ? 1.5 : 1.2,
                  ),
                ),
                focusedBorder: const OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: _kBrand, width: 2),
                ),
              ),
            ),
            const SizedBox(height: 10),
            if (_kasAkhirCtrl.text.isNotEmpty)
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                decoration: BoxDecoration(
                  color: selisihColor.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.zero,
                  border:
                      Border.all(color: selisihColor.withValues(alpha: 0.3)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      selisih >= 0 ? 'Kelebihan Kas' : 'Kekurangan Kas',
                      style: TextStyle(
                          color: selisihColor,
                          fontWeight: FontWeight.w600,
                          fontSize: 13),
                    ),
                    Text(_fmtRp(selisih.abs()),
                        style: TextStyle(
                            color: selisihColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 14)),
                  ],
                ),
              ),
            const SizedBox(height: 14),
            const FieldLabel('Catatan (opsional)'),
            InputField(
              controller: _notesCtrl,
              hint: 'Tambahkan catatan...',
              maxLines: 2,
            ),
            const SizedBox(height: 22),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _loading ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _kBrand,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
                child: _loading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Text('Tutup Shift & Simpan',
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//
// SUMMARY CARD
//
class _SummaryCard extends StatelessWidget {
  final int sesi, transaksi, omzet;
  const _SummaryCard(
      {required this.sesi, required this.transaksi, required this.omzet});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_kBrand, AppColors.primaryDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.zero,
        boxShadow: [
          BoxShadow(
              color: _kBrand.withValues(alpha: 0.25),
              blurRadius: 10,
              offset: const Offset(0, 4))
        ],
      ),
      child: Row(
        children: [
          _SumItem(
              label: 'Sesi', value: '$sesi', icon: Icons.lock_clock_outlined),
          _vDivider(),
          _SumItem(
              label: 'Transaksi',
              value: '$transaksi',
              icon: Icons.receipt_long_outlined),
          _vDivider(),
          _SumItem(
              label: 'Total Omzet',
              value: _fmtRp(omzet),
              icon: Icons.monetization_on_outlined),
        ],
      ),
    );
  }

  Widget _vDivider() => Container(
      height: 40,
      width: 1,
      color: Colors.white24,
      margin: const EdgeInsets.symmetric(horizontal: 8));
}

class _SumItem extends StatelessWidget {
  final String label, value;
  final IconData icon;
  const _SumItem(
      {required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Expanded(
        child: Column(
      children: [
        Icon(icon, color: Colors.white70, size: 16),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
            maxLines: 1,
            overflow: TextOverflow.ellipsis),
        Text(label,
            style: const TextStyle(color: Colors.white60, fontSize: 11)),
      ],
    ));
  }
}

//
// SESSION CARD
//
class _SessionCard extends StatelessWidget {
  final KasirSession session;
  final bool expanded;
  final VoidCallback onToggle;
  const _SessionCard(
      {required this.session, required this.expanded, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    final isOpen = session.isOpen;
    final selisih = session.selisihKas;
    final selisihColor =
        selisih >= 0 ? const Color(0xFF388E3C) : AppColors.danger;

    return GestureDetector(
      onTap: onToggle,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          border: Border.all(
            color: isOpen
                ? const Color(0xFFFFB300).withValues(alpha: 0.4)
                : const Color(0xFFEEEEEE),
          ),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 6,
                offset: const Offset(0, 2))
          ],
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              child: Row(
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: isOpen
                          ? const Color(0xFFFFB300)
                          : const Color(0xFF94A3B8),
                      shape: BoxShape.rectangle,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              session.kasirName.isNotEmpty
                                  ? session.kasirName
                                  : 'Petugas',
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                  color: Colors.black87),
                            ),
                            if (session.shiftName != null &&
                                session.shiftName!.isNotEmpty) ...[
                              const SizedBox(width: 4),
                              Text('(${session.shiftName})',
                                  style: const TextStyle(
                                      fontSize: 12, color: Colors.black54)),
                            ],
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(
                                color: isOpen
                                    ? const Color(0xFFFFF8E1)
                                    : const Color(0xFFF1F5F9),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: Text(
                                isOpen ? 'Aktif' : 'Selesai',
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                    color: isOpen
                                        ? const Color(0xFFFFB300)
                                        : const Color(0xFF64748B)),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 3),
                        Text(
                          isOpen
                              ? 'Dibuka: ${_fmtDate(session.openedAt)}'
                              : 'Ditutup: ${_fmtDate(session.closedAt)}',
                          style: const TextStyle(
                              fontSize: 12, color: Colors.black45),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Petugas: ${_petugasLabel(session)}',
                          style: const TextStyle(
                              fontSize: 12, color: Colors.black45),
                        ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(_fmtRp(session.totalRevenue),
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: Colors.black87)),
                      Text('${session.totalTransactions} transaksi',
                          style: const TextStyle(
                              fontSize: 11, color: Colors.black45)),
                    ],
                  ),
                  const SizedBox(width: 8),
                  AnimatedRotation(
                    duration: const Duration(milliseconds: 200),
                    turns: expanded ? 0.5 : 0,
                    child: const Icon(Icons.keyboard_arrow_down_rounded,
                        color: Colors.black38, size: 22),
                  ),
                ],
              ),
            ),
            AnimatedCrossFade(
              duration: const Duration(milliseconds: 200),
              crossFadeState: expanded
                  ? CrossFadeState.showSecond
                  : CrossFadeState.showFirst,
              firstChild: const SizedBox.shrink(),
              secondChild: Column(
                children: [
                  const Divider(height: 1, color: Color(0xFFF0F0F0)),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
                    child: Column(
                      children: [
                        _DetailRow(
                            label: 'Durasi Sesi',
                            value: _durasi(session.openedAt, session.closedAt),
                            icon: Icons.timer_outlined),
                        _DetailRow(
                            label: 'Dibuka',
                            value: _fmtDate(session.openedAt),
                            icon: Icons.login_rounded),
                        _DetailRow(
                            label: 'Petugas',
                            value: _petugasLabel(session),
                            icon: Icons.badge_outlined),
                        if (!isOpen)
                          _DetailRow(
                              label: 'Ditutup',
                              value: _fmtDate(session.closedAt),
                              icon: Icons.logout_rounded),
                        const SizedBox(height: 8),
                        const Divider(height: 1, color: Color(0xFFF0F0F0)),
                        const SizedBox(height: 8),
                        _DetailRow(
                            label: 'Modal Awal',
                            value: _fmtRp(session.openingCash),
                            icon: Icons.account_balance_wallet_outlined),
                        _DetailRow(
                            label: 'Penjualan Tunai',
                            value: _fmtRp(session.totalCash),
                            icon: Icons.payments_outlined,
                            valueColor: const Color(0xFF388E3C)),
                        _DetailRow(
                            label: 'Non-Tunai (QRIS/Transfer)',
                            value: _fmtRp(session.totalNonCash),
                            icon: Icons.contactless_outlined,
                            valueColor: const Color(0xFF1565C0)),
                        if (!isOpen) ...[
                          _DetailRow(
                              label: 'Kas Akhir Aktual',
                              value: _fmtRp(session.closingCash),
                              icon: Icons.calculate_outlined),
                          const SizedBox(height: 6),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              color: selisihColor.withValues(alpha: 0.08),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  selisih >= 0
                                      ? '- Kelebihan Kas'
                                      : ' Kekurangan Kas',
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13,
                                      color: selisihColor),
                                ),
                                Text(
                                  _fmtRp(selisih.abs()),
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                      color: selisihColor),
                                ),
                              ],
                            ),
                          ),
                        ],
                        if (session.notes != null &&
                            session.notes!.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(10),
                            decoration: const BoxDecoration(
                              color: Color(0xFFF5F5F5),
                              borderRadius: BorderRadius.zero,
                            ),
                            child: Text(
                              ' ${session.notes}',
                              style: const TextStyle(
                                  fontSize: 12, color: Colors.black54),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color? valueColor;
  const _DetailRow(
      {required this.label,
      required this.value,
      required this.icon,
      this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Icon(icon, size: 16, color: Colors.black38),
          const SizedBox(width: 8),
          Expanded(
              child: Text(label,
                  style: const TextStyle(fontSize: 13, color: Colors.black54))),
          Text(value,
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: valueColor ?? Colors.black87)),
        ],
      ),
    );
  }
}

//
// EMPTY STATE
//
class _EmptyState extends StatelessWidget {
  final String subtitle;
  const _EmptyState({this.subtitle = 'Belum ada riwayat shift.'});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _kBrand.withValues(alpha: 0.07),
              shape: BoxShape.rectangle,
            ),
            child: const Icon(Icons.point_of_sale_rounded,
                color: _kBrand, size: 48),
          ),
          const SizedBox(height: 18),
          const Text('Belum Ada Riwayat Shift',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87)),
          const SizedBox(height: 8),
          Text(subtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 13, color: Colors.black45)),
        ],
      ),
    );
  }
}

//
// REUSABLE WIDGETS
//
class _SmallButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color color;
  const _SmallButton(
      {required this.label, required this.onTap, required this.color});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration:
            BoxDecoration(color: color, borderRadius: BorderRadius.zero),
        child: Text(label,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _DropdownChip extends StatelessWidget {
  final String value;
  final List<String> options;
  final ValueChanged<String> onChanged;
  const _DropdownChip(
      {required this.value, required this.options, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        final selected = await showKasirOptionSheet<String>(
          context,
          title: 'Pilih',
          options: options,
          currentValue: value,
          labelBuilder: (idx) => idx,
        );
        if (selected != null) onChanged(selected);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: const Color(0xFFF5F5F5),
          borderRadius: BorderRadius.zero,
          border: Border.all(color: const Color(0xFFE0E0E0)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
                child: Text(value,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87))),
            const Icon(Icons.keyboard_arrow_down_rounded,
                color: _kBrand, size: 20),
          ],
        ),
      ),
    );
  }
}

class FieldLabel extends StatelessWidget {
  final String text;
  const FieldLabel(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(text,
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Colors.black54)),
      );
}

class InputField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final TextInputType keyboardType;
  final String? prefix;
  final int maxLines;
  final bool readOnly;
  final ValueChanged<String>? onChanged;

  const InputField({
    super.key,
    required this.controller,
    required this.hint,
    this.keyboardType = TextInputType.text,
    this.prefix,
    this.maxLines = 1,
    this.readOnly = false,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      readOnly: readOnly,
      keyboardType: keyboardType,
      maxLines: maxLines,
      onChanged: onChanged,
      inputFormatters: keyboardType == TextInputType.number
          ? (prefix == 'Rp'
              ? const [CurrencyInputFormatter()]
              : [FilteringTextInputFormatter.digitsOnly])
          : null,
      style: const TextStyle(fontSize: 14, color: Colors.black87),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.black38, fontSize: 14),
        prefixText: prefix != null ? '$prefix ' : null,
        prefixStyle: const TextStyle(
            fontSize: 14, color: Colors.black54, fontWeight: FontWeight.w600),
        filled: true,
        fillColor: readOnly ? const Color(0xFFF9F9F9) : _kBg,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: Color(0xFFE0E0E0))),
        enabledBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: Color(0xFFE0E0E0))),
        focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: _kBrand, width: 1.5)),
      ),
    );
  }
}

//
// BUKA KASIR SHEET
//
class BukaKasirSheet extends ConsumerStatefulWidget {
  final String initialKasirName;
  final Future<void> Function(String, int, String?) onSubmit;
  const BukaKasirSheet(
      {super.key, required this.initialKasirName, required this.onSubmit});

  @override
  ConsumerState<BukaKasirSheet> createState() => _BukaKasirSheetState();
}

class _BukaKasirSheetState extends ConsumerState<BukaKasirSheet> {
  late TextEditingController _kasirCtrl;
  final _modalCtrl = TextEditingController();
  String? _selectedShift;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _kasirCtrl = TextEditingController(text: widget.initialKasirName);
    final settings = ref.read(shiftSettingsProvider);
    if (settings.shiftNames.isNotEmpty) {
      _selectedShift = settings.shiftNames.first;
    }
  }

  @override
  void dispose() {
    _kasirCtrl.dispose();
    _modalCtrl.dispose();
    super.dispose();
  }

  int _parseInt(String v) => parseCurrencyInput(v);

  Future<void> _submit() async {
    final kasir = _kasirCtrl.text.trim();
    if (kasir.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Masukkan nama petugas.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      return;
    }
    setState(() => _loading = true);
    try {
      await widget.onSubmit(
        kasir,
        _parseInt(_modalCtrl.text),
        _selectedShift,
      );
      // No pop here, parent will handle navigation
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Gagal memulai shift. Silakan coba lagi.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        ));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    final settings = ref.watch(shiftSettingsProvider);

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.zero),
      ),
      padding: EdgeInsets.fromLTRB(20, 16, 20, 24 + bottomInset),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.zero),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: _kBrand.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.zero),
                  child: const Icon(Icons.lock_open_rounded,
                      color: _kBrand, size: 22),
                ),
                const SizedBox(width: 12),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Buka Shift Baru',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87)),
                    Text(
                      'Masukkan modal awal untuk memulai sesi',
                      style: TextStyle(fontSize: 12, color: Colors.black45),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Divider(height: 1),
            const SizedBox(height: 16),
            const FieldLabel('Nama Petugas'),
            InputField(
              controller: _kasirCtrl,
              hint: 'Contoh: Budi',
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 14),
            if (settings.enableShift && settings.shiftNames.isNotEmpty) ...[
              const FieldLabel('Pilih Shift'),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: _kBg,
                  borderRadius: BorderRadius.zero,
                  border: Border.all(color: const Color(0xFFE0E0E0)),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _selectedShift,
                    isExpanded: true,
                    items: settings.shiftNames
                        .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                        .toList(),
                    onChanged: (v) => setState(() => _selectedShift = v),
                  ),
                ),
              ),
              const SizedBox(height: 14),
            ],
            const FieldLabel('Modal Awal (Kas Tunai)'),
            InputField(
              controller: _modalCtrl,
              hint: '0',
              keyboardType: TextInputType.number,
              prefix: 'Rp',
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _loading ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _kBrand,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                ),
                child: _loading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Text('Mulai Shift Sekarang',
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

