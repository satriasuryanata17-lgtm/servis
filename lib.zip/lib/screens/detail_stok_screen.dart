import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../database/db_helper.dart';
import '../models/db_models.dart';
import '../providers/providers.dart';
import '../core/theme.dart';
import '../utils/currency_input_formatter.dart';
import 'produk_screen.dart';

const Color _kBrand = AppColors.primaryBrand;

bool _isWide(BuildContext ctx) {
  final mq = MediaQuery.of(ctx);
  return mq.size.width >= 720 ||
      (mq.orientation == Orientation.landscape && mq.size.width >= 600);
}

class DetailStokScreen extends ConsumerStatefulWidget {
  final Product product;

  /// True when shown as an embedded right-panel inside GudangLaporan
  final bool embedded;

  const DetailStokScreen({
    super.key,
    required this.product,
    this.embedded = false,
  });

  @override
  ConsumerState<DetailStokScreen> createState() => _DetailStokScreenState();
}

class _DetailStokScreenState extends ConsumerState<DetailStokScreen> {
  late Product _product;
  bool _manajemenStok = false;
  List<StockLog> _stockLogs = [];
  bool _loadingLogs = false;

  @override
  void initState() {
    super.initState();
    _product = widget.product;
    _manajemenStok = _product.hasStockManagement == 1;
    _loadLogs();
  }

  Future<void> _loadLogs() async {
    if (_product.id == null) return;
    setState(() => _loadingLogs = true);
    final logs = await DBHelper.instance.getStockLogsForProduct(_product.id!);
    final inLogs = logs.where((l) => l.type == 'in').toList();
    if (mounted) {
      setState(() {
        _stockLogs = inLogs;
        _loadingLogs = false;
      });
    }
  }

  String _fRp(int value) {
    if (value == 0) return 'Rp0';
    String s = value.toString(), r = '';
    int c = 0;
    for (int i = s.length - 1; i >= 0; i--) {
      r = s[i] + r;
      c++;
      if (c % 3 == 0 && i != 0) r = '.$r';
    }
    return 'Rp$r';
  }

  String _fDate(DateTime dt) =>
      '${dt.day.toString().padLeft(2, '0')}-${dt.month.toString().padLeft(2, '0')}-${dt.year}';

  String _generateStockName() {
    const months = [
      'JAN',
      'FEB',
      'MAR',
      'APR',
      'MEI',
      'JUN',
      'JUL',
      'AGU',
      'SEP',
      'OKT',
      'NOV',
      'DES'
    ];
    final now = DateTime.now();
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    final rng = Random();
    final suffix =
        List.generate(3, (_) => chars[rng.nextInt(chars.length)]).join();
    return '${months[now.month - 1]}-$suffix';
  }

  bool get _isMaterial => _product.isMaterial == 1;

  String get _stockItemName => _isMaterial ? 'Bahan Baku' : 'Produk';

  String get _unitLabel {
    final unit = _product.unit.trim();
    return unit.isEmpty ? 'unit' : unit;
  }

  String get _stockSheetTitle => 'Tambah Stok $_stockItemName';

  String get _stockSheetSubtitle => _isMaterial
      ? 'Catat sparepart dan bahan masuk seperti kabel, timah solder, konektor, atau komponen.'
      : 'Catat stok masuk untuk barang yang dijual.';

  int _parseIntInput(TextEditingController ctrl) {
    return int.tryParse(ctrl.text.replaceAll('.', '').trim()) ?? 0;
  }

  String _stockQtyLabel(int qty) => '$qty $_unitLabel';

  Widget _buildStockInputSummary(
    TextEditingController qtyCtrl,
    TextEditingController beliCtrl,
  ) {
    final incomingQty = _parseIntInput(qtyCtrl);
    final modalPerUnit = _parseIntInput(beliCtrl);
    final currentStock = _product.stock;
    final afterStock = currentStock + incomingQty;
    final totalModalMasuk = incomingQty * modalPerUnit;
    final avgModal = afterStock <= 0 || modalPerUnit <= 0 || incomingQty <= 0
        ? _product.buyPrice
        : (((currentStock * _product.buyPrice) + totalModalMasuk) / afterStock)
            .round();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FBFF),
        border: Border.all(color: const Color(0xFFD6E4FF)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.inventory_2_outlined, size: 16, color: _kBrand),
              SizedBox(width: 8),
              Text(
                'Ringkasan Stok',
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF1E3A8A),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _StockSummaryTile(
                  label: 'Stok sekarang',
                  value: _stockQtyLabel(currentStock),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _StockSummaryTile(
                  label: 'Setelah masuk',
                  value: incomingQty > 0
                      ? _stockQtyLabel(afterStock)
                      : 'Isi jumlah dulu',
                  highlight: incomingQty > 0,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _StockSummaryTile(
                  label: 'Total modal masuk',
                  value: _fRp(totalModalMasuk),
                  highlight: totalModalMasuk > 0,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _StockSummaryTile(
                  label: 'Modal rata-rata',
                  value: avgModal > 0 ? _fRp(avgModal) : '-',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _submitTambahStok(
    BuildContext ctx,
    TextEditingController nameCtrl,
    TextEditingController qtyCtrl,
    TextEditingController beliCtrl,
    DateTime tanggalMasuk,
    DateTime tanggalKedaluwarsa,
    bool pakaiKedaluwarsa,
  ) async {
    final qty = _parseIntInput(qtyCtrl);
    if (qty <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Masukkan jumlah stok yang valid.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      return;
    }
    if (_product.id == null) return;

    final modalBaru = _parseIntInput(beliCtrl);
    if (modalBaru <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Masukkan harga modal per $_unitLabel yang valid.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape:
              const RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
      return;
    }

    final oldStock = _product.stock;
    final oldBuyPrice = _product.buyPrice;
    final log = StockLog(
      productId: _product.id!,
      type: 'in',
      qty: qty,
      date: DateTime.now().toIso8601String(),
      stockName: nameCtrl.text.trim().isNotEmpty ? nameCtrl.text.trim() : null,
      entryDate: tanggalMasuk.toIso8601String().substring(0, 10),
      expiryDate: pakaiKedaluwarsa
          ? tanggalKedaluwarsa.toIso8601String().substring(0, 10)
          : null,
    );

    await ref.read(productsProvider.notifier).recordStockLog(log);

    if (modalBaru > 0 && modalBaru != oldBuyPrice) {
      final totalQty = oldStock + qty;
      final avgBuyPrice = totalQty <= 0
          ? modalBaru
          : (((oldStock * oldBuyPrice) + (qty * modalBaru)) / totalQty).round();
      final latest = ref
              .read(productsProvider)
              .where((p) => p.id == _product.id)
              .firstOrNull ??
          _product.copyWith(stock: totalQty);
      await ref
          .read(productsProvider.notifier)
          .updateProduct(latest.copyWith(buyPrice: avgBuyPrice));
    }

    if (ctx.mounted) Navigator.pop(ctx);
    await _loadLogs();
    final productsData = ref.read(productsProvider);
    final updated = productsData.where((p) => p.id == _product.id).firstOrNull;
    if (updated != null && mounted) {
      setState(() => _product = updated);
    }
  }

  Future<void> _toggleManajemenStok(bool value) async {
    final updated = Product(
      id: _product.id,
      name: _product.name,
      categoryId: _product.categoryId,
      stock: _product.stock,
      buyPrice: _product.buyPrice,
      sellPrice: _product.sellPrice,
      unit: _product.unit,
      minStock: _product.minStock,
      createdAt: _product.createdAt,
      imagePath: _product.imagePath,
      description: _product.description,
      sku: _product.sku,
      barcode: _product.barcode,
      hasStockManagement: value ? 1 : 0,
      hasWholesale: _product.hasWholesale,
      isExtra: _product.isExtra,
    );
    await ref.read(productsProvider.notifier).updateProduct(updated);
    setState(() {
      _product = updated;
      _manajemenStok = value;
    });
  }

  void _showTambahStokSheet() {
    final nameCtrl = TextEditingController(text: _generateStockName());
    final qtyCtrl = TextEditingController();
    final beliCtrl = TextEditingController(
        text: _product.buyPrice > 0
            ? formatCurrencyInput(_product.buyPrice)
            : '');
    DateTime tanggalMasuk = DateTime.now();
    DateTime tanggalKedaluwarsa = DateTime.now();
    bool pakaiKedaluwarsa = false;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.zero)),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) {
          final isLandscapeMode =
              MediaQuery.of(ctx).orientation == Orientation.landscape;

          return Padding(
            padding:
                EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
            child: SingleChildScrollView(
              child: isLandscapeMode
                  ? _buildCompactStockRow(
                      ctx,
                      setSt,
                      nameCtrl,
                      qtyCtrl,
                      beliCtrl,
                      tanggalMasuk,
                      tanggalKedaluwarsa,
                      pakaiKedaluwarsa,
                      (v) => tanggalMasuk = v,
                      (v) => tanggalKedaluwarsa = v,
                      (v) => pakaiKedaluwarsa = v)
                  : _buildStandardStockColumn(
                      ctx,
                      setSt,
                      nameCtrl,
                      qtyCtrl,
                      beliCtrl,
                      tanggalMasuk,
                      tanggalKedaluwarsa,
                      pakaiKedaluwarsa,
                      (v) => tanggalMasuk = v,
                      (v) => tanggalKedaluwarsa = v,
                      (v) => pakaiKedaluwarsa = v),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCompactStockRow(
      BuildContext ctx,
      StateSetter setSt,
      TextEditingController nameCtrl,
      TextEditingController qtyCtrl,
      TextEditingController beliCtrl,
      DateTime tanggalMasuk,
      DateTime tanggalKedaluwarsa,
      bool pakaiKedaluwarsa,
      Function(DateTime) onMasukChanged,
      Function(DateTime) onExpChanged,
      Function(bool) onExpToggle) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 800),
      padding: const EdgeInsets.all(24),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Left Side: Illustration & Branding
          Expanded(
            flex: 2,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: const BoxDecoration(
                    color: Color(0xFFF9F0EE),
                    borderRadius: BorderRadius.zero,
                  ),
                  child: SizedBox(
                    width: 140,
                    height: 100,
                    child: CustomPaint(painter: _WorkerBoxPainter()),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  _stockSheetTitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: Colors.black87),
                ),
                const SizedBox(height: 8),
                Text(
                  _stockSheetSubtitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12, color: Colors.black45),
                ),
              ],
            ),
          ),
          const SizedBox(width: 32),
          // Right Side: Form
          Expanded(
            flex: 3,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Expanded(
                      child: _FormField(
                          label: 'Kode Batch Otomatis',
                          child: TextField(
                              controller: nameCtrl,
                              style: const TextStyle(fontSize: 13),
                              decoration:
                                  _inputDec('Terisi otomatis, bisa diganti')))),
                  const SizedBox(width: 12),
                  Expanded(
                      child: _FormField(
                          label: 'Jumlah Masuk',
                          required: true,
                          child: TextField(
                              controller: qtyCtrl,
                              keyboardType: TextInputType.number,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly
                              ],
                              onChanged: (_) => setSt(() {}),
                              style: const TextStyle(fontSize: 13),
                              decoration: _inputDec('0')
                                  .copyWith(suffixText: _unitLabel)))),
                ]),
                const SizedBox(height: 16),
                Row(children: [
                  Expanded(
                      child: _FormField(
                          label: 'Harga Modal / $_unitLabel',
                          required: true,
                          child: TextField(
                              controller: beliCtrl,
                              keyboardType: TextInputType.number,
                              inputFormatters: const [CurrencyInputFormatter()],
                              onChanged: (_) => setSt(() {}),
                              style: const TextStyle(fontSize: 13),
                              decoration:
                                  _inputDec('0').copyWith(prefixText: 'Rp ')))),
                  const SizedBox(width: 12),
                  Expanded(
                      child: _FormField(
                          label: 'Tanggal Masuk',
                          required: true,
                          child: GestureDetector(
                            onTap: () async {
                              final picked = await showDatePicker(
                                  context: context,
                                  initialDate: tanggalMasuk,
                                  firstDate: DateTime(2020),
                                  lastDate: DateTime(2030));
                              if (picked != null) {
                                setSt(() => onMasukChanged(picked));
                              }
                            },
                            child: Container(
                              height: 46,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: const Color(0xFFDDDDDD)),
                                  borderRadius: BorderRadius.zero),
                              child: Row(children: [
                                const Icon(Icons.calendar_today_outlined,
                                    size: 16, color: Colors.black54),
                                const SizedBox(width: 8),
                                Text(_fDate(tanggalMasuk),
                                    style: const TextStyle(fontSize: 13)),
                              ]),
                            ),
                          ))),
                ]),
                const SizedBox(height: 6),
                const Text(
                  'Harga modal ini dipakai untuk menghitung nilai stok dan estimasi keuntungan.',
                  style: TextStyle(
                      fontSize: 11, color: Color(0xFF64748B), height: 1.3),
                ),
                const SizedBox(height: 12),
                _buildStockInputSummary(qtyCtrl, beliCtrl),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: Row(
                        children: [
                          const Text('Tanggal kedaluwarsa',
                              style: TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.w600)),
                          const SizedBox(width: 8),
                          Switch(
                              value: pakaiKedaluwarsa,
                              onChanged: (v) => setSt(() => onExpToggle(v)),
                              activeThumbColor: _kBrand,
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap),
                        ],
                      ),
                    ),
                    if (pakaiKedaluwarsa)
                      Expanded(
                        flex: 2,
                        child: GestureDetector(
                          onTap: () async {
                            final picked = await showDatePicker(
                                context: context,
                                initialDate: tanggalKedaluwarsa,
                                firstDate: DateTime(2020),
                                lastDate: DateTime(2035));
                            if (picked != null) {
                              setSt(() => onExpChanged(picked));
                            }
                          },
                          child: Container(
                            height: 46,
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: const Color(0xFFDDDDDD)),
                                borderRadius: BorderRadius.zero),
                            child: Row(children: [
                              const Icon(Icons.calendar_today_outlined,
                                  size: 16, color: Colors.black54),
                              const SizedBox(width: 8),
                              Text(_fDate(tanggalKedaluwarsa),
                                  style: const TextStyle(fontSize: 13)),
                            ]),
                          ),
                        ),
                      ),
                  ],
                ),
                if (!pakaiKedaluwarsa) ...[
                  const SizedBox(height: 4),
                  const Text(
                    'Aktifkan jika barang punya masa berlaku.',
                    style: TextStyle(
                        fontSize: 11, color: Color(0xFF64748B), height: 1.3),
                  ),
                ],
                const SizedBox(height: 24),
                Row(children: [
                  Expanded(
                      child: OutlinedButton(
                          onPressed: () => Navigator.pop(ctx),
                          style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: _kBrand),
                              foregroundColor: _kBrand,
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14)),
                          child: const Text('Batal',
                              style: TextStyle(
                                  fontWeight: FontWeight.w600, fontSize: 14)))),
                  const SizedBox(width: 12),
                  Expanded(
                      child: ElevatedButton(
                          onPressed: () => _submitTambahStok(
                                ctx,
                                nameCtrl,
                                qtyCtrl,
                                beliCtrl,
                                tanggalMasuk,
                                tanggalKedaluwarsa,
                                pakaiKedaluwarsa,
                              ),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: _kBrand,
                              foregroundColor: Colors.white,
                              shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.zero),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14)),
                          child: const Text('Simpan Stok',
                              style: TextStyle(
                                  fontWeight: FontWeight.w600, fontSize: 14)))),
                ]),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStandardStockColumn(
      BuildContext ctx,
      StateSetter setSt,
      TextEditingController nameCtrl,
      TextEditingController qtyCtrl,
      TextEditingController beliCtrl,
      DateTime tanggalMasuk,
      DateTime tanggalKedaluwarsa,
      bool pakaiKedaluwarsa,
      Function(DateTime) onMasukChanged,
      Function(DateTime) onExpChanged,
      Function(bool) onExpToggle) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          color: const Color(0xFFF8FAFC),
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                color: _kBrand.withValues(alpha: 0.10),
                child: const Icon(Icons.inventory_2_outlined,
                    color: _kBrand, size: 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_stockSheetTitle,
                        style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: Colors.black87)),
                    const SizedBox(height: 3),
                    Text(_product.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF334155))),
                    const SizedBox(height: 2),
                    Text(_stockSheetSubtitle,
                        style: const TextStyle(
                            fontSize: 11.5,
                            height: 1.3,
                            color: Color(0xFF64748B))),
                  ],
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Expanded(
                    child: _FormField(
                        label: 'Kode Batch Otomatis',
                        child: TextField(
                            controller: nameCtrl,
                            style: const TextStyle(fontSize: 13),
                            decoration:
                                _inputDec('Terisi otomatis, bisa diganti')))),
                const SizedBox(width: 12),
                Expanded(
                    child: _FormField(
                        label: 'Jumlah Masuk',
                        required: true,
                        child: TextField(
                            controller: qtyCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            onChanged: (_) => setSt(() {}),
                            style: const TextStyle(fontSize: 13),
                            decoration: _inputDec('0')
                                .copyWith(suffixText: _unitLabel)))),
              ]),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                    child: _FormField(
                        label: 'Harga Modal / $_unitLabel',
                        required: true,
                        child: TextField(
                            controller: beliCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: const [CurrencyInputFormatter()],
                            onChanged: (_) => setSt(() {}),
                            style: const TextStyle(fontSize: 13),
                            decoration:
                                _inputDec('0').copyWith(prefixText: 'Rp ')))),
                const SizedBox(width: 12),
                Expanded(
                    child: _FormField(
                        label: 'Tanggal Masuk',
                        required: true,
                        child: GestureDetector(
                          onTap: () async {
                            final picked = await showDatePicker(
                                context: context,
                                initialDate: tanggalMasuk,
                                firstDate: DateTime(2020),
                                lastDate: DateTime(2030));
                            if (picked != null) {
                              setSt(() => onMasukChanged(picked));
                            }
                          },
                          child: Container(
                            height: 46,
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: const Color(0xFFDDDDDD)),
                                borderRadius: BorderRadius.zero),
                            child: Row(children: [
                              const Icon(Icons.calendar_today_outlined,
                                  size: 16, color: Colors.black54),
                              const SizedBox(width: 8),
                              Text(_fDate(tanggalMasuk),
                                  style: const TextStyle(fontSize: 13)),
                            ]),
                          ),
                        ))),
              ]),
              const SizedBox(height: 6),
              const Text(
                'Harga modal ini dipakai untuk menghitung nilai stok dan estimasi keuntungan.',
                style: TextStyle(
                    fontSize: 11, color: Color(0xFF64748B), height: 1.3),
              ),
              const SizedBox(height: 12),
              _buildStockInputSummary(qtyCtrl, beliCtrl),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Tanggal Kedaluwarsa',
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87)),
                  Switch(
                      value: pakaiKedaluwarsa,
                      onChanged: (v) => setSt(() => onExpToggle(v)),
                      activeThumbColor: _kBrand),
                ],
              ),
              if (!pakaiKedaluwarsa) ...[
                const SizedBox(height: 4),
                const Text(
                  'Aktifkan jika barang punya masa berlaku.',
                  style: TextStyle(
                      fontSize: 11, color: Color(0xFF64748B), height: 1.3),
                ),
              ],
              if (pakaiKedaluwarsa) ...[
                const SizedBox(height: 8),
                GestureDetector(
                  onTap: () async {
                    final picked = await showDatePicker(
                        context: context,
                        initialDate: tanggalKedaluwarsa,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2035));
                    if (picked != null) {
                      setSt(() => onExpChanged(picked));
                    }
                  },
                  child: Container(
                    width: double.infinity,
                    height: 48,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                        border: Border.all(color: const Color(0xFFDDDDDD)),
                        borderRadius: BorderRadius.zero),
                    child: Row(children: [
                      const Icon(Icons.calendar_today_outlined,
                          size: 16, color: Colors.black54),
                      const SizedBox(width: 10),
                      Text(_fDate(tanggalKedaluwarsa),
                          style: const TextStyle(fontSize: 13)),
                    ]),
                  ),
                ),
              ],
              const SizedBox(height: 24),
              Row(children: [
                Expanded(
                    child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: _kBrand),
                            foregroundColor: _kBrand,
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                            padding: const EdgeInsets.symmetric(vertical: 14)),
                        child: const Text('Batal',
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 14)))),
                const SizedBox(width: 12),
                Expanded(
                    child: ElevatedButton(
                        onPressed: () => _submitTambahStok(
                              ctx,
                              nameCtrl,
                              qtyCtrl,
                              beliCtrl,
                              tanggalMasuk,
                              tanggalKedaluwarsa,
                              pakaiKedaluwarsa,
                            ),
                        style: ElevatedButton.styleFrom(
                            backgroundColor: _kBrand,
                            foregroundColor: Colors.white,
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                            padding: const EdgeInsets.symmetric(vertical: 14)),
                        child: const Text('Simpan Stok',
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 14)))),
              ]),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ],
    );
  }

  InputDecoration _inputDec(String hint) => InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.black38, fontSize: 13),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        border: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: Color(0xFFDDDDDD))),
        enabledBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: Color(0xFFDDDDDD))),
        focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: _kBrand)),
      );

  @override
  Widget build(BuildContext context) {
    // Sync product with provider
    final products = ref.watch(productsProvider);
    final synced = products.where((p) => p.id == _product.id).firstOrNull;
    if (synced != null &&
        (synced.stock != _product.stock ||
            synced.hasStockManagement != _product.hasStockManagement)) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          setState(() {
            _product = synced;
            _manajemenStok = synced.hasStockManagement == 1;
          });
        }
      });
    }

    final modal = _product.buyPrice * _product.stock;
    final omzet = _product.sellPrice * _product.stock;
    final profit = omzet - modal;

    // Embedded mode (inside GudangLaporan wide panel)
    if (widget.embedded) {
      return _buildEmbeddedLayout(modal, omzet, profit);
    }

    return LayoutBuilder(builder: (ctx, _) {
      final wide = _isWide(ctx);
      return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: wide
              ? _buildWideLayout(modal, omzet, profit)
              : _buildNarrowLayout(modal, omzet, profit),
        ),
      );
    });
  }

  Widget _buildEmbeddedLayout(int modal, int omzet, int profit) {
    return Column(children: [
      // Panel header
      Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
        color: Colors.white,
        child: Row(children: [
          Container(
            width: 44,
            height: 44,
            decoration: const BoxDecoration(
                color: Color(0xFFF0F0F0), borderRadius: BorderRadius.zero),
            child: const Icon(Icons.image_not_supported_outlined,
                color: Colors.black26, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(_product.name,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87)),
                Text('${_product.unit}  |  Stok: ${_product.stock}',
                    style:
                        const TextStyle(fontSize: 12, color: Colors.black54)),
              ])),
          _TambahBtn(onTap: _showTambahStokSheet),
        ]),
      ),
      const Divider(height: 1, color: Color(0xFFEEEEEE)),

      // Content
      Expanded(
          child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _buildFinancialCards(modal, omzet, profit),
          const SizedBox(height: 20),
          _buildInfoSection(),
          const SizedBox(height: 20),
          _buildManajemenSection(),
          if (_manajemenStok) ...[
            const SizedBox(height: 16),
            _buildStockLogSection(),
          ],
        ]),
      )),
    ]);
  }

  Widget _buildWideLayout(int modal, int omzet, int profit) {
    return Column(children: [
      // Header
      Padding(
        padding: const EdgeInsets.fromLTRB(4, 12, 12, 12),
        child: Row(children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _kBrand, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          const Expanded(
              child: Text('Detail Stok',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87))),
          _TambahBtn(onTap: _showTambahStokSheet),
        ]),
      ),
      const Divider(height: 1, color: Color(0xFFEEEEEE)),

      Expanded(
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // LEFT: product info
          SizedBox(
            width: 340,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(children: [
                _buildFinancialCards(modal, omzet, profit),
                const SizedBox(height: 16),
                _buildInfoSection(),
                const SizedBox(height: 16),
                _buildUbahDetailBtn(),
              ]),
            ),
          ),
          const VerticalDivider(width: 1, color: Color(0xFFEEEEEE)),

          // RIGHT: stock management
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(children: [
                _buildManajemenSection(),
                if (_manajemenStok) ...[
                  const SizedBox(height: 16),
                  _buildStockLogSection(),
                ],
                if (!_manajemenStok) ...[
                  const SizedBox(height: 20),
                  _buildStokSaatIni(),
                ],
              ]),
            ),
          ),
        ]),
      ),
    ]);
  }

  Widget _buildNarrowLayout(int modal, int omzet, int profit) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(4, 12, 12, 12),
        child: Row(children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _kBrand, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          const Expanded(
              child: Text('Detail Stok',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87))),
        ]),
      ),
      const Divider(height: 1, color: Color(0xFFEEEEEE)),
      Expanded(
          child: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Column(children: [
              _InfoRow('Nama Produk', _product.name),
              _InfoRow(
                  'Deskripsi',
                  _product.description?.isNotEmpty == true
                      ? _product.description!
                      : '-'),
              _InfoRow('Modal per $_unitLabel',
                  _product.buyPrice > 0 ? _fRp(_product.buyPrice) : '-'),
              _InfoRow('Harga Jual',
                  _product.sellPrice > 0 ? _fRp(_product.sellPrice) : '-'),
              _InfoRow('SKU',
                  _product.sku?.isNotEmpty == true ? _product.sku! : '-'),
              _InfoRow(
                  'Stok', _product.stock > 0 ? _product.stock.toString() : '-'),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => _product.isExtra == 1
                          ? ExtraProductFormScreen(existing: _product)
                          : ProductFormScreen(existing: _product),
                    ),
                  ).then((_) {
                    final products = ref.read(productsProvider);
                    final updated =
                        products.where((p) => p.id == _product.id).firstOrNull;
                    if (updated != null && mounted) {
                      setState(() => _product = updated);
                    }
                  });
                },
                style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: _kBrand),
                    foregroundColor: _kBrand,
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.zero),
                    padding: const EdgeInsets.symmetric(vertical: 13)),
                child: const Text('Ubah Detail Produk',
                    style:
                        TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(children: [
              _InfoRow('Modal', _product.stock > 0 ? _fRp(modal) : '-'),
              _InfoRow(
                  'Estimasi Omzet', _product.stock > 0 ? _fRp(omzet) : '-'),
              _InfoRow(
                  'Estimasi Profit', _product.stock > 0 ? _fRp(profit) : '-'),
            ]),
          ),
          const SizedBox(height: 8),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          const SizedBox(height: 16),
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _buildStokSaatIni()),
          const SizedBox(height: 16),
          const Divider(height: 1, color: Color(0xFFEEEEEE)),
          const SizedBox(height: 16),
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _buildManajemenSection()),
          if (_manajemenStok)
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: _buildStockLogSection()),
          const SizedBox(height: 32),
        ]),
      )),
      if (!_manajemenStok)
        Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _showTambahStokSheet,
              style: ElevatedButton.styleFrom(
                  backgroundColor: _kBrand,
                  foregroundColor: Colors.white,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text('Tambah Stok',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
            ),
          ),
        ),
    ]);
  }

  Widget _buildFinancialCards(int modal, int omzet, int profit) {
    return Column(children: [
      Row(children: [
        Expanded(
            child: _FinCard('Modal', _product.stock > 0 ? _fRp(modal) : '-',
                Icons.payments_outlined, Colors.blue)),
        const SizedBox(width: 10),
        Expanded(
            child: _FinCard(
                'Est. Omzet',
                _product.stock > 0 ? _fRp(omzet) : '-',
                Icons.trending_up_rounded,
                _kBrand)),
      ]),
      const SizedBox(height: 10),
      _FinCard(
          'Est. Profit',
          _product.stock > 0 ? _fRp(profit) : '-',
          Icons.account_balance_wallet_outlined,
          profit >= 0 ? AppColors.success : AppColors.danger,
          full: true),
    ]);
  }

  Widget _buildInfoSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: const Color(0xFFF9F9F9),
          borderRadius: BorderRadius.zero,
          border: Border.all(color: const Color(0xFFEEEEEE))),
      child: Column(children: [
        _InfoRow('Nama Produk', _product.name),
        _InfoRow(
            'Deskripsi',
            _product.description?.isNotEmpty == true
                ? _product.description!
                : '-'),
        _InfoRow('Modal per $_unitLabel',
            _product.buyPrice > 0 ? _fRp(_product.buyPrice) : '-'),
        _InfoRow('Harga Jual',
            _product.sellPrice > 0 ? _fRp(_product.sellPrice) : '-'),
        _InfoRow('SKU', _product.sku?.isNotEmpty == true ? _product.sku! : '-'),
      ]),
    );
  }

  Widget _buildUbahDetailBtn() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => _product.isExtra == 1
                  ? ExtraProductFormScreen(existing: _product)
                  : ProductFormScreen(existing: _product),
            ),
          ).then((_) {
            final products = ref.read(productsProvider);
            final updated =
                products.where((p) => p.id == _product.id).firstOrNull;
            if (updated != null && mounted) setState(() => _product = updated);
          });
        },
        icon: const Icon(Icons.edit_outlined, size: 16),
        label: const Text('Ubah Detail Produk'),
        style: OutlinedButton.styleFrom(
            side: const BorderSide(color: _kBrand),
            foregroundColor: _kBrand,
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            padding: const EdgeInsets.symmetric(vertical: 13)),
      ),
    );
  }

  Widget _buildStokSaatIni() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Stok Saat Ini',
          style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.black87)),
      const SizedBox(height: 8),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
            color: const Color(0xFFF9F9F9),
            borderRadius: BorderRadius.zero,
            border: Border.all(color: const Color(0xFFEEEEEE))),
        child: Text(_product.stock.toString(),
            style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Colors.black87)),
      ),
    ]);
  }

  Widget _buildManajemenSection() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Manajemen Stok',
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87)),
          Switch(
              value: _manajemenStok,
              onChanged: _toggleManajemenStok,
              activeThumbColor: _kBrand),
        ],
      ),
      const SizedBox(height: 4),
      const Text(
          'Harga beli produk akan mengikuti harga beli stok pertama yang tersedia jika fitur manajemen stok diaktifkan.',
          style: TextStyle(fontSize: 12, color: Colors.black54)),
    ]);
  }

  Widget _buildStockLogSection() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Divider(height: 1, color: Color(0xFFEEEEEE)),
      const SizedBox(height: 16),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Daftar Stok',
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87)),
          GestureDetector(
            onTap: _showTambahStokSheet,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: const BoxDecoration(
                  color: _kBrand, borderRadius: BorderRadius.zero),
              child: const Row(children: [
                Icon(Icons.add, color: Colors.white, size: 16),
                SizedBox(width: 4),
                Text('Tambah',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600)),
              ]),
            ),
          ),
        ],
      ),
      const SizedBox(height: 8),
      if (_loadingLogs)
        const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator(color: _kBrand)))
      else if (_stockLogs.isEmpty)
        const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(
                child: Text('Belum ada stok',
                    style: TextStyle(color: Colors.black45, fontSize: 13))))
      else
        ...(_stockLogs.map((log) {
          final isIn = log.type == 'in';
          DateTime? dt;
          try {
            dt = DateTime.parse(log.date);
          } catch (_) {}
          final timeStr = dt != null
              ? '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}'
              : '';
          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
                color: const Color(0xFFF9F9F9),
                borderRadius: BorderRadius.zero,
                border: Border.all(color: const Color(0xFFEEEEEE))),
            child: Row(children: [
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (log.stockName?.isNotEmpty == true)
                        Text(log.stockName!,
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 13)),
                      Text(
                          '$timeStr | ${isIn ? "Penambahan Stok" : "Pengurangan Stok"}',
                          style: const TextStyle(
                              fontSize: 12, color: Colors.black54)),
                      if (log.expiryDate?.isNotEmpty == true)
                        Text('Kedaluwarsa: ${log.expiryDate}',
                            style: const TextStyle(
                                fontSize: 11, color: Colors.orange)),
                    ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                if (log.oldQty != null && log.newQty != null)
                  Text('${log.oldQty} > ${log.newQty}',
                      style:
                          const TextStyle(fontSize: 11, color: Colors.black54)),
                Text('${isIn ? '+' : '-'}${log.qty}',
                    style: TextStyle(
                        color: isIn ? Colors.green : AppColors.danger,
                        fontWeight: FontWeight.bold,
                        fontSize: 14)),
              ]),
            ]),
          );
        })),
    ]);
  }
}

class _FinCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final bool full;

  const _FinCard(this.label, this.value, this.icon, this.color,
      {this.full = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
          color: color.withValues(alpha: 0.06),
          borderRadius: BorderRadius.zero,
          border: Border.all(color: color.withValues(alpha: 0.15))),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 10),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(label,
                    style: TextStyle(
                        fontSize: 11, color: color.withValues(alpha: 0.8))),
                Text(value,
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: color),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
              ])),
        ],
      ),
    );
  }
}

class _TambahBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _TambahBtn({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: const BoxDecoration(
            color: _kBrand, borderRadius: BorderRadius.zero),
        child: const Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.add, color: Colors.white, size: 16),
          SizedBox(width: 4),
          Text('Tambah Stok',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}

class _StockSummaryTile extends StatelessWidget {
  final String label;
  final String value;
  final bool highlight;

  const _StockSummaryTile({
    required this.label,
    required this.value,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = highlight ? _kBrand : const Color(0xFF0F172A);
    return Container(
      constraints: const BoxConstraints(minHeight: 54),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.zero,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 10.5,
              color: Color(0xFF64748B),
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12.5,
              color: color,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(fontSize: 13.5, color: Colors.black54)),
          const SizedBox(width: 16),
          Flexible(
              child: Text(value,
                  textAlign: TextAlign.end,
                  style: const TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87))),
        ],
      ),
    );
  }
}

class _FormField extends StatelessWidget {
  final String label;
  final bool required;
  final Widget child;
  const _FormField(
      {required this.label, this.required = false, required this.child});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Text(label,
            style: const TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
                color: Colors.black87)),
        if (required)
          const Text(' *',
              style: TextStyle(color: _kBrand, fontWeight: FontWeight.bold)),
      ]),
      const SizedBox(height: 6),
      child,
    ]);
  }
}

class _WorkerBoxPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final bgPaint = Paint()..color = const Color(0xFFEDD5CD);
    canvas.drawCircle(Offset(w * 0.5, h * 0.55), w * 0.42, bgPaint);
    final wheelPaint = Paint()..color = const Color(0xFF5A5A5A);
    canvas.drawCircle(Offset(w * 0.62, h * 0.90), 8, wheelPaint);
    canvas.drawCircle(Offset(w * 0.78, h * 0.90), 8, wheelPaint);
    final cartPaint = Paint()..color = const Color(0xFF8A5C4A);
    canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(w * 0.38, h * 0.72, w * 0.46, 14),
            const Radius.circular(0)),
        cartPaint);
    final handlePaint = Paint()
      ..color = const Color(0xFF8A5C4A)
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    canvas.drawLine(
        Offset(w * 0.38, h * 0.79), Offset(w * 0.25, h * 0.55), handlePaint);
    final boxColors = [
      const Color(0xFF9E9E9E),
      const Color(0xFF757575),
      const Color(0xFFBDBDBD)
    ];
    canvas.drawRect(Rect.fromLTWH(w * 0.43, h * 0.48, 30, 24),
        Paint()..color = boxColors[0]);
    canvas.drawRect(Rect.fromLTWH(w * 0.43 + 32, h * 0.48, 30, 24),
        Paint()..color = boxColors[1]);
    canvas.drawRect(Rect.fromLTWH(w * 0.43 + 8, h * 0.26, 30, 22),
        Paint()..color = boxColors[2]);
    canvas.drawRect(Rect.fromLTWH(w * 0.43 + 40, h * 0.26, 28, 22),
        Paint()..color = boxColors[0]);
    final bodyPaint = Paint()..color = const Color(0xFFD32F2F);
    final headPaint = Paint()..color = const Color(0xFF4A3728);
    canvas.drawCircle(Offset(w * 0.22, h * 0.22), 11, headPaint);
    canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(w * 0.13, h * 0.35, 28, 34),
            const Radius.circular(0)),
        bodyPaint);
    canvas.drawRect(Rect.fromLTWH(w * 0.13, h * 0.66, 11, 22), bodyPaint);
    canvas.drawRect(Rect.fromLTWH(w * 0.13 + 14, h * 0.66, 11, 22), bodyPaint);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(w * 0.30, h * 0.37, 16, 9), const Radius.circular(0)),
        bodyPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

