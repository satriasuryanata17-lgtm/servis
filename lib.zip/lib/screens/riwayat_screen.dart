import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../models/db_models.dart';
import '../database/db_helper.dart';
import '../providers/providers.dart';
import '../services/export_service.dart';
import 'struk_screen.dart';
import 'detail_transaksi_piutang_screen.dart';
import 'riwayat_pesanan_terhapus_screen.dart';
import 'responsive_layout.dart';
import '../widgets/kasir_dialog.dart';
import '../core/theme.dart';
import 'main_shell.dart';
import '../utils/transaction_code_formatter.dart';
import '../services/whatsapp_helper.dart';

// (Providers moved to providers.dart)

// CONSTANTS
const _kBrand = AppColors.primaryBrand;
const _kPeriodHarian = 'daily';
const _kPeriodBulanan = 'monthly';
const _kPeriodTahunan = 'yearly';
const _kPeriodKustom = 'custom';

// FORMAT HELPERS
String _fmtRp(int n) {
  if (n == 0) {
    return '0';
  }
  final s = n.toString();
  final buf = StringBuffer();
  int c = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    buf.write(s[i]);
    c++;
    if (c % 3 == 0 && i != 0) {
      buf.write('.');
    }
  }
  return buf.toString().split('').reversed.join();
}

String _periodLabel(String period) {
  switch (period) {
    case _kPeriodBulanan:
      return 'Periode Bulanan';
    case _kPeriodTahunan:
      return 'Periode Tahunan';
    case _kPeriodKustom:
      return 'Kustom Tanggal';
    default:
      return 'Periode Harian';
  }
}

String _dateLabel(String period, DateTime date) {
  switch (period) {
    case _kPeriodBulanan:
      return DateFormat('MMMM yyyy', 'id').format(date);
    case _kPeriodTahunan:
      return '${date.year}';
    default:
      return DateFormat('dd MMMM yyyy', 'id').format(date);
  }
}

String _formatNoTransaksi(Transaction tx) {
  return TransactionCodeFormatter.format(
    id: tx.id ?? 0,
    createdAt: tx.createdAt,
    transactionCode: tx.transactionCode,
  );
}

// PAYMENT METHOD HELPERS
String _methodLabel(String m) {
  final lower = m.toLowerCase();
  switch (lower) {
    case 'qris':
      return 'QRIS';
    case 'transfer':
      return 'Transfer';
    case 'pesanan':
    case 'buat_pesanan':
      return 'Tagihan';
    default:
      return 'Tunai';
  }
}

//  RIWAYAT SCREEN  -  Responsive (Phone + Tablet/Landscape)
class RiwayatScreen extends ConsumerStatefulWidget {
  final bool isEmbedded;
  const RiwayatScreen({super.key, this.isEmbedded = false});

  @override
  ConsumerState<RiwayatScreen> createState() => _RiwayatScreenState();
}

class _RiwayatScreenState extends ConsumerState<RiwayatScreen> {
  final _searchCtrl = TextEditingController();
  late final PageController _pageCtrl;

  @override
  void initState() {
    super.initState();
    // Use current provider state for initial page
    final initialTab = ref.read(riwayatTabProvider);
    _searchCtrl.text = ref.read(riwayatSearchProvider);
    _pageCtrl = PageController(initialPage: initialTab);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _pageCtrl.dispose();
    super.dispose();
  }

  bool _isWide(BuildContext context) =>
      MediaQuery.of(context).size.width >= 720;

  @override
  Widget build(BuildContext context) {
    // Listen for external tab changes (e.g. from Notifications)
    ref.listen<int>(riwayatTabProvider, (prev, next) {
      if (_pageCtrl.hasClients && _pageCtrl.page?.round() != next) {
        _pageCtrl.jumpToPage(next);
      }
    });

    final tab = ref.watch(riwayatTabProvider);
    final wide = _isWide(context);

    final content = wide
        ? _buildWideLayout(tab)
        : Column(
            children: [
              _buildMobileHeader(),
              _buildTabBar(tab),
              const Divider(height: 1, color: Color(0xFFEEEEEE)),
              Expanded(
                child: PageView(
                  controller: _pageCtrl,
                  onPageChanged: (i) =>
                      ref.read(riwayatTabProvider.notifier).set(i),
                  children: [
                    _buildLunasContent(false),
                    _buildBelumLunasContent(false),
                  ],
                ),
              ),
            ],
          );

    if (widget.isEmbedded) return content;

    if (wide) {
      return KasirResponsiveScaffold(
        title: 'Riwayat & Tagihan',
        navIndex: 4,
        showNavRail: false,
        showAppBar: true,
        actions: [
          _buildSearchBox(wide),
          const SizedBox(width: 8),
          _buildArchiveBtn(),
          const SizedBox(width: 16),
        ],
        body: content,
      );
    }

    //  MOBILE LAYOUT
    return KasirResponsiveScaffold(
      title: 'Riwayat & Tagihan',
      navIndex: 4,
      showNavRail: false,
      showAppBar: false,
      body: content,
    );
  }

  Widget _buildSearchBox(bool wide) {
    final search = ref.watch(riwayatSearchProvider);
    final hasQuery = search.trim().isNotEmpty;
    return SizedBox(
      width: wide ? 320 : double.infinity,
      height: 38,
      child: TextField(
        controller: _searchCtrl,
        onChanged: (v) => ref.read(riwayatSearchProvider.notifier).set(v),
        style: const TextStyle(
          fontSize: 12.5,
          fontWeight: FontWeight.w700,
          color: Color(0xFF1E293B),
        ),
        decoration: InputDecoration(
          hintText: 'Cari Pelanggan / No. Transaksi...',
          hintStyle: const TextStyle(
            color: Color(0xFF94A3B8),
            fontSize: 11.5,
            fontWeight: FontWeight.w600,
          ),
          prefixIcon: const Icon(
            Icons.search_rounded,
            color: Color(0xFF64748B),
            size: 18,
          ),
          suffixIcon: !hasQuery
              ? null
              : IconButton(
                  tooltip: 'Hapus pencarian',
                  padding: EdgeInsets.zero,
                  icon: const Icon(Icons.close_rounded,
                      size: 18, color: Color(0xFF94A3B8)),
                  onPressed: () {
                    _searchCtrl.clear();
                    ref.read(riwayatSearchProvider.notifier).set('');
                  },
                ),
          prefixIconConstraints:
              const BoxConstraints(minWidth: 40, minHeight: 38),
          suffixIconConstraints:
              const BoxConstraints(minWidth: 36, minHeight: 38),
          filled: true,
          fillColor: const Color(0xFFF3F6FA),
          contentPadding: EdgeInsets.zero,
          border: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide.none,
          ),
          focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(color: _kBrand, width: 1.2),
          ),
        ),
      ),
    );
  }

  Widget _buildArchiveBtn() {
    return SizedBox(
      width: 42,
      height: 38,
      child: IconButton(
        padding: EdgeInsets.zero,
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => const RiwayatPesananTerhapusScreen()),
        ),
        icon: const Icon(Icons.inventory_2_outlined, color: Colors.black87),
        tooltip: 'Riwayat Pesanan Terhapus',
      ),
    );
  }

  Widget _buildMobileHeader() {
    return Container(
      color: Colors.white,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
          child: Row(
            children: [
              SizedBox(
                width: 42,
                height: 38,
                child: IconButton(
                  padding: EdgeInsets.zero,
                  icon: Icon(
                    (ShellScope.of(context) != null)
                        ? Icons.menu
                        : Icons.arrow_back_ios_new_rounded,
                    color: Colors.black87,
                    size: 20,
                  ),
                  onPressed: () {
                    final shell = ShellScope.of(context);
                    if (shell != null) {
                      shell.openDrawer?.call();
                    } else if (Navigator.canPop(context)) {
                      Navigator.pop(context);
                    }
                  },
                ),
              ),
              Expanded(child: _buildSearchBox(false)),
              const SizedBox(width: 8),
              _buildArchiveBtn(),
              const SizedBox(width: 8),
              SizedBox(
                width: 42,
                height: 38,
                child: IconButton(
                  padding: EdgeInsets.zero,
                  onPressed: _exportLunasTransactions,
                  icon: const Icon(Icons.file_download_outlined,
                      color: Colors.black87),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWideLayout(int tab) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        //  SIDEBAR (Filters & Controls)
        Container(
          width: 320,
          decoration: const BoxDecoration(
            color: Colors.white,
            border: Border(right: BorderSide(color: Color(0xFFEEEEEE))),
          ),
          child: Column(
            children: [
              // 1. Status Switcher (Lunas / Piutang)
              _buildStatusSwitcher(tab),
              const Divider(height: 1, color: Color(0xFFEEEEEE)),

              // 2. Filters Area
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (tab == 0) ..._buildLunasSidebarControls(),
                      if (tab == 1) ..._buildPiutangSidebarControls(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),

        //  MAIN AREA (List Content)
        Expanded(
          child: tab == 0 ? _buildLunasListArea() : _buildPiutangListArea(),
        ),
      ],
    );
  }

  Widget _buildStatusSwitcher(int currentTab) {
    final piutangCount = ref.watch(piutangTransactionsProvider).maybeWhen(
          data: (list) => list.length,
          orElse: () => 0,
        );

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      child: Row(
        children: [
          _buildStatusBtn('Riwayat Lunas', currentTab == 0,
              () => ref.read(riwayatTabProvider.notifier).set(0)),
          const SizedBox(width: 8),
          _buildStatusBtn(
            'Belum Lunas',
            currentTab == 1,
            () => ref.read(riwayatTabProvider.notifier).set(1),
            badgeCount: piutangCount,
          ),
        ],
      ),
    );
  }

  Widget _buildStatusBtn(String label, bool active, VoidCallback onTap,
      {int badgeCount = 0}) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
          height: 40,
          decoration: BoxDecoration(
            color: active ? _kBrand : Colors.white,
            borderRadius: BorderRadius.zero,
            border:
                Border.all(color: active ? _kBrand : const Color(0xFFE2E8F0)),
          ),
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.center,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: active ? Colors.white : Colors.black54,
                ),
              ),
              if (badgeCount > 0)
                Positioned(
                  top: -6,
                  right: -6,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 18,
                      minHeight: 18,
                    ),
                    child: Text(
                      '$badgeCount',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildLunasSidebarControls() {
    final period = ref.watch(riwayatPeriodTypeProvider);
    final date = ref.watch(riwayatSelectedDateProvider);
    final summaryAsync = ref.watch(lunasSummaryProvider);

    return [
      const Padding(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Text('FILTER PERIODE',
            style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: Colors.black38,
                letterSpacing: 1.1)),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            _DropdownPill(
                label: _periodLabel(period),
                onTap: () => _showPeriodPicker(period)),
            const SizedBox(height: 10),
            _DropdownPill(
                label: _dateLabel(period, date),
                onTap: () => _handleDateTap(period, date)),
          ],
        ),
      ),
      const SizedBox(height: 16),
      const Divider(height: 1, color: Color(0xFFEEEEEE)),
      summaryAsync.when(
        skipLoadingOnRefresh: true,
        skipLoadingOnReload: true,
        data: (s) => _LunasSummary(summary: s, period: period, date: date),
        loading: () => const Center(
            child: Padding(
                padding: EdgeInsets.all(20),
                child: CircularProgressIndicator(strokeWidth: 2))),
        error: (_, __) => const SizedBox(),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: OutlinedButton.icon(
          onPressed: _exportLunasTransactions,
          icon: const Icon(Icons.download_outlined, size: 16),
          label: const Text('Ekspor (.xlsx)', style: TextStyle(fontSize: 12)),
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: _kBrand),
            foregroundColor: _kBrand,
            minimumSize: const Size(double.infinity, 44),
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          ),
        ),
      ),
    ];
  }

  List<Widget> _buildPiutangSidebarControls() {
    final period = ref.watch(riwayatPeriodTypeProvider);
    final date = ref.watch(riwayatSelectedDateProvider);
    final summaryAsync = ref.watch(piutangSummaryProvider);

    return [
      const Padding(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Text('FILTER PERIODE',
            style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: Colors.black38,
                letterSpacing: 1.1)),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            _DropdownPill(
                label: _periodLabel(period),
                onTap: () => _showPeriodPicker(period)),
            const SizedBox(height: 10),
            _DropdownPill(
                label: _dateLabel(period, date),
                onTap: () => _handleDateTap(period, date)),
          ],
        ),
      ),
      const SizedBox(height: 16),
      const Divider(height: 1, color: Color(0xFFEEEEEE)),
      summaryAsync.when(
        skipLoadingOnRefresh: true,
        skipLoadingOnReload: true,
        data: (s) => _BelumLunasSummary(summary: s, period: period, date: date),
        loading: () => const Center(
            child: Padding(
                padding: EdgeInsets.all(20),
                child: CircularProgressIndicator(strokeWidth: 2))),
        error: (_, __) => const SizedBox(),
      ),
    ];
  }

  Widget _buildLunasListArea() {
    final transactionsAsync = ref.watch(lunasTransactionsProvider);
    final search = ref.watch(riwayatSearchProvider);
    final period = ref.watch(riwayatPeriodTypeProvider);

    return transactionsAsync.when(
      skipLoadingOnRefresh: true,
      skipLoadingOnReload: true,
      data: (list) {
        final filtered = _applySearch(list, search);
        if (filtered.isEmpty) {
          return _EmptyState(
              subtitle: 'Belum ada transaksi di ${_periodLabel(period)}');
        }
        return _TransactionList(transactions: filtered);
      },
      loading: () =>
          const Center(child: CircularProgressIndicator(color: _kBrand)),
      error: (_, __) => const _EmptyState(subtitle: 'Gagal memuat transaksi'),
    );
  }

  Widget _buildPiutangListArea() {
    final transactionsAsync = ref.watch(piutangTransactionsProvider);
    final search = ref.watch(riwayatSearchProvider);
    final period = ref.watch(riwayatPeriodTypeProvider);

    return transactionsAsync.when(
      skipLoadingOnRefresh: true,
      skipLoadingOnReload: true,
      data: (list) {
        final filtered = _applySearch(list, search);
        if (filtered.isEmpty) {
          return _EmptyState(
              subtitle: 'Belum ada transaksi di ${_periodLabel(period)}');
        }
        return _TransactionList(transactions: filtered);
      },
      loading: () =>
          const Center(child: CircularProgressIndicator(color: _kBrand)),
      error: (_, __) => const _EmptyState(),
    );
  }

  Widget _buildTabBar(int tab) {
    final piutangCount = ref.watch(piutangTransactionsProvider).maybeWhen(
          data: (list) => list.length,
          orElse: () => 0,
        );

    return Row(
      children: [
        _TabItem(
          label: 'Lunas',
          selected: tab == 0,
          onTap: () => ref.read(riwayatTabProvider.notifier).set(0),
        ),
        _TabItem(
          label: 'Belum Lunas',
          selected: tab == 1,
          onTap: () => ref.read(riwayatTabProvider.notifier).set(1),
          badgeCount: piutangCount,
        ),
      ],
    );
  }

  //  LUNAS CONTENT (LEGACY SUPPORT FOR MOBILE)
  Widget _buildLunasContent(bool wide) {
    if (wide) {
      return const SizedBox(); // Use _buildWideLayout
    }

    final period = ref.watch(riwayatPeriodTypeProvider);
    final date = ref.watch(riwayatSelectedDateProvider);
    final summaryAsync = ref.watch(lunasSummaryProvider);
    final transactionsAsync = ref.watch(lunasTransactionsProvider);
    final search = ref.watch(riwayatSearchProvider);

    return Column(
      children: [
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          child: Row(
            children: [
              Expanded(
                  child: _DropdownPill(
                      label: _periodLabel(period),
                      onTap: () => _showPeriodPicker(period))),
              const SizedBox(width: 12),
              Expanded(
                  child: _DropdownPill(
                      label: _dateLabel(period, date),
                      onTap: () => _handleDateTap(period, date))),
            ],
          ),
        ),
        const Divider(height: 1, color: Color(0xFFEEEEEE)),
        summaryAsync.when(
          skipLoadingOnRefresh: true,
          skipLoadingOnReload: true,
          data: (s) => _LunasSummary(summary: s, period: period, date: date),
          loading: () => const Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Center(
                  child: CircularProgressIndicator(
                      color: _kBrand, strokeWidth: 2))),
          error: (_, __) => const SizedBox(height: 80),
        ),
        Expanded(
          child: transactionsAsync.when(
            skipLoadingOnRefresh: true,
            skipLoadingOnReload: true,
            data: (list) {
              final filtered = _applySearch(list, search);
              if (filtered.isEmpty) {
                return _EmptyState(
                    subtitle: 'Belum ada transaksi di ${_periodLabel(period)}');
              }
              return _TransactionList(transactions: filtered);
            },
            loading: () =>
                const Center(child: CircularProgressIndicator(color: _kBrand)),
            error: (_, __) =>
                const _EmptyState(subtitle: 'Gagal memuat transaksi'),
          ),
        ),
      ],
    );
  }

  //  BELUM LUNAS CONTENT (LEGACY SUPPORT FOR MOBILE)
  Widget _buildBelumLunasContent(bool wide) {
    if (wide) {
      return const SizedBox();
    }

    final period = ref.watch(riwayatPeriodTypeProvider);
    final date = ref.watch(riwayatSelectedDateProvider);
    final summaryAsync = ref.watch(piutangSummaryProvider);
    final transactionsAsync = ref.watch(piutangTransactionsProvider);
    final search = ref.watch(riwayatSearchProvider);

    return Column(
      children: [
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          child: Row(
            children: [
              Expanded(
                  child: _DropdownPill(
                      label: _periodLabel(period),
                      onTap: () => _showPeriodPicker(period))),
              const SizedBox(width: 12),
              Expanded(
                  child: _DropdownPill(
                      label: _dateLabel(period, date),
                      onTap: () => _handleDateTap(period, date))),
            ],
          ),
        ),
        const Divider(height: 1, color: Color(0xFFEEEEEE)),
        summaryAsync.when(
          skipLoadingOnRefresh: true,
          skipLoadingOnReload: true,
          data: (s) =>
              _BelumLunasSummary(summary: s, period: period, date: date),
          loading: () => const Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Center(
                  child: CircularProgressIndicator(
                      color: _kBrand, strokeWidth: 2))),
          error: (_, __) => const SizedBox(height: 80),
        ),
        const Divider(height: 1, color: Color(0xFFEEEEEE)),
        Expanded(
          child: transactionsAsync.when(
            skipLoadingOnRefresh: true,
            skipLoadingOnReload: true,
            data: (list) {
              final filtered = _applySearch(list, search);
              if (filtered.isEmpty) {
                return _EmptyState(
                    subtitle: 'Belum ada transaksi di ${_periodLabel(period)}');
              }
              return _TransactionList(transactions: filtered);
            },
            loading: () =>
                const Center(child: CircularProgressIndicator(color: _kBrand)),
            error: (_, __) => const _EmptyState(),
          ),
        ),
      ],
    );
  }

  void _showPeriodPicker(String current) {
    String selected = current;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.zero)),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setLocal) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(height: 8),
                _PeriodOption(
                    label: 'Periode Harian',
                    selected: selected == _kPeriodHarian,
                    onTap: () => setLocal(() => selected = _kPeriodHarian)),
                _PeriodOption(
                    label: 'Periode Bulanan',
                    selected: selected == _kPeriodBulanan,
                    onTap: () => setLocal(() => selected = _kPeriodBulanan)),
                _PeriodOption(
                    label: 'Periode Tahunan',
                    selected: selected == _kPeriodTahunan,
                    onTap: () => setLocal(() => selected = _kPeriodTahunan)),
                _PeriodOption(
                    label: 'Kustom Tanggal',
                    selected: selected == _kPeriodKustom,
                    onTap: () => setLocal(() => selected = _kPeriodKustom)),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
                  child: Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(ctx),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: _kBrand),
                            foregroundColor: _kBrand,
                            minimumSize: const Size(0, 48),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                          ),
                          child: const Text('Batal'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            ref
                                .read(riwayatPeriodTypeProvider.notifier)
                                .set(selected);
                            Navigator.pop(ctx);
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _kBrand,
                            foregroundColor: Colors.white,
                            minimumSize: const Size(0, 48),
                            elevation: 0,
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                          ),
                          child: const Text('Pilih'),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _handleDateTap(String period, DateTime current) {
    switch (period) {
      case _kPeriodHarian:
        _pickDay(current);
        break;
      case _kPeriodBulanan:
        _pickMonth(current);
        break;
      case _kPeriodTahunan:
        _pickYear(current);
        break;
      default:
        _pickDay(current);
    }
  }

  void _pickDay(DateTime current) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: current,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx)
            .copyWith(colorScheme: const ColorScheme.light(primary: _kBrand)),
        child: child!,
      ),
    );
    if (picked != null && mounted) {
      ref.read(riwayatSelectedDateProvider.notifier).set(picked);
    }
  }

  void _pickMonth(DateTime current) async {
    int year = current.year;
    int month = current.month;
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'Mei',
      'Jun',
      'Jul',
      'Agu',
      'Sep',
      'Okt',
      'Nov',
      'Des'
    ];

    await showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setLocal) {
          return Dialog(
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            backgroundColor: Colors.white,
            elevation: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                          icon: const Icon(Icons.chevron_left_rounded,
                              color: _kBrand),
                          onPressed: () => setLocal(() => year--)),
                      Text('$year',
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: Colors.black87)),
                      IconButton(
                          icon: const Icon(Icons.chevron_right_rounded,
                              color: _kBrand),
                          onPressed: () => setLocal(() {
                                if (year < DateTime.now().year) {
                                  year++;
                                }
                              })),
                    ],
                  ),
                  const SizedBox(height: 16),
                  GridView.count(
                    crossAxisCount: 4,
                    shrinkWrap: true,
                    mainAxisSpacing: 8,
                    crossAxisSpacing: 8,
                    children: List.generate(12, (i) {
                      final isSelected = month == i + 1;
                      return GestureDetector(
                        onTap: () => setLocal(() => month = i + 1),
                        child: Container(
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color:
                                isSelected ? _kBrand : const Color(0xFFF7F9FB),
                            borderRadius: BorderRadius.zero,
                          ),
                          child: Text(
                            months[i],
                            style: TextStyle(
                              color: isSelected ? Colors.white : Colors.black87,
                              fontWeight: isSelected
                                  ? FontWeight.bold
                                  : FontWeight.w600,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                          ),
                          child: Text('Batal',
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.grey.shade500)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            ref
                                .read(riwayatSelectedDateProvider.notifier)
                                .set(DateTime(year, month));
                            Navigator.pop(ctx);
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _kBrand,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                          ),
                          child: const Text('Pilih',
                              style: TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        });
      },
    );
  }

  void _pickYear(DateTime current) async {
    int year = current.year;
    final now = DateTime.now().year;
    final years = List.generate(10, (i) => now - i);

    await showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setLocal) {
          return Dialog(
            shape:
                const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            backgroundColor: Colors.white,
            elevation: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Pilih Tahun',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: Colors.black87)),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: years.map((y) {
                        final isSelected = year == y;
                        return GestureDetector(
                          onTap: () => setLocal(() => year = y),
                          child: IntrinsicWidth(
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 8),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? _kBrand
                                    : const Color(0xFFF7F9FB),
                                borderRadius: BorderRadius.zero,
                              ),
                              child: Text('$y',
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white
                                        : Colors.black87,
                                    fontWeight: isSelected
                                        ? FontWeight.bold
                                        : FontWeight.w600,
                                  )),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                          ),
                          child: Text('Batal',
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.grey.shade500)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            ref
                                .read(riwayatSelectedDateProvider.notifier)
                                .set(DateTime(year));
                            Navigator.pop(ctx);
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _kBrand,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.zero),
                          ),
                          child: const Text('Pilih',
                              style: TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        });
      },
    );
  }

  Future<void> _exportLunasTransactions() async {
    final period = ref.read(riwayatPeriodTypeProvider);
    final date = ref.read(riwayatSelectedDateProvider);
    final query = ref.read(riwayatSearchProvider);

    try {
      final list = await ref.read(lunasTransactionsProvider.future);
      final filtered = _applySearch(list, query);
      if (filtered.isEmpty) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Belum ada data lunas untuk diekspor.'),
              backgroundColor: Colors.black87,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)),
        );
        return;
      }

      final rows = filtered.map((tx) {
        final dt = DateTime.tryParse(tx.createdAt);
        final dateLabel = dt != null
            ? DateFormat('dd-MM-yyyy HH:mm', 'id').format(dt)
            : tx.createdAt;
        return <Object?>[
          tx.id,
          dateLabel,
          tx.customerName ?? 'Pelanggan Umum',
          _methodLabel(tx.paymentMethod),
          tx.totalAmount,
          tx.discountAmount,
          tx.grandTotal,
          tx.amountPaid,
          tx.changeAmount,
          tx.note ?? '',
        ];
      }).toList();

      await ExportService.exportAndShareCsv(
        filePrefix: 'riwayat_lunas_${_periodLabel(period).toLowerCase()}',
        headers: const [
          'ID',
          'Tanggal',
          'Pelanggan',
          'Metode Bayar',
          'Total',
          'Diskon',
          'Grand Total',
          'Dibayar',
          'Kembalian',
          'Catatan',
        ],
        rows: rows,
        subject: 'Ekspor Riwayat Servis Lunas',
        message: 'Periode: ${_dateLabel(period, date)}',
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Gagal mengekspor riwayat. Silakan coba lagi.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero)));
    }
  }

  List<Transaction> _applySearch(List<Transaction> list, String query) {
    if (query.isEmpty) {
      return list;
    }
    final q = query.toLowerCase();
    return list.where((t) {
      final noTransaksi = _formatNoTransaksi(t).toLowerCase();
      return t.id.toString().contains(q) ||
          noTransaksi.contains(q) ||
          (t.customerName?.toLowerCase().contains(q) ?? false);
    }).toList();
  }
}

// LUNAS SUMMARY WIDGET
class _LunasSummary extends StatefulWidget {
  final Map<String, int> summary;
  final String period;
  final DateTime date;
  const _LunasSummary(
      {required this.summary, required this.period, required this.date});

  @override
  State<_LunasSummary> createState() => _LunasSummaryState();
}

class _LunasSummaryState extends State<_LunasSummary> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    return _SummaryDropdown(
      title: 'Omzet periode ini',
      subtitle: _dateLabel(widget.period, widget.date),
      badgeLabel: 'Lunas',
      badgeIcon: Icons.trending_up_rounded,
      primaryLabel: 'Omzet',
      primaryValue: 'Rp${_fmtRp(widget.summary['omzet'] ?? 0)}',
      expanded: _expanded,
      onToggle: () => setState(() => _expanded = !_expanded),
      metrics: [
        _SummaryMetricData(
            'Jumlah transaksi', '${widget.summary['count'] ?? 0} tx'),
        _SummaryMetricData('Total item', '${widget.summary['products'] ?? 0}'),
      ],
    );
  }
}

// BELUM LUNAS SUMMARY WIDGET
class _BelumLunasSummary extends StatefulWidget {
  final Map<String, int> summary;
  final String period;
  final DateTime date;
  const _BelumLunasSummary(
      {required this.summary, required this.period, required this.date});

  @override
  State<_BelumLunasSummary> createState() => _BelumLunasSummaryState();
}

class _BelumLunasSummaryState extends State<_BelumLunasSummary> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    return _SummaryDropdown(
      title: 'Belum lunas periode ini',
      subtitle: _dateLabel(widget.period, widget.date),
      badgeLabel: 'Belum Lunas',
      badgeIcon: Icons.schedule_rounded,
      primaryLabel: 'Sisa tagihan',
      primaryValue: 'Rp${_fmtRp(widget.summary['sisa_piutang'] ?? 0)}',
      expanded: _expanded,
      onToggle: () => setState(() => _expanded = !_expanded),
      metrics: [
        _SummaryMetricData('Total tagihan',
            'Rp${_fmtRp(widget.summary['total_piutang'] ?? 0)}'),
        _SummaryMetricData(
            'Terbayar', 'Rp${_fmtRp(widget.summary['total_terbayar'] ?? 0)}'),
        _SummaryMetricData(
            'Jumlah transaksi', '${widget.summary['count'] ?? 0} tx'),
        _SummaryMetricData('Total item', '${widget.summary['products'] ?? 0}'),
      ],
    );
  }
}

class _SummaryMetricData {
  final String label;
  final String value;

  const _SummaryMetricData(this.label, this.value);
}

class _SummaryDropdown extends StatelessWidget {
  final String title;
  final String subtitle;
  final String badgeLabel;
  final IconData badgeIcon;
  final String primaryLabel;
  final String primaryValue;
  final bool expanded;
  final VoidCallback onToggle;
  final List<_SummaryMetricData> metrics;

  const _SummaryDropdown({
    required this.title,
    required this.subtitle,
    required this.badgeLabel,
    required this.badgeIcon,
    required this.primaryLabel,
    required this.primaryValue,
    required this.expanded,
    required this.onToggle,
    required this.metrics,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Material(
        color: AppColors.primaryBrand,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.20),
            ),
          ),
          child: Column(
            children: [
              InkWell(
                onTap: onToggle,
                borderRadius: BorderRadius.circular(8),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Row(
                    children: [
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.14),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.16),
                          ),
                        ),
                        child: Icon(badgeIcon, size: 17, color: Colors.white),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 2),
                            Text(
                              subtitle,
                              style: const TextStyle(
                                fontSize: 10,
                                color: Colors.white70,
                                fontWeight: FontWeight.w600,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 112),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              primaryValue,
                              style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              primaryLabel,
                              style: const TextStyle(
                                fontSize: 9,
                                color: Colors.white70,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 6),
                      Icon(
                        expanded
                            ? Icons.keyboard_arrow_up_rounded
                            : Icons.keyboard_arrow_down_rounded,
                        size: 20,
                        color: Colors.white70,
                      ),
                    ],
                  ),
                ),
              ),
              if (expanded) ...[
                Divider(
                  height: 1,
                  color: Colors.white.withValues(alpha: 0.16),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _SummaryStatusChip(
                        label: badgeLabel,
                        icon: badgeIcon,
                      ),
                      const SizedBox(height: 10),
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final itemWidth = (constraints.maxWidth - 8) / 2;
                          return Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: metrics
                                .map(
                                  (m) => SizedBox(
                                    width: itemWidth,
                                    child: _SummaryMetric(metric: m),
                                  ),
                                )
                                .toList(),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _SummaryStatusChip extends StatelessWidget {
  final String label;
  final IconData icon;

  const _SummaryStatusChip({required this.label, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: Colors.white.withValues(alpha: 0.16)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: Colors.white),
          const SizedBox(width: 5),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryMetric extends StatelessWidget {
  final _SummaryMetricData metric;

  const _SummaryMetric({required this.metric});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.14),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            metric.label,
            style: const TextStyle(
              fontSize: 10,
              color: Colors.white70,
              fontWeight: FontWeight.w600,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 3),
          Text(
            metric.value,
            style: const TextStyle(
              fontSize: 12,
              color: Colors.white,
              fontWeight: FontWeight.w900,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// TRANSACTION LIST
class _TransactionList extends ConsumerWidget {
  final List<Transaction> transactions;
  const _TransactionList({required this.transactions});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 90),
      itemCount: transactions.length,
      separatorBuilder: (_, __) => const SizedBox(height: 6),
      itemBuilder: (ctx, i) {
        final tx = transactions[i];
        final dt = DateTime.tryParse(tx.createdAt);
        final timeLabel =
            dt != null ? DateFormat('HH:mm', 'id').format(dt) : '';
        final dateLabel =
            dt != null ? DateFormat('dd MMM', 'id').format(dt) : tx.createdAt;
        final isUnpaid = tx.amountPaid < tx.grandTotal;
        final customerName = tx.customerName?.isNotEmpty == true
            ? tx.customerName!
            : 'Pelanggan Umum';
        final details = [
          '$dateLabel - $timeLabel',
          _formatNoTransaksi(tx),
          if (tx.address != null && tx.address!.trim().isNotEmpty)
            tx.address!.trim(),
        ].join('  |  ');

        return Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.zero,
            onTap: () => Navigator.push(
              ctx,
              MaterialPageRoute(
                builder: (_) => isUnpaid
                    ? DetailTransaksiPiutangScreen(transactionId: tx.id!)
                    : StrukScreen(transactionId: tx.id!),
              ),
            ),
            onLongPress: () => _confirmDelete(ctx, ref, tx.id!),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: const Color(0xFFE2E8F0)),
                borderRadius: BorderRadius.zero,
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _PaymentThumb(method: tx.paymentMethod, isUnpaid: isUnpaid),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                customerName,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14,
                                  color: Color(0xFF0F172A),
                                  letterSpacing: 0,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            const SizedBox(width: 8),
                            ConstrainedBox(
                              constraints: const BoxConstraints(maxWidth: 102),
                              child: FittedBox(
                                fit: BoxFit.scaleDown,
                                alignment: Alignment.centerRight,
                                child: Text(
                                  'Rp${_fmtRp(tx.grandTotal)}',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 14,
                                    color: isUnpaid
                                        ? AppColors.danger
                                        : const Color(0xFF0F172A),
                                    letterSpacing: 0,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Icon(Icons.chevron_right_rounded,
                                size: 17, color: Color(0xFFCBD5E1)),
                            const SizedBox(width: 4),
                            _DeleteTransactionButton(
                              onPressed: tx.id == null
                                  ? null
                                  : () => _confirmDelete(ctx, ref, tx.id!),
                            ),
                          ],
                        ),
                        const SizedBox(height: 2),
                        Text(
                          details,
                          style: const TextStyle(
                            fontSize: 10.5,
                            color: Color(0xFF64748B),
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Wrap(
                          spacing: 5,
                          runSpacing: 3,
                          children: [
                            _servisStatusPill(
                              status: tx.servisStatus,
                              kelengkapan: tx.kelengkapan,
                              onTap: () =>
                                  _showservisStatusUpdateDialog(ctx, ref, tx),
                            ),
                            if (tx.orderType != null &&
                                tx.orderType!.trim().isNotEmpty)
                              _HistoryPill(
                                icon: Icons.local_shipping_outlined,
                                label: _orderTypeLabel(tx.orderType),
                                foreground: _kBrand,
                                background: const Color(0xFFEFF6FF),
                                border: const Color(0xFFBFDBFE),
                              ),
                            _HistoryPill(
                              icon: isUnpaid
                                  ? Icons.schedule_rounded
                                  : Icons.check_circle_rounded,
                              label: isUnpaid
                                  ? 'Belum lunas'
                                  : (tx.paymentMethod == 'buat_pesanan' ||
                                          tx.paymentMethod == 'Pesanan'
                                      ? 'Sudah lunas'
                                      : _methodLabel(tx.paymentMethod)),
                              foreground: isUnpaid
                                  ? AppColors.danger
                                  : const Color(0xFF15803D),
                              background: isUnpaid
                                  ? const Color(0xFFFFF1F2)
                                  : const Color(0xFFF0FDF4),
                              border: isUnpaid
                                  ? const Color(0xFFFECACA)
                                  : const Color(0xFFBBF7D0),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _DeleteTransactionButton extends StatelessWidget {
  final VoidCallback? onPressed;

  const _DeleteTransactionButton({required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: 26,
      child: Material(
        color: AppColors.danger.withValues(alpha: 0.08),
        shape: const RoundedRectangleBorder(
          side: BorderSide(color: Color(0xFFFECACA)),
        ),
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.zero,
          child: Icon(
            Icons.delete_outline_rounded,
            size: 16,
            color:
                onPressed == null ? const Color(0xFFCBD5E1) : AppColors.danger,
          ),
        ),
      ),
    );
  }
}

class _servisStatusPill extends StatelessWidget {
  final String status;
  final String? kelengkapan;
  final VoidCallback onTap;

  const _servisStatusPill({
    required this.status,
    required this.kelengkapan,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = _getStatusColor(status);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.zero,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.09),
          border: Border.all(color: color.withValues(alpha: 0.4)),
          borderRadius: BorderRadius.zero,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.sync_rounded, size: 10, color: color),
            const SizedBox(width: 3),
            Text(
              kelengkapan == null ? status : '$status - $kelengkapan',
              style: TextStyle(
                fontSize: 9.5,
                fontWeight: FontWeight.w800,
                color: color,
                letterSpacing: 0,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

class _HistoryPill extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color foreground;
  final Color background;
  final Color border;

  const _HistoryPill({
    required this.icon,
    required this.label,
    required this.foreground,
    required this.background,
    required this.border,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
      decoration: BoxDecoration(
        color: background,
        border: Border.all(color: border),
        borderRadius: BorderRadius.zero,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 10, color: foreground),
          const SizedBox(width: 3),
          Text(
            label,
            style: TextStyle(
              fontSize: 9.5,
              fontWeight: FontWeight.w800,
              color: foreground,
              letterSpacing: 0,
            ),
          ),
        ],
      ),
    );
  }
}

String _orderTypeLabel(String? value) {
  final raw = value?.trim() ?? '';
  final lower = raw.toLowerCase();
  if (lower.contains('antar')) return 'Antar/Jemput';
  if (lower.contains('ambil')) return 'Ambil di Toko';
  return raw;
}

Color _getStatusColor(String status) {
  switch (status) {
    case 'Diterima':
      return _kBrand;
    case 'Proses':
      return const Color(0xFFF59E0B);
    case 'Siap Ambil':
      return const Color(0xFF10B981);
    case 'Selesai':
      return const Color(0xFF64748B);
    default:
      return const Color(0xFF94A3B8);
  }
}

void _showservisStatusUpdateDialog(
    BuildContext context, WidgetRef ref, Transaction tx) {
  showDialog(
    context: context,
    builder: (ctx) {
      String localStatus = tx.servisStatus;
      return StatefulBuilder(builder: (ctx, setLocal) {
        return AlertDialog(
          title: const Text('Update Status Servis',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: ['Diterima', 'Proses', 'Siap Ambil', 'Selesai'].map((s) {
              final isSel = localStatus == s;
              return ListTile(
                leading: Icon(
                  isSel ? Icons.check_circle : Icons.circle_outlined,
                  color: isSel ? _kBrand : Colors.grey,
                ),
                title: Text(s,
                    style: TextStyle(
                        fontWeight: isSel ? FontWeight.bold : FontWeight.normal,
                        color: isSel ? _kBrand : Colors.black87)),
                onTap: () => setLocal(() => localStatus = s),
              );
            }).toList(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Batal', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () async {
                await ref
                    .read(transactionsProvider.notifier)
                    .updateservisStatus(tx.id!, localStatus, tx.kelengkapan);
                if (ctx.mounted) {
                  Navigator.pop(ctx);
                }

                // Auto-WA if status is 'Siap Ambil'
                if (localStatus == 'Siap Ambil') {
                  _askToSendWhatsApp(tx, localStatus);
                }
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: _kBrand,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.zero)),
              child: const Text('Update'),
            ),
          ],
        );
      });
    },
  );
}

void _askToSendWhatsApp(Transaction tx, String status) async {
  final warung = await DBHelper.instance.getWarungProfile();
  final customer = tx.customerId != null
      ? await DBHelper.instance.getCustomerById(tx.customerId!)
      : null;

  final msg = WhatsAppHelper.buildservisStatusMessage(
    namaWarung: warung['nama'] ?? 'Juragan Servis',
    customerName: tx.customerName ?? 'Pelanggan',
    noTransaksi: _formatNoTransaksi(tx),
    status: status,
    grandTotal: tx.grandTotal,
    paymentStatus: tx.amountPaid >= tx.grandTotal ? 'Lunas' : 'Belum Lunas',
  );

  WhatsAppHelper.sendMessage(message: msg, phone: customer?.phone);
}

Future<void> _confirmDelete(
    BuildContext context, WidgetRef ref, int txId) async {
  final confirmed = await showKasirDeleteConfirmDialog(
    context,
    title: 'Hapus Transaksi?',
    message:
        'Transaksi akan dipindahkan ke riwayat terhapus. Stok barang dan saldo akan dikembalikan secara otomatis.',
  );

  if (confirmed == true) {
    await ref.read(transactionsProvider.notifier).deleteTransaction(txId);
    if (!context.mounted) {
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Transaksi telah dihapus'),
          backgroundColor: Colors.black87),
    );
  }
}

// PAYMENT METHOD THUMBNAIL
class _PaymentThumb extends StatelessWidget {
  final String method;
  final bool isUnpaid;
  const _PaymentThumb({required this.method, this.isUnpaid = false});

  @override
  Widget build(BuildContext context) {
    final m = method.toLowerCase();

    if (isUnpaid) {
      return Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
            color: AppColors.danger.withValues(alpha: 0.08),
            borderRadius: BorderRadius.zero),
        child: const Icon(Icons.schedule_rounded,
            color: AppColors.danger, size: 18),
      );
    }
    if (m == 'qris') {
      return Container(
        width: 34,
        height: 34,
        decoration: const BoxDecoration(
            color: Color(0xFFF3E8FF), borderRadius: BorderRadius.zero),
        child: const Icon(Icons.qr_code_rounded,
            color: Color(0xFF7C3AED), size: 18),
      );
    }
    if (m == 'transfer') {
      return Container(
        width: 34,
        height: 34,
        decoration: const BoxDecoration(
            color: Color(0xFFEFF6FF), borderRadius: BorderRadius.zero),
        child: const Icon(Icons.account_balance_rounded,
            color: Color(0xFF2563EB), size: 18),
      );
    }
    if (m == 'pesanan' || m == 'buat_pesanan') {
      return Container(
        width: 34,
        height: 34,
        decoration: const BoxDecoration(
            color: Color(0xFFFFF3E0), borderRadius: BorderRadius.zero),
        child: const Icon(Icons.receipt_long_rounded,
            color: Color(0xFFF57F17), size: 18),
      );
    }
    return Container(
      width: 34,
      height: 34,
      decoration: const BoxDecoration(
          color: AppColors.brandLight, borderRadius: BorderRadius.zero),
      child: const Icon(Icons.payments_rounded,
          color: AppColors.primaryBrand, size: 18),
    );
  }
}

// ignore: unused_element
class _QrisPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = Colors.white
      ..isAntiAlias = true;
    final s = size.width / 5;
    for (final (dx, dy) in [(0.0, 0.0), (3 * s, 0.0), (0.0, 3 * s)]) {
      p.style = PaintingStyle.stroke;
      p.strokeWidth = s * 0.5;
      canvas.drawRect(
          Rect.fromLTWH(dx + s * 0.25, dy + s * 0.25, s * 1.5, s * 1.5), p);
      p.style = PaintingStyle.fill;
      canvas.drawRect(
          Rect.fromLTWH(dx + s * 0.75, dy + s * 0.75, s * 0.5, s * 0.5), p);
    }
    p.style = PaintingStyle.fill;
    final dots = [
      (3 * s, 3 * s),
      (4 * s, 3 * s),
      (3 * s, 4 * s),
      (4.5 * s, 4 * s),
      (2 * s, 2 * s),
      (2.5 * s, 0.0),
      (4 * s, 2 * s),
    ];
    for (final (dx, dy) in dots) {
      canvas.drawRect(Rect.fromLTWH(dx, dy, s * 0.7, s * 0.7), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// EMPTY STATE
class _EmptyState extends StatelessWidget {
  final String? subtitle;
  const _EmptyState({this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 220,
            height: 170,
            child: CustomPaint(painter: _CardIllustrationPainter()),
          ),
          const SizedBox(height: 20),
          const Text('Transaksi Tidak Ditemukan',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87)),
          if (subtitle != null) ...[
            const SizedBox(height: 6),
            Text(subtitle!,
                style: const TextStyle(fontSize: 13, color: Colors.black45)),
          ],
        ],
      ),
    );
  }
}

// SMALL REUSABLE WIDGETS
class _TabItem extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final int badgeCount;
  const _TabItem(
      {required this.label,
      required this.selected,
      required this.onTap,
      this.badgeCount = 0});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                        color: selected ? _kBrand : Colors.grey,
                        fontWeight:
                            selected ? FontWeight.bold : FontWeight.w500,
                        fontSize: 15),
                  ),
                  if (badgeCount > 0)
                    Positioned(
                      top: -4,
                      right: -14,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 16,
                          minHeight: 16,
                        ),
                        child: Text(
                          '$badgeCount',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Container(
                height: 2, color: selected ? _kBrand : Colors.transparent),
          ],
        ),
      ),
    );
  }
}

class _DropdownPill extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _DropdownPill({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: _kBrand.withValues(alpha: 0.06),
          borderRadius: BorderRadius.zero,
          border: Border.all(color: _kBrand.withValues(alpha: 0.2)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w600, color: _kBrand),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const Icon(Icons.keyboard_arrow_down_rounded,
                size: 18, color: _kBrand),
          ],
        ),
      ),
    );
  }
}

class _PeriodOption extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _PeriodOption(
      {required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        color: selected ? _kBrand.withValues(alpha: 0.08) : Colors.transparent,
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 15,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            color: selected ? _kBrand : Colors.black87,
          ),
        ),
      ),
    );
  }
}

// CREDIT CARD ILLUSTRATION PAINTER
class _CardIllustrationPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..isAntiAlias = true;
    final w = size.width;
    final h = size.height;

    canvas.save();
    canvas.translate(w * 0.04, h * 0.04);
    canvas.rotate(-0.14);

    p.color = Colors.black.withValues(alpha: 0.08);
    p.maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(3, 6, w * 0.80, h * 0.54), const Radius.circular(0)),
        p);
    p.maskFilter = null;

    p.color = const Color(0xFF2B3A6E);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(0, 0, w * 0.80, h * 0.54), const Radius.circular(0)),
        p);

    p.color = const Color(0xFF1A2648);
    canvas.drawRect(Rect.fromLTWH(0, h * 0.12, w * 0.80, h * 0.10), p);

    p.color = const Color(0xFFD4A843);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(w * 0.07, h * 0.27, w * 0.13, h * 0.09),
            const Radius.circular(0)),
        p);

    canvas.restore();

    canvas.save();
    canvas.translate(w * 0.16, h * 0.30);

    p.color = Colors.black.withValues(alpha: 0.10);
    p.maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(2, 6, w * 0.80, h * 0.56), const Radius.circular(0)),
        p);
    p.maskFilter = null;

    p.color = Colors.white;
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(0, 0, w * 0.80, h * 0.56), const Radius.circular(0)),
        p);

    p.color = const Color(0xFFDEDEDE);
    p.style = PaintingStyle.stroke;
    p.strokeWidth = 0.8;
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(0, 0, w * 0.80, h * 0.56), const Radius.circular(0)),
        p);
    p.style = PaintingStyle.fill;

    p.color = _kBrand.withValues(alpha: 0.88);
    canvas.drawCircle(Offset(w * 0.085, h * 0.115), w * 0.062, p);

    p.color = _kBrand.withValues(alpha: 0.42);
    canvas.drawCircle(Offset(w * 0.142, h * 0.115), w * 0.062, p);

    p.color = _kBrand.withValues(alpha: 0.6);
    final dotY = h * 0.305;
    final groupX = [w * 0.06, w * 0.27, w * 0.48, w * 0.65];
    for (final gx in groupX) {
      for (int i = 0; i < 4; i++) {
        canvas.drawCircle(Offset(gx + i * 7.5, dotY), 3.5, p);
      }
    }

    p.color = const Color(0xFFE0E0E0);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(w * 0.06, h * 0.42, w * 0.34, h * 0.043),
            const Radius.circular(0)),
        p);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(w * 0.06, h * 0.49, w * 0.22, h * 0.038),
            const Radius.circular(0)),
        p);

    p.color = _kBrand;
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(w * 0.67, h * 0.065, w * 0.095, h * 0.11),
            const Radius.circular(0)),
        p);

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

