import 'dart:convert';

import '../models/db_models.dart';

class StaffPermissionKey {
  static const dashboard = 'dashboard';
  static const order = 'order';
  static const servisStatus = 'servis_status';
  static const history = 'history';
  static const customers = 'customers';
  static const products = 'products';
  static const employees = 'employees';
  static const reports = 'reports';
  static const wallet = 'wallet';
  static const settings = 'settings';
  static const sync = 'sync';
  static const ai = 'ai';
  static const notifications = 'notifications';
  static const remoteScanner = 'remote_scanner';
  static const deleteTransactions = 'delete_transactions';
  static const adjustWallet = 'adjust_wallet';

  static const all = [
    dashboard,
    order,
    servisStatus,
    history,
    customers,
    products,
    employees,
    reports,
    wallet,
    settings,
    sync,
    ai,
    notifications,
    remoteScanner,
    deleteTransactions,
    adjustWallet,
  ];
}

class StaffPermissionSpec {
  final String key;
  final String title;
  final String description;
  final String group;

  const StaffPermissionSpec({
    required this.key,
    required this.title,
    required this.description,
    required this.group,
  });
}

class StaffAccess {
  static const specs = [
    StaffPermissionSpec(
      key: StaffPermissionKey.dashboard,
      title: 'Dashboard',
      description: 'Melihat ringkasan operasional dan transaksi terakhir.',
      group: 'Menu Utama',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.order,
      title: 'Order Servis',
      description: 'Membuat pesanan dan memproses pembayaran.',
      group: 'Menu Utama',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.servisStatus,
      title: 'Status Servis',
      description: 'Mengelola diterima, proses, siap ambil, dan selesai.',
      group: 'Menu Utama',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.history,
      title: 'Riwayat',
      description: 'Melihat riwayat transaksi dan detail struk.',
      group: 'Menu Utama',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.customers,
      title: 'Pelanggan',
      description: 'Melihat dan memakai data pelanggan saat transaksi.',
      group: 'Menu Utama',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.products,
      title: 'Layanan & Inventori',
      description: 'Tambah, ubah, stok, kategori, dan harga layanan.',
      group: 'Manajemen',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.employees,
      title: 'Karyawan',
      description: 'Tambah, ubah, hapus, dan atur akses karyawan.',
      group: 'Manajemen',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.reports,
      title: 'Laporan',
      description: 'Melihat laporan omzet, layanan, stok, dan performa.',
      group: 'Manajemen',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.wallet,
      title: 'Buku Kas Usaha',
      description: 'Melihat dan mencatat kas usaha di luar kas shift.',
      group: 'Manajemen',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.settings,
      title: 'Pengaturan',
      description: 'Mengubah identitas toko, struk, pembayaran, dan sistem.',
      group: 'Sistem',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.sync,
      title: 'Sinkronisasi',
      description: 'Sinkron data antar perangkat.',
      group: 'Sistem',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.ai,
      title: 'Asisten AI',
      description: 'Membuka analisis AI dari data servis.',
      group: 'Sistem',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.notifications,
      title: 'Notifikasi',
      description: 'Melihat notifikasi operasional.',
      group: 'Sistem',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.remoteScanner,
      title: 'Scanner PC',
      description: 'Menghubungkan scanner HP ke PC.',
      group: 'Sistem',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.deleteTransactions,
      title: 'Hapus Transaksi',
      description: 'Menghapus transaksi dan mengembalikan stok/saldo.',
      group: 'Aksi Sensitif',
    ),
    StaffPermissionSpec(
      key: StaffPermissionKey.adjustWallet,
      title: 'Koreksi Saldo Kas',
      description: 'Mencatat selisih dan koreksi saldo kas.',
      group: 'Aksi Sensitif',
    ),
  ];

  static const defaultEmployeePermissions = {
    StaffPermissionKey.dashboard,
    StaffPermissionKey.order,
    StaffPermissionKey.servisStatus,
    StaffPermissionKey.history,
    StaffPermissionKey.customers,
    StaffPermissionKey.notifications,
    StaffPermissionKey.remoteScanner,
  };

  static Set<String> get fullPermissions => StaffPermissionKey.all.toSet();

  static bool isAdmin(Employee? staff) {
    if (staff == null) return false;
    final role = staff.role.toLowerCase();
    return role.contains('admin') || role.contains('owner');
  }

  static bool usesDefaultPermissions(Employee employee) {
    return (employee.permissionsJson ?? '').trim().isEmpty;
  }

  static Set<String>? parsePermissions(String? raw) {
    final text = raw?.trim();
    if (text == null || text.isEmpty) return null;
    try {
      final decoded = jsonDecode(text);
      if (decoded is List) {
        return decoded.whereType<String>().toSet();
      }
    } catch (_) {}
    return null;
  }

  static String encodePermissions(Set<String> keys) {
    final ordered = StaffPermissionKey.all.where(keys.contains).toList();
    return jsonEncode(ordered);
  }

  static Set<String> effectivePermissions(Employee? staff) {
    if (staff == null || isAdmin(staff)) return fullPermissions;
    return parsePermissions(staff.permissionsJson) ??
        defaultEmployeePermissions;
  }

  static bool can(Employee? staff, String permissionKey) {
    return effectivePermissions(staff).contains(permissionKey);
  }

  static String? permissionForShellIndex(int index) {
    return switch (index) {
      0 => StaffPermissionKey.dashboard,
      1 => StaffPermissionKey.order,
      2 => StaffPermissionKey.products,
      3 => StaffPermissionKey.order,
      4 => StaffPermissionKey.history,
      5 => StaffPermissionKey.reports,
      6 => StaffPermissionKey.customers,
      7 => StaffPermissionKey.employees,
      8 => StaffPermissionKey.notifications,
      9 => StaffPermissionKey.settings,
      10 => StaffPermissionKey.servisStatus,
      11 => StaffPermissionKey.sync,
      12 => StaffPermissionKey.ai,
      _ => null,
    };
  }

  static bool canOpenShellIndex(Employee? staff, int index) {
    final permission = permissionForShellIndex(index);
    return permission == null || can(staff, permission);
  }
}

