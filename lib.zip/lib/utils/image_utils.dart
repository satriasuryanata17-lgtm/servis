import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

class ImageUtils {
  /// Menyimpan gambar ke folder internal aplikasi (berguna untuk Desktop)
  static Future<String?> saveImageToLocalDirectory(String originalPath) async {
    try {
      final File originalFile = File(originalPath);
      if (!await originalFile.exists()) return null;

      // Gunakan Application Documents Directory
      final directory = await getApplicationSupportDirectory();

      // Buat folder khusus untuk gambar Juragan Servis
      final String appImagesPath =
          p.join(directory.path, 'Juragan Servis', 'Images');
      final Directory appImagesDir = Directory(appImagesPath);

      if (!await appImagesDir.exists()) {
        await appImagesDir.create(recursive: true);
      }

      // Generate nama file unik
      final String extension = p.extension(originalPath);
      final String fileName =
          'img_${DateTime.now().millisecondsSinceEpoch}$extension';
      final String newPath = p.join(appImagesPath, fileName);

      // Salin file ke folder internal
      final File newFile = await originalFile.copy(newPath);
      return newFile.path;
    } catch (e) {
      debugPrint('Error saving image to local directory: $e');
      return originalPath; // Fallback ke path asli jika gagal
    }
  }
}

