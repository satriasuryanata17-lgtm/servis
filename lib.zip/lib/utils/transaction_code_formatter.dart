import 'package:intl/intl.dart';

class TransactionCodeFormatter {
  static const String defaultPrefix = 'TRX';

  static String format({
    required int id,
    required String createdAt,
    String? transactionCode,
    String? storeName,
    String? customPrefix,
  }) {
    final existingCode = transactionCode?.trim();
    if (existingCode != null && existingCode.isNotEmpty) {
      return existingCode.toUpperCase();
    }

    final prefix = customPrefix ?? derivePrefix(storeName);
    try {
      final dt = DateTime.parse(createdAt);
      final timePart = DateFormat('ddMMyyyyHHmm').format(dt);
      return '$prefix$timePart${id.toString().padLeft(2, '0')}';
    } catch (_) {
      return '$prefix${id.toString().padLeft(11, '0')}';
    }
  }

  static String derivePrefix(String? storeName) {
    final raw = (storeName ?? '').trim().toUpperCase();
    if (raw.isEmpty) return defaultPrefix;

    final parts = raw
        .split(RegExp(r'[^A-Z0-9]+'))
        .where((part) => part.isNotEmpty)
        .toList();
    final initials = parts.map((part) => part[0]).join();
    final compact = raw.replaceAll(RegExp(r'[^A-Z0-9]'), '');

    final seed = initials.length >= 3 ? initials : compact;
    if (seed.isEmpty) return defaultPrefix;
    if (seed.length >= 3) return seed.substring(0, 3);
    return (seed + defaultPrefix).substring(0, 3);
  }
}

