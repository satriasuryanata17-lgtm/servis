//
// MODERN APP BAR BUILDER
// Gunakan ini di SEMUA AppBar definitions untuk konsistensi
//

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/theme.dart';

/// Modern AppBar yang konsisten di seluruh app
class ModernAppBarBuilder {
  /// AppBar standar dengan title dan back button
  static PreferredSizeWidget standard({
    required String title,
    List<Widget>? actions,
    VoidCallback? onBackPressed,
    Color bgColor = AppColors.surface,
  }) {
    return AppBar(
      title: Text(title, style: AppText.h2),
      backgroundColor: bgColor,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarIconBrightness: Brightness.dark,
        statusBarColor: Colors.transparent,
      ),
      leading: BackButton(
        color: AppColors.textTitle,
        onPressed: onBackPressed,
      ),
      actions: actions,
      shape: const Border(
        bottom: BorderSide(color: AppColors.divider, width: 0.5),
      ),
    );
  }

  /// AppBar dengan drawer button (untuk main screens)
  static PreferredSizeWidget withDrawer({
    required String title,
    required VoidCallback onDrawerPressed,
    List<Widget>? actions,
    Color bgColor = AppColors.surface,
  }) {
    return AppBar(
      title: Text(title, style: AppText.h2),
      backgroundColor: bgColor,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarIconBrightness: Brightness.dark,
        statusBarColor: Colors.transparent,
      ),
      leading: Builder(
        builder: (ctx) => IconButton(
          icon: const Icon(Icons.menu, color: AppColors.primaryBrand, size: 26),
          onPressed: onDrawerPressed,
        ),
      ),
      actions: actions,
      shape: const Border(
        bottom: BorderSide(color: AppColors.divider, width: 0.5),
      ),
    );
  }

  /// AppBar minimal (untuk sub-screens)
  static PreferredSizeWidget minimal({
    required String title,
    List<Widget>? actions,
  }) {
    return AppBar(
      title: Text(title, style: AppText.h2),
      backgroundColor: AppColors.surface,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarIconBrightness: Brightness.dark,
        statusBarColor: Colors.transparent,
      ),
      leading: const BackButton(color: AppColors.textTitle),
      actions: actions,
      shape: const Border(
        bottom: BorderSide(color: AppColors.divider, width: 0.5),
      ),
    );
  }

  /// AppBar dengan custom content (advanced)
  static PreferredSizeWidget custom({
    required String title,
    required Widget leading,
    List<Widget>? actions,
    double height = kToolbarHeight,
  }) {
    return AppBar(
      title: Text(title, style: AppText.h2),
      backgroundColor: AppColors.surface,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarIconBrightness: Brightness.dark,
        statusBarColor: Colors.transparent,
      ),
      leading: leading,
      actions: actions,
      toolbarHeight: height,
      shape: const Border(
        bottom: BorderSide(color: AppColors.divider, width: 0.5),
      ),
    );
  }
}

/// Scaffold backgrounds standardized
class ModernScaffoldBg {
  static const Color light = AppColors.background; // #F5F7FA
  static const Color surface = AppColors.surface; // #FFFFFF
  static const Color dim = AppColors.surfaceDim; // #F0F1F5
}

/// Modern snackbar style
class ModernSnackBar {
  static void show({
    required BuildContext context,
    required String message,
    Duration duration = const Duration(milliseconds: 2200),
    ModernSnackBarType type = ModernSnackBarType.info,
  }) {
    IconData icon;
    Color iconColor;

    switch (type) {
      case ModernSnackBarType.success:
        icon = Icons.check_circle_rounded;
        iconColor = AppColors.success;
        break;
      case ModernSnackBarType.warning:
        icon = Icons.warning_amber_rounded;
        iconColor = AppColors.warning;
        break;
      case ModernSnackBarType.error:
        icon = Icons.error_rounded;
        iconColor = AppColors.danger;
        break;
      default:
        icon = Icons.info_rounded;
        iconColor = AppColors.primaryBrand;
    }

    final screenWidth = MediaQuery.sizeOf(context).width;
    final isWideScreen = screenWidth >= 700;
    final horizontalPadding = isWideScreen ? 18.0 : 12.0;
    final verticalPadding = isWideScreen ? 14.0 : 9.0;
    final iconSize = isWideScreen ? 20.0 : 16.0;
    final messageFontSize = isWideScreen ? 14.0 : 12.5;
    final bottomMargin = isWideScreen ? 18.0 : 12.0;

    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        padding: EdgeInsets.symmetric(
          horizontal: horizontalPadding,
          vertical: verticalPadding,
        ),
        content: Row(
          children: [
            Icon(icon, color: iconColor, size: iconSize),
            SizedBox(width: isWideScreen ? 12 : 9),
            Expanded(
              child: Text(
                message,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: messageFontSize,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0,
                  height: 1.25,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFF1F2937),
        behavior: SnackBarBehavior.floating,
        elevation: 0,
        margin: EdgeInsets.fromLTRB(14, 0, 14, bottomMargin),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        duration: duration,
      ),
    );
  }

  static void success({
    required BuildContext context,
    required String message,
  }) {
    show(context: context, message: message, type: ModernSnackBarType.success);
  }

  static void error({
    required BuildContext context,
    required String message,
  }) {
    show(context: context, message: message, type: ModernSnackBarType.error);
  }

  static void warning({
    required BuildContext context,
    required String message,
  }) {
    show(context: context, message: message, type: ModernSnackBarType.warning);
  }
}

enum ModernSnackBarType { success, error, warning, info }

