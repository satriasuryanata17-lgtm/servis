import 'package:sqflite/sqflite.dart' hide Transaction;
import 'package:path/path.dart';
import 'dart:io';
import 'dart:async';
import 'package:flutter/foundation.dart' hide Category;
import '../models/db_models.dart';
import '../utils/transaction_code_formatter.dart';

class _PaymentPart {
  final String walletId;
  final int nominal;

  const _PaymentPart({
    required this.walletId,
    required this.nominal,
  });
}

class DBHelper {
  static const String _dbName = 'juragankasir_v2.db';
  static const int _dbVersion = 51;
  static String? _databasePathOverride;
  static const String defaultCategoryName = 'Semua';
  static const List<String> _nonOperationalExpenseCategories = [
    'Pembatalan',
    'Koreksi',
    'Pelunasan',
    'Pemulihan',
    'Servis',
    'Pembelian Stok',
    'Pembelian Aset',
    'Pembelian Unit',
    'Pembelian Barang',
    'Refund',
  ];
  static const List<String> _inventoryPurchaseCategories = [
    'Pembelian Stok',
    'Pembelian Aset',
    'Pembelian Unit',
    'Pembelian Barang',
  ];
  static const Set<String> _cashShiftLedgerCategories = {
    'penjualan',
    'servis',
    'pembatalan',
    'pemulihan',
    'pelunasan',
    'pembelian stok',
    'pembatalan pembelian',
    'refund',
  };
  static const Set<String> _shiftRevenueCategories = {
    'penjualan',
    'servis',
    'pelunasan',
  };
  static const List<String> _cashWalletAliases = ['cash', 'tunai', '1'];
  static const List<String> _nonCashWalletAliases = [
    'non_tunai',
    'noncash',
    'non_cash',
    'nontunai',
    'qris',
    'transfer',
    'bank',
    'debit',
    'kartu',
    'card',
    'edc',
    'cashless',
    'e_wallet',
    'ewallet',
    '2',
  ];

  static String _dateKey(DateTime date) =>
      date.toIso8601String().substring(0, 10);

  static String _sqlPlaceholders(int count) =>
      List.filled(count, '?').join(', ');

  static String _normalizeWalletId(String? value) => (value ?? '')
      .trim()
      .toLowerCase()
      .replaceAll('-', '_')
      .replaceAll(' ', '_');

  static String _walletIdSqlExpression([String column = 'wallet_id']) =>
      "LOWER(REPLACE(REPLACE(COALESCE($column, ''), '-', '_'), ' ', '_'))";

  static List<String>? _walletAliasesFor(String walletId) {
    final id = _normalizeWalletId(walletId);
    if (_cashWalletAliases.contains(id)) return _cashWalletAliases;
    if (_nonCashWalletAliases.contains(id)) return _nonCashWalletAliases;
    return null;
  }

  static String _canonicalWalletId(String? value) {
    final id = _normalizeWalletId(value);
    if (id.isEmpty || _cashWalletAliases.contains(id)) return 'tunai';
    if (_nonCashWalletAliases.contains(id)) return 'non_tunai';
    return id;
  }

  static String _canonicalWalletType(String? value) {
    final type = (value ?? '').trim().toLowerCase();
    if (type == 'keluar' ||
        type == 'out' ||
        type == 'expense' ||
        type == 'pengeluaran') {
      return 'keluar';
    }
    return 'masuk';
  }

  static bool _isCashWalletId(String walletId) {
    final id = _normalizeWalletId(walletId);
    return _cashWalletAliases.contains(id);
  }

  static bool _isNonCashWalletId(String walletId) {
    final id = _normalizeWalletId(walletId);
    return _nonCashWalletAliases.contains(id) ||
        id.contains('bank') ||
        id.contains('ewallet') ||
        id.contains('e_wallet') ||
        id.contains('e-wallet');
  }

  static bool _isMixedPaymentWalletId(String walletId) {
    final id = walletId.trim().toLowerCase();
    return id.startsWith('campuran') || id.contains('tunai:');
  }

  static int _extractMixedCashAmount(String walletId, int nominal) {
    final match = RegExp(
      r'(tunai|cash)\s*:\s*[^0-9]*([0-9][0-9.,]*)',
      caseSensitive: false,
    ).firstMatch(walletId);
    if (match == null) return 0;
    final raw = match.group(2)?.replaceAll(RegExp(r'[^0-9]'), '') ?? '';
    final parsed = int.tryParse(raw) ?? 0;
    return parsed.clamp(0, nominal).toInt();
  }

  static List<int> _splitWalletNominal(String walletId, int nominal) {
    if (nominal <= 0) return [0, 0];
    if (_isCashWalletId(walletId)) return [nominal, 0];
    if (_isMixedPaymentWalletId(walletId)) {
      final cash = _extractMixedCashAmount(walletId, nominal);
      return [cash, nominal - cash];
    }
    if (_isNonCashWalletId(walletId)) return [0, nominal];
    return [0, 0];
  }

  static bool _requestsCashWallet(String walletId) {
    return _isCashWalletId(walletId);
  }

  static bool _requestsNonCashWallet(String walletId) {
    final id = _normalizeWalletId(walletId);
    return id == 'non_tunai' || _isNonCashWalletId(id);
  }

  static const List<String> backupTables = [
    'categories',
    'finance_categories',
    'products',
    'product_recipes',
    'stock_logs',
    'customers',
    'transactions',
    'transaction_items',
    'transaction_material_usages',
    'cicilans',
    'audit_logs',
    'employees',
    'warung_profile',
    'profil',
    'wallet_transactions',
    'discounts',
    'payment_settings',
    'kasir_sessions',
    'suppliers',
    'purchase_orders',
    'purchase_items',
    'return_transactions',
    'return_items',
    'fnb_tables',
    'fnb_kitchen_tickets',
  ];

  static const List<String> restoreDeleteOrder = [
    'fnb_kitchen_tickets',
    'fnb_tables',
    'return_items',
    'return_transactions',
    'purchase_items',
    'purchase_orders',
    'suppliers',
    'audit_logs',
    'cicilans',
    'transaction_material_usages',
    'transaction_items',
    'transactions',
    'customers',
    'stock_logs',
    'product_recipes',
    'products',
    'categories',
    'wallet_transactions',
    'finance_categories',
    'discounts',
    'payment_settings',
    'kasir_sessions',
    'employees',
    'warung_profile',
    'resi_print_logs',
    'profil',
  ];

  static const List<String> restoreInsertOrder = [
    'categories',
    'finance_categories',
    'products',
    'product_recipes',
    'stock_logs',
    'customers',
    'transactions',
    'transaction_items',
    'transaction_material_usages',
    'cicilans',
    'audit_logs',
    'employees',
    'warung_profile',
    'profil',
    'wallet_transactions',
    'discounts',
    'payment_settings',
    'kasir_sessions',
    'suppliers',
    'purchase_orders',
    'purchase_items',
    'return_transactions',
    'return_items',
    'fnb_tables',
    'fnb_kitchen_tickets',
  ];

  static const List<String> requiredBackupTables = [
    'categories',
    'products',
    'transactions',
    'transaction_items',
  ];

  static int get schemaVersion => _dbVersion;
  static String get databaseName => _dbName;

  static bool isDefaultCategoryName(String? name) =>
      (name ?? '').trim().toLowerCase() == defaultCategoryName.toLowerCase();

  static void overrideDatabasePathForTesting(String? path) {
    _databasePathOverride = path;
  }

  DBHelper._();
  static final DBHelper instance = DBHelper._();

  Database? _database;
  Future<void>? _coreSchemaFuture;
  Future<void>? _walletTransactionSchemaFuture;

  Future<Database> get database async {
    if (_database != null) return _database!;
    debugPrint('[DB] Initializing database...');
    _database = await _initDB();
    debugPrint('[DB] Database initialized.');
    return _database!;
  }

  Future<String> getDatabasePath() async {
    final overridePath = _databasePathOverride;
    if (overridePath != null && overridePath.trim().isNotEmpty) {
      return overridePath;
    }
    final dbPath = await getDatabasesPath();
    return join(dbPath, _dbName);
  }

  Future<Database> _initDB() async {
    final path = await getDatabasePath();
    return await openDatabase(
      path,
      version: _dbVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON;');
      },
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
      onOpen: _onOpen,
    );
  }

  Future<void> close() async {
    final db = _database;
    if (db != null && db.isOpen) {
      await db.close();
    }
    _database = null;
    _resetSchemaEnsureCache();
  }

  void _resetSchemaEnsureCache() {
    _coreSchemaFuture = null;
    _walletTransactionSchemaFuture = null;
  }

  Future<void> resetToFactory() async {
    final db = await database;
    await db.execute('PRAGMA foreign_keys = OFF;');
    try {
      final tableRows = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type = 'table'",
      );
      final existingTables =
          tableRows.map((row) => row['name']?.toString()).whereType<String>();
      final existing = existingTables.toSet();

      for (final table in restoreDeleteOrder) {
        if (existing.contains(table)) {
          await db.delete(table);
        }
      }

      if (existing.contains('sqlite_sequence')) {
        await db.delete('sqlite_sequence');
      }

      if (existing.contains('categories')) {
        await db.insert('categories', {'name': defaultCategoryName});
      }
    } finally {
      await db.execute('PRAGMA foreign_keys = ON;');
    }
    _resetSchemaEnsureCache();
    await _ensureCoreSchema(db);
  }

  Future<void> _onOpen(Database db) async {
    await _ensureCoreSchema(db);
    await _syncTransactionCustomerNameSnapshots(db);
    // Migration: Simplify Servis Statuses (guard legacy schemas)
    final hasTransactionsTable = await _hasTable(db, 'transactions');
    if (hasTransactionsTable) {
      final hasservisStatus =
          await _hasColumn(db, 'transactions', 'servis_status');
      if (hasservisStatus) {
        await db.execute('''
          UPDATE transactions 
          SET servis_status = 'Proses' 
          WHERE servis_status IN ('Pengecekan', 'Menunggu Part', 'Perbaikan', 'QC')
        ''');
      }
    }
  }

  Future<bool> _hasColumn(
    DatabaseExecutor db,
    String table,
    String column,
  ) async {
    final tableInfo = await db.rawQuery('PRAGMA table_info($table)');
    return tableInfo.any((entry) => entry['name'] == column);
  }

  Future<bool> _hasTable(DatabaseExecutor db, String table) async {
    final rows = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?",
      [table],
    );
    return rows.isNotEmpty;
  }

  Future<void> _syncTransactionCustomerNameSnapshots(
    DatabaseExecutor db,
  ) async {
    final hasTransactionsTable = await _hasTable(db, 'transactions');
    final hasCustomersTable = await _hasTable(db, 'customers');
    if (!hasTransactionsTable || !hasCustomersTable) return;

    final hasCustomerId = await _hasColumn(db, 'transactions', 'customer_id');
    final hasCustomerName =
        await _hasColumn(db, 'transactions', 'customer_name');
    final hasCustomerMasterName = await _hasColumn(db, 'customers', 'name');
    if (!hasCustomerId || !hasCustomerName || !hasCustomerMasterName) return;

    await db.execute('''
      UPDATE transactions
      SET customer_name = (
        SELECT customers.name
        FROM customers
        WHERE customers.id = transactions.customer_id
      )
      WHERE customer_id IS NOT NULL
        AND EXISTS (
          SELECT 1 FROM customers
          WHERE customers.id = transactions.customer_id
        )
        AND COALESCE(customer_name, '') != COALESCE((
          SELECT customers.name
          FROM customers
          WHERE customers.id = transactions.customer_id
        ), '')
    ''');
  }

  int? _asInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value.toString());
  }

  Future<void> _ensureCategorySchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        duration_hours INTEGER NOT NULL DEFAULT 0
      )
    ''');

    final hasDurationHours =
        await _hasColumn(db, 'categories', 'duration_hours');
    if (!hasDurationHours) {
      await db.execute(
        'ALTER TABLE categories ADD COLUMN duration_hours INTEGER NOT NULL DEFAULT 0;',
      );
    }

    await _ensureDefaultCategory(db);
  }

  Future<int> _ensureDefaultCategory(DatabaseExecutor db) async {
    final rows = await db.query(
      'categories',
      columns: ['id'],
      where: 'LOWER(TRIM(name)) = ?',
      whereArgs: [defaultCategoryName.toLowerCase()],
      orderBy: 'id ASC',
    );

    if (rows.isEmpty) {
      return db.insert('categories', {
        'name': defaultCategoryName,
        'duration_hours': 0,
      });
    }

    final defaultId = _asInt(rows.first['id'])!;
    final duplicateIds =
        rows.skip(1).map((row) => _asInt(row['id'])).whereType<int>().toList();
    if (duplicateIds.isNotEmpty) {
      final placeholders = List.filled(duplicateIds.length, '?').join(',');
      if (await _hasTable(db, 'products')) {
        await db.rawUpdate(
          'UPDATE products SET category_id = ? WHERE category_id IN ($placeholders)',
          [defaultId, ...duplicateIds],
        );
      }
      await db.rawDelete(
        'DELETE FROM categories WHERE id IN ($placeholders)',
        duplicateIds,
      );
    }

    return defaultId;
  }

  Future<int> _ensureProductCategory(
    DatabaseExecutor db,
    int? categoryId, {
    String? categoryName,
  }) async {
    await _ensureCategorySchema(db);

    if (categoryId != null) {
      final rows = await db.query(
        'categories',
        columns: ['id'],
        where: 'id = ?',
        whereArgs: [categoryId],
        limit: 1,
      );
      if (rows.isNotEmpty) return categoryId;
    }

    final trimmedName = categoryName?.trim();
    if (trimmedName != null && trimmedName.isNotEmpty) {
      final rows = await db.query(
        'categories',
        columns: ['id'],
        where: 'LOWER(TRIM(name)) = LOWER(TRIM(?))',
        whereArgs: [trimmedName],
        limit: 1,
      );
      final resolvedId = rows.isEmpty ? null : _asInt(rows.first['id']);
      if (resolvedId != null) return resolvedId;
    }

    return _ensureDefaultCategory(db);
  }

  Future<void> _repairProductCategoryLinks(DatabaseExecutor db) async {
    await _ensureCategorySchema(db);
    if (!await _hasTable(db, 'products')) return;

    final defaultId = await _ensureDefaultCategory(db);
    await db.rawUpdate('''
      UPDATE products
      SET category_id = ?
      WHERE category_id IS NULL
         OR category_id NOT IN (SELECT id FROM categories)
    ''', [defaultId]);
  }

  static const List<Map<String, Object>> _defaultFinanceCategories = [
    {
      'name': 'Servis',
      'type': 'masuk',
      'icon_key': 'sales',
      'color_hex': '#00A86B',
      'sort_order': 10,
    },
    {
      'name': 'Pemasukan Lain',
      'type': 'masuk',
      'icon_key': 'wallet',
      'color_hex': '#3A7D7C',
      'sort_order': 20,
    },
    {
      'name': 'Modal Tambahan',
      'type': 'masuk',
      'icon_key': 'capital',
      'color_hex': '#2563EB',
      'sort_order': 30,
    },
    {
      'name': 'Pendapatan Jasa',
      'type': 'masuk',
      'icon_key': 'service',
      'color_hex': '#0891B2',
      'sort_order': 40,
    },
    {
      'name': 'Cashback/Rebate',
      'type': 'masuk',
      'icon_key': 'cashback',
      'color_hex': '#D97706',
      'sort_order': 50,
    },
    {
      'name': 'Komisi',
      'type': 'masuk',
      'icon_key': 'commission',
      'color_hex': '#7C3AED',
      'sort_order': 60,
    },
    {
      'name': 'Cicilan',
      'type': 'masuk',
      'icon_key': 'installment',
      'color_hex': '#00A86B',
      'sort_order': 70,
    },
    {
      'name': 'Pemulihan',
      'type': 'masuk',
      'icon_key': 'restore',
      'color_hex': '#2563EB',
      'sort_order': 80,
    },
    {
      'name': 'Refund Retur',
      'type': 'masuk',
      'icon_key': 'refund',
      'color_hex': '#0891B2',
      'sort_order': 90,
    },
    {
      'name': 'Pembelian Stok',
      'type': 'keluar',
      'icon_key': 'inventory',
      'color_hex': '#3A7D7C',
      'sort_order': 900,
    },
    {
      'name': 'Persediaan & Bahan',
      'type': 'keluar',
      'icon_key': 'materials',
      'color_hex': '#2E7D32',
      'sort_order': 10,
    },
    {
      'name': 'Gaji & Honor',
      'type': 'keluar',
      'icon_key': 'salary',
      'color_hex': '#37474F',
      'sort_order': 20,
    },
    {
      'name': 'Sewa',
      'type': 'keluar',
      'icon_key': 'rent',
      'color_hex': '#1565C0',
      'sort_order': 30,
    },
    {
      'name': 'Utilitas',
      'type': 'keluar',
      'icon_key': 'utilities',
      'color_hex': '#F57C00',
      'sort_order': 40,
    },
    {
      'name': 'Transportasi & Pengiriman',
      'type': 'keluar',
      'icon_key': 'transport',
      'color_hex': '#C62828',
      'sort_order': 50,
    },
    {
      'name': 'Perlengkapan',
      'type': 'keluar',
      'icon_key': 'stationery',
      'color_hex': '#2563EB',
      'sort_order': 60,
    },
    {
      'name': 'Pemasaran & Promosi',
      'type': 'keluar',
      'icon_key': 'promo',
      'color_hex': '#DB2777',
      'sort_order': 70,
    },
    {
      'name': 'Perawatan & Perbaikan',
      'type': 'keluar',
      'icon_key': 'maintenance',
      'color_hex': '#0891B2',
      'sort_order': 80,
    },
    {
      'name': 'Biaya Admin/Bank',
      'type': 'keluar',
      'icon_key': 'admin_bank',
      'color_hex': '#D97706',
      'sort_order': 90,
    },
    {
      'name': 'Pajak & Retribusi',
      'type': 'keluar',
      'icon_key': 'tax',
      'color_hex': '#7C3AED',
      'sort_order': 100,
    },
    {
      'name': 'Operasional Umum',
      'type': 'keluar',
      'icon_key': 'operations',
      'color_hex': '#64748B',
      'sort_order': 110,
    },
    {
      'name': 'Bonus & Insentif',
      'type': 'keluar',
      'icon_key': 'bonus',
      'color_hex': '#3A7D7C',
      'sort_order': 120,
    },
    {
      'name': 'Pembatalan',
      'type': 'keluar',
      'icon_key': 'cancel',
      'color_hex': '#E73A53',
      'sort_order': 910,
    },
    {
      'name': 'Pembatalan Pembelian',
      'type': 'keluar',
      'icon_key': 'cancel',
      'color_hex': '#E73A53',
      'sort_order': 920,
    },
    {
      'name': 'Koreksi',
      'type': 'keluar',
      'icon_key': 'adjustment',
      'color_hex': '#64748B',
      'sort_order': 930,
    },
    {
      'name': 'Lainnya',
      'type': 'keluar',
      'icon_key': 'other',
      'color_hex': '#546E7A',
      'sort_order': 1000,
    },
  ];

  String _normalizeFinanceType(String type) =>
      type.trim().toLowerCase() == 'masuk' ? 'masuk' : 'keluar';

  String _fallbackFinanceCategoryName(String type) =>
      _normalizeFinanceType(type) == 'masuk' ? 'Pemasukan Lain' : 'Lainnya';

  static const Map<String, String> _legacyIncomeCategoryAliases = {
    'manual': 'Pemasukan Lain',
    'pemasukan manual': 'Pemasukan Lain',
    'cashback': 'Cashback/Rebate',
    'lainnya': 'Pemasukan Lain',
  };

  static const Map<String, String> _legacyExpenseCategoryAliases = {
    'gaji': 'Gaji & Honor',
    'bahan baku': 'Persediaan & Bahan',
    'atk': 'Perlengkapan',
    'bonus di luar gaji': 'Bonus & Insentif',
    'listrik/air': 'Utilitas',
    'transportasi': 'Transportasi & Pengiriman',
    'promosi': 'Pemasaran & Promosi',
    'operasional': 'Operasional Umum',
  };

  String _canonicalFinanceCategoryName(String type, String name) {
    final normalizedType = _normalizeFinanceType(type);
    final trimmed = name.trim();
    final normalizedName = trimmed.toLowerCase();
    if (normalizedType == 'masuk') {
      return _legacyIncomeCategoryAliases[normalizedName] ?? trimmed;
    }
    return _legacyExpenseCategoryAliases[normalizedName] ?? trimmed;
  }

  Map<String, Object> _financeDefaultsForName(String type, String name) {
    final normalizedType = _normalizeFinanceType(type);
    final normalizedName =
        _canonicalFinanceCategoryName(normalizedType, name).toLowerCase();
    for (final item in _defaultFinanceCategories) {
      if ((item['type'] as String) == normalizedType &&
          (item['name'] as String).trim().toLowerCase() == normalizedName) {
        return item;
      }
    }
    return {
      'name': name,
      'type': normalizedType,
      'icon_key': normalizedType == 'masuk' ? 'wallet' : 'receipt',
      'color_hex': normalizedType == 'masuk' ? '#00A86B' : '#3A7D7C',
      'sort_order': 700,
    };
  }

  Future<void> _ensureFinanceCategorySchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS finance_categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL DEFAULT 'keluar',
        icon_key TEXT NOT NULL DEFAULT 'receipt',
        color_hex TEXT NOT NULL DEFAULT '#3A7D7C',
        is_system INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        sort_order INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL DEFAULT ''
      )
    ''');
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_finance_categories_type_name ON finance_categories(type, name)',
    );

    Future<void> addColumnIfMissing(String column, String definition) async {
      if (!await _hasColumn(db, 'finance_categories', column)) {
        await db
            .execute('ALTER TABLE finance_categories ADD COLUMN $definition;');
      }
    }

    await addColumnIfMissing('type', "type TEXT NOT NULL DEFAULT 'keluar'");
    await addColumnIfMissing(
        'icon_key', "icon_key TEXT NOT NULL DEFAULT 'receipt'");
    await addColumnIfMissing(
        'color_hex', "color_hex TEXT NOT NULL DEFAULT '#3A7D7C'");
    await addColumnIfMissing(
        'is_system', 'is_system INTEGER NOT NULL DEFAULT 0');
    await addColumnIfMissing(
        'is_active', 'is_active INTEGER NOT NULL DEFAULT 1');
    await addColumnIfMissing(
        'sort_order', 'sort_order INTEGER NOT NULL DEFAULT 0');
    await addColumnIfMissing(
        'created_at', "created_at TEXT NOT NULL DEFAULT ''");
    await addColumnIfMissing(
        'updated_at', "updated_at TEXT NOT NULL DEFAULT ''");

    await _seedDefaultFinanceCategories(db);
    await _migrateLegacyFinanceCategoryAliases(db);
    await _backfillFinanceCategoriesFromWallet(db);
  }

  Future<void> _seedDefaultFinanceCategories(DatabaseExecutor db) async {
    for (final item in _defaultFinanceCategories) {
      await _ensureFinanceCategoryForName(
        db,
        item['type'] as String,
        item['name'] as String,
        iconKey: item['icon_key'] as String,
        colorHex: item['color_hex'] as String,
        sortOrder: item['sort_order'] as int,
        isSystem: true,
      );
    }
  }

  Future<void> _migrateLegacyFinanceCategoryAliases(DatabaseExecutor db) async {
    if (!await _hasTable(db, 'wallet_transactions')) return;
    final aliasesByType = <String, Map<String, String>>{
      'masuk': _legacyIncomeCategoryAliases,
      'keluar': _legacyExpenseCategoryAliases,
    };

    for (final typeEntry in aliasesByType.entries) {
      final type = typeEntry.key;
      for (final aliasEntry in typeEntry.value.entries) {
        final legacyName = aliasEntry.key;
        final targetName = aliasEntry.value;
        if (legacyName == targetName.trim().toLowerCase()) continue;
        final targetId = await _ensureFinanceCategoryForName(
          db,
          type,
          targetName,
          isSystem: true,
        );
        final legacyRows = await db.query(
          'finance_categories',
          columns: ['id'],
          where: 'type = ? AND LOWER(TRIM(name)) = ?',
          whereArgs: [type, legacyName],
        );
        for (final row in legacyRows) {
          final legacyId = (row['id'] as num?)?.toInt();
          if (legacyId == null || legacyId == targetId) continue;
          await db.update(
            'wallet_transactions',
            {'category_id': targetId, 'kategori': targetName},
            where:
                'category_id = ? OR (type = ? AND LOWER(TRIM(kategori)) = ?)',
            whereArgs: [legacyId, type, legacyName],
          );
          await db.update(
            'finance_categories',
            {'is_active': 0, 'updated_at': DateTime.now().toIso8601String()},
            where: 'id = ?',
            whereArgs: [legacyId],
          );
        }
      }
    }
  }

  Future<int> _ensureFinanceCategoryForName(
    DatabaseExecutor db,
    String type,
    String name, {
    String? iconKey,
    String? colorHex,
    int? sortOrder,
    bool isSystem = false,
    bool activateExisting = false,
  }) async {
    final normalizedType = _normalizeFinanceType(type);
    final rawName = name.trim().isEmpty
        ? _fallbackFinanceCategoryName(normalizedType)
        : name.trim();
    final trimmedName = _canonicalFinanceCategoryName(normalizedType, rawName);
    final existing = await db.query(
      'finance_categories',
      columns: [
        'id',
        'is_system',
        'is_active',
        'icon_key',
        'color_hex',
        'sort_order'
      ],
      where: 'type = ? AND LOWER(TRIM(name)) = ?',
      whereArgs: [normalizedType, trimmedName.toLowerCase()],
      limit: 1,
    );
    final defaults = _financeDefaultsForName(normalizedType, trimmedName);
    final now = DateTime.now().toIso8601String();

    if (existing.isNotEmpty) {
      final id = (existing.first['id'] as num).toInt();
      final update = <String, Object?>{'updated_at': now};
      if (isSystem && (existing.first['is_system'] as num?)?.toInt() != 1) {
        update['is_system'] = 1;
      }
      if (activateExisting &&
          (existing.first['is_active'] as num?)?.toInt() != 1) {
        update['is_active'] = 1;
      }
      if ((iconKey ?? '').trim().isNotEmpty &&
          existing.first['icon_key']?.toString() != iconKey) {
        update['icon_key'] = iconKey;
      }
      if ((colorHex ?? '').trim().isNotEmpty &&
          existing.first['color_hex']?.toString() != colorHex) {
        update['color_hex'] = colorHex;
      }
      if (sortOrder != null &&
          (existing.first['sort_order'] as num?)?.toInt() != sortOrder) {
        update['sort_order'] = sortOrder;
      }
      if (update.length > 1) {
        await db.update('finance_categories', update,
            where: 'id = ?', whereArgs: [id]);
      }
      return id;
    }

    return await db.insert('finance_categories', {
      'name': trimmedName,
      'type': normalizedType,
      'icon_key': iconKey ?? defaults['icon_key'],
      'color_hex': colorHex ?? defaults['color_hex'],
      'is_system': isSystem ? 1 : 0,
      'is_active': 1,
      'sort_order': sortOrder ?? defaults['sort_order'],
      'created_at': now,
      'updated_at': now,
    });
  }

  Future<void> _backfillFinanceCategoriesFromWallet(DatabaseExecutor db) async {
    if (!await _hasTable(db, 'wallet_transactions')) return;
    if (!await _hasColumn(db, 'wallet_transactions', 'category_id')) return;

    final distinctRows = await db.rawQuery('''
      SELECT DISTINCT type, kategori
      FROM wallet_transactions
      WHERE TRIM(COALESCE(kategori, '')) != ''
    ''');
    for (final row in distinctRows) {
      await _ensureFinanceCategoryForName(
        db,
        row['type']?.toString() ?? 'keluar',
        row['kategori']?.toString() ?? '',
        isSystem: _isSystemFinanceCategoryName(
          row['type']?.toString() ?? 'keluar',
          row['kategori']?.toString() ?? '',
        ),
      );
    }

    final rows = await db.query(
      'wallet_transactions',
      columns: ['id', 'type', 'kategori', 'category_id'],
    );
    for (final row in rows) {
      final id = (row['id'] as num?)?.toInt();
      if (id == null) continue;
      final currentCategoryId = (row['category_id'] as num?)?.toInt();
      if (currentCategoryId != null && currentCategoryId > 0) {
        final exists = await db.query(
          'finance_categories',
          columns: ['id'],
          where: 'id = ?',
          whereArgs: [currentCategoryId],
          limit: 1,
        );
        if (exists.isNotEmpty) continue;
      }
      final type = row['type']?.toString() ?? 'keluar';
      final name = row['kategori']?.toString() ?? '';
      final categoryId = await _ensureFinanceCategoryForName(
        db,
        type,
        name,
        isSystem: _isSystemFinanceCategoryName(type, name),
      );
      await db.update(
        'wallet_transactions',
        {'category_id': categoryId},
        where: 'id = ?',
        whereArgs: [id],
      );
    }
  }

  bool _isSystemFinanceCategoryName(String type, String name) {
    final normalizedType = _normalizeFinanceType(type);
    final normalizedName =
        _canonicalFinanceCategoryName(normalizedType, name).toLowerCase();
    return _defaultFinanceCategories.any(
      (item) =>
          item['type'] == normalizedType &&
          (item['name'] as String).trim().toLowerCase() == normalizedName,
    );
  }

  Future<void> _ensureWalletTransactionSchema(Database db) async {
    final existing = _walletTransactionSchemaFuture;
    if (existing != null) return existing;

    final future = _performWalletTransactionSchemaEnsure(db);
    _walletTransactionSchemaFuture = future;
    try {
      await future;
    } catch (_) {
      if (identical(_walletTransactionSchemaFuture, future)) {
        _walletTransactionSchemaFuture = null;
      }
      rethrow;
    }
  }

  Future<void> _performWalletTransactionSchemaEnsure(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS wallet_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_id TEXT NOT NULL DEFAULT 'tunai',
        nominal INTEGER NOT NULL DEFAULT 0,
        type TEXT NOT NULL DEFAULT 'masuk',
        tanggal TEXT NOT NULL DEFAULT '',
        waktu TEXT NOT NULL DEFAULT '',
        keterangan TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT '',
        kategori TEXT NOT NULL DEFAULT '',
        category_id INTEGER,
        foto_path TEXT NOT NULL DEFAULT '',
        source TEXT NOT NULL DEFAULT 'manual',
        is_deleted INTEGER NOT NULL DEFAULT 0,
        deleted_at TEXT,
        updated_at TEXT
      )
    ''');

    Future<void> addColumnIfMissing(
      String column,
      String definition,
    ) async {
      if (!await _hasColumn(db, 'wallet_transactions', column)) {
        await db.execute(
          'ALTER TABLE wallet_transactions ADD COLUMN $definition;',
        );
      }
    }

    await addColumnIfMissing(
      'wallet_id',
      "wallet_id TEXT NOT NULL DEFAULT 'tunai'",
    );
    await addColumnIfMissing('nominal', 'nominal INTEGER NOT NULL DEFAULT 0');
    await addColumnIfMissing('type', "type TEXT NOT NULL DEFAULT 'masuk'");
    await addColumnIfMissing('tanggal', "tanggal TEXT NOT NULL DEFAULT ''");
    await addColumnIfMissing('waktu', "waktu TEXT NOT NULL DEFAULT ''");
    await addColumnIfMissing(
      'keterangan',
      "keterangan TEXT NOT NULL DEFAULT ''",
    );
    await addColumnIfMissing(
      'created_at',
      "created_at TEXT NOT NULL DEFAULT ''",
    );
    await addColumnIfMissing('kategori', "kategori TEXT NOT NULL DEFAULT ''");
    await addColumnIfMissing('category_id', 'category_id INTEGER');
    await addColumnIfMissing('foto_path', "foto_path TEXT NOT NULL DEFAULT ''");
    await addColumnIfMissing('source', "source TEXT NOT NULL DEFAULT 'manual'");
    await addColumnIfMissing(
      'is_deleted',
      'is_deleted INTEGER NOT NULL DEFAULT 0',
    );
    await addColumnIfMissing('deleted_at', 'deleted_at TEXT');
    await addColumnIfMissing('updated_at', 'updated_at TEXT');
    await db.execute('''
      UPDATE wallet_transactions
      SET updated_at = COALESCE(NULLIF(updated_at, ''), created_at)
      WHERE updated_at IS NULL OR TRIM(updated_at) = ''
    ''');

    await db.update(
      'wallet_transactions',
      {'source': 'system'},
      where: '''
        TRIM(COALESCE(kategori, '')) IN (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        OR keterangan LIKE ?
        OR keterangan LIKE ?
        OR keterangan LIKE ?
        OR keterangan LIKE ?
        OR keterangan LIKE ?
      ''',
      whereArgs: [
        'Servis',
        'Pelunasan',
        'Pembatalan',
        'Pemulihan',
        'Pembelian Stok',
        'Pembatalan Pembelian',
        'Refund Retur',
        'Refund',
        'Koreksi',
        'Cicilan',
        'Pemasukan Servis%',
        'Pelunasan%',
        'Pembatalan Penjualan%',
        'Refund Retur #%',
        '%Pembelian #%',
      ],
    );
    await db.update(
      'wallet_transactions',
      {'source': 'adjustment'},
      where: '''
        TRIM(COALESCE(kategori, '')) = ?
        OR keterangan LIKE ?
      ''',
      whereArgs: [
        'Koreksi',
        'Penyesuaian Saldo%',
      ],
    );
    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_wallet_transactions_active_history
      ON wallet_transactions(is_deleted, tanggal DESC, waktu DESC, created_at DESC)
    ''');
    await _ensureFinanceCategorySchema(db);
    await _backfillFinanceCategoriesFromWallet(db);
  }

  Future<void> _ensureCoreSchema(Database db) async {
    final existing = _coreSchemaFuture;
    if (existing != null) return existing;

    final future = _performCoreSchemaEnsure(db);
    _coreSchemaFuture = future;
    try {
      await future;
    } catch (_) {
      if (identical(_coreSchemaFuture, future)) {
        _coreSchemaFuture = null;
      }
      rethrow;
    }
  }

  Future<void> _performCoreSchemaEnsure(Database db) async {
    await _ensureCategorySchema(db);
    await _ensureWalletTransactionSchema(db);
    await _repairProductCategoryLinks(db);

    final hasTransactionsTable = await _hasTable(db, 'transactions');
    final hasTransactionItemsTable = await _hasTable(db, 'transaction_items');
    final hasKasirSessionsTable = await _hasTable(db, 'kasir_sessions');
    final hasLicenseTable = await _hasTable(db, 'license');
    final hasWarungProfileTable = await _hasTable(db, 'warung_profile');

    await _ensureAuditLogSchema(db);
    await _ensurePurchaseOrderSchema(db);

    if (!hasTransactionsTable) return;

    final hasTransactionUpdatedAt =
        await _hasColumn(db, 'transactions', 'updated_at');
    if (!hasTransactionUpdatedAt) {
      await db.execute("ALTER TABLE transactions ADD COLUMN updated_at TEXT;");
    }
    await db.execute('''
      UPDATE transactions
      SET updated_at = created_at
      WHERE updated_at IS NULL OR TRIM(updated_at) = ''
    ''');

    final hasTransactionCode = await _hasColumn(
      db,
      'transactions',
      'transaction_code',
    );
    if (!hasTransactionCode) {
      await db.execute(
        "ALTER TABLE transactions ADD COLUMN transaction_code TEXT;",
      );
    }

    final hasservisStatus =
        await _hasColumn(db, 'transactions', 'servis_status');
    if (!hasservisStatus) {
      await db.execute(
        "ALTER TABLE transactions ADD COLUMN servis_status TEXT NOT NULL DEFAULT 'Diterima';",
      );
    }

    final hasDueDate = await _hasColumn(db, 'transactions', 'due_date');
    if (!hasDueDate) {
      await db.execute("ALTER TABLE transactions ADD COLUMN due_date TEXT;");
    }

    final hasLastReminderAt =
        await _hasColumn(db, 'transactions', 'last_reminder_at');
    if (!hasLastReminderAt) {
      await db.execute(
        "ALTER TABLE transactions ADD COLUMN last_reminder_at TEXT;",
      );
    }

    final hasReminderCount =
        await _hasColumn(db, 'transactions', 'reminder_count');
    if (!hasReminderCount) {
      await db.execute(
        "ALTER TABLE transactions ADD COLUMN reminder_count INTEGER NOT NULL DEFAULT 0;",
      );
    }

    final hasFulfillmentType =
        await _hasColumn(db, 'transactions', 'fulfillment_type');
    if (!hasFulfillmentType) {
      await db.execute(
        "ALTER TABLE transactions ADD COLUMN fulfillment_type TEXT;",
      );
    }

    final hasServiceLevel =
        await _hasColumn(db, 'transactions', 'service_level');
    if (!hasServiceLevel) {
      await db.execute(
        "ALTER TABLE transactions ADD COLUMN service_level TEXT;",
      );
    }

    final hasSlaHours = await _hasColumn(db, 'transactions', 'sla_hours');
    if (!hasSlaHours) {
      await db.execute(
        "ALTER TABLE transactions ADD COLUMN sla_hours INTEGER NOT NULL DEFAULT 0;",
      );
    }

    if (hasKasirSessionsTable) {
      final hasStaffId = await _hasColumn(db, 'kasir_sessions', 'staff_id');
      if (!hasStaffId) {
        await db
            .execute("ALTER TABLE kasir_sessions ADD COLUMN staff_id INTEGER;");
      }

      final hasStaffName = await _hasColumn(db, 'kasir_sessions', 'staff_name');
      if (!hasStaffName) {
        await db
            .execute("ALTER TABLE kasir_sessions ADD COLUMN staff_name TEXT;");
      }

      final hasStaffRole = await _hasColumn(db, 'kasir_sessions', 'staff_role');
      if (!hasStaffRole) {
        await db
            .execute("ALTER TABLE kasir_sessions ADD COLUMN staff_role TEXT;");
      }

      final hasDeviceId = await _hasColumn(db, 'kasir_sessions', 'device_id');
      if (!hasDeviceId) {
        await db.execute(
          "ALTER TABLE kasir_sessions ADD COLUMN device_id TEXT NOT NULL DEFAULT '';",
        );
      }

      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_kasir_sessions_active_device ON kasir_sessions(device_id, closed_at, opened_at)',
      );
    }

    if (hasTransactionItemsTable) {
      final hasOriginalUnitPrice = await _hasColumn(
        db,
        'transaction_items',
        'original_unit_price',
      );
      if (!hasOriginalUnitPrice) {
        await db.execute(
          "ALTER TABLE transaction_items ADD COLUMN original_unit_price INTEGER NOT NULL DEFAULT 0;",
        );
      }

      final hasAppliedDiscountName = await _hasColumn(
        db,
        'transaction_items',
        'applied_discount_name',
      );
      if (!hasAppliedDiscountName) {
        await db.execute(
          "ALTER TABLE transaction_items ADD COLUMN applied_discount_name TEXT;",
        );
      }

      final hasAppliedDiscountIsPercentage = await _hasColumn(
        db,
        'transaction_items',
        'applied_discount_is_percentage',
      );
      if (!hasAppliedDiscountIsPercentage) {
        await db.execute(
          "ALTER TABLE transaction_items ADD COLUMN applied_discount_is_percentage INTEGER NOT NULL DEFAULT 0;",
        );
      }

      final hasAppliedDiscountValue = await _hasColumn(
        db,
        'transaction_items',
        'applied_discount_value',
      );
      if (!hasAppliedDiscountValue) {
        await db.execute(
          "ALTER TABLE transaction_items ADD COLUMN applied_discount_value INTEGER NOT NULL DEFAULT 0;",
        );
      }

      final hasIsPriceOverride = await _hasColumn(
        db,
        'transaction_items',
        'is_price_override',
      );
      if (!hasIsPriceOverride) {
        await db.execute(
          "ALTER TABLE transaction_items ADD COLUMN is_price_override INTEGER NOT NULL DEFAULT 0;",
        );
      }

      final hasOriginalSubtotal = await _hasColumn(
        db,
        'transaction_items',
        'original_subtotal',
      );
      if (!hasOriginalSubtotal) {
        await db.execute(
          "ALTER TABLE transaction_items ADD COLUMN original_subtotal INTEGER NOT NULL DEFAULT 0;",
        );
      }

      final hasPriceOverrideAmount = await _hasColumn(
        db,
        'transaction_items',
        'price_override_amount',
      );
      if (!hasPriceOverrideAmount) {
        await db.execute(
          "ALTER TABLE transaction_items ADD COLUMN price_override_amount INTEGER NOT NULL DEFAULT 0;",
        );
      }

      // Add 'unit' column (e.g. 'kg', 'pcs', etc.)
      final hasUnit = await _hasColumn(db, 'transaction_items', 'unit');
      if (!hasUnit) {
        await db.execute(
          "ALTER TABLE transaction_items ADD COLUMN unit TEXT;",
        );
      }

      // Add 'is_hardware' column (1 = layanan/weight-based, 0 = piece-based)
      final hasIsHardware =
          await _hasColumn(db, 'transaction_items', 'is_hardware');
      if (!hasIsHardware) {
        await db.execute(
          "ALTER TABLE transaction_items ADD COLUMN is_hardware INTEGER NOT NULL DEFAULT 0;",
        );
      }

      await db.execute(
        "UPDATE transaction_items SET original_unit_price = unit_price WHERE original_unit_price = 0;",
      );
      await db.execute(
        "UPDATE transaction_items SET original_subtotal = subtotal WHERE original_subtotal = 0;",
      );
    }

    final hasProductsTable = await _hasTable(db, 'products');
    if (hasProductsTable) {
      final hasDurationHours =
          await _hasColumn(db, 'products', 'duration_hours');
      if (!hasDurationHours) {
        await db.execute(
            "ALTER TABLE products ADD COLUMN duration_hours INTEGER DEFAULT 0;");
      }
      await _ensureProductMaterialSchema(db);
      await _ensureProductSupplierSchema(db);
    }

    await _ensureMaterialRecipeSchema(db);

    final hasCustomersTable = await _hasTable(db, 'customers');
    if (hasCustomersTable) {
      final hasMemberCode = await _hasColumn(db, 'customers', 'member_code');
      if (!hasMemberCode) {
        await db.execute("ALTER TABLE customers ADD COLUMN member_code TEXT;");
      }
      final hasWhatsappValidatedAt =
          await _hasColumn(db, 'customers', 'whatsapp_validated_at');
      if (!hasWhatsappValidatedAt) {
        await db.execute(
          "ALTER TABLE customers ADD COLUMN whatsapp_validated_at TEXT;",
        );
      }
      final hasWhatsappValidatedPhone =
          await _hasColumn(db, 'customers', 'whatsapp_validated_phone');
      if (!hasWhatsappValidatedPhone) {
        await db.execute(
          "ALTER TABLE customers ADD COLUMN whatsapp_validated_phone TEXT;",
        );
      }
    }

    final hasCategoriesTable = await _hasTable(db, 'categories');
    if (hasCategoriesTable) {
      final hasCatDuration =
          await _hasColumn(db, 'categories', 'duration_hours');
      if (!hasCatDuration) {
        await db.execute(
          "ALTER TABLE categories ADD COLUMN duration_hours INTEGER DEFAULT 0;",
        );
      }
    }

    if (hasLicenseTable) {
      final hasCanRemotePrint =
          await _hasColumn(db, 'license', 'can_remote_print');
      if (!hasCanRemotePrint) {
        await db.execute(
          "ALTER TABLE license ADD COLUMN can_remote_print INTEGER NOT NULL DEFAULT 0;",
        );
      }

      final hasIsTrial = await _hasColumn(db, 'license', 'is_trial');
      if (!hasIsTrial) {
        await db.execute(
          "ALTER TABLE license ADD COLUMN is_trial INTEGER NOT NULL DEFAULT 0;",
        );
      }

      final hasLdrPrintCount =
          await _hasColumn(db, 'license', 'ldr_print_count');
      if (!hasLdrPrintCount) {
        await db.execute(
          "ALTER TABLE license ADD COLUMN ldr_print_count INTEGER NOT NULL DEFAULT 0;",
        );
      }
    }

    final storeRows = hasWarungProfileTable
        ? await db.query('warung_profile', columns: ['nama'], limit: 1)
        : const <Map<String, Object?>>[];
    final storeName =
        storeRows.isNotEmpty ? storeRows.first['nama'] as String? : null;
    // Background update for missing transaction codes to avoid blocking UI startup
    unawaited(() async {
      try {
        final txRows = await db.query(
          'transactions',
          columns: ['id', 'created_at', 'transaction_code'],
          where: "transaction_code IS NULL OR TRIM(transaction_code) = ''",
        );
        if (txRows.isNotEmpty) {
          debugPrint(
              '[DB] Background updating ${txRows.length} transaction codes...');
          final batch = db.batch();
          for (final row in txRows) {
            final txId = row['id'] as int?;
            if (txId == null) continue;
            batch.update(
              'transactions',
              {
                'transaction_code': TransactionCodeFormatter.format(
                  id: txId,
                  createdAt: row['created_at'] as String? ?? '',
                  storeName: storeName,
                ),
              },
              where: 'id = ?',
              whereArgs: [txId],
            );
          }
          await batch.commit(noResult: true);
          debugPrint('[DB] Background update completed.');
        }
      } catch (e) {
        debugPrint('[DB] Background update error: $e');
      }
    }());

    await _ensureWorkshopSchema(db);
    await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_transactions_code ON transactions (transaction_code)');
    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_transactions_active_history
      ON transactions(is_deleted, created_at DESC)
    ''');
    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_transactions_active_status
      ON transactions(is_deleted, servis_status, created_at DESC)
    ''');
    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_transactions_active_payment
      ON transactions(is_deleted, payment_method, created_at DESC)
    ''');
  }

  Future<void> _ensureAuditLogSchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id INTEGER,
        staff_id INTEGER,
        staff_name TEXT NOT NULL DEFAULT 'Sistem',
        staff_role TEXT NOT NULL DEFAULT '',
        amount INTEGER NOT NULL DEFAULT 0,
        note TEXT NOT NULL DEFAULT '',
        metadata_json TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    final columns = await db.rawQuery('PRAGMA table_info(audit_logs)');
    bool hasColumn(String column) =>
        columns.any((entry) => entry['name'] == column);

    if (!hasColumn('action')) {
      await db.execute(
        "ALTER TABLE audit_logs ADD COLUMN action TEXT NOT NULL DEFAULT '';",
      );
    }
    if (!hasColumn('entity_type')) {
      await db.execute(
        "ALTER TABLE audit_logs ADD COLUMN entity_type TEXT NOT NULL DEFAULT '';",
      );
    }
    if (!hasColumn('entity_id')) {
      await db.execute("ALTER TABLE audit_logs ADD COLUMN entity_id INTEGER;");
    }
    if (!hasColumn('staff_id')) {
      await db.execute("ALTER TABLE audit_logs ADD COLUMN staff_id INTEGER;");
    }
    if (!hasColumn('staff_name')) {
      await db.execute(
        "ALTER TABLE audit_logs ADD COLUMN staff_name TEXT NOT NULL DEFAULT 'Sistem';",
      );
    }
    if (!hasColumn('staff_role')) {
      await db.execute(
        "ALTER TABLE audit_logs ADD COLUMN staff_role TEXT NOT NULL DEFAULT '';",
      );
    }
    if (!hasColumn('amount')) {
      await db.execute(
        "ALTER TABLE audit_logs ADD COLUMN amount INTEGER NOT NULL DEFAULT 0;",
      );
    }
    if (!hasColumn('note')) {
      await db.execute(
        "ALTER TABLE audit_logs ADD COLUMN note TEXT NOT NULL DEFAULT '';",
      );
    }
    if (!hasColumn('metadata_json')) {
      await db.execute(
        "ALTER TABLE audit_logs ADD COLUMN metadata_json TEXT;",
      );
    }
    if (!hasColumn('created_at')) {
      await db.execute(
        "ALTER TABLE audit_logs ADD COLUMN created_at TEXT NOT NULL DEFAULT '';",
      );
    }

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action)',
    );
  }

  Future<void> _ensureMaterialRecipeSchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS product_recipes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        service_product_id INTEGER NOT NULL,
        material_product_id INTEGER NOT NULL,
        qty_per_unit REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (service_product_id) REFERENCES products (id) ON DELETE CASCADE,
        FOREIGN KEY (material_product_id) REFERENCES products (id)
      )
    ''');
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_product_recipes_service ON product_recipes(service_product_id)',
    );

    await db.execute('''
      CREATE TABLE IF NOT EXISTS transaction_material_usages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id INTEGER NOT NULL,
        service_product_id INTEGER NOT NULL,
        material_product_id INTEGER NOT NULL,
        material_name TEXT NOT NULL DEFAULT '',
        qty INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (transaction_id) REFERENCES transactions (id),
        FOREIGN KEY (service_product_id) REFERENCES products (id),
        FOREIGN KEY (material_product_id) REFERENCES products (id)
      )
    ''');
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_material_usages_transaction ON transaction_material_usages(transaction_id)',
    );
  }

  Future<void> _ensureProductMaterialSchema(DatabaseExecutor db) async {
    final hasProductsTable = await _hasTable(db, 'products');
    if (!hasProductsTable) return;
    final hasIsMaterial = await _hasColumn(db, 'products', 'is_material');
    if (!hasIsMaterial) {
      await db.execute(
        "ALTER TABLE products ADD COLUMN is_material INTEGER NOT NULL DEFAULT 0;",
      );
    }
  }

  Future<void> _ensureProductSupplierSchema(DatabaseExecutor db) async {
    if (!await _hasTable(db, 'products')) return;
    final hasSupplierId = await _hasColumn(db, 'products', 'supplier_id');
    if (!hasSupplierId) {
      await db.execute("ALTER TABLE products ADD COLUMN supplier_id INTEGER;");
    }
  }

  Future<void> _ensurePurchaseOrderSchema(DatabaseExecutor db) async {
    final purchaseOrderInfo =
        await db.rawQuery("PRAGMA table_info(purchase_orders)");
    if (purchaseOrderInfo.isNotEmpty) {
      final hasPaidAmount =
          purchaseOrderInfo.any((entry) => entry['name'] == 'paid_amount');
      if (!hasPaidAmount) {
        await db.execute(
          "ALTER TABLE purchase_orders ADD COLUMN paid_amount INTEGER NOT NULL DEFAULT 0;",
        );
        await db.execute(
          "UPDATE purchase_orders SET paid_amount = total_amount WHERE is_paid = 1 AND paid_amount = 0;",
        );
      }
    }

    final purchaseItemInfo =
        await db.rawQuery("PRAGMA table_info(purchase_items)");
    if (purchaseItemInfo.isNotEmpty) {
      final hasReceivedQty =
          purchaseItemInfo.any((entry) => entry['name'] == 'received_qty');
      if (!hasReceivedQty) {
        await db.execute(
          "ALTER TABLE purchase_items ADD COLUMN received_qty INTEGER NOT NULL DEFAULT 0;",
        );
        await db.execute('''
          UPDATE purchase_items
          SET received_qty = qty
          WHERE purchase_order_id IN (
            SELECT id FROM purchase_orders WHERE status = 'received'
          )
        ''');
      }
    }
  }

  Future<void> _ensureWorkshopSchema(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS fnb_tables (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        area TEXT NOT NULL DEFAULT 'Ruang Utama',
        seats INTEGER NOT NULL DEFAULT 2,
        status TEXT NOT NULL DEFAULT 'available',
        active_transaction_id INTEGER,
        merged_to_table_id INTEGER,
        qr_slug TEXT NOT NULL DEFAULT '',
        sort_order INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (active_transaction_id) REFERENCES transactions (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS fnb_kitchen_tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id INTEGER NOT NULL,
        table_name TEXT NOT NULL DEFAULT '',
        customer_name TEXT,
        order_type TEXT,
        status TEXT NOT NULL DEFAULT 'queued',
        station TEXT NOT NULL DEFAULT 'Workshop',
        note TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (transaction_id) REFERENCES transactions (id)
      )
    ''');

    final tableCountRows =
        await db.rawQuery('SELECT COUNT(*) as count FROM fnb_tables');
    final tableCount = (tableCountRows.first['count'] as num?)?.toInt() ?? 0;
    if (tableCount == 0) {
      await _seedDefaultWorkshopStations(db);
    }
  }

  Future<void> _seedDefaultWorkshopStations(DatabaseExecutor db) async {
    final now = DateTime.now().toIso8601String();
    final defaults = <Map<String, dynamic>>[
      {'name': 'Stasiun 1', 'area': 'Workshop', 'seats': 1, 'sort_order': 1},
      {'name': 'Stasiun 2', 'area': 'Workshop', 'seats': 1, 'sort_order': 2},
      {'name': 'Stasiun 3', 'area': 'Workshop', 'seats': 1, 'sort_order': 3},
      {
        'name': 'Area Diagnosa',
        'area': 'Workshop',
        'seats': 1,
        'sort_order': 4
      },
      {
        'name': 'Area Pengerjaan',
        'area': 'Workshop',
        'seats': 1,
        'sort_order': 5
      },
      {'name': 'Area QC', 'area': 'Workshop', 'seats': 1, 'sort_order': 6},
    ];

    for (final row in defaults) {
      final slug =
          '${row['area']}-${row['name']}'.toLowerCase().replaceAll(' ', '-');
      await db.insert('fnb_tables', {
        ...row,
        'status': 'available',
        'active_transaction_id': null,
        'merged_to_table_id': null,
        'qr_slug': slug,
        'updated_at': now,
      });
    }
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute('ALTER TABLE products ADD COLUMN image_path TEXT;');
    }
    if (oldVersion < 3) {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS customers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          phone TEXT,
          address TEXT,
          created_at TEXT NOT NULL
        )
      ''');
      await db.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          customer_id INTEGER,
          customer_name TEXT,
          total_amount INTEGER NOT NULL DEFAULT 0,
          discount_amount INTEGER NOT NULL DEFAULT 0,
          grand_total INTEGER NOT NULL DEFAULT 0,
          payment_method TEXT NOT NULL DEFAULT 'cash',
          amount_paid INTEGER NOT NULL DEFAULT 0,
          change_amount INTEGER NOT NULL DEFAULT 0,
          note TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT,
          FOREIGN KEY (customer_id) REFERENCES customers (id)
        )
      ''');
      await db.execute('''
        CREATE TABLE IF NOT EXISTS transaction_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          transaction_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          product_name TEXT NOT NULL,
          qty INTEGER NOT NULL DEFAULT 0,
          unit_price INTEGER NOT NULL DEFAULT 0,
          subtotal INTEGER NOT NULL DEFAULT 0,
          FOREIGN KEY (transaction_id) REFERENCES transactions (id),
          FOREIGN KEY (product_id) REFERENCES products (id)
        )
      ''');
    }
    if (oldVersion < 4) {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS wallet_transactions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          wallet_id TEXT NOT NULL DEFAULT 'tunai',
          nominal INTEGER NOT NULL DEFAULT 0,
          type TEXT NOT NULL DEFAULT 'masuk',
          tanggal TEXT NOT NULL,
          waktu TEXT NOT NULL,
          keterangan TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL,
          kategori TEXT NOT NULL DEFAULT '',
          foto_path TEXT NOT NULL DEFAULT '',
          source TEXT NOT NULL DEFAULT 'manual',
          is_deleted INTEGER NOT NULL DEFAULT 0,
          deleted_at TEXT
        )
      ''');
    }
    if (oldVersion < 5) {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS profil (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          nama TEXT NOT NULL DEFAULT '',
          foto_path TEXT NOT NULL DEFAULT ''
        )
      ''');
    }
    if (oldVersion < 6) {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS employees (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'Kasir',
          phone TEXT,
          pin TEXT,
          permissions_json TEXT,
          created_at TEXT NOT NULL
        )
      ''');
      await db.execute('''
        CREATE TABLE IF NOT EXISTS warung_profile (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          nama TEXT NOT NULL DEFAULT '',
          alamat TEXT NOT NULL DEFAULT '',
          telepon TEXT NOT NULL DEFAULT '',
          catatan TEXT NOT NULL DEFAULT '',
          logo_path TEXT NOT NULL DEFAULT '',
          updated_at TEXT NOT NULL
        )
      ''');
    }
    if (oldVersion < 7) {
      await db.execute('ALTER TABLE products ADD COLUMN description TEXT;');
      await db.execute('ALTER TABLE products ADD COLUMN sku TEXT;');
      await db.execute('ALTER TABLE products ADD COLUMN barcode TEXT;');
      await db.execute(
          'ALTER TABLE products ADD COLUMN has_stock_management INTEGER NOT NULL DEFAULT 0;');
      await db.execute(
          'ALTER TABLE products ADD COLUMN has_wholesale INTEGER NOT NULL DEFAULT 0;');
      await db.execute(
          'ALTER TABLE products ADD COLUMN is_extra INTEGER NOT NULL DEFAULT 0;');
    }
    if (oldVersion < 8) {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS cicilans (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          transaction_id INTEGER NOT NULL,
          nominal INTEGER NOT NULL DEFAULT 0,
          metode_pembayaran TEXT NOT NULL DEFAULT 'tunai',
          created_at TEXT NOT NULL,
          FOREIGN KEY (transaction_id) REFERENCES transactions (id)
        )
      ''');
    }
    if (oldVersion < 9) {
      await db.execute('ALTER TABLE stock_logs ADD COLUMN stock_name TEXT;');
      await db.execute('ALTER TABLE stock_logs ADD COLUMN entry_date TEXT;');
      await db.execute('ALTER TABLE stock_logs ADD COLUMN expiry_date TEXT;');
      await db.execute('ALTER TABLE stock_logs ADD COLUMN new_qty INTEGER;');
      await db.execute('ALTER TABLE stock_logs ADD COLUMN employee_name TEXT;');
      await db
          .execute('ALTER TABLE stock_logs ADD COLUMN employee_id INTEGER;');
    }
    if (oldVersion < 10) {
      await db.execute(
          'ALTER TABLE products ADD COLUMN extra_target_categories TEXT;');
      await db.execute(
          'ALTER TABLE products ADD COLUMN extra_target_products TEXT;');
    }
    if (oldVersion < 11) {
      await db.execute(
          'ALTER TABLE transactions ADD COLUMN additional_charges INTEGER NOT NULL DEFAULT 0;');
    }
    if (oldVersion < 12) {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS discounts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          nominal INTEGER NOT NULL DEFAULT 0,
          is_percentage INTEGER NOT NULL DEFAULT 0,
          start_date TEXT NOT NULL,
          end_date TEXT NOT NULL,
          product_ids TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL
        )
      ''');
    }
    if (oldVersion < 13) {
      await db.execute(
          'ALTER TABLE products ADD COLUMN has_extra_popup INTEGER NOT NULL DEFAULT 0;');
    }
    if (oldVersion < 14) {
      await db.execute('ALTER TABLE transaction_items ADD COLUMN note TEXT;');
    }
    if (oldVersion < 15) {
      // Check if additional_charges exists first (safeguard for botched v11)
      var tableInfo = await db.rawQuery("PRAGMA table_info(transactions)");
      bool hasCharges =
          tableInfo.any((column) => column['name'] == 'additional_charges');
      if (!hasCharges) {
        await db.execute(
            'ALTER TABLE transactions ADD COLUMN additional_charges INTEGER NOT NULL DEFAULT 0;');
      }
      await db.execute(
          'ALTER TABLE transactions ADD COLUMN additional_charges_json TEXT;');
    }
    if (oldVersion < 16) {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS payment_settings (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          qris_path TEXT NOT NULL DEFAULT '',
          bank_name TEXT NOT NULL DEFAULT '',
          account_name TEXT NOT NULL DEFAULT '',
          account_number TEXT NOT NULL DEFAULT ''
        )
      ''');
    }
    if (oldVersion < 17) {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS kasir_sessions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          kasir_name TEXT NOT NULL DEFAULT '',
          opened_at TEXT NOT NULL,
          closed_at TEXT,
          opening_cash INTEGER NOT NULL DEFAULT 0,
          closing_cash INTEGER NOT NULL DEFAULT 0,
          total_transactions INTEGER NOT NULL DEFAULT 0,
          total_revenue INTEGER NOT NULL DEFAULT 0,
          total_cash INTEGER NOT NULL DEFAULT 0,
          total_non_cash INTEGER NOT NULL DEFAULT 0,
          notes TEXT,
          staff_id INTEGER,
          staff_name TEXT,
          staff_role TEXT,
          device_id TEXT NOT NULL DEFAULT ''
        )
      ''');
    }
    if (oldVersion < 18) {
      await db.execute(
          'ALTER TABLE products ADD COLUMN wholesale_min_qty INTEGER NOT NULL DEFAULT 0;');
      await db.execute(
          'ALTER TABLE products ADD COLUMN wholesale_price INTEGER NOT NULL DEFAULT 0;');
      await db.execute(
          'ALTER TABLE transactions ADD COLUMN is_deleted INTEGER NOT NULL DEFAULT 0;');
      await db.execute('ALTER TABLE transactions ADD COLUMN deleted_at TEXT;');
    }
    if (oldVersion < 19) {
      // Extend wallet_transactions with kategori & foto_path
      if (!await _hasColumn(db, 'wallet_transactions', 'kategori')) {
        await db.execute(
            "ALTER TABLE wallet_transactions ADD COLUMN kategori TEXT NOT NULL DEFAULT '';");
      }
      if (!await _hasColumn(db, 'wallet_transactions', 'foto_path')) {
        await db.execute(
            "ALTER TABLE wallet_transactions ADD COLUMN foto_path TEXT NOT NULL DEFAULT '';");
      }

      // Suppliers
      await db.execute('''
        CREATE TABLE IF NOT EXISTS suppliers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          phone TEXT,
          address TEXT,
          hutang INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL
        )
      ''');

      // Purchase Orders
      await db.execute('''
        CREATE TABLE IF NOT EXISTS purchase_orders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          supplier_id INTEGER,
          supplier_name TEXT NOT NULL DEFAULT '',
          total_amount INTEGER NOT NULL DEFAULT 0,
          status TEXT NOT NULL DEFAULT 'draft',
          note TEXT,
          created_at TEXT NOT NULL,
          received_at TEXT,
          is_paid INTEGER NOT NULL DEFAULT 0,
          FOREIGN KEY (supplier_id) REFERENCES suppliers (id)
        )
      ''');

      // Purchase Items
      await db.execute('''
        CREATE TABLE IF NOT EXISTS purchase_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          purchase_order_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          product_name TEXT NOT NULL,
          qty INTEGER NOT NULL DEFAULT 0,
          unit_price INTEGER NOT NULL DEFAULT 0,
          subtotal INTEGER NOT NULL DEFAULT 0,
          FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders (id),
          FOREIGN KEY (product_id) REFERENCES products (id)
        )
      ''');
    }
    if (oldVersion < 20) {
      // Customer discount_pct
      await db.execute(
          "ALTER TABLE customers ADD COLUMN discount_pct REAL NOT NULL DEFAULT 0;");

      // Return transactions table
      await db.execute('''
        CREATE TABLE IF NOT EXISTS return_transactions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          transaction_id INTEGER NOT NULL,
          customer_name TEXT,
          reason TEXT NOT NULL DEFAULT '',
          refund_method TEXT NOT NULL DEFAULT 'tunai',
          total_refund INTEGER NOT NULL DEFAULT 0,
          note TEXT,
          created_at TEXT NOT NULL,
          FOREIGN KEY (transaction_id) REFERENCES transactions (id)
        )
      ''');

      // Return items table
      await db.execute('''
        CREATE TABLE IF NOT EXISTS return_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          return_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          product_name TEXT NOT NULL,
          qty INTEGER NOT NULL DEFAULT 0,
          unit_price INTEGER NOT NULL DEFAULT 0,
          subtotal INTEGER NOT NULL DEFAULT 0,
          FOREIGN KEY (return_id) REFERENCES return_transactions (id),
          FOREIGN KEY (product_id) REFERENCES products (id)
        )
      ''');
    }
    if (oldVersion < 21) {
      // Add shift_name to KasirSession
      var tableInfo = await db.rawQuery("PRAGMA table_info(kasir_sessions)");
      bool hasShiftName =
          tableInfo.any((column) => column['name'] == 'shift_name');
      if (!hasShiftName) {
        await db
            .execute('ALTER TABLE kasir_sessions ADD COLUMN shift_name TEXT;');
      }
    }
    if (oldVersion < 22) {
      // Add social media to warung_profile
      var tableInfo = await db.rawQuery("PRAGMA table_info(warung_profile)");
      bool hasInstagram =
          tableInfo.any((column) => column['name'] == 'instagram');
      if (!hasInstagram) {
        await db.execute(
            "ALTER TABLE warung_profile ADD COLUMN instagram TEXT NOT NULL DEFAULT '';");
        await db.execute(
            "ALTER TABLE warung_profile ADD COLUMN facebook TEXT NOT NULL DEFAULT '';");
        await db.execute(
            "ALTER TABLE warung_profile ADD COLUMN tiktok TEXT NOT NULL DEFAULT '';");
      }
    }
    if (oldVersion < 23) {
      // Add keterangan to suppliers
      var tableInfo = await db.rawQuery("PRAGMA table_info(suppliers)");
      bool hasKeterangan =
          tableInfo.any((column) => column['name'] == 'keterangan');
      if (!hasKeterangan) {
        await db.execute(
            "ALTER TABLE suppliers ADD COLUMN keterangan TEXT DEFAULT '';");
      }
    }
    if (oldVersion < 24) {
      // Add expiry_date to products kolom ini ada di Product.toMap() tapi tidak pernah
      // ditambahkan ke schema maupun migrasi sebelumnya, menyebabkan insertProduct gagal
      var tableInfo = await db.rawQuery('PRAGMA table_info(products)');
      bool hasExpiryDate =
          tableInfo.any((column) => column['name'] == 'expiry_date');
      if (!hasExpiryDate) {
        await db.execute('ALTER TABLE products ADD COLUMN expiry_date TEXT;');
      }
    }
    if (oldVersion < 25) {
      // Add is_active to employees
      var tableInfo = await db.rawQuery("PRAGMA table_info(employees)");
      bool hasActive = tableInfo.any((column) => column['name'] == 'is_active');
      if (!hasActive) {
        await db.execute(
            'ALTER TABLE employees ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1;');
      }
    }
    if (oldVersion < 26) {
      final tableInfo = await db.rawQuery("PRAGMA table_info(license)");
      bool hasLicenseId =
          tableInfo.any((column) => column['name'] == 'license_id');
      bool hasSerial = tableInfo.any((column) => column['name'] == 'serial');
      bool hasLastValidated =
          tableInfo.any((column) => column['name'] == 'last_validated_at');
      bool hasValidationExpires =
          tableInfo.any((column) => column['name'] == 'validation_expires_at');
      bool hasSignature =
          tableInfo.any((column) => column['name'] == 'signature');

      if (!hasLicenseId) {
        await db.execute(
            "ALTER TABLE license ADD COLUMN license_id TEXT DEFAULT '';");
      }
      if (!hasSerial) {
        await db
            .execute("ALTER TABLE license ADD COLUMN serial TEXT DEFAULT '';");
      }
      if (!hasLastValidated) {
        await db
            .execute("ALTER TABLE license ADD COLUMN last_validated_at TEXT;");
      }
      if (!hasValidationExpires) {
        await db.execute(
            "ALTER TABLE license ADD COLUMN validation_expires_at TEXT;");
      }
      if (!hasSignature) {
        await db.execute(
            "ALTER TABLE license ADD COLUMN signature TEXT NOT NULL DEFAULT '';");
      }
    }
    if (oldVersion < 28) {
      await db.execute('''
        CREATE TABLE IF NOT EXISTS resi_print_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tracking_number TEXT NOT NULL DEFAULT '',
          courier TEXT NOT NULL DEFAULT '',
          source TEXT NOT NULL DEFAULT 'manual',
          created_at TEXT NOT NULL
        )
      ''');
    }
    if (oldVersion < 29) {
      final tableInfo = await db.rawQuery("PRAGMA table_info(profil)");
      final hasAdminPin =
          tableInfo.any((column) => column['name'] == 'admin_pin');
      final hasAdminPinHash =
          tableInfo.any((column) => column['name'] == 'admin_pin_hash');

      if (!hasAdminPin) {
        await db.execute(
          "ALTER TABLE profil ADD COLUMN admin_pin TEXT NOT NULL DEFAULT '';",
        );
      }
      if (!hasAdminPinHash) {
        await db.execute(
          "ALTER TABLE profil ADD COLUMN admin_pin_hash TEXT NOT NULL DEFAULT '';",
        );
      }
    }
    if (oldVersion < 30) {
      final tableInfo =
          await db.rawQuery("PRAGMA table_info(payment_settings)");
      final hasBanksJson =
          tableInfo.any((column) => column['name'] == 'banks_json');
      if (!hasBanksJson) {
        await db.execute(
            "ALTER TABLE payment_settings ADD COLUMN banks_json TEXT;");
      }
    }
    if (oldVersion < 31) {
      final tableInfo = await db.rawQuery("PRAGMA table_info(transactions)");
      final columnsToAdd = ['order_type', 'pickup_schedule', 'payment_status'];
      for (final col in columnsToAdd) {
        if (!tableInfo.any((column) => column['name'] == col)) {
          await db.execute("ALTER TABLE transactions ADD COLUMN $col TEXT;");
        }
      }
    }
    if (oldVersion < 32) {
      final tableInfo =
          await db.rawQuery("PRAGMA table_info(payment_settings)");
      final hasQrisName =
          tableInfo.any((column) => column['name'] == 'qris_name');
      if (!hasQrisName) {
        await db.execute(
            "ALTER TABLE payment_settings ADD COLUMN qris_name TEXT NOT NULL DEFAULT '';");
      }
    }
    if (oldVersion < 33) {
      final tableInfo = await db.rawQuery("PRAGMA table_info(transactions)");
      final hasQueueNumber =
          tableInfo.any((column) => column['name'] == 'queue_number');
      if (!hasQueueNumber) {
        await db.execute(
            "ALTER TABLE transactions ADD COLUMN queue_number INTEGER NOT NULL DEFAULT 0;");
      }
    }
    if (oldVersion < 34) {
      await _ensureCoreSchema(db);
    }
    if (oldVersion < 35) {
      await _ensureCoreSchema(db);
    }
    if (oldVersion < 36) {
      await _ensureCoreSchema(db);
    }
    if (oldVersion < 37) {
      await _ensureWorkshopSchema(db);
    }
    if (oldVersion < 38) {
      final hasIsHardware = await _hasColumn(db, 'products', 'is_hardware');
      if (!hasIsHardware) {
        await db.execute(
            "ALTER TABLE products ADD COLUMN is_hardware INTEGER NOT NULL DEFAULT 0;");
      }

      final hasservisStatus =
          await _hasColumn(db, 'transactions', 'servis_status');
      if (!hasservisStatus) {
        await db.execute(
            "ALTER TABLE transactions ADD COLUMN servis_status TEXT NOT NULL DEFAULT 'Diterima';");
      }

      final hasKelengkapan = await _hasColumn(db, 'transactions', 'kelengkapan');
      if (!hasKelengkapan) {
        await db.execute("ALTER TABLE transactions ADD COLUMN kelengkapan TEXT;");
      }
    }
    if (oldVersion < 39) {
      // Re-create transaction_items with REAL qty if needed, or just alter logic.
      // SQLite allows storing REAL in INTEGER column, but for clarity:
      // Note: ALTER TABLE doesn't support changing type.
      // We will just ensure code handles double.
    }
    if (oldVersion < 41) {
      final hasAddress = await _hasColumn(db, 'transactions', 'address');
      if (!hasAddress) {
        await db.execute("ALTER TABLE transactions ADD COLUMN address TEXT;");
      }
    }
    if (oldVersion < 43) {
      await _ensureMaterialRecipeSchema(db);
    }
    if (oldVersion < 44) {
      await _ensureProductMaterialSchema(db);
    }
    if (oldVersion < 45) {
      await _ensureCategorySchema(db);
      await _repairProductCategoryLinks(db);
    }
    if (oldVersion < 46) {
      await _ensurePurchaseOrderSchema(db);
    }
    if (oldVersion < 47) {
      await _ensureProductSupplierSchema(db);
    }
    if (oldVersion < 48) {
      final hasCustomersTable = await _hasTable(db, 'customers');
      if (hasCustomersTable) {
        final hasWhatsappValidatedAt =
            await _hasColumn(db, 'customers', 'whatsapp_validated_at');
        if (!hasWhatsappValidatedAt) {
          await db.execute(
            "ALTER TABLE customers ADD COLUMN whatsapp_validated_at TEXT;",
          );
        }
        final hasWhatsappValidatedPhone =
            await _hasColumn(db, 'customers', 'whatsapp_validated_phone');
        if (!hasWhatsappValidatedPhone) {
          await db.execute(
            "ALTER TABLE customers ADD COLUMN whatsapp_validated_phone TEXT;",
          );
        }
      }
    }
    if (oldVersion < 49) {
      final hasEmployeesTable = await _hasTable(db, 'employees');
      if (hasEmployeesTable) {
        final hasPermissionsJson =
            await _hasColumn(db, 'employees', 'permissions_json');
        if (!hasPermissionsJson) {
          await db.execute(
              "ALTER TABLE employees ADD COLUMN permissions_json TEXT;");
        }
      }
    }
    if (oldVersion < 51) {
      await db.execute(
          'ALTER TABLE products ADD COLUMN is_deleted INTEGER NOT NULL DEFAULT 0;');
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE license (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        license_id TEXT,
        serial TEXT,
        serial_hash TEXT NOT NULL,
        device_id TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        expired_at TEXT,
        last_validated_at TEXT,
        validation_expires_at TEXT,
        signature TEXT NOT NULL DEFAULT '',
        can_remote_print INTEGER NOT NULL DEFAULT 0,
        is_trial INTEGER NOT NULL DEFAULT 0,
        ldr_print_count INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        duration_hours INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await _ensureDefaultCategory(db);

    await db.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category_id INTEGER NOT NULL DEFAULT 1,
        stock INTEGER NOT NULL DEFAULT 0,
        buy_price INTEGER NOT NULL DEFAULT 0,
        sell_price INTEGER NOT NULL DEFAULT 0,
        unit TEXT NOT NULL DEFAULT 'pcs',
        min_stock INTEGER NOT NULL DEFAULT 5,
        created_at TEXT NOT NULL,
        image_path TEXT,
        description TEXT,
        sku TEXT,
        barcode TEXT,
        has_stock_management INTEGER NOT NULL DEFAULT 0,
        has_wholesale INTEGER NOT NULL DEFAULT 0,
        wholesale_min_qty INTEGER NOT NULL DEFAULT 0,
        wholesale_price INTEGER NOT NULL DEFAULT 0,
        has_extra_popup INTEGER NOT NULL DEFAULT 0,
        is_extra INTEGER NOT NULL DEFAULT 0,
        extra_target_categories TEXT,
        extra_target_products TEXT,
        expiry_date TEXT,
        is_hardware INTEGER NOT NULL DEFAULT 0,
        duration_hours INTEGER NOT NULL DEFAULT 0,
        is_material INTEGER NOT NULL DEFAULT 0,
        supplier_id INTEGER,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (category_id) REFERENCES categories (id)
      )
    ''');
    await db.execute('''
      CREATE TABLE stock_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        type TEXT NOT NULL,
        qty INTEGER NOT NULL DEFAULT 0,
        date TEXT NOT NULL,
        stock_name TEXT,
        entry_date TEXT,
        expiry_date TEXT,
        old_qty INTEGER,
        new_qty INTEGER,
        employee_name TEXT,
        FOREIGN KEY (product_id) REFERENCES products (id)
      )
    ''');
    await _ensureMaterialRecipeSchema(db);
    await db.execute('''
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        address TEXT,
        discount_pct REAL NOT NULL DEFAULT 0,
        member_code TEXT,
        whatsapp_validated_at TEXT,
        whatsapp_validated_phone TEXT,
        created_at TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        customer_name TEXT,
        total_amount INTEGER NOT NULL DEFAULT 0,
        discount_amount INTEGER NOT NULL DEFAULT 0,
        additional_charges INTEGER NOT NULL DEFAULT 0,
        additional_charges_json TEXT,
        grand_total INTEGER NOT NULL DEFAULT 0,
        payment_method TEXT NOT NULL DEFAULT 'cash',
        amount_paid INTEGER NOT NULL DEFAULT 0,
        change_amount INTEGER NOT NULL DEFAULT 0,
        note TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        deleted_at TEXT,
        order_type TEXT,
        pickup_schedule TEXT,
        fulfillment_type TEXT,
        service_level TEXT,
        sla_hours INTEGER NOT NULL DEFAULT 0,
        payment_status TEXT,
        queue_number INTEGER NOT NULL DEFAULT 0,
        transaction_code TEXT,
        servis_status TEXT NOT NULL DEFAULT 'Diterima',
        kelengkapan TEXT,
        address TEXT,
        due_date TEXT,
        last_reminder_at TEXT,
        reminder_count INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (customer_id) REFERENCES customers (id)
      )
    ''');
    await db.execute('''
      CREATE TABLE audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id INTEGER,
        staff_id INTEGER,
        staff_name TEXT NOT NULL DEFAULT 'Sistem',
        staff_role TEXT NOT NULL DEFAULT '',
        amount INTEGER NOT NULL DEFAULT 0,
        note TEXT NOT NULL DEFAULT '',
        metadata_json TEXT,
        created_at TEXT NOT NULL
      )
    ''');
    await db.execute(
      'CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at DESC)',
    );
    await db.execute(
      'CREATE INDEX idx_audit_logs_action ON audit_logs(action)',
    );
    await db.execute('''
      CREATE TABLE transaction_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        qty REAL NOT NULL DEFAULT 0,
        unit_price INTEGER NOT NULL DEFAULT 0,
        original_unit_price INTEGER NOT NULL DEFAULT 0,
        original_subtotal INTEGER NOT NULL DEFAULT 0,
        price_override_amount INTEGER NOT NULL DEFAULT 0,
        subtotal INTEGER NOT NULL DEFAULT 0,
        note TEXT,
        applied_discount_name TEXT,
        applied_discount_is_percentage INTEGER NOT NULL DEFAULT 0,
        applied_discount_value INTEGER NOT NULL DEFAULT 0,
        is_price_override INTEGER NOT NULL DEFAULT 0,
        unit TEXT,
        is_hardware INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (transaction_id) REFERENCES transactions (id),
        FOREIGN KEY (product_id) REFERENCES products (id)
      )
    ''');
    await db.execute('''
      CREATE TABLE profil (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL DEFAULT '',
        foto_path TEXT NOT NULL DEFAULT '',
        admin_pin TEXT NOT NULL DEFAULT '',
        admin_pin_hash TEXT NOT NULL DEFAULT ''
      )
    ''');
    await db.execute('''
      CREATE TABLE wallet_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        wallet_id TEXT NOT NULL DEFAULT 'tunai',
        nominal INTEGER NOT NULL DEFAULT 0,
        type TEXT NOT NULL DEFAULT 'masuk',
        tanggal TEXT NOT NULL,
        waktu TEXT NOT NULL,
        keterangan TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        kategori TEXT NOT NULL DEFAULT '',
        foto_path TEXT NOT NULL DEFAULT '',
        source TEXT NOT NULL DEFAULT 'manual',
        is_deleted INTEGER NOT NULL DEFAULT 0,
        deleted_at TEXT,
        updated_at TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE employees (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'Kasir',
        phone TEXT,
        pin TEXT,
        permissions_json TEXT,
        created_at TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1
      )
    ''');
    await db.execute('''
      CREATE TABLE warung_profile (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL DEFAULT '',
        alamat TEXT NOT NULL DEFAULT '',
        telepon TEXT NOT NULL DEFAULT '',
        catatan TEXT NOT NULL DEFAULT '',
        logo_path TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL,
        instagram TEXT NOT NULL DEFAULT '',
        facebook TEXT NOT NULL DEFAULT '',
        tiktok TEXT NOT NULL DEFAULT ''
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS cicilans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id INTEGER NOT NULL,
        nominal INTEGER NOT NULL DEFAULT 0,
        metode_pembayaran TEXT NOT NULL DEFAULT 'tunai',
        created_at TEXT NOT NULL,
        FOREIGN KEY (transaction_id) REFERENCES transactions (id)
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS discounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        nominal INTEGER NOT NULL DEFAULT 0,
        is_percentage INTEGER NOT NULL DEFAULT 0,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        product_ids TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS payment_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        qris_path TEXT NOT NULL DEFAULT '',
        bank_name TEXT NOT NULL DEFAULT '',
        account_name TEXT NOT NULL DEFAULT '',
        account_number TEXT NOT NULL DEFAULT '',
        banks_json TEXT,
        qris_name TEXT NOT NULL DEFAULT ''
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS kasir_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kasir_name TEXT NOT NULL DEFAULT '',
        opened_at TEXT NOT NULL,
        closed_at TEXT,
        opening_cash INTEGER NOT NULL DEFAULT 0,
        closing_cash INTEGER NOT NULL DEFAULT 0,
        total_transactions INTEGER NOT NULL DEFAULT 0,
        total_revenue INTEGER NOT NULL DEFAULT 0,
        total_cash INTEGER NOT NULL DEFAULT 0,
        total_non_cash INTEGER NOT NULL DEFAULT 0,
        notes TEXT,
        shift_name TEXT,
        staff_id INTEGER,
        staff_name TEXT,
        staff_role TEXT,
        device_id TEXT NOT NULL DEFAULT ''
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        address TEXT,
        hutang INTEGER NOT NULL DEFAULT 0,
        keterangan TEXT DEFAULT '',
        created_at TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS purchase_orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        supplier_id INTEGER,
        supplier_name TEXT NOT NULL DEFAULT '',
        total_amount INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'draft',
        note TEXT,
        created_at TEXT NOT NULL,
        received_at TEXT,
        is_paid INTEGER NOT NULL DEFAULT 0,
        paid_amount INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (supplier_id) REFERENCES suppliers (id)
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS purchase_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        purchase_order_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        qty INTEGER NOT NULL DEFAULT 0,
        unit_price INTEGER NOT NULL DEFAULT 0,
        subtotal INTEGER NOT NULL DEFAULT 0,
        received_qty INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders (id),
        FOREIGN KEY (product_id) REFERENCES products (id)
      )
    ''');
    // Return transactions
    await db.execute('''
      CREATE TABLE IF NOT EXISTS return_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id INTEGER NOT NULL,
        customer_name TEXT,
        reason TEXT NOT NULL DEFAULT '',
        refund_method TEXT NOT NULL DEFAULT 'tunai',
        total_refund INTEGER NOT NULL DEFAULT 0,
        note TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (transaction_id) REFERENCES transactions (id)
      )
    ''');
    // Return items
    await db.execute('''
      CREATE TABLE IF NOT EXISTS return_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        return_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        qty INTEGER NOT NULL DEFAULT 0,
        unit_price INTEGER NOT NULL DEFAULT 0,
        subtotal INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (return_id) REFERENCES return_transactions (id),
        FOREIGN KEY (product_id) REFERENCES products (id)
      )
    ''');
    // Resi Print Logs
    await db.execute('''
      CREATE TABLE IF NOT EXISTS resi_print_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tracking_number TEXT NOT NULL DEFAULT '',
        courier TEXT NOT NULL DEFAULT '',
        source TEXT NOT NULL DEFAULT 'manual',
        created_at TEXT NOT NULL
      )
    ''');
    await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_transactions_code ON transactions (transaction_code)');
  }

  // ============== LICENSE ==================
  Future<int> insertLicense(License license) async {
    final db = await database;
    await db.delete('license');
    return await db.insert('license', license.toMap());
  }

  Future<License?> getLicense() async {
    final db = await database;
    final maps = await db.query('license', limit: 1);
    if (maps.isNotEmpty) return License.fromMap(maps.first);
    return null;
  }

  Future<void> deleteLicense() async {
    final db = await database;
    await db.delete('license');
  }

  // ============== CATEGORIES ================
  Future<List<Category>> getCategories() async {
    final db = await database;
    await _ensureCategorySchema(db);
    final result = await db.query(
      'categories',
      orderBy:
          "CASE WHEN LOWER(TRIM(name)) = '${defaultCategoryName.toLowerCase()}' THEN 0 ELSE 1 END, name COLLATE NOCASE ASC",
    );
    return result.map((m) => Category.fromMap(m)).toList();
  }

  Future<int> insertCategory(String name, {int durationHours = 0}) async {
    final db = await database;
    await _ensureCategorySchema(db);
    final trimmedName = name.trim();
    if (trimmedName.isEmpty || isDefaultCategoryName(trimmedName)) {
      return _ensureDefaultCategory(db);
    }

    final existing = await db.query(
      'categories',
      columns: ['id'],
      where: 'LOWER(TRIM(name)) = LOWER(TRIM(?))',
      whereArgs: [trimmedName],
      limit: 1,
    );
    final existingId = existing.isEmpty ? null : _asInt(existing.first['id']);
    if (existingId != null) return existingId;

    return await db.insert('categories', {
      'name': trimmedName,
      'duration_hours': durationHours,
    });
  }

  Future<int> countProductsByCategory(int categoryId) async {
    final db = await database;
    final result = await db.rawQuery(
        'SELECT COUNT(*) as count FROM products WHERE category_id = ? AND is_deleted = 0',
        [categoryId]);
    return result.isNotEmpty ? (result.first['count'] as int) : 0;
  }

  Future<Map<int, int>> getAllCategoryProductCounts() async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT category_id, COUNT(*) as count 
      FROM products 
      WHERE is_deleted = 0
      GROUP BY category_id
    ''');

    final Map<int, int> counts = {};
    for (var row in result) {
      counts[row['category_id'] as int] = row['count'] as int;
    }
    return counts;
  }

  Future<void> deleteCategory(int id) async {
    final db = await database;
    await _ensureCategorySchema(db);
    final rows = await db.query(
      'categories',
      columns: ['id', 'name'],
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    if (rows.isEmpty) return;
    if (isDefaultCategoryName(rows.first['name'] as String?)) {
      throw Exception('Kategori "Semua" adalah kategori sistem.');
    }

    await db.transaction((txn) async {
      final fallbackId = await _ensureDefaultCategory(txn);
      await txn.update(
        'products',
        {'category_id': fallbackId},
        where: 'category_id = ?',
        whereArgs: [id],
      );
      await txn.delete('categories', where: 'id = ?', whereArgs: [id]);
    });
  }

  Future<void> updateCategory(int id, String name, {int? durationHours}) async {
    final db = await database;
    await _ensureCategorySchema(db);
    final existing = await db.query(
      'categories',
      columns: ['id', 'name'],
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    if (existing.isEmpty) return;
    if (isDefaultCategoryName(existing.first['name'] as String?)) {
      throw Exception('Kategori "Semua" adalah kategori sistem.');
    }

    final trimmedName = name.trim();
    if (trimmedName.isEmpty) {
      throw Exception('Nama kategori tidak boleh kosong.');
    }
    if (isDefaultCategoryName(trimmedName)) {
      throw Exception('Nama "Semua" dipakai untuk kategori sistem.');
    }

    final duplicate = await db.query(
      'categories',
      columns: ['id'],
      where: 'LOWER(TRIM(name)) = LOWER(TRIM(?)) AND id != ?',
      whereArgs: [trimmedName, id],
      limit: 1,
    );
    if (duplicate.isNotEmpty) {
      throw Exception('Nama kategori sudah ada.');
    }

    final Map<String, dynamic> values = {'name': trimmedName};
    if (durationHours != null) {
      values['duration_hours'] = durationHours;
    }
    await db.update('categories', values, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> resolveProductCategoryId({
    int? categoryId,
    String? categoryName,
  }) async {
    final db = await database;
    return _ensureProductCategory(
      db,
      categoryId,
      categoryName: categoryName,
    );
  }

  // ============== FINANCE CATEGORIES ================
  Future<List<FinanceCategory>> getFinanceCategories({
    String? type,
    bool includeInactive = false,
  }) async {
    final db = await database;
    await _ensureFinanceCategorySchema(db);
    final whereParts = <String>[];
    final whereArgs = <Object?>[];
    if (type != null && type.trim().isNotEmpty) {
      whereParts.add('type = ?');
      whereArgs.add(_normalizeFinanceType(type));
    }
    if (!includeInactive) whereParts.add('is_active = 1');
    final rows = await db.query(
      'finance_categories',
      where: whereParts.isEmpty ? null : whereParts.join(' AND '),
      whereArgs: whereArgs.isEmpty ? null : whereArgs,
      orderBy:
          'type ASC, is_active DESC, sort_order ASC, is_system DESC, name ASC',
    );
    return rows.map((row) => FinanceCategory.fromMap(row)).toList();
  }

  Future<FinanceCategory?> getFinanceCategoryById(int id) async {
    final db = await database;
    await _ensureFinanceCategorySchema(db);
    final rows = await db.query(
      'finance_categories',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return FinanceCategory.fromMap(rows.first);
  }

  Future<int> resolveFinanceCategoryId({
    required String type,
    required String name,
  }) async {
    final db = await database;
    await _ensureFinanceCategorySchema(db);
    return _ensureFinanceCategoryForName(db, type, name);
  }

  Future<int> insertFinanceCategory(FinanceCategory category) async {
    final db = await database;
    await _ensureFinanceCategorySchema(db);
    final type = _normalizeFinanceType(category.type);
    final name = category.name.trim();
    if (name.isEmpty) throw ArgumentError('Nama kategori wajib diisi.');
    if (_isSystemFinanceCategoryName(type, name)) {
      return _ensureFinanceCategoryForName(
        db,
        type,
        name,
        isSystem: true,
        activateExisting: true,
      );
    }
    return _ensureFinanceCategoryForName(
      db,
      type,
      name,
      iconKey: category.iconKey,
      colorHex: category.colorHex,
      sortOrder: category.sortOrder,
      activateExisting: true,
    );
  }

  Future<void> updateFinanceCategory(FinanceCategory category) async {
    if (category.id == null) {
      throw ArgumentError('Finance category id is required.');
    }
    final db = await database;
    await _ensureFinanceCategorySchema(db);
    final current = await getFinanceCategoryById(category.id!);
    if (current == null) throw StateError('Kategori tidak ditemukan.');
    if (current.system) throw StateError('Kategori sistem tidak bisa diubah.');
    final type = _normalizeFinanceType(category.type);
    final name = category.name.trim();
    if (name.isEmpty) throw ArgumentError('Nama kategori wajib diisi.');
    final duplicate = await db.query(
      'finance_categories',
      columns: ['id'],
      where: 'id != ? AND type = ? AND LOWER(TRIM(name)) = ?',
      whereArgs: [category.id, type, name.toLowerCase()],
      limit: 1,
    );
    if (duplicate.isNotEmpty) throw StateError('Nama kategori sudah dipakai.');

    await db.transaction((txn) async {
      await txn.update(
        'finance_categories',
        {
          'name': name,
          'type': type,
          'icon_key': category.iconKey,
          'color_hex': category.colorHex,
          'is_active': category.isActive,
          'sort_order': category.sortOrder,
          'updated_at': DateTime.now().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [category.id],
      );
      await txn.update(
        'wallet_transactions',
        {'kategori': name},
        where: 'category_id = ? OR (type = ? AND LOWER(TRIM(kategori)) = ?)',
        whereArgs: [category.id, current.type, current.name.toLowerCase()],
      );
    });
  }

  Future<void> setFinanceCategoryActive(int id, bool active) async {
    final db = await database;
    await _ensureFinanceCategorySchema(db);
    final current = await getFinanceCategoryById(id);
    if (current == null) throw StateError('Kategori tidak ditemukan.');
    if (current.system && !active) {
      throw StateError('Kategori sistem tidak bisa dinonaktifkan.');
    }
    await db.update(
      'finance_categories',
      {
        'is_active': active ? 1 : 0,
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // ============== PRODUCTS =================
  Future<int> insertProduct(Product product) async {
    final db = await database;
    final map = product.toMap();
    map['category_id'] = await _ensureProductCategory(
      db,
      _asInt(map['category_id']),
    );
    return await db.insert('products', map);
  }

  Future<List<Product>> getAllProducts() async {
    final db = await database;
    final result = await db.query('products',
        where: 'is_deleted = 0', orderBy: 'name ASC');
    return result.map((m) => Product.fromMap(m)).toList();
  }

  Future<Product?> getProductById(int id) async {
    final db = await database;
    final result =
        await db.query('products', where: 'id = ?', whereArgs: [id], limit: 1);
    if (result.isNotEmpty) return Product.fromMap(result.first);
    return null;
  }

  Future<List<Product>> getLowStockProducts() async {
    final db = await database;
    final result = await db.rawQuery(
        'SELECT * FROM products WHERE stock <= min_stock AND has_stock_management = 1 AND is_deleted = 0 ORDER BY stock ASC');
    return result.map((m) => Product.fromMap(m)).toList();
  }

  Future<int> updateProduct(Product product) async {
    final db = await database;
    final map = product.toMap();
    map['category_id'] = await _ensureProductCategory(
      db,
      _asInt(map['category_id']),
    );
    return await db
        .update('products', map, where: 'id = ?', whereArgs: [product.id]);
  }

  Future<void> deleteProduct(int id) async {
    final db = await database;
    try {
      await db.transaction((txn) async {
        await txn.delete('product_recipes',
            where: 'service_product_id = ? OR material_product_id = ?',
            whereArgs: [id, id]);
        await txn
            .delete('stock_logs', where: 'product_id = ?', whereArgs: [id]);
        await txn.delete('products', where: 'id = ?', whereArgs: [id]);
      });
    } catch (e) {
      if (e.toString().contains('FOREIGN KEY')) {
        await db.update('products', {'is_deleted': 1},
            where: 'id = ?', whereArgs: [id]);
      } else {
        rethrow;
      }
    }
  }

  Future<void> deleteProducts(List<int> ids) async {
    if (ids.isEmpty) return;
    final db = await database;
    for (final id in ids) {
      try {
        await db.transaction((txn) async {
          await txn.delete('product_recipes',
              where: 'service_product_id = ? OR material_product_id = ?',
              whereArgs: [id, id]);
          await txn
              .delete('stock_logs', where: 'product_id = ?', whereArgs: [id]);
          await txn.delete('products', where: 'id = ?', whereArgs: [id]);
        });
      } catch (e) {
        if (e.toString().contains('FOREIGN KEY')) {
          await db.update('products', {'is_deleted': 1},
              where: 'id = ?', whereArgs: [id]);
        } else {
          rethrow;
        }
      }
    }
  }

  Future<List<ProductRecipe>> getProductRecipes(int serviceProductId) async {
    final db = await database;
    await _ensureMaterialRecipeSchema(db);
    final rows = await db.query(
      'product_recipes',
      where: 'service_product_id = ?',
      whereArgs: [serviceProductId],
      orderBy: 'id ASC',
    );
    return rows.map(ProductRecipe.fromMap).toList();
  }

  Future<void> replaceProductRecipes(
    int serviceProductId,
    List<ProductRecipe> recipes,
  ) async {
    final db = await database;
    await _ensureMaterialRecipeSchema(db);
    await db.transaction((txn) async {
      await txn.delete(
        'product_recipes',
        where: 'service_product_id = ?',
        whereArgs: [serviceProductId],
      );
      final now = DateTime.now().toIso8601String();
      for (final recipe in recipes) {
        if (recipe.materialProductId <= 0 || recipe.qtyPerUnit <= 0) continue;
        if (recipe.materialProductId == serviceProductId) continue;
        await txn.insert('product_recipes', {
          'service_product_id': serviceProductId,
          'material_product_id': recipe.materialProductId,
          'qty_per_unit': recipe.qtyPerUnit,
          'created_at': recipe.createdAt.isEmpty ? now : recipe.createdAt,
        });
      }
    });
  }

  // ============== STOCK LOGS ===============
  Future<int> insertStockLog(StockLog log) async {
    final db = await database;
    final p =
        await db.query('products', where: 'id = ?', whereArgs: [log.productId]);
    if (p.isNotEmpty) {
      final product = Product.fromMap(p.first);
      int oldStock = product.stock;
      int newStock = product.stock;
      if (log.type == 'in') {
        newStock += log.qty;
      } else {
        newStock = (newStock - log.qty).clamp(0, 999999);
      }
      await db.update('products', {'stock': newStock},
          where: 'id = ?', whereArgs: [log.productId]);
      // Build log with old/new qty populated
      final logWithQty = StockLog(
        productId: log.productId,
        type: log.type,
        qty: log.qty,
        date: log.date,
        stockName: log.stockName,
        entryDate: log.entryDate,
        expiryDate: log.expiryDate,
        oldQty: oldStock,
        newQty: newStock,
        employeeName: log.employeeName,
      );
      return await db.insert('stock_logs', logWithQty.toMap());
    }
    return await db.insert('stock_logs', log.toMap());
  }

  Future<List<StockLog>> getStockLogsForProduct(int productId) async {
    final db = await database;
    final result = await db.query('stock_logs',
        where: 'product_id = ?',
        whereArgs: [productId],
        orderBy: 'date DESC',
        limit: 50);
    return result.map((m) => StockLog.fromMap(m)).toList();
  }

  Future<List<StockLog>> getAllStockLogs({int limit = 100}) async {
    final db = await database;
    final result =
        await db.query('stock_logs', orderBy: 'date DESC', limit: limit);
    return result.map((m) => StockLog.fromMap(m)).toList();
  }

  /// Returns stock logs for a date range filtered by local date string prefix
  Future<List<Map<String, dynamic>>> getStockLogsWithProduct({
    required String datePrefix,
  }) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT sl.*, p.name as product_name, p.image_path as image_path,
             p.is_material as is_material
      FROM stock_logs sl
      JOIN products p ON p.id = sl.product_id
      WHERE sl.date LIKE ? AND p.has_stock_management = 1
      ORDER BY sl.date DESC
    ''', ['$datePrefix%']);
    return result;
  }

  Future<List<Map<String, dynamic>>> getAllStockLogsWithProduct(
      {int limit = 500}) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT sl.*, p.name as product_name, p.image_path as image_path,
             p.is_material as is_material
      FROM stock_logs sl
      JOIN products p ON p.id = sl.product_id
      WHERE p.has_stock_management = 1
      ORDER BY sl.date DESC
      LIMIT ?
    ''', [limit]);
    return result;
  }

  // ============== ANALYTICS ================

  /// Ringkasan hari ini (tanggal lokal format: yyyy-MM-dd)
  Future<Map<String, int>> getDailySummary(String dateStr) async {
    final db = await database;
    final logs = await db.query('stock_logs',
        where: "type = 'out' AND date LIKE ?", whereArgs: ['$dateStr%']);

    int totalSales = 0;
    int totalProfit = 0;
    int transactionCount = logs.length;

    final allProducts = await getAllProducts();
    final prodMap = {for (var p in allProducts) p.id: p};

    for (var log in logs) {
      final sl = StockLog.fromMap(log);
      final p = prodMap[sl.productId];
      if (p != null) {
        totalSales += p.sellPrice * sl.qty;
        totalProfit += (p.sellPrice - p.buyPrice) * sl.qty;
      }
    }
    return {
      'sales': totalSales,
      'profit': totalProfit,
      'count': transactionCount
    };
  }

  /// Top produk terlaris berdasarkan total qty keluar
  Future<List<Map<String, dynamic>>> getTopSellingProducts(
      {int limit = 5}) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT p.id, p.name, p.unit, p.image_path, SUM(sl.qty) as total_sold
      FROM stock_logs sl
      JOIN products p ON p.id = sl.product_id
      WHERE sl.type = 'out'
      GROUP BY sl.product_id
      ORDER BY total_sold DESC
      LIMIT ?
    ''', [limit]);
    return result;
  }

  /// Agregasi penjualan N hari terakhir untuk grafik
  Future<List<Map<String, dynamic>>> getSalesByPeriod({int days = 7}) async {
    final db = await database;
    final cutoffDate = DateTime.now().subtract(Duration(days: days));
    final cutoffStr = cutoffDate.toIso8601String().substring(0, 10);

    final logs = await db.query('stock_logs',
        where: "type = 'out' AND date >= ?", whereArgs: [cutoffStr]);
    final allProducts = await getAllProducts();
    final prodMap = {for (var p in allProducts) p.id: p};

    int totalSales = 0;
    int totalProfit = 0;
    int count = logs.length;

    Map<int, Map<String, dynamic>> perProduct = {};
    for (var log in logs) {
      final sl = StockLog.fromMap(log);
      final p = prodMap[sl.productId];
      if (p != null) {
        totalSales += p.sellPrice * sl.qty;
        totalProfit += (p.sellPrice - p.buyPrice) * sl.qty;
        if (!perProduct.containsKey(p.id)) {
          perProduct[p.id!] = {
            'name': p.name,
            'qty': 0,
            'sales': 0,
            'profit': 0
          };
        }
        perProduct[p.id!]!['qty'] = (perProduct[p.id!]!['qty'] as int) + sl.qty;
        perProduct[p.id!]!['sales'] =
            (perProduct[p.id!]!['sales'] as int) + (p.sellPrice * sl.qty);
        perProduct[p.id!]!['profit'] = (perProduct[p.id!]!['profit'] as int) +
            ((p.sellPrice - p.buyPrice) * sl.qty);
      }
    }

    return [
      {'total_sales': totalSales, 'total_profit': totalProfit, 'count': count},
      ...perProduct.values.toList()
        ..sort((a, b) => (b['sales'] as int).compareTo(a['sales'] as int)),
    ];
  }

  /// Data harian untuk grafik 7 hari terakhir
  Future<List<Map<String, dynamic>>> getWeeklySalesChartData() async {
    return getSalesTrendData('last_7_days');
  }

  /// Data Penjualan Fleksibel (Hari, Minggu, Bulan, Tahun)
  Future<List<Map<String, dynamic>>> getSalesTrendData(String period) async {
    final db = await database;
    final List<Map<String, dynamic>> res = [];
    final now = DateTime.now();

    if (period == 'today') {
      // Per Jam untuk hari ini (00:00 - 23:59)
      final dateStr = now.toIso8601String().substring(0, 10);
      for (int i = 0; i < 24; i++) {
        final hourStr = i.toString().padLeft(2, '0');
        final result = await db.rawQuery(
          'SELECT COALESCE(SUM(grand_total), 0) as sales '
          'FROM transactions WHERE is_deleted = 0 AND created_at LIKE ?',
          ['$dateStr $hourStr:%'],
        );
        res.add({
          'key': hourStr,
          'sales': (result.first['sales'] as num?)?.toInt() ?? 0,
          'label': '$hourStr:00',
        });
      }
    } else if (period == 'last_7_days') {
      // Per Hari (7 hari terakhir)
      for (int i = 6; i >= 0; i--) {
        final date = now.subtract(Duration(days: i));
        final dateStr = date.toIso8601String().substring(0, 10);
        final result = await db.rawQuery(
          'SELECT COALESCE(SUM(grand_total), 0) as sales '
          'FROM transactions WHERE is_deleted = 0 AND created_at LIKE ?',
          ['$dateStr%'],
        );
        res.add({
          'key': dateStr,
          'sales': (result.first['sales'] as num?)?.toInt() ?? 0,
          'label': _getDayLabel(date),
        });
      }
    } else if (period == 'month') {
      // Per Hari untuk bulan berjalan
      final daysInMonth = DateTime(now.year, now.month + 1, 0).day;
      final monthStr = now.toIso8601String().substring(0, 7);
      for (int i = 1; i <= daysInMonth; i++) {
        final dayStr = i.toString().padLeft(2, '0');
        final result = await db.rawQuery(
          'SELECT COALESCE(SUM(grand_total), 0) as sales '
          'FROM transactions WHERE is_deleted = 0 AND created_at LIKE ?',
          ['$monthStr-$dayStr%'],
        );
        res.add({
          'key': '$monthStr-$dayStr',
          'sales': (result.first['sales'] as num?)?.toInt() ?? 0,
          'label': '$i',
        });
      }
    } else if (period == 'year') {
      // Per Bulan untuk tahun berjalan
      final yearStr = now.year.toString();
      final monthNames = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'Mei',
        'Jun',
        'Jul',
        'Agt',
        'Sep',
        'Okt',
        'Nov',
        'Des'
      ];
      for (int i = 1; i <= 12; i++) {
        final monthIdx = i.toString().padLeft(2, '0');
        final result = await db.rawQuery(
          'SELECT COALESCE(SUM(grand_total), 0) as sales '
          'FROM transactions WHERE is_deleted = 0 AND created_at LIKE ?',
          ['$yearStr-$monthIdx%'],
        );
        res.add({
          'key': monthIdx,
          'sales': (result.first['sales'] as num?)?.toInt() ?? 0,
          'label': monthNames[i - 1],
        });
      }
    }
    return res;
  }

  /// Statistik Penjualan per Kategori (Dashboard Widget)
  Future<List<Map<String, dynamic>>> getCategorySalesStatistics() async {
    final db = await database;
    // Ambil top 5 kategori berdasarkan omzet
    return await db.rawQuery('''
      SELECT c.name, COALESCE(SUM(ti.subtotal), 0) as sales
      FROM categories c
      LEFT JOIN products p ON p.category_id = c.id
      LEFT JOIN transaction_items ti ON ti.product_id = p.id
      LEFT JOIN transactions t ON t.id = ti.transaction_id
      WHERE t.is_deleted = 0 OR t.id IS NULL
      GROUP BY c.id
      ORDER BY sales DESC
      LIMIT 5
    ''');
  }

  String _getDayLabel(DateTime date) {
    final now = DateTime.now();
    if (date.day == now.day &&
        date.month == now.month &&
        date.year == now.year) {
      return 'Hari Ini';
    }
    final days = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
    return days[date.weekday % 7];
  }

  // ============== ANALISIS LAPORAN ================

  /// Mengambil statistik komprehensif penjualan untuk rentang waktu tertentu
  Future<Map<String, dynamic>> getSalesStatsReport(
      DateTime start, DateTime end) async {
    final db = await database;
    final startIso = start.toIso8601String();
    final endIso = end.toIso8601String();

    // Transaksi Lunas & Omzet
    final lunasSummary = await db.rawQuery(
      '''
      SELECT COUNT(*) as count, COALESCE(SUM(grand_total), 0) as omzet
      FROM transactions
      WHERE created_at >= ? AND created_at <= ? AND amount_paid >= grand_total
      ''',
      [startIso, endIso],
    );

    // Produk Terjual & Profit (dari Lunas saja, atau semua? Biasa semua atau lunas. Mari asumsikan dari lunas)
    final itemSummary = await db.rawQuery(
      '''
      SELECT COALESCE(SUM(ti.qty), 0) as products,
             COALESCE(SUM((ti.unit_price - COALESCE(p.buy_price, 0)) * ti.qty), 0) as profit
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      LEFT JOIN products p ON p.id = ti.product_id
      WHERE t.created_at >= ? AND t.created_at <= ? AND t.amount_paid >= t.grand_total
      ''',
      [startIso, endIso],
    );

    // Transaksi Piutang (Total, Piutang Terbayar, Sisa Piutang)
    final piutangSummary = await db.rawQuery(
      '''
      SELECT COUNT(*) as count, 
             COALESCE(SUM(grand_total), 0) as total_piutang,
             COALESCE(SUM(amount_paid), 0) as piutang_terbayar
      FROM transactions
      WHERE created_at >= ? AND created_at <= ? AND amount_paid < grand_total
      ''',
      [startIso, endIso],
    );

    final totalPiutang =
        (piutangSummary.first['total_piutang'] as num?)?.toInt() ?? 0;
    final piutangTerbayar =
        (piutangSummary.first['piutang_terbayar'] as num?)?.toInt() ?? 0;

    return {
      'lunas_count': (lunasSummary.first['count'] as num?)?.toInt() ?? 0,
      'omzet': (lunasSummary.first['omzet'] as num?)?.toInt() ?? 0,
      'products': (itemSummary.first['products'] as num?)?.toInt() ?? 0,
      'profit': (itemSummary.first['profit'] as num?)?.toInt() ?? 0,
      'piutang_count': (piutangSummary.first['count'] as num?)?.toInt() ?? 0,
      'total_piutang': totalPiutang,
      'piutang_terbayar': piutangTerbayar,
      'sisa_piutang': totalPiutang - piutangTerbayar,
    };
  }

  /// Mengambil rekaman omzet lunas per bulan untuk grafik Bar Chart
  Future<List<double>> getMonthlyOmzetReport(int year) async {
    final db = await database;
    final startIso = DateTime(year, 1, 1).toIso8601String();
    final endIso = DateTime(year, 12, 31, 23, 59, 59).toIso8601String();

    final rows = await db.rawQuery(
      '''
      SELECT strftime('%m', created_at) as month, COALESCE(SUM(grand_total), 0) as omzet
      FROM transactions
      WHERE created_at >= ? AND created_at <= ? AND amount_paid >= grand_total
      GROUP BY month
      ''',
      [startIso, endIso],
    );

    final List<double> monthlyData = List<double>.filled(12, 0);
    for (var row in rows) {
      final monthStr = row['month'] as String?;
      if (monthStr != null) {
        final monthIdx = int.parse(monthStr) - 1;
        monthlyData[monthIdx] = ((row['omzet'] as num?)?.toDouble() ?? 0);
      }
    }
    return monthlyData;
  }

  /// Top layanan terjual berdasarkan item transaksi, bukan pemakaian bahan baku.
  Future<List<Map<String, dynamic>>> getTopSellingProductsByDateRange(
      DateTime start, DateTime end,
      {int limit = 30}) async {
    final db = await database;
    final startIso = start.toIso8601String();
    final endIso = end.toIso8601String();
    final result = await db.rawQuery('''
      SELECT
        p.id,
        COALESCE(NULLIF(ti.product_name, ''), p.name) as name,
        COALESCE(NULLIF(ti.unit, ''), p.unit) as unit,
        p.image_path,
        SUM(ti.qty) as total_sold
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      LEFT JOIN products p ON p.id = ti.product_id
      WHERE t.is_deleted = 0
        AND t.created_at >= ?
        AND t.created_at <= ?
        AND COALESCE(p.is_material, 0) != 1
      GROUP BY ti.product_id, COALESCE(NULLIF(ti.product_name, ''), p.name), COALESCE(NULLIF(ti.unit, ''), p.unit), p.image_path
      ORDER BY total_sold DESC
      LIMIT ?
    ''', [startIso, endIso, limit]);
    return result;
  }

  // ============== CUSTOMERS ================
  String _customerPhoneKey(String? phone) =>
      (phone ?? '').replaceAll(RegExp(r'[^0-9]'), '');

  Future<int> insertCustomer(Customer customer) async {
    final db = await database;
    return await db.insert('customers', customer.toMap());
  }

  Future<Customer?> getCustomerByPhone(String phone) async {
    final db = await database;
    final result = await db.query(
      'customers',
      where: 'phone = ?',
      whereArgs: [phone],
      limit: 1,
    );
    if (result.isEmpty) return null;
    return Customer.fromMap(result.first);
  }

  /// Insert customer if phone not found, otherwise update name/phone/address.
  /// Returns the saved (existing or newly created) customer with id.
  Future<Customer> upsertCustomerByPhone({
    required String name,
    required String phone,
    String? address,
  }) async {
    final existing = await getCustomerByPhone(phone);
    if (existing == null) {
      final now = DateTime.now().toIso8601String();
      final c = Customer(
        name: name,
        phone: phone,
        address: address,
        createdAt: now,
      );
      final id = await insertCustomer(c);
      return Customer(
        id: id,
        name: c.name,
        phone: c.phone,
        address: c.address,
        discountPct: c.discountPct,
        memberCode: c.memberCode,
        createdAt: c.createdAt,
      );
    }

    final updated = Customer(
      id: existing.id,
      name: name,
      phone: phone,
      address: address ?? existing.address,
      discountPct: existing.discountPct,
      memberCode: existing.memberCode,
      whatsappValidatedAt: existing.whatsappValidatedAt,
      whatsappValidatedPhone: existing.whatsappValidatedPhone,
      createdAt: existing.createdAt,
    );
    await updateCustomer(updated);
    return updated;
  }

  Future<List<Customer>> getAllCustomers() async {
    final db = await database;
    final result = await db.query('customers', orderBy: 'name ASC');
    return result.map((m) => Customer.fromMap(m)).toList();
  }

  Future<int> updateCustomer(Customer customer) async {
    final db = await database;
    final map = customer.toMap();
    if (customer.id != null &&
        customer.whatsappValidatedAt == null &&
        customer.whatsappValidatedPhone == null) {
      final existing = await getCustomerById(customer.id!);
      final samePhone = _customerPhoneKey(existing?.phone) ==
          _customerPhoneKey(customer.phone);
      if (samePhone && existing?.whatsappValidatedAt != null) {
        map['whatsapp_validated_at'] = existing!.whatsappValidatedAt;
        map['whatsapp_validated_phone'] = existing.whatsappValidatedPhone;
      }
    }
    return await db.transaction<int>((txn) async {
      final updated = await txn.update(
        'customers',
        map,
        where: 'id = ?',
        whereArgs: [customer.id],
      );
      if (updated > 0 && customer.id != null) {
        await txn.update(
          'transactions',
          {'customer_name': customer.name},
          where: 'customer_id = ?',
          whereArgs: [customer.id],
        );
      }
      return updated;
    });
  }

  Future<void> markCustomerWhatsappValidated({
    required int customerId,
    required String phone,
    String? validatedAt,
  }) async {
    final db = await database;
    await db.update(
      'customers',
      {
        'whatsapp_validated_at':
            validatedAt ?? DateTime.now().toIso8601String(),
        'whatsapp_validated_phone': phone,
      },
      where: 'id = ?',
      whereArgs: [customerId],
    );
  }

  Future<void> deleteCustomer(int id) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.update('transactions', {'customer_id': null},
          where: 'customer_id = ?', whereArgs: [id]);
      await txn.delete('customers', where: 'id = ?', whereArgs: [id]);
    });
  }

  Future<int> getCustomerTransactionCount(int customerId) async {
    final db = await database;
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS count FROM transactions WHERE customer_id = ?',
      [customerId],
    );
    return (rows.first['count'] as num?)?.toInt() ?? 0;
  }

  Future<Customer?> getCustomerById(int id) async {
    final db = await instance.database;
    final result =
        await db.query('customers', where: 'id = ?', whereArgs: [id]);
    if (result.isNotEmpty) {
      return Customer.fromMap(result.first);
    }
    return null;
  }

  // ============== EMPLOYEES ================
  Future<int> insertEmployee(Employee employee) async {
    final db = await database;
    return await db.insert('employees', employee.toMap());
  }

  Future<List<Employee>> getAllEmployees() async {
    final db = await database;
    final result = await db.query('employees', orderBy: 'name ASC');
    return result.map((m) => Employee.fromMap(m)).toList();
  }

  Future<int> updateEmployee(Employee employee) async {
    final db = await database;
    return await db.update(
      'employees',
      employee.toMap(),
      where: 'id = ?',
      whereArgs: [employee.id],
    );
  }

  Future<void> deleteEmployee(int id) async {
    final db = await database;
    await db.delete('employees', where: 'id = ?', whereArgs: [id]);
  }

  // ============== TRANSACTIONS ================
  int _usageQty(double transactionQty, double qtyPerUnit) {
    if (transactionQty <= 0 || qtyPerUnit <= 0) return 0;
    return (transactionQty * qtyPerUnit).ceil();
  }

  Future<void> _deductTrackedProductStock(
    DatabaseExecutor txn, {
    required int productId,
    required String productName,
    required int qty,
    required String txDate,
    required String stockName,
    bool allowMaterial = false,
  }) async {
    if (qty <= 0) return;
    final pRows = await txn.query(
      'products',
      where: 'id = ?',
      whereArgs: [productId],
      limit: 1,
    );
    if (pRows.isEmpty) {
      throw Exception('Produk dengan id $productId tidak ditemukan.');
    }

    final product = Product.fromMap(pRows.first);
    if (product.isMaterialItem && !allowMaterial) {
      throw Exception(
        'Bahan baku ${product.name} tidak bisa dijual langsung di halaman order.',
      );
    }
    if (!product.tracksInventory) return;

    final currentStock = product.stock;
    if (currentStock < qty) {
      throw Exception(
        'Stok $productName tidak cukup. Tersedia $currentStock, dibutuhkan $qty.',
      );
    }

    final newStock = currentStock - qty;
    await txn.update(
      'products',
      {'stock': newStock},
      where: 'id = ?',
      whereArgs: [productId],
    );

    await txn.insert('stock_logs', {
      'product_id': productId,
      'type': 'out',
      'qty': qty,
      'date': txDate,
      'stock_name': stockName,
      'old_qty': currentStock,
      'new_qty': newStock,
    });
  }

  Future<void> _restoreTrackedProductStock(
    DatabaseExecutor txn, {
    required int productId,
    required int qty,
    required String stockName,
  }) async {
    if (qty <= 0) return;
    final pRows = await txn.query(
      'products',
      where: 'id = ?',
      whereArgs: [productId],
      limit: 1,
    );
    if (pRows.isEmpty) return;

    final product = Product.fromMap(pRows.first);
    if (!product.tracksInventory) return;

    final newStock = product.stock + qty;
    await txn.update(
      'products',
      {'stock': newStock},
      where: 'id = ?',
      whereArgs: [productId],
    );

    await txn.insert('stock_logs', {
      'product_id': productId,
      'type': 'in',
      'qty': qty,
      'date': DateTime.now().toIso8601String(),
      'stock_name': stockName,
      'old_qty': product.stock,
      'new_qty': newStock,
    });
  }

  Future<void> _deductRecipeMaterialsForItem(
    DatabaseExecutor txn, {
    required int transactionId,
    required TransactionItem item,
    required String txDate,
  }) async {
    final recipeRows = await txn.query(
      'product_recipes',
      where: 'service_product_id = ?',
      whereArgs: [item.productId],
      orderBy: 'id ASC',
    );
    if (recipeRows.isEmpty) return;

    for (final recipeMap in recipeRows) {
      final recipe = ProductRecipe.fromMap(recipeMap);
      final usageQty = _usageQty(item.qty, recipe.qtyPerUnit);
      if (usageQty <= 0) continue;

      final materialRows = await txn.query(
        'products',
        where: 'id = ?',
        whereArgs: [recipe.materialProductId],
        limit: 1,
      );
      if (materialRows.isEmpty) {
        throw Exception(
          'Bahan baku untuk ${item.productName} tidak ditemukan.',
        );
      }
      final material = Product.fromMap(materialRows.first);
      if (!material.tracksInventory) continue;

      await _deductTrackedProductStock(
        txn,
        productId: material.id!,
        productName: material.name,
        qty: usageQty,
        txDate: txDate,
        stockName: 'Bahan baku transaksi #$transactionId - ${item.productName}',
        allowMaterial: true,
      );

      await txn.insert('transaction_material_usages', {
        'transaction_id': transactionId,
        'service_product_id': item.productId,
        'material_product_id': material.id,
        'material_name': material.name,
        'qty': usageQty,
        'created_at': txDate,
      });
    }
  }

  Future<void> _deductMaterialUsageSnapshot(
    DatabaseExecutor txn, {
    required int transactionId,
    required String stockName,
  }) async {
    final rows = await txn.query(
      'transaction_material_usages',
      where: 'transaction_id = ?',
      whereArgs: [transactionId],
    );
    for (final row in rows) {
      final productId = row['material_product_id'] as int;
      final qty = (row['qty'] as num?)?.toInt() ?? 0;
      final name = row['material_name'] as String? ?? 'Bahan baku';
      await _deductTrackedProductStock(
        txn,
        productId: productId,
        productName: name,
        qty: qty,
        txDate: DateTime.now().toIso8601String(),
        stockName: stockName,
        allowMaterial: true,
      );
    }
  }

  Future<void> _restoreMaterialUsageSnapshot(
    DatabaseExecutor txn, {
    required int transactionId,
    required String stockName,
  }) async {
    final rows = await txn.query(
      'transaction_material_usages',
      where: 'transaction_id = ?',
      whereArgs: [transactionId],
    );
    for (final row in rows) {
      final productId = row['material_product_id'] as int;
      final qty = (row['qty'] as num?)?.toInt() ?? 0;
      await _restoreTrackedProductStock(
        txn,
        productId: productId,
        qty: qty,
        stockName: stockName,
      );
    }
  }

  Future<int> insertTransaction(
      Transaction transaction, List<TransactionItem> items,
      {String? transactionPrefix}) async {
    final db = await database;
    await _ensureCoreSchema(db);
    return await db.transaction<int>((txn) async {
      final storeRows = await txn.query(
        'warung_profile',
        columns: ['nama'],
        limit: 1,
      );
      final storeName =
          storeRows.isNotEmpty ? storeRows.first['nama'] as String? : null;

      // Calculate daily queue number
      final nowStr = transaction.createdAt.split('T').first; // Get YYYY-MM-DD
      final countResult = await txn.rawQuery(
          "SELECT COUNT(*) as count FROM transactions WHERE created_at LIKE ? AND is_deleted = 0",
          ['$nowStr%']);
      final dailyCount = (countResult.first['count'] as num?)?.toInt() ?? 0;
      final queueNumber = dailyCount + 1;

      // Create updated map with queue_number
      final txMap = transaction.toMap();
      txMap['queue_number'] = queueNumber;
      txMap.remove('transaction_code');

      final txId = await txn.insert('transactions', txMap);
      final txDate = transaction.createdAt;
      final supportsTransactionCode = await _hasColumn(
        txn,
        'transactions',
        'transaction_code',
      );
      final savedTransactionCode =
          transaction.transactionCode?.trim().isNotEmpty == true
              ? transaction.transactionCode!.trim().toUpperCase()
              : TransactionCodeFormatter.format(
                  id: txId,
                  createdAt: txDate,
                  storeName: storeName,
                  customPrefix: transactionPrefix,
                );
      if (supportsTransactionCode) {
        await txn.update(
          'transactions',
          {'transaction_code': savedTransactionCode},
          where: 'id = ?',
          whereArgs: [txId],
        );
      }

      for (final item in items) {
        final itemMap = item.toMap();
        itemMap['transaction_id'] = txId;
        await txn.insert('transaction_items', itemMap);

        await _deductTrackedProductStock(
          txn,
          productId: item.productId,
          productName: item.productName,
          qty: item.qty.ceil(),
          txDate: txDate,
          stockName: 'Transaksi #$txId',
        );
        await _deductRecipeMaterialsForItem(
          txn,
          transactionId: txId,
          item: item,
          txDate: txDate,
        );
      }

      // 4. Tambah uang masuk ke dompet jika ada pembayaran masuk
      final cashIn = transaction.amountPaid - transaction.changeAmount;
      if (cashIn > 0) {
        final now = DateTime.tryParse(txDate) ?? DateTime.now();
        await txn.insert('wallet_transactions', {
          'wallet_id': transaction.paymentMethod,
          'nominal': cashIn,
          'type': 'masuk',
          'tanggal': now.toIso8601String().substring(0, 10),
          'waktu': now.toIso8601String().substring(11, 16),
          'keterangan': 'Pemasukan Servis',
          'created_at': txDate,
          'kategori': 'Servis',
          'foto_path': '',
          'source': 'system',
          'updated_at': txDate,
        });
      }

      return txId;
    });
  }

  Future<void> mergeTransaction(int txId, int additionalTotal,
      int additionalGrandTotal, List<TransactionItem> items) async {
    final db = await database;
    await _ensureCoreSchema(db);
    await db.transaction((txn) async {
      // 1. Get existing tx
      final txData =
          await txn.query('transactions', where: 'id = ?', whereArgs: [txId]);
      if (txData.isEmpty) throw Exception('Transaksi tidak ditemukan');
      final currentTx = Transaction.fromMap(txData.first);

      // 2. Update totals
      await txn.update(
        'transactions',
        {
          'total_amount': currentTx.totalAmount + additionalTotal,
          'grand_total': currentTx.grandTotal + additionalGrandTotal,
          'updated_at': DateTime.now().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [txId],
      );

      final txDate = DateTime.now().toIso8601String();

      // 3. Insert items and deduct stock
      for (final item in items) {
        final itemMap = item.toMap();
        itemMap['transaction_id'] = txId;
        await txn.insert('transaction_items', itemMap);

        await _deductTrackedProductStock(
          txn,
          productId: item.productId,
          productName: item.productName,
          qty: item.qty.ceil(),
          txDate: txDate,
          stockName: 'Tambahan transaksi #$txId',
        );
        await _deductRecipeMaterialsForItem(
          txn,
          transactionId: txId,
          item: item,
          txDate: txDate,
        );
      }
    });
  }

  Future<int> splitTransaction(
      int sourceTxId, List<int> selectedItemIds) async {
    final db = await database;
    return await db.transaction<int>((txn) async {
      // 1. Ambil transaksi asal
      final txData = await txn
          .query('transactions', where: 'id = ?', whereArgs: [sourceTxId]);
      if (txData.isEmpty) throw Exception('Transaksi asal tidak ditemukan');
      final sourceTx = Transaction.fromMap(txData.first);

      // 2. Buat transaksi baru (copy dari asal tapi reset angka)
      final txMap = sourceTx.toMap();
      txMap.remove('id');
      txMap.remove('transaction_code');
      txMap['total_amount'] = 0;
      txMap['grand_total'] = 0;
      txMap['amount_paid'] = 0;
      txMap['change_amount'] = 0;
      txMap['note'] = '${txMap['note'] ?? ''} (Split dari #$sourceTxId)'.trim();
      txMap['created_at'] = DateTime.now().toIso8601String();

      final newTxId = await txn.insert('transactions', txMap);

      // 3. Pindahkan items terpilih
      for (final itemId in selectedItemIds) {
        await txn.update(
          'transaction_items',
          {'transaction_id': newTxId},
          where: 'id = ? AND transaction_id = ?',
          whereArgs: [itemId, sourceTxId],
        );
      }

      // 4. Hitung ulang total untuk kedua transaksi
      Future<void> recalculate(int id) async {
        final items = await txn.query('transaction_items',
            where: 'transaction_id = ?', whereArgs: [id]);
        int total = 0;
        for (final item in items) {
          total += (item['subtotal'] as num).toInt();
        }
        await txn.update(
          'transactions',
          {
            'total_amount': total,
            'grand_total': total,
          },
          where: 'id = ?',
          whereArgs: [id],
        );
      }

      await recalculate(sourceTxId);
      await recalculate(newTxId);

      return newTxId;
    });
  }

  Future<List<Transaction>> getAllTransactions({int limit = 200}) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT * FROM transactions 
      WHERE is_deleted = 0 
      ORDER BY 
        CASE WHEN (amount_paid < grand_total AND grand_total > 0) THEN 0 ELSE 1 END,
        created_at DESC
      LIMIT ?
    ''', [limit]);
    return result.map((m) => Transaction.fromMap(m)).toList();
  }

  Future<int> countActiveservisTransactions() async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT COUNT(*) AS count
      FROM transactions
      WHERE is_deleted = 0
        AND TRIM(COALESCE(servis_status, '')) != ''
        AND servis_status != 'Selesai'
    ''');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<int> countPendingUnpaidTransactions() async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT COUNT(*) AS count
      FROM transactions
      WHERE is_deleted = 0
        AND amount_paid < grand_total
    ''');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<List<Transaction>> getTransactionsByDate(String dateStr) async {
    final db = await database;
    final result = await db.query('transactions',
        where: 'is_deleted = 0 AND created_at LIKE ?',
        whereArgs: ['$dateStr%'],
        orderBy: 'created_at DESC');
    return result.map((m) => Transaction.fromMap(m)).toList();
  }

  Future<void> updateTransactionservisStatus(
      int id, String status, String? kelengkapan) async {
    final db = await database;
    final now = DateTime.now().toIso8601String();
    await db.update(
      'transactions',
      {
        'servis_status': status,
        if (kelengkapan != null) 'kelengkapan': kelengkapan,
        'updated_at': now,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<Transaction?> getTransactionById(int id) async {
    final db = await database;
    final result =
        await db.query('transactions', where: 'id = ?', whereArgs: [id]);
    if (result.isNotEmpty) return Transaction.fromMap(result.first);
    return null;
  }

  Future<Transaction?> getTransactionByCode(String code) async {
    final db = await database;
    // Normalize input: uppercase and remove spaces/hyphens/underscores
    final normCode =
        code.toUpperCase().trim().replaceAll(RegExp(r'[\s\-\_]+'), '');
    if (normCode.isEmpty) return null;

    // 1. Exact match on transaction_code (after removing separators from both)
    var result = await db.rawQuery(
        "SELECT * FROM transactions WHERE REPLACE(REPLACE(REPLACE(UPPER(transaction_code), ' ', ''), '-', ''), '_', '') = ? AND is_deleted = 0 LIMIT 1",
        [normCode]);
    if (result.isNotEmpty) return Transaction.fromMap(result.first);

    // 2. Exact match on the original code column just in case
    result = await db.query('transactions',
        where: 'UPPER(transaction_code) = ? AND is_deleted = 0',
        whereArgs: [normCode],
        limit: 1);
    if (result.isNotEmpty) return Transaction.fromMap(result.first);

    // 3. Fallback to ID if the code is purely numeric
    final idValue = int.tryParse(normCode);
    if (idValue != null) {
      result = await db.query('transactions',
          where: 'id = ? AND is_deleted = 0', whereArgs: [idValue], limit: 1);
      if (result.isNotEmpty) return Transaction.fromMap(result.first);
    }

    // 4. Try to extract the ID from the end of a long code (format: PREFIX + ddMMyyyyHHmm + ID padded)
    final digits = normCode.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length >= 14) {
      final idStr = digits.substring(12);
      final parsedId = int.tryParse(idStr);
      if (parsedId != null && parsedId > 0) {
        result = await db.query('transactions',
            where: 'id = ? AND is_deleted = 0',
            whereArgs: [parsedId],
            limit: 1);
        if (result.isNotEmpty) return Transaction.fromMap(result.first);
      }
    }

    // 5. Partial match as last resort
    result = await db.query('transactions',
        where: 'UPPER(transaction_code) LIKE ? AND is_deleted = 0',
        whereArgs: ['%$normCode%'],
        limit: 1);
    if (result.isNotEmpty) return Transaction.fromMap(result.first);

    return null;
  }

  Future<List<_PaymentPart>> _getTransactionPaymentParts(
    DatabaseExecutor executor,
    int transactionId,
    Map<String, Object?> txMap,
  ) async {
    final amountPaid = (txMap['amount_paid'] as num?)?.toInt() ?? 0;
    final changeAmount = (txMap['change_amount'] as num?)?.toInt() ?? 0;
    final paidNet = (amountPaid - changeAmount).clamp(0, amountPaid).toInt();
    if (paidNet <= 0) return const [];

    final parts = <_PaymentPart>[];
    var installmentTotal = 0;
    final installments = await executor.query(
      'cicilans',
      columns: ['nominal', 'metode_pembayaran'],
      where: 'transaction_id = ?',
      whereArgs: [transactionId],
      orderBy: 'created_at ASC',
    );
    for (final row in installments) {
      final nominal = (row['nominal'] as num?)?.toInt() ?? 0;
      if (nominal <= 0) continue;
      installmentTotal += nominal;
      parts.add(_PaymentPart(
        walletId: row['metode_pembayaran']?.toString() ?? 'tunai',
        nominal: nominal,
      ));
    }

    final initialPaid = (paidNet - installmentTotal).clamp(0, paidNet).toInt();
    if (initialPaid > 0) {
      parts.insert(
        0,
        _PaymentPart(
          walletId: txMap['payment_method']?.toString() ?? 'tunai',
          nominal: initialPaid,
        ),
      );
    }

    return parts;
  }

  Future<void> softDeleteTransaction(int id,
      {bool restoreStock = true, bool reverseWallet = true}) async {
    final db = await database;
    await db.transaction((txn) async {
      // 1. Ambil data transaksi
      final txMaps = await txn.query('transactions',
          where: 'id = ?', whereArgs: [id], limit: 1);
      if (txMaps.isEmpty) return;
      final alreadyDeleted = (txMaps.first['is_deleted'] as int?) == 1;
      if (alreadyDeleted) return;

      // 2. Kembalikan Stok Produk
      if (restoreStock) {
        final items = await txn.query('transaction_items',
            where: 'transaction_id = ?', whereArgs: [id]);
        for (var itemMap in items) {
          final productId = itemMap['product_id'] as int;
          final qty = (itemMap['qty'] as num).toDouble();

          await _restoreTrackedProductStock(
            txn,
            productId: productId,
            qty: qty.ceil(),
            stockName: 'Pembatalan Transaksi #$id',
          );
        }
        await _restoreMaterialUsageSnapshot(
          txn,
          transactionId: id,
          stockName: 'Pembatalan bahan baku transaksi #$id',
        );
      }

      // 3. Balikkan Saldo Dompet (jika ada uang masuk)
      if (reverseWallet) {
        final paymentParts =
            await _getTransactionPaymentParts(txn, id, txMaps.first);
        final now = DateTime.now();
        for (final part in paymentParts) {
          await txn.insert('wallet_transactions', {
            'wallet_id': part.walletId,
            'nominal': part.nominal,
            'type': 'keluar',
            'tanggal': now.toIso8601String().substring(0, 10),
            'waktu': now.toIso8601String().substring(11, 16),
            'keterangan': 'Pembatalan Penjualan #$id',
            'created_at': now.toIso8601String(),
            'kategori': 'Pembatalan',
            'foto_path': '',
            'source': 'system',
            'updated_at': now.toIso8601String(),
          });
        }
      }

      // 4. Tandai sebagai dihapus
      await txn.update(
        'transactions',
        {
          'is_deleted': 1,
          'deleted_at': DateTime.now().toIso8601String(),
          'updated_at': DateTime.now().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [id],
      );
    });
  }

  Future<void> restoreTransaction(int id,
      {bool deductStock = true, bool addWallet = true}) async {
    final db = await database;
    await db.transaction((txn) async {
      // 1. Ambil data transaksi
      final txMaps = await txn.query('transactions',
          where: 'id = ?', whereArgs: [id], limit: 1);
      if (txMaps.isEmpty) return;
      final alreadyActive = (txMaps.first['is_deleted'] as int?) != 1;
      if (alreadyActive) return;

      // 2. Potong Stok Kembali
      if (deductStock) {
        final items = await txn.query('transaction_items',
            where: 'transaction_id = ?', whereArgs: [id]);
        for (var itemMap in items) {
          final productId = itemMap['product_id'] as int;
          final qty = (itemMap['qty'] as num?)?.toDouble() ?? 0;
          await _deductTrackedProductStock(
            txn,
            productId: productId,
            productName: 'produk #$productId',
            qty: qty.ceil(),
            txDate: DateTime.now().toIso8601String(),
            stockName: 'Pemulihan Transaksi #$id',
          );
        }
        await _deductMaterialUsageSnapshot(
          txn,
          transactionId: id,
          stockName: 'Pemulihan bahan baku transaksi #$id',
        );
      }

      // 3. Masukkan kembali ke Saldo Dompet
      if (addWallet) {
        final paymentParts =
            await _getTransactionPaymentParts(txn, id, txMaps.first);
        final now = DateTime.now();
        for (final part in paymentParts) {
          await txn.insert('wallet_transactions', {
            'wallet_id': part.walletId,
            'nominal': part.nominal,
            'type': 'masuk',
            'tanggal': now.toIso8601String().substring(0, 10),
            'waktu': now.toIso8601String().substring(11, 16),
            'keterangan': 'Pemulihan Penjualan #$id',
            'created_at': now.toIso8601String(),
            'kategori': 'Pemulihan',
            'foto_path': '',
            'source': 'system',
            'updated_at': now.toIso8601String(),
          });
        }
      }

      // 4. Batalkan tanda hapus
      await txn.update(
        'transactions',
        {
          'is_deleted': 0,
          'deleted_at': null,
          'updated_at': DateTime.now().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [id],
      );
    });
  }

  Future<List<Transaction>> getDeletedTransactions() async {
    final db = await database;
    final cutoff =
        DateTime.now().subtract(const Duration(days: 90)).toIso8601String();
    final result = await db.query(
      'transactions',
      where: 'is_deleted = 1 AND deleted_at >= ?',
      whereArgs: [cutoff],
      orderBy: 'deleted_at DESC',
    );
    return result.map((m) => Transaction.fromMap(m)).toList();
  }

  Future<List<TransactionItem>> getTransactionItems(int transactionId) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT ti.*, p.unit, p.is_hardware 
      FROM transaction_items ti
      LEFT JOIN products p ON p.id = ti.product_id
      WHERE ti.transaction_id = ?
    ''', [transactionId]);
    return result.map((m) => TransactionItem.fromMap(m)).toList();
  }

  Future<Map<int, String>> getPriorityServiceLabelsByTransactionIds(
      List<int> transactionIds) async {
    if (transactionIds.isEmpty) return {};
    final db = await database;
    final placeholders = List.filled(transactionIds.length, '?').join(',');
    final rows = await db.rawQuery('''
      SELECT transaction_id, product_name
      FROM transaction_items
      WHERE transaction_id IN ($placeholders)
      ORDER BY transaction_id ASC, id ASC
    ''', transactionIds);

    final labels = <int, String>{};
    for (final row in rows) {
      final txId = (row['transaction_id'] as num?)?.toInt();
      if (txId == null || labels.containsKey(txId)) continue;
      final label = _priorityServiceLabel(row['product_name']?.toString());
      if (label != null) labels[txId] = label;
    }
    return labels;
  }

  String? _priorityServiceLabel(String? productName) {
    final name = productName?.trim();
    if (name == null || name.isEmpty) return null;

    final lower = name.toLowerCase();
    final hasKeyword = lower.contains('express') ||
        lower.contains('kilat') ||
        lower.contains('cepat') ||
        lower.contains('prioritas');

    final hourMatch = RegExp(r'(\d+)\s*jam').firstMatch(lower);
    final hours =
        hourMatch == null ? null : int.tryParse(hourMatch.group(1) ?? '');
    final isShortSla = hours != null && hours > 0 && hours <= 8;

    if (!hasKeyword && !isShortSla) return null;

    final suffix = hours == null ? '' : ' $hours jam';
    if (lower.contains('express')) return 'Express$suffix';
    if (lower.contains('kilat')) return 'Kilat$suffix';
    if (lower.contains('cepat')) return 'Cepat$suffix';
    if (lower.contains('prioritas')) return 'Prioritas$suffix';
    return 'Express$suffix';
  }

  // ============== servis OPERATIONS =================
  Future<List<servisStation>> getservisStations() async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    final result =
        await db.query('fnb_tables', orderBy: 'sort_order ASC, name ASC');
    return result.map((m) => servisStation.fromMap(m)).toList();
  }

  Future<servisStation?> getservisStationByTransactionId(
      int transactionId) async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    final result = await db.query(
      'fnb_tables',
      where: 'active_transaction_id = ?',
      whereArgs: [transactionId],
      limit: 1,
    );
    if (result.isEmpty) return null;
    return servisStation.fromMap(result.first);
  }

  Future<int> insertservisStation(servisStation table) async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    return db.insert('fnb_tables', table.toMap()..remove('id'));
  }

  Future<void> updateservisStation(servisStation table) async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    await db.update(
      'fnb_tables',
      table.toMap()..remove('id'),
      where: 'id = ?',
      whereArgs: [table.id],
    );
  }

  Future<void> assignservisStationToTransaction({
    required int stationId,
    required int transactionId,
  }) async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    await db.update(
      'fnb_tables',
      {
        'status': 'occupied',
        'active_transaction_id': transactionId,
        'merged_to_table_id': null,
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [stationId],
    );
  }

  Future<void> updateservisStationStatus(int tableId, String status) async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    await db.update(
      'fnb_tables',
      {
        'status': status,
        if (status == 'available' || status == 'cleaning')
          'active_transaction_id': null,
        if (status != 'merged') 'merged_to_table_id': null,
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [tableId],
    );
  }

  Future<void> releaseservisStationByTransactionId(int transactionId) async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    await db.update(
      'fnb_tables',
      {
        'status': 'cleaning',
        'active_transaction_id': null,
        'merged_to_table_id': null,
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'active_transaction_id = ?',
      whereArgs: [transactionId],
    );
  }

  Future<void> mergeservisStations({
    required int sourceTableId,
    required int targetTableId,
  }) async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    await db.update(
      'fnb_tables',
      {
        'status': 'merged',
        'merged_to_table_id': targetTableId,
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [sourceTableId],
    );
  }

  Future<List<servisWorkshopTicket>> getservisWorkshopTickets({
    bool includeDone = false,
  }) async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    final result = await db.query(
      'fnb_kitchen_tickets',
      where: includeDone ? null : "status != 'done'",
      orderBy:
          "CASE status WHEN 'queued' THEN 0 WHEN 'preparing' THEN 1 WHEN 'ready' THEN 2 ELSE 3 END, created_at ASC",
      limit: includeDone ? 80 : null,
    );
    return result.map((m) => servisWorkshopTicket.fromMap(m)).toList();
  }

  Future<int> insertservisWorkshopTicket(servisWorkshopTicket ticket) async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    return db.insert('fnb_kitchen_tickets', ticket.toMap()..remove('id'));
  }

  Future<void> updateservisWorkshopTicketStatus(
      int ticketId, String status) async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    await db.update(
      'fnb_kitchen_tickets',
      {
        'status': status,
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [ticketId],
    );
  }

  Future<void> updateWorkshopTicketStatusByTransaction(
    int transactionId,
    String status,
  ) async {
    final db = await database;
    await _ensureWorkshopSchema(db);
    await db.update(
      'fnb_kitchen_tickets',
      {
        'status': status,
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'transaction_id = ?',
      whereArgs: [transactionId],
    );
  }

  DateTime _startOfDay(DateTime d) => DateTime(d.year, d.month, d.day);

  Map<String, DateTime> _periodBounds({
    required String periodType,
    required DateTime selectedDate,
  }) {
    switch (periodType) {
      case 'monthly':
        final start = DateTime(selectedDate.year, selectedDate.month, 1);
        final end = DateTime(selectedDate.year, selectedDate.month + 1, 1);
        return {'start': start, 'end': end};
      case 'yearly':
        final start = DateTime(selectedDate.year, 1, 1);
        final end = DateTime(selectedDate.year + 1, 1, 1);
        return {'start': start, 'end': end};
      default:
        final start = _startOfDay(selectedDate);
        final end = start.add(const Duration(days: 1));
        return {'start': start, 'end': end};
    }
  }

  Future<List<Transaction>> getTransactionsByPeriod({
    required String periodType,
    required DateTime selectedDate,
    bool? isPaid,
    int limit = 200,
  }) async {
    final db = await database;
    final bounds =
        _periodBounds(periodType: periodType, selectedDate: selectedDate);
    final startIso = bounds['start']!.toIso8601String();
    final endIso = bounds['end']!.toIso8601String();

    final whereParts = <String>[
      'is_deleted = 0',
      'created_at >= ?',
      'created_at < ?'
    ];
    final whereArgs = <Object>[startIso, endIso];
    if (isPaid != null) {
      whereParts.add(
          isPaid ? 'amount_paid >= grand_total' : 'amount_paid < grand_total');
    }

    final result = await db.query(
      'transactions',
      where: whereParts.join(' AND '),
      whereArgs: whereArgs,
      orderBy: 'created_at DESC',
      limit: limit,
    );
    return result.map((m) => Transaction.fromMap(m)).toList();
  }

  Future<Map<String, int>> getPaidSummaryByPeriod({
    required String periodType,
    required DateTime selectedDate,
  }) async {
    final db = await database;
    final bounds =
        _periodBounds(periodType: periodType, selectedDate: selectedDate);
    final startIso = bounds['start']!.toIso8601String();
    final endIso = bounds['end']!.toIso8601String();

    final txSummary = await db.rawQuery(
      '''
      SELECT
        COUNT(*) as count,
        COALESCE(SUM(grand_total), 0) as omzet
      FROM transactions
      WHERE created_at >= ?
        AND created_at < ?
        AND amount_paid >= grand_total
        AND is_deleted = 0
      ''',
      [startIso, endIso],
    );

    final itemSummary = await db.rawQuery(
      '''
      SELECT
        COALESCE(SUM(ti.qty), 0) as products,
        COALESCE(SUM((ti.unit_price - COALESCE(p.buy_price, 0)) * ti.qty), 0) as profit
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      LEFT JOIN products p ON p.id = ti.product_id
      WHERE t.created_at >= ?
        AND t.created_at < ?
        AND t.amount_paid >= t.grand_total
        AND t.is_deleted = 0
      ''',
      [startIso, endIso],
    );

    return {
      'count': (txSummary.first['count'] as num?)?.toInt() ?? 0,
      'omzet': (txSummary.first['omzet'] as num?)?.toInt() ?? 0,
      'products': (itemSummary.first['products'] as num?)?.toInt() ?? 0,
      'profit': (itemSummary.first['profit'] as num?)?.toInt() ?? 0,
    };
  }

  Future<Map<String, int>> getUnpaidSummaryByPeriod({
    required String periodType,
    required DateTime selectedDate,
  }) async {
    final db = await database;
    final bounds =
        _periodBounds(periodType: periodType, selectedDate: selectedDate);
    final startIso = bounds['start']!.toIso8601String();
    final endIso = bounds['end']!.toIso8601String();

    final txSummary = await db.rawQuery(
      '''
      SELECT
        COUNT(*) as count,
        COALESCE(SUM(grand_total), 0) as total_piutang,
        COALESCE(SUM(amount_paid), 0) as total_terbayar
      FROM transactions
      WHERE created_at >= ?
        AND created_at < ?
        AND amount_paid < grand_total
        AND is_deleted = 0
      ''',
      [startIso, endIso],
    );

    final itemSummary = await db.rawQuery(
      '''
      SELECT COALESCE(SUM(ti.qty), 0) as products
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      WHERE t.created_at >= ?
        AND t.created_at < ?
        AND t.amount_paid < t.grand_total
        AND t.is_deleted = 0
      ''',
      [startIso, endIso],
    );

    final totalPiutang =
        (txSummary.first['total_piutang'] as num?)?.toInt() ?? 0;
    final totalTerbayar =
        (txSummary.first['total_terbayar'] as num?)?.toInt() ?? 0;

    return {
      'count': (txSummary.first['count'] as num?)?.toInt() ?? 0,
      'total_piutang': totalPiutang,
      'total_terbayar': totalTerbayar,
      'sisa_piutang': totalPiutang - totalTerbayar,
      'products': (itemSummary.first['products'] as num?)?.toInt() ?? 0,
    };
  }

  Future<List<Transaction>> getUnpaidTransactions({int limit = 200}) async {
    final db = await database;
    final result = await db.query(
      'transactions',
      where: 'is_deleted = 0 AND amount_paid < grand_total',
      orderBy: 'created_at DESC',
      limit: limit,
    );
    return result.map((m) => Transaction.fromMap(m)).toList();
  }

  Future<Map<String, int>> getUnpaidSummary() async {
    final db = await database;
    final txSummary = await db.rawQuery(
      '''
      SELECT
        COUNT(*) as count,
        COALESCE(SUM(grand_total), 0) as total_piutang,
        COALESCE(SUM(amount_paid), 0) as total_terbayar
      FROM transactions
      WHERE is_deleted = 0 AND amount_paid < grand_total
      ''',
    );

    final itemSummary = await db.rawQuery(
      '''
      SELECT COALESCE(SUM(ti.qty), 0) as products
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      WHERE t.is_deleted = 0 AND t.amount_paid < t.grand_total
      ''',
    );

    final totalPiutang =
        (txSummary.first['total_piutang'] as num?)?.toInt() ?? 0;
    final totalTerbayar =
        (txSummary.first['total_terbayar'] as num?)?.toInt() ?? 0;

    return {
      'count': (txSummary.first['count'] as num?)?.toInt() ?? 0,
      'products': (itemSummary.first['products'] as num?)?.toInt() ?? 0,
      'total_piutang': totalPiutang,
      'total_terbayar': totalTerbayar,
      'sisa_piutang': totalPiutang - totalTerbayar,
    };
  }

  /// Get daily summary from actual transactions table (V3)
  Future<Map<String, int>> getDailySummaryV3(String dateStr) async {
    final db = await database;
    final summary = await db.rawQuery(
      '''
      SELECT 
        COUNT(*) as count, 
        COALESCE(SUM(grand_total), 0) as sales,
        COALESCE(SUM(CASE WHEN payment_status != 'Lunas' THEN grand_total - amount_paid ELSE 0 END), 0) as unpaid,
        SUM(CASE WHEN servis_status IN ('Siap Ambil', 'Selesai', 'Selesai (Diantar)') THEN 1 ELSE 0 END) as completed
      FROM transactions WHERE is_deleted = 0 AND created_at LIKE ?
      ''',
      ['$dateStr%'],
    );
    final profitResult = await db.rawQuery(
      '''
      SELECT COALESCE(SUM((ti.unit_price - COALESCE(p.buy_price, 0)) * ti.qty), 0) as profit
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      LEFT JOIN products p ON p.id = ti.product_id
      WHERE t.is_deleted = 0 AND t.created_at LIKE ?
      ''',
      ['$dateStr%'],
    );

    return {
      'sales': (summary.first['sales'] as num?)?.toInt() ?? 0,
      'profit': (profitResult.first['profit'] as num?)?.toInt() ?? 0,
      'count': (summary.first['count'] as num?)?.toInt() ?? 0,
      'unpaid': (summary.first['unpaid'] as num?)?.toInt() ?? 0,
      'completed': (summary.first['completed'] as num?)?.toInt() ?? 0,
    };
  }

  /// Total kuantitas produk terjual pada hari tertentu (yyyy-MM-dd)
  Future<int> getDailySoldQtyV3(String dateStr) async {
    final db = await database;
    final result = await db.rawQuery(
      '''
      SELECT COALESCE(SUM(ti.qty), 0) as sold_qty
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      WHERE t.created_at LIKE ?
      ''',
      ['$dateStr%'],
    );
    return (result.first['sold_qty'] as num?)?.toInt() ?? 0;
  }

  /// Total berat pengecekanan (kg) pada hari tertentu — hanya item layanan
  Future<double> getDailyTotalWeight(String dateStr) async {
    final db = await database;
    final result = await db.rawQuery(
      '''
      SELECT COALESCE(SUM(ti.qty), 0) as total_weight
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      LEFT JOIN products p ON p.id = ti.product_id
      WHERE t.is_deleted = 0 
        AND t.created_at LIKE ?
        AND COALESCE(p.is_hardware, ti.is_hardware, 0) = 1
      ''',
      ['$dateStr%'],
    );
    return (result.first['total_weight'] as num?)?.toDouble() ?? 0.0;
  }

  /// Customer total spending
  Future<int> getCustomerTotalSpending(int customerId) async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(grand_total), 0) as total FROM transactions WHERE customer_id = ?',
      [customerId],
    );
    return (result.first['total'] as num?)?.toInt() ?? 0;
  }

  // ============== WALLET TRANSACTIONS ================

  Future<int> insertWalletTransaction(WalletTransaction tx) async {
    final db = await database;
    await _ensureWalletTransactionSchema(db);
    final data = tx.toMap()..remove('id');
    data['wallet_id'] = _canonicalWalletId(tx.walletId);
    data['type'] = _canonicalWalletType(tx.type);
    final categoryName = (tx.kategori ?? '').trim().isEmpty
        ? _fallbackFinanceCategoryName(data['type'] as String)
        : (tx.kategori ?? '').trim();
    data['kategori'] = categoryName;
    data['category_id'] = tx.categoryId ??
        await _ensureFinanceCategoryForName(
          db,
          data['type'] as String,
          categoryName,
        );
    final fallbackUpdatedAt = tx.createdAt.trim().isNotEmpty
        ? tx.createdAt
        : DateTime.now().toIso8601String();
    data['updated_at'] = tx.updatedAt?.trim().isNotEmpty == true
        ? tx.updatedAt
        : fallbackUpdatedAt;
    return await db.insert('wallet_transactions', data);
  }

  Future<int> updateWalletTransaction(WalletTransaction tx) async {
    if (tx.id == null) {
      throw ArgumentError('Wallet transaction id is required');
    }
    final db = await database;
    await _ensureWalletTransactionSchema(db);
    final data = tx.toMap()
      ..remove('id')
      ..remove('is_deleted')
      ..remove('deleted_at')
      ..['wallet_id'] = _canonicalWalletId(tx.walletId)
      ..['type'] = _canonicalWalletType(tx.type)
      ..['source'] = 'manual'
      ..['updated_at'] = DateTime.now().toIso8601String();
    final categoryName = (tx.kategori ?? '').trim().isEmpty
        ? _fallbackFinanceCategoryName(data['type'] as String)
        : (tx.kategori ?? '').trim();
    data['kategori'] = categoryName;
    data['category_id'] = tx.categoryId ??
        await _ensureFinanceCategoryForName(
          db,
          data['type'] as String,
          categoryName,
        );
    return await db.update(
      'wallet_transactions',
      data,
      where: 'id = ? AND source = ? AND is_deleted = 0',
      whereArgs: [tx.id, 'manual'],
    );
  }

  Future<int> cancelManualWalletTransaction(int id) async {
    final db = await database;
    await _ensureWalletTransactionSchema(db);
    return await db.update(
      'wallet_transactions',
      {
        'is_deleted': 1,
        'deleted_at': DateTime.now().toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ? AND source = ? AND is_deleted = 0',
      whereArgs: [id, 'manual'],
    );
  }

  Future<List<WalletTransaction>> getAllWalletTransactions() async {
    final db = await database;
    await _ensureWalletTransactionSchema(db);
    final result = await db.query(
      'wallet_transactions',
      where: 'is_deleted = 0',
      orderBy: 'tanggal DESC, waktu DESC, created_at DESC',
    );
    return result.map((m) => WalletTransaction.fromMap(m)).toList();
  }

  Future<List<WalletTransaction>> getWalletTransactionsByWallet(
      String walletId) async {
    final db = await database;
    await _ensureWalletTransactionSchema(db);
    final aliases = _walletAliasesFor(walletId);
    final result = aliases == null
        ? await db.query(
            'wallet_transactions',
            where: 'wallet_id = ? AND is_deleted = 0',
            whereArgs: [_canonicalWalletId(walletId)],
            orderBy: 'tanggal DESC, waktu DESC, created_at DESC',
          )
        : await db.rawQuery(
            '''
            SELECT *
            FROM wallet_transactions
            WHERE ${_walletIdSqlExpression()} IN (${_sqlPlaceholders(aliases.length)})
              AND is_deleted = 0
            ORDER BY tanggal DESC, waktu DESC, created_at DESC
            ''',
            aliases,
          );
    return result.map((m) => WalletTransaction.fromMap(m)).toList();
  }

  /// Hitung saldo dompet: SUM masuk - SUM keluar
  Future<int> getWalletBalance({String? walletId, String? since}) async {
    final db = await database;
    await _ensureWalletTransactionSchema(db);
    final whereParts = <String>['is_deleted = 0'];
    final whereArgs = <dynamic>[];

    if (since != null) {
      whereParts.add('created_at >= ?');
      whereArgs.add(since);
    }

    final rows = await db.query(
      'wallet_transactions',
      columns: ['wallet_id', 'nominal', 'type'],
      where: whereParts.join(' AND '),
      whereArgs: whereArgs.isEmpty ? null : whereArgs,
    );

    final requestedWallet = _normalizeWalletId(walletId);
    var total = 0;
    for (final row in rows) {
      final rowWalletId = row['wallet_id']?.toString() ?? 'tunai';
      final nominal = (row['nominal'] as num?)?.toInt() ?? 0;
      if (nominal <= 0) continue;
      final sign = row['type']?.toString().toLowerCase() == 'keluar' ? -1 : 1;
      final split = _splitWalletNominal(rowWalletId, nominal);

      if (requestedWallet.isEmpty) {
        total += sign * (split[0] + split[1]);
      } else if (_requestsCashWallet(requestedWallet)) {
        total += sign * split[0];
      } else if (_requestsNonCashWallet(requestedWallet)) {
        total += sign * split[1];
      } else if (_normalizeWalletId(rowWalletId) == requestedWallet) {
        total += sign * nominal;
      }
    }

    return total;
  }

  Future<void> resetWalletBalance() async {
    final db = await database;
    await db.delete('wallet_transactions');
  }

  // ============== PROFIL ================

  Future<Map<String, String>> getProfil() async {
    final db = await database;
    final result = await db.query('profil', limit: 1);
    if (result.isNotEmpty) {
      return {
        'nama': result.first['nama'] as String? ?? '',
        'foto_path': result.first['foto_path'] as String? ?? '',
        'admin_pin': result.first['admin_pin'] as String? ?? '',
        'admin_pin_hash': result.first['admin_pin_hash'] as String? ?? '',
      };
    }
    return {
      'nama': '',
      'foto_path': '',
      'admin_pin': '',
      'admin_pin_hash': '',
    };
  }

  Future<void> saveProfil({
    required String nama,
    required String fotoPath,
    String? adminPinHash,
  }) async {
    final db = await database;
    final existing = await db.query('profil', limit: 1);
    final data = {
      'nama': nama,
      'foto_path': fotoPath,
      if (adminPinHash != null) 'admin_pin_hash': adminPinHash,
      if (adminPinHash != null) 'admin_pin': '',
    };
    if (existing.isEmpty) {
      await db.insert('profil', {
        'nama': nama,
        'foto_path': fotoPath,
        'admin_pin': '',
        'admin_pin_hash': adminPinHash ?? '',
      });
    } else {
      await db.update(
        'profil',
        data,
        where: 'id = ?',
        whereArgs: [existing.first['id']],
      );
    }
  }

  /// Koreksi Saldo Profesional: membuat entri adjustment ke wallet_transactions
  /// agar saldo bersih = [targetBalance]. Membuat jejak audit yang dapat dilacak.
  Future<void> adjustWalletBalance({
    required String walletId, // 'tunai' atau 'non_tunai'
    required int targetBalance,
    String keterangan = 'Penyesuaian Saldo Admin',
  }) async {
    final currentBalance = await getWalletBalance(walletId: walletId);
    final selisih = targetBalance - currentBalance;
    if (selisih == 0) return; // Tidak perlu koreksi

    final now = DateTime.now();
    final tanggal = now.toIso8601String().substring(0, 10);
    final waktu =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';

    final db = await database;
    await _ensureWalletTransactionSchema(db);
    await db.insert('wallet_transactions', {
      'wallet_id': _canonicalWalletId(walletId),
      'nominal': selisih.abs(),
      'type': selisih > 0 ? 'masuk' : 'keluar',
      'tanggal': tanggal,
      'waktu': waktu,
      'keterangan': keterangan,
      'created_at': now.toIso8601String(),
      'kategori': 'Koreksi',
      'foto_path': '',
      'source': 'adjustment',
      'is_deleted': 0,
      'deleted_at': null,
      'updated_at': now.toIso8601String(),
    });
  }

  // ============== WARUNG PROFILE ================
  Future<Map<String, String>> getWarungProfile() async {
    final db = await database;
    final result = await db.query('warung_profile', limit: 1);
    if (result.isEmpty) {
      return {
        'nama': '',
        'alamat': '',
        'telepon': '',
        'catatan': '',
        'logo_path': '',
      };
    }

    final row = result.first;
    return {
      'nama': row['nama'] as String? ?? '',
      'alamat': row['alamat'] as String? ?? '',
      'telepon': row['telepon'] as String? ?? '',
      'catatan': row['catatan'] as String? ?? '',
      'logo_path': row['logo_path'] as String? ?? '',
      'instagram': row['instagram'] as String? ?? '',
      'facebook': row['facebook'] as String? ?? '',
      'tiktok': row['tiktok'] as String? ?? '',
    };
  }

  Future<void> saveWarungProfile({
    required String nama,
    required String alamat,
    required String telepon,
    required String catatan,
    required String logoPath,
    String? instagram,
    String? facebook,
    String? tiktok,
  }) async {
    final db = await database;
    final existing = await db.query('warung_profile', limit: 1);
    final now = DateTime.now().toIso8601String();

    final data = {
      'nama': nama,
      'alamat': alamat,
      'telepon': telepon,
      'catatan': catatan,
      'logo_path': logoPath,
      'updated_at': now,
      if (instagram != null) 'instagram': instagram,
      if (facebook != null) 'facebook': facebook,
      if (tiktok != null) 'tiktok': tiktok,
    };

    if (existing.isEmpty) {
      await db.insert('warung_profile', data);
    } else {
      await db.update(
        'warung_profile',
        data,
        where: 'id = ?',
        whereArgs: [existing.first['id']],
      );
    }
  }

  Future<bool> isWarungProfileComplete() async {
    final profile = await getWarungProfile();
    return profile['nama']!.trim().isNotEmpty &&
        profile['alamat']!.trim().isNotEmpty &&
        profile['telepon']!.trim().isNotEmpty;
  }

  // ============== CICILAN ================
  Future<int> insertCicilan(Cicilan cicilan) async {
    final db = await database;
    return await db.transaction<int>((txn) async {
      // 1. Simpan cicilan
      final cicilanId = await txn.insert('cicilans', cicilan.toMap());

      // 2. Tambah saldo dompet (pemasukan riil)
      if (cicilan.nominal > 0) {
        final now = DateTime.tryParse(cicilan.createdAt) ?? DateTime.now();
        await txn.insert('wallet_transactions', {
          'wallet_id': cicilan.metodePembayaran,
          'nominal': cicilan.nominal,
          'type': 'masuk',
          'tanggal': now.toIso8601String().substring(0, 10),
          'waktu': now.toIso8601String().substring(11, 16),
          'keterangan': 'Pelunasan Belum Lunas',
          'created_at': cicilan.createdAt,
          'kategori': 'Pelunasan',
          'foto_path': '',
          'source': 'system',
          'updated_at': cicilan.createdAt,
        });
      }
      return cicilanId;
    });
  }

  Future<List<Cicilan>> getCicilansByTransactionId(int transactionId) async {
    final db = await database;
    final result = await db.query(
      'cicilans',
      where: 'transaction_id = ?',
      whereArgs: [transactionId],
      orderBy: 'created_at ASC',
    );
    return result.map((m) => Cicilan.fromMap(m)).toList();
  }

  Future<void> updateTransactionAmountPaid(
      int transactionId, int amountPaid) async {
    final db = await database;
    await db.update(
      'transactions',
      {
        'amount_paid': amountPaid,
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [transactionId],
    );
  }

  Future<void> updateTransactionStatus(int transactionId, String status) async {
    final db = await database;
    await db.update(
      'transactions',
      {
        'payment_status': status,
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [transactionId],
    );
  }

  Future<void> updatePiutangDueDate(int transactionId, String? dueDate) async {
    final db = await database;
    await db.update(
      'transactions',
      {
        'due_date': dueDate,
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [transactionId],
    );
  }

  Future<void> markPiutangReminderSent(int transactionId) async {
    final db = await database;
    await db.rawUpdate(
      '''
      UPDATE transactions
      SET last_reminder_at = ?, reminder_count = COALESCE(reminder_count, 0) + 1
      WHERE id = ?
      ''',
      [DateTime.now().toIso8601String(), transactionId],
    );
  }

  // ============== AUDIT LOGS ================
  Future<int> insertAuditLog(AuditLog log) async {
    final db = await database;
    await _ensureCoreSchema(db);
    final data = log.toMap()..remove('id');
    return db.insert('audit_logs', data);
  }

  Future<List<AuditLog>> getAuditLogs({
    DateTime? start,
    DateTime? end,
    String? action,
    int limit = 300,
  }) async {
    final db = await database;
    await _ensureCoreSchema(db);

    final clauses = <String>[];
    final args = <Object?>[];
    if (start != null) {
      clauses.add('created_at >= ?');
      args.add(start.toIso8601String());
    }
    if (end != null) {
      clauses.add('created_at < ?');
      args.add(end.toIso8601String());
    }
    if (action != null && action.trim().isNotEmpty && action != 'all') {
      clauses.add('action = ?');
      args.add(action);
    }

    final result = await db.query(
      'audit_logs',
      where: clauses.isEmpty ? null : clauses.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'created_at DESC',
      limit: limit,
    );
    return result.map((m) => AuditLog.fromMap(m)).toList();
  }

  // ============== DISCOUNTS ================
  Future<int> insertDiscount(Discount discount) async {
    final db = await database;
    return await db.insert('discounts', discount.toMap());
  }

  Future<void> updateDiscount(Discount discount) async {
    final db = await database;
    await db.update(
      'discounts',
      discount.toMap(),
      where: 'id = ?',
      whereArgs: [discount.id],
    );
  }

  Future<List<Discount>> getAllDiscounts() async {
    final db = await database;
    final result = await db.query('discounts', orderBy: 'created_at DESC');
    return result.map((m) => Discount.fromMap(m)).toList();
  }

  Future<void> deleteDiscount(int id) async {
    final db = await database;
    await db.delete('discounts', where: 'id = ?', whereArgs: [id]);
  }

  // ============== PAYMENT SETTINGS ============
  Future<Map<String, dynamic>?> getPaymentSettings() async {
    final db = await database;
    final maps = await db.query('payment_settings', limit: 1);
    if (maps.isNotEmpty) return maps.first;
    return null;
  }

  Future<void> savePaymentSettings({
    required String qrisPath,
    required String bankName,
    required String accountName,
    required String accountNumber,
    String? banksJson,
    String? qrisName,
  }) async {
    final db = await database;
    final existing = await db.query('payment_settings');

    final data = {
      'qris_path': qrisPath,
      'bank_name': bankName,
      'account_name': accountName,
      'account_number': accountNumber,
      'banks_json': banksJson,
      'qris_name': qrisName ?? '',
    };

    if (existing.isEmpty) {
      await db.insert('payment_settings', data);
    } else {
      await db.update('payment_settings', data,
          where: 'id = ?', whereArgs: [existing.first['id']]);
    }
  }

  // ============== KASIR SESSIONS ============

  /// Simpan sesi baru (buka kasir) returns new id.
  Future<int> insertKasirSession(KasirSession session) async {
    final db = await database;
    await _ensureCoreSchema(db);
    final data = session.toMap()..remove('id');
    final supportsStaffId = await _hasColumn(db, 'kasir_sessions', 'staff_id');
    final supportsStaffName =
        await _hasColumn(db, 'kasir_sessions', 'staff_name');
    final supportsStaffRole =
        await _hasColumn(db, 'kasir_sessions', 'staff_role');
    final supportsDeviceId =
        await _hasColumn(db, 'kasir_sessions', 'device_id');
    if (!supportsStaffId) data.remove('staff_id');
    if (!supportsStaffName) data.remove('staff_name');
    if (!supportsStaffRole) data.remove('staff_role');
    if (!supportsDeviceId) data.remove('device_id');
    return await db.insert('kasir_sessions', data);
  }

  /// Tutup sesi yang sedang aktif (closed_at masih NULL).
  Future<void> closeKasirSession({
    required int id,
    required String closedAt,
    required int closingCash,
    required int totalTransactions,
    required int totalRevenue,
    required int totalCash,
    required int totalNonCash,
    String? notes,
    String? deviceId,
  }) async {
    final db = await database;
    await _ensureCoreSchema(db);
    final cleanDeviceId = deviceId?.trim() ?? '';
    final where = cleanDeviceId.isEmpty
        ? 'id = ?'
        : '''
          id = ?
          OR (
            (closed_at IS NULL OR TRIM(closed_at) = '')
            AND TRIM(COALESCE(device_id, '')) = ?
          )
        ''';
    final whereArgs =
        cleanDeviceId.isEmpty ? <Object?>[id] : <Object?>[id, cleanDeviceId];
    await db.update(
      'kasir_sessions',
      {
        'closed_at': closedAt,
        'closing_cash': closingCash,
        'total_transactions': totalTransactions,
        'total_revenue': totalRevenue,
        'total_cash': totalCash,
        'total_non_cash': totalNonCash,
        if (notes != null) 'notes': notes,
        if (cleanDeviceId.isNotEmpty) 'device_id': cleanDeviceId,
      },
      where: where,
      whereArgs: whereArgs,
    );
  }

  /// Ambil semua sesi, terbaru di atas.
  Future<List<KasirSession>> getAllKasirSessions() async {
    final db = await database;
    final result = await db.query(
      'kasir_sessions',
      orderBy: 'opened_at DESC',
    );
    return result.map((m) => KasirSession.fromMap(m)).toList();
  }

  /// Cari sesi yang masih terbuka (closed_at IS NULL).
  Future<KasirSession?> getActiveKasirSession({String? deviceId}) async {
    final db = await database;
    await _ensureCoreSchema(db);
    final cleanDeviceId = deviceId?.trim() ?? '';
    if (cleanDeviceId.isNotEmpty) {
      final local = await db.query(
        'kasir_sessions',
        where: '''
          (closed_at IS NULL OR TRIM(closed_at) = '')
          AND TRIM(COALESCE(device_id, '')) = ?
        ''',
        whereArgs: [cleanDeviceId],
        limit: 1,
        orderBy: 'opened_at DESC',
      );
      if (local.isNotEmpty) return KasirSession.fromMap(local.first);

      final legacy = await db.query(
        'kasir_sessions',
        where: '''
          (closed_at IS NULL OR TRIM(closed_at) = '')
          AND TRIM(COALESCE(device_id, '')) = ''
        ''',
        orderBy: 'opened_at DESC',
      );
      final hasKnownDeviceSession = (await db.query(
        'kasir_sessions',
        where: "TRIM(COALESCE(device_id, '')) <> ''",
        limit: 1,
      ))
          .isNotEmpty;
      if (!hasKnownDeviceSession && legacy.length == 1) {
        final row = legacy.first;
        final id = (row['id'] as num?)?.toInt();
        if (id != null) {
          await db.update(
            'kasir_sessions',
            {'device_id': cleanDeviceId},
            where: 'id = ?',
            whereArgs: [id],
          );
          return KasirSession.fromMap({...row, 'device_id': cleanDeviceId});
        }
      }
      return null;
    }

    final result = await db.query(
      'kasir_sessions',
      where: "closed_at IS NULL OR TRIM(closed_at) = ''",
      limit: 1,
      orderBy: 'opened_at DESC',
    );
    if (result.isEmpty) return null;
    return KasirSession.fromMap(result.first);
  }

  Future<void> clearWalletTransactions() async {
    final db = await database;
    await db.delete('wallet_transactions');
  }

  Future<Map<String, dynamic>> getTransactionSummaryBetween(
      String from, String to) async {
    final db = await database;
    await _ensureWalletTransactionSchema(db);

    final rows = await db.query(
      'transactions',
      where: 'is_deleted = 0 AND created_at >= ? AND created_at < ?',
      whereArgs: [from, to],
    );
    final totalTrx = rows.length;
    var fallbackRevenue = 0;
    var fallbackNonCash = 0;

    for (final r in rows) {
      final gt = (r['grand_total'] as num?)?.toInt() ?? 0;
      final pm = r['payment_method'] as String? ?? '';
      final amountPaid = (r['amount_paid'] as num?)?.toInt() ?? 0;
      final changeAmount = (r['change_amount'] as num?)?.toInt() ?? 0;
      final paidNet = (amountPaid - changeAmount).clamp(0, gt).toInt();
      if (paidNet <= 0) continue;

      fallbackRevenue += paidNet;
      fallbackNonCash += _splitWalletNominal(pm, paidNet)[1];
    }

    final walletRows = await db.query(
      'wallet_transactions',
      columns: ['wallet_id', 'nominal', 'type', 'kategori', 'is_deleted'],
      where: 'created_at >= ? AND created_at < ?',
      whereArgs: [from, to],
    );

    var ledgerRevenue = 0;
    var ledgerNonCash = 0;
    var hasLedgerRevenue = false;
    for (final row in walletRows) {
      final category = row['kategori']?.toString().trim().toLowerCase() ?? '';
      final type = row['type']?.toString().trim().toLowerCase() ?? '';
      if (!_shiftRevenueCategories.contains(category) || type != 'masuk') {
        continue;
      }

      if ((row['is_deleted'] as num?)?.toInt() == 1) {
        continue;
      }

      final nominal = (row['nominal'] as num?)?.toInt() ?? 0;
      if (nominal <= 0) continue;

      hasLedgerRevenue = true;
      ledgerRevenue += nominal;
      final walletId = row['wallet_id']?.toString() ?? 'tunai';
      ledgerNonCash += _splitWalletNominal(walletId, nominal)[1];
    }

    final totalCash = await getPhysicalCashFlow(since: from, until: to);
    final totalRevenue = hasLedgerRevenue ? ledgerRevenue : fallbackRevenue;
    final totalNonCash = hasLedgerRevenue ? ledgerNonCash : fallbackNonCash;

    return {
      'total_transactions': totalTrx,
      'total_revenue': totalRevenue,
      'total_cash':
          hasLedgerRevenue ? totalCash : fallbackRevenue - fallbackNonCash,
      'total_non_cash': totalNonCash,
    };
  }

  /// Mendapatkan total arus kas fisik (uang tunai) di laci.
  Future<int> getPhysicalCashFlow({String? since, String? until}) async {
    final db = await database;
    await _ensureWalletTransactionSchema(db);
    final whereParts = <String>['is_deleted = 0'];
    final args = <dynamic>[];

    if (since != null) {
      whereParts.add('created_at >= ?');
      args.add(since);
    }
    if (until != null) {
      whereParts.add('created_at < ?');
      args.add(until);
    }

    final rows = await db.query(
      'wallet_transactions',
      columns: ['wallet_id', 'nominal', 'type', 'created_at', 'kategori'],
      where: whereParts.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
    );

    var total = 0;
    for (final row in rows) {
      final category = row['kategori']?.toString().trim().toLowerCase() ?? '';
      if (!_cashShiftLedgerCategories.contains(category)) continue;

      final walletId = row['wallet_id']?.toString() ?? 'tunai';
      final nominal = (row['nominal'] as num?)?.toInt() ?? 0;
      if (nominal <= 0) continue;
      final sign = row['type']?.toString().toLowerCase() == 'keluar' ? -1 : 1;
      final split = _splitWalletNominal(walletId, nominal);
      total += sign * split[0];
    }
    return total;
  }

  /// Mendapatkan total arus pembayaran non-tunai pada rentang tertentu.
  Future<int> getNonCashFlow({String? since, String? until}) async {
    final db = await database;
    await _ensureWalletTransactionSchema(db);
    final whereParts = <String>['is_deleted = 0'];
    final args = <dynamic>[];

    if (since != null) {
      whereParts.add('created_at >= ?');
      args.add(since);
    }
    if (until != null) {
      whereParts.add('created_at < ?');
      args.add(until);
    }

    final rows = await db.query(
      'wallet_transactions',
      columns: ['wallet_id', 'nominal', 'type', 'created_at', 'kategori'],
      where: whereParts.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
    );

    var total = 0;
    for (final row in rows) {
      final category = row['kategori']?.toString().trim().toLowerCase() ?? '';
      if (!_cashShiftLedgerCategories.contains(category)) continue;

      final walletId = row['wallet_id']?.toString() ?? 'tunai';
      final nominal = (row['nominal'] as num?)?.toInt() ?? 0;
      if (nominal <= 0) continue;
      final sign = row['type']?.toString().toLowerCase() == 'keluar' ? -1 : 1;
      final split = _splitWalletNominal(walletId, nominal);
      total += sign * split[1];
    }
    return total;
  }

  /// Ambil riwayat stok masuk yang akan kedaluwarsa dalam [days] ke depan.
  Future<List<Map<String, dynamic>>> getNearExpiryBatches(
      {int days = 30}) async {
    final db = await database;
    final now = DateTime.now();
    final todayStr = now.toIso8601String().substring(0, 10);
    final limitDate =
        now.add(Duration(days: days)).toIso8601String().substring(0, 10);

    return await db.rawQuery('''
      SELECT sl.*, p.name as product_name, p.image_path as image_path,
             p.is_material as is_material
      FROM stock_logs sl
      JOIN products p ON p.id = sl.product_id
      WHERE sl.type = 'in' 
        AND sl.expiry_date IS NOT NULL 
        AND sl.expiry_date != ''
        AND sl.expiry_date >= ?
        AND sl.expiry_date <= ?
      ORDER BY sl.expiry_date ASC
    ''', [todayStr, limitDate]);
  }

  //  SUPPLIER METHODS

  Future<int> insertSupplier(Supplier s) async {
    final db = await database;
    return await db.insert('suppliers', s.toMap()..remove('id'));
  }

  Future<List<Supplier>> getAllSuppliers() async {
    final db = await database;
    final rows = await db.query('suppliers', orderBy: 'name ASC');
    return rows.map(Supplier.fromMap).toList();
  }

  Future<int> updateSupplier(Supplier s) async {
    final db = await database;
    return await db
        .update('suppliers', s.toMap(), where: 'id = ?', whereArgs: [s.id]);
  }

  Future<void> deleteSupplier(int id) async {
    final db = await database;
    await db.delete('suppliers', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> addHutangSupplier(int supplierId, int amount) async {
    final db = await database;
    await db.rawUpdate('UPDATE suppliers SET hutang = hutang + ? WHERE id = ?',
        [amount, supplierId]);
  }

  Future<void> bayarHutangSupplier(int supplierId, int amount) async {
    final db = await database;
    await db.rawUpdate(
        'UPDATE suppliers SET hutang = MAX(0, hutang - ?) WHERE id = ?',
        [amount, supplierId]);
  }

  Future<void> setSupplierProducts(
    int supplierId,
    Set<int> productIds,
  ) async {
    final db = await database;
    await _ensureProductSupplierSchema(db);
    await db.transaction((txn) async {
      await txn.update(
        'products',
        {'supplier_id': null},
        where: 'supplier_id = ?',
        whereArgs: [supplierId],
      );

      if (productIds.isEmpty) return;

      final placeholders = _sqlPlaceholders(productIds.length);
      await txn.rawUpdate(
        '''
        UPDATE products
        SET supplier_id = ?
        WHERE id IN ($placeholders)
          AND has_stock_management = 1
        ''',
        [supplierId, ...productIds],
      );
    });
  }

  Future<Map<int, List<Map<String, dynamic>>>> getSupplierProductSummaryMap({
    int limitPerSupplier = 100,
  }) async {
    final db = await database;
    await _ensureProductSupplierSchema(db);
    final rows = await db.rawQuery('''
      SELECT
        p.supplier_id,
        p.id AS product_id,
        p.name AS product_name,
        p.unit AS unit,
        p.stock AS total_qty,
        p.buy_price AS buy_price,
        p.has_stock_management AS has_stock_management
      FROM products p
      WHERE p.supplier_id IS NOT NULL
        AND p.has_stock_management = 1
      ORDER BY p.supplier_id ASC, p.name ASC
    ''');

    final result = <int, List<Map<String, dynamic>>>{};
    for (final row in rows) {
      final supplierId = (row['supplier_id'] as num?)?.toInt();
      if (supplierId == null) continue;
      final list = result.putIfAbsent(supplierId, () => []);
      if (list.length >= limitPerSupplier) continue;
      list.add(Map<String, dynamic>.from(row));
    }
    return result;
  }

  //  PURCHASE ORDER METHODS

  Future<List<Product>> getProductsForSupplierPurchase({
    int? supplierId,
    bool fallbackToAllStockManaged = true,
  }) async {
    final db = await database;
    await _ensureProductSupplierSchema(db);

    if (supplierId != null) {
      final rows = await db.query(
        'products',
        where: 'supplier_id = ? AND has_stock_management = 1',
        whereArgs: [supplierId],
        orderBy: 'name ASC',
      );
      if (rows.isNotEmpty || !fallbackToAllStockManaged) {
        return rows.map(Product.fromMap).toList();
      }
    }

    final rows = await db.query(
      'products',
      where: 'has_stock_management = 1',
      orderBy: 'name ASC',
    );
    return rows.map(Product.fromMap).toList();
  }

  Future<int> insertPurchaseOrder(PurchaseOrder po) async {
    final db = await database;
    return await db.insert('purchase_orders', po.toMap()..remove('id'));
  }

  Future<List<PurchaseOrder>> getAllPurchaseOrders() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT po.*,
             COALESCE(SUM(pi.received_qty * pi.unit_price), 0) as received_amount
      FROM purchase_orders po
      LEFT JOIN purchase_items pi ON pi.purchase_order_id = po.id
      GROUP BY po.id
      ORDER BY po.created_at DESC
    ''');
    return rows.map(PurchaseOrder.fromMap).toList();
  }

  Future<PurchaseOrder?> getPurchaseOrderById(int id) async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT po.*,
             COALESCE(SUM(pi.received_qty * pi.unit_price), 0) as received_amount
      FROM purchase_orders po
      LEFT JOIN purchase_items pi ON pi.purchase_order_id = po.id
      WHERE po.id = ?
      GROUP BY po.id
      LIMIT 1
    ''', [id]);
    if (rows.isEmpty) return null;
    return PurchaseOrder.fromMap(rows.first);
  }

  Future<int> insertPurchaseItem(PurchaseItem item) async {
    final db = await database;
    return await db.insert('purchase_items', item.toMap()..remove('id'));
  }

  Future<List<PurchaseItem>> getPurchaseItems(int poId) async {
    final db = await database;
    final rows = await db.query('purchase_items',
        where: 'purchase_order_id = ?', whereArgs: [poId]);
    return rows.map(PurchaseItem.fromMap).toList();
  }

  Future<int> getPurchaseOrderReceivedValue(int poId) async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(received_qty * unit_price), 0) as total
      FROM purchase_items
      WHERE purchase_order_id = ?
    ''', [poId]);
    return (rows.first['total'] as num?)?.toInt() ?? 0;
  }

  /// Konfirmasi terima pembelian: stok bertambah sesuai qty yang diterima.
  /// Jika [receivedQtyByItemId] kosong, semua sisa barang akan diterima.
  Future<void> receivePurchaseOrder(
    int poId, {
    Map<int, int>? receivedQtyByItemId,
  }) async {
    final db = await database;
    final now = DateTime.now().toIso8601String();
    final items = await getPurchaseItems(poId);
    final po = await getPurchaseOrderById(poId);
    if (po == null) return;
    if (po.status == 'received') return;

    await db.transaction((txn) async {
      var receivedValue = 0;
      var allReceived = true;

      // Tambah stok setiap produk + buat stock log
      for (final item in items) {
        final itemId = item.id;
        final requestedQty = itemId == null
            ? item.remainingQty
            : (receivedQtyByItemId?[itemId] ?? item.remainingQty);
        final qtyToReceive = requestedQty.clamp(0, item.remainingQty).toInt();
        final newReceivedQty = item.receivedQty + qtyToReceive;
        if (newReceivedQty < item.qty) allReceived = false;
        if (qtyToReceive <= 0) continue;

        final productRows = await txn.query('products',
            where: 'id = ?', whereArgs: [item.productId], limit: 1);
        if (productRows.isEmpty) continue;
        final currentStock = productRows.first['stock'] as int? ?? 0;
        final currentBuyPrice = productRows.first['buy_price'] as int? ?? 0;
        final newStock = currentStock + qtyToReceive;
        receivedValue += qtyToReceive * item.unitPrice;
        final newBuyPrice = currentStock > 0 && currentBuyPrice > 0
            ? (((currentStock * currentBuyPrice) +
                        (qtyToReceive * item.unitPrice)) /
                    newStock)
                .round()
            : item.unitPrice;

        if (itemId != null) {
          await txn.update(
            'purchase_items',
            {'received_qty': newReceivedQty},
            where: 'id = ?',
            whereArgs: [itemId],
          );
        }

        await txn.update(
          'products',
          {'stock': newStock, 'buy_price': newBuyPrice},
          where: 'id = ?',
          whereArgs: [item.productId],
        );

        await txn.insert('stock_logs', {
          'product_id': item.productId,
          'type': 'in',
          'qty': qtyToReceive,
          'date': now,
          'stock_name': 'Pembelian #$poId',
          'entry_date': now.substring(0, 10),
          'old_qty': currentStock,
          'new_qty': newStock,
          'employee_name': 'Supplier: ${po.supplierName}',
        });
      }

      final nextStatus = allReceived ? 'received' : 'partial_received';
      await txn.update(
        'purchase_orders',
        {
          'status': nextStatus,
          'received_at': po.receivedAt ?? now,
        },
        where: 'id = ?',
        whereArgs: [poId],
      );

      // Barang diterima menjadi hutang supplier sampai dibayar.
      if (po.supplierId != null && receivedValue > 0) {
        await txn.rawUpdate(
            'UPDATE suppliers SET hutang = hutang + ? WHERE id = ?',
            [receivedValue, po.supplierId]);
      }
    });
  }

  Future<void> payPurchaseOrder(
    int poId, {
    required int amount,
    String walletId = 'tunai',
  }) async {
    final db = await database;
    final po = await getPurchaseOrderById(poId);
    if (po == null) return;
    if (po.isPaid == 1) return;
    final receivedValue = await getPurchaseOrderReceivedValue(poId);
    final currentPaid = po.effectivePaidAmount;
    final payable =
        (receivedValue - currentPaid).clamp(0, po.totalAmount).toInt();
    final amountToPay = amount.clamp(0, payable).toInt();
    if (amountToPay <= 0) return;

    final paymentAt = DateTime.tryParse(po.createdAt) ?? DateTime.now();
    final tanggal = _dateKey(paymentAt);
    final waktu =
        '${paymentAt.hour.toString().padLeft(2, '0')}:${paymentAt.minute.toString().padLeft(2, '0')}';

    await db.transaction((txn) async {
      final nextPaid =
          (currentPaid + amountToPay).clamp(0, po.totalAmount).toInt();
      final isFullyPaid = nextPaid >= po.totalAmount ? 1 : 0;
      await txn.update(
        'purchase_orders',
        {'is_paid': isFullyPaid, 'paid_amount': nextPaid},
        where: 'id = ?',
        whereArgs: [poId],
      );

      if (po.supplierId != null) {
        await txn.rawUpdate(
            'UPDATE suppliers SET hutang = MAX(0, hutang - ?) WHERE id = ?',
            [amountToPay, po.supplierId]);
      }

      await txn.insert('wallet_transactions', {
        'wallet_id': walletId,
        'nominal': amountToPay,
        'type': 'keluar',
        'tanggal': tanggal,
        'waktu': waktu,
        'keterangan': isFullyPaid == 1
            ? 'Pelunasan Pembelian #$poId - ${po.supplierName}'
            : 'Bayar sebagian Pembelian #$poId - ${po.supplierName}',
        'created_at': paymentAt.toIso8601String(),
        'kategori': 'Pembelian Stok',
        'foto_path': '',
        'source': 'system',
        'updated_at': paymentAt.toIso8601String(),
      });
    });
  }

  Future<void> markPurchaseOrderPaid(int poId) async {
    final po = await getPurchaseOrderById(poId);
    if (po == null) return;
    final receivedValue = await getPurchaseOrderReceivedValue(poId);
    final payable = receivedValue - po.effectivePaidAmount;
    await payPurchaseOrder(poId, amount: payable);
  }

  Future<void> cancelPurchaseOrder(int id) async {
    final db = await database;
    final po = await getPurchaseOrderById(id);
    if (po == null) return;
    final items = await getPurchaseItems(id);

    final now = DateTime.now();
    final nowIso = now.toIso8601String();
    final tanggal = _dateKey(now);
    final waktu =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

    await db.transaction((txn) async {
      var receivedValue = 0;

      for (final item in items) {
        final qtyToReverse = item.receivedQty;
        if (qtyToReverse <= 0) continue;
        receivedValue += qtyToReverse * item.unitPrice;

        final productRows = await txn.query(
          'products',
          where: 'id = ?',
          whereArgs: [item.productId],
          limit: 1,
        );
        if (productRows.isEmpty) continue;

        final currentStock = (productRows.first['stock'] as num?)?.toInt() ?? 0;
        final newStock = currentStock - qtyToReverse;

        await txn.update(
          'products',
          {'stock': newStock},
          where: 'id = ?',
          whereArgs: [item.productId],
        );

        await txn.insert('stock_logs', {
          'product_id': item.productId,
          'type': 'out',
          'qty': qtyToReverse,
          'date': nowIso,
          'stock_name': 'Pembatalan Pembelian #$id',
          'entry_date': nowIso.substring(0, 10),
          'old_qty': currentStock,
          'new_qty': newStock,
          'employee_name': 'Supplier: ${po.supplierName}',
        });
      }

      final paidForDebt =
          po.effectivePaidAmount.clamp(0, receivedValue).toInt();
      final debtToRemove =
          (receivedValue - paidForDebt).clamp(0, receivedValue).toInt();
      if (po.supplierId != null && debtToRemove > 0) {
        await txn.rawUpdate(
          'UPDATE suppliers SET hutang = MAX(0, hutang - ?) WHERE id = ?',
          [debtToRemove, po.supplierId],
        );
      }

      final paymentRows = await txn.query(
        'wallet_transactions',
        where: 'type = ? AND keterangan LIKE ?',
        whereArgs: ['keluar', '%Pembelian #$id -%'],
      );
      for (final row in paymentRows) {
        final nominal = (row['nominal'] as num?)?.toInt() ?? 0;
        if (nominal <= 0) continue;
        await txn.insert('wallet_transactions', {
          'wallet_id': row['wallet_id']?.toString() ?? 'tunai',
          'nominal': nominal,
          'type': 'masuk',
          'tanggal': tanggal,
          'waktu': waktu,
          'keterangan': 'Pembatalan Pembelian #$id - ${po.supplierName}',
          'created_at': nowIso,
          'kategori': 'Pembatalan Pembelian',
          'foto_path': '',
          'source': 'system',
          'updated_at': nowIso,
        });
      }

      await txn.delete(
        'purchase_items',
        where: 'purchase_order_id = ?',
        whereArgs: [id],
      );
      await txn.delete('purchase_orders', where: 'id = ?', whereArgs: [id]);
    });
  }

  Future<void> deletePurchaseOrder(int id) async {
    await cancelPurchaseOrder(id);
  }

  //  PENGELUARAN / LABA RUGI METHODS

  /// Rekap semua arus kas keluar per kategori pada rentang tanggal.
  Future<Map<String, int>> getExpensesByCategoryRange(
      DateTime start, DateTime end) async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT kategori, SUM(nominal) as total
      FROM wallet_transactions
      WHERE type = 'keluar'
        AND is_deleted = 0
        AND tanggal >= ? AND tanggal < ?
        AND TRIM(kategori) != ''
      GROUP BY kategori
      ORDER BY total DESC
    ''', [_dateKey(start), _dateKey(end)]);

    final result = <String, int>{};
    for (final row in rows) {
      result[row['kategori'] as String] = (row['total'] as num?)?.toInt() ?? 0;
    }
    return result;
  }

  /// Rekap biaya operasional per kategori pada rentang tanggal.
  Future<Map<String, int>> getOperationalExpensesByCategoryRange(
      DateTime start, DateTime end) async {
    final db = await database;
    final placeholders =
        _sqlPlaceholders(_nonOperationalExpenseCategories.length);
    final rows = await db.rawQuery('''
      SELECT kategori, SUM(nominal) as total
      FROM wallet_transactions
      WHERE type = 'keluar'
        AND is_deleted = 0
        AND tanggal >= ? AND tanggal < ?
        AND TRIM(kategori) != ''
        AND kategori NOT IN ($placeholders)
      GROUP BY kategori
      ORDER BY total DESC
    ''', [
      _dateKey(start),
      _dateKey(end),
      ..._nonOperationalExpenseCategories,
    ]);

    final result = <String, int>{};
    for (final row in rows) {
      result[row['kategori'] as String] = (row['total'] as num?)?.toInt() ?? 0;
    }
    return result;
  }

  /// Rekap pengeluaran per kategori pada bulan tertentu
  Future<Map<String, int>> getExpensesByCategory(int year, int month) async {
    final start = DateTime(year, month, 1);
    final end =
        month == 12 ? DateTime(year + 1, 1, 1) : DateTime(year, month + 1, 1);
    return getExpensesByCategoryRange(start, end);
  }

  /// Total biaya operasional pada rentang tanggal
  Future<int> getTotalExpensesRange(DateTime start, DateTime end) async {
    final db = await database;
    final placeholders =
        _sqlPlaceholders(_nonOperationalExpenseCategories.length);
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(nominal), 0) as total
      FROM wallet_transactions
      WHERE type = 'keluar'
        AND is_deleted = 0
        AND tanggal >= ? AND tanggal < ?
        AND TRIM(kategori) != ''
        AND kategori NOT IN ($placeholders)
    ''', [
      _dateKey(start),
      _dateKey(end),
      ..._nonOperationalExpenseCategories,
    ]);
    return (rows.first['total'] as num?)?.toInt() ?? 0;
  }

  /// Total biaya operasional pada bulan tertentu
  Future<int> getTotalExpenses(int year, int month) async {
    final start = DateTime(year, month, 1);
    final end =
        month == 12 ? DateTime(year + 1, 1, 1) : DateTime(year, month + 1, 1);
    return getTotalExpensesRange(start, end);
  }

  /// Pembelian stok/unit/aset tetap dicatat di arus kas, bukan beban periode.
  Future<int> getInventoryPurchaseCashOutRange(
      DateTime start, DateTime end) async {
    final db = await database;
    final placeholders = _sqlPlaceholders(_inventoryPurchaseCategories.length);
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(nominal), 0) as total
      FROM wallet_transactions
      WHERE type = 'keluar'
        AND is_deleted = 0
        AND tanggal >= ? AND tanggal < ?
        AND kategori IN ($placeholders)
    ''', [
      _dateKey(start),
      _dateKey(end),
      ..._inventoryPurchaseCategories,
    ]);
    return (rows.first['total'] as num?)?.toInt() ?? 0;
  }

  Future<int> _getGrossHppRange(
    Database db,
    DateTime start,
    DateTime end,
  ) async {
    final rows = await db.rawQuery('''
      WITH item_costs AS (
        SELECT
          ti.transaction_id,
          ti.product_id,
          SUM(ti.qty) as total_qty,
          SUM(
            CASE
              WHEN COALESCE(p.is_material, 0) = 0
              THEN COALESCE(p.buy_price, 0) * ti.qty
              ELSE 0
            END
          ) as product_hpp
        FROM transaction_items ti
        JOIN transactions t ON ti.transaction_id = t.id
        LEFT JOIN products p ON ti.product_id = p.id
        WHERE t.is_deleted = 0
          AND t.created_at >= ?
          AND t.created_at < ?
        GROUP BY ti.transaction_id, ti.product_id
      ),
      material_costs AS (
        SELECT
          tmu.transaction_id,
          tmu.service_product_id as product_id,
          SUM(tmu.qty * COALESCE(mp.buy_price, 0)) as material_hpp
        FROM transaction_material_usages tmu
        JOIN transactions t ON t.id = tmu.transaction_id
        LEFT JOIN products mp ON mp.id = tmu.material_product_id
        WHERE t.is_deleted = 0
          AND t.created_at >= ?
          AND t.created_at < ?
        GROUP BY tmu.transaction_id, tmu.service_product_id
      )
      SELECT COALESCE(SUM(
        CASE
          WHEN mc.material_hpp IS NULL THEN ic.product_hpp
          ELSE mc.material_hpp
        END
      ), 0) as hpp
      FROM item_costs ic
      LEFT JOIN material_costs mc
        ON mc.transaction_id = ic.transaction_id
       AND mc.product_id = ic.product_id
    ''', [
      start.toIso8601String(),
      end.toIso8601String(),
      start.toIso8601String(),
      end.toIso8601String(),
    ]);
    return (rows.first['hpp'] as num?)?.toInt() ?? 0;
  }

  Future<int> _getReturnHppRange(
    Database db,
    DateTime start,
    DateTime end,
  ) async {
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(
        CASE
          WHEN COALESCE(p.has_stock_management, 0) = 1
           AND COALESCE(p.is_material, 0) = 0
          THEN COALESCE(p.buy_price, 0) * ri.qty
          ELSE 0
        END
      ), 0) as hpp
      FROM return_items ri
      JOIN return_transactions rt ON rt.id = ri.return_id
      LEFT JOIN products p ON p.id = ri.product_id
      WHERE substr(rt.created_at, 1, 10) >= ?
        AND substr(rt.created_at, 1, 10) < ?
    ''', [_dateKey(start), _dateKey(end)]);
    return (rows.first['hpp'] as num?)?.toInt() ?? 0;
  }

  /// Laba Rugi rentang tanggal: omzet, HPP, laba kotor, biaya, laba bersih
  Future<Map<String, int>> getLabaRugiRange(
      DateTime start, DateTime end) async {
    final db = await database;

    final omzetRows = await db.rawQuery('''
      SELECT COALESCE(SUM(grand_total), 0) as omzet
      FROM transactions
      WHERE is_deleted = 0
        AND created_at >= ?
        AND created_at < ?
    ''', [start.toIso8601String(), end.toIso8601String()]);
    final omzetKotor = (omzetRows.first['omzet'] as num?)?.toInt() ?? 0;

    final returRows = await db.rawQuery('''
      SELECT COALESCE(SUM(total_refund), 0) as total
      FROM return_transactions
      WHERE substr(created_at, 1, 10) >= ?
        AND substr(created_at, 1, 10) < ?
    ''', [_dateKey(start), _dateKey(end)]);
    final returPenjualan = (returRows.first['total'] as num?)?.toInt() ?? 0;

    final hppKotor = await _getGrossHppRange(db, start, end);
    final hppRetur = await _getReturnHppRange(db, start, end);
    final omzet = omzetKotor - returPenjualan;
    final hpp = hppKotor - hppRetur;
    final labaKotor = omzet - hpp;
    final pengeluaran = await getTotalExpensesRange(start, end);
    final pembelianStok = await getInventoryPurchaseCashOutRange(start, end);
    final labaBersih = labaKotor - pengeluaran;

    return {
      'omzet_kotor': omzetKotor,
      'retur_penjualan': returPenjualan,
      'omzet': omzet,
      'hpp_kotor': hppKotor,
      'hpp_retur': hppRetur,
      'hpp': hpp,
      'laba_kotor': labaKotor,
      'pengeluaran': pengeluaran,
      'laba_bersih': labaBersih,
      'pembelian_stok': pembelianStok,
      'pembelian_aset': pembelianStok,
    };
  }

  /// Laba Rugi bulanan: omzet, HPP, laba kotor, biaya, laba bersih
  Future<Map<String, int>> getLabaRugiBulan(int year, int month) async {
    final start = DateTime(year, month, 1);
    final end =
        month == 12 ? DateTime(year + 1, 1, 1) : DateTime(year, month + 1, 1);
    return getLabaRugiRange(start, end);
  }

  /// Margin per layanan dengan HPP dari bahan baku terpakai atau modal produk.
  Future<List<Map<String, dynamic>>> getMarginPerProduk(
      DateTime start, DateTime end,
      {int limit = 20}) async {
    final db = await database;
    final rows = await db.rawQuery('''
      WITH sales AS (
        SELECT
          ti.transaction_id,
          ti.product_id,
          MAX(ti.product_name) as product_name,
          MAX(COALESCE(ti.unit, p.unit, 'pcs')) as unit,
          MAX(COALESCE(p.has_stock_management, 0)) as has_stock_management,
          MAX(COALESCE(p.is_material, 0)) as is_material,
          SUM(ti.qty) as total_qty,
          SUM(ti.subtotal) as total_omzet,
          SUM(
            CASE
              WHEN COALESCE(p.is_material, 0) = 0
              THEN COALESCE(p.buy_price, 0) * ti.qty
              ELSE 0
            END
          ) as product_hpp
        FROM transaction_items ti
        JOIN transactions t ON ti.transaction_id = t.id
        LEFT JOIN products p ON p.id = ti.product_id
        WHERE t.is_deleted = 0
          AND t.created_at >= ?
          AND t.created_at < ?
        GROUP BY ti.transaction_id, ti.product_id
      ),
      material_costs AS (
        SELECT
          tmu.transaction_id,
          tmu.service_product_id as product_id,
          SUM(tmu.qty * COALESCE(mp.buy_price, 0)) as material_hpp
        FROM transaction_material_usages tmu
        JOIN transactions t ON t.id = tmu.transaction_id
        LEFT JOIN products mp ON mp.id = tmu.material_product_id
        WHERE t.is_deleted = 0
          AND t.created_at >= ?
          AND t.created_at < ?
        GROUP BY tmu.transaction_id, tmu.service_product_id
      ),
      sales_by_product AS (
        SELECT
          s.product_id,
          MAX(s.product_name) as product_name,
          MAX(s.unit) as unit,
          MAX(s.has_stock_management) as has_stock_management,
          SUM(CASE WHEN mc.material_hpp IS NOT NULL THEN 1 ELSE 0 END) as recipe_usage_count,
          SUM(s.total_qty) as total_qty,
          SUM(s.total_omzet) as total_omzet,
          SUM(
            CASE
              WHEN mc.material_hpp IS NULL THEN s.product_hpp
              ELSE mc.material_hpp
            END
          ) as total_hpp
        FROM sales s
        LEFT JOIN material_costs mc
          ON mc.transaction_id = s.transaction_id
         AND mc.product_id = s.product_id
        GROUP BY s.product_id
      ),
      returns_by_product AS (
        SELECT
          ri.product_id,
          MAX(ri.product_name) as product_name,
          MAX(COALESCE(p.unit, 'pcs')) as unit,
          SUM(ri.qty) as return_qty,
          SUM(ri.subtotal) as return_omzet,
          SUM(
            CASE
              WHEN COALESCE(p.has_stock_management, 0) = 1
               AND COALESCE(p.is_material, 0) = 0
              THEN COALESCE(p.buy_price, 0) * ri.qty
              ELSE 0
            END
          ) as return_hpp
        FROM return_items ri
        JOIN return_transactions rt ON rt.id = ri.return_id
        LEFT JOIN products p ON p.id = ri.product_id
        WHERE substr(rt.created_at, 1, 10) >= ?
          AND substr(rt.created_at, 1, 10) < ?
        GROUP BY ri.product_id
      ),
      product_keys AS (
        SELECT product_id FROM sales_by_product
        UNION
        SELECT product_id FROM returns_by_product
      )
      SELECT
        pk.product_id,
        COALESCE(s.product_name, r.product_name, p.name, '-') as product_name,
        COALESCE(s.unit, r.unit, p.unit, 'pcs') as unit,
        COALESCE(s.has_stock_management, p.has_stock_management, 0) as has_stock_management,
        COALESCE(s.recipe_usage_count, 0) as recipe_usage_count,
        CASE
          WHEN COALESCE(s.recipe_usage_count, 0) > 0 THEN 'Resep bahan'
          WHEN COALESCE(s.has_stock_management, p.has_stock_management, 0) = 1 THEN 'Modal stok'
          ELSE 'HPP tidak dihitung'
        END as hpp_source,
        COALESCE(s.total_qty, 0) - COALESCE(r.return_qty, 0) as total_qty,
        COALESCE(s.total_omzet, 0) - COALESCE(r.return_omzet, 0) as total_omzet,
        COALESCE(s.total_hpp, 0) - COALESCE(r.return_hpp, 0) as total_hpp,
        COALESCE(s.total_omzet, 0) - COALESCE(r.return_omzet, 0)
          - (COALESCE(s.total_hpp, 0) - COALESCE(r.return_hpp, 0)) as laba_kotor,
        CASE
          WHEN COALESCE(s.total_omzet, 0) - COALESCE(r.return_omzet, 0) > 0
          THEN ROUND(
            100.0 * (
              COALESCE(s.total_omzet, 0) - COALESCE(r.return_omzet, 0)
              - (COALESCE(s.total_hpp, 0) - COALESCE(r.return_hpp, 0))
            ) / (COALESCE(s.total_omzet, 0) - COALESCE(r.return_omzet, 0)),
            1
          )
          ELSE 0
        END as margin_pct
      FROM product_keys pk
      LEFT JOIN sales_by_product s ON s.product_id = pk.product_id
      LEFT JOIN returns_by_product r ON r.product_id = pk.product_id
      LEFT JOIN products p ON p.id = pk.product_id
      WHERE (COALESCE(s.total_qty, 0) - COALESCE(r.return_qty, 0)) != 0
         OR (COALESCE(s.total_omzet, 0) - COALESCE(r.return_omzet, 0)) != 0
      ORDER BY laba_kotor DESC
      LIMIT ?
    ''', [
      start.toIso8601String(),
      end.toIso8601String(),
      start.toIso8601String(),
      end.toIso8601String(),
      _dateKey(start),
      _dateKey(end),
      limit,
    ]);
    return List<Map<String, dynamic>>.from(rows);
  }

  /// Data 12-bulan untuk grafik omzet vs HPP
  Future<List<Map<String, dynamic>>> getOmzetVsHppBulanan(int year) async {
    final result = <Map<String, dynamic>>[];
    for (int month = 1; month <= 12; month++) {
      final data = await getLabaRugiBulan(year, month);
      result.add({'bulan': month, ...data});
    }
    return result;
  }

  //  RETURN / RETUR METHODS

  /// Insert a return transaction with its items (restore stock + optional wallet)
  Future<int> insertReturn(
      ReturnTransaction ret, List<ReturnItem> items) async {
    final db = await database;
    return await db.transaction<int>((txn) async {
      final normalizedMethod = ret.normalizedRefundMethod;
      final retMap = ret.toMap()
        ..remove('id')
        ..['refund_method'] = normalizedMethod;
      final retId = await txn.insert('return_transactions', retMap);

      for (final item in items) {
        final itemMap = item.toMap()..remove('id');
        itemMap['return_id'] = retId;
        await txn.insert('return_items', itemMap);

        // Restore stock
        final pRows = await txn.query('products',
            where: 'id = ?', whereArgs: [item.productId], limit: 1);
        if (pRows.isNotEmpty) {
          final product = Product.fromMap(pRows.first);
          if (product.tracksInventory) {
            final currentStock = product.stock;
            final newStock = currentStock + item.qty;
            await txn.update('products', {'stock': newStock},
                where: 'id = ?', whereArgs: [item.productId]);

            await txn.insert('stock_logs', {
              'product_id': item.productId,
              'type': 'in',
              'qty': item.qty,
              'date': ret.createdAt,
              'stock_name': 'Retur #$retId',
              'old_qty': currentStock,
              'new_qty': newStock,
              'employee_name': 'Retur',
            });
          }
        }
      }

      // Refund tunai/non-tunai harus tercatat sebagai kas keluar.
      if ((normalizedMethod == 'tunai' || normalizedMethod == 'non_tunai') &&
          ret.totalRefund > 0) {
        final now = DateTime.tryParse(ret.createdAt) ?? DateTime.now();
        await txn.insert('wallet_transactions', {
          'wallet_id': normalizedMethod,
          'nominal': ret.totalRefund,
          'type': 'keluar',
          'tanggal': now.toIso8601String().substring(0, 10),
          'waktu': now.toIso8601String().substring(11, 16),
          'keterangan': 'Refund Layanan #$retId',
          'created_at': ret.createdAt,
          'kategori': 'Refund',
          'foto_path': '',
          'source': 'system',
          'updated_at': ret.createdAt,
        });
      }

      return retId;
    });
  }

  Future<List<ReturnTransaction>> getAllReturns({int limit = 200}) async {
    final db = await database;
    final result = await db.query('return_transactions',
        orderBy: 'created_at DESC', limit: limit);
    return result.map((m) => ReturnTransaction.fromMap(m)).toList();
  }

  Future<List<ReturnItem>> getReturnItems(int returnId) async {
    final db = await database;
    final result = await db
        .query('return_items', where: 'return_id = ?', whereArgs: [returnId]);
    return result.map((m) => ReturnItem.fromMap(m)).toList();
  }

  Future<List<ReturnTransaction>> getReturnsByTransactionId(int txId) async {
    final db = await database;
    final result = await db.query('return_transactions',
        where: 'transaction_id = ?',
        whereArgs: [txId],
        orderBy: 'created_at DESC');
    return result.map((m) => ReturnTransaction.fromMap(m)).toList();
  }

  Future<Map<String, int>> getReturnSummary() async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT COUNT(*) as count,
             COALESCE(SUM(total_refund), 0) as total_refund
      FROM return_transactions
    ''');
    return {
      'count': (result.first['count'] as num?)?.toInt() ?? 0,
      'total_refund': (result.first['total_refund'] as num?)?.toInt() ?? 0,
    };
  }

  //  SALES TARGET HELPER QUERIES

  Future<int> getTodaySalesTotal() async {
    final db = await database;
    final todayStr = DateTime.now().toIso8601String().substring(0, 10);
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(grand_total), 0) as total FROM transactions WHERE created_at LIKE ? AND amount_paid >= grand_total AND is_deleted = 0',
      ['$todayStr%'],
    );
    return (result.first['total'] as num?)?.toInt() ?? 0;
  }

  Future<int> getMonthSalesTotal() async {
    final db = await database;
    final now = DateTime.now();
    final monthPrefix = '${now.year}-${now.month.toString().padLeft(2, '0')}';
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(grand_total), 0) as total FROM transactions WHERE created_at LIKE ? AND amount_paid >= grand_total AND is_deleted = 0',
      ['$monthPrefix%'],
    );
    return (result.first['total'] as num?)?.toInt() ?? 0;
  }

  Future<int> getYesterdaySalesTotal() async {
    final db = await database;
    final yesterday = DateTime.now().subtract(const Duration(days: 1));
    final dateStr = yesterday.toIso8601String().substring(0, 10);
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(grand_total), 0) as total FROM transactions WHERE created_at LIKE ? AND amount_paid >= grand_total AND is_deleted = 0',
      ['$dateStr%'],
    );
    return (result.first['total'] as num?)?.toInt() ?? 0;
  }

  Future<int> getLastMonthSalesTotal() async {
    final db = await database;
    final now = DateTime.now();
    final lastMonth = DateTime(now.year, now.month - 1, 1);
    final monthPrefix =
        '${lastMonth.year}-${lastMonth.month.toString().padLeft(2, '0')}';
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(grand_total), 0) as total FROM transactions WHERE created_at LIKE ? AND amount_paid >= grand_total AND is_deleted = 0',
      ['$monthPrefix%'],
    );
    return (result.first['total'] as num?)?.toInt() ?? 0;
  }

  //  BACKUP / RESTORE METHODS

  Future<bool> backupDatabaseTo(String targetPath) async {
    Database? db;
    try {
      db = await database;
      // 1. Ensure all WAL data is checkpointed to the main .db file
      await db.rawQuery('PRAGMA wal_checkpoint(FULL);');

      final targetFile = File(targetPath);
      await targetFile.parent.create(recursive: true);
      if (await targetFile.exists()) {
        await targetFile.delete();
      }

      // 2. Try modern VACUUM INTO (Atomic backup)
      // VACUUM INTO requires SQLite 3.27.0+. Check version to prevent OS log spam on older devices.
      bool supportsVacuumInto = false;
      try {
        final versionResult = await db.rawQuery('select sqlite_version()');
        if (versionResult.isNotEmpty) {
          final versionStr = versionResult.first.values.first.toString();
          final parts = versionStr.split('.');
          if (parts.length >= 2) {
            final major = int.tryParse(parts[0]) ?? 0;
            final minor = int.tryParse(parts[1]) ?? 0;
            if (major > 3 || (major == 3 && minor >= 27)) {
              supportsVacuumInto = true;
            }
          }
        }
      } catch (_) {}

      if (supportsVacuumInto) {
        final escapedPath = targetPath.replaceAll("'", "''");
        try {
          await db.execute("VACUUM INTO '$escapedPath';");
          return true;
        } catch (e) {
          debugPrint('VACUUM INTO failed: $e');
        }
      } else {
        debugPrint(
            'VACUUM INTO unsupported on this device (SQLite < 3.27), using manual copy.');
      }

      // 3. Fallback: Manual copy after closing
      final sourcePath = await getDatabasePath();
      await close();

      try {
        final sourceFile = File(sourcePath);
        if (await sourceFile.exists()) {
          await sourceFile.copy(targetPath);
          return true;
        }
        return false;
      } catch (e) {
        if (e is PathAccessException ||
            e.toString().contains('Permission denied')) {
          // Rethrow so the service can handle fallback to internal storage
          rethrow;
        }
        debugPrint('Manual copy backup failed: $e');
        rethrow;
      } finally {
        await database; // Re-open
      }
    } catch (e) {
      if (e is! PathAccessException) {
        debugPrint('backupDatabaseTo critical failure: $e');
      }
      rethrow; // Pass to BackupService
    }
  }

  Future<void> replaceDatabaseWithFile(File sourceFile) async {
    final targetPath = await getDatabasePath();
    final targetFile = File(targetPath);
    await targetFile.parent.create(recursive: true);

    await close();

    final walFile = File('$targetPath-wal');
    final shmFile = File('$targetPath-shm');
    if (await walFile.exists()) {
      await walFile.delete();
    }
    if (await shmFile.exists()) {
      await shmFile.delete();
    }

    await sourceFile.copy(targetPath);
    await database;
  }

  /// Export semua tabel penting ke Map (untuk di-JSON-kan)
  Future<Map<String, dynamic>> exportAllData() async {
    final db = await database;
    await _ensureCoreSchema(db);
    final export = <String, dynamic>{
      'version': _dbVersion,
      'exported_at': DateTime.now().toIso8601String(),
    };

    for (final table in backupTables) {
      export[table] = await db.query(table);
    }

    return export;
  }

  /// Restore data dari Map hasil export JSON (sebelumnya importData)
  Future<void> restoreAllData(Map<String, dynamic> data) async {
    final db = await database;
    await db.transaction((txn) async {
      for (final table in restoreDeleteOrder) {
        await txn.delete(table);
      }

      for (final table in restoreInsertOrder) {
        final tableData = data[table];
        if (tableData is! List) continue;

        final rows = List<Map<String, dynamic>>.from(
          tableData.map(
            (row) => Map<String, dynamic>.from(row as Map),
          ),
        );

        if (table == 'categories') {
          for (final row in rows) {
            await txn.insert(table, row);
          }
          await _ensureCategorySchema(txn);
          continue;
        }

        for (final row in rows) {
          if (table == 'products') {
            row['category_id'] = await _ensureProductCategory(
              txn,
              _asInt(row['category_id']),
            );
          }
          await txn.insert(table, row);
        }
      }
    });
    _resetSchemaEnsureCache();
    await _ensureCoreSchema(db);
  }

  // ============== ADVANCED ANALYTICS (BI) ============

  /// Ringkasan Penjualan Harian untuk grafik/tabel tren
  Future<List<Map<String, dynamic>>> getDailySalesSummary(
      int year, int month) async {
    final db = await database;
    final startDate = '$year-${month.toString().padLeft(2, '0')}-01';
    final endDate = month == 12
        ? '${year + 1}-01-01'
        : '$year-${(month + 1).toString().padLeft(2, '0')}-01';

    final rows = await db.rawQuery('''
      SELECT 
        DATE(created_at) as date, 
        SUM(grand_total) as total_sales,
        COUNT(*) as transaction_count
      FROM transactions
      WHERE is_deleted = 0 
        AND created_at >= ? AND created_at < ?
      GROUP BY DATE(created_at)
      ORDER BY date ASC
    ''', [startDate, endDate]);
    return List<Map<String, dynamic>>.from(rows);
  }

  /// Breakdown Penjualan berdasarkan Metode Pembayaran
  Future<Map<String, int>> getSalesByPaymentMethod(int year, int month) async {
    final db = await database;
    final startDate = '$year-${month.toString().padLeft(2, '0')}-01';
    final endDate = month == 12
        ? '${year + 1}-01-01'
        : '$year-${(month + 1).toString().padLeft(2, '0')}-01';

    final rows = await db.rawQuery('''
      SELECT payment_method, SUM(grand_total) as total
      FROM transactions
      WHERE is_deleted = 0 
        AND created_at >= ? AND created_at < ?
      GROUP BY payment_method
    ''', [startDate, endDate]);

    final result = <String, int>{};
    for (final row in rows) {
      String pm = (row['payment_method']?.toString() ?? 'Lainnya').trim();
      if (pm.isEmpty) pm = 'Lainnya';
      result[pm] = (row['total'] as num?)?.toInt() ?? 0;
    }
    return result;
  }

  /// Menghitung total nilai aset gudang (stok * harga beli)
  Future<Map<String, dynamic>> getInventoryAnalysis() async {
    final db = await database;
    final stats = await db.rawQuery('''
      SELECT 
        COUNT(*) as total_skus,
        SUM(stock) as total_items,
        SUM(stock * buy_price) as total_value
      FROM products
    ''');

    final lowStock = await getLowStockProducts();

    return {
      'total_skus': (stats.first['total_skus'] as num?)?.toInt() ?? 0,
      'total_items': (stats.first['total_items'] as num?)?.toInt() ?? 0,
      'total_value': (stats.first['total_value'] as num?)?.toInt() ?? 0,
      'low_stock_count': lowStock.length,
      'low_stock_list': lowStock,
    };
  }

  /// Total pelanggan terdaftar
  Future<int> getTotalCustomerCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM customers');
    return (result.first['count'] as num?)?.toInt() ?? 0;
  }

  /// Top pelanggan berdasarkan total belanja
  Future<List<Map<String, dynamic>>> getTopCustomers({int limit = 5}) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT 
        customer_id, 
        customer_name, 
        COUNT(*) as transaction_count,
        SUM(grand_total) as total_spending
      FROM transactions
      WHERE is_deleted = 0 AND customer_id IS NOT NULL
      GROUP BY customer_id
      ORDER BY total_spending DESC
      LIMIT ?
    ''', [limit]);
    return result;
  }

  /// Ringkasan Hutang ke Supplier
  Future<List<Map<String, dynamic>>> getSupplierDebtSummary() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT name, hutang, phone
      FROM suppliers
      WHERE hutang > 0
      ORDER BY hutang DESC
    ''');
    return List<Map<String, dynamic>>.from(rows);
  }

  /// Valuasi Stok per Kategori
  Future<List<Map<String, dynamic>>> getInventoryValuationByCategory() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT 
        COALESCE(c.name, 'Tanpa Kategori') as category_name,
        COUNT(p.id) as sku_count,
        SUM(p.stock) as total_qty,
        SUM(p.stock * p.buy_price) as total_valuation
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      GROUP BY p.category_id
      ORDER BY total_valuation DESC
    ''');
    return List<Map<String, dynamic>>.from(rows);
  }

  // ============== RESI PRINT LOGS ================
  Future<int> insertResiLog(
      {required String trackingNumber,
      required String courier,
      required String source}) async {
    final db = await database;
    return await db.insert('resi_print_logs', {
      'tracking_number': trackingNumber,
      'courier': courier,
      'source': source,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<List<Map<String, dynamic>>> getResiLogs({int limit = 50}) async {
    final db = await database;
    return await db.query('resi_print_logs',
        orderBy: 'created_at DESC', limit: limit);
  }

  Future<void> clearOldResiLogs(int days) async {
    final db = await database;
    final date =
        DateTime.now().subtract(Duration(days: days)).toIso8601String();
    await db
        .delete('resi_print_logs', where: 'created_at < ?', whereArgs: [date]);
  }

  Future<List<Map<String, dynamic>>> getMenuEngineeringData(
      {int days = 30}) async {
    final db = await database;
    final dateLimit =
        DateTime.now().subtract(Duration(days: days)).toIso8601String();

    // Query to get popularity (volume) and profitability per product
    // Note: profit per unit is (unit_price - buy_price)
    // We join with products table to get current buy_price
    final result = await db.rawQuery('''
      SELECT 
        ti.product_id, 
        ti.product_name,
        SUM(ti.qty) as total_qty,
        SUM(ti.qty * (ti.unit_price - p.buy_price)) as total_profit,
        p.image_path,
        c.name as category_name
      FROM transaction_items ti
      INNER JOIN transactions t ON ti.transaction_id = t.id
      INNER JOIN products p ON ti.product_id = p.id
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE t.is_deleted = 0 
        AND t.created_at >= ?
      GROUP BY ti.product_id
      ORDER BY total_qty DESC
    ''', [dateLimit]);

    return result;
  }

  Future<List<Map<String, dynamic>>> getCategoryPerformance(
      {int days = 30}) async {
    final db = await database;
    final dateLimit =
        DateTime.now().subtract(Duration(days: days)).toIso8601String();

    return await db.rawQuery('''
      SELECT 
        c.name as category_name,
        SUM(ti.qty) as total_qty,
        SUM(ti.qty * ti.unit_price) as total_sales,
        SUM(ti.qty * (ti.unit_price - p.buy_price)) as total_profit
      FROM transaction_items ti
      INNER JOIN transactions t ON ti.transaction_id = t.id
      INNER JOIN products p ON ti.product_id = p.id
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE t.is_deleted = 0 AND t.created_at >= ?
      GROUP BY c.id
      ORDER BY total_sales DESC
    ''', [dateLimit]);
  }

  Future<List<Map<String, dynamic>>> getPaymentMethodStats(
      {int days = 30}) async {
    final db = await database;
    final dateLimit =
        DateTime.now().subtract(Duration(days: days)).toIso8601String();

    return await db.rawQuery('''
      SELECT 
        payment_method,
        COUNT(id) as transaction_count,
        SUM(grand_total) as total_amount
      FROM transactions
      WHERE is_deleted = 0 AND created_at >= ?
      GROUP BY payment_method
      ORDER BY total_amount DESC
    ''', [dateLimit]);
  }

  Future<Map<String, dynamic>> getservisProfitSummary({int days = 30}) async {
    final db = await database;
    final dateLimit =
        DateTime.now().subtract(Duration(days: days)).toIso8601String();
    final res = await db.rawQuery('''
      SELECT 
        SUM(ti.subtotal) as total_revenue,
        SUM(ti.qty * p.buy_price) as total_cost,
        SUM(ti.subtotal - (ti.qty * p.buy_price)) as total_profit
      FROM transaction_items ti
      JOIN products p ON ti.product_id = p.id
      JOIN transactions t ON ti.transaction_id = t.id
      WHERE t.is_deleted = 0 AND t.created_at >= ?
    ''', [dateLimit]);
    if (res.isEmpty || res.first['total_revenue'] == null) {
      return {'total_revenue': 0, 'total_cost': 0, 'total_profit': 0};
    }
    return res.first;
  }

  Future<List<Map<String, dynamic>>> getservisDailySalesStats(
      {int days = 30}) async {
    final db = await database;
    final dateLimit =
        DateTime.now().subtract(Duration(days: days)).toIso8601String();
    return await db.rawQuery('''
      SELECT 
        strftime('%w', created_at) as day_of_week,
        COUNT(id) as transaction_count,
        SUM(grand_total) as total_sales
      FROM transactions
      WHERE is_deleted = 0 AND created_at >= ?
      GROUP BY day_of_week
      ORDER BY day_of_week ASC
    ''', [dateLimit]);
  }
}



