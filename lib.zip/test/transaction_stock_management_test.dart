import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/models/db_models.dart';
import 'package:juragan_servis/providers/providers.dart';

import 'test_helper.dart';

void main() {
  late Directory tempDir;

  setUp(() async {
    tempDir = await prepareTestDatabase();
  });

  tearDown(() async {
    await cleanupTestDatabase(tempDir);
  });

  test(
      'transaction does not deduct stock for products without inventory tracking',
      () async {
    final dbHelper = DBHelper.instance;
    final trackedProductId = await dbHelper.insertProduct(
      Product(
        name: 'Air Mineral',
        categoryId: 1,
        stock: 20,
        buyPrice: 2000,
        sellPrice: 5000,
        unit: 'botol',
        minStock: 1,
        createdAt: '2026-04-19T08:00:00.000Z',
        hasStockManagement: 1,
      ),
    );
    final untrackedProductId = await dbHelper.insertProduct(
      Product(
        name: 'Jasa Bungkus',
        categoryId: 1,
        stock: 0,
        buyPrice: 0,
        sellPrice: 3000,
        unit: 'layanan',
        minStock: 0,
        createdAt: '2026-04-19T08:01:00.000Z',
        hasStockManagement: 0,
      ),
    );

    await dbHelper.insertTransaction(
      Transaction(
        totalAmount: 13000,
        grandTotal: 13000,
        paymentMethod: 'cash',
        amountPaid: 13000,
        createdAt: '2026-04-19T08:05:00.000Z',
      ),
      [
        TransactionItem(
          transactionId: 0,
          productId: trackedProductId,
          productName: 'Air Mineral',
          qty: 2,
          unitPrice: 5000,
          subtotal: 10000,
        ),
        TransactionItem(
          transactionId: 0,
          productId: untrackedProductId,
          productName: 'Jasa Bungkus',
          qty: 1,
          unitPrice: 3000,
          subtotal: 3000,
        ),
      ],
    );

    expect((await dbHelper.getProductById(trackedProductId))!.stock, 18);
    expect((await dbHelper.getProductById(untrackedProductId))!.stock, 0);
  });

  test('servis recipe deducts and restores raw material stock snapshot',
      () async {
    final dbHelper = DBHelper.instance;
    final serviceId = await dbHelper.insertProduct(
      Product(
        name: 'Pengecekan Layanan',
        categoryId: 1,
        stock: 0,
        buyPrice: 0,
        sellPrice: 15000,
        unit: 'kg',
        minStock: 0,
        createdAt: '2026-04-19T08:00:00.000Z',
        hasStockManagement: 0,
      ),
    );
    final detergentId = await dbHelper.insertProduct(
      Product(
        name: 'Deterjen Cair',
        categoryId: 5,
        stock: 200,
        buyPrice: 50,
        sellPrice: 0,
        unit: 'ml',
        minStock: 50,
        createdAt: '2026-04-19T08:01:00.000Z',
        hasStockManagement: 1,
        isMaterial: 1,
      ),
    );

    await dbHelper.replaceProductRecipes(serviceId, [
      ProductRecipe(
        serviceProductId: serviceId,
        materialProductId: detergentId,
        qtyPerUnit: 25,
        createdAt: '2026-04-19T08:02:00.000Z',
      ),
    ]);

    final txId = await dbHelper.insertTransaction(
      Transaction(
        totalAmount: 45000,
        grandTotal: 45000,
        paymentMethod: 'cash',
        amountPaid: 45000,
        createdAt: '2026-04-19T08:05:00.000Z',
      ),
      [
        TransactionItem(
          transactionId: 0,
          productId: serviceId,
          productName: 'Pengecekan Layanan',
          qty: 3,
          unitPrice: 15000,
          subtotal: 45000,
        ),
      ],
    );

    expect((await dbHelper.getProductById(detergentId))!.stock, 125);

    await dbHelper.replaceProductRecipes(serviceId, [
      ProductRecipe(
        serviceProductId: serviceId,
        materialProductId: detergentId,
        qtyPerUnit: 99,
        createdAt: '2026-04-19T09:00:00.000Z',
      ),
    ]);

    await dbHelper.softDeleteTransaction(txId);
    expect((await dbHelper.getProductById(detergentId))!.stock, 200);

    await dbHelper.restoreTransaction(txId);
    expect((await dbHelper.getProductById(detergentId))!.stock, 125);
  });

  test('raw material cannot be sold as order item', () async {
    final dbHelper = DBHelper.instance;
    final materialId = await dbHelper.insertProduct(
      Product(
        name: 'Kelengkapan Servis',
        categoryId: 5,
        stock: 100,
        buyPrice: 100,
        sellPrice: 0,
        unit: 'ml',
        minStock: 10,
        createdAt: '2026-04-19T08:01:00.000Z',
        hasStockManagement: 1,
        isMaterial: 1,
      ),
    );

    expect(
      () => dbHelper.insertTransaction(
        Transaction(
          totalAmount: 0,
          grandTotal: 0,
          paymentMethod: 'cash',
          amountPaid: 0,
          createdAt: '2026-04-19T08:05:00.000Z',
        ),
        [
          TransactionItem(
            transactionId: 0,
            productId: materialId,
            productName: 'Kelengkapan Servis',
            qty: 1,
            unitPrice: 0,
            subtotal: 0,
          ),
        ],
      ),
      throwsA(isA<Exception>()),
    );
    expect((await dbHelper.getProductById(materialId))!.stock, 100);
  });

  test('tracked product opening stock is recorded in stock history', () async {
    final container = ProviderContainer();
    addTearDown(container.dispose);

    final productId =
        await container.read(productsProvider.notifier).addProduct(
              Product(
                name: 'Bed Cover Besar',
                categoryId: 1,
                stock: 500,
                buyPrice: 20000,
                sellPrice: 35000,
                unit: 'pcs',
                minStock: 5,
                createdAt: '2026-04-19T08:00:00.000Z',
                hasStockManagement: 1,
              ),
            );

    final product = await DBHelper.instance.getProductById(productId);
    final logs = await DBHelper.instance.getStockLogsForProduct(productId);

    expect(product!.stock, 500);
    expect(product.hasStockManagement, 1);
    expect(logs, hasLength(1));
    expect(logs.first.stockName, 'Stok Awal');
    expect(logs.first.type, 'in');
    expect(logs.first.qty, 500);
    expect(logs.first.oldQty, 0);
    expect(logs.first.newQty, 500);
  });

  test('untracked service is saved without inventory quantity', () async {
    final container = ProviderContainer();
    addTearDown(container.dispose);

    final productId =
        await container.read(productsProvider.notifier).addProduct(
              Product(
                name: 'Pengecekan Kering Lipat Reguler',
                categoryId: 1,
                stock: 99,
                buyPrice: 0,
                sellPrice: 6000,
                unit: 'kg',
                minStock: 5,
                createdAt: '2026-04-19T08:00:00.000Z',
                hasStockManagement: 0,
              ),
            );

    final product = await DBHelper.instance.getProductById(productId);
    final logs = await DBHelper.instance.getStockLogsForProduct(productId);

    expect(product!.stock, 0);
    expect(product.minStock, 0);
    expect(product.hasStockManagement, 0);
    expect(logs, isEmpty);
  });
}

