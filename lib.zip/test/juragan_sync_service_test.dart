import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/services/juragan_sync_service.dart';

void main() {
  test('JuraganSyncMerger remaps servis recipe and usage relations', () {
    final local = <String, dynamic>{
      'categories': [
        {'id': 1, 'name': 'Layanan', 'duration_hours': 24},
      ],
      'products': [
        {
          'id': 1,
          'name': 'Pengecekan Layanan',
          'category_id': 1,
          'unit': 'kg',
          'is_hardware': 1,
          'is_material': 0,
        },
        {
          'id': 2,
          'name': 'Detergen',
          'category_id': 1,
          'unit': 'ml',
          'is_hardware': 0,
          'is_material': 1,
        },
      ],
      'product_recipes': [
        {
          'id': 1,
          'service_product_id': 1,
          'material_product_id': 2,
          'qty_per_unit': 10,
          'created_at': '2026-01-01T00:00:00Z',
        },
      ],
      'customers': [
        {'id': 1, 'name': 'Ayu', 'phone': '0811', 'created_at': 'now'},
      ],
      'transactions': [
        {
          'id': 1,
          'transaction_code': 'JL-001',
          'created_at': '2026-01-01T01:00:00Z',
          'grand_total': 10000,
          'amount_paid': 10000,
          'payment_method': 'cash',
          'customer_id': 1,
          'customer_name': 'Ayu',
        },
      ],
      'transaction_items': [
        {
          'id': 1,
          'transaction_id': 1,
          'product_id': 1,
          'qty': 1.5,
          'unit_price': 7000,
          'subtotal': 10500,
        },
      ],
      'transaction_material_usages': [
        {
          'id': 1,
          'transaction_id': 1,
          'service_product_id': 1,
          'material_product_id': 2,
          'material_name': 'Detergen',
          'qty': 15,
          'created_at': '2026-01-01T01:00:00Z',
        },
      ],
    };

    final peer = <String, dynamic>{
      'categories': [
        {'id': 1, 'name': 'Layanan', 'duration_hours': 24},
      ],
      'products': [
        {
          'id': 1,
          'name': 'Pengecekan Layanan',
          'category_id': 1,
          'unit': 'kg',
          'is_hardware': 1,
          'is_material': 0,
        },
        {
          'id': 2,
          'name': 'Kelengkapan',
          'category_id': 1,
          'unit': 'ml',
          'is_hardware': 0,
          'is_material': 1,
        },
      ],
      'product_recipes': [
        {
          'id': 1,
          'service_product_id': 1,
          'material_product_id': 2,
          'qty_per_unit': 5,
          'created_at': '2026-01-02T00:00:00Z',
        },
      ],
      'customers': [
        {'id': 1, 'name': 'Budi', 'phone': '0822', 'created_at': 'now'},
      ],
      'transactions': [
        {
          'id': 1,
          'transaction_code': 'JL-002',
          'created_at': '2026-01-02T01:00:00Z',
          'grand_total': 12000,
          'amount_paid': 12000,
          'payment_method': 'cash',
          'customer_id': 1,
          'customer_name': 'Budi',
        },
      ],
      'transaction_material_usages': [
        {
          'id': 1,
          'transaction_id': 1,
          'service_product_id': 1,
          'material_product_id': 2,
          'material_name': 'Kelengkapan',
          'qty': 8,
          'created_at': '2026-01-02T01:00:00Z',
        },
      ],
      'fnb_tables': [
        {
          'id': 1,
          'name': 'Workshop A',
          'area': 'Workshop',
          'active_transaction_id': 1,
          'merged_to_table_id': null,
          'qr_slug': 'workshop-a',
          'updated_at': '2026-01-02T01:00:00Z',
        },
      ],
      'fnb_kitchen_tickets': [
        {
          'id': 1,
          'transaction_id': 1,
          'table_name': 'Workshop A',
          'status': 'queued',
          'station': 'Pengecekan',
          'created_at': '2026-01-02T01:00:00Z',
          'updated_at': '2026-01-02T01:00:00Z',
        },
      ],
    };

    final merged = JuraganSyncMerger.merge(local, peer);

    final products =
        List<Map<String, dynamic>>.from(merged['products'] as List);
    expect(products.map((row) => row['name']),
        containsAll(['Pengecekan Layanan', 'Detergen', 'Kelengkapan']));

    final recipes =
        List<Map<String, dynamic>>.from(merged['product_recipes'] as List);
    expect(recipes, hasLength(2));
    expect(recipes.last['service_product_id'], 1);
    expect(recipes.last['material_product_id'], 3);

    final usages = List<Map<String, dynamic>>.from(
      merged['transaction_material_usages'] as List,
    );
    expect(usages.last['transaction_id'], 2);
    expect(usages.last['service_product_id'], 1);
    expect(usages.last['material_product_id'], 3);

    final stations =
        List<Map<String, dynamic>>.from(merged['fnb_tables'] as List);
    expect(stations.single['active_transaction_id'], 2);

    final tickets =
        List<Map<String, dynamic>>.from(merged['fnb_kitchen_tickets'] as List);
    expect(tickets.single['transaction_id'], 2);
  });

  test('JuraganSyncMerger resolves deleted transaction conflicts safely', () {
    final local = <String, dynamic>{
      'categories': [
        {'id': 1, 'name': 'Layanan'},
      ],
      'products': [
        {
          'id': 1,
          'name': 'Pengecekan Layanan',
          'category_id': 1,
          'unit': 'kg',
          'stock': 8,
          'has_stock_management': 1,
          'barcode': 'LDR001',
          'is_hardware': 1,
          'is_material': 0,
        },
      ],
      'customers': [
        {'id': 1, 'name': 'Ayu', 'phone': '0811'},
      ],
      'transactions': [
        {
          'id': 1,
          'transaction_code': 'JL-DEL-001',
          'created_at': '2026-05-31T09:00:00.000',
          'grand_total': 20000,
          'amount_paid': 20000,
          'payment_method': 'cash',
          'customer_id': 1,
          'customer_name': 'Ayu',
          'is_deleted': 0,
        },
      ],
      'transaction_items': [
        {
          'id': 1,
          'transaction_id': 1,
          'product_id': 1,
          'qty': 2,
          'unit_price': 10000,
          'subtotal': 20000,
          'note': '',
        },
      ],
      'stock_logs': [
        {
          'id': 1,
          'product_id': 1,
          'type': 'out',
          'qty': 2,
          'date': '2026-05-31T09:00:00.000',
          'stock_name': 'Transaksi #1',
        },
      ],
      'wallet_transactions': [
        {
          'id': 1,
          'wallet_id': 1,
          'type': 'in',
          'nominal': 20000,
          'created_at': '2026-05-31T09:00:00.000',
          'keterangan': 'Penjualan #1',
        },
      ],
    };

    final peer = <String, dynamic>{
      'categories': [
        {'id': 1, 'name': 'Layanan'},
      ],
      'products': [
        {
          'id': 1,
          'name': 'Pengecekan Layanan',
          'category_id': 1,
          'unit': 'kg',
          'stock': 10,
          'has_stock_management': 1,
          'barcode': 'LDR001',
          'is_hardware': 1,
          'is_material': 0,
        },
      ],
      'customers': [
        {'id': 1, 'name': 'Ayu', 'phone': '0811'},
      ],
      'transactions': [
        {
          'id': 9,
          'transaction_code': 'JL-DEL-001',
          'created_at': '2026-05-31T09:00:00.000',
          'grand_total': 20000,
          'amount_paid': 20000,
          'payment_method': 'cash',
          'customer_id': 1,
          'customer_name': 'Ayu',
          'is_deleted': 1,
          'deleted_at': '2026-05-31T10:00:00.000',
        },
      ],
      'transaction_items': [
        {
          'id': 9,
          'transaction_id': 9,
          'product_id': 1,
          'qty': 2,
          'unit_price': 10000,
          'subtotal': 20000,
          'note': '',
        },
      ],
      'stock_logs': [
        {
          'id': 9,
          'product_id': 1,
          'type': 'in',
          'qty': 2,
          'date': '2026-05-31T10:00:00.000',
          'stock_name': 'Pembatalan Transaksi #9',
        },
        {
          'id': 10,
          'product_id': 1,
          'type': 'in',
          'qty': 1,
          'date': '2026-05-31T10:00:00.000',
          'stock_name': 'Pembatalan bahan baku transaksi #9',
        },
      ],
      'wallet_transactions': [
        {
          'id': 9,
          'wallet_id': 1,
          'type': 'out',
          'nominal': 20000,
          'created_at': '2026-05-31T10:00:00.000',
          'keterangan': 'Pembatalan Penjualan #9',
        },
      ],
    };

    final conflicts =
        JuraganSyncMerger.findTransactionDeleteConflicts(local, peer);
    expect(conflicts, hasLength(1));
    expect(conflicts.single.deletedOnPeer, isTrue);

    final keepDeleted = JuraganSyncMerger.merge(local, peer);
    final keptTransactions =
        List<Map<String, dynamic>>.from(keepDeleted['transactions'] as List);
    expect(keptTransactions.single['is_deleted'], 1);

    final restored = JuraganSyncMerger.merge(
      local,
      peer,
      transactionResolutions: {
        conflicts.single.key: JuraganSyncTransactionResolution.restoreActive,
      },
    );
    final restoredTransactions =
        List<Map<String, dynamic>>.from(restored['transactions'] as List);
    expect(restoredTransactions.single['is_deleted'], 0);

    final restoredStockLogs =
        List<Map<String, dynamic>>.from(restored['stock_logs'] as List);
    expect(
      restoredStockLogs.any((row) =>
          row['stock_name'].toString().toLowerCase().contains('pembatalan')),
      isFalse,
    );

    final restoredWallets = List<Map<String, dynamic>>.from(
        restored['wallet_transactions'] as List);
    expect(
      restoredWallets.any((row) =>
          row['keterangan'].toString().toLowerCase().contains('pembatalan')),
      isFalse,
    );
  });

  test('JuraganSyncMerger keeps deleted manual wallet rows after sync', () {
    final local = <String, dynamic>{
      'wallet_transactions': [
        {
          'id': 1,
          'wallet_id': 'tunai',
          'type': 'masuk',
          'nominal': 125000,
          'created_at': '2026-06-01T08:00:00.000',
          'updated_at': '2026-06-01T08:05:00.000',
          'source': 'manual',
          'is_deleted': 0,
          'keterangan': 'Setoran kas',
        },
      ],
    };
    final peer = <String, dynamic>{
      'wallet_transactions': [
        {
          'id': 9,
          'wallet_id': 'tunai',
          'type': 'masuk',
          'nominal': 125000,
          'created_at': '2026-06-01T08:00:00.000',
          'updated_at': '2026-06-01T08:10:00.000',
          'deleted_at': '2026-06-01T08:10:00.000',
          'source': 'manual',
          'is_deleted': 1,
          'keterangan': 'Setoran kas',
        },
      ],
    };

    final merged = JuraganSyncMerger.merge(local, peer);
    final wallets =
        List<Map<String, dynamic>>.from(merged['wallet_transactions'] as List);

    expect(wallets, hasLength(1));
    expect(wallets.single['is_deleted'], 1);
    expect(wallets.single['deleted_at'], '2026-06-01T08:10:00.000');
  });

  test('JuraganSyncMerger keeps newest manual wallet edit after sync', () {
    final local = <String, dynamic>{
      'wallet_transactions': [
        {
          'id': 1,
          'wallet_id': 'tunai',
          'type': 'keluar',
          'nominal': 20000,
          'created_at': '2026-06-01T09:00:00.000',
          'updated_at': '2026-06-01T09:05:00.000',
          'source': 'manual',
          'is_deleted': 0,
          'kategori': 'Operasional',
          'keterangan': 'Biaya parkir',
        },
      ],
    };
    final peer = <String, dynamic>{
      'wallet_transactions': [
        {
          'id': 7,
          'wallet_id': 'tunai',
          'type': 'keluar',
          'nominal': 35000,
          'created_at': '2026-06-01T09:00:00.000',
          'updated_at': '2026-06-01T09:15:00.000',
          'source': 'manual',
          'is_deleted': 0,
          'kategori': 'Operasional',
          'keterangan': 'Biaya bensin',
        },
      ],
    };

    final merged = JuraganSyncMerger.merge(local, peer);
    final wallets =
        List<Map<String, dynamic>>.from(merged['wallet_transactions'] as List);

    expect(wallets, hasLength(1));
    expect(wallets.single['nominal'], 35000);
    expect(wallets.single['keterangan'], 'Biaya bensin');
  });

  test('JuraganSyncMerger preserves decimal stock after sync recalculation',
      () {
    final local = <String, dynamic>{
      'categories': [
        {'id': 1, 'name': 'Bahan'},
      ],
      'products': [
        {
          'id': 1,
          'name': 'Deterjen Cair',
          'category_id': 1,
          'unit': 'liter',
          'stock': 10.5,
          'has_stock_management': 1,
          'barcode': 'MAT001',
          'is_hardware': 0,
          'is_material': 1,
        },
      ],
      'stock_logs': [
        {
          'id': 1,
          'product_id': 1,
          'type': 'out',
          'qty': 0.55,
          'date': '2026-06-01T09:00:00.000',
          'stock_name': 'Pemakaian bahan',
        },
      ],
    };

    final merged = JuraganSyncMerger.merge(local, const <String, dynamic>{});
    final products =
        List<Map<String, dynamic>>.from(merged['products'] as List);

    expect(products.single['stock'], closeTo(10.5, 0.0001));
  });
}

