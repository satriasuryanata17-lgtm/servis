import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/services/cash_drawer_service.dart';

void main() {
  group('CashDrawerService.paymentMethodHasCash', () {
    test('mengenali pembayaran tunai lintas bahasa', () {
      expect(CashDrawerService.paymentMethodHasCash('cash'), isTrue);
      expect(CashDrawerService.paymentMethodHasCash('Tunai'), isTrue);
      expect(CashDrawerService.paymentMethodHasCash('Efectivo'), isTrue);
      expect(CashDrawerService.paymentMethodHasCash('Dinheiro'), isTrue);
    });

    test('mengenali pembayaran campuran lintas bahasa', () {
      expect(
        CashDrawerService.paymentMethodHasCash(
          'Campuran (Tunai: Rp10.000 & QRIS)',
        ),
        isTrue,
      );
      expect(
        CashDrawerService.paymentMethodHasCash(
          'Mixed (Cash: Rp10,000 & QRIS)',
        ),
        isTrue,
      );
      expect(
        CashDrawerService.paymentMethodHasCash(
          'Mixto (Efectivo: 10,00 EUR & QRIS)',
        ),
        isTrue,
      );
      expect(
        CashDrawerService.paymentMethodHasCash(
          'Misto (Dinheiro: R\$ 10,00 & QRIS)',
        ),
        isTrue,
      );
    });

    test('tidak membuka untuk pembayaran non-tunai', () {
      expect(CashDrawerService.paymentMethodHasCash('qris'), isFalse);
      expect(CashDrawerService.paymentMethodHasCash('bank'), isFalse);
      expect(CashDrawerService.paymentMethodHasCash('transfer'), isFalse);
      expect(CashDrawerService.paymentMethodHasCash('Non-Cash'), isFalse);
      expect(CashDrawerService.paymentMethodHasCash('Non Tunai'), isFalse);
      expect(CashDrawerService.paymentMethodHasCash('Cashless'), isFalse);
    });
  });
}

