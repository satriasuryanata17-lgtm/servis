import 'dart:io';
import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/models/db_models.dart';
import 'package:juragan_servis/providers/providers.dart';
import 'package:juragan_servis/utils/transaction_code_formatter.dart';
import 'package:sqflite/sqflite.dart' hide Transaction;

import 'test_helper.dart';

void main() {
  late Directory tempDir;

  setUp(() async {
    tempDir = await prepareTestDatabase();
  });

  tearDown(() async {
    await cleanupTestDatabase(tempDir);
  });

  test('insertTransaction menyimpan transaction_code dari nama toko', () async {
    final dbHelper = DBHelper.instance;

    await dbHelper.saveWarungProfile(
      nama: 'Toko Maju Jaya',
      alamat: 'Jl. Mawar',
      telepon: '08123456789',
      catatan: '',
      logoPath: '',
    );

    final productId = await dbHelper.insertProduct(
      Product(
        name: 'Kopi Susu',
        categoryId: 1,
        stock: 10,
        buyPrice: 7000,
        sellPrice: 12000,
        unit: 'gelas',
        minStock: 1,
        createdAt: '2026-04-22T09:00:00.000Z',
      ),
    );

    final transactionId = await dbHelper.insertTransaction(
      Transaction(
        totalAmount: 12000,
        grandTotal: 12000,
        paymentMethod: 'cash',
        amountPaid: 15000,
        changeAmount: 3000,
        createdAt: '2026-04-22T09:15:00.000Z',
      ),
      [
        TransactionItem(
          transactionId: 0,
          productId: productId,
          productName: 'Kopi Susu',
          qty: 1,
          unitPrice: 12000,
          subtotal: 12000,
        ),
      ],
    );

    final stored = await dbHelper.getTransactionById(transactionId);

    expect(stored, isNotNull);
    expect(
      stored!.transactionCode,
      TransactionCodeFormatter.format(
        id: transactionId,
        createdAt: stored.createdAt,
        storeName: 'Toko Maju Jaya',
      ),
    );
  });

  test('kasir session menyimpan petugas aktif', () async {
    final dbHelper = DBHelper.instance;

    final sessionId = await dbHelper.insertKasirSession(
      KasirSession(
        kasirName: 'Kasir Depan',
        openedAt: '2026-04-22T08:00:00.000Z',
        openingCash: 150000,
        staffId: 7,
        staffName: 'Rani',
        staffRole: 'Kasir',
      ),
    );

    final sessions = await dbHelper.getAllKasirSessions();
    final stored = sessions.firstWhere((session) => session.id == sessionId);

    expect(stored.staffId, 7);
    expect(stored.staffName, 'Rani');
    expect(stored.staffRole, 'Kasir');
  });

  test('hitung kas shift mencatat selisih ke audit tanpa menutup sesi',
      () async {
    final dbHelper = DBHelper.instance;
    final openedAt =
        DateTime.now().subtract(const Duration(minutes: 5)).toIso8601String();
    final sessionId = await dbHelper.insertKasirSession(
      KasirSession(
        kasirName: 'Kasir Depan',
        openedAt: openedAt,
        openingCash: 100000,
      ),
    );
    final container = ProviderContainer();
    addTearDown(container.dispose);

    await container.read(kasirSessionsProvider.notifier).recordCashCount(
          sessionId: sessionId,
          expectedCash: 150000,
          actualCash: 140000,
          notes: 'Uang kurang saat cek tengah shift',
        );

    final active = await dbHelper.getActiveKasirSession();
    final audits = await dbHelper.getAuditLogs(limit: 5);
    final log =
        audits.firstWhere((item) => item.action == 'shift_cash_counted');
    final meta = jsonDecode(log.metadataJson ?? '{}') as Map<String, dynamic>;

    expect(active?.id, sessionId);
    expect(log.amount, -10000);
    expect(log.note, 'Uang kurang saat cek tengah shift');
    expect(meta['expected_cash'], 150000);
    expect(meta['actual_cash'], 140000);
    expect(meta['difference'], -10000);
  });

  test('arus kas fisik tidak menghitung koreksi saldo dompet', () async {
    final dbHelper = DBHelper.instance;

    await dbHelper.insertWalletTransaction(WalletTransaction(
      walletId: 'tunai',
      nominal: 100000,
      type: 'masuk',
      tanggal: '2026-05-26',
      waktu: '08:00',
      keterangan: 'Pembayaran Servis',
      createdAt: '2026-05-26T08:00:00.000',
      kategori: 'Penjualan',
    ));
    await dbHelper.insertWalletTransaction(WalletTransaction(
      walletId: 'tunai',
      nominal: 25000,
      type: 'masuk',
      tanggal: '2026-05-26',
      waktu: '09:00',
      keterangan: 'Penyesuaian Saldo Admin',
      createdAt: '2026-05-26T09:00:00.000',
      kategori: 'Koreksi',
    ));

    expect(await dbHelper.getWalletBalance(walletId: 'tunai'), 125000);
    expect(await dbHelper.getPhysicalCashFlow(), 100000);
  });

  test('membuka database lama memperbaiki kolom baru walau versi sudah sama',
      () async {
    final dbPath = await DBHelper.instance.getDatabasePath();

    final legacyDb = await openDatabase(
      dbPath,
      version: DBHelper.schemaVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER,
            customer_name TEXT,
            total_amount INTEGER NOT NULL DEFAULT 0,
            discount_amount INTEGER NOT NULL DEFAULT 0,
            additional_charges INTEGER NOT NULL DEFAULT 0,
            additional_charges_json TEXT,
            grand_total INTEGER NOT NULL DEFAULT 0,
            payment_method TEXT NOT NULL DEFAULT 'cash',
            amount_paid INTEGER NOT NULL DEFAULT 0,
            change_amount INTEGER NOT NULL DEFAULT 0,
            note TEXT,
            created_at TEXT NOT NULL,
            is_deleted INTEGER NOT NULL DEFAULT 0,
            deleted_at TEXT,
            order_type TEXT,
            pickup_schedule TEXT,
            payment_status TEXT,
            queue_number INTEGER NOT NULL DEFAULT 0
          )
        ''');
        await db.execute('''
          CREATE TABLE kasir_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kasir_name TEXT NOT NULL DEFAULT '',
            opened_at TEXT NOT NULL,
            closed_at TEXT,
            opening_cash INTEGER NOT NULL DEFAULT 0,
            closing_cash INTEGER NOT NULL DEFAULT 0,
            total_transactions INTEGER NOT NULL DEFAULT 0,
            total_revenue INTEGER NOT NULL DEFAULT 0,
            total_cash INTEGER NOT NULL DEFAULT 0,
            total_non_cash INTEGER NOT NULL DEFAULT 0,
            notes TEXT,
            shift_name TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE warung_profile (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL DEFAULT '',
            alamat TEXT NOT NULL DEFAULT '',
            telepon TEXT NOT NULL DEFAULT '',
            catatan TEXT NOT NULL DEFAULT '',
            logo_path TEXT NOT NULL DEFAULT '',
            updated_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id INTEGER,
            staff_name TEXT NOT NULL DEFAULT 'Sistem',
            note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
          )
        ''');
      },
    );
    await legacyDb.close();

    await DBHelper.instance.close();
    final repairedDb = await DBHelper.instance.database;

    final txInfo = await repairedDb.rawQuery('PRAGMA table_info(transactions)');
    final sessionInfo = await repairedDb.rawQuery(
      'PRAGMA table_info(kasir_sessions)',
    );
    final auditInfo = await repairedDb.rawQuery(
      'PRAGMA table_info(audit_logs)',
    );

    expect(
      txInfo.any((column) => column['name'] == 'transaction_code'),
      isTrue,
    );
    expect(
      sessionInfo.any((column) => column['name'] == 'staff_id'),
      isTrue,
    );
    expect(
      sessionInfo.any((column) => column['name'] == 'staff_name'),
      isTrue,
    );
    expect(
      sessionInfo.any((column) => column['name'] == 'staff_role'),
      isTrue,
    );
    expect(
      auditInfo.any((column) => column['name'] == 'metadata_json'),
      isTrue,
    );
    expect(
      auditInfo.any((column) => column['name'] == 'amount'),
      isTrue,
    );
    expect(
      auditInfo.any((column) => column['name'] == 'staff_role'),
      isTrue,
    );

    await DBHelper.instance.insertAuditLog(AuditLog(
      action: 'shift_cash_counted',
      entityType: 'kasir_session',
      entityId: 1,
      amount: -10000,
      note: 'Selisih test',
      metadataJson: '{"difference":-10000}',
      createdAt: DateTime.now().toIso8601String(),
    ));

    final audits = await DBHelper.instance.getAuditLogs(
      action: 'shift_cash_counted',
      limit: 1,
    );
    expect(audits.single.amount, -10000);
    expect(
      jsonDecode(audits.single.metadataJson ?? '{}')['difference'],
      -10000,
    );
  });
}

