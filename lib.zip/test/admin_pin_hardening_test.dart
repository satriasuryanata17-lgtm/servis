import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/providers/providers.dart';

import 'test_helper.dart';

void main() {
  late Directory tempDir;

  setUp(() async {
    tempDir = await prepareTestDatabase();
  });

  tearDown(() async {
    await cleanupTestDatabase(tempDir);
  });

  test('blank profile rejects default admin pin until explicitly configured',
      () async {
    final container = ProviderContainer();
    addTearDown(container.dispose);

    final profilNotifier = container.read(profilProvider.notifier);
    await profilNotifier.loadProfil();

    expect(profilNotifier.hasConfiguredAdminPin, isFalse);
    expect(profilNotifier.verifyPin('123456'), isFalse);

    await profilNotifier.updateAdminPin('654321');

    expect(profilNotifier.hasConfiguredAdminPin, isTrue);
    expect(profilNotifier.verifyPin('654321'), isTrue);
    expect(profilNotifier.verifyPin('123456'), isFalse);
  });

  test('legacy default admin pin is migrated to unset and no longer accepted',
      () async {
    final db = await DBHelper.instance.database;
    await db.insert('profil', {
      'nama': 'Owner',
      'foto_path': '',
      'admin_pin': '123456',
      'admin_pin_hash': '',
    });

    final container = ProviderContainer();
    addTearDown(container.dispose);

    final profilNotifier = container.read(profilProvider.notifier);
    await profilNotifier.loadProfil();

    expect(profilNotifier.hasConfiguredAdminPin, isFalse);
    expect(profilNotifier.verifyPin('123456'), isFalse);

    final storedProfile = await DBHelper.instance.getProfil();
    expect(storedProfile['admin_pin'], isEmpty);
    expect(storedProfile['admin_pin_hash'], isEmpty);
  });
}

