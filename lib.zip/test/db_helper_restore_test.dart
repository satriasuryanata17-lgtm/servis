import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/models/db_models.dart';

import 'test_helper.dart';

void main() {
  late Directory tempDir;

  setUp(() async {
    tempDir = await prepareTestDatabase();
  });

  tearDown(() async {
    await cleanupTestDatabase(tempDir);
  });

  test('restoreAllData restores related tables without foreign key failures',
      () async {
    final dbHelper = DBHelper.instance;

    final productId = await dbHelper.insertProduct(
      Product(
        name: 'Es Teh',
        categoryId: 1,
        stock: 15,
        buyPrice: 3000,
        sellPrice: 5000,
        unit: 'gelas',
        minStock: 2,
        createdAt: '2026-04-08T10:00:00.000Z',
      ),
    );

    final transactionId = await dbHelper.insertTransaction(
      Transaction(
        totalAmount: 5000,
        grandTotal: 5000,
        paymentMethod: 'cash',
        amountPaid: 5000,
        createdAt: '2026-04-08T10:05:00.000Z',
      ),
      [
        TransactionItem(
          transactionId: 0,
          productId: productId,
          productName: 'Es Teh',
          qty: 1,
          unitPrice: 5000,
          subtotal: 5000,
        ),
      ],
    );

    final export = await dbHelper.exportAllData();

    await expectLater(dbHelper.restoreAllData(export), completes);

    final restoredProduct = await dbHelper.getProductById(productId);
    final restoredTransaction =
        await dbHelper.getTransactionById(transactionId);
    final restoredItems = await dbHelper.getTransactionItems(transactionId);

    expect(restoredProduct, isNotNull);
    expect(restoredTransaction, isNotNull);
    expect(restoredItems, hasLength(1));
    expect(restoredItems.first.productId, productId);
  });
}

