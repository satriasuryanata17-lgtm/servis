import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/models/db_models.dart';

import 'test_helper.dart';

void main() {
  late Directory tempDir;

  setUp(() async {
    tempDir = await prepareTestDatabase();
  });

  tearDown(() async {
    await cleanupTestDatabase(tempDir);
  });

  test('restoreAllData used by sync keeps local license intact', () async {
    final dbHelper = DBHelper.instance;
    await dbHelper.insertLicense(
      License(
        licenseId: 'lic-servis-1',
        serial: 'SERIAL-servis',
        serialHash: 'hash-servis',
        deviceId: 'device-servis',
        isActive: 1,
        expiredAt: '2030-01-01T00:00:00.000Z',
        signature: 'signature-servis',
      ),
    );

    final export = await dbHelper.exportAllData();
    expect(export.containsKey('license'), isFalse);

    await dbHelper.restoreAllData(export);

    final license = await dbHelper.getLicense();
    expect(license, isNotNull);
    expect(license!.licenseId, 'lic-servis-1');
    expect(license.serial, 'SERIAL-servis');
    expect(license.deviceId, 'device-servis');
  });
}

