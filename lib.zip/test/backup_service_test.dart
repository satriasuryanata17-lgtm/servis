import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/models/db_models.dart';
import 'package:juragan_servis/services/backup_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'test_helper.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory tempDir;

  setUp(() async {
    tempDir = await prepareTestDatabase();
  });

  tearDown(() async {
    await cleanupTestDatabase(tempDir);
  });

  test('validateBackup accepts generated backup and rejects tampered payload',
      () async {
    final dbHelper = DBHelper.instance;
    await dbHelper.insertProduct(
      Product(
        name: 'Kopi Susu',
        categoryId: 1,
        stock: 8,
        buyPrice: 8000,
        sellPrice: 15000,
        unit: 'cup',
        minStock: 1,
        createdAt: '2026-04-08T12:00:00.000Z',
      ),
    );

    final backupPath = await BackupService.createBackupFile();
    final backupData = jsonDecode(
      await File(backupPath).readAsString(),
    ) as Map<String, dynamic>;

    expect(BackupService.validateBackup(backupData), isNull);

    final unsigned = Map<String, dynamic>.from(backupData)
      ..remove('_checksum_sha256');
    expect(
      BackupService.validateBackup(unsigned),
      contains('tidak memiliki checksum integritas'),
    );

    final tampered = Map<String, dynamic>.from(backupData)
      ..['products'] = <Map<String, dynamic>>[];
    expect(
      BackupService.validateBackup(tampered),
      contains('Integritas file backup gagal diverifikasi'),
    );

    final futureVersion = Map<String, dynamic>.from(backupData)
      ..['version'] = DBHelper.schemaVersion + 1;
    expect(
      BackupService.validateBackup(futureVersion),
      contains('versi aplikasi yang lebih baru'),
    );
  });

  test(
      'validateNativeBackupFile accepts legacy native backup without signature',
      () async {
    final dbHelper = DBHelper.instance;
    await dbHelper.insertProduct(
      Product(
        name: 'Air Mineral',
        categoryId: 1,
        stock: 10,
        buyPrice: 3000,
        sellPrice: 5000,
        unit: 'botol',
        minStock: 1,
        createdAt: '2026-04-20T08:00:00.000Z',
      ),
    );

    final backupPath = await BackupService.runNativeBackup();
    expect(backupPath, isNotNull);

    final backupFile = File(backupPath!);
    final signatureFile = File('$backupPath.sig');
    expect(await signatureFile.exists(), isTrue);

    await signatureFile.delete();

    expect(await BackupService.validateNativeBackupFile(backupFile), isNull);
  });

  test(
      'validateNativeBackupFile rejects tampered sidecar signature when present',
      () async {
    final dbHelper = DBHelper.instance;
    await dbHelper.insertProduct(
      Product(
        name: 'Teh Botol',
        categoryId: 1,
        stock: 12,
        buyPrice: 5000,
        sellPrice: 8000,
        unit: 'botol',
        minStock: 1,
        createdAt: '2026-04-08T13:00:00.000Z',
      ),
    );

    final backupPath = await BackupService.runNativeBackup();
    expect(backupPath, isNotNull);

    final backupFile = File(backupPath!);
    final signatureFile = File('$backupPath.sig');
    expect(await signatureFile.exists(), isTrue);
    expect(await BackupService.validateNativeBackupFile(backupFile), isNull);

    final signature = jsonDecode(
      await signatureFile.readAsString(),
    ) as Map<String, dynamic>;
    signature['_checksum_sha256'] = 'invalid-signature';
    await signatureFile.writeAsString(jsonEncode(signature));

    expect(
      await BackupService.validateNativeBackupFile(backupFile),
      contains('Integritas backup native gagal diverifikasi'),
    );
  });

  test('encrypted portable backup hides plaintext and decrypts with passphrase',
      () async {
    final dbHelper = DBHelper.instance;
    await dbHelper.insertProduct(
      Product(
        name: 'Keripik Balado',
        categoryId: 1,
        stock: 5,
        buyPrice: 7000,
        sellPrice: 12000,
        unit: 'pcs',
        minStock: 1,
        createdAt: '2026-04-19T09:00:00.000Z',
      ),
    );

    final backupPath = await BackupService.createEncryptedPortableBackupFile(
      passphrase: 'BackupAman123',
    );
    final backupFile = File(backupPath);
    final rawContent = await backupFile.readAsString();

    expect(backupPath.endsWith('.jkb'), isTrue);
    expect(rawContent.contains('Keripik Balado'), isFalse);

    final summary = await BackupService.getBackupFileSummary(
      backupFile,
      passphrase: 'BackupAman123',
    );
    expect(summary['type'], 'JSON Portable (Terenkripsi)');
    expect(summary['products'], 1);

    final payload = await BackupService.readBackupPayloadFromFile(
      backupFile,
      passphrase: 'BackupAman123',
    );
    expect(BackupService.validateBackup(payload), isNull);
    expect(
      (payload['products'] as List).length,
      1,
    );

    expect(
      () => BackupService.readBackupPayloadFromFile(
        backupFile,
        passphrase: 'salah-total',
      ),
      throwsFormatException,
    );
  });

  test('encrypted portable restore restores product photos and remaps paths',
      () async {
    final imageFile = File('${tempDir.path}/layanan-perbaikan.jpg');
    final imageBytes = List<int>.generate(64, (i) => i);
    await imageFile.writeAsBytes(imageBytes);

    final dbHelper = DBHelper.instance;
    await dbHelper.insertProduct(
      Product(
        name: 'Perbaikan Premium',
        categoryId: 1,
        stock: 0,
        buyPrice: 0,
        sellPrice: 12000,
        unit: 'kg',
        minStock: 0,
        createdAt: '2026-05-25T08:00:00.000Z',
        imagePath: imageFile.path,
        isHardware: 1,
      ),
    );

    final backupPath = await BackupService.createEncryptedPortableBackupFile(
      passphrase: 'BackupAman123',
    );
    final backupFile = File(backupPath);
    final payload = await BackupService.readBackupPayloadFromFile(
      backupFile,
      passphrase: 'BackupAman123',
    );
    expect((payload['_media_files'] as List?)?.length, 1);

    await imageFile.delete();
    final db = await dbHelper.database;
    await db.delete('products');

    await BackupService.restoreEmbeddedMediaForTesting(payload);
    await dbHelper.restoreAllData(payload);

    final products = await db.query('products');
    expect(products, hasLength(1));
    final restoredPath = products.first['image_path'] as String?;
    expect(restoredPath, isNotNull);
    expect(restoredPath, isNot(imageFile.path));
    expect(await File(restoredPath!).exists(), isTrue);
    expect(await File(restoredPath).readAsBytes(), imageBytes);
  });

  test('performAutoBackup respects selected frequency', () async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('auto_backup_enabled', true);
    await prefs.setString(
      'last_auto_backup_date',
      DateTime.now().subtract(const Duration(days: 8)).toIso8601String(),
    );

    await BackupService.setAutoBackupFrequency(
      BackupService.autoFrequencyMonthly,
    );
    await BackupService.performAutoBackup();
    var files = await BackupService.getLocalBackupFiles();
    expect(files.where((f) => f.path.endsWith('.db')), isEmpty);

    await BackupService.setAutoBackupFrequency(
      BackupService.autoFrequencyWeekly,
    );
    await BackupService.performAutoBackup();
    files = await BackupService.getLocalBackupFiles();
    expect(files.where((f) => f.path.endsWith('.db')).length, 1);
  });
}

