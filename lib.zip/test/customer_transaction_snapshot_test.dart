import 'dart:convert';
import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/models/db_models.dart';
import 'package:juragan_servis/providers/providers.dart';

import 'test_helper.dart';

void main() {
  late Directory tempDir;

  setUp(() async {
    tempDir = await prepareTestDatabase();
  });

  tearDown(() async {
    await cleanupTestDatabase(tempDir);
  });

  test('ubah nama pelanggan ikut memperbarui snapshot transaksi lama',
      () async {
    final dbHelper = DBHelper.instance;
    final customerId = await dbHelper.insertCustomer(
      Customer(
        name: 'Ayu Lama',
        phone: '0811111111',
        createdAt: '2026-06-01T08:00:00.000',
      ),
    );

    final linkedTxId = await dbHelper.insertTransaction(
      Transaction(
        customerId: customerId,
        customerName: 'Ayu Lama',
        totalAmount: 15000,
        grandTotal: 15000,
        paymentMethod: 'tunai',
        amountPaid: 15000,
        createdAt: '2026-06-01T08:10:00.000',
        servisStatus: 'Proses',
      ),
      [],
    );
    final manualTxId = await dbHelper.insertTransaction(
      Transaction(
        customerName: 'Pelanggan Ketik Manual',
        totalAmount: 12000,
        grandTotal: 12000,
        paymentMethod: 'tunai',
        amountPaid: 12000,
        createdAt: '2026-06-01T08:20:00.000',
      ),
      [],
    );

    await dbHelper.updateCustomer(
      Customer(
        id: customerId,
        name: 'Ayu Baru',
        phone: '0811111111',
        createdAt: '2026-06-01T08:00:00.000',
      ),
    );

    final linked = await dbHelper.getTransactionById(linkedTxId);
    final manual = await dbHelper.getTransactionById(manualTxId);

    expect(linked?.customerName, 'Ayu Baru');
    expect(linked?.servisStatus, 'Proses');
    expect(manual?.customerName, 'Pelanggan Ketik Manual');
    expect(manual?.customerId, isNull);
  });

  test('database dibuka ulang memperbaiki snapshot nama pelanggan yang lama',
      () async {
    final dbHelper = DBHelper.instance;
    final customerId = await dbHelper.insertCustomer(
      Customer(
        name: 'Budi Lama',
        phone: '0822222222',
        createdAt: '2026-06-01T09:00:00.000',
      ),
    );
    final txId = await dbHelper.insertTransaction(
      Transaction(
        customerId: customerId,
        customerName: 'Budi Lama',
        totalAmount: 20000,
        grandTotal: 20000,
        paymentMethod: 'tunai',
        amountPaid: 20000,
        createdAt: '2026-06-01T09:10:00.000',
      ),
      [],
    );

    final db = await dbHelper.database;
    await db.update(
      'customers',
      {'name': 'Budi Baru'},
      where: 'id = ?',
      whereArgs: [customerId],
    );
    await dbHelper.close();

    final synced = await dbHelper.getTransactionById(txId);

    expect(synced?.customerName, 'Budi Baru');
  });

  test('hapus pelanggan wajib pin, tercatat audit, dan transaksi tetap ada',
      () async {
    final dbHelper = DBHelper.instance;
    final customerId = await dbHelper.insertCustomer(
      Customer(
        name: 'Satria',
        phone: '0833333333',
        createdAt: '2026-06-01T10:00:00.000',
      ),
    );
    final txId = await dbHelper.insertTransaction(
      Transaction(
        customerId: customerId,
        customerName: 'Satria',
        totalAmount: 45000,
        grandTotal: 45000,
        paymentMethod: 'tunai',
        amountPaid: 45000,
        createdAt: '2026-06-01T10:10:00.000',
        servisStatus: 'Selesai',
      ),
      [],
    );
    final container = ProviderContainer();
    addTearDown(container.dispose);
    container.read(activeStaffProvider);
    await Future<void>.delayed(Duration.zero);

    await expectLater(
      container.read(customersProvider.notifier).deleteCustomer(customerId),
      throwsA(isA<StateError>()),
    );
    expect(await dbHelper.getCustomerById(customerId), isNotNull);
    expect((await dbHelper.getTransactionById(txId))?.customerId, customerId);

    await container.read(activeStaffProvider.notifier).set(
          Employee(
            id: 7,
            name: 'Kasir Depan',
            role: 'Kasir',
            createdAt: '2026-06-01T07:00:00.000',
          ),
        );
    await container
        .read(customersProvider.notifier)
        .deleteCustomer(customerId, pinVerified: true);

    final deletedCustomer = await dbHelper.getCustomerById(customerId);
    final preservedTx = await dbHelper.getTransactionById(txId);
    final audits = await dbHelper.getAuditLogs(action: 'customer_deleted');
    final audit = audits.single;
    final metadata =
        jsonDecode(audit.metadataJson ?? '{}') as Map<String, dynamic>;

    expect(deletedCustomer, isNull);
    expect(preservedTx, isNotNull);
    expect(preservedTx?.customerId, isNull);
    expect(preservedTx?.customerName, 'Satria');
    expect(preservedTx?.servisStatus, 'Selesai');
    expect(audit.staffName, 'Kasir Depan');
    expect(audit.staffRole, 'Kasir');
    expect(audit.note, contains('1 transaksi lama tetap tersimpan'));
    expect(metadata['customer_id'], customerId);
    expect(metadata['customer_name'], 'Satria');
    expect(metadata['customer_phone'], '0833333333');
    expect(metadata['transaction_count'], 1);
    expect(metadata['authorized_by'], 'admin_pin');
  });
}

