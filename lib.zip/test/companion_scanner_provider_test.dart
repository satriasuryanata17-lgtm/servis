import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:juragan_servis/providers/companion_scanner_provider.dart';
import 'package:juragan_servis/services/scanner_server_service.dart';

class _FakeScannerServerService extends ScannerServerService {
  _FakeScannerServerService();

  final bool startSucceeds = true;
  final String? localIp = '192.168.1.20';
  final int portValue = 8080;
  int startCalls = 0;
  int stopCalls = 0;
  bool _running = false;

  @override
  bool get isRunning => _running;

  @override
  int get port => _running ? portValue : 0;

  @override
  Future<String?> getLocalIp() async => localIp;

  @override
  Future<bool> startServer({required String authToken}) async {
    startCalls++;
    _running = startSucceeds;
    return startSucceeds;
  }

  @override
  void stopServer() {
    stopCalls++;
    _running = false;
  }
}

Future<void> _pumpAsync() async {
  await Future<void>.delayed(const Duration(milliseconds: 1));
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('host scanner tidak auto start saat setting dimatikan', () async {
    SharedPreferences.setMockInitialValues({
      'remote_scanner_host_auto_start': false,
    });

    final fakeService = _FakeScannerServerService();
    final container = ProviderContainer(
      overrides: [
        scannerServerServiceProvider.overrideWithValue(fakeService),
      ],
    );
    addTearDown(container.dispose);

    container.read(companionScannerStateProvider);
    await _pumpAsync();

    expect(
      container.read(companionScannerStateProvider).autoStartEnabled,
      isFalse,
    );

    await container
        .read(companionScannerStateProvider.notifier)
        .syncHostSession(shouldBeActive: true);
    await _pumpAsync();

    expect(fakeService.startCalls, 0);
    expect(container.read(companionScannerStateProvider).isRunning, isFalse);
  });

  test('mengaktifkan auto start saat sesi aktif langsung menyalakan host',
      () async {
    SharedPreferences.setMockInitialValues({
      'remote_scanner_host_auto_start': false,
    });

    final fakeService = _FakeScannerServerService();
    final container = ProviderContainer(
      overrides: [
        scannerServerServiceProvider.overrideWithValue(fakeService),
      ],
    );
    addTearDown(container.dispose);

    container.read(companionScannerStateProvider);
    await _pumpAsync();

    await container
        .read(companionScannerStateProvider.notifier)
        .syncHostSession(shouldBeActive: true);
    await container
        .read(companionScannerStateProvider.notifier)
        .setAutoStartEnabled(true);
    await _pumpAsync();

    final state = container.read(companionScannerStateProvider);
    expect(fakeService.startCalls, 1);
    expect(state.isRunning, isTrue);
    expect(state.ipAddress, '192.168.1.20');
    expect(state.port, 8080);
  });

  test('host scanner berhenti saat sesi desktop berakhir', () async {
    SharedPreferences.setMockInitialValues({
      'remote_scanner_host_auto_start': true,
    });

    final fakeService = _FakeScannerServerService();
    final container = ProviderContainer(
      overrides: [
        scannerServerServiceProvider.overrideWithValue(fakeService),
      ],
    );
    addTearDown(container.dispose);

    container.read(companionScannerStateProvider);
    await _pumpAsync();

    await container
        .read(companionScannerStateProvider.notifier)
        .syncHostSession(shouldBeActive: true);
    await _pumpAsync();
    expect(container.read(companionScannerStateProvider).isRunning, isTrue);

    await container
        .read(companionScannerStateProvider.notifier)
        .syncHostSession(shouldBeActive: false);
    await _pumpAsync();

    expect(fakeService.stopCalls, greaterThan(0));
    expect(container.read(companionScannerStateProvider).isRunning, isFalse);
  });
}

