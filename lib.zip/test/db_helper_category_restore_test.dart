import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/models/db_models.dart';

import 'test_helper.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory tempDir;

  setUp(() async {
    tempDir = await prepareTestDatabase();
  });

  tearDown(() async {
    await cleanupTestDatabase(tempDir);
  });

  Product productFixture({
    int? id,
    required String name,
    required int categoryId,
  }) {
    return Product(
      id: id,
      name: name,
      categoryId: categoryId,
      stock: 1,
      buyPrice: 5000,
      sellPrice: 10000,
      unit: 'pcs',
      minStock: 0,
      createdAt: '2026-05-26T08:00:00.000',
    );
  }

  test('new database creates one protected default category', () async {
    final categories = await DBHelper.instance.getCategories();

    expect(categories.length, 1);
    expect(categories.single.name, DBHelper.defaultCategoryName);
  });

  test('restore keeps backup category ids used by products', () async {
    await DBHelper.instance.restoreAllData({
      'categories': [
        {'id': 8, 'name': 'Servis Sepatu Premium', 'duration_hours': 0},
      ],
      'products': [
        productFixture(id: 21, name: 'Deep Clean Sepatu', categoryId: 8)
            .toMap(),
      ],
    });

    final restored = await DBHelper.instance.getProductById(21);
    final categories = await DBHelper.instance.getCategories();

    expect(restored?.categoryId, 8);
    expect(categories.any((c) => c.id == 8), isTrue);
    expect(
      categories.any((c) => DBHelper.isDefaultCategoryName(c.name)),
      isTrue,
    );
  });

  test('restore moves products with missing categories to default', () async {
    await DBHelper.instance.restoreAllData({
      'categories': <Map<String, dynamic>>[],
      'products': [
        productFixture(id: 31, name: 'Produk Backup Lama', categoryId: 99)
            .toMap(),
      ],
    });

    final defaultCategory = (await DBHelper.instance.getCategories()).single;
    final restored = await DBHelper.instance.getProductById(31);

    expect(restored?.categoryId, defaultCategory.id);
  });

  test('stale category id can resolve by category name', () async {
    final categoryId = await DBHelper.instance.insertCategory(
      'Karpet Besar',
      durationHours: 24,
    );

    final resolved = await DBHelper.instance.resolveProductCategoryId(
      categoryId: 999,
      categoryName: 'Karpet Besar',
    );

    expect(resolved, categoryId);
  });

  test('default category cannot be deleted and manual delete reassigns product',
      () async {
    final defaultCategory = (await DBHelper.instance.getCategories()).single;
    expect(
      () => DBHelper.instance.deleteCategory(defaultCategory.id!),
      throwsException,
    );

    final manualCategoryId =
        await DBHelper.instance.insertCategory('Servis Software');
    final productId = await DBHelper.instance.insertProduct(
      productFixture(name: 'Pengecekan Jas', categoryId: manualCategoryId),
    );

    await DBHelper.instance.deleteCategory(manualCategoryId);

    final restored = await DBHelper.instance.getProductById(productId);
    expect(restored?.categoryId, defaultCategory.id);
  });

  test('duplicate default categories from backup are merged', () async {
    await DBHelper.instance.restoreAllData({
      'categories': [
        {'id': 7, 'name': 'Semua', 'duration_hours': 0},
        {'id': 8, 'name': 'semua', 'duration_hours': 0},
      ],
      'products': [
        productFixture(id: 41, name: 'Produk Default Duplikat', categoryId: 8)
            .toMap(),
      ],
    });

    final categories = await DBHelper.instance.getCategories();
    final defaultCategories = categories
        .where((c) => DBHelper.isDefaultCategoryName(c.name))
        .toList();
    final restored = await DBHelper.instance.getProductById(41);

    expect(defaultCategories.length, 1);
    expect(restored?.categoryId, defaultCategories.single.id);
  });
}

