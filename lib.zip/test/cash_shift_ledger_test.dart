import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/models/db_models.dart';
import 'package:juragan_servis/providers/providers.dart';

import 'test_helper.dart';

void main() {
  late Directory tempDir;

  setUp(() async {
    tempDir = await prepareTestDatabase();
  });

  tearDown(() async {
    await cleanupTestDatabase(tempDir);
  });

  Future<int> addService({
    required String name,
    required int price,
  }) {
    return DBHelper.instance.insertProduct(
      Product(
        name: name,
        categoryId: 1,
        stock: 0,
        buyPrice: 0,
        sellPrice: price,
        unit: 'kg',
        minStock: 0,
        createdAt: '2026-06-06T07:00:00.000',
        hasStockManagement: 0,
      ),
    );
  }

  Future<int> addTransaction({
    required int productId,
    required int total,
    required String paymentMethod,
    required int amountPaid,
    int changeAmount = 0,
    String paymentStatus = 'Lunas',
    String createdAt = '2026-06-06T08:10:00.000',
  }) {
    return DBHelper.instance.insertTransaction(
      Transaction(
        totalAmount: total,
        grandTotal: total,
        paymentMethod: paymentMethod,
        amountPaid: amountPaid,
        changeAmount: changeAmount,
        paymentStatus: paymentStatus,
        createdAt: createdAt,
      ),
      [
        TransactionItem(
          transactionId: 0,
          productId: productId,
          productName: 'Pengecekan Layanan',
          qty: 1,
          unitPrice: total,
          subtotal: total,
        ),
      ],
    );
  }

  test('shift ledger memisahkan tunai, non-tunai, dan campuran', () async {
    final productId = await addService(name: 'Pengecekan Layanan', price: 100000);

    await addTransaction(
      productId: productId,
      total: 100000,
      paymentMethod: 'cash',
      amountPaid: 100000,
      createdAt: '2026-06-06T08:10:00.000',
    );
    await addTransaction(
      productId: productId,
      total: 50000,
      paymentMethod: 'qris',
      amountPaid: 50000,
      createdAt: '2026-06-06T08:20:00.000',
    );
    await addTransaction(
      productId: productId,
      total: 70000,
      paymentMethod: 'Campuran (Tunai: Rp20.000 & QRIS)',
      amountPaid: 70000,
      createdAt: '2026-06-06T08:30:00.000',
    );

    final summary = await DBHelper.instance.getTransactionSummaryBetween(
      '2026-06-06T08:00:00.000',
      '2026-06-06T12:00:00.000',
    );

    expect(summary['total_transactions'], 3);
    expect(summary['total_revenue'], 220000);
    expect(summary['total_cash'], 120000);
    expect(summary['total_non_cash'], 100000);
    expect(await DBHelper.instance.getPhysicalCashFlow(), 120000);
    expect(await DBHelper.instance.getNonCashFlow(), 100000);
    expect(await DBHelper.instance.getWalletBalance(), 220000);
    expect(await DBHelper.instance.getWalletBalance(walletId: 'tunai'), 120000);
    expect(
      await DBHelper.instance.getWalletBalance(walletId: 'non_tunai'),
      100000,
    );
  });

  test('pelunasan penuh dari status mencatat Buku Kas dan tidak dobel',
      () async {
    final productId = await addService(name: 'Pengecekan Layanan', price: 80000);
    final txId = await addTransaction(
      productId: productId,
      total: 80000,
      paymentMethod: 'buat_pesanan',
      amountPaid: 0,
      paymentStatus: 'Belum Lunas',
    );
    final container = ProviderContainer();
    addTearDown(container.dispose);

    await container.read(transactionsProvider.notifier).markAsPaidOnly(
          txId: txId,
          grandTotal: 80000,
          paymentMethod: 'tunai',
        );
    await container.read(transactionsProvider.notifier).markAsPaidOnly(
          txId: txId,
          grandTotal: 80000,
          paymentMethod: 'tunai',
        );

    final tx = await DBHelper.instance.getTransactionById(txId);
    final installments =
        await DBHelper.instance.getCicilansByTransactionId(txId);
    final summary = await DBHelper.instance.getTransactionSummaryBetween(
      '2000-01-01T00:00:00.000',
      '2100-01-01T00:00:00.000',
    );

    expect(tx?.amountPaid, 80000);
    expect(tx?.paymentStatus, 'Lunas');
    expect(tx?.paymentMethod, 'tunai');
    expect(installments, hasLength(1));
    expect(installments.single.nominal, 80000);
    expect(installments.single.metodePembayaran, 'tunai');
    expect(await DBHelper.instance.getWalletBalance(walletId: 'tunai'), 80000);
    expect(summary['total_revenue'], 80000);
    expect(summary['total_cash'], 80000);
    expect(summary['total_non_cash'], 0);
  });

  test('DP tunai dan pelunasan non-tunai tetap benar saat hapus dan restore',
      () async {
    final productId = await addService(name: 'Pengecekan Layanan', price: 100000);
    final txId = await addTransaction(
      productId: productId,
      total: 100000,
      paymentMethod: 'tunai',
      amountPaid: 30000,
      paymentStatus: 'Belum Lunas',
    );
    final container = ProviderContainer();
    addTearDown(container.dispose);

    await container.read(transactionsProvider.notifier).markAsPaidOnly(
          txId: txId,
          grandTotal: 100000,
          paymentMethod: 'qris',
        );

    expect(await DBHelper.instance.getWalletBalance(walletId: 'tunai'), 30000);
    expect(
      await DBHelper.instance.getWalletBalance(walletId: 'non_tunai'),
      70000,
    );
    expect((await DBHelper.instance.getTransactionById(txId))?.paymentMethod,
        'tunai');

    await DBHelper.instance.softDeleteTransaction(txId);
    expect(await DBHelper.instance.getWalletBalance(walletId: 'tunai'), 0);
    expect(await DBHelper.instance.getWalletBalance(walletId: 'non_tunai'), 0);

    await DBHelper.instance.restoreTransaction(txId);
    expect(await DBHelper.instance.getWalletBalance(walletId: 'tunai'), 30000);
    expect(
      await DBHelper.instance.getWalletBalance(walletId: 'non_tunai'),
      70000,
    );
  });

  test('rumus dashboard shift memakai kas laci fisik dan pendapatan shift',
      () async {
    final productId = await addService(name: 'Pengecekan Layanan', price: 60000);
    await DBHelper.instance.insertKasirSession(
      KasirSession(
        kasirName: 'Kasir Pagi',
        openedAt: '2026-06-06T08:00:00.000',
        openingCash: 50000,
      ),
    );
    await addTransaction(
      productId: productId,
      total: 60000,
      paymentMethod: 'tunai',
      amountPaid: 60000,
      createdAt: '2026-06-06T08:30:00.000',
    );
    await addTransaction(
      productId: productId,
      total: 40000,
      paymentMethod: 'transfer',
      amountPaid: 40000,
      createdAt: '2026-06-06T08:40:00.000',
    );
    final session = await DBHelper.instance.getActiveKasirSession();
    final cashFlow = await DBHelper.instance.getPhysicalCashFlow(
      since: session!.openedAt,
      until: '2026-06-06T09:00:00.000',
    );
    final summary = await DBHelper.instance.getTransactionSummaryBetween(
      session.openedAt,
      '2026-06-06T09:00:00.000',
    );

    expect(session.openingCash + cashFlow, 110000);
    expect(summary['total_transactions'], 2);
    expect(summary['total_revenue'], 100000);
    expect(summary['total_cash'], 60000);
    expect(summary['total_non_cash'], 40000);
  });
}

