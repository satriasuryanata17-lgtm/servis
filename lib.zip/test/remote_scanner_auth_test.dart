import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/services/remote_scanner_auth.dart';

void main() {
  test('remote scanner signed payload is deterministic for same input', () {
    final now = DateTime.utc(2026, 4, 19, 3, 0, 0);
    final signedA = RemoteScannerAuth.signPayload(
      secret: 'scanner-secret',
      method: 'POST',
      path: '/scan',
      payload: {
        'barcode': '8991002101234',
        'original': '8991002101234',
      },
      nowUtc: now,
      nonce: 'nonce-123',
    );
    final signedB = RemoteScannerAuth.signPayload(
      secret: 'scanner-secret',
      method: 'POST',
      path: '/scan',
      payload: {
        'original': '8991002101234',
        'barcode': '8991002101234',
      },
      nowUtc: now,
      nonce: 'nonce-123',
    );

    expect(signedA['auth'], signedB['auth']);
  });

  test('remote scanner timestamp freshness enforces short replay window', () {
    final now = DateTime.utc(2026, 4, 19, 3, 0, 45);
    final validTimestamp =
        now.subtract(const Duration(seconds: 30)).millisecondsSinceEpoch;
    final expiredTimestamp =
        now.subtract(const Duration(minutes: 2)).millisecondsSinceEpoch;

    expect(
      RemoteScannerAuth.isTimestampFresh(validTimestamp, nowUtc: now),
      isTrue,
    );
    expect(
      RemoteScannerAuth.isTimestampFresh(expiredTimestamp, nowUtc: now),
      isFalse,
    );
  });
}

