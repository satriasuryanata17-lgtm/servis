import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/models/db_models.dart';

import 'test_helper.dart';

void main() {
  late Directory tempDir;

  setUp(() async {
    tempDir = await prepareTestDatabase();
  });

  tearDown(() async {
    await cleanupTestDatabase(tempDir);
  });

  Future<int> walletEntryCount() async {
    final db = await DBHelper.instance.database;
    final rows =
        await db.rawQuery('SELECT COUNT(*) as count FROM wallet_transactions');
    return rows.first['count'] as int? ?? 0;
  }

  test('soft delete and restore transaction are idempotent', () async {
    final dbHelper = DBHelper.instance;
    final productId = await dbHelper.insertProduct(
      Product(
        name: 'Nasi Goreng',
        categoryId: 1,
        stock: 10,
        buyPrice: 10000,
        sellPrice: 15000,
        unit: 'porsi',
        minStock: 1,
        createdAt: '2026-04-08T09:00:00.000Z',
        hasStockManagement: 1,
      ),
    );

    final transactionId = await dbHelper.insertTransaction(
      Transaction(
        totalAmount: 30000,
        grandTotal: 30000,
        paymentMethod: 'cash',
        amountPaid: 30000,
        createdAt: '2026-04-08T09:05:00.000Z',
      ),
      [
        TransactionItem(
          transactionId: 0,
          productId: productId,
          productName: 'Nasi Goreng',
          qty: 2,
          unitPrice: 15000,
          subtotal: 30000,
        ),
      ],
    );

    expect((await dbHelper.getProductById(productId))!.stock, 8);
    expect(await walletEntryCount(), 1);

    await dbHelper.softDeleteTransaction(transactionId);
    expect((await dbHelper.getProductById(productId))!.stock, 10);
    expect(await walletEntryCount(), 2);

    await dbHelper.softDeleteTransaction(transactionId);
    expect((await dbHelper.getProductById(productId))!.stock, 10);
    expect(await walletEntryCount(), 2);

    await dbHelper.restoreTransaction(transactionId);
    expect((await dbHelper.getProductById(productId))!.stock, 8);
    expect(await walletEntryCount(), 3);

    await dbHelper.restoreTransaction(transactionId);
    expect((await dbHelper.getProductById(productId))!.stock, 8);
    expect(await walletEntryCount(), 3);
  });

  test('restoreTransaction rejects when stock is no longer sufficient',
      () async {
    final dbHelper = DBHelper.instance;
    final productId = await dbHelper.insertProduct(
      Product(
        name: 'Mie Ayam',
        categoryId: 1,
        stock: 5,
        buyPrice: 7000,
        sellPrice: 12000,
        unit: 'mangkok',
        minStock: 1,
        createdAt: '2026-04-08T11:00:00.000Z',
        hasStockManagement: 1,
      ),
    );

    final transactionId = await dbHelper.insertTransaction(
      Transaction(
        totalAmount: 24000,
        grandTotal: 24000,
        paymentMethod: 'cash',
        amountPaid: 24000,
        createdAt: '2026-04-08T11:15:00.000Z',
      ),
      [
        TransactionItem(
          transactionId: 0,
          productId: productId,
          productName: 'Mie Ayam',
          qty: 2,
          unitPrice: 12000,
          subtotal: 24000,
        ),
      ],
    );

    await dbHelper.softDeleteTransaction(transactionId);
    final db = await dbHelper.database;
    await db.update(
      'products',
      {'stock': 0},
      where: 'id = ?',
      whereArgs: [productId],
    );

    await expectLater(
      dbHelper.restoreTransaction(transactionId),
      throwsA(isA<Exception>()),
    );

    final transaction = await dbHelper.getTransactionById(transactionId);
    expect(transaction!.isDeleted, 1);
  });
}

