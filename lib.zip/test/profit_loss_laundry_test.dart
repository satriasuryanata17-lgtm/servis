import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/models/db_models.dart';

import 'test_helper.dart';

void main() {
  late Directory tempDir;

  setUp(() async {
    tempDir = await prepareTestDatabase();
  });

  tearDown(() async {
    await cleanupTestDatabase(tempDir);
  });

  test('laba rugi servis uses material HPP and excludes non-operational cash',
      () async {
    final dbHelper = DBHelper.instance;
    final serviceId = await dbHelper.insertProduct(
      Product(
        name: 'Pengecekan Layanan',
        categoryId: 1,
        stock: 0,
        buyPrice: 999,
        sellPrice: 15000,
        unit: 'kg',
        minStock: 0,
        createdAt: '2026-05-10T08:00:00.000',
        hasStockManagement: 0,
      ),
    );
    final expressId = await dbHelper.insertProduct(
      Product(
        name: 'Servis Express',
        categoryId: 1,
        stock: 0,
        buyPrice: 5000,
        sellPrice: 20000,
        unit: 'paket',
        minStock: 0,
        createdAt: '2026-05-10T08:05:00.000',
        hasStockManagement: 0,
      ),
    );
    final detergentId = await dbHelper.insertProduct(
      Product(
        name: 'Deterjen Cair',
        categoryId: 1,
        stock: 500,
        buyPrice: 50,
        sellPrice: 0,
        unit: 'ml',
        minStock: 50,
        createdAt: '2026-05-10T08:10:00.000',
        hasStockManagement: 1,
        isMaterial: 1,
      ),
    );

    await dbHelper.replaceProductRecipes(serviceId, [
      ProductRecipe(
        serviceProductId: serviceId,
        materialProductId: detergentId,
        qtyPerUnit: 25,
        createdAt: '2026-05-10T08:15:00.000',
      ),
    ]);

    final transactionId = await dbHelper.insertTransaction(
      Transaction(
        totalAmount: 65000,
        grandTotal: 65000,
        paymentMethod: 'cash',
        amountPaid: 65000,
        createdAt: '2026-05-10T09:00:00.000',
      ),
      [
        TransactionItem(
          transactionId: 0,
          productId: serviceId,
          productName: 'Pengecekan Layanan',
          qty: 3,
          unitPrice: 15000,
          subtotal: 45000,
        ),
        TransactionItem(
          transactionId: 0,
          productId: expressId,
          productName: 'Servis Express',
          qty: 1,
          unitPrice: 20000,
          subtotal: 20000,
        ),
      ],
    );

    await dbHelper.insertWalletTransaction(
      WalletTransaction(
        walletId: 'tunai',
        nominal: 10000,
        type: 'keluar',
        tanggal: '2026-05-10',
        waktu: '10:00',
        keterangan: 'Gaji harian',
        createdAt: '2026-05-10T10:00:00.000',
        kategori: 'Gaji',
      ),
    );
    await dbHelper.insertWalletTransaction(
      WalletTransaction(
        walletId: 'tunai',
        nominal: 100000,
        type: 'keluar',
        tanggal: '2026-05-10',
        waktu: '10:30',
        keterangan: 'Pembelian stok deterjen',
        createdAt: '2026-05-10T10:30:00.000',
        kategori: 'Pembelian Stok',
      ),
    );
    await dbHelper.insertWalletTransaction(
      WalletTransaction(
        walletId: 'tunai',
        nominal: 5000,
        type: 'keluar',
        tanggal: '2026-05-10',
        waktu: '11:00',
        keterangan: 'Koreksi saldo',
        createdAt: '2026-05-10T11:00:00.000',
        kategori: 'Koreksi',
      ),
    );

    await dbHelper.insertReturn(
      ReturnTransaction(
        transactionId: transactionId,
        customerName: 'Pelanggan',
        reason: 'lainnya',
        refundMethod: 'tunai',
        totalRefund: 15000,
        createdAt: '2026-05-10T12:00:00.000',
      ),
      [
        ReturnItem(
          returnId: 0,
          productId: serviceId,
          productName: 'Pengecekan Layanan',
          qty: 1,
          unitPrice: 15000,
          subtotal: 15000,
        ),
      ],
    );

    final start = DateTime(2026, 5, 1);
    final end = DateTime(2026, 6, 1);
    final summary = await dbHelper.getLabaRugiRange(start, end);

    expect(summary['omzet_kotor'], 65000);
    expect(summary['retur_penjualan'], 15000);
    expect(summary['omzet'], 50000);
    expect(summary['hpp_kotor'], 8750);
    expect(summary['hpp'], 8750);
    expect(summary['laba_kotor'], 41250);
    expect(summary['pengeluaran'], 10000);
    expect(summary['laba_bersih'], 31250);
    expect(summary['pembelian_stok'], 100000);

    final allExpenses = await dbHelper.getExpensesByCategoryRange(start, end);
    expect(allExpenses['Gaji'], 10000);
    expect(allExpenses['Pembelian Stok'], 100000);
    expect(allExpenses['Koreksi'], 5000);

    final operationalExpenses =
        await dbHelper.getOperationalExpensesByCategoryRange(start, end);
    expect(operationalExpenses, {'Gaji': 10000});

    final margins = await dbHelper.getMarginPerProduk(start, end);
    final pengecekan =
        margins.firstWhere((row) => row['product_name'] == 'Pengecekan Layanan');
    expect((pengecekan['total_qty'] as num).toInt(), 2);
    expect((pengecekan['total_omzet'] as num).toInt(), 30000);
    expect((pengecekan['total_hpp'] as num).toInt(), 3750);
    expect((pengecekan['laba_kotor'] as num).toInt(), 26250);

    final monthly = await dbHelper.getOmzetVsHppBulanan(2026);
    expect(monthly[4]['omzet'], 50000);
    expect(monthly[4]['hpp'], 8750);
    expect(monthly[4]['pengeluaran'], 10000);
    expect(monthly[4]['laba_bersih'], 31250);
  });
}

