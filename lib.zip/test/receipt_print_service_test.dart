import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:juragan_servis/services/receipt_print_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late Directory tempDir;

  setUp(() async {
    tempDir = await Directory.systemTemp.createTemp(
      'juragankasir_receipt_test_',
    );
  });

  tearDown(() async {
    if (await tempDir.exists()) {
      await tempDir.delete(recursive: true);
    }
  });

  test('logo samping mencetak header raster gabungan sesuai template',
      () async {
    final logoPath = await _createLogoFile(
      tempDir,
      width: 240,
      height: 360,
    );
    final document = _buildDocument(
      logoPosition: 'left',
      itemCount: 3,
    );

    final bytes = await ReceiptPrintService.buildEscPosBytes(
      document: document,
      logoPath: logoPath,
    );

    expect(bytes, isNotEmpty);
    expect(_countRasterCommands(bytes), greaterThan(0));
    expect(
      _containsSequence(bytes, document.namaWarung.toUpperCase().codeUnits),
      isFalse,
    );
    expect(_containsSequence(bytes, document.alamat.codeUnits), isTrue);
  });

  test('struk panjang dengan logo tetap memuat footer sampai akhir', () async {
    final logoPath = await _createLogoFile(
      tempDir,
      width: 260,
      height: 520,
    );
    const footer = 'Terima kasih telah berbelanja di toko kami';
    final document = _buildDocument(
      logoPosition: 'top',
      itemCount: 60,
      footer: footer,
    );

    final bytes = await ReceiptPrintService.buildEscPosBytes(
      document: document,
      logoPath: logoPath,
    );

    final footerIndex = _indexOfSequence(bytes, footer.codeUnits);
    final lastItemIndex = _indexOfSequence(bytes, 'Produk Ke-60'.codeUnits);

    expect(bytes, isNotEmpty);
    expect(footerIndex, greaterThan(lastItemIndex));
    expect(
      bytes.sublist(bytes.length - 3),
      orderedEquals(<int>[0x1B, 0x64, 0x08]),
    );
  });

  test('detail promo item tampil dan antrian tidak dicetak', () async {
    final logoPath = await _createLogoFile(
      tempDir,
      width: 180,
      height: 180,
    );
    final document = _buildDocument(
      logoPosition: 'top',
      itemCount: 3,
    );

    final bytes = await ReceiptPrintService.buildEscPosBytes(
      document: document,
      logoPath: logoPath,
    );

    expect(_containsSequence(bytes, 'Produk Ke-1'.codeUnits), isTrue);
    expect(_containsSequence(bytes, 'Rp2.500'.codeUnits), isTrue);
    expect(_containsSequence(bytes, 'ANTRIAN'.codeUnits), isFalse);
  });

  test('harga nego tidak menambahkan label yang membuat baris harga terpotong',
      () async {
    final document = _buildDocument(
      logoPosition: 'top',
      itemCount: 1,
      negotiatedItem: true,
    );

    final bytes = await ReceiptPrintService.buildEscPosBytes(
      document: document,
      logoPath: '',
    );

    expect(_containsSequence(bytes, '(nego)'.codeUnits), isFalse);
    expect(_containsSequence(bytes, 'Harga awal Rp5.000'.codeUnits), isTrue);
  });

  test('command buka laci memakai ESC/POS drawer kick', () {
    expect(
      ReceiptPrintService.cashDrawerKickBytes(),
      orderedEquals(<int>[0x1B, 0x70, 0x00, 0x3C, 0x78]),
    );
    expect(
      ReceiptPrintService.cashDrawerKickBytes(pin: 1, onTimeMs: 50),
      orderedEquals(<int>[0x1B, 0x70, 0x01, 0x19, 0x78]),
    );
  });
}

ReceiptPrintDocument _buildDocument({
  required String logoPosition,
  required int itemCount,
  String footer = 'Terima kasih telah berbelanja!',
  bool negotiatedItem = false,
}) {
  final items = List<ReceiptPrintItem>.generate(
    itemCount,
    (index) {
      final qty = ((index % 3) + 1).toDouble();
      final unitPrice = 2500 + (index * 100);
      return ReceiptPrintItem(
        name: 'Produk Ke-${index + 1}',
        qty: qty,
        unitPrice: unitPrice,
        originalUnitPrice: index == 0 ? 5000 : unitPrice,
        subtotal: (qty * unitPrice).round(),
        note: index.isEven ? 'Catatan item ${index + 1}' : '',
        appliedDiscountName: index == 0 ? 'Promo Spesial' : '',
        appliedDiscountIsPercentage: index == 0 ? 1 : 0,
        appliedDiscountValue: index == 0 ? 50 : 0,
        originalSubtotal: negotiatedItem && index == 0 ? 5000 : 0,
        priceOverrideAmount: negotiatedItem && index == 0 ? 2500 : 0,
        isPriceOverride: negotiatedItem && index == 0,
      );
    },
  );

  final subtotal = items.fold<int>(0, (sum, item) => sum + item.subtotal);

  return ReceiptPrintService.buildDocument(
    ukuranKertas: '58mm',
    namaWarung: 'Toko Bunga Indah',
    alamat: 'Jl. Mawar No. 10, Bojonggede, Bogor',
    telepon: '0895370347091',
    footer: footer,
    instagram: 'bungaindah',
    facebook: 'bungaindah',
    tiktok: 'bungaindah',
    logoPosition: logoPosition,
    logoWidth: 60,
    showAlamat: true,
    showTelepon: true,
    showTotalPesanan: true,
    noTransaksi: 'TRX20042026001403',
    tanggal: '20-04-2026 00:14',
    kasirName: 'Demo Kasir',
    paymentMethod: 'Tunai',
    items: items,
    subtotal: subtotal,
    discountAmount: 500,
    charges: const [
      ReceiptPrintCharge(label: 'Pajak', value: 1000),
      ReceiptPrintCharge(label: 'Biaya Lain', value: 2000),
    ],
    additionalCharges: 0,
    grandTotal: subtotal + 2500,
    amountPaid: subtotal + 10000,
    changeAmount: 7500,
    queueNumber: 7,
  );
}

Future<String> _createLogoFile(
  Directory tempDir, {
  required int width,
  required int height,
}) async {
  final image = img.Image(width: width, height: height);
  img.fill(image, color: img.ColorRgb8(255, 255, 255));

  img.fillRect(
    image,
    x1: width ~/ 8,
    y1: height ~/ 8,
    x2: width - (width ~/ 8),
    y2: height - (height ~/ 8),
    color: img.ColorRgb8(0, 0, 0),
  );
  img.fillRect(
    image,
    x1: width ~/ 3,
    y1: height ~/ 3,
    x2: width - (width ~/ 3),
    y2: height - (height ~/ 3),
    color: img.ColorRgb8(255, 255, 255),
  );

  final file = File('${tempDir.path}${Platform.pathSeparator}logo.png');
  await file.writeAsBytes(img.encodePng(image));
  return file.path;
}

bool _containsSequence(List<int> source, List<int> pattern) {
  return _indexOfSequence(source, pattern) >= 0;
}

int _indexOfSequence(List<int> source, List<int> pattern) {
  if (pattern.isEmpty || pattern.length > source.length) return -1;

  for (int i = 0; i <= source.length - pattern.length; i++) {
    bool match = true;
    for (int j = 0; j < pattern.length; j++) {
      if (source[i + j] != pattern[j]) {
        match = false;
        break;
      }
    }
    if (match) return i;
  }

  return -1;
}

int _countRasterCommands(List<int> bytes) {
  int count = 0;
  for (int i = 0; i <= bytes.length - 3; i++) {
    if (bytes[i] == 0x1D && bytes[i + 1] == 0x76 && bytes[i + 2] == 0x30) {
      count++;
    }
  }
  return count;
}

