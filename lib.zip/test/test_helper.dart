import 'dart:io';

import 'package:juragan_servis/database/db_helper.dart';
import 'package:juragan_servis/services/backup_service.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

Future<Directory> prepareTestDatabase() async {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  final tempDir = await Directory.systemTemp.createTemp('juragankasir_test_');
  SharedPreferences.setMockInitialValues(<String, Object>{});
  DBHelper.overrideDatabasePathForTesting(
    p.join(tempDir.path, 'juragankasir_test.db'),
  );
  BackupService.overrideDocumentsDirectoryForTesting(tempDir.path);
  await DBHelper.instance.close();
  return tempDir;
}

Future<void> cleanupTestDatabase(Directory tempDir) async {
  await DBHelper.instance.close();
  DBHelper.overrideDatabasePathForTesting(null);
  BackupService.overrideDocumentsDirectoryForTesting(null);
  if (await tempDir.exists()) {
    await tempDir.delete(recursive: true);
  }
}

