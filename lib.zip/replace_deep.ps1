Get-ChildItem -Path "lib", "test" -Filter "*.dart" -Recurse | ForEach-Object {
    if (Test-Path $_ -PathType Leaf) {
        $content = Get-Content $_.FullName -Raw
        $content = $content -creplace 'fragrance', 'kelengkapan'
        $content = $content -creplace 'Fragrance', 'Kelengkapan'
        $content = $content -creplace '(?i)pewangi', 'Kelengkapan'
        $content = $content -creplace 'kiloan', 'hardware'
        $content = $content -creplace 'Kiloan', 'Hardware'
        $content = $content -creplace 'satuan', 'software'
        $content = $content -creplace 'Satuan', 'Software'
        $content = $content -creplace 'Cuci', 'Pengecekan'
        $content = $content -creplace 'Pengeringan', 'Menunggu Part'
        $content = $content -creplace 'Setrika', 'Perbaikan'
        $content = $content -creplace 'Jemur', 'QC'
        $content = $content -creplace 'cuci', 'pengecekan'
        $content = $content -creplace 'pengeringan', 'menunggu_part'
        $content = $content -creplace 'setrika', 'perbaikan'
        $content = $content -creplace 'jemur', 'qc'
        Set-Content $_.FullName $content
    }
}
